// TFXSTL.h  - STL typedef declarations

#include <vector>
#include <list>

using namespace std;

typedef vector<void*> CPointerArray;
typedef list<void*> CPointerList;