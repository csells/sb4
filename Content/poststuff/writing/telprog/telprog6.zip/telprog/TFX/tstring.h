// tstring.h

#ifndef TSTRING_H
#define TSTRING_H

#include <string>   // string and wstring

#ifdef UNICODE
#define tstring wstring
#else
#define tstring string
#endif

#endif  // TSTRING_H
