// This code is a part of the Telephony Framework C++ Library.
// Copyright (C) 1997 Chris Sells. All rights reserved.
// TfxPhone.h: All necessary TFX Phone related classes

#ifndef TFXPHONE_H
#define TFXPHONE_H

#include "TfxShared.h"
#include "tAppSink.h"
#include "tPhone.h"
#include "tPhoneSink.h"
#include "tPhoneCaps.h"
#include "tDeviceID.h"

DWORD TfxGetNumPhones();
TRESULT TfxPhoneInitialize(CtAppSink* pAppSink = 0, LPCSTR szAppName = 0,
                        HINSTANCE hInst = 0);
void TfxPhoneShutdown();

TRESULT TfxPhoneGetIcon(DWORD nPhoneID,
                        LPHICON phicon,
                        LPCSTR pszDeviceClass = 0);

#endif  // TFXPHONE_H