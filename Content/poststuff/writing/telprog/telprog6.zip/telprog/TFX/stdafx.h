// This code is a part of the Telephony Framework C++ Library.
// Copyright (C) 1997 Chris Sells. All rights reserved.
// stdafx.h: Header to precompile

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

// Uncomment for released versions
//#define NDEBUG
#include <assert.h>
//#include <afxwin.h>         // MFC core and standard components
