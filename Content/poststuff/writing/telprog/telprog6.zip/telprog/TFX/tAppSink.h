// This code is a part of the Telephony Framework C++ Library.
// Copyright (C) 1997 Chris Sells. All rights reserved.
// tAppSink.h: CtAppSink class interface

#ifndef TAPPSINK_H
#define TAPPSINK_H

#include "TfxShared.h"

class CtAppSink
{
public:
    // Sink events (placeholders for overriding only)
    virtual void    OnLineCreate(DWORD nLineID) {}
    virtual void    OnPhoneCreate(DWORD nPhoneID) {}
    virtual void    OnLineRequest(DWORD nRequestMode, HWND hRequestWnd, TREQUEST nRequestID) {}
};

#endif  // TAPPSINK_H