// CallScreenDlg.cpp : implementation file
//

#include "stdafx.h"
#include "tMonitor.h"
#include "CallScreenDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCallScreenDlg dialog


CCallScreenDlg::CCallScreenDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCallScreenDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCallScreenDlg)
	m_nRings = 0;
	//}}AFX_DATA_INIT
}


void CCallScreenDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCallScreenDlg)
	DDX_Control(pDX, IDC_SPIN, m_spin);
	DDX_Text(pDX, IDC_RINGS, m_nRings);
	DDV_MinMaxInt(pDX, m_nRings, 0, 4);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCallScreenDlg, CDialog)
	//{{AFX_MSG_MAP(CCallScreenDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCallScreenDlg message handlers

BOOL CCallScreenDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
    m_spin.SetRange(0, 4);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
