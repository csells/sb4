// IncomingCallDlg.h : header file
//

#include <tWave.h>  // CtWave

/////////////////////////////////////////////////////////////////////////////
// CIncomingCallDlg dialog

class CIncomingCallDlg :
    public CDialog,
    public CtCallSink,
    public CtWaveSink
{
// Construction
public:
	void Answer();
	void Drop();
	BOOL DoModeless(CWnd* pParentWnd = 0);
	CIncomingCallDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CIncomingCallDlg)
	enum { IDD = IDD_CALL };
	CString	m_sName;
	CString	m_sPhoneNo;
	//}}AFX_DATA

    CtCall* m_pCall;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIncomingCallDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CIncomingCallDlg)
	afx_msg void OnHangUp();
	afx_msg void OnTakeCall();
	afx_msg void OnTakeMessage();
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

    friend class CtMonitorView;

private:
    enum TODO
    {
        todoNothing,
        todoTakeMessage,
        todoTakeCall,
    };
    TODO    m_todo;
    CtWave  m_wave;
    char    m_szDigitBuffer[2]; // One digit and null
    CtPhone m_phone;    // Used to set speakerphone mode

    // Call events
    virtual void    OnCallState(CtCall* pCall, DWORD nCallState, DWORD dwParam2, DWORD nCallPriviledge);
    virtual void    OnCallMonitorDigits(CtCall* pCall, char cDigit, DWORD nDigitMode);

    // Wave events
    virtual void OnWaveOutDone();
    virtual void OnWaveInData();
};
