// ListViewExt.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CListViewEx view

class CListViewEx : public CListView
{
protected:
	CListViewEx();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CListViewEx)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CListViewEx();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

    virtual LPCSTR  GetColumnText(int nColumn, LPARAM lParam) = 0;
    virtual void    DrawItem(LPDRAWITEMSTRUCT lpDrawItem);

	// Generated message map functions
protected:
	//{{AFX_MSG(CListViewEx)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
    void    DrawItemColumn(HDC hdc, LPCTSTR lpsz, LPRECT prcClip);
    BOOL    CalcStringEllipsis(HDC hdc, LPTSTR lpszString, int cchMax, UINT uColWidth);
};

/////////////////////////////////////////////////////////////////////////////
