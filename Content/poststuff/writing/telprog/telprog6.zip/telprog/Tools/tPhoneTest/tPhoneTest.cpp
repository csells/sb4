// tPhoneTest.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "tPhoneTest.h"
#include "tPhoneTestDlg.h"
#include "tPhoneNo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTPhoneTestApp

BEGIN_MESSAGE_MAP(CTPhoneTestApp, CWinApp)
	//{{AFX_MSG_MAP(CTPhoneTestApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTPhoneTestApp construction

CTPhoneTestApp::CTPhoneTestApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CTPhoneTestApp object

CTPhoneTestApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CTPhoneTestApp initialization

BOOL CTPhoneTestApp::InitInstance()
{
    // Test the copy constructor and the assignment operator
    CtPhoneNo   pno1("+1 648-1234");
    TRACE("pno1= %s\n", pno1.GetTranslatable(0));

    CtPhoneNo   pno2 = pno1;
    TRACE("pno2= %s (should equal pno1)\n", pno2.GetTranslatable(0));

    CtPhoneNo   pno3("911");
    TRACE("pno3= %s\n", pno3.GetTranslatable(0));

    pno3 = pno1;
    TRACE("pno3= %s (should equal pno1)\n", pno3.GetTranslatable(0));

	// Show the dialog
	CTPhoneTestDlg dlg;
	m_pMainWnd = &dlg;
	dlg.DoModal();

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
