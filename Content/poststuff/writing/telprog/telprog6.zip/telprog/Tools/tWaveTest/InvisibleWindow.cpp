#include "stdafx.h"
#include <InvisibleWindow.cpp>