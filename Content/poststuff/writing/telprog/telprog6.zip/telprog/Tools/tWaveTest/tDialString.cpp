#include "stdafx.h"
#include <tDialString.cpp>
