LONG WINAPI lineAccept(
    HCALL a0,
    LPCSTR a1,
    DWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPCSTR,     DWORD)> fp(g_hinstThat, "lineAccept");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineAddProvider(
    LPCSTR a0,
    HWND a1,
    LPDWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    LPCSTR,     HWND,     LPDWORD)> fp(g_hinstThat, "lineAddProvider");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineAddProviderA(
    LPCSTR a0,
    HWND a1,
    LPDWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    LPCSTR,     HWND,     LPDWORD)> fp(g_hinstThat, "lineAddProviderA");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineAddProviderW(
    LPCWSTR a0,
    HWND a1,
    LPDWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    LPCWSTR,     HWND,     LPDWORD)> fp(g_hinstThat, "lineAddProviderW");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineAddToConference(
    HCALL a0,
    HCALL a1)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     HCALL)> fp(g_hinstThat, "lineAddToConference");
    return fp.Trace(fp()(a0, a1));
}

LONG WINAPI lineAgentSpecific(
    HLINE a0,
    DWORD a1,
    DWORD a2,
    LPVOID a3,
    DWORD a4)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     DWORD,     LPVOID,     DWORD)> fp(g_hinstThat, "lineAgentSpecific");
    return fp.Trace(fp()(a0, a1, a2, a3, a4));
}

LONG WINAPI lineAnswer(
    HCALL a0,
    LPCSTR a1,
    DWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPCSTR,     DWORD)> fp(g_hinstThat, "lineAnswer");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineBlindTransfer(
    HCALL a0,
    LPCSTR a1,
    DWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPCSTR,     DWORD)> fp(g_hinstThat, "lineBlindTransfer");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineBlindTransferA(
    HCALL a0,
    LPCSTR a1,
    DWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPCSTR,     DWORD)> fp(g_hinstThat, "lineBlindTransferA");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineBlindTransferW(
    HCALL a0,
    LPCWSTR a1,
    DWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPCWSTR,     DWORD)> fp(g_hinstThat, "lineBlindTransferW");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineClose(
    HLINE a0)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE)> fp(g_hinstThat, "lineClose");
    return fp.Trace(fp()(a0));
}

LONG WINAPI lineCompleteCall(
    HCALL a0,
    LPDWORD a1,
    DWORD a2,
    DWORD a3)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPDWORD,     DWORD,     DWORD)> fp(g_hinstThat, "lineCompleteCall");
    return fp.Trace(fp()(a0, a1, a2, a3));
}

LONG WINAPI lineCompleteTransfer(
    HCALL a0,
    HCALL a1,
    LPHCALL a2,
    DWORD a3)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     HCALL,     LPHCALL,     DWORD)> fp(g_hinstThat, "lineCompleteTransfer");
    return fp.Trace(fp()(a0, a1, a2, a3));
}

LONG WINAPI lineConfigDialog(
    DWORD a0,
    HWND a1,
    LPCSTR a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    DWORD,     HWND,     LPCSTR)> fp(g_hinstThat, "lineConfigDialog");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineConfigDialogA(
    DWORD a0,
    HWND a1,
    LPCSTR a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    DWORD,     HWND,     LPCSTR)> fp(g_hinstThat, "lineConfigDialogA");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineConfigDialogW(
    DWORD a0,
    HWND a1,
    LPCWSTR a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    DWORD,     HWND,     LPCWSTR)> fp(g_hinstThat, "lineConfigDialogW");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineConfigDialogEdit(
    DWORD a0,
    HWND a1,
    LPCSTR a2,
    LPVOID a3,
    DWORD a4,
    LPVARSTRING a5)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    DWORD,     HWND,     LPCSTR,     LPVOID,     DWORD,     LPVARSTRING)> fp(g_hinstThat, "lineConfigDialogEdit");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5));
}

LONG WINAPI lineConfigDialogEditA(
    DWORD a0,
    HWND a1,
    LPCSTR a2,
    LPVOID a3,
    DWORD a4,
    LPVARSTRING a5)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    DWORD,     HWND,     LPCSTR,     LPVOID,     DWORD,     LPVARSTRING)> fp(g_hinstThat, "lineConfigDialogEditA");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5));
}

LONG WINAPI lineConfigDialogEditW(
    DWORD a0,
    HWND a1,
    LPCWSTR a2,
    LPVOID a3,
    DWORD a4,
    LPVARSTRING a5)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    DWORD,     HWND,     LPCWSTR,     LPVOID,     DWORD,     LPVARSTRING)> fp(g_hinstThat, "lineConfigDialogEditW");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5));
}

LONG WINAPI lineConfigProvider(
    HWND a0,
    DWORD a1)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HWND,     DWORD)> fp(g_hinstThat, "lineConfigProvider");
    return fp.Trace(fp()(a0, a1));
}

LONG WINAPI lineDeallocateCall(
    HCALL a0)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL)> fp(g_hinstThat, "lineDeallocateCall");
    return fp.Trace(fp()(a0));
}

LONG WINAPI lineDevSpecific(
    HLINE a0,
    DWORD a1,
    HCALL a2,
    LPVOID a3,
    DWORD a4)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     HCALL,     LPVOID,     DWORD)> fp(g_hinstThat, "lineDevSpecific");
    return fp.Trace(fp()(a0, a1, a2, a3, a4));
}

LONG WINAPI lineDevSpecificFeature(
    HLINE a0,
    DWORD a1,
    LPVOID a2,
    DWORD a3)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     LPVOID,     DWORD)> fp(g_hinstThat, "lineDevSpecificFeature");
    return fp.Trace(fp()(a0, a1, a2, a3));
}

LONG WINAPI lineDial(
    HCALL a0,
    LPCSTR a1,
    DWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPCSTR,     DWORD)> fp(g_hinstThat, "lineDial");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineDialA(
    HCALL a0,
    LPCSTR a1,
    DWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPCSTR,     DWORD)> fp(g_hinstThat, "lineDialA");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineDialW(
    HCALL a0,
    LPCWSTR a1,
    DWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPCWSTR,     DWORD)> fp(g_hinstThat, "lineDialW");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineDrop(
    HCALL a0,
    LPCSTR a1,
    DWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPCSTR,     DWORD)> fp(g_hinstThat, "lineDrop");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineForward(
    HLINE a0,
    DWORD a1,
    DWORD a2,
    LPLINEFORWARDLIST a3,
    DWORD a4,
    LPHCALL a5,
    LPLINECALLPARAMS a6)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     DWORD,     LPLINEFORWARDLIST,     DWORD,     LPHCALL,     LPLINECALLPARAMS)> fp(g_hinstThat, "lineForward");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5, a6));
}

LONG WINAPI lineForwardA(
    HLINE a0,
    DWORD a1,
    DWORD a2,
    LPLINEFORWARDLIST a3,
    DWORD a4,
    LPHCALL a5,
    LPLINECALLPARAMS a6)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     DWORD,     LPLINEFORWARDLIST,     DWORD,     LPHCALL,     LPLINECALLPARAMS)> fp(g_hinstThat, "lineForwardA");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5, a6));
}

LONG WINAPI lineForwardW(
    HLINE a0,
    DWORD a1,
    DWORD a2,
    LPLINEFORWARDLIST a3,
    DWORD a4,
    LPHCALL a5,
    LPLINECALLPARAMS a6)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     DWORD,     LPLINEFORWARDLIST,     DWORD,     LPHCALL,     LPLINECALLPARAMS)> fp(g_hinstThat, "lineForwardW");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5, a6));
}

LONG WINAPI lineGatherDigits(
    HCALL a0,
    DWORD a1,
    LPSTR a2,
    DWORD a3,
    LPCSTR a4,
    DWORD a5,
    DWORD a6)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     DWORD,     LPSTR,     DWORD,     LPCSTR,     DWORD,     DWORD)> fp(g_hinstThat, "lineGatherDigits");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5, a6));
}

LONG WINAPI lineGatherDigitsA(
    HCALL a0,
    DWORD a1,
    LPSTR a2,
    DWORD a3,
    LPCSTR a4,
    DWORD a5,
    DWORD a6)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     DWORD,     LPSTR,     DWORD,     LPCSTR,     DWORD,     DWORD)> fp(g_hinstThat, "lineGatherDigitsA");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5, a6));
}

LONG WINAPI lineGatherDigitsW(
    HCALL a0,
    DWORD a1,
    LPWSTR a2,
    DWORD a3,
    LPCWSTR a4,
    DWORD a5,
    DWORD a6)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     DWORD,     LPWSTR,     DWORD,     LPCWSTR,     DWORD,     DWORD)> fp(g_hinstThat, "lineGatherDigitsW");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5, a6));
}

LONG WINAPI lineGenerateDigits(
    HCALL a0,
    DWORD a1,
    LPCSTR a2,
    DWORD a3)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     DWORD,     LPCSTR,     DWORD)> fp(g_hinstThat, "lineGenerateDigits");
    return fp.Trace(fp()(a0, a1, a2, a3));
}

LONG WINAPI lineGenerateDigitsA(
    HCALL a0,
    DWORD a1,
    LPCSTR a2,
    DWORD a3)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     DWORD,     LPCSTR,     DWORD)> fp(g_hinstThat, "lineGenerateDigitsA");
    return fp.Trace(fp()(a0, a1, a2, a3));
}

LONG WINAPI lineGenerateDigitsW(
    HCALL a0,
    DWORD a1,
    LPCWSTR a2,
    DWORD a3)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     DWORD,     LPCWSTR,     DWORD)> fp(g_hinstThat, "lineGenerateDigitsW");
    return fp.Trace(fp()(a0, a1, a2, a3));
}

LONG WINAPI lineGenerateTone(
    HCALL a0,
    DWORD a1,
    DWORD a2,
    DWORD a3,
    LPLINEGENERATETONE a4)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     DWORD,     DWORD,     DWORD,     LPLINEGENERATETONE)> fp(g_hinstThat, "lineGenerateTone");
    return fp.Trace(fp()(a0, a1, a2, a3, a4));
}

LONG WINAPI lineGetAddressCaps(
    HLINEAPP a0,
    DWORD a1,
    DWORD a2,
    DWORD a3,
    DWORD a4,
    LPLINEADDRESSCAPS a5)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     DWORD,     DWORD,     DWORD,     LPLINEADDRESSCAPS)> fp(g_hinstThat, "lineGetAddressCaps");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5));
}

LONG WINAPI lineGetAddressCapsA(
    HLINEAPP a0,
    DWORD a1,
    DWORD a2,
    DWORD a3,
    DWORD a4,
    LPLINEADDRESSCAPS a5)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     DWORD,     DWORD,     DWORD,     LPLINEADDRESSCAPS)> fp(g_hinstThat, "lineGetAddressCapsA");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5));
}

LONG WINAPI lineGetAddressCapsW(
    HLINEAPP a0,
    DWORD a1,
    DWORD a2,
    DWORD a3,
    DWORD a4,
    LPLINEADDRESSCAPS a5)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     DWORD,     DWORD,     DWORD,     LPLINEADDRESSCAPS)> fp(g_hinstThat, "lineGetAddressCapsW");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5));
}

LONG WINAPI lineGetAddressID(
    HLINE a0,
    LPDWORD a1,
    DWORD a2,
    LPCSTR a3,
    DWORD a4)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     LPDWORD,     DWORD,     LPCSTR,     DWORD)> fp(g_hinstThat, "lineGetAddressID");
    return fp.Trace(fp()(a0, a1, a2, a3, a4));
}

LONG WINAPI lineGetAddressIDA(
    HLINE a0,
    LPDWORD a1,
    DWORD a2,
    LPCSTR a3,
    DWORD a4)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     LPDWORD,     DWORD,     LPCSTR,     DWORD)> fp(g_hinstThat, "lineGetAddressIDA");
    return fp.Trace(fp()(a0, a1, a2, a3, a4));
}

LONG WINAPI lineGetAddressIDW(
    HLINE a0,
    LPDWORD a1,
    DWORD a2,
    LPCWSTR a3,
    DWORD a4)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     LPDWORD,     DWORD,     LPCWSTR,     DWORD)> fp(g_hinstThat, "lineGetAddressIDW");
    return fp.Trace(fp()(a0, a1, a2, a3, a4));
}

LONG WINAPI lineGetAddressStatus(
    HLINE a0,
    DWORD a1,
    LPLINEADDRESSSTATUS a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     LPLINEADDRESSSTATUS)> fp(g_hinstThat, "lineGetAddressStatus");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineGetAddressStatusA(
    HLINE a0,
    DWORD a1,
    LPLINEADDRESSSTATUS a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     LPLINEADDRESSSTATUS)> fp(g_hinstThat, "lineGetAddressStatusA");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineGetAddressStatusW(
    HLINE a0,
    DWORD a1,
    LPLINEADDRESSSTATUS a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     LPLINEADDRESSSTATUS)> fp(g_hinstThat, "lineGetAddressStatusW");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineGetAgentActivityListA(
    HLINE a0,
    DWORD a1,
    LPLINEAGENTACTIVITYLIST a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     LPLINEAGENTACTIVITYLIST)> fp(g_hinstThat, "lineGetAgentActivityListA");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineGetAgentActivityListW(
    HLINE a0,
    DWORD a1,
    LPLINEAGENTACTIVITYLIST a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     LPLINEAGENTACTIVITYLIST)> fp(g_hinstThat, "lineGetAgentActivityListW");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineGetAgentCapsA(
    HLINEAPP a0,
    DWORD a1,
    DWORD a2,
    DWORD a3,
    LPLINEAGENTCAPS a4)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     DWORD,     DWORD,     LPLINEAGENTCAPS)> fp(g_hinstThat, "lineGetAgentCapsA");
    return fp.Trace(fp()(a0, a1, a2, a3, a4));
}

LONG WINAPI lineGetAgentCapsW(
    HLINEAPP a0,
    DWORD a1,
    DWORD a2,
    DWORD a3,
    LPLINEAGENTCAPS a4)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     DWORD,     DWORD,     LPLINEAGENTCAPS)> fp(g_hinstThat, "lineGetAgentCapsW");
    return fp.Trace(fp()(a0, a1, a2, a3, a4));
}

LONG WINAPI lineGetAgentGroupListA(
    HLINE a0,
    DWORD a1,
    LPLINEAGENTGROUPLIST a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     LPLINEAGENTGROUPLIST)> fp(g_hinstThat, "lineGetAgentGroupListA");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineGetAgentGroupListW(
    HLINE a0,
    DWORD a1,
    LPLINEAGENTGROUPLIST a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     LPLINEAGENTGROUPLIST)> fp(g_hinstThat, "lineGetAgentGroupListW");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineGetAgentStatusA(
    HLINE a0,
    DWORD a1,
    LPLINEAGENTSTATUS a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     LPLINEAGENTSTATUS)> fp(g_hinstThat, "lineGetAgentStatusA");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineGetAgentStatusW(
    HLINE a0,
    DWORD a1,
    LPLINEAGENTSTATUS a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     LPLINEAGENTSTATUS)> fp(g_hinstThat, "lineGetAgentStatusW");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineGetAppPriority(
    LPCSTR a0,
    DWORD a1,
    LPLINEEXTENSIONID a2,
    DWORD a3,
    LPVARSTRING a4,
    LPDWORD a5)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    LPCSTR,     DWORD,     LPLINEEXTENSIONID,     DWORD,     LPVARSTRING,     LPDWORD)> fp(g_hinstThat, "lineGetAppPriority");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5));
}

LONG WINAPI lineGetAppPriorityA(
    LPCSTR a0,
    DWORD a1,
    LPLINEEXTENSIONID a2,
    DWORD a3,
    LPVARSTRING a4,
    LPDWORD a5)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    LPCSTR,     DWORD,     LPLINEEXTENSIONID,     DWORD,     LPVARSTRING,     LPDWORD)> fp(g_hinstThat, "lineGetAppPriorityA");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5));
}

LONG WINAPI lineGetAppPriorityW(
    LPCWSTR a0,
    DWORD a1,
    LPLINEEXTENSIONID a2,
    DWORD a3,
    LPVARSTRING a4,
    LPDWORD a5)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    LPCWSTR,     DWORD,     LPLINEEXTENSIONID,     DWORD,     LPVARSTRING,     LPDWORD)> fp(g_hinstThat, "lineGetAppPriorityW");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5));
}

LONG WINAPI lineGetCallInfo(
    HCALL a0,
    LPLINECALLINFO a1)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPLINECALLINFO)> fp(g_hinstThat, "lineGetCallInfo");
    return fp.Trace(fp()(a0, a1));
}

LONG WINAPI lineGetCallInfoA(
    HCALL a0,
    LPLINECALLINFO a1)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPLINECALLINFO)> fp(g_hinstThat, "lineGetCallInfoA");
    return fp.Trace(fp()(a0, a1));
}

LONG WINAPI lineGetCallInfoW(
    HCALL a0,
    LPLINECALLINFO a1)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPLINECALLINFO)> fp(g_hinstThat, "lineGetCallInfoW");
    return fp.Trace(fp()(a0, a1));
}

LONG WINAPI lineGetCallStatus(
    HCALL a0,
    LPLINECALLSTATUS a1)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPLINECALLSTATUS)> fp(g_hinstThat, "lineGetCallStatus");
    return fp.Trace(fp()(a0, a1));
}

LONG WINAPI lineGetConfRelatedCalls(
    HCALL a0,
    LPLINECALLLIST a1)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPLINECALLLIST)> fp(g_hinstThat, "lineGetConfRelatedCalls");
    return fp.Trace(fp()(a0, a1));
}

LONG WINAPI lineGetCountry(
    DWORD a0,
    DWORD a1,
    LPLINECOUNTRYLIST a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    DWORD,     DWORD,     LPLINECOUNTRYLIST)> fp(g_hinstThat, "lineGetCountry");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineGetCountryA(
    DWORD a0,
    DWORD a1,
    LPLINECOUNTRYLIST a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    DWORD,     DWORD,     LPLINECOUNTRYLIST)> fp(g_hinstThat, "lineGetCountryA");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineGetCountryW(
    DWORD a0,
    DWORD a1,
    LPLINECOUNTRYLIST a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    DWORD,     DWORD,     LPLINECOUNTRYLIST)> fp(g_hinstThat, "lineGetCountryW");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineGetDevCaps(
    HLINEAPP a0,
    DWORD a1,
    DWORD a2,
    DWORD a3,
    LPLINEDEVCAPS a4)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     DWORD,     DWORD,     LPLINEDEVCAPS)> fp(g_hinstThat, "lineGetDevCaps");
    return fp.Trace(fp()(a0, a1, a2, a3, a4));
}

LONG WINAPI lineGetDevCapsA(
    HLINEAPP a0,
    DWORD a1,
    DWORD a2,
    DWORD a3,
    LPLINEDEVCAPS a4)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     DWORD,     DWORD,     LPLINEDEVCAPS)> fp(g_hinstThat, "lineGetDevCapsA");
    return fp.Trace(fp()(a0, a1, a2, a3, a4));
}

LONG WINAPI lineGetDevCapsW(
    HLINEAPP a0,
    DWORD a1,
    DWORD a2,
    DWORD a3,
    LPLINEDEVCAPS a4)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     DWORD,     DWORD,     LPLINEDEVCAPS)> fp(g_hinstThat, "lineGetDevCapsW");
    return fp.Trace(fp()(a0, a1, a2, a3, a4));
}

LONG WINAPI lineGetDevConfig(
    DWORD a0,
    LPVARSTRING a1,
    LPCSTR a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    DWORD,     LPVARSTRING,     LPCSTR)> fp(g_hinstThat, "lineGetDevConfig");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineGetDevConfigA(
    DWORD a0,
    LPVARSTRING a1,
    LPCSTR a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    DWORD,     LPVARSTRING,     LPCSTR)> fp(g_hinstThat, "lineGetDevConfigA");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineGetDevConfigW(
    DWORD a0,
    LPVARSTRING a1,
    LPCWSTR a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    DWORD,     LPVARSTRING,     LPCWSTR)> fp(g_hinstThat, "lineGetDevConfigW");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineGetNewCalls(
    HLINE a0,
    DWORD a1,
    DWORD a2,
    LPLINECALLLIST a3)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     DWORD,     LPLINECALLLIST)> fp(g_hinstThat, "lineGetNewCalls");
    return fp.Trace(fp()(a0, a1, a2, a3));
}

LONG WINAPI lineGetIcon(
    DWORD a0,
    LPCSTR a1,
    LPHICON a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    DWORD,     LPCSTR,     LPHICON)> fp(g_hinstThat, "lineGetIcon");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineGetIconA(
    DWORD a0,
    LPCSTR a1,
    LPHICON a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    DWORD,     LPCSTR,     LPHICON)> fp(g_hinstThat, "lineGetIconA");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineGetIconW(
    DWORD a0,
    LPCWSTR a1,
    LPHICON a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    DWORD,     LPCWSTR,     LPHICON)> fp(g_hinstThat, "lineGetIconW");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineGetID(
    HLINE a0,
    DWORD a1,
    HCALL a2,
    DWORD a3,
    LPVARSTRING a4,
    LPCSTR a5)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     HCALL,     DWORD,     LPVARSTRING,     LPCSTR)> fp(g_hinstThat, "lineGetID");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5));
}

LONG WINAPI lineGetIDA(
    HLINE a0,
    DWORD a1,
    HCALL a2,
    DWORD a3,
    LPVARSTRING a4,
    LPCSTR a5)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     HCALL,     DWORD,     LPVARSTRING,     LPCSTR)> fp(g_hinstThat, "lineGetIDA");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5));
}

LONG WINAPI lineGetIDW(
    HLINE a0,
    DWORD a1,
    HCALL a2,
    DWORD a3,
    LPVARSTRING a4,
    LPCWSTR a5)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     HCALL,     DWORD,     LPVARSTRING,     LPCWSTR)> fp(g_hinstThat, "lineGetIDW");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5));
}

LONG WINAPI lineGetLineDevStatus(
    HLINE a0,
    LPLINEDEVSTATUS a1)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     LPLINEDEVSTATUS)> fp(g_hinstThat, "lineGetLineDevStatus");
    return fp.Trace(fp()(a0, a1));
}

LONG WINAPI lineGetLineDevStatusA(
    HLINE a0,
    LPLINEDEVSTATUS a1)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     LPLINEDEVSTATUS)> fp(g_hinstThat, "lineGetLineDevStatusA");
    return fp.Trace(fp()(a0, a1));
}

LONG WINAPI lineGetLineDevStatusW(
    HLINE a0,
    LPLINEDEVSTATUS a1)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     LPLINEDEVSTATUS)> fp(g_hinstThat, "lineGetLineDevStatusW");
    return fp.Trace(fp()(a0, a1));
}

LONG WINAPI lineGetMessage(
    HLINEAPP a0,
    LPLINEMESSAGE a1,
    DWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     LPLINEMESSAGE,     DWORD)> fp(g_hinstThat, "lineGetMessage");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineGetNumRings(
    HLINE a0,
    DWORD a1,
    LPDWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     LPDWORD)> fp(g_hinstThat, "lineGetNumRings");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineGetProviderList(
    DWORD a0,
    LPLINEPROVIDERLIST a1)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    DWORD,     LPLINEPROVIDERLIST)> fp(g_hinstThat, "lineGetProviderList");
    return fp.Trace(fp()(a0, a1));
}

LONG WINAPI lineGetProviderListA(
    DWORD a0,
    LPLINEPROVIDERLIST a1)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    DWORD,     LPLINEPROVIDERLIST)> fp(g_hinstThat, "lineGetProviderListA");
    return fp.Trace(fp()(a0, a1));
}

LONG WINAPI lineGetProviderListW(
    DWORD a0,
    LPLINEPROVIDERLIST a1)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    DWORD,     LPLINEPROVIDERLIST)> fp(g_hinstThat, "lineGetProviderListW");
    return fp.Trace(fp()(a0, a1));
}

LONG WINAPI lineGetRequest(
    HLINEAPP a0,
    DWORD a1,
    LPVOID a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     LPVOID)> fp(g_hinstThat, "lineGetRequest");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineGetRequestA(
    HLINEAPP a0,
    DWORD a1,
    LPVOID a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     LPVOID)> fp(g_hinstThat, "lineGetRequestA");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineGetRequestW(
    HLINEAPP a0,
    DWORD a1,
    LPVOID a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     LPVOID)> fp(g_hinstThat, "lineGetRequestW");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineGetStatusMessages(
    HLINE a0,
    LPDWORD a1,
    LPDWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     LPDWORD,     LPDWORD)> fp(g_hinstThat, "lineGetStatusMessages");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineGetTranslateCaps(
    HLINEAPP a0,
    DWORD a1,
    LPLINETRANSLATECAPS a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     LPLINETRANSLATECAPS)> fp(g_hinstThat, "lineGetTranslateCaps");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineGetTranslateCapsA(
    HLINEAPP a0,
    DWORD a1,
    LPLINETRANSLATECAPS a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     LPLINETRANSLATECAPS)> fp(g_hinstThat, "lineGetTranslateCapsA");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineGetTranslateCapsW(
    HLINEAPP a0,
    DWORD a1,
    LPLINETRANSLATECAPS a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     LPLINETRANSLATECAPS)> fp(g_hinstThat, "lineGetTranslateCapsW");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineHandoff(
    HCALL a0,
    LPCSTR a1,
    DWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPCSTR,     DWORD)> fp(g_hinstThat, "lineHandoff");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineHandoffA(
    HCALL a0,
    LPCSTR a1,
    DWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPCSTR,     DWORD)> fp(g_hinstThat, "lineHandoffA");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineHandoffW(
    HCALL a0,
    LPCWSTR a1,
    DWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPCWSTR,     DWORD)> fp(g_hinstThat, "lineHandoffW");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineHold(
    HCALL a0)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL)> fp(g_hinstThat, "lineHold");
    return fp.Trace(fp()(a0));
}

LONG WINAPI lineInitialize(
    LPHLINEAPP a0,
    HINSTANCE a1,
    LINECALLBACK a2,
    LPCSTR a3,
    LPDWORD a4)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    LPHLINEAPP,     HINSTANCE,     LINECALLBACK,     LPCSTR,     LPDWORD)> fp(g_hinstThat, "lineInitialize");
    return fp.Trace(fp()(a0, a1, a2, a3, a4));
}

LONG WINAPI lineInitializeExA(
    LPHLINEAPP a0,
    HINSTANCE a1,
    LINECALLBACK a2,
    LPCSTR a3,
    LPDWORD a4,
    LPDWORD a5,
    LPLINEINITIALIZEEXPARAMS a6)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    LPHLINEAPP,     HINSTANCE,     LINECALLBACK,     LPCSTR,     LPDWORD,     LPDWORD,     LPLINEINITIALIZEEXPARAMS)> fp(g_hinstThat, "lineInitializeExA");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5, a6));
}

LONG WINAPI lineInitializeExW(
    LPHLINEAPP a0,
    HINSTANCE a1,
    LINECALLBACK a2,
    LPCWSTR a3,
    LPDWORD a4,
    LPDWORD a5,
    LPLINEINITIALIZEEXPARAMS a6)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    LPHLINEAPP,     HINSTANCE,     LINECALLBACK,     LPCWSTR,     LPDWORD,     LPDWORD,     LPLINEINITIALIZEEXPARAMS)> fp(g_hinstThat, "lineInitializeExW");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5, a6));
}

LONG WINAPI lineMakeCall(
    HLINE a0,
    LPHCALL a1,
    LPCSTR a2,
    DWORD a3,
    LPLINECALLPARAMS a4)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     LPHCALL,     LPCSTR,     DWORD,     LPLINECALLPARAMS)> fp(g_hinstThat, "lineMakeCall");
    return fp.Trace(fp()(a0, a1, a2, a3, a4));
}

LONG WINAPI lineMakeCallA(
    HLINE a0,
    LPHCALL a1,
    LPCSTR a2,
    DWORD a3,
    LPLINECALLPARAMS a4)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     LPHCALL,     LPCSTR,     DWORD,     LPLINECALLPARAMS)> fp(g_hinstThat, "lineMakeCallA");
    return fp.Trace(fp()(a0, a1, a2, a3, a4));
}

LONG WINAPI lineMakeCallW(
    HLINE a0,
    LPHCALL a1,
    LPCWSTR a2,
    DWORD a3,
    LPLINECALLPARAMS a4)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     LPHCALL,     LPCWSTR,     DWORD,     LPLINECALLPARAMS)> fp(g_hinstThat, "lineMakeCallW");
    return fp.Trace(fp()(a0, a1, a2, a3, a4));
}

LONG WINAPI lineMonitorDigits(
    HCALL a0,
    DWORD a1)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     DWORD)> fp(g_hinstThat, "lineMonitorDigits");
    return fp.Trace(fp()(a0, a1));
}

LONG WINAPI lineMonitorMedia(
    HCALL a0,
    DWORD a1)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     DWORD)> fp(g_hinstThat, "lineMonitorMedia");
    return fp.Trace(fp()(a0, a1));
}

LONG WINAPI lineMonitorTones(
    HCALL a0,
    LPLINEMONITORTONE a1,
    DWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPLINEMONITORTONE,     DWORD)> fp(g_hinstThat, "lineMonitorTones");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineNegotiateAPIVersion(
    HLINEAPP a0,
    DWORD a1,
    DWORD a2,
    DWORD a3,
    LPDWORD a4,
    LPLINEEXTENSIONID a5)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     DWORD,     DWORD,     LPDWORD,     LPLINEEXTENSIONID)> fp(g_hinstThat, "lineNegotiateAPIVersion");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5));
}

LONG WINAPI lineNegotiateExtVersion(
    HLINEAPP a0,
    DWORD a1,
    DWORD a2,
    DWORD a3,
    DWORD a4,
    LPDWORD a5)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     DWORD,     DWORD,     DWORD,     LPDWORD)> fp(g_hinstThat, "lineNegotiateExtVersion");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5));
}

LONG WINAPI lineOpen(
    HLINEAPP a0,
    DWORD a1,
    LPHLINE a2,
    DWORD a3,
    DWORD a4,
    DWORD a5,
    DWORD a6,
    DWORD a7,
    LPLINECALLPARAMS a8)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     LPHLINE,     DWORD,     DWORD,     DWORD,     DWORD,     DWORD,     LPLINECALLPARAMS)> fp(g_hinstThat, "lineOpen");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5, a6, a7, a8));
}

LONG WINAPI lineOpenA(
    HLINEAPP a0,
    DWORD a1,
    LPHLINE a2,
    DWORD a3,
    DWORD a4,
    DWORD a5,
    DWORD a6,
    DWORD a7,
    LPLINECALLPARAMS a8)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     LPHLINE,     DWORD,     DWORD,     DWORD,     DWORD,     DWORD,     LPLINECALLPARAMS)> fp(g_hinstThat, "lineOpenA");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5, a6, a7, a8));
}

LONG WINAPI lineOpenW(
    HLINEAPP a0,
    DWORD a1,
    LPHLINE a2,
    DWORD a3,
    DWORD a4,
    DWORD a5,
    DWORD a6,
    DWORD a7,
    LPLINECALLPARAMS a8)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     LPHLINE,     DWORD,     DWORD,     DWORD,     DWORD,     DWORD,     LPLINECALLPARAMS)> fp(g_hinstThat, "lineOpenW");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5, a6, a7, a8));
}

LONG WINAPI linePark(
    HCALL a0,
    DWORD a1,
    LPCSTR a2,
    LPVARSTRING a3)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     DWORD,     LPCSTR,     LPVARSTRING)> fp(g_hinstThat, "linePark");
    return fp.Trace(fp()(a0, a1, a2, a3));
}

LONG WINAPI lineParkA(
    HCALL a0,
    DWORD a1,
    LPCSTR a2,
    LPVARSTRING a3)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     DWORD,     LPCSTR,     LPVARSTRING)> fp(g_hinstThat, "lineParkA");
    return fp.Trace(fp()(a0, a1, a2, a3));
}

LONG WINAPI lineParkW(
    HCALL a0,
    DWORD a1,
    LPCWSTR a2,
    LPVARSTRING a3)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     DWORD,     LPCWSTR,     LPVARSTRING)> fp(g_hinstThat, "lineParkW");
    return fp.Trace(fp()(a0, a1, a2, a3));
}

LONG WINAPI linePickup(
    HLINE a0,
    DWORD a1,
    LPHCALL a2,
    LPCSTR a3,
    LPCSTR a4)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     LPHCALL,     LPCSTR,     LPCSTR)> fp(g_hinstThat, "linePickup");
    return fp.Trace(fp()(a0, a1, a2, a3, a4));
}

LONG WINAPI linePickupA(
    HLINE a0,
    DWORD a1,
    LPHCALL a2,
    LPCSTR a3,
    LPCSTR a4)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     LPHCALL,     LPCSTR,     LPCSTR)> fp(g_hinstThat, "linePickupA");
    return fp.Trace(fp()(a0, a1, a2, a3, a4));
}

LONG WINAPI linePickupW(
    HLINE a0,
    DWORD a1,
    LPHCALL a2,
    LPCWSTR a3,
    LPCWSTR a4)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     LPHCALL,     LPCWSTR,     LPCWSTR)> fp(g_hinstThat, "linePickupW");
    return fp.Trace(fp()(a0, a1, a2, a3, a4));
}

LONG WINAPI linePrepareAddToConference(
    HCALL a0,
    LPHCALL a1,
    LPLINECALLPARAMS a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPHCALL,     LPLINECALLPARAMS)> fp(g_hinstThat, "linePrepareAddToConference");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI linePrepareAddToConferenceA(
    HCALL a0,
    LPHCALL a1,
    LPLINECALLPARAMS a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPHCALL,     LPLINECALLPARAMS)> fp(g_hinstThat, "linePrepareAddToConferenceA");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI linePrepareAddToConferenceW(
    HCALL a0,
    LPHCALL a1,
    LPLINECALLPARAMS a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPHCALL,     LPLINECALLPARAMS)> fp(g_hinstThat, "linePrepareAddToConferenceW");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineProxyMessage(
    HLINE a0,
    HCALL a1,
    DWORD a2,
    DWORD a3,
    DWORD a4,
    DWORD a5)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     HCALL,     DWORD,     DWORD,     DWORD,     DWORD)> fp(g_hinstThat, "lineProxyMessage");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5));
}

LONG WINAPI lineProxyResponse(
    HLINE a0,
    LPLINEPROXYREQUEST a1,
    DWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     LPLINEPROXYREQUEST,     DWORD)> fp(g_hinstThat, "lineProxyResponse");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineRedirect(
    HCALL a0,
    LPCSTR a1,
    DWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPCSTR,     DWORD)> fp(g_hinstThat, "lineRedirect");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineRedirectA(
    HCALL a0,
    LPCSTR a1,
    DWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPCSTR,     DWORD)> fp(g_hinstThat, "lineRedirectA");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineRedirectW(
    HCALL a0,
    LPCWSTR a1,
    DWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPCWSTR,     DWORD)> fp(g_hinstThat, "lineRedirectW");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineRegisterRequestRecipient(
    HLINEAPP a0,
    DWORD a1,
    DWORD a2,
    DWORD a3)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     DWORD,     DWORD)> fp(g_hinstThat, "lineRegisterRequestRecipient");
    return fp.Trace(fp()(a0, a1, a2, a3));
}

LONG WINAPI lineReleaseUserUserInfo(
    HCALL a0)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL)> fp(g_hinstThat, "lineReleaseUserUserInfo");
    return fp.Trace(fp()(a0));
}

LONG WINAPI lineRemoveFromConference(
    HCALL a0)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL)> fp(g_hinstThat, "lineRemoveFromConference");
    return fp.Trace(fp()(a0));
}

LONG WINAPI lineRemoveProvider(
    DWORD a0,
    HWND a1)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    DWORD,     HWND)> fp(g_hinstThat, "lineRemoveProvider");
    return fp.Trace(fp()(a0, a1));
}

LONG WINAPI lineSecureCall(
    HCALL a0)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL)> fp(g_hinstThat, "lineSecureCall");
    return fp.Trace(fp()(a0));
}

LONG WINAPI lineSendUserUserInfo(
    HCALL a0,
    LPCSTR a1,
    DWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPCSTR,     DWORD)> fp(g_hinstThat, "lineSendUserUserInfo");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineSetAgentActivity(
    HLINE a0,
    DWORD a1,
    DWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     DWORD)> fp(g_hinstThat, "lineSetAgentActivity");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineSetAgentGroup(
    HLINE a0,
    DWORD a1,
    LPLINEAGENTGROUPLIST a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     LPLINEAGENTGROUPLIST)> fp(g_hinstThat, "lineSetAgentGroup");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineSetAgentState(
    HLINE a0,
    DWORD a1,
    DWORD a2,
    DWORD a3)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     DWORD,     DWORD)> fp(g_hinstThat, "lineSetAgentState");
    return fp.Trace(fp()(a0, a1, a2, a3));
}

LONG WINAPI lineSetAppPriority(
    LPCSTR a0,
    DWORD a1,
    LPLINEEXTENSIONID a2,
    DWORD a3,
    LPCSTR a4,
    DWORD a5)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    LPCSTR,     DWORD,     LPLINEEXTENSIONID,     DWORD,     LPCSTR,     DWORD)> fp(g_hinstThat, "lineSetAppPriority");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5));
}

LONG WINAPI lineSetAppPriorityA(
    LPCSTR a0,
    DWORD a1,
    LPLINEEXTENSIONID a2,
    DWORD a3,
    LPCSTR a4,
    DWORD a5)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    LPCSTR,     DWORD,     LPLINEEXTENSIONID,     DWORD,     LPCSTR,     DWORD)> fp(g_hinstThat, "lineSetAppPriorityA");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5));
}

LONG WINAPI lineSetAppPriorityW(
    LPCWSTR a0,
    DWORD a1,
    LPLINEEXTENSIONID a2,
    DWORD a3,
    LPCWSTR a4,
    DWORD a5)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    LPCWSTR,     DWORD,     LPLINEEXTENSIONID,     DWORD,     LPCWSTR,     DWORD)> fp(g_hinstThat, "lineSetAppPriorityW");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5));
}

LONG WINAPI lineSetAppSpecific(
    HCALL a0,
    DWORD a1)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     DWORD)> fp(g_hinstThat, "lineSetAppSpecific");
    return fp.Trace(fp()(a0, a1));
}

LONG WINAPI lineSetCallData(
    HCALL a0,
    LPVOID a1,
    DWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPVOID,     DWORD)> fp(g_hinstThat, "lineSetCallData");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineSetCallParams(
    HCALL a0,
    DWORD a1,
    DWORD a2,
    DWORD a3,
    LPLINEDIALPARAMS a4)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     DWORD,     DWORD,     DWORD,     LPLINEDIALPARAMS)> fp(g_hinstThat, "lineSetCallParams");
    return fp.Trace(fp()(a0, a1, a2, a3, a4));
}

LONG WINAPI lineSetCallPrivilege(
    HCALL a0,
    DWORD a1)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     DWORD)> fp(g_hinstThat, "lineSetCallPrivilege");
    return fp.Trace(fp()(a0, a1));
}

LONG WINAPI lineSetCallQualityOfService(
    HCALL a0,
    LPVOID a1,
    DWORD a2,
    LPVOID a3,
    DWORD a4)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPVOID,     DWORD,     LPVOID,     DWORD)> fp(g_hinstThat, "lineSetCallQualityOfService");
    return fp.Trace(fp()(a0, a1, a2, a3, a4));
}

LONG WINAPI lineSetCallTreatment(
    HCALL a0,
    DWORD a1)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     DWORD)> fp(g_hinstThat, "lineSetCallTreatment");
    return fp.Trace(fp()(a0, a1));
}

LONG WINAPI lineSetCurrentLocation(
    HLINEAPP a0,
    DWORD a1)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD)> fp(g_hinstThat, "lineSetCurrentLocation");
    return fp.Trace(fp()(a0, a1));
}

LONG WINAPI lineSetDevConfig(
    DWORD a0,
    LPVOID a1,
    DWORD a2,
    LPCSTR a3)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    DWORD,     LPVOID,     DWORD,     LPCSTR)> fp(g_hinstThat, "lineSetDevConfig");
    return fp.Trace(fp()(a0, a1, a2, a3));
}

LONG WINAPI lineSetDevConfigA(
    DWORD a0,
    LPVOID a1,
    DWORD a2,
    LPCSTR a3)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    DWORD,     LPVOID,     DWORD,     LPCSTR)> fp(g_hinstThat, "lineSetDevConfigA");
    return fp.Trace(fp()(a0, a1, a2, a3));
}

LONG WINAPI lineSetDevConfigW(
    DWORD a0,
    LPVOID a1,
    DWORD a2,
    LPCWSTR a3)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    DWORD,     LPVOID,     DWORD,     LPCWSTR)> fp(g_hinstThat, "lineSetDevConfigW");
    return fp.Trace(fp()(a0, a1, a2, a3));
}

LONG WINAPI lineSetLineDevStatus(
    HLINE a0,
    DWORD a1,
    DWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     DWORD)> fp(g_hinstThat, "lineSetLineDevStatus");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineSetMediaControl(
    HLINE a0,
    DWORD a1,
    HCALL a2,
    DWORD a3,
    LPLINEMEDIACONTROLDIGIT a4,
    DWORD a5,
    LPLINEMEDIACONTROLMEDIA a6,
    DWORD a7,
    LPLINEMEDIACONTROLTONE a8,
    DWORD a9,
    LPLINEMEDIACONTROLCALLSTATE a10,
    DWORD a11)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     HCALL,     DWORD,     LPLINEMEDIACONTROLDIGIT,     DWORD,     LPLINEMEDIACONTROLMEDIA,     DWORD,     LPLINEMEDIACONTROLTONE,     DWORD,     LPLINEMEDIACONTROLCALLSTATE,     DWORD)> fp(g_hinstThat, "lineSetMediaControl");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11));
}

LONG WINAPI lineSetMediaMode(
    HCALL a0,
    DWORD a1)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     DWORD)> fp(g_hinstThat, "lineSetMediaMode");
    return fp.Trace(fp()(a0, a1));
}

LONG WINAPI lineSetNumRings(
    HLINE a0,
    DWORD a1,
    DWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     DWORD)> fp(g_hinstThat, "lineSetNumRings");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineSetStatusMessages(
    HLINE a0,
    DWORD a1,
    DWORD a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     DWORD)> fp(g_hinstThat, "lineSetStatusMessages");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineSetTerminal(
    HLINE a0,
    DWORD a1,
    HCALL a2,
    DWORD a3,
    DWORD a4,
    DWORD a5,
    DWORD a6)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     HCALL,     DWORD,     DWORD,     DWORD,     DWORD)> fp(g_hinstThat, "lineSetTerminal");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5, a6));
}

LONG WINAPI lineSetTollList(
    HLINEAPP a0,
    DWORD a1,
    LPCSTR a2,
    DWORD a3)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     LPCSTR,     DWORD)> fp(g_hinstThat, "lineSetTollList");
    return fp.Trace(fp()(a0, a1, a2, a3));
}

LONG WINAPI lineSetTollListA(
    HLINEAPP a0,
    DWORD a1,
    LPCSTR a2,
    DWORD a3)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     LPCSTR,     DWORD)> fp(g_hinstThat, "lineSetTollListA");
    return fp.Trace(fp()(a0, a1, a2, a3));
}

LONG WINAPI lineSetTollListW(
    HLINEAPP a0,
    DWORD a1,
    LPCWSTR a2,
    DWORD a3)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     LPCWSTR,     DWORD)> fp(g_hinstThat, "lineSetTollListW");
    return fp.Trace(fp()(a0, a1, a2, a3));
}

LONG WINAPI lineSetupConference(
    HCALL a0,
    HLINE a1,
    LPHCALL a2,
    LPHCALL a3,
    DWORD a4,
    LPLINECALLPARAMS a5)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     HLINE,     LPHCALL,     LPHCALL,     DWORD,     LPLINECALLPARAMS)> fp(g_hinstThat, "lineSetupConference");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5));
}

LONG WINAPI lineSetupConferenceA(
    HCALL a0,
    HLINE a1,
    LPHCALL a2,
    LPHCALL a3,
    DWORD a4,
    LPLINECALLPARAMS a5)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     HLINE,     LPHCALL,     LPHCALL,     DWORD,     LPLINECALLPARAMS)> fp(g_hinstThat, "lineSetupConferenceA");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5));
}

LONG WINAPI lineSetupConferenceW(
    HCALL a0,
    HLINE a1,
    LPHCALL a2,
    LPHCALL a3,
    DWORD a4,
    LPLINECALLPARAMS a5)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     HLINE,     LPHCALL,     LPHCALL,     DWORD,     LPLINECALLPARAMS)> fp(g_hinstThat, "lineSetupConferenceW");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5));
}

LONG WINAPI lineSetupTransfer(
    HCALL a0,
    LPHCALL a1,
    LPLINECALLPARAMS a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPHCALL,     LPLINECALLPARAMS)> fp(g_hinstThat, "lineSetupTransfer");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineSetupTransferA(
    HCALL a0,
    LPHCALL a1,
    LPLINECALLPARAMS a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPHCALL,     LPLINECALLPARAMS)> fp(g_hinstThat, "lineSetupTransferA");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineSetupTransferW(
    HCALL a0,
    LPHCALL a1,
    LPLINECALLPARAMS a2)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     LPHCALL,     LPLINECALLPARAMS)> fp(g_hinstThat, "lineSetupTransferW");
    return fp.Trace(fp()(a0, a1, a2));
}

LONG WINAPI lineShutdown(
    HLINEAPP a0)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP)> fp(g_hinstThat, "lineShutdown");
    return fp.Trace(fp()(a0));
}

LONG WINAPI lineSwapHold(
    HCALL a0,
    HCALL a1)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL,     HCALL)> fp(g_hinstThat, "lineSwapHold");
    return fp.Trace(fp()(a0, a1));
}

LONG WINAPI lineTranslateAddress(
    HLINEAPP a0,
    DWORD a1,
    DWORD a2,
    LPCSTR a3,
    DWORD a4,
    DWORD a5,
    LPLINETRANSLATEOUTPUT a6)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     DWORD,     LPCSTR,     DWORD,     DWORD,     LPLINETRANSLATEOUTPUT)> fp(g_hinstThat, "lineTranslateAddress");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5, a6));
}

LONG WINAPI lineTranslateAddressA(
    HLINEAPP a0,
    DWORD a1,
    DWORD a2,
    LPCSTR a3,
    DWORD a4,
    DWORD a5,
    LPLINETRANSLATEOUTPUT a6)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     DWORD,     LPCSTR,     DWORD,     DWORD,     LPLINETRANSLATEOUTPUT)> fp(g_hinstThat, "lineTranslateAddressA");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5, a6));
}

LONG WINAPI lineTranslateAddressW(
    HLINEAPP a0,
    DWORD a1,
    DWORD a2,
    LPCWSTR a3,
    DWORD a4,
    DWORD a5,
    LPLINETRANSLATEOUTPUT a6)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     DWORD,     LPCWSTR,     DWORD,     DWORD,     LPLINETRANSLATEOUTPUT)> fp(g_hinstThat, "lineTranslateAddressW");
    return fp.Trace(fp()(a0, a1, a2, a3, a4, a5, a6));
}

LONG WINAPI lineTranslateDialog(
    HLINEAPP a0,
    DWORD a1,
    DWORD a2,
    HWND a3,
    LPCSTR a4)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     DWORD,     HWND,     LPCSTR)> fp(g_hinstThat, "lineTranslateDialog");
    return fp.Trace(fp()(a0, a1, a2, a3, a4));
}

LONG WINAPI lineTranslateDialogA(
    HLINEAPP a0,
    DWORD a1,
    DWORD a2,
    HWND a3,
    LPCSTR a4)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     DWORD,     HWND,     LPCSTR)> fp(g_hinstThat, "lineTranslateDialogA");
    return fp.Trace(fp()(a0, a1, a2, a3, a4));
}

LONG WINAPI lineTranslateDialogW(
    HLINEAPP a0,
    DWORD a1,
    DWORD a2,
    HWND a3,
    LPCWSTR a4)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINEAPP,     DWORD,     DWORD,     HWND,     LPCWSTR)> fp(g_hinstThat, "lineTranslateDialogW");
    return fp.Trace(fp()(a0, a1, a2, a3, a4));
}

LONG WINAPI lineUncompleteCall(
    HLINE a0,
    DWORD a1)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD)> fp(g_hinstThat, "lineUncompleteCall");
    return fp.Trace(fp()(a0, a1));
}

LONG WINAPI lineUnhold(
    HCALL a0)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HCALL)> fp(g_hinstThat, "lineUnhold");
    return fp.Trace(fp()(a0));
}

LONG WINAPI lineUnpark(
    HLINE a0,
    DWORD a1,
    LPHCALL a2,
    LPCSTR a3)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     LPHCALL,     LPCSTR)> fp(g_hinstThat, "lineUnpark");
    return fp.Trace(fp()(a0, a1, a2, a3));
}

LONG WINAPI lineUnparkA(
    HLINE a0,
    DWORD a1,
    LPHCALL a2,
    LPCSTR a3)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     LPHCALL,     LPCSTR)> fp(g_hinstThat, "lineUnparkA");
    return fp.Trace(fp()(a0, a1, a2, a3));
}

LONG WINAPI lineUnparkW(
    HLINE a0,
    DWORD a1,
    LPHCALL a2,
    LPCWSTR a3)
{
    static FunctionPointer<LONG, LONG (WINAPI*)(    HLINE,     DWORD,     LPHCALL,     LPCWSTR)> fp(g_hinstThat, "lineUnparkW");
    return fp.Trace(fp()(a0, a1, a2, a3));
}

