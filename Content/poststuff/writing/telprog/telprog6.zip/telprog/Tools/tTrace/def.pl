printf("LIBRARY TTRACE\n");
printf("EXPORTS\n");

while( <> )
{
    chomp();

    if( /(.*)\(/ )
    {
        printf("    $1\n");
    }
}
