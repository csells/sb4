// tDaemon.h : main header file for the TDAEMON application
//

#if !defined(AFX_TDAEMON_H__1A21B6D8_5147_11D1_A84F_0080C7667ABF__INCLUDED_)
#define AFX_TDAEMON_H__1A21B6D8_5147_11D1_A84F_0080C7667ABF__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CtDaemonApp:
// See tDaemon.cpp for the implementation of this class
//

class CtDaemonApp : public CWinApp
{
public:
	CtDaemonApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CtDaemonApp)
	public:
	virtual BOOL InitInstance();
    virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CtDaemonApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TDAEMON_H__1A21B6D8_5147_11D1_A84F_0080C7667ABF__INCLUDED_)
