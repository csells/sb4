// tDialDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CtDialDlg dialog

class CtDialDlg : public CDialog
{
// Construction
public:
	CtDialDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CtDialDlg)
	enum { IDD = IDD_TDIAL_DIALOG };
	CButton	m_btnHangUp;
	CListBox	m_listLines;
	CEdit	m_editLog;
	CButton	m_btnDial;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CtDialDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CtDialDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnAnswer();
	afx_msg void OnDial();
	afx_msg void OnHangUp();
	afx_msg void OnDestroy();
	afx_msg void OnAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

    void OnCallState(HCALL hCall, DWORD nCallState, DWORD dwParam2, DWORD nCallPriviledge);
    void OnReply(DWORD nRequestID, DWORD nResult);

private:
	HLINE       m_hLine;
	HCALL       m_hCall;
    DWORD       m_nMakeCallRequest;
    DWORD       m_nDropCallRequest;
    HLINEAPP    m_hLineApp;
    DWORD       m_nLines;
    DWORD*      m_aApiVersions;

	void    Dial(LPCSTR pszPhoneNo = 0);
    void    LogStatus(LPCSTR pszFormat, ...);
	void    UpdateStatus();
    LONG    InitializeLines(DWORD dwLoVersion, DWORD dwHiVersion);

    friend void CALLBACK
    MyLineCallback(DWORD dwDevice, DWORD nMsg, DWORD dwInstance,
                   DWORD dwParam1, DWORD dwParam2, DWORD dwParam3);
};
