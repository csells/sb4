// MyTapi.cpp: My TAPI helper function propotypes

LONG MyGetLineDevCaps(HLINEAPP hLineApp, DWORD nApiVersion, DWORD nLineID, LINEDEVCAPS** ppd);
LPCSTR MyGetLineName(LINEDEVCAPS* pd);

LONG MyGetCountryList(DWORD nApiVersion, DWORD nCountryID, LINECOUNTRYLIST** ppd);
DWORD MyGetCountryCode(LINECOUNTRYLIST* pd, DWORD nCountry);
LPCSTR MyGetCountryName(LINECOUNTRYLIST* pd, DWORD nCountry);

LONG MyGetTranslateCaps(HLINEAPP hLineApp, DWORD nApiVersion, LINETRANSLATECAPS** ppd);
LPCSTR MyGetLocationName(LINETRANSLATECAPS* pd, DWORD nLocation);
DWORD MyGetPermanentLocationID(LINETRANSLATECAPS* pd, DWORD nLocation);

LONG MyGetAddressCaps(HLINEAPP hLineApp, DWORD nLineID, DWORD nAddressID, DWORD nApiVersion, LINEADDRESSCAPS** ppd);
LPCSTR MyGetAddress(LINEADDRESSCAPS* pd);

LONG MyTranslateAddress(HLINEAPP hLineApp, DWORD nLineID, DWORD nApiVersion, LPCSTR pszAddressIn, LINETRANSLATEOUTPUT** ppd);
LPCSTR MyGetDisplayableString(LINETRANSLATEOUTPUT* pd);
