// tDial.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "tDial.h"
#include "tDialDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CtDialApp

BEGIN_MESSAGE_MAP(CtDialApp, CWinApp)
	//{{AFX_MSG_MAP(CtDialApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CtDialApp construction

CtDialApp::CtDialApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CtDialApp object

CtDialApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CtDialApp initialization

BOOL CtDialApp::InitInstance()
{
	// Standard initialization
	CtDialDlg   dlgDial;

	m_pMainWnd = &dlgDial;
	dlgDial.DoModal();

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}

