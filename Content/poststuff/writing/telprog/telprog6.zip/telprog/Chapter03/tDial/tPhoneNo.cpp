// tPhoneNo.cpp: CtPhoneNo class implementation dummy

#include "stdafx.h"
#include <tPhoneNo.cpp>
