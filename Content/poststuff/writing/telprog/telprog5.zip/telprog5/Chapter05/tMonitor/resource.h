//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by tMonitor.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_GREETING                    101
#define IDS_NOREQUESTRECIPIENT          102
#define IDS_REQUESTQUEUEFULL            103
#define IDS_INVALDESTADDRESS            104
#define IDS_NOLOCATIONINFO              105
#define IDR_MAINFRAME                   128
#define IDR_TMONITTYPE                  129
#define IDD_CALL                        130
#define IDD_SCREEN                      131
#define IDD_LINES                       132
#define IDC_NAME                        1000
#define IDC_PHONE_NO                    1001
#define IDC_TAKE_CALL                   1002
#define IDC_TAKE_MESSAGE                1003
#define IDC_HANG_UP                     1004
#define IDC_TAKING_MESSAGE              1005
#define IDC_RINGS                       1006
#define IDC_SPIN                        1007
#define IDC_LINES                       1009
#define ID_MONITOR_DIAL                 32771
#define ID_VIEW_AUTOSIZECOLUMNS         32772
#define ID_VIEW_COLUMN_AUTOSIZE         32772
#define ID_VIEW_MESSAGES                32774
#define ID_MONITOR_CALLSCREENSETTINGS   32775
#define ID_VIEW_LINES                   32776
#define IDS_CANT_INIT_TAPI              61204
#define IDS_CANT_INIT_TAPI_LINE         61204
#define IDS_CANT_DROP_CALL              61205
#define IDS_CANT_ANSWER_CALL            61206
#define IDS_CANT_OPEN_MESSAGES          61207
#define IDS_CANT_INIT_TAPI_PHONE        61208

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
