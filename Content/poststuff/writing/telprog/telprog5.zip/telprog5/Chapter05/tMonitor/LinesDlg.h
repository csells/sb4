// LinesDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CLinesDlg dialog

class CLinesDlg : public CDialog
{
// Construction
public:
	const CtLine*   m_rgLines;
	CLinesDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CLinesDlg)
	enum { IDD = IDD_LINES };
	CListCtrl	m_listLines;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLinesDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CLinesDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
