// CallScreenDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCallScreenDlg dialog

class CCallScreenDlg : public CDialog
{
// Construction
public:
	CCallScreenDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCallScreenDlg)
	enum { IDD = IDD_SCREEN };
	CSpinButtonCtrl	m_spin;
	short	m_nRings;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCallScreenDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCallScreenDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
