// tMonitorDoc.cpp : implementation of the CtMonitorDoc class
//

#include "stdafx.h"
#include "tMonitor.h"

#include "tMonitorDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CtMonitorDoc

IMPLEMENT_DYNCREATE(CtMonitorDoc, CDocument)

BEGIN_MESSAGE_MAP(CtMonitorDoc, CDocument)
	//{{AFX_MSG_MAP(CtMonitorDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CtMonitorDoc construction/destruction

CtMonitorDoc::CtMonitorDoc()
{
}

CtMonitorDoc::~CtMonitorDoc()
{
}

BOOL CtMonitorDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CtMonitorDoc serialization

void CtMonitorDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
	}
	else
	{
	}
}

/////////////////////////////////////////////////////////////////////////////
// CtMonitorDoc diagnostics

#ifdef _DEBUG
void CtMonitorDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CtMonitorDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CtMonitorDoc commands
