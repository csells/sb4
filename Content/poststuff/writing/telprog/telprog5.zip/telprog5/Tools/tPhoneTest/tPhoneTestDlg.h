// tPhoneTestDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTPhoneTestDlg dialog

class CTPhoneTestDlg : public CDialog
{
// Construction
public:
	CTPhoneTestDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CTPhoneTestDlg)
	enum { IDD = IDD_TPHONETEST_DIALOG };
	CString	m_sCountryCode;
	CString	m_sAreaCode;
	CString	m_sPhoneNo;
	BOOL	m_bCanonical;
	CString	m_sCanonical;
	CString	m_sDisplayable;
	CString	m_sTranslatable;
	BOOL	m_bConvert;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTPhoneTestDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CTPhoneTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnChangeInfo();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
