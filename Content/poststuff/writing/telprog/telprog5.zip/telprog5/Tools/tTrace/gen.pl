while( <> )
{
    chomp();

    if( /(.*)\(/ )
    {
        printf("LONG WINAPI $_\n");
        $fname = $1;
        $argc = 0;
    }
    elsif( /\);/ )
    {
        printf(")\n{\n");

        # Example:
        # static FunctionPointer<LONG (WINAPI*)(HCALL, LPCSTR, DWORD)> fp(g_hinst, "lineAccept");
        # return fp.Trace(fp()(a0, a1, a2));

        printf("    static FunctionPointer<LONG, LONG (WINAPI*)(");
        for( $i = 0; $i < $argc; $i++ )
        {
            if( $i ) { printf(", "); }
            printf("$argv[$i]");
        }
        
        printf(")> fp(g_hinstThat, \"$fname\");\n");
        printf("    return fp.Trace(fp()(");

        # Print args
        for( $i = 0; $i < $argc; $i++ )
        {
            if( $i ) { printf(", "); }
            printf("a$i");
        }    

        print "));\n}\n\n";
    }
    elsif( /[a-zA-Z0-9_]/ )
    {
        if( $argc )
        {
            printf(",\n");
        }

        printf("$_ a$argc");
        $argv[$argc] = $_;
        $argc++;
    }
}
