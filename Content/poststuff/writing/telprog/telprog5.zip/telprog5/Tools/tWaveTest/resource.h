//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by tWaveTest.rc
//
#define IDS_PLAY_RESOURCE               1
#define IDS_PLAY_DTMF                   2
#define IDM_PLAY_RESOURCE               0x010
#define IDM_PLAY_DTMF                   0x020
#define IDD_TWAVETEST_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDR_TEST_WAVE                   129
#define IDR_DTMF0                       132
#define IDR_DTMF1                       133
#define IDR_DTMF2                       134
#define IDR_DTMF3                       135
#define IDR_DTMF4                       136
#define IDR_DTMF5                       137
#define IDR_DTMF6                       138
#define IDR_DTMF7                       139
#define IDR_DTMF8                       140
#define IDR_DTMF9                       141
#define IDR_DTMFSTAR                    142
#define IDR_DTMFPOUND                   143
#define IDR_DTMFA                       144
#define IDR_DTMFB                       145
#define IDR_DTMFC                       146
#define IDR_DTMFD                       147
#define IDC_FILE                        1000
#define IDC_BROWSE                      1001
#define IDC_PLAY                        1002
#define IDC_RECORD                      1003
#define IDC_STOP                        1004
#define IDC_DTMF                        1005
#define IDC_CLOSE                       1006
#define IDC_PLAY_DTMF                   1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        148
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
