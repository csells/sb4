// pch.h

#define STRICT
#include <windows.h>
#include <windowsx.h>
#include <tapi.h>
#include <tspi.h>
#include <tdialstring.h>
