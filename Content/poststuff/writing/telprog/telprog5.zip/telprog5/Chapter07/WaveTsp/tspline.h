// tspLine.h

#ifndef TSPLINE_H
#define TSPLINE_H

class CtspLine
{
public:
    CtspLine(HTAPILINE htLine, LINEEVENT pfnEventProc, DWORD dwDeviceID);

    void    Event(HTAPILINE htLine, HTAPICALL htCall, DWORD dwMsg,
                  DWORD dwParam1 = 0, DWORD dwParam2 = 0, DWORD dwParam3 = 0);

    DWORD   GetNumActiveCalls();
    DWORD   GetDeviceID();

    long    MakeCall(DRV_REQUESTID dwRequestID, HTAPICALL htCall, LPHDRVCALL phdCall,
                     LPCWSTR pszDestAddress, DWORD dwCountryCode,
                     LPLINECALLPARAMS const pCallParams);

private:
    LINEEVENT   m_pfnEventProc;
    HTAPILINE   m_htLine;
    DWORD       m_nActiveCalls;
    DWORD       m_dwDeviceID;

    friend class CtspCall;
};

#endif  // TSPLINE_H
