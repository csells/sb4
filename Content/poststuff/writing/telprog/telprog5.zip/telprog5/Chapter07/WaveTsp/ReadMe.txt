WaveTSP

To Debug:
-Build into Debug directory as wavetsp.dll.
-Copy wavetsp.dll into windows directory as wavetsp.tsp.
-Set Additional DLLs to debug to include wavetsp.tsp in windows directory.
-Run 'c:\windows\rundll32.exe shell32.dll,Control_RunDLL telephon.cpl' under
 the debugger.
-Breakpoints set in project source will work.

Debugging Setup:
Executable for Debug Session:   c:\nt4\system32\rundll32.exe
Arguments:                      shell32.dll,Control_RunDLL telephon.cpl

TODO:
+Friendly name instead of wavetsp.tsp in CP
 (FileDescription in version resource).
+Make it work w/ dialer.exe

-Functions
-Dialing dialog

