// pch.h

#define STRICT
#include <windows.h>
#include <tapi.h>
