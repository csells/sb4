//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by wavetsp.rc
//
#define IDD_CONFIG                      101
#define IDC_TEST                        101
#define IDI_WAVETSP                     105
#define DTMF_ID_BASE                    132
#define IDR_DTMF0                       132
#define IDR_DTMF1                       133
#define IDR_DTMF2                       134
#define IDR_DTMF3                       135
#define IDR_DTMF4                       136
#define IDR_DTMF5                       137
#define IDR_DTMF6                       138
#define IDR_DTMF7                       139
#define IDR_DTMF8                       140
#define IDR_DTMF9                       141
#define IDR_DTMFSTAR                    142
#define IDR_DTMFPOUND                   143
#define IDR_DTMFA                       144
#define IDR_DTMFB                       145
#define IDR_DTMFC                       146
#define IDR_DTMFD                       147
#define IDC_DEVICES                     1001
#define IDC_NAME                        1002
#define IDC_MESSAGE                     1002
#define IDC_PORT                        1003
#define IDC_DTMF                        1003
#define IDC_COMMANDS                    1004
#define IDC_ADD                         1005
#define IDC_REMOVE                      1006
#define IDD_CALL_STATUS                 1300
#define IDC_DIAL                        1300

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
