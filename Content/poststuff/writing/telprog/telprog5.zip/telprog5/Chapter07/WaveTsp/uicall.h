// uicall.h

#include "tdialstring.h"

class CuiCall : private CtDialStringSink
{
public:
    CuiCall(HTAPIDIALOGINSTANCE htDlgInst,
            TUISPIDLLCALLBACK lpfnUIDLLCallback,
            LPCSTR pszAddress,
            LINEDIALPARAMS* pdp,
            TSPUIDATA* pData);

    bool Dial(HWND hwndDialog);
    void SetCallState(DWORD dwCallState);
    void Cancel();

    // CtDialStringSink
    virtual void OnDialDone();
    virtual void OnDialError();

private:
    void Callback(DWORD nCallState, LONG tr);

    HWND                m_hwndDialog;
    CtDialString        m_dsAddress;
    HTAPIDIALOGINSTANCE m_htDlgInst;
    TUISPIDLLCALLBACK   m_pfnCallback;
    TSPUIDATA*          m_pData;
    LINEDIALPARAMS*     m_pdp;
};
