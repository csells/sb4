//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by tDial.rc
//
#define IDS_CANT_INIT_TAPI              1
#define IDS_CANT_MAKE_CALL              2
#define IDS_CANT_OPEN_LINE              3
#define IDS_INVALID_ADDRESS             4
#define IDD_TDIAL_DIALOG                102
#define IDR_MAINFRAME                   128
#define IDD_ABOUT                       129
#define IDD_PHONE_NO                    131
#define IDC_DIAL                        1000
#define IDC_HANG_UP                     1001
#define IDC_PHONE_NO                    1003
#define IDC_LOG                         1004
#define IDC_ABOUT                       1008
#define IDC_OPTIONS                     1009
#define IDC_LOCATIONS                   1012
#define IDC_TRANSLATE_DIALOG            1013
#define IDC_COUNTRY_CODE                1014
#define IDC_AREA_CODE                   1015
#define IDC_BUILD_CANONICAL             1016
#define IDC_DIAL_STRING                 1017
#define IDC_CONFIG_DIALOG               1018
#define IDC_LINE_ICON                   1023
#define IDC_LINES                       1024
#define IDC_ADDRESSES                   1026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
