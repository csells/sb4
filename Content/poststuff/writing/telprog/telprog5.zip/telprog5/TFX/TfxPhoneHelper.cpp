// This code is a part of the Telephony Framework C++ Library.
// Copyright (C) 1997 Chris Sells. All rights reserved.
// TfxPhoneHelper.cpp: TFX global helper functions

#include "stdafx.h"
#include "TfxPhone.h"
#include "TfxUtil.h"

TRESULT TfxPhoneInitialize(
    CtAppSink*  pAppSink,
    LPCSTR      szAppName,
    HINSTANCE   hInst)
{
    TRESULT tr = CtPhone::Initialize(pAppSink,
                                    (szAppName ? szAppName : ::AfxGetAppName()),
                                    (hInst ? hInst : ::AfxGetInstanceHandle()));
    if( TSUCCEEDED(tr) && CtPhone::GetNumDevs() < 1 )
    {
        ::TfxPhoneShutdown();
        tr = PHONEERR_OPERATIONFAILED;
    }
    return tr;
}

void TfxPhoneShutdown()
{
    CtPhone::Shutdown();
}

DWORD TfxGetNumPhones()
{
    return CtPhone::GetNumDevs();
}

TRESULT TfxPhoneGetIcon(
    DWORD   nPhoneID,
    LPHICON phicon,
    LPCSTR  pszDeviceClass) // = 0
{
    return CtPhone::GetIcon(nPhoneID, phicon, pszDeviceClass);
}