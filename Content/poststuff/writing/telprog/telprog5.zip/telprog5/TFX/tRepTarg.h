// This code is a part of the Telephony Framework C++ Library.
// Copyright (C) 1997 Chris Sells. All rights reserved.
// tRepTarg.h: CtReplyTarget class interface

#ifndef TREPTARG_H
#define TREPTARG_H

#include "TfxShared.h"

class CtReplyTarget
{
public:
    // Must be implemented in the derived class
    virtual void    OnReply(TREQUEST nRequestID, TRESULT nResult, DWORD nRequestType) =0;
};

#endif  // TREPTARG_H
