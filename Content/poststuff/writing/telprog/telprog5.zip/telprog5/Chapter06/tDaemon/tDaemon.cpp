// tDaemon.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "tDaemon.h"
#include "tDaemonDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CtDaemonApp

BEGIN_MESSAGE_MAP(CtDaemonApp, CWinApp)
	//{{AFX_MSG_MAP(CtDaemonApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CtDaemonApp construction

CtDaemonApp::CtDaemonApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CtDaemonApp object

CtDaemonApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CtDaemonApp initialization

BOOL CtDaemonApp::InitInstance()
{
    // Initialize the line
    if( TFAILED(::TfxLineInitialize()) )
	{
        ::AfxMessageBox(IDS_CANT_INIT_TAPI);
        return FALSE;
	}

	CtDaemonDlg dlg;
	m_pMainWnd = &dlg;
	dlg.DoModal();

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}

int CtDaemonApp::ExitInstance() 
{
	::TfxLineShutdown();
	return CWinApp::ExitInstance();
}
