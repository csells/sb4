// UserControl1.cs
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using System.Runtime.InteropServices;   // DONE
using System.Security;
using System.Security.Permissions;

namespace iectrl {
  public delegate void OuchCallback(int degree);

  // DONE
  [InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
  public interface IOuchEvents {
    // DONE
    [DispId(1)] void OuchEvent(int degree);
  }

  // DONE
  [ComSourceInterfaces(typeof(IOuchEvents))]
  public class UserControl1 : System.Windows.Forms.UserControl {
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.Label label1;
    public event OuchCallback OuchEvent;

    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public UserControl1() {
      // This call is required by the Windows.Forms Form Designer.
      InitializeComponent();

      // TODO: Add any initialization after the InitForm call

    }

    public void SaySomething(string something) {
      MessageBox.Show(prefix + something);
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if( components != null )
          components.Dispose();
      }
      base.Dispose( disposing );
    }

		#region Component Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify 
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.label1 = new System.Windows.Forms.Label();
      this.groupBox1.SuspendLayout();
      this.SuspendLayout();
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.label1});
      this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(150, 150);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "groupBox1";
      // 
      // label1
      // 
      this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.label1.Location = new System.Drawing.Point(3, 16);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(144, 131);
      this.label1.TabIndex = 1;
      this.label1.Text = "Click me!";
      this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      this.label1.Click += new System.EventHandler(this.label1_Click);
      // 
      // UserControl1
      // 
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.groupBox1});
      this.Name = "UserControl1";
      this.groupBox1.ResumeLayout(false);
      this.ResumeLayout(false);

    }
		#endregion

    bool HavePermission(IPermission perm) {
      try { perm.Demand(); }
      catch( SecurityException ) { return false; }
      return true;
    }

    void label1_Click(object sender, EventArgs e) {
      // Make sure we have permission to call unmanaged code
      SecurityPermissionFlag flag = SecurityPermissionFlag.UnmanagedCode;
      SecurityPermission perm = new SecurityPermission(flag);
      if( !HavePermission(perm) ) return;

      // Grant managed hosting code permission to call unmanaged code
      perm.Assert();
      if( OuchEvent != null ) OuchEvent(10);
    }

    string prefix = "";

    public string SomethingPrefix {
      get {
        return prefix;
      }

      set {
        prefix = value;
      }
    }
  }
}
