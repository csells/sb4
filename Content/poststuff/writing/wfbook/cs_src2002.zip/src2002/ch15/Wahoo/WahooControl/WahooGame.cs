using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace WahooControl
{
    public class WahooGame : Control
    {
        public delegate void GameOverCallback();
        public delegate void LinesRemovedCallback(int linesRemoved);
        
        public event GameOverCallback       GameOver;
        public event LinesRemovedCallback   LinesRemoved;

        public WahooGame()
        {
            // Required for the designer
            InitializeComponent();

            // Custom init
            _game.Rows = 20;
            _game.Columns = 10;
            _game.Padding = 2;

            // Turn off the flicker
            SetStyle(ControlStyles.DoubleBuffer, true);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer = new System.Windows.Forms.Timer(this.components);
            // 
            // timer
            // 
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
        }

        public int TickInterval
        {
            get { return _tick; }
            set { _tick = value; }
        }
        
        public int Speed
        {
            get { return _speed; }
        }
        
        public int Rows
        {
            get { return _game.Rows; }
            set { _game.Rows = value; Invalidate(); }
        }
        
        public int Columns
        {
            get { return _game.Columns; }
            set { _game.Columns = value; Invalidate(); }
        }

        public int Padding
        {
            get { return _game.Padding; }
            set { _game.Padding = value; Invalidate(); }
        }
        
        public bool IsPaused
        {
            get { return _isPaused; }
        }
        
        public bool IsPlaying
        {
            get { return _isPlaying; }
        }

        public void New()
        {
            _game.Reset();
            _linesRemoved = 0;
            timer.Interval = _tick;
            timer.Enabled = true;
            _isPlaying = true;
            _isPaused = false;
        }
        
        public void Pause()
        {
            timer.Enabled = false;
            _isPaused = true;
        }
        
        public void Resume()
        {
            timer.Enabled = true;
            _isPaused = false;
        }

        public bool ProcessKey(Keys keyData)
        {
            if( DesignMode || !_isPlaying || _isPaused ) return false;
        
            // Check for the arrow keys, too
            bool    processed = false;
            if( keyData == _dropKey || keyData == Keys.Down ) processed = _game.Drop();
            else if( keyData == _leftKey || keyData == Keys.Left ) processed = _game.Left();
            else if( keyData == _rightKey || keyData == Keys.Right ) processed = _game.Right();
            else if( keyData == _rotateRightKey || keyData == Keys.Up ) processed = _game.RotateRight();
            else if( keyData == _rotateLeftKey ) processed = _game.RotateLeft();
        
            if( processed ) Invalidate();
            return processed;
        }

        void Draw(Graphics g)
        {
            _game.Draw(g);
        }
        
        void DrawDesignMode(Graphics g)
        {
            for( int row = 0; row != _game.Rows; ++row )
            {
                for( int col = 0; col != _game.Columns; ++col )
                {
                    g.DrawRectangle(Pens.Black, Game.GetCellRectangle(ClientSize, _game.Rows, _game.Columns, _game.Padding, row, col));
                }
            }
        }
        
        int     _linesRemoved = 0;
        int     _tick = 500;
        int     _speed = 0;
        Keys    _leftKey = Keys.J;
        Keys    _rightKey = Keys.L;
        Keys    _rotateRightKey = Keys.I;
        Keys    _rotateLeftKey = Keys.Oemcomma;
        Keys    _dropKey = Keys.K;
        bool    _isPlaying = false;
        bool    _isPaused = false;
        Game    _game = new Game();
        private System.Windows.Forms.Timer timer;
        private System.ComponentModel.IContainer components;

        #region Event handlers

        //        protected override void OnKeyDown(KeyEventArgs e)
        //        {
        //            if( ProcessKey(e.KeyData) )
        //            {
        //                Invalidate();
        //            }
        //
        //            base.OnKeyDown(e);
        //        }

        protected override void OnPaint(PaintEventArgs args)
        {
            base.OnPaint(args);

            if( DesignMode ) DrawDesignMode(args.Graphics);
            else Draw(args.Graphics);
        }

        protected override void OnSizeChanged(EventArgs e)
        {
            _game.Size = ClientSize;
            Invalidate();
        }

        private void timer_Tick(object sender, System.EventArgs e)
        {
            // Update the game
            _game.Tick();
            
            // Redraw
            Invalidate();
            
            // Check for removed lines
            if( _game.LinesRemoved > _linesRemoved )
            {
                if( LinesRemoved != null ) LinesRemoved(_game.LinesRemoved - _linesRemoved);
                _linesRemoved = _game.LinesRemoved;
            
                // Increase the speed (in chunks)
                if( _tick - _linesRemoved * 10 > 0 )
                {
                    _speed = (_linesRemoved/10) * 100;
                    timer.Interval = _tick - _speed;
                }
            }
            
            // Check for game over
            if( _game.IsOver )
            {
                timer.Enabled = false;
                _isPlaying = false;
                _isPaused = false;
                if( GameOver != null ) GameOver();
            }
        }

        #endregion
    }
}
