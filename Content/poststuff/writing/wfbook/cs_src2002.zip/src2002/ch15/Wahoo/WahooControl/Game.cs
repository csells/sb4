using System;
using System.Drawing;
using System.Collections;
using System.Diagnostics;

namespace WahooControl
{
    class Game
    {
        public void Tick()
        {
            // When the current shape gets to the bottom...
            if( !_currentShape.Down() )
            {
                // If we collide on the first line, game over
                if( _currentShape.Row == 0 )
                {
                    _isOver = true;
                    return;
                }

                // Move current shape to set of filled cells
                AcquireCurrentShape();
        
                // Remove the filled lines (and update the score)
                int fillsFound = CheckFills(_currentShape.Row, _currentShape.Height);
                _linesRemoved += fillsFound;
        
                // Create a new shape
                _currentShape = GetRandomShape();
            }
        }

        public void Draw(Graphics g)
        {
            // Draw the board background
            Rectangle   topLeftCell = GetCellRectangle(_size, _rows, _cols, _padding, 0, 0);
            Rectangle   bottomRightCell = GetCellRectangle(_size, _rows, _cols, _padding, _rows - 1, _cols - 1);
            Rectangle   gameRect = new Rectangle(topLeftCell.Left, topLeftCell.Top, bottomRightCell.Right - topLeftCell.Left, bottomRightCell.Bottom - topLeftCell.Top);
            gameRect.Inflate(_padding, _padding);
            g.DrawRectangle(Pens.Black, gameRect);

            // Draw the current shape
            if( _currentShape != null ) _currentShape.Draw(g);

            // Draw the colored cells left behind by old shapes
            for( int row = 0; row != _rows; ++row )
            {
                for( int col = 0; col != _cols; ++col )
                {
                    if( CellFilled(row, col) ) DrawCell(g, _cellColors[row, col], row, col);
                }
            }
        }

        public bool CellFilled(int row, int col)
        {
            // If we're out of bounds, report that as filled
            // That will cause the edges to act as a boundary
            // and prevent turning a shape out of bounds
            if( row < 0 || row >= _rows ) return true;
            if( col < 0 || col >= _cols ) return true;

            // Check the visible cells
            return !_cellColors[row, col].IsEmpty;
        }

        public bool Drop()
        {
            // Drop as far as we can
            while( _currentShape.Down() ) ;
            return true;
        }

        public bool Left()
        {
            return _currentShape.Left();
        }

        public bool Right()
        {
            return _currentShape.Right();
        }

        public bool RotateRight()
        {
            return _currentShape.RotateRight();
        }

        public bool RotateLeft()
        {
            return _currentShape.RotateLeft();
        }

        public void Reset()
        {
            _isOver = false;
            _linesRemoved = 0;
            ResetRowCol();
            _currentShape = GetRandomShape();
        }

        protected Shape GetRandomShape()
        {
            Shape   shape = null;

            switch( _rnd.Next(0, 7) )
            {
                case 0: shape = new ShapeT(this); break;
                case 1: shape = new ShapeCrook1(this); break;
                case 2: shape = new ShapeCrook2(this); break;
                case 3: shape = new ShapeL1(this); break;
                case 4: shape = new ShapeL2(this); break;
                case 5: shape = new ShapeLine(this); break;
                case 6: shape = new ShapeBox(this); break;
                default: Debug.Assert(false, "Check your random usage"); return null;
            }

            int colCentered = (_cols - shape.Width)/2;
            while( colCentered-- != 0 ) shape.Right();
            return shape;
        }

        protected void FillCell(int row, int col, Color color)
        {
            _cellColors[row, col] = color;
        }

        protected void ClearCell(int row, int col)
        {
            _cellColors[row, col] = new Color();
        }

        protected Color CellColor(int row, int col)
        {
            return _cellColors[row, col];
        }

        protected void AcquireCurrentShape()
        {
            // Make all currently set cells in the shape part of the cells of the game
            Color   color = _currentShape.Color;
            for( int row = 0; row != _currentShape.Height; ++row )
            {
                for( int col = 0; col != _currentShape.Width; ++col )
                {
                    if( _currentShape.CellFilled(row, col) )
                    {
                        FillCell(row + _currentShape.Row, col + _currentShape.Column, color);
                    }
                }
            }
        }

        protected void MoveLines(int bottomRow)
        {
            // Move bottomRow to not quite the top
            for( int row = bottomRow - 1; row > 0; --row )
            {
                for( int col = 0; col != _cols; ++col )
                {
                    FillCell(row + 1, col, CellColor(row, col));
                }
            }
    
            // Clear the top row
            for( int col = 0; col != _cols; ++col )
            {
                ClearCell(0, col);
            }
        }

        protected int CheckFills(int topRow, int height)
        {
            int filledLines = 0;
    
            for( int row = topRow; row != topRow + height; ++row )
            {
                bool lineFilled = true;
                for( int col = 0; col != _cols; ++col )
                {
                    if( !CellFilled(row, col) ) { lineFilled = false; break; }
                }
        
                if( lineFilled )
                {
                    ++filledLines;
                    MoveLines(row);
                    --row; // Check this line again
                }
            }
    
            return filledLines;
        }

        public bool IsOver
        {
            get { return _isOver; }
        }

        public int LinesRemoved
        {
            get { return _linesRemoved; }
        }

        public Size Size
        {
            get { return _size; }
            set { _size = value; }
        }

        public int Rows
        {
            get { return _rows; }
            set { _rows = value; ResetRowCol(); }
        }

        public int Columns
        {
            get { return _cols; }
            set { _cols = value; ResetRowCol(); }
        }

        public int Padding
        {
            get { return _padding; }
            set { _padding = value; }
        }

        protected void ResetRowCol()
        {
            _cellColors = new Color[_rows, _cols];
        }

        internal void DrawCell(Graphics g, Color color, int row, int col)
        {
            // TODO: Cache brushes -- we're only using 7 colors!
            using( Brush brush = new SolidBrush(color) )
            {
                Rectangle   rect = GetCellRectangle(_size, _rows, _cols, _padding, row, col);
                rect.Inflate(-1, -1);
                g.FillRectangle(brush, rect);
                g.DrawRectangle(Pens.Black, rect);
                rect.Inflate(1, 1);
                g.DrawRectangle(Pens.White, rect);
            }
        }

        // Calculate a cell rectangle given a game size, how many rows and cols in a game,
        // the amount of padding around each cell and the cell in question.
        // NOTE: This is more calculation than we strictly need to do, but it's
        // handy for drawing the design view as well as if these properties change on the fly.
        internal static Rectangle GetCellRectangle(Size size, int rows, int cols, int padding, int row, int col)
        {
            // This algorithm fills the area defined by size, making each cell a rectangle
//            int cx = (size.Width - padding * (cols + 1))/cols;
//            int cy = (size.Height - padding * (rows + 1))/rows;
//            int x = padding + (cx + padding) * col;
//            int y = padding + (cy + padding) * row;
//            return new Rectangle(x, y, cx, cy);

            // This algorithm fills the center of the area defined by size, making each cell a square
            int cx = (size.Width - padding * (cols + 1))/cols;
            int cy = (size.Height - padding * (rows + 1))/rows;
            int side = Math.Min(cx, cy);
            int cxTotal = (side + padding) * cols + padding;
            int cyTotal = (side + padding) * rows + padding;
            int leftOffset = (size.Width - cxTotal)/2;
            int topOffset = (size.Height - cyTotal)/2;
            int x = leftOffset + padding + (side + padding) * col;
            int y = topOffset + padding + (side + padding) * row;
            return new Rectangle(x, y, side, side);
        }

        Size        _size;
        int         _rows;
        int         _cols;
        int         _padding;
        bool        _isOver;
        int         _linesRemoved;
        Shape       _currentShape;
        Random      _rnd = new Random();
        Color[,]    _cellColors;
    }
}
