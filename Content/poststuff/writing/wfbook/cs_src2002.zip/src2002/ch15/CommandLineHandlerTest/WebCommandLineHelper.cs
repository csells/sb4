// WebCommandLineHelper.cs: Contributed by Chris Sells
// Inspired by Rob Macdonald [rob@SALTERTON.COM]

#region Copyright � 2002-2003 The Genghis Group
/*
 * This software is provided 'as-is', without any express or implied warranty.
 * In no event will the authors be held liable for any damages arising from the
 * use of this software.
 *
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, subject to the following restrictions:
 *
 * 1. The origin of this software must not be misrepresented; you must not claim
 * that you wrote the original software. If you use this software in a product,
 * an acknowledgment in the product documentation is required, as shown here:
 *
 * Portions copyright � 2002-2003 The Genghis Group (http://www.genghisgroup.com/).
 *
 * 2. No substantial portion of the source code of this library may be redistributed
 * without the express written permission of the copyright holders, where
 * "substantial" is defined as enough code to be recognizably from this library.
*/
#endregion
#region Features
// The WebCommandLineHelper class is meant to be used to hide the
// difference between command line args when the app is launched
// locally via the shell or when it's launched remotely
// via an URL.
// The ConfigFileHandler class maps requests for .config files
// with URL arguments in them to the actual .config file.
#endregion
#region Usage
/* Client-side usage:
class App {
    // Can be launched as EXE, e.g. foo.exe foo=bar "qu ux"
    // Can be launched as URL, e.g. http://localhost/foo/foo.exe?foo=bar&qu%20ux
    static void Main(string[] args) {
        args = WebCommandLineHelper.CommandLineArgs(args);
        
        string argstring = "";
        foreach( string arg in args ) argstring += arg + "\r\n";
        MessageBox.Show(argstring, "Args from " + (WebCommandLineHelper.LaunchedFromUrl ? "URL" : "EXE"));
    }
}
*/
/* Server-side usage:
 * 1. Build the ConfigFileHandler class into a DLL
 * 2. Map .EXE files to the class in your web.config with these entries:
 * 
<httpHandlers>
  <add verb="*" path="*.exe" type="Genghis.Web.ConfigFileHandler, CommandLineHandlerTest" />
</httpHandlers>

 * 3. Map .EXE files to ASP.NET in your application's IIS configuration
 */
#endregion
#region History
// 3/30/02:
// -Updated for .NET v1.1 and the APP_LAUNCH_URL appdomain data
//
// 3/10/02:
// -Updated by Chris Sells [csells@sellsbrothers.com] to use
//  ConfigurationFile from currIndexent app domain to avoid ieexec.exe
//  specifics and to work w/ fewer permissions.
// -Also updated by Chris to assume that the server-side will handle
//  the request for the .config file with embedded command-line
//  arguments, otherwise fusion won't find it, as fusion looks long
//  before we can patch the ConfigurationFile appdomain variable.
// -Note: I ripped off URL decoding and query string parsing from
//  HttpUtility and HttpValueCollection so that partially-trusted
//  applications could 
// -Also added a server-side .exe handler that will server up .config
//  files, even for .exes that are launched with URLs containing
//  arguments
//
// 10/1/02:
//  -Updated by Chris Sells [csells@sellsbrothers.com] to fix the currIndexent
//   AppDomain's APP_CONFIG_FILE to exclude URL arguments, otherwise the
//   custom .config appsettings can't be obtained, because the APP_CONFIG_FILE
//   variable is pre-loaded to include the entire URL, include the args.
//   This fix was inspired by Dave Thorson [davethorson@attbi.com]. Thanks, Dave!
#endregion

using System;
using System.Web;
using System.Security;
using System.Diagnostics;
using System.Collections;
using System.Text;

namespace Genghis.Web {
  public class WebCommandLineHelper {
    static public bool Empty(string s) { return s == null || s.Length == 0; }

    static char separationChar = '?';
    protected static char SeparationCharacter {
      get { return separationChar; }
      set { separationChar = value; }
    }

    static public bool LaunchedFromUrl {
      get {
        try {
          // Check if we have a site
          string  url = (string)AppDomain.CurrentDomain.GetData("APPBASE");
          System.Security.Policy.Site.CreateFromUrl(url);
          return true;
        }
        catch( ArgumentException ) {
          return false;
        }
      }
    }

    static public string GetLaunchUrlWithArgs() {
      if( !LaunchedFromUrl ) throw new ApplicationException("Launch URL not available (not launched from URL)");

      // Only works for .NET 1.1+
      AppDomain domain = AppDomain.CurrentDomain;
      object obj = domain.GetData("APP_LAUNCH_URL");
      string appLaunchUrl = (obj != null ? obj.ToString() : "");

      // Fall back for .NET 1.0
      if( Empty(appLaunchUrl) ) {
        const string ext = ".config";
        string configFile = domain.SetupInformation.ConfigurationFile;
        Debug.Assert(configFile.ToLower().EndsWith(ext));
        appLaunchUrl = configFile.Substring(0, configFile.Length - ext.Length);
      }

      return appLaunchUrl;
    }

    static public string GetLaunchUrlNoArgs() {
      string url = GetLaunchUrlWithArgs();
      int delimiter = url.IndexOf(separationChar);
      if( delimiter < 0 ) return url;
      return url.Substring(0, delimiter);
    }

    static public string GetLaunchUrlOnlyArgs() {
      string url = GetLaunchUrlWithArgs();
      int delimiter = url.IndexOf(separationChar);
      if( delimiter < 0 ) return null;
      return url.Substring(delimiter + 1);
    }

    // Ripped this off from HttpUtility
    protected class UrlDecoder {
      private int bufferSize;
      private int numChars;
      private char[] charBuffer;
      private int numBytes;
      private byte[] byteBuffer;
      private System.Text.Encoding encoding;

      internal UrlDecoder(int bufferSize, Encoding encoding) {
        this.bufferSize = bufferSize;
        this.encoding = encoding;
        this.charBuffer = new char[bufferSize];
      }

      private void FlushBytes () {
        if( this.numBytes > 0 ) {
          this.numChars += this.encoding.GetChars(this.byteBuffer, 0, this.numBytes, this.charBuffer, this.numChars);
          this.numBytes = 0;
        }
      }

      internal void AddChar(char ch) {
        int i;
        this.FlushBytes();
        this.numChars = (i = this.numChars)  +  1;
        this.charBuffer[i] = ch;
      }

      internal void AddByte(byte  b) {
        if( this.byteBuffer == null ) this.byteBuffer = new Byte[this.bufferSize];
        this.byteBuffer[this.numBytes++] = b;
      }

      internal string GetString () {
        this.FlushBytes ();
        if( this.numChars > 0) return new String (this.charBuffer, 0, this.numChars);
        return String.Empty;
      }
    }

    // Ripped this off from HttpUtility
    static protected int HexToInt(char h) {
      if( (h  >=  '0') && (h  <=  '9') ) return h  -  '0';
      if( (h  >=  'a') && (h  <=  'f') ) return (h  -  'a')  +  10;
      if( (h  >=  'A') && (h  <=  'F') ) return (h  -  'A')  +  10;
      return -1;
    }

    // Ripped this off from HttpUtility
    static public string UrlDecode(string s) {
      int length = s.Length;
      UrlDecoder decoder = new UrlDecoder(length, System.Text.Encoding.UTF8);
      for( int currIndex = 0; currIndex != length; ++currIndex ) {
        char currChar = s[currIndex];
        if( currChar == '+' ) currChar = ' ';
        else if( currChar == '%' && currIndex < length - 2 ) {
          if( s[currIndex + 1] == 'u' && currIndex < length - 5 ) {
            int digit1 = HexToInt(s[currIndex + 2]);
            int digit2 = HexToInt(s[currIndex + 3]);
            int digit3 = HexToInt(s[currIndex + 4]);
            int digit4 = HexToInt(s[currIndex + 5]);
            if( digit1 >= 0 && digit2 >= 0 && digit3 >= 0 && digit4 >= 0 ) {
              currChar = (char)((ushort) digit1 << 12 | digit2 << 8 | digit3 << 4 | digit4);
              currIndex += 5;
              decoder.AddChar(currChar);
              continue;
            }
          }
          else {
            int digit1 = HexToInt(s[currIndex + 1]);
            int digit2 = HexToInt(s[currIndex + 2]);
            if( digit1 >= 0 && digit2 >= 0 ) {
              currIndex += 2;
              decoder.AddByte((byte)(digit1 << 4 | digit2));
              continue;
            }
          }
        }

        if( (currChar & 0xFF80) == 0 )
          decoder.AddByte((byte)currChar);
        else
          decoder.AddChar(currChar);
      }

      return decoder.GetString();
    }

    static public string[] CommandLineArgs(string[] argsFromMain) {
      if( !LaunchedFromUrl ) return argsFromMain;

      string s = GetLaunchUrlOnlyArgs();
      if( Empty(s) ) return new string[0];

      ArrayList argList = new ArrayList();

      // Ripped this off from HttpValueCollection to parse query
      // string manually, as we may not have permissions to use
      // HttpRequest to parse the query string for us
      int length = s.Length;
      int currIndex = 0;
      while( currIndex < length ) {
        int argIndex = currIndex;
        int equalsIndex = -1;
        while( currIndex < length ) {
          if( s[currIndex] == '=' ) {
            if( equalsIndex < 0 ) equalsIndex = currIndex;
          }
          else if( s[currIndex] == '&' ) break;
          currIndex++;
        }

        string key = null;
        string value = null;
        if( equalsIndex >= 0 ) {
          key = s.Substring(argIndex, equalsIndex - argIndex);
          value = s.Substring(equalsIndex + 1, currIndex - equalsIndex - 1);
        }
        else {
          value = s.Substring(argIndex, currIndex - argIndex);
        }

        if( !Empty(value) ) {
          if( !Empty(key) ) argList.Add(UrlDecode(key) + "=" + UrlDecode(value));
          else argList.Add(UrlDecode(value));
        }

        currIndex++;
      }

      return (string[])argList.ToArray(typeof(string));
    }

  }

  public class ConfigFileHandler : IHttpHandler {
    // Redirect calls to "foo.exe?foo.config"
    // to "foo.exe.config"
    public void ProcessRequest(HttpContext context) {
      //      using( FileStream file = new FileStream(@"c:\temp\configHandlerLog.txt", FileMode.Append, FileAccess.Write) ) {
      //        using( StreamWriter writer = new StreamWriter(file) ) {
      //          writer.WriteLine("ProcessRequest: Request.PhysicalPath= " + context.Request.PhysicalPath);
      //          writer.WriteLine("ProcessRequest: Request.Url= " + context.Request.Url);
      //        }
      //      }

      // Just the .exe part in the file system
      string path = context.Request.PhysicalPath;

      // The entire request URL, include args and .config
      string url = context.Request.RawUrl;

      // If someone's asking for a .config, strip the arguments
      string ext = ".config";
      if( url.ToLower().EndsWith(ext) ) {
        context.Response.WriteFile(path + ext);
      }
        // If someone's asking for the .exe, send it
      else {
        context.Response.ContentType = "application/octet-stream";
        context.Response.WriteFile(path);
      }
    }

    public bool IsReusable {
      get { return true; }
    }
  }

}

