using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Controls
{
	/// <summary>
	/// Summary description for FileBrowseTextBox.
	/// </summary>
	public class FileBrowseTextBox : System.Windows.Forms.UserControl
	{
    private Controls.FileTextBox fileTextBox1;
    private System.Windows.Forms.Button browseButton;
    private System.Windows.Forms.OpenFileDialog openFile;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public FileBrowseTextBox()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitForm call

		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.fileTextBox1 = new Controls.FileTextBox();
      this.browseButton = new System.Windows.Forms.Button();
      this.openFile = new System.Windows.Forms.OpenFileDialog();
      this.SuspendLayout();
      // 
      // fileTextBox1
      // 
      this.fileTextBox1.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.fileTextBox1.ForeColor = System.Drawing.Color.Red;
      this.fileTextBox1.Name = "fileTextBox1";
      this.fileTextBox1.Size = new System.Drawing.Size(304, 20);
      this.fileTextBox1.TabIndex = 0;
      this.fileTextBox1.Text = "fileTextBox1";
      // 
      // browseButton
      // 
      this.browseButton.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.browseButton.Location = new System.Drawing.Point(304, 0);
      this.browseButton.Name = "browseButton";
      this.browseButton.Size = new System.Drawing.Size(24, 23);
      this.browseButton.TabIndex = 1;
      this.browseButton.Text = "...";
      this.browseButton.Click += new System.EventHandler(this.browseButton_Click);
      // 
      // openFile
      // 
      this.openFile.AddExtension = false;
      this.openFile.ShowReadOnly = true;
      this.openFile.Title = "Select File...";
      // 
      // FileBrowseTextBox
      // 
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.browseButton,
                                                                  this.fileTextBox1});
      this.Name = "FileBrowseTextBox";
      this.Size = new System.Drawing.Size(328, 24);
      this.ResumeLayout(false);

    }
		#endregion

    void browseButton_Click(object sender, EventArgs e)
    {
      if (this.openFile.ShowDialog() == DialogResult.OK)
      {
        fileTextBox1.Text = this.openFile.FileName;
      }
    }
	}
}
