using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Controls
{
	/// <summary>
	/// Summary description for WndProcForm.
	/// </summary>
	public class WndProcForm : System.Windows.Forms.Form
	{
    private System.Windows.Forms.ListBox listBox1;
    private Controls.WndProcTextBox wndProcTextBox1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public WndProcForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.listBox1 = new System.Windows.Forms.ListBox();
      this.wndProcTextBox1 = new Controls.WndProcTextBox();
      this.SuspendLayout();
      // 
      // listBox1
      // 
      this.listBox1.Location = new System.Drawing.Point(8, 72);
      this.listBox1.Name = "listBox1";
      this.listBox1.Size = new System.Drawing.Size(352, 433);
      this.listBox1.TabIndex = 0;
      // 
      // wndProcTextBox1
      // 
      this.wndProcTextBox1.Location = new System.Drawing.Point(16, 16);
      this.wndProcTextBox1.Name = "wndProcTextBox1";
      this.wndProcTextBox1.Size = new System.Drawing.Size(320, 20);
      this.wndProcTextBox1.TabIndex = 1;
      this.wndProcTextBox1.Text = "wndProcTextBox1";
      this.wndProcTextBox1.ShowEventInfoEvent += new Controls.WndProcTextBox.ShowEventInfo(this.wndProcTextBox1_ShowEventInfoEvent);
      // 
      // WndProcForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(368, 518);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.wndProcTextBox1,
                                                                  this.listBox1});
      this.Name = "WndProcForm";
      this.Text = "WndProcForm";
      this.ResumeLayout(false);

    }
		#endregion

    private void wndProcTextBox1_ShowEventInfoEvent(string info)
    {
      listBox1.Items.Add(info);
    }
	}
}
