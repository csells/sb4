using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Controls
{
  public class NewScrollingCtrl : ScrollableControl
  {
	  public NewScrollingCtrl()
	  {
      SetStyle(ControlStyles.SupportsTransparentBackColor | 
        ControlStyles.UserPaint |
        ControlStyles.Opaque |
        ControlStyles.ResizeRedraw, 
        true);
    }

    protected override void OnPaint(PaintEventArgs pe)
    {
      // Create the brushes to paint with (From Chapter 4)
      Brush backBrush = new SolidBrush(this.BackColor);
      Brush circleBrush = new SolidBrush(Color.Red);
      Brush foreBrush = new SolidBrush(this.ForeColor);

      // Set up our drawing surface
      RectangleF rect = new RectangleF(DisplayRectangle.X,
                                        DisplayRectangle.Y,
                                        DisplayRectangle.Width,
                                        DisplayRectangle.Height);

      // Specify that our string is centered 
      // horizontally and vertically
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Center;
      format.FormatFlags = StringFormatFlags.NoWrap;

      // Draw the background and the circle
      pe.Graphics.FillRectangle(backBrush, rect);
      pe.Graphics.FillEllipse(circleBrush, rect);

      // Draw the string from members of base Control
      pe.Graphics.DrawString(this.Text, 
                            this.Font, 
                            foreBrush, 
                            rect, 
                            format);
      
      // Clean our Brushes
      foreBrush.Dispose();
      circleBrush.Dispose();
      backBrush.Dispose();

      // Notify listeners last
      base.OnPaint(pe);
    }

    protected override void OnTextChanged(EventArgs e)
    {
      base.OnTextChanged(e);

      // Cause a paint to happen
      Invalidate();

      // Set the scroll size
      SetScrollMinSize();
    }

    protected override void OnFontChanged(EventArgs e)
    {
      base.OnFontChanged(e);

      // Cause a paint to happen
      Invalidate();

      // Set the scroll size
      SetScrollMinSize();
    }

    protected override void OnForeColorChanged(EventArgs e)
    {
      base.OnForeColorChanged(e);

      // Cause a paint to happen
      Invalidate();
    }

    protected override void OnBackColorChanged(EventArgs e)
    {
      base.OnBackColorChanged(e);

      // Cause a paint to happen
      Invalidate();
    }

    void SetScrollMinSize()
    {
      // Create a Graphics Object to measure with
      Graphics g = this.CreateGraphics();

      // Determine the size of the text
      SizeF sizeF = g.MeasureString(this.Text, this.Font);
      Size size = new Size((int)Math.Ceiling(sizeF.Width),
        (int)Math.Ceiling(sizeF.Height));

      // Set the minimum size to the text size
      this.AutoScrollMinSize = size;    
    }

	}
}
