using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Controls {
  /// <summary>
  /// Summary description for CustomControl1.
  /// </summary>
  public class ScrollingEllipseLabel : ScrollableControl {
    public ScrollingEllipseLabel() {
      // Required for Designer support
      InitializeComponent();

      // Automatically redraw when resized
      this.SetStyle(ControlStyles.ResizeRedraw, true);

      // Double-buffer to eliminate flicker
      this.SetStyle(ControlStyles.DoubleBuffer, true);
      this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
      this.SetStyle(ControlStyles.UserPaint, true);    
    }

    protected override void OnPaint(PaintEventArgs pe) {
      Graphics g = pe.Graphics;
      using( Brush foreBrush = new SolidBrush(this.ForeColor) )
      using( Brush backBrush = new SolidBrush(this.BackColor) ) {
    g.FillEllipse(foreBrush, this.DisplayRectangle);

        StringFormat format = new StringFormat();
        format.Alignment = StringAlignment.Center;
        format.LineAlignment = StringAlignment.Center;
        g.DrawString(
          this.Text, this.Font, backBrush, this.DisplayRectangle, format);
      }

      // Calling the base class OnPaint
      base.OnPaint(pe);
    }

    void InitializeComponent() {
      // 
      // ScrollingEllipseLabel
      // 
      this.FontChanged += new System.EventHandler(this.ScrollingEllipseLabel_FontChanged);
      this.TextChanged += new System.EventHandler(this.ScrollingEllipseLabel_TextChanged);

    }

void ScrollingEllipseLabel_TextChanged(object sender, EventArgs e) {
  this.Invalidate();

  // Text changed -- calculate new DisplayRectangle
  SetScrollMinSize();
}

void ScrollingEllipseLabel_FontChanged(object sender, EventArgs e) {
  // Font changed -- calculate new DisplayRectangle
  SetScrollMinSize();
}

void SetScrollMinSize() {
  // Create a Graphics Object to measure with
  using( Graphics g = this.CreateGraphics() ) {
    // Determine the size of the text
    SizeF sizeF = g.MeasureString(this.Text, this.Font);
    Size size =
      new Size(
      (int)Math.Ceiling(sizeF.Width),
      (int)Math.Ceiling(sizeF.Height));

    // Set the minimum size to the text size
    this.AutoScrollMinSize = size;    
  }
}

  }
}
