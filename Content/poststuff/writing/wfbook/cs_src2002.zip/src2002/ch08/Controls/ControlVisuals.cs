using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.Drawing.Text;

namespace Controls
{
	/// <summary>
	/// Summary description for ControlVisuals.
	/// </summary>
	public class ControlVisuals : System.Windows.Forms.Form
	{
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.TextBox textBox1;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Button button1;
    private System.Windows.Forms.Button button2;
    private System.Windows.Forms.Button button3;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.TextBox theTextBox;
    private System.Windows.Forms.GroupBox groupBox3;
    private System.Windows.Forms.ImageList bigImageList;
    private System.Windows.Forms.GroupBox groupBox4;
    private System.Windows.Forms.ImageList smallImageList;
    private System.Windows.Forms.ListView listView1;
    private System.Windows.Forms.TreeView treeView1;
    private System.Windows.Forms.Button button5;
    private System.Windows.Forms.Button button6;
    private System.Windows.Forms.Button button7;
    private System.Windows.Forms.Button button4;
    private System.Windows.Forms.Button button8;
    private System.Windows.Forms.Button button9;
    private System.Windows.Forms.Button button10;
    private System.Windows.Forms.GroupBox groupBox5;
    private System.ComponentModel.IContainer components;

		public ControlVisuals()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ControlVisuals));
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.button3 = new System.Windows.Forms.Button();
      this.button2 = new System.Windows.Forms.Button();
      this.button1 = new System.Windows.Forms.Button();
      this.label1 = new System.Windows.Forms.Label();
      this.textBox1 = new System.Windows.Forms.TextBox();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.theTextBox = new System.Windows.Forms.TextBox();
      this.label2 = new System.Windows.Forms.Label();
      this.bigImageList = new System.Windows.Forms.ImageList(this.components);
      this.groupBox3 = new System.Windows.Forms.GroupBox();
      this.button9 = new System.Windows.Forms.Button();
      this.button8 = new System.Windows.Forms.Button();
      this.button4 = new System.Windows.Forms.Button();
      this.groupBox4 = new System.Windows.Forms.GroupBox();
      this.button7 = new System.Windows.Forms.Button();
      this.button6 = new System.Windows.Forms.Button();
      this.button5 = new System.Windows.Forms.Button();
      this.treeView1 = new System.Windows.Forms.TreeView();
      this.smallImageList = new System.Windows.Forms.ImageList(this.components);
      this.listView1 = new System.Windows.Forms.ListView();
      this.button10 = new System.Windows.Forms.Button();
      this.groupBox5 = new System.Windows.Forms.GroupBox();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.groupBox3.SuspendLayout();
      this.groupBox4.SuspendLayout();
      this.groupBox5.SuspendLayout();
      this.SuspendLayout();
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.button3,
                                                                            this.button2,
                                                                            this.button1,
                                                                            this.label1,
                                                                            this.textBox1});
      this.groupBox1.Location = new System.Drawing.Point(7, 15);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(402, 99);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Ambient Properties";
      // 
      // button3
      // 
      this.button3.Location = new System.Drawing.Point(307, 68);
      this.button3.Name = "button3";
      this.button3.Size = new System.Drawing.Size(88, 22);
      this.button3.TabIndex = 4;
      this.button3.Text = "Reset";
      this.button3.Click += new System.EventHandler(this.button3_Click);
      // 
      // button2
      // 
      this.button2.Location = new System.Drawing.Point(161, 68);
      this.button2.Name = "button2";
      this.button2.Size = new System.Drawing.Size(139, 22);
      this.button2.TabIndex = 3;
      this.button2.Text = "Change Control Props";
      this.button2.Click += new System.EventHandler(this.button2_Click);
      // 
      // button1
      // 
      this.button1.Location = new System.Drawing.Point(7, 68);
      this.button1.Name = "button1";
      this.button1.Size = new System.Drawing.Size(146, 22);
      this.button1.TabIndex = 2;
      this.button1.Text = "Change Container Props";
      this.button1.Click += new System.EventHandler(this.button1_Click);
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(7, 23);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(92, 21);
      this.label1.TabIndex = 1;
      this.label1.Text = "A Label:";
      // 
      // textBox1
      // 
      this.textBox1.Location = new System.Drawing.Point(110, 23);
      this.textBox1.Name = "textBox1";
      this.textBox1.Size = new System.Drawing.Size(91, 20);
      this.textBox1.TabIndex = 0;
      this.textBox1.Text = "A TextBox";
      // 
      // groupBox2
      // 
      this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.theTextBox,
                                                                            this.label2});
      this.groupBox2.Location = new System.Drawing.Point(7, 121);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size(402, 61);
      this.groupBox2.TabIndex = 1;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Accessibility";
      // 
      // theTextBox
      // 
      this.theTextBox.AccessibleDescription = "Full name of the user.";
      this.theTextBox.AccessibleName = "FullName";
      this.theTextBox.AccessibleRole = System.Windows.Forms.AccessibleRole.Text;
      this.theTextBox.Location = new System.Drawing.Point(117, 23);
      this.theTextBox.Name = "theTextBox";
      this.theTextBox.Size = new System.Drawing.Size(270, 20);
      this.theTextBox.TabIndex = 1;
      this.theTextBox.Text = "";
      // 
      // label2
      // 
      this.label2.AccessibleDescription = "Label for the Name Textbox.";
      this.label2.AccessibleName = "TextBoxLabel";
      this.label2.AccessibleRole = System.Windows.Forms.AccessibleRole.StaticText;
      this.label2.Location = new System.Drawing.Point(15, 23);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(91, 21);
      this.label2.TabIndex = 0;
      this.label2.Text = "Name:";
      // 
      // bigImageList
      // 
      this.bigImageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
      this.bigImageList.ImageSize = new System.Drawing.Size(32, 32);
      this.bigImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("bigImageList.ImageStream")));
      this.bigImageList.TransparentColor = System.Drawing.Color.Transparent;
      // 
      // groupBox3
      // 
      this.groupBox3.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.button10,
                                                                            this.button9,
                                                                            this.button8,
                                                                            this.button4});
      this.groupBox3.Location = new System.Drawing.Point(7, 189);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new System.Drawing.Size(402, 131);
      this.groupBox3.TabIndex = 2;
      this.groupBox3.TabStop = false;
      this.groupBox3.Text = "Owner Drawn Controls";
      // 
      // button9
      // 
      this.button9.Location = new System.Drawing.Point(16, 72);
      this.button9.Name = "button9";
      this.button9.Size = new System.Drawing.Size(184, 23);
      this.button9.TabIndex = 6;
      this.button9.Text = "Variable Size Listbox";
      this.button9.Click += new System.EventHandler(this.button9_Click);
      // 
      // button8
      // 
      this.button8.Location = new System.Drawing.Point(16, 48);
      this.button8.Name = "button8";
      this.button8.Size = new System.Drawing.Size(184, 23);
      this.button8.TabIndex = 5;
      this.button8.Text = "Fixed Size Listbox";
      this.button8.Click += new System.EventHandler(this.button8_Click);
      // 
      // button4
      // 
      this.button4.Location = new System.Drawing.Point(16, 24);
      this.button4.Name = "button4";
      this.button4.Size = new System.Drawing.Size(184, 23);
      this.button4.TabIndex = 4;
      this.button4.Text = "Button";
      this.button4.Click += new System.EventHandler(this.button4_Click);
      // 
      // groupBox4
      // 
      this.groupBox4.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.treeView1});
      this.groupBox4.Location = new System.Drawing.Point(8, 336);
      this.groupBox4.Name = "groupBox4";
      this.groupBox4.Size = new System.Drawing.Size(296, 250);
      this.groupBox4.TabIndex = 3;
      this.groupBox4.TabStop = false;
      this.groupBox4.Text = "ImageList and Tree Control";
      // 
      // button7
      // 
      this.button7.Location = new System.Drawing.Point(128, 808);
      this.button7.Name = "button7";
      this.button7.Size = new System.Drawing.Size(80, 21);
      this.button7.TabIndex = 4;
      this.button7.Text = "SwitchViews";
      this.button7.Click += new System.EventHandler(this.button7_Click);
      // 
      // button6
      // 
      this.button6.Location = new System.Drawing.Point(8, 808);
      this.button6.Name = "button6";
      this.button6.Size = new System.Drawing.Size(117, 21);
      this.button6.TabIndex = 3;
      this.button6.Text = "Populate TreeView";
      this.button6.Click += new System.EventHandler(this.button6_Click);
      // 
      // button5
      // 
      this.button5.Location = new System.Drawing.Point(208, 808);
      this.button5.Name = "button5";
      this.button5.Size = new System.Drawing.Size(110, 21);
      this.button5.TabIndex = 2;
      this.button5.Text = "Populate ListView";
      this.button5.Click += new System.EventHandler(this.button5_Click);
      // 
      // treeView1
      // 
      this.treeView1.ImageList = this.smallImageList;
      this.treeView1.Location = new System.Drawing.Point(7, 23);
      this.treeView1.Name = "treeView1";
      this.treeView1.Size = new System.Drawing.Size(273, 217);
      this.treeView1.TabIndex = 1;
      // 
      // smallImageList
      // 
      this.smallImageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
      this.smallImageList.ImageSize = new System.Drawing.Size(16, 16);
      this.smallImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("smallImageList.ImageStream")));
      this.smallImageList.TransparentColor = System.Drawing.Color.Transparent;
      // 
      // listView1
      // 
      this.listView1.LargeImageList = this.bigImageList;
      this.listView1.Location = new System.Drawing.Point(8, 24);
      this.listView1.Name = "listView1";
      this.listView1.Size = new System.Drawing.Size(271, 168);
      this.listView1.SmallImageList = this.smallImageList;
      this.listView1.TabIndex = 0;
      // 
      // button10
      // 
      this.button10.Location = new System.Drawing.Point(16, 96);
      this.button10.Name = "button10";
      this.button10.Size = new System.Drawing.Size(184, 23);
      this.button10.TabIndex = 7;
      this.button10.Text = "StatusBar";
      this.button10.Click += new System.EventHandler(this.button10_Click);
      // 
      // groupBox5
      // 
      this.groupBox5.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.listView1});
      this.groupBox5.Location = new System.Drawing.Point(8, 592);
      this.groupBox5.Name = "groupBox5";
      this.groupBox5.Size = new System.Drawing.Size(296, 208);
      this.groupBox5.TabIndex = 4;
      this.groupBox5.TabStop = false;
      this.groupBox5.Text = "ImageList and ListView";
      // 
      // ControlVisuals
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(440, 838);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.groupBox5,
                                                                  this.groupBox4,
                                                                  this.groupBox3,
                                                                  this.groupBox2,
                                                                  this.groupBox1,
                                                                  this.button6,
                                                                  this.button7,
                                                                  this.button5});
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "ControlVisuals";
      this.Text = "ControlVisuals";
      this.groupBox1.ResumeLayout(false);
      this.groupBox2.ResumeLayout(false);
      this.groupBox3.ResumeLayout(false);
      this.groupBox4.ResumeLayout(false);
      this.groupBox5.ResumeLayout(false);
      this.ResumeLayout(false);

    }
		#endregion

    #region Ambient Properties
    // Set group's properties
    private void button1_Click(object sender, System.EventArgs e)
    {
      groupBox1.Font = new Font("Times New Roman", 14);;
    }

    // Set Controls's Properties
    private void button2_Click(object sender, System.EventArgs e)
    {
      // 
      // 'this' refers to the form class that contains 
      // the group box
      // 
      label1.Font = this.Font;
      textBox1.Font = this.Font;
    }

    // Reset
    private void button3_Click(object sender, System.EventArgs e)
    {
      groupBox1.ResetFont();
      label1.ResetFont();
      textBox1.ResetFont();
    }
    #endregion

    #region ownerDrawn Controls
    private void button4_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
    {
//      // Add an obnoxious red square 
//      Pen pen = new Pen(Color.Red, 2);
//      e.Graphics.DrawRectangle(pen, 5, 5, button4.Width - 10, button4.Height - 10);
    }
    private void listBox1_DrawItem(object sender, System.Windows.Forms.DrawItemEventArgs e)
    {
//      // Draw the background
//      e.DrawBackground();
//
//      // Draw the string
//      e.Graphics.DrawString(listBox1.Items[e.Index].ToString(), 
//        e.Font, 
//        new SolidBrush(e.ForeColor), 
//        e.Bounds);
//
//
//      // Draw a red line through each item as it is drawn
//      if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
//      {
//        e.Graphics.DrawLine(new Pen(Color.Red, 1),
//          e.Bounds.Left, 
//          e.Bounds.Top, 
//          e.Bounds.Right, 
//          e.Bounds.Bottom);
//      }
//      else
//      {
//        e.Graphics.DrawLine(new Pen(Color.Blue, 1),
//          e.Bounds.Left, 
//          e.Bounds.Top, 
//          e.Bounds.Right, 
//          e.Bounds.Bottom);
//      }
//
//      // Draw the focus rectangle
//      e.DrawFocusRectangle();
    }

    private void listBox2_DrawItem(object sender, System.Windows.Forms.DrawItemEventArgs e)
    {
//      // Draw the background
//      e.DrawBackground();
//
//      // If the item is an even item, draw twice as big too
//      Font textFont;
//      if (e.Index % 2 == 0) textFont = new Font(e.Font.FontFamily, e.Font.Size * 2);
//      else textFont = e.Font;
//      
//      // Draw the string
//      e.Graphics.DrawString(listBox2.Items[e.Index].ToString(), 
//        textFont, 
//        new SolidBrush(e.ForeColor), 
//        e.Bounds);
//
//      // Draw the focus rectangle
//      e.DrawFocusRectangle();
    
    }

    private void listBox2_MeasureItem(object sender, System.Windows.Forms.MeasureItemEventArgs e)
    {
//      // Make every even item double Height
//      if (e.Index % 2 == 0)
//      {
//        e.ItemHeight *= 2;
//      }
    }

    private void statusBar1_DrawItem(object sender, System.Windows.Forms.StatusBarDrawItemEventArgs e)
    {
//      // Draw a grey background
//      e.Graphics.DrawRectangle(new Pen(e.BackColor), e.Bounds);
//
//      // Draw a disabled text instead
//      ControlPaint.DrawStringDisabled(e.Graphics, 
//                                      "Disabled", 
//                                      e.Font, 
//                                      e.ForeColor, 
//                                      e.Bounds, 
//                                      StringFormat.GenericDefault);
//
////      // Draw the icon
////      e.Graphics.DrawIconUnstretched(this.Icon, e.Bounds);

    }
    #endregion

    #region ImageLists
    // TreeView
    private void button6_Click(object sender, System.EventArgs e)
    {
      // Create the top node
      TreeNode top = new TreeNode("One");
      top.ImageIndex = 0;
      top.SelectedImageIndex = 1;

      // Add it to the top of the Tree View
      treeView1.Nodes.Add(top);

      // Create two children
      TreeNode firstChild = new TreeNode("Two");
      firstChild.ImageIndex = 1;
      firstChild.SelectedImageIndex = 2;

      // Add it as the first child of the top node
      top.Nodes.Add(firstChild);

      TreeNode secondChild = new TreeNode("Three");
      secondChild.ImageIndex = 2;
      secondChild.SelectedImageIndex = 0;

      // Add it as the second child of the top node
      top.Nodes.Add(secondChild);
    }

    // ListView
    private void button5_Click(object sender, System.EventArgs e)
    {
      // Add items to the list view
      ListViewItem one = new ListViewItem("One");
      one.ImageIndex = 0;

      ListViewItem two = new ListViewItem("Two");
      two.ImageIndex = 1;

      ListViewItem three = new ListViewItem("Three");
      three.ImageIndex = 2;


      // Add the items to the listview
      listView1.Items.Add(one);
      listView1.Items.Add(two);
      listView1.Items.Add(three);
    }
    
    // SwitchView
    private void button7_Click(object sender, System.EventArgs e)
    {
      switch(listView1.View)
      {
        case View.LargeIcon:
          listView1.View = View.SmallIcon;
          break;
        case View.SmallIcon:
          listView1.View = View.List;
          break;
        case View.List:
          listView1.View = View.Details;
          break;
        case View.Details:
          listView1.View = View.LargeIcon;
          break;
      }    
    }

    #endregion

    private void button4_Click(object sender, System.EventArgs e)
    {
      (new OwnerDrawnButton()).Show();
    }

    private void button8_Click(object sender, System.EventArgs e)
    {
      (new OwnerDrawnFixedListBox()).Show();
    }

    private void button9_Click(object sender, System.EventArgs e)
    {
      (new OwnerDrawnVariableListBox()).Show();
    }

    private void button10_Click(object sender, System.EventArgs e)
    {
      (new OwnerDrawnStatusBar()).Show();
    }



	}
}
