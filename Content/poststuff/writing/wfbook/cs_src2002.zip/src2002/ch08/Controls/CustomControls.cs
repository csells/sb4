using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Controls {
  /// <summary>
  /// Summary description for CustomControls.
  /// </summary>
  public class CustomControls : System.Windows.Forms.Form {
    private Controls.EllipseLabel ellipseLabel1;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public CustomControls() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
      this.SetStyle(ControlStyles.ResizeRedraw, true);
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.ellipseLabel1 = new Controls.EllipseLabel();
      this.SuspendLayout();
      // 
      // ellipseLabel1
      // 
      this.ellipseLabel1.Location = new System.Drawing.Point(48, 32);
      this.ellipseLabel1.Name = "ellipseLabel1";
      this.ellipseLabel1.Prefix = "foo: ";
      this.ellipseLabel1.Size = new System.Drawing.Size(184, 104);
      this.ellipseLabel1.TabIndex = 2;
      this.ellipseLabel1.Text = "ellipseLabel1";
      this.ellipseLabel1.PrefixChanged += new Controls.EllipseLabel.PrefixedChangedEventHandler(this.ellipseLabel1_PrefixChanged);
      // 
      // CustomControls
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(272, 166);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.ellipseLabel1});
      this.Name = "CustomControls";
      this.Text = "CustomControls";
      this.Click += new System.EventHandler(this.CustomControls_Click);
      this.ResumeLayout(false);

    }
		#endregion

    void button1_Click(object sender, EventArgs e) {
      ellipseLabel1.Text = "hugga-bugga";
      //myLabel1.ForeColor = Color.FromName("Yellow");
    }

    private void CustomControls_Click(object sender, System.EventArgs e) {
      ellipseLabel1.Prefix = "bar: ";
    }

    private void ellipseLabel1_PrefixChanged(object sender, Controls.EllipseLabel.PrefixEventArgs e) {
      MessageBox.Show("Prefix changed to " + e.Prefix);
    }

  }
}
