using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Controls
{
	/// <summary>
	/// Summary description for OwnerDrawnButton.
	/// </summary>
	public class OwnerDrawnButton : System.Windows.Forms.Form
	{
    private System.Windows.Forms.Button button4;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public OwnerDrawnButton()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.button4 = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // button4
      // 
      this.button4.Location = new System.Drawing.Point(16, 16);
      this.button4.Name = "button4";
      this.button4.Size = new System.Drawing.Size(200, 40);
      this.button4.TabIndex = 1;
      this.button4.Text = "button4";
      this.button4.Paint += new System.Windows.Forms.PaintEventHandler(this.button4_Paint);
      // 
      // OwnerDrawnButton
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(232, 86);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.button4});
      this.Name = "OwnerDrawnButton";
      this.Text = "OwnerDrawnButton";
      this.ResumeLayout(false);

    }
		#endregion

    private void button4_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
    {
    
      // Add an obnoxious red square 
      Pen pen = new Pen(Color.Red, 2);
      e.Graphics.DrawRectangle(pen, 5, 5, button4.Width - 10, button4.Height - 10);
    }
	}
}
