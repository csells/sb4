using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Controls {
  /// <summary>
  /// Summary description for OwnerDrawnVariableListBox.
  /// </summary>
  public class OwnerDrawnVariableListBox : System.Windows.Forms.Form {
    private System.Windows.Forms.ListBox listBox2;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public OwnerDrawnVariableListBox() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.listBox2 = new System.Windows.Forms.ListBox();
      this.SuspendLayout();
      // 
      // listBox2
      // 
      this.listBox2.Dock = System.Windows.Forms.DockStyle.Fill;
      this.listBox2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
      this.listBox2.IntegralHeight = false;
      this.listBox2.Items.AddRange(new object[] {
                                                  "Huey",
                                                  "Dewy",
                                                  "Louis"});
      this.listBox2.Name = "listBox2";
      this.listBox2.Size = new System.Drawing.Size(292, 222);
      this.listBox2.TabIndex = 4;
      this.listBox2.MeasureItem += new System.Windows.Forms.MeasureItemEventHandler(this.listBox2_MeasureItem);
      this.listBox2.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.listBox2_DrawItem);
      // 
      // OwnerDrawnVariableListBox
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 222);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.listBox2});
      this.Name = "OwnerDrawnVariableListBox";
      this.Text = "OwnerDrawnVariableListBox";
      this.ResumeLayout(false);

    }
		#endregion

    void listBox2_DrawItem(object sender, DrawItemEventArgs e) {
      // Draw the background
      e.DrawBackground();

      // Get the default font
      Font drawFont = e.Font;
      bool ourFont = false;
  
      // Draw in italics if selected
      if( (e.State & DrawItemState.Selected) == DrawItemState.Selected ) {
        ourFont = true;
        drawFont = new Font(drawFont, FontStyle.Italic);
      }

      using( Brush brush = new SolidBrush(e.ForeColor) ) {
        // Draw the listbox item
        e.Graphics.DrawString(listBox2.Items[e.Index].ToString(), 
          drawFont, 
          new SolidBrush(e.ForeColor), 
          e.Bounds);

        if( ourFont ) drawFont.Dispose();
      }

      // Draw the focus rectangle
      e.DrawFocusRectangle();
    }

    void listBox2_MeasureItem(object sender, MeasureItemEventArgs e) {
      // Make every even item double high
      if( e.Index % 2 == 0 ) {
        e.ItemHeight *= 2;
      }
    }

  }
}
