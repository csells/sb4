using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Controls {
  /// <summary>
  /// Summary description for ControlBehavior.
  /// </summary>
  public class ControlBehavior : System.Windows.Forms.Form {
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.TextBox textBox1;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label activeCtlLabel;
    private System.Windows.Forms.Button button1;
    private System.Windows.Forms.CheckBox checkBox1;
    private System.Windows.Forms.RadioButton radioButton1;
    private System.Windows.Forms.ProgressBar progressBar1;
    private System.Windows.Forms.Timer timer1;
    private System.Windows.Forms.Label lblStatus;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.TextBox textBox2;
    private System.Windows.Forms.ErrorProvider errorProvider1;
    private System.Windows.Forms.Button button2;
    private System.Windows.Forms.ToolTip toolTip1;
    private System.Windows.Forms.GroupBox groupBox3;
    private System.Windows.Forms.TextBox textBox3;
    private System.Windows.Forms.GroupBox groupBox4;
    private System.Windows.Forms.TextBox textBox4;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.Button button3;
    private System.ComponentModel.IContainer components;

    public ControlBehavior() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
      if (textBox1.CanFocus) textBox1.Focus();
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.components = new System.ComponentModel.Container();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.lblStatus = new System.Windows.Forms.Label();
      this.progressBar1 = new System.Windows.Forms.ProgressBar();
      this.radioButton1 = new System.Windows.Forms.RadioButton();
      this.checkBox1 = new System.Windows.Forms.CheckBox();
      this.button1 = new System.Windows.Forms.Button();
      this.activeCtlLabel = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.label1 = new System.Windows.Forms.Label();
      this.textBox1 = new System.Windows.Forms.TextBox();
      this.timer1 = new System.Windows.Forms.Timer(this.components);
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.button2 = new System.Windows.Forms.Button();
      this.textBox2 = new System.Windows.Forms.TextBox();
      this.errorProvider1 = new System.Windows.Forms.ErrorProvider();
      this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
      this.groupBox3 = new System.Windows.Forms.GroupBox();
      this.button3 = new System.Windows.Forms.Button();
      this.textBox3 = new System.Windows.Forms.TextBox();
      this.groupBox4 = new System.Windows.Forms.GroupBox();
      this.label5 = new System.Windows.Forms.Label();
      this.label4 = new System.Windows.Forms.Label();
      this.textBox4 = new System.Windows.Forms.TextBox();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.groupBox3.SuspendLayout();
      this.groupBox4.SuspendLayout();
      this.SuspendLayout();
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.lblStatus,
                                                                            this.progressBar1,
                                                                            this.radioButton1,
                                                                            this.checkBox1,
                                                                            this.button1,
                                                                            this.activeCtlLabel,
                                                                            this.label2,
                                                                            this.label1,
                                                                            this.textBox1});
      this.groupBox1.Location = new System.Drawing.Point(7, 8);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(329, 136);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Focus and The Active Control";
      // 
      // lblStatus
      // 
      this.lblStatus.Location = new System.Drawing.Point(7, 106);
      this.lblStatus.Name = "lblStatus";
      this.lblStatus.Size = new System.Drawing.Size(307, 22);
      this.lblStatus.TabIndex = 5;
      this.lblStatus.Text = "label3";
      this.lblStatus.TextAlign = System.Drawing.ContentAlignment.TopCenter;
      // 
      // progressBar1
      // 
      this.progressBar1.Location = new System.Drawing.Point(7, 68);
      this.progressBar1.Name = "progressBar1";
      this.progressBar1.Size = new System.Drawing.Size(307, 8);
      this.progressBar1.TabIndex = 4;
      // 
      // radioButton1
      // 
      this.radioButton1.Location = new System.Drawing.Point(102, 45);
      this.radioButton1.Name = "radioButton1";
      this.radioButton1.Size = new System.Drawing.Size(95, 23);
      this.radioButton1.TabIndex = 3;
      this.radioButton1.Text = "radioButton1";
      // 
      // checkBox1
      // 
      this.checkBox1.Location = new System.Drawing.Point(7, 45);
      this.checkBox1.Name = "checkBox1";
      this.checkBox1.Size = new System.Drawing.Size(95, 23);
      this.checkBox1.TabIndex = 2;
      this.checkBox1.Text = "checkBox1";
      // 
      // button1
      // 
      this.button1.Location = new System.Drawing.Point(227, 30);
      this.button1.Name = "button1";
      this.button1.Size = new System.Drawing.Size(68, 22);
      this.button1.TabIndex = 1;
      this.button1.Text = "button1";
      this.button1.Click += new System.EventHandler(this.button1_Click);
      // 
      // activeCtlLabel
      // 
      this.activeCtlLabel.Location = new System.Drawing.Point(132, 83);
      this.activeCtlLabel.Name = "activeCtlLabel";
      this.activeCtlLabel.Size = new System.Drawing.Size(189, 22);
      this.activeCtlLabel.TabIndex = 3;
      // 
      // label2
      // 
      this.label2.Location = new System.Drawing.Point(7, 83);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(125, 22);
      this.label2.TabIndex = 2;
      this.label2.Text = "The Active Control is:";
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(7, 23);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(81, 21);
      this.label1.TabIndex = 1;
      this.label1.Text = "label1";
      // 
      // textBox1
      // 
      this.textBox1.Location = new System.Drawing.Point(102, 23);
      this.textBox1.Name = "textBox1";
      this.textBox1.Size = new System.Drawing.Size(92, 20);
      this.textBox1.TabIndex = 0;
      this.textBox1.Text = "textBox1";
      this.textBox1.Leave += new System.EventHandler(this.textBox1_Leave);
      this.textBox1.Enter += new System.EventHandler(this.textBox1_Enter);
      // 
      // timer1
      // 
      this.timer1.Interval = 250;
      this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
      // 
      // groupBox2
      // 
      this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.button2,
                                                                            this.textBox2});
      this.groupBox2.Location = new System.Drawing.Point(7, 151);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size(329, 99);
      this.groupBox2.TabIndex = 1;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Validating Controls";
      // 
      // button2
      // 
      this.button2.Location = new System.Drawing.Point(227, 61);
      this.button2.Name = "button2";
      this.button2.Size = new System.Drawing.Size(87, 21);
      this.button2.TabIndex = 1;
      this.button2.Text = "Does Nothing";
      // 
      // textBox2
      // 
      this.textBox2.Location = new System.Drawing.Point(7, 30);
      this.textBox2.Name = "textBox2";
      this.textBox2.Size = new System.Drawing.Size(256, 20);
      this.textBox2.TabIndex = 0;
      this.textBox2.Text = "textBox2";
      this.toolTip1.SetToolTip(this.textBox2, "This is my non-empty listbox...");
      this.textBox2.Validating += new System.ComponentModel.CancelEventHandler(this.textBox2_Validating);
      this.textBox2.Validated += new System.EventHandler(this.textBox2_Validated);
      // 
      // errorProvider1
      // 
      this.errorProvider1.DataMember = null;
      // 
      // groupBox3
      // 
      this.groupBox3.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.button3,
                                                                            this.textBox3});
      this.groupBox3.Location = new System.Drawing.Point(7, 257);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new System.Drawing.Size(329, 95);
      this.groupBox3.TabIndex = 2;
      this.groupBox3.TabStop = false;
      this.groupBox3.Text = "Drag-n-Drop";
      // 
      // button3
      // 
      this.button3.Location = new System.Drawing.Point(7, 61);
      this.button3.Name = "button3";
      this.button3.Size = new System.Drawing.Size(69, 21);
      this.button3.TabIndex = 2;
      this.button3.Text = "Howdie";
      this.button3.QueryContinueDrag += new System.Windows.Forms.QueryContinueDragEventHandler(this.button3_QueryContinueDrag);
      this.button3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button3_MouseDown);
      // 
      // textBox3
      // 
      this.textBox3.AllowDrop = true;
      this.textBox3.Location = new System.Drawing.Point(7, 23);
      this.textBox3.Multiline = true;
      this.textBox3.Name = "textBox3";
      this.textBox3.Size = new System.Drawing.Size(307, 30);
      this.textBox3.TabIndex = 0;
      this.textBox3.Text = "textbox3";
      this.textBox3.DragOver += new System.Windows.Forms.DragEventHandler(this.textBox3_DragOver);
      this.textBox3.DragDrop += new System.Windows.Forms.DragEventHandler(this.textBox3_DragDrop);
      this.textBox3.QueryContinueDrag += new System.Windows.Forms.QueryContinueDragEventHandler(this.textBox3_QueryContinueDrag);
      this.textBox3.DragEnter += new System.Windows.Forms.DragEventHandler(this.textBox3_DragEnter);
      this.textBox3.DragLeave += new System.EventHandler(this.textBox3_DragLeave);
      // 
      // groupBox4
      // 
      this.groupBox4.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.label5,
                                                                            this.label4,
                                                                            this.textBox4});
      this.groupBox4.Location = new System.Drawing.Point(7, 386);
      this.groupBox4.Name = "groupBox4";
      this.groupBox4.Size = new System.Drawing.Size(329, 106);
      this.groupBox4.TabIndex = 3;
      this.groupBox4.TabStop = false;
      this.groupBox4.Text = "Keyboard Handling";
      // 
      // label5
      // 
      this.label5.Location = new System.Drawing.Point(15, 76);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(299, 22);
      this.label5.TabIndex = 2;
      this.label5.Text = "label5";
      // 
      // label4
      // 
      this.label4.Location = new System.Drawing.Point(15, 53);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(299, 22);
      this.label4.TabIndex = 1;
      this.label4.Text = "label4";
      // 
      // textBox4
      // 
      this.textBox4.Location = new System.Drawing.Point(15, 23);
      this.textBox4.Name = "textBox4";
      this.textBox4.Size = new System.Drawing.Size(292, 20);
      this.textBox4.TabIndex = 0;
      this.textBox4.Text = "textBox4";
      this.textBox4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox4_KeyDown);
      this.textBox4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox4_KeyPress);
      this.textBox4.KeyUp += new System.Windows.Forms.KeyEventHandler(this.textBox4_KeyUp);
      // 
      // ControlBehavior
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(343, 499);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.groupBox4,
                                                                  this.groupBox3,
                                                                  this.groupBox2,
                                                                  this.groupBox1});
      this.Name = "ControlBehavior";
      this.Text = "ControlBehavior";
      this.groupBox1.ResumeLayout(false);
      this.groupBox2.ResumeLayout(false);
      this.groupBox3.ResumeLayout(false);
      this.groupBox4.ResumeLayout(false);
      this.ResumeLayout(false);

    }
		#endregion

    #region ActiveControl
    private void timer1_Tick(object sender, System.EventArgs e) {
      activeCtlLabel.Text = ActiveControl.Name;
    }

    private void textBox1_Leave(object sender, System.EventArgs e) {
      lblStatus.Text = "Left textBox1";
    }

    private void textBox1_Enter(object sender, System.EventArgs e) {
      lblStatus.Text = "Entered textBox1";
    }

    private void button1_Click(object sender, System.EventArgs e) {
      textBox1.Focus();
    }
    #endregion

    #region validation
    private void textBox2_Validating(object sender, 
      System.ComponentModel.CancelEventArgs e) {
      if (textBox2.Text.Length == 0 || textBox2.Text.StartsWith(" ")) {
        // Stop Leaving the Control
        e.Cancel = true;

        // Show the error
        //MessageBox.Show("TextBox cannot be empty or start with a space");
        errorProvider1.SetError(textBox2, 
          "TextBox cannot be empty or start with a space");

      }
    }

    private void textBox2_Validated(object sender, System.EventArgs e) {
      // Clear the error
      errorProvider1.SetError(textBox2, "");
    }
    #endregion

    #region Drag-n-Drop
    void textBox3_DragEnter(object sender, DragEventArgs e) {
      SetDropEffect(e);
    }

    private void textBox3_DragLeave(object sender, System.EventArgs e) {
      //      label3.Text = "Left Drag-n-Drop";
    }

    // KeyState Values (not available in WinForms)
    [FlagsAttribute] enum KeyState {
      LeftMouse = 1,
      RightMouse = 2,
      ShiftKey = 4,
      CtrlKey = 8,
      MiddleMouse = 16,
      AltKey = 32,
    }

    void SetDropEffect(DragEventArgs  e) {
      KeyState keyState = (KeyState)e.KeyState;
      System.Diagnostics.Debug.WriteLine("KeyState= " + keyState.ToString());

      // If the data is a string, we can handle it
      if( e.Data.GetDataPresent(typeof(string)) ) {
        // If only ctrl is pressed, copy it
        if( (keyState & KeyState.CtrlKey) == KeyState.CtrlKey ) {
          e.Effect = DragDropEffects.Copy;
        }
        else { // Else, move it
          e.Effect = DragDropEffects.Move;
        }
      }
        // We don't like the data, so do not allow anything 
      else {
        e.Effect = DragDropEffects.None;
      }
    }

    void textBox3_DragOver(object sender, DragEventArgs e) {
      SetDropEffect(e);
    }

    private void textBox3_DragDrop(object sender, DragEventArgs e) {
      string s = e.Data.GetData(typeof(string)) as string;
      if ((e.Effect & DragDropEffects.Copy) == DragDropEffects.Copy) {
        textBox3.Text = s;
      }
      else if ((e.Effect & DragDropEffects.Move) == DragDropEffects.Move) {
        textBox3.Text = s;

      }
    }
    private void textBox3_QueryContinueDrag(object sender, System.Windows.Forms.QueryContinueDragEventArgs e) {
      // If the drag goes outside the form, cancel it
      e.Action = DragAction.Cancel;
    }

    void button3_MouseDown(object sender, MouseEventArgs e) {
      // Cause the drag and drop to happen and capture what happened
      DragDropEffects effects = DoDragDrop(button3.Text, 
        DragDropEffects.Copy | 
        DragDropEffects.Move);
      
      // If the effect was move, remove the text of the button
      if (effects == DragDropEffects.Move) {
        button3.Text = "";
      }
    }
    #endregion

    #region Key Handling
    private Regex simpleEmailAllowEx = new Regex(@"[a-zA-Z@\.\b]+");
    private void textBox4_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e) {
      // Show the modifiers
      string mods = "";
      if ((Control.ModifierKeys & Keys.Shift) == Keys.Shift) mods += "Shift ";
      if ((Control.ModifierKeys & Keys.Alt) == Keys.Shift) mods += "Alt ";
      if ((Control.ModifierKeys & Keys.Control) == Keys.Shift) mods += "Ctrl ";
      label4.Text = mods;
      
      // Don't allow any of these
      if (simpleEmailAllowEx.Match(e.KeyChar.ToString()).Success == false) {
        // If it is one of these, simply ignore them
        e.Handled = true;
      }
    }
    
    private void textBox4_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e) {
      label4.Text = string.Format("key: {0}, Alt({1}), Shift ({2}), Ctrl({3})",
        Convert.ToChar(e.KeyValue).ToString(),
        e.Alt,
        e.Shift,
        e.Control);
    }

    private void textBox4_KeyUp(object sender, System.Windows.Forms.KeyEventArgs e) {
      label5.Text = string.Format("key: {0}, Alt({1}), Shift ({2}), Ctrl({3})",
        Convert.ToChar(e.KeyValue).ToString(),
        e.Alt,
        e.Shift,
        e.Control);
    }

    #endregion

    private void button3_QueryContinueDrag(object sender, System.Windows.Forms.QueryContinueDragEventArgs e) {
      // If the drag goes outside the form, cancel it
      e.Action = DragAction.Cancel;
    }




  
  }
}
