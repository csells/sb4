using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Controls
{
	/// <summary>
	/// Summary description for ControlInteraction.
	/// </summary>
	public class ControlInteraction : System.Windows.Forms.Form
	{
    private System.Windows.Forms.GroupBox groupBox1;
    private AxMSForms.AxTabStrip axTabStrip1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ControlInteraction()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ControlInteraction));
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.axTabStrip1 = new AxMSForms.AxTabStrip();
      this.groupBox1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.axTabStrip1)).BeginInit();
      this.SuspendLayout();
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.axTabStrip1});
      this.groupBox1.Location = new System.Drawing.Point(8, 8);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(344, 224);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Hosting COM Components";
      // 
      // axTabStrip1
      // 
      this.axTabStrip1.ContainingControl = this;
      this.axTabStrip1.Location = new System.Drawing.Point(8, 32);
      this.axTabStrip1.Name = "axTabStrip1";
      this.axTabStrip1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axTabStrip1.OcxState")));
      this.axTabStrip1.Size = new System.Drawing.Size(320, 180);
      this.axTabStrip1.TabIndex = 0;
      // 
      // ControlInteraction
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(6, 15);
      this.ClientSize = new System.Drawing.Size(360, 240);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.groupBox1});
      this.Name = "ControlInteraction";
      this.Text = "ControlInteraction";
      this.groupBox1.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.axTabStrip1)).EndInit();
      this.ResumeLayout(false);

    }
		#endregion
	}
}
