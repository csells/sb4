using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Controls
{
	/// <summary>
	/// Summary description for ScrollControls.
	/// </summary>
	public class ScrollControls : System.Windows.Forms.Form
	{
    private Controls.ScrollingEllipseLabel ScrollingEllipseLabel1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ScrollControls()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.ScrollingEllipseLabel1 = new Controls.ScrollingEllipseLabel();
      this.SuspendLayout();
      // 
      // ScrollingEllipseLabel1
      // 
      this.ScrollingEllipseLabel1.AutoScroll = true;
      this.ScrollingEllipseLabel1.AutoScrollMargin = new System.Drawing.Size(10, 10);
      this.ScrollingEllipseLabel1.AutoScrollMinSize = new System.Drawing.Size(95, 14);
      this.ScrollingEllipseLabel1.Location = new System.Drawing.Point(29, 32);
      this.ScrollingEllipseLabel1.Name = "ScrollingEllipseLabel1";
      this.ScrollingEllipseLabel1.Size = new System.Drawing.Size(91, 96);
      this.ScrollingEllipseLabel1.TabIndex = 0;
      this.ScrollingEllipseLabel1.Text = "foo123456789abc";
      // 
      // ScrollControls
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(233, 166);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.ScrollingEllipseLabel1});
      this.Name = "ScrollControls";
      this.Text = "ScrollControls";
      this.ResumeLayout(false);

    }
		#endregion
	}
}
