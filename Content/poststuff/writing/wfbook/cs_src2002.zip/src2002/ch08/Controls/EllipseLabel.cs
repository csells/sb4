using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Controls {
  /// <summary>
  /// Summary description for CustomControl1.
  /// </summary>
  public class EllipseLabel : Control {
    public EllipseLabel() {
      // Required for Designer support
      InitializeComponent();

      // Automatically redraw when resized
      this.SetStyle(ControlStyles.ResizeRedraw, true);

      // Double-buffer to eliminate flicker
      this.SetStyle(ControlStyles.DoubleBuffer, true);
      this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
      this.SetStyle(ControlStyles.UserPaint, true);    
    }

    // Let clients know of changes in the Prefix property
    //public event EventHandler PrefixChanged;
    public class PrefixEventArgs : EventArgs {
      public string Prefix;
      public PrefixEventArgs(string prefix) { Prefix = prefix; }
    }

    public delegate
      void PrefixedChangedEventHandler(object sender, PrefixEventArgs e);
    public event PrefixedChangedEventHandler PrefixChanged;

    // Used to prepend to Text property at output
    string prefix = "";

    public void ResetPrefix() {
      this.Prefix = ""; // Uses Prefix setter
    }

    public string Prefix {
      get { return this.prefix; }
      set {
        this.prefix = value;

        // Fire PrefixChanged event 
        if( this.PrefixChanged != null ) {
          PrefixChanged(this, new PrefixEventArgs(value));
        }

        this.Invalidate();
      }
    }

    protected override void OnPaint(PaintEventArgs pe) {
      // Custom paint code
      Graphics g = pe.Graphics;
      using( Brush foreBrush = new SolidBrush(this.ForeColor) )
      using( Brush backBrush = new SolidBrush(this.BackColor) ) {
        g.FillEllipse(foreBrush, this.ClientRectangle);

        StringFormat format = new StringFormat();
        format.Alignment = StringAlignment.Center;
        format.LineAlignment = StringAlignment.Center;
        g.DrawString(
          this.prefix + this.Text, this.Font, backBrush, this.ClientRectangle, format);
      }

      // Calling the base class OnPaint
      base.OnPaint(pe);
    }

    void InitializeComponent() {
      // 
      // EllipseLabel
      // 
      this.Click += new System.EventHandler(this.EllipseLabel_Click);
      this.TextChanged += new System.EventHandler(this.EllipseLabel_TextChanged);
      this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.EllipseLabel_MouseUp);
      this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.EllipseLabel_KeyDown);
      this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.EllipseLabel_MouseMove);
      this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.EllipseLabel_MouseDown);
    }

    void EllipseLabel_TextChanged(object sender, EventArgs e) {
      this.Invalidate();
    }

    void SetMouseForeColor(MouseEventArgs e) {
      if( this.ClientRectangle.Width == e.X ) return;
      if( this.ClientRectangle.Height == e.Y ) return;

      int red = (e.X * 255/(this.ClientRectangle.Width - e.X))%256;
      if( red < 0 ) red = -red;
      int green = 0;
      int blue = (e.Y * 255/(this.ClientRectangle.Height - e.Y))%256;
      if( blue < 0 ) blue = -blue;
      this.ForeColor = Color.FromArgb(red, green, blue);
    }

    void EllipseLabel_MouseDown(object sender, MouseEventArgs e) {
      SetMouseForeColor(e);
    }

    void EllipseLabel_MouseMove(object sender, MouseEventArgs e) {
      if( (e.Button & MouseButtons.Left) == MouseButtons.Left ) {
        SetMouseForeColor(e);
      }
    }

    void EllipseLabel_MouseUp(object sender, MouseEventArgs e) {
      SetMouseForeColor(e);
    }

    //    void EllipseLabel_KeyPress(object sender, KeyPressEventArgs e) {
    //      Point location = new Point(this.Left, this.Top);
    //
    //      switch( e.KeyChar ) {
    //        case 'i':
    //          --location.Y;
    //          break;
    //
    //        case 'j':
    //          --location.X;
    //          break;
    //
    //        case 'k':
    //          ++location.Y;
    //          break;
    //
    //        case 'l':
    //          ++location.X;
    //          break;
    //      }
    //
    //      this.Location = location;
    //    }

    protected override bool IsInputKey(Keys keyData) {
      // Make sure we get arrow keys
      switch( keyData ) {
        case Keys.Up:
        case Keys.Left:
        case Keys.Down:
        case Keys.Right:
          return true;
      }

      // The rest can be determined by the base class
      return base.IsInputKey(keyData);
    }

    void EllipseLabel_KeyDown(object sender, KeyEventArgs e) {
      Point location = new Point(this.Left, this.Top);
  
      switch( e.KeyCode ) {
        case Keys.I:
        case Keys.Up:
          --location.Y;
          break;
  
        case Keys.J:
        case Keys.Left:
          --location.X;
          break;
  
        case Keys.K:
        case Keys.Down:
          ++location.Y;
          break;
  
        case Keys.L:
        case Keys.Right:
          ++location.X;
          break;
      }
  
      this.Location = location;
    }

    void EllipseLabel_Click(object sender, EventArgs e) {
      if( Control.ModifierKeys == Keys.Control ) {
        MessageBox.Show("Ctrl+Click detected");
      }
    }

  }
}
