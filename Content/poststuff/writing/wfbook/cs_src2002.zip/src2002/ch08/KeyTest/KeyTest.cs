using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace KeyTest {
  /// <summary>
  /// Summary description for Form1.
  /// </summary>
  public class Form1 : System.Windows.Forms.Form {
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label keyDataLabel;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label keyCodeLabel;
    private System.Windows.Forms.Label modifiersLabel;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.Label keyValueLabel;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Label keyCharLabel;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.MainMenu mainMenu1;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public Form1() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.label1 = new System.Windows.Forms.Label();
      this.keyDataLabel = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.keyCodeLabel = new System.Windows.Forms.Label();
      this.modifiersLabel = new System.Windows.Forms.Label();
      this.label4 = new System.Windows.Forms.Label();
      this.keyValueLabel = new System.Windows.Forms.Label();
      this.label5 = new System.Windows.Forms.Label();
      this.label3 = new System.Windows.Forms.Label();
      this.keyCharLabel = new System.Windows.Forms.Label();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.label6 = new System.Windows.Forms.Label();
      this.mainMenu1 = new System.Windows.Forms.MainMenu();
      this.groupBox1.SuspendLayout();
      this.SuspendLayout();
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(16, 16);
      this.label1.Name = "label1";
      this.label1.TabIndex = 0;
      this.label1.Text = "KeyData";
      // 
      // keyDataLabel
      // 
      this.keyDataLabel.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.keyDataLabel.Location = new System.Drawing.Point(128, 16);
      this.keyDataLabel.Name = "keyDataLabel";
      this.keyDataLabel.Size = new System.Drawing.Size(192, 23);
      this.keyDataLabel.TabIndex = 1;
      // 
      // label2
      // 
      this.label2.Location = new System.Drawing.Point(16, 48);
      this.label2.Name = "label2";
      this.label2.TabIndex = 0;
      this.label2.Text = "KeyCode";
      // 
      // keyCodeLabel
      // 
      this.keyCodeLabel.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.keyCodeLabel.Location = new System.Drawing.Point(128, 48);
      this.keyCodeLabel.Name = "keyCodeLabel";
      this.keyCodeLabel.Size = new System.Drawing.Size(192, 23);
      this.keyCodeLabel.TabIndex = 1;
      // 
      // modifiersLabel
      // 
      this.modifiersLabel.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.modifiersLabel.Location = new System.Drawing.Point(128, 80);
      this.modifiersLabel.Name = "modifiersLabel";
      this.modifiersLabel.Size = new System.Drawing.Size(192, 23);
      this.modifiersLabel.TabIndex = 1;
      // 
      // label4
      // 
      this.label4.Location = new System.Drawing.Point(16, 80);
      this.label4.Name = "label4";
      this.label4.TabIndex = 0;
      this.label4.Text = "Modifiers";
      // 
      // keyValueLabel
      // 
      this.keyValueLabel.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.keyValueLabel.Location = new System.Drawing.Point(128, 112);
      this.keyValueLabel.Name = "keyValueLabel";
      this.keyValueLabel.Size = new System.Drawing.Size(192, 23);
      this.keyValueLabel.TabIndex = 1;
      // 
      // label5
      // 
      this.label5.Location = new System.Drawing.Point(16, 112);
      this.label5.Name = "label5";
      this.label5.TabIndex = 0;
      this.label5.Text = "KeyValue";
      // 
      // label3
      // 
      this.label3.Location = new System.Drawing.Point(16, 144);
      this.label3.Name = "label3";
      this.label3.TabIndex = 0;
      this.label3.Text = "KeyChar";
      // 
      // keyCharLabel
      // 
      this.keyCharLabel.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.keyCharLabel.Location = new System.Drawing.Point(128, 144);
      this.keyCharLabel.Name = "keyCharLabel";
      this.keyCharLabel.Size = new System.Drawing.Size(192, 23);
      this.keyCharLabel.TabIndex = 1;
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.label6});
      this.groupBox1.Location = new System.Drawing.Point(24, 176);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(296, 64);
      this.groupBox1.TabIndex = 2;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Click In Here!";
      // 
      // label6
      // 
      this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
      this.label6.Location = new System.Drawing.Point(3, 16);
      this.label6.Name = "label6";
      this.label6.Size = new System.Drawing.Size(290, 45);
      this.label6.TabIndex = 0;
      this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      this.label6.Click += new System.EventHandler(this.label6_Click);
      // 
      // Form1
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(328, 246);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.groupBox1,
                                                                  this.keyDataLabel,
                                                                  this.label1,
                                                                  this.label2,
                                                                  this.keyCodeLabel,
                                                                  this.modifiersLabel,
                                                                  this.label4,
                                                                  this.keyValueLabel,
                                                                  this.label5,
                                                                  this.label3,
                                                                  this.keyCharLabel});
      this.Menu = this.mainMenu1;
      this.Name = "Form1";
      this.Text = "KeyTest";
      this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
      this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
      this.groupBox1.ResumeLayout(false);
      this.ResumeLayout(false);

    }
		#endregion

    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main() {
      Application.Run(new Form1());
    }

    private void Form1_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e) {
      keyCharLabel.Text = null;
      keyDataLabel.Text = e.KeyData.ToString();
      keyCodeLabel.Text = e.KeyCode.ToString();
      modifiersLabel.Text = e.Modifiers.ToString();
      keyValueLabel.Text = e.KeyValue.ToString();
    }

    static bool Empty(string s) { return s == null || s.Length == 0; }

    private void Form1_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e) {
      keyCharLabel.Text = "'" + e.KeyChar.ToString() + "'";
      if( Empty(keyCharLabel.Text) ) keyCharLabel.Text = "<empty>";
    }

    void label6_Click(object sender, EventArgs e) {
      if( Control.ModifierKeys == Keys.Control ) {
        label6.Text = "Ctrl+Click detected";
      }
      else {
        label6.Text = "Not a Ctrl+Click";
      }
    }

  }
}
