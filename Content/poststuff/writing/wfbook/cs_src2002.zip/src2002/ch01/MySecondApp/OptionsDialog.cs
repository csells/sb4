using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace MySecondApp {
  /// <summary>
  /// Summary description for OptionsDialog.
  /// </summary>
  public class MyOptionsDialog : System.Windows.Forms.Form {
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Button okButton;
    private System.Windows.Forms.Button cancelButton;
    private System.Windows.Forms.ColorDialog colorDialog1;
    private System.Windows.Forms.ErrorProvider errorProvider1;
    private System.Windows.Forms.Button changeColorButton;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public MyOptionsDialog() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.label1 = new System.Windows.Forms.Label();
      this.changeColorButton = new System.Windows.Forms.Button();
      this.okButton = new System.Windows.Forms.Button();
      this.cancelButton = new System.Windows.Forms.Button();
      this.colorDialog1 = new System.Windows.Forms.ColorDialog();
      this.errorProvider1 = new System.Windows.Forms.ErrorProvider();
      this.SuspendLayout();
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(16, 16);
      this.label1.Name = "label1";
      this.label1.TabIndex = 0;
      this.label1.Text = "Favorite Color";
      this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // changeColorButton
      // 
      this.changeColorButton.Location = new System.Drawing.Point(128, 16);
      this.changeColorButton.Name = "changeColorButton";
      this.changeColorButton.TabIndex = 1;
      this.changeColorButton.Text = "Change...";
      this.changeColorButton.Click += new System.EventHandler(this.changeColorButton_Click);
      this.changeColorButton.Validating += new System.ComponentModel.CancelEventHandler(this.changeColorButton_Validating);
      // 
      // okButton
      // 
      this.okButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
      this.okButton.DialogResult = System.Windows.Forms.DialogResult.OK;
      this.okButton.Location = new System.Drawing.Point(40, 88);
      this.okButton.Name = "okButton";
      this.okButton.TabIndex = 2;
      this.okButton.Text = "OK";
      // 
      // cancelButton
      // 
      this.cancelButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
      this.cancelButton.CausesValidation = false;
      this.cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
      this.cancelButton.Location = new System.Drawing.Point(128, 88);
      this.cancelButton.Name = "cancelButton";
      this.cancelButton.TabIndex = 2;
      this.cancelButton.Text = "Cancel";
      // 
      // MyOptionsDialog
      // 
      this.AcceptButton = this.okButton;
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.CancelButton = this.cancelButton;
      this.ClientSize = new System.Drawing.Size(216, 126);
      this.ControlBox = false;
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.okButton,
                                                                  this.changeColorButton,
                                                                  this.label1,
                                                                  this.cancelButton});
      this.Name = "MyOptionsDialog";
      this.Text = "Options";
      this.ResumeLayout(false);

    }
		#endregion

    private void changeColorButton_Click(object sender, System.EventArgs e) {
      if( colorDialog1.ShowDialog() == DialogResult.OK ) {
        changeColorButton.BackColor = colorDialog1.Color;
      }
    }

private void changeColorButton_Validating(object sender, CancelEventArgs e) {
  byte greenness = changeColorButton.BackColor.G;
  string err = "";
  if( greenness < Color.LightGreen.G ) {
    err = "I'm sorry, we were going for leafy, leafy...";
    e.Cancel = true;
  }
  errorProvider1.SetError(changeColorButton, err);
}

    public Color FavoriteColor {
      get {
        return colorDialog1.Color;
      }
      set {
        changeColorButton.BackColor = value;
        colorDialog1.Color = value;
      }
    }
  }
}
