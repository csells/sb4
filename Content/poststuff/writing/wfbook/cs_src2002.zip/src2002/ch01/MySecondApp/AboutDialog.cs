using System;
using System.Drawing;
using System.Drawing.Printing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace MySecondApp {
  /// <summary>
  /// Summary description for AboutDialog.
  /// </summary>
  public class AboutDialog : System.Windows.Forms.Form {
    private System.Windows.Forms.Button printButton;
    private System.Drawing.Printing.PrintDocument printDocument1;
    private System.Windows.Forms.Button button1;
    private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public AboutDialog() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
      this.SetStyle(ControlStyles.ResizeRedraw, true);
      this.SetStyle(ControlStyles.DoubleBuffer, true);
      this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(AboutDialog));
      this.printButton = new System.Windows.Forms.Button();
      this.printDocument1 = new System.Drawing.Printing.PrintDocument();
      this.button1 = new System.Windows.Forms.Button();
      this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
      this.SuspendLayout();
      // 
      // printButton
      // 
      this.printButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.printButton.Location = new System.Drawing.Point(59, 224);
      this.printButton.Name = "printButton";
      this.printButton.TabIndex = 0;
      this.printButton.Text = "Print";
      this.printButton.Click += new System.EventHandler(this.printButton_Click);
      // 
      // printDocument1
      // 
      this.printDocument1.QueryPageSettings += new System.Drawing.Printing.QueryPageSettingsEventHandler(this.printDocument1_QueryPageSettings);
      this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
      // 
      // button1
      // 
      this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.button1.Location = new System.Drawing.Point(147, 224);
      this.button1.Name = "button1";
      this.button1.Size = new System.Drawing.Size(87, 23);
      this.button1.TabIndex = 0;
      this.button1.Text = "Print Preview";
      this.button1.Click += new System.EventHandler(this.button1_Click);
      // 
      // printPreviewDialog1
      // 
      this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
      this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
      this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
      this.printPreviewDialog1.Enabled = true;
      this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
      this.printPreviewDialog1.Location = new System.Drawing.Point(148, 17);
      this.printPreviewDialog1.MaximumSize = new System.Drawing.Size(0, 0);
      this.printPreviewDialog1.Name = "printPreviewDialog1";
      this.printPreviewDialog1.Opacity = 1;
      this.printPreviewDialog1.TransparencyKey = System.Drawing.Color.Empty;
      this.printPreviewDialog1.Visible = false;
      // 
      // AboutDialog
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(13, 34);
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.printButton,
                                                                  this.button1});
      this.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Name = "AboutDialog";
      this.Text = "About";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.AboutDialog_Paint);
      this.ResumeLayout(false);

    }
		#endregion

void Draw(Graphics g) {
  g.SmoothingMode = SmoothingMode.AntiAlias;

  Rectangle rect = this.ClientRectangle;
  int cx = rect.Width;
  int cy = rect.Height;
  float scale = (float)cy/(float)cx;

  using( LinearGradientBrush brush =
            new LinearGradientBrush( this.ClientRectangle,
                                    Color.Empty,
                                    Color.Empty,
                                    45) ) {
    ColorBlend blend = new ColorBlend();
    blend.Colors = new Color[] { Color.Red, Color.Green, Color.Blue };
    blend.Positions = new float[] { 0, .5f, 1 };
    brush.InterpolationColors = blend;
    using( Pen pen = new Pen(brush) ) {
      for( int x = 0; x < cx; x += 7 ) {
        g.DrawLine(pen, 0, x * scale, cx - x, 0);
        g.DrawLine(pen, 0, (cx - x) * scale, cx - x, cx * scale);
        g.DrawLine(pen, cx - x, 0 * scale, cx, (cx - x) * scale);
        g.DrawLine(pen, cx - x, cx * scale, cx, x * scale);
      }
    }

    StringFormat format = new StringFormat();
    format.Alignment = StringAlignment.Center;
    format.LineAlignment = StringAlignment.Center;
    string s = "Ain't graphics cool?";
    g.DrawString(s, this.Font, brush, rect, format);
  }
}

    void AboutDialog_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      Draw(g);
    }

    private void printButton_Click(object sender, System.EventArgs e) {
      PrintDialog dlg = new PrintDialog();
      dlg.Document = printDocument1;
      if( dlg.ShowDialog() == DialogResult.OK ) {
        printDocument1.Print();
      }
    }

    void printDocument1_PrintPage(object sender, PrintPageEventArgs e) {
      Graphics g = e.Graphics;
      Draw(g);
    }

    void printDocument1_QueryPageSettings(object sender, QueryPageSettingsEventArgs e) {
    }

    private void button1_Click(object sender, System.EventArgs e) {
      printPreviewDialog1.Document = printDocument1;
      printPreviewDialog1.ShowDialog();
    }
  }
}
