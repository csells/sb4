using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;

namespace MySecondApp {
  /// <summary>
  /// Summary description for Form2.
  /// </summary>
  public class Form2 : System.Windows.Forms.Form {
    private System.Windows.Forms.StatusBar statusBar1;
    private System.Windows.Forms.TreeView treeView1;
    private System.Windows.Forms.Splitter splitter1;
    private System.Windows.Forms.MainMenu mainMenu1;
    private System.Windows.Forms.MenuItem menuItem1;
    private System.Windows.Forms.MenuItem viewOptionsMenuItem;
    private System.Windows.Forms.MenuItem menuItem2;
    private System.Windows.Forms.MenuItem helpAboutMenuItem;
    private System.Windows.Forms.TextBox textBox1;
    private System.Windows.Forms.MenuItem menuItem3;
    private System.Windows.Forms.MenuItem fileSaveMenuItem;
    private System.Windows.Forms.SaveFileDialog saveFileDialog1;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public Form2() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.statusBar1 = new System.Windows.Forms.StatusBar();
      this.treeView1 = new System.Windows.Forms.TreeView();
      this.splitter1 = new System.Windows.Forms.Splitter();
      this.mainMenu1 = new System.Windows.Forms.MainMenu();
      this.menuItem3 = new System.Windows.Forms.MenuItem();
      this.fileSaveMenuItem = new System.Windows.Forms.MenuItem();
      this.menuItem1 = new System.Windows.Forms.MenuItem();
      this.viewOptionsMenuItem = new System.Windows.Forms.MenuItem();
      this.menuItem2 = new System.Windows.Forms.MenuItem();
      this.helpAboutMenuItem = new System.Windows.Forms.MenuItem();
      this.textBox1 = new System.Windows.Forms.TextBox();
      this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
      this.SuspendLayout();
      // 
      // statusBar1
      // 
      this.statusBar1.Location = new System.Drawing.Point(0, 75);
      this.statusBar1.Name = "statusBar1";
      this.statusBar1.Size = new System.Drawing.Size(292, 22);
      this.statusBar1.TabIndex = 0;
      this.statusBar1.Text = "Dock = Bottom";
      // 
      // treeView1
      // 
      this.treeView1.Dock = System.Windows.Forms.DockStyle.Left;
      this.treeView1.ImageIndex = -1;
      this.treeView1.Name = "treeView1";
      this.treeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
                                                                          new System.Windows.Forms.TreeNode("Dock", new System.Windows.Forms.TreeNode[] {
                                                                                                                                                          new System.Windows.Forms.TreeNode("=", new System.Windows.Forms.TreeNode[] {
                                                                                                                                                                                                                                       new System.Windows.Forms.TreeNode("Left")})})});
      this.treeView1.SelectedImageIndex = -1;
      this.treeView1.Size = new System.Drawing.Size(121, 75);
      this.treeView1.TabIndex = 1;
      // 
      // splitter1
      // 
      this.splitter1.Location = new System.Drawing.Point(121, 0);
      this.splitter1.Name = "splitter1";
      this.splitter1.Size = new System.Drawing.Size(3, 75);
      this.splitter1.TabIndex = 2;
      this.splitter1.TabStop = false;
      // 
      // mainMenu1
      // 
      this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.menuItem3,
                                                                              this.menuItem1,
                                                                              this.menuItem2});
      // 
      // menuItem3
      // 
      this.menuItem3.Index = 0;
      this.menuItem3.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.fileSaveMenuItem});
      this.menuItem3.Text = "&File";
      // 
      // fileSaveMenuItem
      // 
      this.fileSaveMenuItem.Index = 0;
      this.fileSaveMenuItem.Text = "&Save...";
      this.fileSaveMenuItem.Click += new System.EventHandler(this.fileSaveMenuItem_Click);
      // 
      // menuItem1
      // 
      this.menuItem1.Index = 1;
      this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.viewOptionsMenuItem});
      this.menuItem1.Text = "&View";
      // 
      // viewOptionsMenuItem
      // 
      this.viewOptionsMenuItem.Index = 0;
      this.viewOptionsMenuItem.Text = "&Options...";
      this.viewOptionsMenuItem.Click += new System.EventHandler(this.viewOptionsMenuItem_Click);
      // 
      // menuItem2
      // 
      this.menuItem2.Index = 2;
      this.menuItem2.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.helpAboutMenuItem});
      this.menuItem2.Text = "&Help";
      // 
      // helpAboutMenuItem
      // 
      this.helpAboutMenuItem.Index = 0;
      this.helpAboutMenuItem.Text = "&About...";
      this.helpAboutMenuItem.Click += new System.EventHandler(this.helpAboutMenuItem_Click);
      // 
      // textBox1
      // 
      this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.textBox1.Location = new System.Drawing.Point(124, 0);
      this.textBox1.Multiline = true;
      this.textBox1.Name = "textBox1";
      this.textBox1.Size = new System.Drawing.Size(168, 75);
      this.textBox1.TabIndex = 3;
      this.textBox1.Text = "";
      // 
      // saveFileDialog1
      // 
      this.saveFileDialog1.FileName = "doc1";
      // 
      // Form2
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 97);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.textBox1,
                                                                  this.splitter1,
                                                                  this.treeView1,
                                                                  this.statusBar1});
      this.Menu = this.mainMenu1;
      this.Name = "Form2";
      this.Text = "MyExplorer";
      this.ResumeLayout(false);

    }
		#endregion

    Color color = Color.LightGreen;

    void viewOptionsMenuItem_Click(object sender, System.EventArgs e) {
      MyOptionsDialog dlg = new MyOptionsDialog();
      dlg.FavoriteColor = this.color;
      if( dlg.ShowDialog() == DialogResult.OK ) {
        this.color = dlg.FavoriteColor;
      }
    }

    private void helpAboutMenuItem_Click(object sender, System.EventArgs e) {
      (new AboutDialog()).ShowDialog();
    }

    void fileSaveMenuItem_Click(object sender, EventArgs e) {
      if( saveFileDialog1.ShowDialog() == DialogResult.OK ) {
        using( StreamWriter writer = new StreamWriter(saveFileDialog1.FileName) ) {
          writer.Write(textBox1.Text);
        }
      }
    }
  }
}
