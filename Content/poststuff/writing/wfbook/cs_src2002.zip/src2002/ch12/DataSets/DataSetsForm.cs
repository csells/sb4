using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace DataSets {
  /// <summary>
  /// Summary description for DataSetsForm.
  /// </summary>
  public class Form1 : System.Windows.Forms.Form {
    private System.Windows.Forms.ListBox listBox1;
    private System.Windows.Forms.ContextMenu contextMenu1;
    private System.Windows.Forms.MenuItem addRowMenuItem;
    private System.Windows.Forms.MenuItem updateSelectedRowMenuItem;
    private System.Windows.Forms.MenuItem deleteSelectedRowMenuItem;
    private System.Windows.Forms.MenuItem commitChangesMenuItem;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public Form1() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.listBox1 = new System.Windows.Forms.ListBox();
      this.contextMenu1 = new System.Windows.Forms.ContextMenu();
      this.addRowMenuItem = new System.Windows.Forms.MenuItem();
      this.updateSelectedRowMenuItem = new System.Windows.Forms.MenuItem();
      this.deleteSelectedRowMenuItem = new System.Windows.Forms.MenuItem();
      this.commitChangesMenuItem = new System.Windows.Forms.MenuItem();
      this.SuspendLayout();
      // 
      // listBox1
      // 
      this.listBox1.ContextMenu = this.contextMenu1;
      this.listBox1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.listBox1.IntegralHeight = false;
      this.listBox1.Name = "listBox1";
      this.listBox1.Size = new System.Drawing.Size(292, 266);
      this.listBox1.TabIndex = 0;
      // 
      // contextMenu1
      // 
      this.contextMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                 this.addRowMenuItem,
                                                                                 this.updateSelectedRowMenuItem,
                                                                                 this.deleteSelectedRowMenuItem,
                                                                                 this.commitChangesMenuItem});
      // 
      // addRowMenuItem
      // 
      this.addRowMenuItem.Index = 0;
      this.addRowMenuItem.Text = "&Add Row";
      this.addRowMenuItem.Click += new System.EventHandler(this.addRowMenuItem_Click);
      // 
      // updateSelectedRowMenuItem
      // 
      this.updateSelectedRowMenuItem.Index = 1;
      this.updateSelectedRowMenuItem.Text = "&Update Selected Row";
      this.updateSelectedRowMenuItem.Click += new System.EventHandler(this.updateSelectedRowMenuItem_Click);
      // 
      // deleteSelectedRowMenuItem
      // 
      this.deleteSelectedRowMenuItem.Index = 2;
      this.deleteSelectedRowMenuItem.Text = "&Delete Selected Row";
      this.deleteSelectedRowMenuItem.Click += new System.EventHandler(this.deleteSelectedRowMenuItem_Click);
      // 
      // commitChangesMenuItem
      // 
      this.commitChangesMenuItem.Index = 3;
      this.commitChangesMenuItem.Text = "&Commit Changes";
      this.commitChangesMenuItem.Click += new System.EventHandler(this.commitChangesMenuItem_Click);
      // 
      // Form1
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.listBox1});
      this.Name = "Form1";
      this.Text = "Data Sets";
      this.Load += new System.EventHandler(this.DataSetsForm_Load);
      this.ResumeLayout(false);

    }
		#endregion

    // A data set for use by the form
    DataSet dataset = new DataSet();

    void PopulateListBox() {
      // Clear the listbox
      listBox1.Items.Clear();

      // Enumerate cached data
      foreach( DataRow row in dataset.Tables[0].Rows ) {
        if( (row.RowState & DataRowState.Deleted) != 0 )  {
          string id =
            row["CustomerID", DataRowVersion.Original].ToString();
          listBox1.Items.Add("***deleted***: " + id);
          continue;
        }

        string item = row["ContactTitle"] + ", " + row["ContactName"];
        //item += string.Format(" ({2})", row.RowState);
        if( row.HasErrors ) item += "(***" + row.RowError + "***)";
        listBox1.Items.Add(item);
      }
    }

    void DataSetsForm_Load(object sender, EventArgs e) {
      // Configure the connection
      SqlConnection conn = new SqlConnection(@"data source=MUNGO\NETSDK;initial catalog=northwind;integrated security=SSPI");

      // Create the adapter from the connection
      SqlDataAdapter adapter = new SqlDataAdapter(conn.CreateCommand());
      adapter.SelectCommand.CommandText = "select * from customers";

      // Fill the data set w/ the Customers table
      adapter.Fill(dataset);

      // Populate listbox
      PopulateListBox();
    }

    void addRowMenuItem_Click(object sender, EventArgs e) {
      // Ask table for an empty DataRow
      DataRow row = dataset.Tables[0].NewRow();

      // Fill DataRow
      row["CustomerID"] = "SELLSB";
      row["CompanyName"] = "Sells Brothers, Inc.";
      row["ContactName"] = "Chris Sells";
      row["ContactTitle"] = "Chief Cook and Bottle Washer";
      row["Address"] = "555 Not My Street";
      row["City"] = "Beaverton";
      row["Region"] = "OR";
      row["PostalCode"] = "97007";
      row["Country"] = "USA";
      row["Phone"] = "503-555-1234";
      row["Fax"] = "503-555-4321";

      // Add DataRow to the table
      dataset.Tables[0].Rows.Add(row);

      // Update listbox
      PopulateListBox();
    }

    void updateSelectedRowMenuItem_Click(object sender, EventArgs e) {
      // Get selection index from listbox
      int index = listBox1.SelectedIndex;
      if( index == -1 ) return;

      // Get row from dataset
      DataRow row = dataset.Tables[0].Rows[index];

      // Update the row as appropriate
      row["ContactTitle"] = "CEO";

      DataTable
        tableChanges = dataset.Tables[0].GetChanges(DataRowState.Modified);
      if( tableChanges != null ) {
        foreach( DataRow changedRow in tableChanges.Rows ) {
          MessageBox.Show(changedRow["CustomerID"] + " modified");
        }
      }

      // Update listbox
      PopulateListBox();
    }

    void deleteSelectedRowMenuItem_Click(object sender, EventArgs e) {
      // Get selection index from listbox
      int index = listBox1.SelectedIndex;
      if( index == -1 ) return;

      // Get row from dataset
      DataRow row = dataset.Tables[0].Rows[index];

      // Remove the row from the dataset
      //dataset.Tables[0].Rows.Remove(row);

      // Mark the row as deleted
      row.Delete();

      DataTable tableChanges = dataset.Tables[0].GetChanges(DataRowState.Deleted);
      if( tableChanges != null ) {
        foreach( DataRow deletedRow in tableChanges.Rows ) {
          MessageBox.Show("***deleted***" + deletedRow["CustomerID", DataRowVersion.Original]);
        }
      }

      // Update listbox
      PopulateListBox();
    }

    void commitChangesMenuItem_Click(object sender, EventArgs e) {
      //      // Build command text for doing deletes
      //      StringBuilder sb = new StringBuilder();
      //      foreach( DataRow row in dataset.Tables[0].GetChanges(DataRowState.Deleted).Rows ) {
      //        string id = row["CustomerID", DataRowVersion.Original].ToString();
      //        sb.AppendFormat("delete from customers where CustomerID = '{0}';\r\n", id);
      //      }
      //
      //      if( sb.Length == 0 ) return;
      //      string cmdText = sb.ToString();
      //      MessageBox.Show(cmdText);
      //      
      //      // Configure the connection
      //      SqlConnection conn = new SqlConnection(@"data source=MUNGO\NETSDK;initial catalog=northwind;integrated security=SSPI");
      //      
      //      // Create command
      //      SqlCommand cmd = new SqlCommand(cmdText, conn);
      //      
      //      // Replicate changes back to data source
      //      conn.Open();
      //      int rowsDeleted = 0;
      //      try {
      //        rowsDeleted = cmd.ExecuteNonQuery();
      //      
      //        // Reset row state
      //        dataset.AcceptChanges();
      //      }
      //      finally {
      //        conn.Close();
      //      }
      //      
      //      MessageBox.Show("Deleted " + rowsDeleted.ToString() + " rows");
      
      // Configure the connection
      SqlConnection conn = new SqlConnection(@"data source=MUNGO\NETSDK;initial catalog=northwind;integrated security=SSPI");
      
      // Create the adapter from the connection w/ a select command
      SqlDataAdapter
        adapter = new SqlDataAdapter("select * from customers", conn);
      
      // Let command builder build commands for insert, update and delete
      new SqlCommandBuilder(adapter);
      
      // Commit changes back to the data source
      try {
        adapter.Update(dataset);
      }
      catch( SqlException ex ) {
        MessageBox.Show(ex.Message, "Error(s) Commiting Changes");
      }

      // Update listbox
      PopulateListBox();
    }
  }
}










