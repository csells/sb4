using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Drawing.Drawing2D;
using System.Diagnostics;

namespace Transparency {
  /// <summary>
  /// Summary description for TransparentForm.
  /// </summary>
  public class TransparentForm : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public TransparentForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
      this.SetStyle(ControlStyles.ResizeRedraw, true);
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      // 
      // TransparentForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(8, 19);
      this.ClientSize = new System.Drawing.Size(216, 102);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
      this.Name = "TransparentForm";
      this.Text = "Transparency Test";
      this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TransparentForm_KeyDown);
      this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.TransparentForm_MouseDown);
      this.SizeChanged += new System.EventHandler(this.TransparentForm_SizeChanged);
      this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TransparentForm_KeyPress);
      this.Load += new System.EventHandler(this.TransparentForm_Load);
      this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.TransparentForm_MouseUp);
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.TransparentForm_Paint);
      this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.TransparentForm_MouseMove);

    }
		#endregion

    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main() {
      Application.Run(new TransparentForm());
    }

    void TransparentForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      using( Pen pen = new Pen(Color.DarkBlue, 4) ) {
        Rectangle rect = this.ClientRectangle;
        rect.Inflate(-2, -2);
        g.FillEllipse(Brushes.Yellow, rect);
        g.DrawEllipse(pen, rect);
      }
      using( Font font = new Font(this.Font, FontStyle.Bold) ) {
        StringFormat format = new StringFormat();
        format.Alignment = StringAlignment.Center;
        format.LineAlignment = StringAlignment.Center;
        g.DrawString("an ellise", font, Brushes.DarkBlue, this.ClientRectangle, format);
      }
    }

    void SetEllipseRegion() {
      // Assume: this.FormBorderStyle = FormBorderStyle.None
      Rectangle rect = this.ClientRectangle;
      using( GraphicsPath path = new GraphicsPath() ) {
        path.AddEllipse(rect);
        this.Region = new Region(path);
      }
    }

    void TransparentForm_Load(object sender, EventArgs e) {
      SetEllipseRegion();
    }

    void TransparentForm_SizeChanged(object sender, EventArgs e) {
      SetEllipseRegion();    
    }

    Point downPoint = Point.Empty;

    void TransparentForm_MouseDown(object sender, MouseEventArgs e) {
      if( e.Button != MouseButtons.Left ) return;
      downPoint = new Point(e.X, e.Y);
    }

    void TransparentForm_MouseMove(object sender, MouseEventArgs e) {
      if( downPoint == Point.Empty ) return;
      Point location =
        new Point(
        this.Left + e.X - downPoint.X, this.Top + e.Y - downPoint.Y);
      this.Location = location;
    }

    void TransparentForm_MouseUp(object sender, MouseEventArgs e) {
      if( e.Button != MouseButtons.Left ) return;
      downPoint = Point.Empty;
    }

    void TransparentForm_KeyDown(object sender, KeyEventArgs e) {
      Point location = new Point(this.Left, this.Top);
  
      switch( e.KeyCode ) {
        case Keys.I:
        case Keys.Up:
          --location.Y;
          break;
  
        case Keys.J:
        case Keys.Left:
          --location.X;
          break;
  
        case Keys.K:
        case Keys.Down:
          ++location.Y;
          break;
  
        case Keys.L:
        case Keys.Right:
          ++location.X;
          break;
      }
  
      this.Location = location;
    }

    void TransparentForm_KeyPress(object sender, KeyPressEventArgs e) {
      Point location = new Point(this.Left, this.Top);
        
      switch( e.KeyChar ) {
        case 'i':
          --location.Y;
          break;
        
        case 'j':
          --location.X;
          break;
        
        case 'k':
          ++location.Y;
          break;
        
        case 'l':
          ++location.X;
          break;
      }
  
      this.Location = location;
    }

    //    protected override void WndProc(ref Message m) {
    //      // Let the base class have first crack
    //      base.WndProc(ref m);
    //      int WM_NCHITTEST = 0x84; // winuser.h
    //      if( m.Msg != WM_NCHITTEST ) return;
    //
    //      // If the user clicked on the client area,
    //      // ask the OS to treat it as a click on the caption
    //      int HTCLIENT = 1;
    //      int HTCAPTION = 2;
    //
    //      if( m.Result.ToInt32() == HTCLIENT ) m.Result = (IntPtr)HTCAPTION;
    //
    //      // Check for a point along the edge
    //      // TODO: just check along the edge
    //      int HTLEFT = 10;
    //      int HTRIGHT = 11;
    //      int HTTOP = 12;
    //      int HTTOPLEFT = 13;
    //      int HTTOPRIGHT = 14;
    //      int HTBOTTOM = 15;
    //      int HTBOTTOMLEFT = 16;
    //      int HTBOTTOMRIGHT = 17;
    //
    //      // Map point around center of ellipse
    //      Point clientLocation = this.PointToClient(new Point(m.LParam.ToInt32()));
    //      int x = clientLocation.X; // TODO
    //      int y = clientLocation.Y; // TODO
    //
    //      // Check for infinity and zero
    //      if( x == 0 && y == 0 ) { m.Result = (IntPtr)HTCAPTION; return; }
    //      else if( x == 0 && y >= 0 ) { m.Result = (IntPtr)HTRIGHT; return; }
    //      else if( x == 0 ) { m.Result = (IntPtr)HTLEFT; return; }
    //      else if( y == 0 && x >= 0 ) { m.Result = (IntPtr)HTTOP; return; }
    //      else if( y == 0 ) { m.Result = (IntPtr)HTBOTTOM; return; }
    //      else Debug.Assert(x != 0 && y != 0);
    //
    //      float slopeAbs = Math.Abs((float)y/(float)x);
    //      if( x > 0 && y > 0 ) {
    //        // Q1
    //        if( slopeAbs > 2 ) m.Result = (IntPtr)HTTOP;
    //        else if( slopeAbs < .5 ) m.Result = (IntPtr)HTRIGHT;
    //        else m.Result = (IntPtr)HTTOPRIGHT;
    //      }
    //      else if( x > 0 && y < 0 ) {
    //        // Q2
    //        if( slopeAbs > 2 ) m.Result = (IntPtr)HTBOTTOM;
    //        else if( slopeAbs < .5 ) m.Result = (IntPtr)HTRIGHT;
    //        else m.Result = (IntPtr)HTBOTTOMRIGHT;
    //      }
    //      else if( x < 0 && y < 0 ) {
    //        // Q3
    //        if( slopeAbs > 2 ) m.Result = (IntPtr)HTBOTTOM;
    //        else if( slopeAbs < .5 ) m.Result = (IntPtr)HTLEFT;
    //        else m.Result = (IntPtr)HTBOTTOMLEFT;
    //      }
    //      else {
    //        // Q4
    //        Debug.Assert(x < 0 && y > 0);
    //        if( slopeAbs > 2 ) m.Result = (IntPtr)HTTOP;
    //        else if( slopeAbs < .5 ) m.Result = (IntPtr)HTLEFT;
    //        else m.Result = (IntPtr)HTTOPLEFT;
    //      }
    //    }

  }
}












