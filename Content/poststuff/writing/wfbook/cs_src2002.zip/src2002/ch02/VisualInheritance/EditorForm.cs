using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;

using System.Windows.Forms;


namespace VisualInheritance
{
	public class EditorForm : VisualInheritance.BaseForm
	{
    private System.Windows.Forms.TextBox textBox1;
		private System.ComponentModel.IContainer components = null;

		public EditorForm()
		{
			// This call is required by the Windows Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.textBox1 = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // statusBar
      // 
      this.statusBar.Location = new System.Drawing.Point(0, 50);
      this.statusBar.Text = "Really ready...";
      this.statusBar.Visible = true;
      // 
      // textBox1
      // 
      this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.textBox1.Multiline = true;
      this.textBox1.Name = "textBox1";
      this.textBox1.Size = new System.Drawing.Size(176, 72);
      this.textBox1.TabIndex = 1;
      this.textBox1.Text = "The quick brown fox, blah, blah, blah...";
      // 
      // EditorForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(176, 72);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.statusBar,
                                                                  this.textBox1});
      this.Name = "EditorForm";
      this.Text = "EditorForm";
      this.ResumeLayout(false);

    }
		#endregion
	}
}

