using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace WindowsApplication33 {
  /// <summary>
  /// Summary description for Form1.
  /// </summary>
  public class ParentForm : System.Windows.Forms.Form {
    private System.Windows.Forms.MainMenu mainMenu1;
    private System.Windows.Forms.MenuItem menuItem1;
    private System.Windows.Forms.MenuItem cmdFileNewChild;
    private System.Windows.Forms.MenuItem menuItem3;
    private System.Windows.Forms.MenuItem cmdWindowTileChildrenVert;
    private System.Windows.Forms.MenuItem cmdWindowTileChildrenHoriz;
    private System.Windows.Forms.MenuItem menuItem9;
    private System.Windows.Forms.MenuItem cmdFileExit;
    private System.Windows.Forms.MenuItem cmdWindowArrangeIcons;
    private System.Windows.Forms.MenuItem cmdCascade;
    private System.Windows.Forms.StatusBar statusBar1;
    private System.Windows.Forms.TreeView treeView1;
    private System.Windows.Forms.Splitter splitter1;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    int nextChild = 1;

    public ParentForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.mainMenu1 = new System.Windows.Forms.MainMenu();
      this.menuItem1 = new System.Windows.Forms.MenuItem();
      this.cmdFileNewChild = new System.Windows.Forms.MenuItem();
      this.menuItem9 = new System.Windows.Forms.MenuItem();
      this.cmdFileExit = new System.Windows.Forms.MenuItem();
      this.menuItem3 = new System.Windows.Forms.MenuItem();
      this.cmdWindowArrangeIcons = new System.Windows.Forms.MenuItem();
      this.cmdCascade = new System.Windows.Forms.MenuItem();
      this.cmdWindowTileChildrenVert = new System.Windows.Forms.MenuItem();
      this.cmdWindowTileChildrenHoriz = new System.Windows.Forms.MenuItem();
      this.statusBar1 = new System.Windows.Forms.StatusBar();
      this.treeView1 = new System.Windows.Forms.TreeView();
      this.splitter1 = new System.Windows.Forms.Splitter();
      this.SuspendLayout();
      // 
      // mainMenu1
      // 
      this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.menuItem1,
                                                                              this.menuItem3});
      // 
      // menuItem1
      // 
      this.menuItem1.Index = 0;
      this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.cmdFileNewChild,
                                                                              this.menuItem9,
                                                                              this.cmdFileExit});
      this.menuItem1.MergeType = System.Windows.Forms.MenuMerge.MergeItems;
      this.menuItem1.Text = "&File";
      // 
      // cmdFileNewChild
      // 
      this.cmdFileNewChild.Index = 0;
      this.cmdFileNewChild.Shortcut = System.Windows.Forms.Shortcut.CtrlN;
      this.cmdFileNewChild.Text = "&New Child";
      this.cmdFileNewChild.Click += new System.EventHandler(this.cmdFileNewChild_Click);
      // 
      // menuItem9
      // 
      this.menuItem9.Index = 1;
      this.menuItem9.MergeOrder = 2;
      this.menuItem9.Text = "-";
      // 
      // cmdFileExit
      // 
      this.cmdFileExit.Index = 2;
      this.cmdFileExit.MergeOrder = 2;
      this.cmdFileExit.Text = "E&xit";
      this.cmdFileExit.Click += new System.EventHandler(this.cmdFileExit_Click);
      // 
      // menuItem3
      // 
      this.menuItem3.Index = 1;
      this.menuItem3.MdiList = true;
      this.menuItem3.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.cmdWindowArrangeIcons,
                                                                              this.cmdCascade,
                                                                              this.cmdWindowTileChildrenVert,
                                                                              this.cmdWindowTileChildrenHoriz});
      this.menuItem3.MergeOrder = 2;
      this.menuItem3.Text = "&Window";
      // 
      // cmdWindowArrangeIcons
      // 
      this.cmdWindowArrangeIcons.Index = 0;
      this.cmdWindowArrangeIcons.Text = "&Arrange Icons";
      this.cmdWindowArrangeIcons.Click += new System.EventHandler(this.cmdWindowArrangeIcons_Click);
      // 
      // cmdCascade
      // 
      this.cmdCascade.Index = 1;
      this.cmdCascade.Text = "&Cascade";
      this.cmdCascade.Click += new System.EventHandler(this.cmdCascade_Click);
      // 
      // cmdWindowTileChildrenVert
      // 
      this.cmdWindowTileChildrenVert.Index = 2;
      this.cmdWindowTileChildrenVert.Text = "Tile Children &Vertically";
      this.cmdWindowTileChildrenVert.Click += new System.EventHandler(this.cmdWindowTileChildrenVert_Click);
      // 
      // cmdWindowTileChildrenHoriz
      // 
      this.cmdWindowTileChildrenHoriz.Index = 3;
      this.cmdWindowTileChildrenHoriz.Text = "Tile Children &Horizontally";
      this.cmdWindowTileChildrenHoriz.Click += new System.EventHandler(this.cmdWindowTileChildrenHoriz_Click);
      // 
      // statusBar1
      // 
      this.statusBar1.Location = new System.Drawing.Point(0, 179);
      this.statusBar1.Name = "statusBar1";
      this.statusBar1.Size = new System.Drawing.Size(352, 22);
      this.statusBar1.TabIndex = 1;
      this.statusBar1.Text = "Ready";
      // 
      // treeView1
      // 
      this.treeView1.Dock = System.Windows.Forms.DockStyle.Left;
      this.treeView1.ImageIndex = -1;
      this.treeView1.Name = "treeView1";
      this.treeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
                                                                          new System.Windows.Forms.TreeNode("Children")});
      this.treeView1.SelectedImageIndex = -1;
      this.treeView1.Size = new System.Drawing.Size(121, 179);
      this.treeView1.TabIndex = 2;
      this.treeView1.Click += new System.EventHandler(this.treeView1_Click);
      // 
      // splitter1
      // 
      this.splitter1.Location = new System.Drawing.Point(121, 0);
      this.splitter1.Name = "splitter1";
      this.splitter1.Size = new System.Drawing.Size(3, 179);
      this.splitter1.TabIndex = 3;
      this.splitter1.TabStop = false;
      // 
      // ParentForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(352, 201);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.splitter1,
                                                                  this.treeView1,
                                                                  this.statusBar1});
      this.IsMdiContainer = true;
      this.Menu = this.mainMenu1;
      this.Name = "ParentForm";
      this.Text = "MDI Parent";
      this.ResumeLayout(false);

    }
		#endregion

    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main() {
      Application.Run(new ParentForm());
    }

    void ChildClosed(object sender, EventArgs e) {
      foreach( TreeNode node in treeView1.Nodes[0].Nodes ) {
        if( node.Tag == sender ) {
          treeView1.Nodes[0].Nodes.Remove(node);
          break;
        }
      }
    }

    void cmdFileNewChild_Click(object sender, EventArgs e) {
      // Create and show new MDI child
      Form child = new ChildForm();
      child.Text = "MDI Child " + nextChild;
      child.Closed += new EventHandler(ChildClosed);
      ++nextChild;
      child.MdiParent = this;
      child.Show();

      // Add node to treeview
      TreeNode	node = new TreeNode(child.Text);
      node.Tag = child;
      treeView1.Nodes[0].Nodes.Add(node);
      treeView1.Nodes[0].Expand();
    }

    private void cmdFileExit_Click(object sender, System.EventArgs e) {
      Close();
    }

    void cmdWindowArrangeIcons_Click(object sender, EventArgs e) {
      this.LayoutMdi(MdiLayout.ArrangeIcons);
    }

    void cmdCascade_Click(object sender, EventArgs e) {
      this.LayoutMdi(MdiLayout.Cascade);
    }
        
    void cmdWindowTileChildrenVert_Click(object sender, EventArgs e) {
      this.LayoutMdi(MdiLayout.TileVertical);
    }
        
    void cmdWindowTileChildrenHoriz_Click(object sender, EventArgs e) {
      this.LayoutMdi(MdiLayout.TileHorizontal);
    }

    private void treeView1_Click(object sender, EventArgs e) {
      // Activate MDI child based on selection in treeview
      Form	child = treeView1.SelectedNode.Tag as Form;
      if( child != null ) child.Activate();
    }

  }
}
