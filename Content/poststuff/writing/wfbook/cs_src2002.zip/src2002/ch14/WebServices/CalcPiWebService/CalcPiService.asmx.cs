using System;
using System.Text;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;

namespace CalcPiWebService {
  public class CalcPiService : System.Web.Services.WebService {
    public CalcPiService() {
      InitializeComponent();
    }

	#region Component Designer generated code
	
    //Required by the Web Services Designer 
    private IContainer components = null;
			
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if(disposing && components != null) {
        components.Dispose();
      }
      base.Dispose(disposing);		
    }
	
	#endregion

    [WebMethod]
    public string CalcPi(int digits) {
      StringBuilder pi = new StringBuilder("3", digits + 2);

      if( digits > 0 ) {
        pi.Append(".");

        for( int i = 0; i < digits; i += 9 ) {
          int nineDigits = NineDigitsOfPi.StartingAt(i+1);
          int digitCount = Math.Min(digits - i, 9);
          string ds = string.Format("{0:D9}", nineDigits);
          pi.Append(ds.Substring(0, digitCount));
        }
      }

      return pi.ToString();

    }

  }
}
