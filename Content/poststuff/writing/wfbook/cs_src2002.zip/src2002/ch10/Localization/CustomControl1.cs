using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Localization
{
	/// <summary>
	/// Summary description for CustomControl1.
	/// </summary>
	public class CustomControl1 : System.Windows.Forms.Control
	{
		public CustomControl1()
		{
		}

		protected override void OnPaint(PaintEventArgs pe)
		{
			// TODO: Add custom paint code here

			// Calling the base class OnPaint
			base.OnPaint(pe);
		}
	}
}
