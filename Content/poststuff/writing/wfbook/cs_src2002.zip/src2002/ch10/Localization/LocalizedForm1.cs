using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace LocalizedApp
{
	/// <summary>
	/// Summary description for LocalizedForm1.
	/// </summary>
	public class LocalizedForm1 : System.Windows.Forms.Form
	{
    private System.Windows.Forms.Button button1;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.TextBox textBox1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public LocalizedForm1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(LocalizedForm1));
      this.button1 = new System.Windows.Forms.Button();
      this.label1 = new System.Windows.Forms.Label();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.textBox1 = new System.Windows.Forms.TextBox();
      this.groupBox1.SuspendLayout();
      this.SuspendLayout();
      // 
      // button1
      // 
      this.button1.AccessibleDescription = ((string)(resources.GetObject("button1.AccessibleDescription")));
      this.button1.AccessibleName = ((string)(resources.GetObject("button1.AccessibleName")));
      this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("button1.Anchor")));
      this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
      this.button1.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("button1.Dock")));
      this.button1.Enabled = ((bool)(resources.GetObject("button1.Enabled")));
      this.button1.FlatStyle = ((System.Windows.Forms.FlatStyle)(resources.GetObject("button1.FlatStyle")));
      this.button1.Font = ((System.Drawing.Font)(resources.GetObject("button1.Font")));
      this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
      this.button1.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("button1.ImageAlign")));
      this.button1.ImageIndex = ((int)(resources.GetObject("button1.ImageIndex")));
      this.button1.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("button1.ImeMode")));
      this.button1.Location = ((System.Drawing.Point)(resources.GetObject("button1.Location")));
      this.button1.Name = "button1";
      this.button1.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("button1.RightToLeft")));
      this.button1.Size = ((System.Drawing.Size)(resources.GetObject("button1.Size")));
      this.button1.TabIndex = ((int)(resources.GetObject("button1.TabIndex")));
      this.button1.Text = resources.GetString("button1.Text");
      this.button1.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("button1.TextAlign")));
      this.button1.Visible = ((bool)(resources.GetObject("button1.Visible")));
      this.button1.Click += new System.EventHandler(this.button1_Click);
      // 
      // label1
      // 
      this.label1.AccessibleDescription = ((string)(resources.GetObject("label1.AccessibleDescription")));
      this.label1.AccessibleName = ((string)(resources.GetObject("label1.AccessibleName")));
      this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("label1.Anchor")));
      this.label1.AutoSize = ((bool)(resources.GetObject("label1.AutoSize")));
      this.label1.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("label1.Dock")));
      this.label1.Enabled = ((bool)(resources.GetObject("label1.Enabled")));
      this.label1.Font = ((System.Drawing.Font)(resources.GetObject("label1.Font")));
      this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
      this.label1.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("label1.ImageAlign")));
      this.label1.ImageIndex = ((int)(resources.GetObject("label1.ImageIndex")));
      this.label1.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("label1.ImeMode")));
      this.label1.Location = ((System.Drawing.Point)(resources.GetObject("label1.Location")));
      this.label1.Name = "label1";
      this.label1.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("label1.RightToLeft")));
      this.label1.Size = ((System.Drawing.Size)(resources.GetObject("label1.Size")));
      this.label1.TabIndex = ((int)(resources.GetObject("label1.TabIndex")));
      this.label1.Text = resources.GetString("label1.Text");
      this.label1.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("label1.TextAlign")));
      this.label1.Visible = ((bool)(resources.GetObject("label1.Visible")));
      // 
      // groupBox1
      // 
      this.groupBox1.AccessibleDescription = ((string)(resources.GetObject("groupBox1.AccessibleDescription")));
      this.groupBox1.AccessibleName = ((string)(resources.GetObject("groupBox1.AccessibleName")));
      this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("groupBox1.Anchor")));
      this.groupBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("groupBox1.BackgroundImage")));
      this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.textBox1,
                                                                            this.label1,
                                                                            this.button1});
      this.groupBox1.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("groupBox1.Dock")));
      this.groupBox1.Enabled = ((bool)(resources.GetObject("groupBox1.Enabled")));
      this.groupBox1.Font = ((System.Drawing.Font)(resources.GetObject("groupBox1.Font")));
      this.groupBox1.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("groupBox1.ImeMode")));
      this.groupBox1.Location = ((System.Drawing.Point)(resources.GetObject("groupBox1.Location")));
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("groupBox1.RightToLeft")));
      this.groupBox1.Size = ((System.Drawing.Size)(resources.GetObject("groupBox1.Size")));
      this.groupBox1.TabIndex = ((int)(resources.GetObject("groupBox1.TabIndex")));
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = resources.GetString("groupBox1.Text");
      this.groupBox1.Visible = ((bool)(resources.GetObject("groupBox1.Visible")));
      // 
      // textBox1
      // 
      this.textBox1.AccessibleDescription = ((string)(resources.GetObject("textBox1.AccessibleDescription")));
      this.textBox1.AccessibleName = ((string)(resources.GetObject("textBox1.AccessibleName")));
      this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("textBox1.Anchor")));
      this.textBox1.AutoSize = ((bool)(resources.GetObject("textBox1.AutoSize")));
      this.textBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("textBox1.BackgroundImage")));
      this.textBox1.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("textBox1.Dock")));
      this.textBox1.Enabled = ((bool)(resources.GetObject("textBox1.Enabled")));
      this.textBox1.Font = ((System.Drawing.Font)(resources.GetObject("textBox1.Font")));
      this.textBox1.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("textBox1.ImeMode")));
      this.textBox1.Location = ((System.Drawing.Point)(resources.GetObject("textBox1.Location")));
      this.textBox1.MaxLength = ((int)(resources.GetObject("textBox1.MaxLength")));
      this.textBox1.Multiline = ((bool)(resources.GetObject("textBox1.Multiline")));
      this.textBox1.Name = "textBox1";
      this.textBox1.PasswordChar = ((char)(resources.GetObject("textBox1.PasswordChar")));
      this.textBox1.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("textBox1.RightToLeft")));
      this.textBox1.ScrollBars = ((System.Windows.Forms.ScrollBars)(resources.GetObject("textBox1.ScrollBars")));
      this.textBox1.Size = ((System.Drawing.Size)(resources.GetObject("textBox1.Size")));
      this.textBox1.TabIndex = ((int)(resources.GetObject("textBox1.TabIndex")));
      this.textBox1.Text = resources.GetString("textBox1.Text");
      this.textBox1.TextAlign = ((System.Windows.Forms.HorizontalAlignment)(resources.GetObject("textBox1.TextAlign")));
      this.textBox1.Visible = ((bool)(resources.GetObject("textBox1.Visible")));
      this.textBox1.WordWrap = ((bool)(resources.GetObject("textBox1.WordWrap")));
      // 
      // LocalizedForm1
      // 
      this.AccessibleDescription = ((string)(resources.GetObject("$this.AccessibleDescription")));
      this.AccessibleName = ((string)(resources.GetObject("$this.AccessibleName")));
      this.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("$this.Anchor")));
      this.AutoScaleBaseSize = ((System.Drawing.Size)(resources.GetObject("$this.AutoScaleBaseSize")));
      this.AutoScroll = ((bool)(resources.GetObject("$this.AutoScroll")));
      this.AutoScrollMargin = ((System.Drawing.Size)(resources.GetObject("$this.AutoScrollMargin")));
      this.AutoScrollMinSize = ((System.Drawing.Size)(resources.GetObject("$this.AutoScrollMinSize")));
      this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
      this.ClientSize = ((System.Drawing.Size)(resources.GetObject("$this.ClientSize")));
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.groupBox1});
      this.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("$this.Dock")));
      this.Enabled = ((bool)(resources.GetObject("$this.Enabled")));
      this.Font = ((System.Drawing.Font)(resources.GetObject("$this.Font")));
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("$this.ImeMode")));
      this.Location = ((System.Drawing.Point)(resources.GetObject("$this.Location")));
      this.MaximumSize = ((System.Drawing.Size)(resources.GetObject("$this.MaximumSize")));
      this.MinimumSize = ((System.Drawing.Size)(resources.GetObject("$this.MinimumSize")));
      this.Name = "LocalizedForm1";
      this.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("$this.RightToLeft")));
      this.StartPosition = ((System.Windows.Forms.FormStartPosition)(resources.GetObject("$this.StartPosition")));
      this.Text = resources.GetString("$this.Text");
      this.Visible = ((bool)(resources.GetObject("$this.Visible")));
      this.groupBox1.ResumeLayout(false);
      this.ResumeLayout(false);

    }
		#endregion

    private void button1_Click(object sender, System.EventArgs e) {
      (new LocalizedForm2()).ShowDialog();
    }
	}
}
