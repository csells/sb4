// This sample demonstrates the following:
//
// -How to use DX to play a MIDI file from managed code
// -How to use the ComponentModel to get resources disposed when the parent form is closed
// -How to properly managed a COM object using ReleaseComObject
// -How to build an unmanaged resource-only DLL
// -How to link unmanaged resources into a managed assembly from within VS.NET
//
// NOTE: This sample depends on the most excellent ntcopyres from
// http://www.codeguru.com/cpp_mfc/rsrc-simple.html to copy the resources
// (a compiled version is part of this sample). Unfortunately, since Win9x
// doesn't support the UpdateResource function, this sample requires an NT-based
// implementation of the Win32 API.
//
// NOTE: The auto-building doesn't seem to work if I do Ctrl-F5 from w/in VS.NET
// because VS.NET seems to relink, but not cause the build step in the resource
// project to run (but why?)

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Reflection;

namespace MidiPlaybackTest
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
        private System.Windows.Forms.Button cmdStart;
        private System.Windows.Forms.Button cmdStop;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
        MidiPlayer  player = new MidiPlayer();

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
            if( components == null ) components = new Container();
            components.Add(player);

            player.LoadFromResource(Assembly.GetExecutingAssembly().Location, "SAMPLE4.MID");
            //player.LoadFromFile(@"C:\temp\MidiPlaybackTest\sample4.mid");
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.cmdStart = new System.Windows.Forms.Button();
            this.cmdStop = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cmdStart
            // 
            this.cmdStart.Location = new System.Drawing.Point(24, 16);
            this.cmdStart.Name = "cmdStart";
            this.cmdStart.TabIndex = 0;
            this.cmdStart.Text = "Start";
            this.cmdStart.Click += new System.EventHandler(this.cmdStart_Click);
            // 
            // cmdStop
            // 
            this.cmdStop.Location = new System.Drawing.Point(112, 16);
            this.cmdStop.Name = "cmdStop";
            this.cmdStop.TabIndex = 1;
            this.cmdStop.Text = "Stop";
            this.cmdStop.Click += new System.EventHandler(this.cmdStop_Click);
            // 
            // Form1
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(208, 54);
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                          this.cmdStop,
                                                                          this.cmdStart});
            this.Name = "Form1";
            this.Text = "MIDI Playback";
            this.ResumeLayout(false);

        }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

        private void cmdStart_Click(object sender, System.EventArgs e)
        {
            player.Start();
        }

        private void cmdStop_Click(object sender, System.EventArgs e)
        {
            player.Stop();
        }
    }
}
