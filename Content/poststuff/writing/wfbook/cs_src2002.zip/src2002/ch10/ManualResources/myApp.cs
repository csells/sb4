using System;
using System.Windows.Forms;
using System.Drawing;

namespace ResourcesApp {
  class Form1 : Form {
    public Form1() {
      // Load the bitmap from a resource
      this.BackgroundImage = new Bitmap(this.GetType(), "Azul.jpg");
    }
  }

  class App {
    static void Main() {
      Application.Run(new Form1());
    }
  }
}
