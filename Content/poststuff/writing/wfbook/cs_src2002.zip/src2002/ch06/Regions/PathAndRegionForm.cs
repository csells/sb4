using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Regions {
  /// <summary>
  /// Summary description for Form1.
  /// </summary>
  public class PathAndRegionForm : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public PathAndRegionForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
      this.SetStyle(ControlStyles.ResizeRedraw, true);
      this.SetStyle(ControlStyles.DoubleBuffer, true);
      this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      // 
      // PathAndRegionForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(12, 28);
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Name = "PathAndRegionForm";
      this.Text = "Path vs. Region";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);

    }
		#endregion

    void Form1_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Center;
      RectangleF rect = new RectangleF(0, 0, this.ClientSize.Width/2f, this.ClientSize.Height);

      using( GraphicsPath path = new GraphicsPath() ) {
        path.AddEllipse(rect);
        path.Flatten(new Matrix(), 13f);
        path.AddString("Flattened Ellipse", this.Font.FontFamily, (int)this.Font.Style, this.Font.GetHeight(g), rect, format);
        g.FillPath(Brushes.Green, path);
        g.DrawPath(Pens.Black, path);
        g.TranslateTransform(rect.Width, 0);

        using( Region region = new Region(path) ) {
          g.FillRegion(Brushes.Red, region);
        }
      }

    }

  }
}












