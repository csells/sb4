using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Transforms {
  /// <summary>
  /// Summary description for PathTranslationForm.
  /// </summary>
  public class PathTranslationForm : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public PathTranslationForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      // 
      // PathTranslationForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(13, 31);
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Name = "PathTranslationForm";
      this.Text = "Path Translation";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.PathTranslationForm_Paint);

    }
		#endregion

    GraphicsPath CreateLabeledRectPath(string label) {
      GraphicsPath path = new GraphicsPath();
      RectangleF rect = new RectangleF(0, 0, 125, 125);
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Center;
      path.AddRectangle(rect);
      path.AddString(label, this.Font.FontFamily, (int)this.Font.Style, this.Font.Height, rect, format);
      return path;
    }

    void PathTranslationForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      using( GraphicsPath path = CreateLabeledRectPath("My Path") ) {

        // Draw at (0, 0)
        g.DrawPath(Pens.Black, path);

        // Translate all points in path by (150, 150)
        Matrix matrix = new Matrix();
        matrix.Translate(150, 150);
        path.Transform(matrix);
        g.DrawPath(Pens.Black, path);
      }
    }

  }
}
