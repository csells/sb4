using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Transforms {
  /// <summary>
  /// Summary description for PathFlattenForm.
  /// </summary>
  public class PathFlattenForm : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public PathFlattenForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      // 
      // PathFlattenForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(10, 25);
      this.BackColor = System.Drawing.Color.White;
      this.ClientSize = new System.Drawing.Size(416, 126);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Name = "PathFlattenForm";
      this.Text = "Path Transforms";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.PathFlattenForm_Paint);

    }
		#endregion

    private void PathFlattenForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e) {
      Graphics g = e.Graphics;
      float width = this.ClientSize.Width/4f;
      float height = this.ClientSize.Height;
      RectangleF rect = new RectangleF(0, 0, width, height);
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Center;

      using( GraphicsPath path = new GraphicsPath() ) {
        // Reset
        path.Reset();
        path.AddEllipse(rect);

        // Draw normal
        g.DrawPath(Pens.Black, path);
        g.DrawString("Ellipse", this.Font, Brushes.Black, rect, format);
        g.TranslateTransform(width, 0);

        // Draw flattened
        path.Flatten(new Matrix(), 10);
        g.DrawPath(Pens.Black, path);
        g.DrawString("Flattened", this.Font, Brushes.Black, rect, format);
        g.TranslateTransform(width, 0);

        // Reset
        path.Reset();
        path.AddEllipse(rect);

        // Draw widened
        using( Pen widenPen = new Pen(Color.Empty /* ignored */, 10) ) {
          path.Widen(widenPen);
          g.DrawPath(Pens.Black, path);
          g.DrawString("Widened", this.Font, Brushes.Black, rect, format);
          g.TranslateTransform(width, 0);
        }

        // Reset
        path.Reset();
        path.AddEllipse(rect);

        // Draw warped
        PointF[] destPoints = new PointF[3];
        destPoints[0] = new PointF(width/2, 0);
        destPoints[1] = new PointF(width, height);
        destPoints[2] = new PointF(0, height/2);
        RectangleF srcRect = new RectangleF(0, 0, width, height/2);
        path.Warp(destPoints, srcRect);
        g.DrawPath(Pens.Black, path);
        g.DrawString("Warped", this.Font, Brushes.Black, rect, format);
        g.TranslateTransform(width, 0);
      }
    }

  }
}














