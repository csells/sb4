using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Applications {
  /// <summary>
  /// Summary description for MainForm.
  /// </summary>
  public class MainForm : System.Windows.Forms.Form {
    private System.Windows.Forms.Button button1;
    private System.Windows.Forms.Button button2;
    private System.Windows.Forms.Button button3;
    private System.Windows.Forms.Button button4;

    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public MainForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.button1 = new System.Windows.Forms.Button();
      this.button2 = new System.Windows.Forms.Button();
      this.button3 = new System.Windows.Forms.Button();
      this.button4 = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // button1
      // 
      this.button1.Location = new System.Drawing.Point(24, 16);
      this.button1.Name = "button1";
      this.button1.Size = new System.Drawing.Size(144, 23);
      this.button1.TabIndex = 0;
      this.button1.Text = "Application.Exit";
      this.button1.Click += new System.EventHandler(this.button1_Click);
      // 
      // button2
      // 
      this.button2.Location = new System.Drawing.Point(24, 53);
      this.button2.Name = "button2";
      this.button2.Size = new System.Drawing.Size(144, 23);
      this.button2.TabIndex = 1;
      this.button2.Text = "Application.ExitThread";
      this.button2.Click += new System.EventHandler(this.button2_Click);
      // 
      // button3
      // 
      this.button3.Location = new System.Drawing.Point(24, 90);
      this.button3.Name = "button3";
      this.button3.Size = new System.Drawing.Size(144, 23);
      this.button3.TabIndex = 2;
      this.button3.Text = "Throw Exception";
      this.button3.Click += new System.EventHandler(this.button3_Click);
      // 
      // button4
      // 
      this.button4.Location = new System.Drawing.Point(24, 127);
      this.button4.Name = "button4";
      this.button4.Size = new System.Drawing.Size(144, 23);
      this.button4.TabIndex = 3;
      this.button4.Text = "Show MessageBox";
      this.button4.Click += new System.EventHandler(this.button4_Click);
      // 
      // MainForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(192, 166);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.button4,
                                                                  this.button3,
                                                                  this.button2,
                                                                  this.button1});
      this.Name = "MainForm";
      this.Text = "Applications";
      this.Closed += new System.EventHandler(this.MainForm_Closed);
      this.ResumeLayout(false);

    }
		#endregion

    static void App_Exit(object sender, EventArgs e) {
      System.Diagnostics.Debug.WriteLine("App_Exit");
    }

    static void App_Idle(object sender, EventArgs e) {
      System.Diagnostics.Debug.WriteLine("App_Idle");
    }

static void App_ThreadException(
  object sender, System.Threading.ThreadExceptionEventArgs e) {

  System.Diagnostics.Debug.WriteLine("App_ThreadException");
  string msg =
    "A problem has occurred in this application:\r\n\r\n" +
    "\t" + e.Exception.Message + "\r\n\r\n" +
    "Would you like to continue the application so that\r\n" +
    "you can save your work?";
  DialogResult res =
    MessageBox.Show(msg, "Unexpected Error", MessageBoxButtons.YesNo);
  if( res == DialogResult.Yes ) return;

  // Shut 'er down, Clancy, she's a pumpin' mud!
  Application.Exit();
}

    static void DumpThreadID(string name) {
      System.Diagnostics.Debug.WriteLine(name + " thread id= " + System.AppDomain.GetCurrentThreadId().ToString());
    }

    static void DummyThreadStart() {
      DumpThreadID("Dummy Thread");
      Application.ThreadExit += new EventHandler(App_ThreadExit);
    }

    static void App_ThreadExit(object sender, EventArgs e) {
      System.Diagnostics.Debug.WriteLine("App_ThreadExit on thread id= " + System.AppDomain.GetCurrentThreadId().ToString());
    }

#region Custom Contexts
    class MyTimedContext : ApplicationContext {
      Timer timer = new Timer();

      public MyTimedContext(Form form) : base(form) {
        timer.Tick += new EventHandler(TimesUp);
        timer.Interval = 5000; // 5 minutes
        timer.Enabled = true;
      }

      void TimesUp(object sender, EventArgs e) {
        timer.Enabled = false;
        timer.Dispose();

        DialogResult res =
          MessageBox.Show(
          "OK to charge your credit card?",
          "Time's Up!",
          MessageBoxButtons.YesNo);
        if( res == DialogResult.No ) {
          // See ya...
          base.MainForm.Close();
        }
      }

    }

    class RemotingServerContext : ApplicationContext {
      public RemotingServerContext(Form form) : base(form) {
      }

      protected override void OnMainFormClosed(object sender, EventArgs e) {
        // Don't let base class exit application
        if( ServicingRemotingClient() ) return;

        // Let base class exit application
        base.OnMainFormClosed(sender, e);
      }

      protected bool ServicingRemotingClient() {
        return true;
      }
    }
#endregion

    [STAThreadAttribute]
    static void Main() {
      Application.ThreadException += new System.Threading.ThreadExceptionEventHandler(App_ThreadException);
      Application.Idle += new EventHandler(App_Idle);
      Application.ThreadExit += new EventHandler(App_ThreadExit);
      Application.ApplicationExit += new EventHandler(App_Exit);

      DumpThreadID("UI Thread");
      System.Threading.Thread dummyThread = new System.Threading.Thread(new System.Threading.ThreadStart(DummyThreadStart));
      dummyThread.Start();

      // Run the application
      Application.Run(new MainForm());
      //      ApplicationContext ctx = new RemotingServerContext(new MainForm());
      //      Application.Run(ctx);
    }

    void button1_Click(object sender, EventArgs e) {
      System.Diagnostics.Debug.WriteLine("Calling Application.Exit()");
      Application.Exit();
    }

    void MainForm_Closed(object sender, EventArgs e) {
      System.Diagnostics.Debug.WriteLine("MainForm Closing");
    }

    private void button2_Click(object sender, System.EventArgs e) {
      System.Diagnostics.Debug.WriteLine("Calling Application.ExitThread()");
      Application.ExitThread();
    }

    private void button3_Click(object sender, System.EventArgs e) {
      System.Diagnostics.Debug.WriteLine("Throwing an exception");
      throw new System.IO.FileLoadException();
    }

    private void button4_Click(object sender, System.EventArgs e) {
      MessageBox.Show("Hi");
    }

  }

}














