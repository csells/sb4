using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace EnvironmentTest {
  /// <summary>
  /// Summary description for AboutBox.
  /// </summary>
  public class AboutBox : System.Windows.Forms.Form {
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.TextBox companyNameTextBox;
    private System.Windows.Forms.TextBox productNameTextBox;
    private System.Windows.Forms.TextBox productVersionTextBox;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.TextBox executablePathTextBox;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.TextBox startupPathTextBox;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public AboutBox() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.label1 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.label3 = new System.Windows.Forms.Label();
      this.companyNameTextBox = new System.Windows.Forms.TextBox();
      this.productNameTextBox = new System.Windows.Forms.TextBox();
      this.productVersionTextBox = new System.Windows.Forms.TextBox();
      this.label4 = new System.Windows.Forms.Label();
      this.executablePathTextBox = new System.Windows.Forms.TextBox();
      this.label5 = new System.Windows.Forms.Label();
      this.startupPathTextBox = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(16, 16);
      this.label1.Name = "label1";
      this.label1.TabIndex = 0;
      this.label1.Text = "Company Name";
      this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // label2
      // 
      this.label2.Location = new System.Drawing.Point(16, 40);
      this.label2.Name = "label2";
      this.label2.TabIndex = 0;
      this.label2.Text = "Product Name";
      this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // label3
      // 
      this.label3.Location = new System.Drawing.Point(16, 64);
      this.label3.Name = "label3";
      this.label3.TabIndex = 0;
      this.label3.Text = "Product Version";
      this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // companyNameTextBox
      // 
      this.companyNameTextBox.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.companyNameTextBox.Location = new System.Drawing.Point(120, 16);
      this.companyNameTextBox.Name = "companyNameTextBox";
      this.companyNameTextBox.Size = new System.Drawing.Size(308, 20);
      this.companyNameTextBox.TabIndex = 1;
      this.companyNameTextBox.Text = "textBox1";
      // 
      // productNameTextBox
      // 
      this.productNameTextBox.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.productNameTextBox.Location = new System.Drawing.Point(120, 40);
      this.productNameTextBox.Name = "productNameTextBox";
      this.productNameTextBox.Size = new System.Drawing.Size(308, 20);
      this.productNameTextBox.TabIndex = 1;
      this.productNameTextBox.Text = "textBox1";
      // 
      // productVersionTextBox
      // 
      this.productVersionTextBox.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.productVersionTextBox.Location = new System.Drawing.Point(120, 64);
      this.productVersionTextBox.Name = "productVersionTextBox";
      this.productVersionTextBox.Size = new System.Drawing.Size(308, 20);
      this.productVersionTextBox.TabIndex = 1;
      this.productVersionTextBox.Text = "textBox1";
      // 
      // label4
      // 
      this.label4.Location = new System.Drawing.Point(16, 88);
      this.label4.Name = "label4";
      this.label4.TabIndex = 0;
      this.label4.Text = "Executable Path";
      this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // executablePathTextBox
      // 
      this.executablePathTextBox.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.executablePathTextBox.Location = new System.Drawing.Point(120, 88);
      this.executablePathTextBox.Name = "executablePathTextBox";
      this.executablePathTextBox.Size = new System.Drawing.Size(308, 20);
      this.executablePathTextBox.TabIndex = 1;
      this.executablePathTextBox.Text = "textBox1";
      // 
      // label5
      // 
      this.label5.Location = new System.Drawing.Point(16, 112);
      this.label5.Name = "label5";
      this.label5.TabIndex = 0;
      this.label5.Text = "Startup Path";
      this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // startupPathTextBox
      // 
      this.startupPathTextBox.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.startupPathTextBox.Location = new System.Drawing.Point(120, 112);
      this.startupPathTextBox.Name = "startupPathTextBox";
      this.startupPathTextBox.Size = new System.Drawing.Size(308, 20);
      this.startupPathTextBox.TabIndex = 1;
      this.startupPathTextBox.Text = "textBox1";
      // 
      // AboutBox
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(448, 150);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.companyNameTextBox,
                                                                  this.label1,
                                                                  this.label2,
                                                                  this.label3,
                                                                  this.productNameTextBox,
                                                                  this.productVersionTextBox,
                                                                  this.label4,
                                                                  this.executablePathTextBox,
                                                                  this.label5,
                                                                  this.startupPathTextBox});
      this.Name = "AboutBox";
      this.Text = "About Box";
      this.Load += new System.EventHandler(this.AboutBox_Load);
      this.ResumeLayout(false);

    }
		#endregion

    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main(string[] args) {
      bool flag = false;
      string name = "";
      int number = 0;

      for( int i = 0; i != args.Length; ++i ) {
        switch( args[i] ) {
          case "/flag": flag = true; break;
          case "/name": name = args[++i]; break;
          case "/number": number = int.Parse(args[++i]); break;
          default: MessageBox.Show("invalid args!"); return;
        }
      }

      MessageBox.Show(flag.ToString(), "flag");
      MessageBox.Show(name, "name");
      MessageBox.Show(number.ToString(), "number");

      Application.Run(new AboutBox());
    }

    void AboutBox_Load(object sender, EventArgs e) {
      this.companyNameTextBox.Text = Application.CompanyName;
      this.productNameTextBox.Text = Application.ProductName;
      this.productVersionTextBox.Text = Application.ProductVersion;
      this.executablePathTextBox.Text = Application.ExecutablePath;
      this.startupPathTextBox.Text = Application.StartupPath;
    }
  }
}
