// InitialInstanceActivator.cs
// Inspired by Mike Woodring
// Copyright (c) 2003, Chris Sells
// Notes:
// -Uses Application.UserAppDataPath to pick a unique string composed
//  of the app name, the app version and the user name. This
//  gets us a unique mutex name, channel name and port number for each
//  user running each app of a specific version.
// Usage:
/*
TODO: Reference the System.Runtime.Remoting assembly
using SellsBrothers;
...
static void Main(string[] args) {
  // Check for initial instance, registering callback to consume args from other instances
  // Main form will be activated automatically
  OtherInstanceCallback callback = new OtherInstanceCallback(OnOtherInstance);
  if( InitialInstanceActivator.Activate(mainForm, callback, args) ) return;
  
  // Check for initial instance w/o registering a callback
  // Main form will still be activated automatically
  if( InitialInstanceActivator.Activate(mainForm) ) return;

  // Check for initial instance, registering callback to consume args from other instances
  // Main form from ApplicationContext will be activated automatically
  OtherInstanceCallback callback = new OtherInstanceCallback(OnOtherInstance);
  if( InitialInstanceActivator.Activate(context, callback, args) ) return;

  TODO: Run application
}

// Called from other instances
static void OnOtherInstance(string[] args) {
  TODO: Handle args from other instance
}
*/

using System;
using System.Windows.Forms;
using System.Threading;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Lifetime;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;

namespace SellsBrothers {
  // Signature of method to call when another instance is detected
  public delegate void OtherInstanceCallback(string[] args);

  public class InitialInstanceActivator {
    public static int Port {
      get {
        // Pick a port based on an application-specific string
        // that also falls into an exceptable range
        return Math.Abs(ChannelName.GetHashCode()/2)%(short.MaxValue - 1024) + 1024;
      }
    }

    public static string ChannelName {
      get {
        return Application.UserAppDataPath.ToLower().Replace(@"\", "_");
      }
    }

    public static string MutexName {
      get {
        return ChannelName;
      }
    }

    public static bool Activate(Form mainForm) {
      return Activate(new ApplicationContext(mainForm), null, null);
    }

    public static bool Activate(Form mainForm, OtherInstanceCallback callback, string[] args) {
      return Activate(new ApplicationContext(mainForm), callback, args);
    }

    public static bool Activate(ApplicationContext context, OtherInstanceCallback callback, string[] args) {
      // Check for existing instance
      bool firstInstance = false;
      Mutex mutex = new Mutex(true, MutexName, out firstInstance);

      if( !firstInstance ) {
        // Open remoting channel exposed from initial instance
        string url = string.Format("tcp://localhost:{0}/{1}", Port, ChannelName);
        MainFormActivator activator = (MainFormActivator)RemotingServices.Connect(typeof(MainFormActivator), url);

        // Send arguments to initial instance and exit this one
        activator.OnOtherInstance(args);
        return true;
      }

      // Expose remoting channel to accept arguments from other instances
      ChannelServices.RegisterChannel(new TcpChannel(Port));
      RemotingServices.Marshal(new MainFormActivator(context, callback), ChannelName);
      return false;
    }

    public class MainFormActivator : MarshalByRefObject {
      public MainFormActivator(ApplicationContext context, OtherInstanceCallback callback) {
        this.context = context;
        this.callback = callback;
      }

      public override object InitializeLifetimeService() {
        // We want an infinite lifetime as far as the
        // remoting infrastructure is concerned
        // (Thanks for Mike Woodring for pointing this out)
        ILease lease = (ILease)base.InitializeLifetimeService();
        lease.InitialLeaseTime = TimeSpan.Zero;
        return(lease);
      }

      public void OnOtherInstance(string[] args) {
        // Transition to the UI thread
        if( this.context.MainForm.InvokeRequired ) {
          OtherInstanceCallback callback = new OtherInstanceCallback(OnOtherInstance);
          this.context.MainForm.Invoke(callback, new object[] { args });
          return;
        }

        // Let the UI thread know about the other instance
        if( this.callback != null ) this.callback(args);

        // Activate the main form
        context.MainForm.Activate();
      }

      ApplicationContext context;
      OtherInstanceCallback callback;
    }
  }
}
