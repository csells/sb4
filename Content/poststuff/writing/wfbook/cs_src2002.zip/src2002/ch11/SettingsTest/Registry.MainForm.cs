using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Configuration;
using System.Collections.Specialized;
using Microsoft.Win32;

namespace SettingsTest.Registry {
  /// <summary>
  /// Summary description for MainForm.
  /// </summary>
  public class MainForm : System.Windows.Forms.Form {
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.TextBox piTextBox;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public MainForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      System.Configuration.AppSettingsReader configurationAppSettings = new System.Configuration.AppSettingsReader();
      this.label1 = new System.Windows.Forms.Label();
      this.piTextBox = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(8, 16);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(64, 23);
      this.label1.TabIndex = 0;
      this.label1.Text = "Today\'s pi";
      // 
      // piTextBox
      // 
      this.piTextBox.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.piTextBox.Location = new System.Drawing.Point(80, 16);
      this.piTextBox.Name = "piTextBox";
      this.piTextBox.Size = new System.Drawing.Size(200, 20);
      this.piTextBox.TabIndex = 1;
      this.piTextBox.Text = "";
      // 
      // MainForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 54);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.piTextBox,
                                                                  this.label1});
      this.Name = "MainForm";
      this.Opacity = ((System.Double)(configurationAppSettings.GetValue("MainForm.Opacity", typeof(System.Double))));
      this.Text = "Settings Test";
      this.Closing += new System.ComponentModel.CancelEventHandler(this.MainForm_Closing);
      this.Load += new System.EventHandler(this.MainForm_Load);
      this.ResumeLayout(false);

    }
		#endregion

    void MainForm_Closing(object sender, CancelEventArgs e) {
      // Save the form's position before it closes
      using( RegistryKey key = Application.UserAppDataRegistry ) {
        // Restore the window state to save location and
        // client size at restored state
        FormWindowState state = this.WindowState;
        this.WindowState = FormWindowState.Normal;
  
        key.SetValue("MainForm.Location", ToString(this.Location));
        key.SetValue("MainForm.ClientSize", ToString(this.ClientSize));
        key.SetValue("MainForm.WindowState", ToString(state));
      }
    }

    // Convert an object to a string
    string ToString(object obj) {
      TypeConverter converter = TypeDescriptor.GetConverter(obj.GetType());
      return converter.ConvertToString(obj);
    }

    void MainForm_Load(object sender, EventArgs e) {
      AppSettingsReader reader = new AppSettingsReader();
      Decimal pi = (Decimal)reader.GetValue("pi", typeof(Decimal));
      piTextBox.Text = pi.ToString();
  
      // Restore the form's position
      using( RegistryKey key = Application.UserAppDataRegistry ) {
        try {
          // Don't let the form's position be set automatically
          this.StartPosition = FormStartPosition.Manual;
  
          this.Location =
            (Point)FromString(
            key.GetValue("MainForm.Location"),
            typeof(Point));
          this.ClientSize =
            (Size)FromString(
            key.GetValue("MainForm.ClientSize"),
            typeof(Size));
          this.WindowState =
            (FormWindowState)FromString(
            key.GetValue("MainForm.WindowState", "Minimized"),
            typeof(FormWindowState));
        }
          // Don't let missing settings scare the user
        catch( Exception ex ) {
          MessageBox.Show(ex.Message, ex.GetType().Name);
        }
      }
    }

    // Convert a string to an object
    object FromString(object obj, Type type) {
      TypeConverter converter = TypeDescriptor.GetConverter(type);
      return converter.ConvertFromString(obj.ToString());
    }


  }
}












