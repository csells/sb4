using System.Windows.Forms;

namespace SettingsTest {
  class App {
    static void Main() {
      // Parse the value manually
      //      NameValueCollection settings = ConfigurationSettings.AppSettings;
      //      Decimal pi1 = Decimal.Parse(settings["pi"]);
      //      MessageBox.Show(pi1.ToString());
      //
      //      // Let AppSettingsReader parse the value
      //      AppSettingsReader reader = new AppSettingsReader();
      //      Decimal pi2 = (Decimal)reader.GetValue("pi", typeof(Decimal));
      //      MessageBox.Show(pi2.ToString());

      //Application.Run(new SettingsTest.Registry.MainForm());
      //Application.Run(new SettingsTest.SpecialFolders.MainForm());
      Application.Run(new SettingsTest.IsolatedStorage.MainForm());
    }
  }
}
