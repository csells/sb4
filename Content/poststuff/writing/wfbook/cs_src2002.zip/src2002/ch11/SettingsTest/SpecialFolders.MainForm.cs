using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Configuration;
using System.Collections.Specialized;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Soap;

namespace SettingsTest.SpecialFolders {
  /// <summary>
  /// Summary description for MainForm.
  /// </summary>
  public class MainForm : System.Windows.Forms.Form {
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.TextBox piTextBox;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public MainForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      System.Configuration.AppSettingsReader configurationAppSettings = new System.Configuration.AppSettingsReader();
      this.label1 = new System.Windows.Forms.Label();
      this.piTextBox = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(8, 16);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(64, 23);
      this.label1.TabIndex = 0;
      this.label1.Text = "Today\'s pi";
      // 
      // piTextBox
      // 
      this.piTextBox.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.piTextBox.Location = new System.Drawing.Point(80, 16);
      this.piTextBox.Name = "piTextBox";
      this.piTextBox.Size = new System.Drawing.Size(200, 20);
      this.piTextBox.TabIndex = 1;
      this.piTextBox.Text = "";
      // 
      // MainForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 54);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.piTextBox,
                                                                  this.label1});
      this.Name = "MainForm";
      this.Opacity = ((System.Double)(configurationAppSettings.GetValue("MainForm.Opacity", typeof(System.Double))));
      this.Text = "Settings Test";
      this.Closing += new System.ComponentModel.CancelEventHandler(this.MainForm_Closing);
      this.Load += new System.EventHandler(this.MainForm_Load);
      this.ResumeLayout(false);

    }
		#endregion

    // Custom type to manage serializable form data
    [SerializableAttribute]
      class FormData {
      public Point Location;
      public Size ClientSize;
      public FormWindowState WindowState;

      public FormData(Form form) {
        this.Location = form.Location;
        this.ClientSize = form.ClientSize;
        this.WindowState = form.WindowState;
      }
    }

    void MainForm_Closing(object sender, CancelEventArgs e) {
      // Save the form's position before it closes
      string fileName =
        Application.LocalUserAppDataPath + @"\MainForm.txt";
      System.Diagnostics.Debug.WriteLine(fileName);
      using( Stream stream =
               new FileStream(fileName, FileMode.Create) ) {
        // Restore the window state to save location and
        // client size at restored state
        FormWindowState state = this.WindowState;
        this.WindowState = FormWindowState.Normal;

        // Serialize custom FormData object
        IFormatter formatter = new SoapFormatter();
        formatter.Serialize(stream, new FormData(this));
      }
    }

    void MainForm_Load(object sender, EventArgs e) {
      AppSettingsReader reader = new AppSettingsReader();
      Decimal pi = (Decimal)reader.GetValue("pi", typeof(Decimal));
      piTextBox.Text = pi.ToString();

      // Restore the form's position
      try {
        string fileName =
          Application.LocalUserAppDataPath + @"\MainForm.txt";
        using( Stream stream =
                 new FileStream(fileName, FileMode.Open) ) {
          // Don't let the form's position be set automatically
          this.StartPosition = FormStartPosition.Manual;

          // Deserialize custom FormData object
          IFormatter formatter = new SoapFormatter();
          FormData data = (FormData)formatter.Deserialize(stream);

          // Set data from FormData object
          this.Location = data.Location;
          this.ClientSize = data.ClientSize;
          this.WindowState = data.WindowState;
        }
      }
        // Don't let missing settings scare the user
      catch( Exception ex ) {
        MessageBox.Show(ex.Message, ex.GetType().Name);
      }
    }

  }
}












