using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Shapes {
  /// <summary>
  /// Summary description for ClosedCurves.
  /// </summary>
  public class BeziersForm : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public BeziersForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      // 
      // BeziersForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(8, 19);
      this.BackColor = System.Drawing.Color.White;
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Name = "BeziersForm";
      this.Text = "Beziers";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.ClosedCurves_Paint);

    }
		#endregion

    private void ClosedCurves_Paint(object sender, System.Windows.Forms.PaintEventArgs e) {
      Graphics g = e.Graphics;
      int x = 0;
      int y = 0;
      int width = this.ClientRectangle.Width/3;
      int height = this.ClientRectangle.Height;
      Brush blackBrush = Brushes.Black;
      Brush fillBrush = Brushes.Gray;
      Pen whitePen = System.Drawing.Pens.White;
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Center;

      using( Pen pen = new Pen(Color.Red, 4) )
      using( Pen pointPen = new Pen(Color.Black, 3) ) {
        pointPen.StartCap = pointPen.EndCap = LineCap.SquareAnchor;

        Point[] points = null;

        points = new Point[] { new Point(x + 25, y + height - 25), new Point(x + width - 25, y + height - 25), new Point(x + 25, y + 25), new Point(x + width - 25, y + 25), };
        g.DrawRectangle(Pens.Black, x, y, width, height);
        g.DrawBeziers(pen, points);
        foreach( Point point in points ) g.DrawLine(pointPen, new Point(point.X, point.Y), new Point(point.X + 1, point.Y));
        for( int i = 0; i != points.Length; ++i ) g.DrawString(i.ToString(), this.Font, blackBrush, points[i]);
        x = (x > this.ClientRectangle.Width - 2*width ? 0 : x + width);
        y = (x == 0 ? y + height : y);

        points = new Point[] { new Point(x + 25, y + 25), new Point(x + width - 25, y + 25), new Point(x + width - 25, y + height - 25), new Point(x + 25, y + height - 25), };
        g.DrawRectangle(Pens.Black, x, y, width, height);
        g.DrawBeziers(pen, points);
        foreach( Point point in points ) g.DrawLine(pointPen, new Point(point.X, point.Y), new Point(point.X + 1, point.Y));
        for( int i = 0; i != points.Length; ++i ) g.DrawString(i.ToString(), this.Font, blackBrush, points[i]);
        x = (x > this.ClientRectangle.Width - 2*width ? 0 : x + width);
        y = (x == 0 ? y + height : y);

        points = new Point[] { new Point(x + 25, y + 25), new Point(x + width - 25, y + 25), new Point(x + 25, y + height - 25), new Point(x + width - 25, y + height - 25), };
        g.DrawRectangle(Pens.Black, x, y, width, height);
        g.DrawBeziers(pen, points);
        foreach( Point point in points ) g.DrawLine(pointPen, new Point(point.X, point.Y), new Point(point.X + 1, point.Y));
        for( int i = 0; i != points.Length; ++i ) g.DrawString(i.ToString(), this.Font, blackBrush, points[i]);
        x = (x > this.ClientRectangle.Width - 2*width ? 0 : x + width);
        y = (x == 0 ? y + height : y);
      }

    }
  }
}
