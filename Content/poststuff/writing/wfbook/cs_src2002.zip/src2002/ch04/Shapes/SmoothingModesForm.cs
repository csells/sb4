using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Shapes {
  /// <summary>
  /// Summary description for Form1.
  /// </summary>
  public class SmoothingModesForm : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public SmoothingModesForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
      this.SetStyle(ControlStyles.ResizeRedraw, true);
      this.SetStyle(ControlStyles.DoubleBuffer, true);
      this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      // 
      // SmoothingModesForm
      // 
      this.AutoScaleBaseSize = new Size(8, 19);
      this.BackColor = Color.White;
      this.ClientSize = new Size(448, 110);
      this.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, ((System.Byte)(0)));
      this.Name = "SmoothingModesForm";
      this.Text = "Smoothing Modes";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);

    }
		#endregion

    void Form1_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      int x = 0;
      int y = 0;
      int width = this.ClientRectangle.Width/2;
      int height = this.ClientRectangle.Height;
      Brush blackBrush = Brushes.Black;
      Brush fillBrush = Brushes.Gray;
      Pen whitePen = Pens.White;
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Center;

      using( Pen pen = new Pen(Color.Red, 4) ) {
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.DrawCurve(pen, new Point[] { new Point(x + 20, y + height - 20), new Point(x + width - 20, y + height - 20), new Point(x + 20, y + 20), new Point(x + width - 20, y + 20), }, 1.0f);
        g.DrawString(g.SmoothingMode.ToString(), this.Font, blackBrush, new Rectangle(x, y, width, height), format);
        x = (x > this.ClientRectangle.Width - 2*width ? 0 : x + width);
        y = (x == 0 ? y + height : y);

        g.SmoothingMode = SmoothingMode.None;
        g.DrawCurve(pen, new Point[] { new Point(x + 20, y + height - 20), new Point(x + width - 20, y + height - 20), new Point(x + 20, y + 20), new Point(x + width - 20, y + 20), }, 1.0f);
        g.DrawString(g.SmoothingMode.ToString(), this.Font, blackBrush, new Rectangle(x, y, width, height), format);
        x = (x > this.ClientRectangle.Width - 2*width ? 0 : x + width);
        y = (x == 0 ? y + height : y);

      }
      
    }
  }
}
