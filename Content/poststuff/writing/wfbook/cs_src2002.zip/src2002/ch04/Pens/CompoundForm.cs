using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Pens {
  /// <summary>
  /// Summary description for CompoundForm.
  /// </summary>
  public class CompoundForm : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public CompoundForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      // 
      // CompoundForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.BackColor = System.Drawing.Color.White;
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Name = "CompoundForm";
      this.Text = "Compound Array";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.CompoundForm_Paint);

    }
		#endregion

    private void CompoundForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e) {
      Graphics g = e.Graphics;
      using( Pen pen = new Pen(Color.Black, 20) ) {
        // Set percentages of width where line starts, then space starts,
        // then line starts again in alternating pattern
        pen.CompoundArray =
          new float[] { 0.0f, 0.25f, 0.45f, 0.55f, 0.75f, 1.0f, };
        g.DrawRectangle(pen, new Rectangle(20, 20, this.ClientRectangle.Width - 40, this.ClientRectangle.Height - 40));
      }

    }
  }
}
