using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Drawing {
  /// <summary>
  /// Summary description for Form1.
  /// </summary>
  public class DrawingForm : System.Windows.Forms.Form {
    private System.Windows.Forms.Button drawEllipseButton;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public DrawingForm() {
      // Required for Windows Form Designer support
      InitializeComponent();

      // constructor code after InitializeComponent call
      this.SetStyle(ControlStyles.ResizeRedraw, true);
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.drawEllipseButton = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // drawEllipseButton
      // 
      this.drawEllipseButton.Location = new Point(43, 32);
      this.drawEllipseButton.Name = "drawEllipseButton";
      this.drawEllipseButton.TabIndex = 0;
      this.drawEllipseButton.Text = "Draw Ellipse";
      this.drawEllipseButton.Click += new System.EventHandler(this.drawEllipseButton_Click);
      // 
      // Form1
      // 
      this.AutoScaleBaseSize = new Size(5, 13);
      this.ClientSize = new Size(160, 86);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.drawEllipseButton});
      this.Name = "Form1";
      this.Text = "Drawing";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.DrawingForm_Paint);
      this.ResumeLayout(false);

    }
		#endregion

    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main() {
      Application.Run(new DrawingForm());
    }

    bool drawEllipse = false;

    void drawEllipseButton_Click(object sender, EventArgs e) {
      // Toggle whether to draw the ellipse or not
      drawEllipse = !drawEllipse;

//      Graphics g = this.CreateGraphics();
//      try {
//        if( drawEllipse ) {
//          // Draw the ellipse
//          g.FillEllipse(Brushes.DarkBlue, this.ClientRectangle);
//        }
//        else {
//          // Erase the previously drawn ellipse
//          g.FillEllipse(SystemBrushes.Control, this.ClientRectangle);
//        }
//      }
//      finally {
//        g.Dispose();
//      }

      this.Invalidate(); // Ask Windows for a Paint event
      //      this.Update(); // Force the Paint event to happen now
      //this.Refresh(); // Invalidate + Update
    }

    void DrawingForm_Paint(object sender, PaintEventArgs e) {
      Color blue25PercentOpache = Color.FromArgb(255*1/4, 0, 0, 255);
      Color blue75PercentOpache = Color.FromArgb(-1090518785);
      Color white = Color.FromArgb(255, 255, 255);
      Color black = Color.FromArgb(0, 0, 0);
      Color blue1 = Color.BlueViolet;
      Color blue2 = Color.FromKnownColor(KnownColor.ActiveBorder);
      Color blue3 = Color.FromName("ActiveBorder");
      Color htmlBlue = ColorTranslator.FromHtml("#0000ff");
      //      string htmlBlueToo = ColorTranslator.ToHtml(htmlBlue);
      //      MessageBox.Show(htmlBlueToo);
      if( !drawEllipse ) return;
      Graphics g = e.Graphics;
      using( Brush brush = new SolidBrush(htmlBlue) ) {
        g.FillEllipse(brush, this.ClientRectangle);
      }
    }
  }
}













