using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Images {
  /// <summary>
  /// Summary description for AnimationForm.
  /// </summary>
  public class AnimationForm : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public AnimationForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.statusBar1 = new System.Windows.Forms.StatusBar();
      this.SuspendLayout();
      // 
      // statusBar1
      // 
      this.statusBar1.Location = new Point(0, 244);
      this.statusBar1.Name = "statusBar1";
      this.statusBar1.Size = new Size(292, 22);
      this.statusBar1.TabIndex = 0;
      this.statusBar1.Text = "statusBar1";
      // 
      // AnimationForm
      // 
      this.AutoScaleBaseSize = new Size(5, 13);
      this.ClientSize = new Size(292, 266);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.statusBar1});
      this.Name = "AnimationForm";
      this.Text = "Animation";
      this.Load += new System.EventHandler(this.AnimationForm_Load);
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.AnimationForm_Paint);
      this.ResumeLayout(false);

    }
		#endregion

    private System.Windows.Forms.StatusBar statusBar1;

    // Load animated GIF
    Bitmap gif = new Bitmap(typeof(AnimationForm), "SAMPLE_ANIMATION_COPY.GIF");

    void AnimationForm_Load(object sender, EventArgs e) {
      // Set client size to size of image
      this.SetClientSizeCore(gif.Width, gif.Height + statusBar1.Height);

      // Check if image supports animation
      if( ImageAnimator.CanAnimate(gif) ) {
        // Subscribe to an event indicating the next frame should be shown
        ImageAnimator.Animate(gif, new EventHandler(gif_FrameChanged));
      }

      statusBar1.Text = gif.GetFrameCount(FrameDimension.Time) + " frames";

    }

    void gif_FrameChanged(object sender, EventArgs e) {
      if( this.InvokeRequired ) {
        // Transition from worker thread to UI thread
        this.BeginInvoke(
          new EventHandler(gif_FrameChanged),
          new object[] { sender, e });
      }
      else {
        // Trigger Paint event to draw next frame
        this.Invalidate();
      }
    }

    void AnimationForm_Paint(object sender, PaintEventArgs e) {
      // Update image's current frame
      ImageAnimator.UpdateFrames(gif);

      // Draw image's active frame
      Graphics g = e.Graphics;
      Rectangle rect = this.ClientRectangle;
      rect.Height -= statusBar1.Height;
      g.DrawImage(gif, rect);

    }

  }
}









