using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Images {
  /// <summary>
  /// Summary description for PanningForm.
  /// </summary>
  public class PanningForm : System.Windows.Forms.Form {
    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.Button upButton;
    private System.Windows.Forms.Button downButton;
    private System.Windows.Forms.Button leftButton;
    private System.Windows.Forms.Button rightButton;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public PanningForm() {
      // Required for Windows Form Designer support
      InitializeComponent();

      // TODO: Add any constructor code after InitializeComponent call
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.panel1 = new System.Windows.Forms.Panel();
      this.upButton = new System.Windows.Forms.Button();
      this.downButton = new System.Windows.Forms.Button();
      this.leftButton = new System.Windows.Forms.Button();
      this.rightButton = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // panel1
      // 
      this.panel1.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.panel1.Location = new System.Drawing.Point(38, 41);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(216, 184);
      this.panel1.TabIndex = 0;
      this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
      // 
      // upButton
      // 
      this.upButton.Anchor = System.Windows.Forms.AnchorStyles.Top;
      this.upButton.Location = new System.Drawing.Point(134, 8);
      this.upButton.Name = "upButton";
      this.upButton.Size = new System.Drawing.Size(24, 23);
      this.upButton.TabIndex = 1;
      this.upButton.Text = "^";
      this.upButton.Click += new System.EventHandler(this.upButton_Click);
      // 
      // downButton
      // 
      this.downButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
      this.downButton.Location = new System.Drawing.Point(134, 232);
      this.downButton.Name = "downButton";
      this.downButton.Size = new System.Drawing.Size(24, 23);
      this.downButton.TabIndex = 1;
      this.downButton.Text = "v";
      this.downButton.Click += new System.EventHandler(this.downButton_Click);
      // 
      // leftButton
      // 
      this.leftButton.Anchor = System.Windows.Forms.AnchorStyles.Left;
      this.leftButton.Location = new System.Drawing.Point(8, 122);
      this.leftButton.Name = "leftButton";
      this.leftButton.Size = new System.Drawing.Size(24, 23);
      this.leftButton.TabIndex = 1;
      this.leftButton.Text = "<";
      this.leftButton.Click += new System.EventHandler(this.leftButton_Click);
      // 
      // rightButton
      // 
      this.rightButton.Anchor = System.Windows.Forms.AnchorStyles.Right;
      this.rightButton.Location = new System.Drawing.Point(264, 122);
      this.rightButton.Name = "rightButton";
      this.rightButton.Size = new System.Drawing.Size(24, 23);
      this.rightButton.TabIndex = 1;
      this.rightButton.Text = ">";
      this.rightButton.Click += new System.EventHandler(this.rightButton_Click);
      // 
      // PanningForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.upButton,
                                                                  this.panel1,
                                                                  this.downButton,
                                                                  this.leftButton,
                                                                  this.rightButton});
      this.Name = "PanningForm";
      this.Text = "Panning";
      this.ResumeLayout(false);

    }
		#endregion

    Bitmap bmp = new Bitmap(typeof(PanningForm), "Soap Bubbles.bmp");
    Size offset = new Size(0, 0);

    void panel1_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      Rectangle destRect = this.panel1.ClientRectangle;
      Rectangle srcRect = new Rectangle(offset.Width, offset.Height, destRect.Width, destRect.Height);
      g.DrawImage(bmp, destRect, srcRect, g.PageUnit);
            
    }

    private void upButton_Click(object sender, System.EventArgs e) {
      offset.Height += 10;
      panel1.Refresh();
    }

    private void rightButton_Click(object sender, System.EventArgs e) {
      offset.Width -= 10;
      panel1.Refresh();
    }

    private void downButton_Click(object sender, System.EventArgs e) {
      offset.Height -= 10;
      panel1.Refresh();
    }

    private void leftButton_Click(object sender, System.EventArgs e) {
      offset.Width += 10;
      panel1.Refresh();
    }
  }
}












