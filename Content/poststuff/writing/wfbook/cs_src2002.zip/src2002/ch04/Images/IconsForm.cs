using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Images {
  /// <summary>
  /// Summary description for IconsForm.
  /// </summary>
  public class IconsForm : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public IconsForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      // 
      // IconsForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.BackColor = System.Drawing.Color.White;
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Name = "IconsForm";
      this.Text = "IconsForm";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.IconsForm_Paint);

    }
		#endregion

    string GetIconName(Icon icon) {
      if( icon == SystemIcons.Application ) return "Application";
      if( icon == SystemIcons.Asterisk ) return "Asterisk";
      if( icon == SystemIcons.Error ) return "Error";
      if( icon == SystemIcons.Exclamation ) return "Exclamation";
      if( icon == SystemIcons.Hand ) return "Hand";
      if( icon == SystemIcons.Information ) return "Information";
      if( icon == SystemIcons.Question ) return "Question";
      if( icon == SystemIcons.Warning ) return "Warning";
      if( icon == SystemIcons.WinLogo ) return "WinLogo";
      
      return "<no name>";
    }

    void IconsForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      int x = 0;
      int y = 0;
      int width = this.ClientRectangle.Width/3;
      int height = this.ClientRectangle.Height/3;
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Far;

      Icon[] icons = new Icon[] { SystemIcons.Application,
                                  SystemIcons.Asterisk,
                                  SystemIcons.Error,
                                  SystemIcons.Exclamation,
                                  SystemIcons.Hand,
                                  SystemIcons.Information,
                                  SystemIcons.Question,
                                  SystemIcons.Warning,
                                  SystemIcons.WinLogo,
      };

      foreach( Icon icon in icons ) {
        Rectangle rect = new Rectangle(x, y, width, height);
        Rectangle iconRect = new Rectangle(x + (width - icon.Width)/2, y + (height - icon.Height)/2, icon.Width, icon.Height);
        g.DrawIconUnstretched(icon, iconRect);
        g.DrawString(GetIconName(icon), this.Font, Brushes.Black, rect, format);
        g.DrawRectangle(Pens.Black, rect);
        x = (x > this.ClientRectangle.Width - 2*width ? 0 : x + width);
        y = (x == 0 ? y + height : y);
      }
      
    }
  }
}
