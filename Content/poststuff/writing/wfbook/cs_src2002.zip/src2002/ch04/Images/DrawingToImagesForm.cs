using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Images {
  /// <summary>
  /// Summary description for DrawingToImagesForm.
  /// </summary>
  public class DrawingToImagesForm : System.Windows.Forms.Form {
    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.Button saveButton;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public DrawingToImagesForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.panel1 = new System.Windows.Forms.Panel();
      this.saveButton = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // panel1
      // 
      this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(292, 224);
      this.panel1.TabIndex = 0;
      this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
      // 
      // saveButton
      // 
      this.saveButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
      this.saveButton.Location = new System.Drawing.Point(104, 232);
      this.saveButton.Name = "saveButton";
      this.saveButton.TabIndex = 1;
      this.saveButton.Text = "Save";
      this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
      // 
      // DrawingToImagesForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.saveButton,
                                                                  this.panel1});
      this.Name = "DrawingToImagesForm";
      this.Text = "Drawing To Images";
      this.Load += new System.EventHandler(this.DrawingToImagesForm_Load);
      this.Layout += new System.Windows.Forms.LayoutEventHandler(this.DrawingToImagesForm_Layout);
      this.ResumeLayout(false);

    }
		#endregion

    int offset;

    void DrawingToImagesForm_Load(object sender, EventArgs e) {
      offset = this.ClientRectangle.Height - this.panel1.Height;
    }

    void DrawingToImagesForm_Layout(object sender, LayoutEventArgs e) {
      this.panel1.Height = this.ClientRectangle.Height - offset;
    }

    void panel1_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      Rectangle rect = this.panel1.ClientRectangle;

      // Create bitmap to draw into based on existing Graphics object
      using( Image image = new Bitmap(rect.Width, rect.Height, g) )
      // Wrap Graphics object around image to draw into
      using( Graphics imageGraphics = Graphics.FromImage(image) ) {
        imageGraphics.FillRectangle(Brushes.White, rect);
        StringFormat format = new StringFormat();
        format.Alignment = StringAlignment.Center;
        format.LineAlignment = StringAlignment.Center;
        imageGraphics.DrawString("Drawing to an image", panel1.Font, Brushes.Black, rect, format);

        // Draw created image to screen
        g.DrawImage(image, rect);
      }

    }

    void saveButton_Click(object sender, EventArgs e) {
      Rectangle rect = new Rectangle(0, 0, 100, 100);

      // Get current graphics object for display
      using( Graphics displayGraphics = this.CreateGraphics() )

      // Create bitmap to draw into based on existing Graphics object
      using( Image image =
               new Bitmap(rect.Width, rect.Height, displayGraphics) )

      // Wrap Graphics object around image to draw into
      using( Graphics imageGraphics = Graphics.FromImage(image) ) {

        imageGraphics.FillRectangle(Brushes.Black, rect);
        StringFormat format = new StringFormat();
        format.Alignment = StringAlignment.Center;
        format.LineAlignment = StringAlignment.Center;
        imageGraphics.DrawString("Drawing to an image", panel1.Font, Brushes.White, rect, format);

        // Save created image to a file
        string file = @"c:\image.png";
        image.Save(file);

        MessageBox.Show("Saved to file: " + file);
      }

    }


  }
}











