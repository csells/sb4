using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Diagnostics;

namespace Images
{
	/// <summary>
	/// Summary description for RotatingForm.
	/// </summary>
	public class RotatingForm : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public RotatingForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      // 
      // RotatingForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.BackColor = System.Drawing.Color.White;
      this.ClientSize = new System.Drawing.Size(352, 302);
      this.Name = "RotatingForm";
      this.Text = "Rotating & Flipping";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.RotatingForm_Paint);

    }
		#endregion

    void RotatingForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      string[] rotateFlipNames = Enum.GetNames(typeof(RotateFlipType));
      int x = 0;
      int y = 0;
      int width = this.ClientRectangle.Width/4;
      int height = this.ClientRectangle.Height/(rotateFlipNames.Length/4);
      Brush blackBrush = System.Drawing.Brushes.Black;
      Pen blackPen = Pens.Black;
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Far;

      Debug.Assert(rotateFlipNames.Length % 4 == 0);
      Array.Sort(rotateFlipNames);

      foreach( string rotateFlipName in rotateFlipNames ) {
        using( Bitmap bitmap = new Bitmap(this.GetType(), "BEANY.BMP") ) {
          RotateFlipType rotateFlip = (RotateFlipType)Enum.Parse(typeof(RotateFlipType), rotateFlipName);
          bitmap.RotateFlip(rotateFlip);
          Rectangle rect = new Rectangle(x, y, width, height);
          g.DrawImageUnscaled(bitmap, x, y);
          g.DrawRectangle(blackPen, rect);
          g.DrawString(rotateFlipName, this.Font, blackBrush, rect, format);
          x += width;
          if( x > this.ClientRectangle.Width - width ) {
            y += height;
            x = 0;
          }
        }
      }

    }
	}
}
