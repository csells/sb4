using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Brushes
{
	/// <summary>
	/// Summary description for TextureBrushesForm.
	/// </summary>
	public class TextureBrushesForm : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public TextureBrushesForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      // 
      // TextureBrushesForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Name = "TextureBrushesForm";
      this.Text = "Texture Brushes";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.TextureBrushesForm_Paint);

    }
		#endregion

    void TextureBrushesForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      int x = 0;
      int y = 0;
      int width = this.ClientRectangle.Width;
      int height = this.ClientRectangle.Height/6;
      Brush blackBrush = System.Drawing.Brushes.Black;
      Pen blackPen = Pens.Black;

      using( Bitmap bitmap = new Bitmap(this.GetType(), "BEANY.BMP") ) {
        using( TextureBrush brush =
                 new TextureBrush(bitmap, WrapMode.Clamp) ) {
          g.FillRectangle(brush, x, y, width, height);
          g.DrawRectangle(blackPen, x, y, width, height);
          g.DrawString(brush.WrapMode.ToString(), this.Font, blackBrush, x, y);
          y += height;
        }

        using( TextureBrush brush =
                 new TextureBrush(bitmap, WrapMode.Tile) ) {
          g.FillRectangle(brush, x, y, width, height);
          g.DrawRectangle(blackPen, x, y, width, height);
          g.DrawString(brush.WrapMode.ToString(), this.Font, blackBrush, x, y);
          y += height;
        }

        using( TextureBrush brush =
                 new TextureBrush(bitmap, WrapMode.TileFlipX) ) {
          g.FillRectangle(brush, x, y, width, height);
          g.DrawRectangle(blackPen, x, y, width, height);
          g.DrawString(brush.WrapMode.ToString(), this.Font, blackBrush, x, y);
          y += height;
        }

        using( TextureBrush brush =
                 new TextureBrush(bitmap, WrapMode.TileFlipY) ) {
          g.FillRectangle(brush, x, y, width, height);
          g.DrawRectangle(blackPen, x, y, width, height);
          g.DrawString(brush.WrapMode.ToString(), this.Font, blackBrush, x, y);
          y += height;
        }

        using( TextureBrush brush =
                 new TextureBrush(bitmap, WrapMode.TileFlipXY) ) {
          g.FillRectangle(brush, x, y, width, height * 2);
          g.DrawRectangle(blackPen, x, y, width, height * 2);
          g.DrawString(brush.WrapMode.ToString(), this.Font, blackBrush, x, y);
        }
      }

    }
	}
}
