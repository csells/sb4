using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Brushes {
  /// <summary>
  /// Summary description for LinearGradientBrushesForm.
  /// </summary>
  public class LinearGradientBrushesForm : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public LinearGradientBrushesForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      // 
      // LinearGradientBrushesForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Name = "LinearGradientBrushesForm";
      this.Text = "Linear Gradient Brushes";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.LinearGradientBrushesForm_Paint);

    }
		#endregion

    void LinearGradientBrushesForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      int x = 0;
      int y = 0;
      int width = this.ClientRectangle.Width;
      int height = this.ClientRectangle.Height/4;
      Brush blackBrush = System.Drawing.Brushes.Black;

      using(
        LinearGradientBrush brush =
          new LinearGradientBrush(
          this.ClientRectangle,
          Color.White,
          Color.Black,
          LinearGradientMode.Horizontal) ) {

        // Normal
        g.FillRectangle(brush, x, y, width, height);
        g.DrawString("Normal", this.Font, blackBrush, x, y);
        y += height;

        // Triangle
        brush.SetBlendTriangularShape(0.5f);
        g.FillRectangle(brush, x, y, width, height);
        g.DrawString("Triangle", this.Font, blackBrush, x, y);
        y += height;

        // Bell
        brush.SetSigmaBellShape(0.5f);
        g.FillRectangle(brush, x, y, width, height);
        g.DrawString("Bell", this.Font, blackBrush, x, y);
        y += height;

        // Custom colors
        ColorBlend blend = new ColorBlend();
        blend.Colors = new Color[] { Color.White, Color.Red, Color.Black, };
        blend.Positions = new float[] { 0.0f, 0.5f, 1.0f };
        brush.InterpolationColors = blend;
        g.FillRectangle(brush, x, y, width, height);
        g.DrawString("Custom Colors", this.Font, blackBrush, x, y);
        y += height;
      }

    }
  }
}
