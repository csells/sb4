using System;
using System.Windows.Forms;

namespace Components {
  public class App {
    [STAThread]
    static void Main() {
      //Application.Run(new TimerForm());
      Application.Run(new AlarmForm());
    }
  }
}
