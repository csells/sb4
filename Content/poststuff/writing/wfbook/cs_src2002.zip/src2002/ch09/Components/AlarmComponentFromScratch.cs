using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace MyComponents {
  internal class AlarmComponent : IComponent {
    Timer timer = new Timer();
    public AlarmComponent() {
       // Check once/second
      timer.Interval = 1000;
      timer.Enabled = true;
      timer.Tick += new EventHandler(timer_Tick);
    }

    public event EventHandler AlarmSounded;
    void timer_Tick(object sender, EventArgs e) {
      if( DateTime.Now < this.alarm ) return;

      timer.Enabled = false;
      if( AlarmSounded != null ) {
        AlarmSounded(this, EventArgs.Empty);
      }
    }

    DateTime alarm = DateTime.MaxValue;
    public DateTime Alarm {
      get { return this.alarm; }
      set { this.alarm = value; }
    }
  
    #region Implementation of IComponent
    public event System.EventHandler Disposed;
    ISite site = null;

    public ISite Site {
      get { return site; }
      set { site = value; }
    }
    #endregion

    #region Implementation of IDisposable
    // Called by client that remembers
    public void Dispose() {
      this.Dispose(true);

      // Excuse the GC from calling our finalizer
      System.GC.SuppressFinalize(this);
    }

    // Called (eventually) by GC when client forgets
    ~AlarmComponent() {
      this.Dispose(false);
    }

    // Centralized resource management
    protected void Dispose(bool disposing) {
      // Release managed resources
      if( disposing ) {
        timer.Dispose();
        timer = null;
      }

      // Release unmanaged resources
      // TODO

      // Let subscribers know
      if( Disposed != null ) Disposed(this, EventArgs.Empty);
    }
    #endregion
  }
}















