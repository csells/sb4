using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Components {
  /// <summary>
  /// Summary description for AlarmForm.
  /// </summary>
  public class AlarmForm : System.Windows.Forms.Form {
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.DateTimePicker dateTimePicker1;
    private System.Windows.Forms.Button setAlarmButton;
    private System.Windows.Forms.StatusBar statusBar1;
    private System.Windows.Forms.Timer timer1;
    private Components.AlarmComponent alarmComponent1;
    private System.ComponentModel.IContainer components;

    public AlarmForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

    #region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.components = new System.ComponentModel.Container();
      this.label1 = new System.Windows.Forms.Label();
      this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
      this.setAlarmButton = new System.Windows.Forms.Button();
      this.statusBar1 = new System.Windows.Forms.StatusBar();
      this.timer1 = new System.Windows.Forms.Timer(this.components);
      this.alarmComponent1 = new Components.AlarmComponent(this.components);
      this.SuspendLayout();
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(16, 16);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(40, 23);
      this.label1.TabIndex = 0;
      this.label1.Text = "When:";
      this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // dateTimePicker1
      // 
      this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Time;
      this.dateTimePicker1.Location = new System.Drawing.Point(64, 16);
      this.dateTimePicker1.Name = "dateTimePicker1";
      this.dateTimePicker1.Size = new System.Drawing.Size(96, 20);
      this.dateTimePicker1.TabIndex = 1;
      // 
      // setAlarmButton
      // 
      this.setAlarmButton.Location = new System.Drawing.Point(88, 48);
      this.setAlarmButton.Name = "setAlarmButton";
      this.setAlarmButton.TabIndex = 2;
      this.setAlarmButton.Text = "Set Alarm";
      this.setAlarmButton.Click += new System.EventHandler(this.setAlarmButton_Click);
      // 
      // statusBar1
      // 
      this.statusBar1.Location = new System.Drawing.Point(0, 96);
      this.statusBar1.Name = "statusBar1";
      this.statusBar1.Size = new System.Drawing.Size(176, 22);
      this.statusBar1.TabIndex = 3;
      // 
      // timer1
      // 
      this.timer1.Enabled = true;
      this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
      // 
      // alarmComponent1
      // 
      this.alarmComponent1.Alarm = new System.DateTime(9999, 12, 31, 23, 59, 59, 999);
      this.alarmComponent1.AlarmSounded += new System.EventHandler(this.alarmComponent1_AlarmSounded);
      // 
      // AlarmForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(176, 118);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.statusBar1,
                                                                  this.setAlarmButton,
                                                                  this.dateTimePicker1,
                                                                  this.label1});
      this.Name = "AlarmForm";
      this.Text = "Alarm Form";
      this.ResumeLayout(false);

    }
		#endregion

    void setAlarmButton_Click(object sender, EventArgs e) {
      alarmComponent1.Alarm = dateTimePicker1.Value;
    }

    private void timer1_Tick(object sender, EventArgs e) {
      statusBar1.Text = DateTime.Now.ToString();
    }

    void alarmComponent1_AlarmSounded(object sender, EventArgs e) {
      MessageBox.Show("Wake Up!");
    }

  }
}
