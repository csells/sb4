using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Drawing.Printing;

namespace Printing
{
	/// <summary>
	/// Summary description for CustomPrintPreviewDialog.
	/// </summary>
	public class CustomPrintPreviewDialog : System.Windows.Forms.Form
	{
    private System.Windows.Forms.PrintPreviewControl printPreviewControl1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public CustomPrintPreviewDialog()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.printPreviewControl1 = new System.Windows.Forms.PrintPreviewControl();
      this.SuspendLayout();
      // 
      // printPreviewControl1
      // 
      this.printPreviewControl1.Columns = 2;
      this.printPreviewControl1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.printPreviewControl1.Name = "printPreviewControl1";
      this.printPreviewControl1.Size = new System.Drawing.Size(432, 446);
      this.printPreviewControl1.TabIndex = 0;
      this.printPreviewControl1.Zoom = 0.1;
      // 
      // CustomPrintPreviewDialog
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(432, 446);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.printPreviewControl1});
      this.Name = "CustomPrintPreviewDialog";
      this.Text = "Preview Control";
      this.Load += new System.EventHandler(this.CustomPrintPreviewDialog_Load);
      this.ResumeLayout(false);

    }
		#endregion

    private void printPreviewControl1_Click(object sender, EventArgs e) {
      // click
      if( (Control.ModifierKeys & Keys.Shift) == 0 ) {
        printPreviewControl1.Zoom *= 2.0;
      }
      // shift+click
      else {
        printPreviewControl1.Zoom /= 2.0;
      }
    }

    private void CustomPrintPreviewDialog_Load(object sender, System.EventArgs e) {
      printPreviewControl1.AutoZoom = true;
    }

    public PrintDocument Document {
      get {
        return printPreviewControl1.Document;
      }

      set {
        printPreviewControl1.Document = value;
      }
    }
	}
}
