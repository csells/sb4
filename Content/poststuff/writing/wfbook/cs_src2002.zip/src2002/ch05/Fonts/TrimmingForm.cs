using System;
using System.Drawing;
using System.Drawing.Text;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Fonts {
  /// <summary>
  /// Summary description for TrimmingForm.
  /// </summary>
  public class TrimmingForm : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public TrimmingForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      // 
      // TrimmingForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(9, 22);
      this.BackColor = System.Drawing.Color.White;
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Name = "TrimmingForm";
      this.Text = "Trimming";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.TrimmingForm_Paint);

    }
		#endregion

    void TrimmingForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      string s = @"a long string that could be trimmed any old place";
      string file = @"c:\a\long\file\name\that\could\be\trimmed\any\old\place.ext";

      StringTrimming[] trimmings = { StringTrimming.None,
                                     StringTrimming.Character,
                                     StringTrimming.EllipsisCharacter,
                                     StringTrimming.Word,
                                     StringTrimming.EllipsisWord,
                                     StringTrimming.EllipsisPath,
      };

      float y = 0;
      StringFormat format = new StringFormat();
      format.FormatFlags = StringFormatFlags.LineLimit;

      // Docs say that tab stops are spaces, but they're world-coords
      SizeF size =
        g.MeasureString(
        StringTrimming.EllipsisCharacter.ToString(), this.Font);
      format.SetTabStops(0, new float[] { size.Width + 10, 0 });

      foreach( StringTrimming trimming in trimmings ) {
        format.Trimming = trimming;
        string line = trimming.ToString() + ":\t" + s;
        if( trimming == StringTrimming.EllipsisPath ) {
          line = trimming.ToString() + ":\t" + file;
        }
        RectangleF rect = new RectangleF(0, y, this.ClientRectangle.Width, this.Font.GetHeight(g) * 1.5f);
        g.DrawString(line, this.Font, Brushes.Black, rect, format);
        y += this.Font.GetHeight(g);
      }

    }

  }
}








