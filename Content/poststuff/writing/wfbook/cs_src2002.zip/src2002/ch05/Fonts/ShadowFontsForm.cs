using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Fonts
{
	/// <summary>
	/// Summary description for ShadowFontsForm.
	/// </summary>
	public class ShadowFontsForm : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ShadowFontsForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      // 
      // ShadowFontsForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(46, 109);
      this.BackColor = System.Drawing.Color.White;
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Name = "ShadowFontsForm";
      this.Text = "Shadow Fonts";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.ShadowFontsForm_Paint);

    }
		#endregion

    // Need to pass in DPI = 100 for GraphicsUnit == Display
    GraphicsPath GetStringPath(string s, float dpi, RectangleF rect, Font font, StringFormat format) {
      GraphicsPath path = new GraphicsPath();
      float emSize = dpi * font.SizeInPoints / 72;
      path.AddString(s, font.FontFamily, (int)font.Style, emSize, rect, format);
      return path;
    }

    void ShadowFontsForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      string s = "Shadow";
      float offset = 4;
      SizeF size = new SizeF(this.ClientRectangle.Width - offset, this.ClientRectangle.Height - offset);
      RectangleF rectShadow = new RectangleF(offset, offset, size.Width, size.Height);
      RectangleF rect = new RectangleF(0, 0, size.Width, size.Height);
      Font font = this.Font;
      StringFormat format = StringFormat.GenericTypographic;
      float dpi = g.DpiY;
      using( GraphicsPath pathShadow = GetStringPath(s, dpi, rectShadow, font, format) )
      using( GraphicsPath path = GetStringPath(s, dpi, rect, font, format) ) {
        g.FillPath(Brushes.Black, pathShadow);
        g.FillPath(Brushes.Red, path);
      }

    }

	}
}







