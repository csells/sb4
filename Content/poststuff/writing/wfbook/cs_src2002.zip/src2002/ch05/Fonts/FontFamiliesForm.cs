using System;using System.Globalization; // CultureInfo
using System.Text;
using System.Drawing;
using System.Drawing.Text;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Fonts {
  /// <summary>
  /// Summary description for Form1.
  /// </summary>
  public class FontFamiliesForm : System.Windows.Forms.Form {
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.ListBox familiesListBox;
    private System.Windows.Forms.Splitter splitter1;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.ListBox installedFamiliesListBox;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public FontFamiliesForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.familiesListBox = new System.Windows.Forms.ListBox();
      this.splitter1 = new System.Windows.Forms.Splitter();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.installedFamiliesListBox = new System.Windows.Forms.ListBox();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.SuspendLayout();
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.familiesListBox});
      this.groupBox1.Dock = System.Windows.Forms.DockStyle.Left;
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(136, 310);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Font Families";
      // 
      // familiesListBox
      // 
      this.familiesListBox.Dock = System.Windows.Forms.DockStyle.Fill;
      this.familiesListBox.IntegralHeight = false;
      this.familiesListBox.Location = new System.Drawing.Point(3, 16);
      this.familiesListBox.Name = "familiesListBox";
      this.familiesListBox.Size = new System.Drawing.Size(130, 291);
      this.familiesListBox.TabIndex = 0;
      // 
      // splitter1
      // 
      this.splitter1.Location = new System.Drawing.Point(136, 0);
      this.splitter1.Name = "splitter1";
      this.splitter1.Size = new System.Drawing.Size(3, 310);
      this.splitter1.TabIndex = 1;
      this.splitter1.TabStop = false;
      // 
      // groupBox2
      // 
      this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.installedFamiliesListBox});
      this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox2.Location = new System.Drawing.Point(139, 0);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size(153, 310);
      this.groupBox2.TabIndex = 2;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Installed Font Families";
      // 
      // installedFamiliesListBox
      // 
      this.installedFamiliesListBox.Dock = System.Windows.Forms.DockStyle.Fill;
      this.installedFamiliesListBox.IntegralHeight = false;
      this.installedFamiliesListBox.Location = new System.Drawing.Point(3, 16);
      this.installedFamiliesListBox.Name = "installedFamiliesListBox";
      this.installedFamiliesListBox.Size = new System.Drawing.Size(147, 291);
      this.installedFamiliesListBox.TabIndex = 0;
      // 
      // FontFamiliesForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 310);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.groupBox2,
                                                                  this.splitter1,
                                                                  this.groupBox1});
      this.Name = "FontFamiliesForm";
      this.Text = "Font Families";
      this.Load += new System.EventHandler(this.Form1_Load);
      this.groupBox1.ResumeLayout(false);
      this.groupBox2.ResumeLayout(false);
      this.ResumeLayout(false);

    }
		#endregion

    private void Form1_Load(object sender, System.EventArgs e) {
      foreach( FontFamily family in FontFamily.Families ) {
        // Can filter based on available styles
        if( !family.IsStyleAvailable(FontStyle.Bold) ) continue;
  
        familiesListBox.Items.Add(family.Name);
      }

      InstalledFontCollection installedFonts = new InstalledFontCollection();
      foreach( FontFamily family in installedFonts.Families ) {
        installedFamiliesListBox.Items.Add(family.Name);
      }
    }

  }
}
