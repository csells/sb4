using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Fonts
{
	/// <summary>
	/// Summary description for LineLimitForm.
	/// </summary>
	public class LineLimitForm : System.Windows.Forms.Form
	{
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.Splitter splitter1;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.Panel panel2;
    private System.Windows.Forms.Splitter splitter2;
    private System.Windows.Forms.GroupBox groupBox3;
    private System.Windows.Forms.Panel panel3;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public LineLimitForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.panel1 = new System.Windows.Forms.Panel();
      this.splitter1 = new System.Windows.Forms.Splitter();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.panel2 = new System.Windows.Forms.Panel();
      this.splitter2 = new System.Windows.Forms.Splitter();
      this.groupBox3 = new System.Windows.Forms.GroupBox();
      this.panel3 = new System.Windows.Forms.Panel();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.groupBox3.SuspendLayout();
      this.SuspendLayout();
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.panel1});
      this.groupBox1.Dock = System.Windows.Forms.DockStyle.Left;
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(152, 86);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "StringFormatFlags == 0";
      // 
      // panel1
      // 
      this.panel1.BackColor = System.Drawing.Color.White;
      this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.panel1.Location = new System.Drawing.Point(3, 16);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(146, 67);
      this.panel1.TabIndex = 0;
      this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
      // 
      // splitter1
      // 
      this.splitter1.Location = new System.Drawing.Point(152, 0);
      this.splitter1.Name = "splitter1";
      this.splitter1.Size = new System.Drawing.Size(3, 86);
      this.splitter1.TabIndex = 1;
      this.splitter1.TabStop = false;
      // 
      // groupBox2
      // 
      this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.panel2});
      this.groupBox2.Dock = System.Windows.Forms.DockStyle.Left;
      this.groupBox2.Location = new System.Drawing.Point(155, 0);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size(165, 86);
      this.groupBox2.TabIndex = 2;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "StringFormatFlags.LineLimit";
      // 
      // panel2
      // 
      this.panel2.BackColor = System.Drawing.Color.White;
      this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
      this.panel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.panel2.Location = new System.Drawing.Point(3, 16);
      this.panel2.Name = "panel2";
      this.panel2.Size = new System.Drawing.Size(159, 67);
      this.panel2.TabIndex = 0;
      this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
      // 
      // splitter2
      // 
      this.splitter2.Location = new System.Drawing.Point(320, 0);
      this.splitter2.Name = "splitter2";
      this.splitter2.Size = new System.Drawing.Size(3, 86);
      this.splitter2.TabIndex = 3;
      this.splitter2.TabStop = false;
      // 
      // groupBox3
      // 
      this.groupBox3.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.panel3});
      this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox3.Location = new System.Drawing.Point(323, 0);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new System.Drawing.Size(157, 86);
      this.groupBox3.TabIndex = 4;
      this.groupBox3.TabStop = false;
      this.groupBox3.Text = "StringFormatFlags.NoClip";
      // 
      // panel3
      // 
      this.panel3.BackColor = System.Drawing.Color.White;
      this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
      this.panel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.panel3.Location = new System.Drawing.Point(3, 16);
      this.panel3.Name = "panel3";
      this.panel3.Size = new System.Drawing.Size(151, 67);
      this.panel3.TabIndex = 0;
      this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
      // 
      // LineLimitForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(480, 86);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.groupBox3,
                                                                  this.splitter2,
                                                                  this.groupBox2,
                                                                  this.splitter1,
                                                                  this.groupBox1});
      this.Name = "LineLimitForm";
      this.Text = "Line Limits";
      this.Layout += new System.Windows.Forms.LayoutEventHandler(this.LineLimitForm_Layout);
      this.groupBox1.ResumeLayout(false);
      this.groupBox2.ResumeLayout(false);
      this.groupBox3.ResumeLayout(false);
      this.ResumeLayout(false);

    }
		#endregion

    string s = "line 1\nline 2\nline 3\nline 4\nline 5";

    private void panel1_Paint(object sender, System.Windows.Forms.PaintEventArgs e) {
      Graphics g = e.Graphics;
      StringFormat format = new StringFormat();
      Rectangle rect = panel1.ClientRectangle;
      rect.Inflate(-10, -10);
      g.DrawString(s, panel1.Font, Brushes.Black, rect, format);
      g.DrawRectangle(Pens.Black, rect);
    }

    private void panel2_Paint(object sender, System.Windows.Forms.PaintEventArgs e) {
      Graphics g = e.Graphics;
      StringFormat format = new StringFormat(StringFormatFlags.LineLimit);
      Rectangle rect = panel1.ClientRectangle;
      rect.Inflate(-10, -10);
      g.DrawString(s, panel1.Font, Brushes.Black, rect, format);
      g.DrawRectangle(Pens.Black, rect);
    }

    private void panel3_Paint(object sender, System.Windows.Forms.PaintEventArgs e) {
      Graphics g = e.Graphics;
      StringFormat format = new StringFormat(StringFormatFlags.NoClip);
      Rectangle rect = panel1.ClientRectangle;
      rect.Inflate(-10, -10);
      g.DrawString(s, panel1.Font, Brushes.Black, rect, format);
      g.DrawRectangle(Pens.Black, rect);
    }

    private void LineLimitForm_Layout(object sender, System.Windows.Forms.LayoutEventArgs e) {
      this.panel1.Refresh();
      this.panel2.Refresh();
      this.panel3.Refresh();
    }
	}
}







