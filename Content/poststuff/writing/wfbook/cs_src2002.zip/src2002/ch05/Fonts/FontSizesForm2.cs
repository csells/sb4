using System;
using System.Drawing;
using System.Drawing.Text;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Fonts
{
	/// <summary>
	/// Summary description for FontSizesForm2.
	/// </summary>
	public class FontSizesForm2 : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public FontSizesForm2()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      // 
      // FontSizesForm2
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(77, 197);
      this.BackColor = System.Drawing.Color.White;
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Font = new System.Drawing.Font("Times New Roman", 128F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Name = "FontSizesForm2";
      this.Text = "Font Family Sizes";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.FontSizesForm2_Paint);

    }
		#endregion

    float GetPixelsFromPoints(float points, float dpi) {
      return (dpi * points)/72f;
    }

    float GetPixelsFromDesignUnits(float designUnits, Font font, float dpi) {
      float scale = GetPixelsFromPoints(font.Size, dpi)/font.FontFamily.GetEmHeight(font.Style);
      return designUnits * scale;
    }

    void DrawBar(Graphics g, Font font, float x, float y1, float y2, string label) {
      g.DrawLine(Pens.Black, x, y1, x, y2);
      g.DrawLine(Pens.Black, x - 10, y1, x + 10, y1);
      g.DrawLine(Pens.Black, x - 1000, y2, x + 10, y2);
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      g.DrawString(label, font, Brushes.Black, x, y1 - font.GetHeight(g), format);
    }

    void FontSizesForm2_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      g.TextRenderingHint = TextRenderingHint.AntiAlias;
      int width = this.ClientRectangle.Width;
      int height = this.ClientRectangle.Height;
      string s = "Yy";
      Font font = this.Font;
      FontFamily family = font.FontFamily;
      float lineSpacing = GetPixelsFromDesignUnits(family.GetLineSpacing(font.Style), font, g.DpiY);
      float cellAscent = GetPixelsFromDesignUnits(family.GetCellAscent(font.Style), font, g.DpiY);
      float cellDescent = GetPixelsFromDesignUnits(family.GetCellDescent(font.Style), font, g.DpiY);
      float leading = lineSpacing - cellAscent - cellDescent;
      int cellWidth = g.MeasureString(s, font).ToSize().Width;
      int x = 0;
      int y = 20 + (int)Math.Ceiling(cellAscent);

      //g.DrawLine(Pens.Black, 0, y, width, y);
      g.DrawString(s, this.Font, Brushes.Black, x, y - cellAscent);

      using( Font barFont = new Font("MS Sans Serif", 8.25f) ) {
        g.DrawString("baseline", barFont, Brushes.Black, x, y - barFont.GetHeight(g));
        DrawBar(g, barFont, x + cellWidth, y - cellAscent, y, "CellAscent");
        DrawBar(g, barFont, x + cellWidth + 50, y, y + cellDescent, "CellDescent");
        DrawBar(g, barFont, x + cellWidth + 100, y + cellDescent, y + cellDescent + leading, "leading");
        DrawBar(g, barFont, x + cellWidth + 150, y - cellAscent, y - cellAscent + lineSpacing, "LineSpacing");
      }
    }



	}
}














