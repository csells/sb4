using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Fonts
{
	/// <summary>
	/// Summary description for MainForm.
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
    private System.Windows.Forms.Button button1;
    private System.Windows.Forms.Button button2;
    private System.Windows.Forms.Button button3;
    private System.Windows.Forms.Button button4;
    private System.Windows.Forms.Button button5;
    private System.Windows.Forms.Button button6;
    private System.Windows.Forms.Button button7;
    private System.Windows.Forms.Button button8;
    private System.Windows.Forms.Button button9;
    private System.Windows.Forms.Button button10;
    private System.Windows.Forms.Button button11;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public MainForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.button1 = new System.Windows.Forms.Button();
      this.button2 = new System.Windows.Forms.Button();
      this.button3 = new System.Windows.Forms.Button();
      this.button4 = new System.Windows.Forms.Button();
      this.button5 = new System.Windows.Forms.Button();
      this.button6 = new System.Windows.Forms.Button();
      this.button7 = new System.Windows.Forms.Button();
      this.button8 = new System.Windows.Forms.Button();
      this.button9 = new System.Windows.Forms.Button();
      this.button10 = new System.Windows.Forms.Button();
      this.button11 = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // button1
      // 
      this.button1.Location = new System.Drawing.Point(8, 8);
      this.button1.Name = "button1";
      this.button1.Size = new System.Drawing.Size(130, 23);
      this.button1.TabIndex = 0;
      this.button1.Text = "Font Families";
      this.button1.Click += new System.EventHandler(this.button1_Click);
      // 
      // button2
      // 
      this.button2.Location = new System.Drawing.Point(8, 40);
      this.button2.Name = "button2";
      this.button2.Size = new System.Drawing.Size(130, 23);
      this.button2.TabIndex = 1;
      this.button2.Text = "Font Sizes";
      this.button2.Click += new System.EventHandler(this.button2_Click);
      // 
      // button3
      // 
      this.button3.Location = new System.Drawing.Point(8, 104);
      this.button3.Name = "button3";
      this.button3.Size = new System.Drawing.Size(130, 23);
      this.button3.TabIndex = 3;
      this.button3.Text = "Multi-Line Text";
      this.button3.Click += new System.EventHandler(this.button3_Click);
      // 
      // button4
      // 
      this.button4.Location = new System.Drawing.Point(8, 136);
      this.button4.Name = "button4";
      this.button4.Size = new System.Drawing.Size(130, 23);
      this.button4.TabIndex = 4;
      this.button4.Text = "Line Limit";
      this.button4.Click += new System.EventHandler(this.button4_Click);
      // 
      // button5
      // 
      this.button5.Location = new System.Drawing.Point(8, 168);
      this.button5.Name = "button5";
      this.button5.Size = new System.Drawing.Size(130, 23);
      this.button5.TabIndex = 5;
      this.button5.Text = "Trimming";
      this.button5.Click += new System.EventHandler(this.button5_Click);
      // 
      // button6
      // 
      this.button6.Location = new System.Drawing.Point(8, 200);
      this.button6.Name = "button6";
      this.button6.Size = new System.Drawing.Size(130, 23);
      this.button6.TabIndex = 6;
      this.button6.Text = "Digit Substitution";
      this.button6.Click += new System.EventHandler(this.button6_Click);
      // 
      // button7
      // 
      this.button7.Location = new System.Drawing.Point(8, 232);
      this.button7.Name = "button7";
      this.button7.Size = new System.Drawing.Size(130, 23);
      this.button7.TabIndex = 7;
      this.button7.Text = "Text Rendering Hints";
      this.button7.Click += new System.EventHandler(this.button7_Click);
      // 
      // button8
      // 
      this.button8.Location = new System.Drawing.Point(8, 264);
      this.button8.Name = "button8";
      this.button8.Size = new System.Drawing.Size(130, 23);
      this.button8.TabIndex = 8;
      this.button8.Text = "Text Contrast";
      this.button8.Click += new System.EventHandler(this.button8_Click);
      // 
      // button9
      // 
      this.button9.Location = new System.Drawing.Point(8, 296);
      this.button9.Name = "button9";
      this.button9.Size = new System.Drawing.Size(130, 23);
      this.button9.TabIndex = 9;
      this.button9.Text = "Outline Fonts";
      this.button9.Click += new System.EventHandler(this.button9_Click);
      // 
      // button10
      // 
      this.button10.Location = new System.Drawing.Point(8, 328);
      this.button10.Name = "button10";
      this.button10.Size = new System.Drawing.Size(130, 23);
      this.button10.TabIndex = 10;
      this.button10.Text = "Shadow Fonts";
      this.button10.Click += new System.EventHandler(this.button10_Click);
      // 
      // button11
      // 
      this.button11.Location = new System.Drawing.Point(8, 72);
      this.button11.Name = "button11";
      this.button11.Size = new System.Drawing.Size(130, 23);
      this.button11.TabIndex = 2;
      this.button11.Text = "Font Sizes (Drawn)";
      this.button11.Click += new System.EventHandler(this.button11_Click);
      // 
      // MainForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(146, 360);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.button1,
                                                                  this.button2,
                                                                  this.button3,
                                                                  this.button4,
                                                                  this.button5,
                                                                  this.button6,
                                                                  this.button7,
                                                                  this.button8,
                                                                  this.button9,
                                                                  this.button10,
                                                                  this.button11});
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.Name = "MainForm";
      this.Text = "Fonts";
      this.ResumeLayout(false);

    }
		#endregion

    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main() {
      Application.Run(new MainForm());
    }

    private void button1_Click(object sender, System.EventArgs e) {
      (new FontFamiliesForm()).ShowDialog();
    }

    private void button2_Click(object sender, System.EventArgs e) {
      (new FontSizesForm()).ShowDialog();
    }

    private void button3_Click(object sender, System.EventArgs e) {
      (new MultiLineTextForm()).ShowDialog();
    }

    private void button4_Click(object sender, System.EventArgs e) {
      (new LineLimitForm()).ShowDialog();
    }

    private void button5_Click(object sender, System.EventArgs e) {
      (new TrimmingForm()).ShowDialog();
    }

    private void button6_Click(object sender, System.EventArgs e) {
      (new DigitSubstitutionForm()).ShowDialog();
    }

    private void button7_Click(object sender, System.EventArgs e) {
      (new TextRenderingHintsForm()).ShowDialog();
    }

    private void button8_Click(object sender, System.EventArgs e) {
      (new TextContrastForm()).ShowDialog();
    }

    private void button9_Click(object sender, System.EventArgs e) {
      (new OutlineFontsForm()).ShowDialog();
    }

    private void button10_Click(object sender, System.EventArgs e) {
      (new ShadowFontsForm()).ShowDialog();
    }

    private void button11_Click(object sender, System.EventArgs e) {
      (new FontSizesForm2()).ShowDialog();
    }
	}
}
