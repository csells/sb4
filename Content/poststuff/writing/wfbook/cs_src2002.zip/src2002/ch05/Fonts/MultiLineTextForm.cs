using System;
using System.Diagnostics;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Fonts {
  /// <summary>
  /// Summary description for MultiLineTextForm.
  /// </summary>
  public class MultiLineTextForm : System.Windows.Forms.Form {
    private System.Windows.Forms.Splitter splitter1;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.Panel automaticPanel;
    private System.Windows.Forms.Panel manualPanel;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public MultiLineTextForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.automaticPanel = new System.Windows.Forms.Panel();
      this.splitter1 = new System.Windows.Forms.Splitter();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.manualPanel = new System.Windows.Forms.Panel();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.SuspendLayout();
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.automaticPanel});
      this.groupBox1.Dock = System.Windows.Forms.DockStyle.Left;
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(152, 266);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Automatic";
      // 
      // automaticPanel
      // 
      this.automaticPanel.BackColor = Color.White;
      this.automaticPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.automaticPanel.Dock = System.Windows.Forms.DockStyle.Fill;
      this.automaticPanel.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Regular, GraphicsUnit.Point, ((System.Byte)(0)));
      this.automaticPanel.Location = new Point(3, 31);
      this.automaticPanel.Name = "automaticPanel";
      this.automaticPanel.Size = new Size(146, 232);
      this.automaticPanel.TabIndex = 0;
      this.automaticPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.automaticPanel_Paint);
      this.automaticPanel.Layout += new System.Windows.Forms.LayoutEventHandler(this.manualPanel_Layout);
      // 
      // splitter1
      // 
      this.splitter1.Location = new Point(152, 0);
      this.splitter1.Name = "splitter1";
      this.splitter1.Size = new Size(3, 266);
      this.splitter1.TabIndex = 1;
      this.splitter1.TabStop = false;
      // 
      // groupBox2
      // 
      this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.manualPanel});
      this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox2.Location = new Point(155, 0);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new Size(137, 266);
      this.groupBox2.TabIndex = 2;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Manual";
      // 
      // manualPanel
      // 
      this.manualPanel.BackColor = Color.White;
      this.manualPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.manualPanel.Dock = System.Windows.Forms.DockStyle.Fill;
      this.manualPanel.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Regular, GraphicsUnit.Point, ((System.Byte)(0)));
      this.manualPanel.Location = new Point(3, 31);
      this.manualPanel.Name = "manualPanel";
      this.manualPanel.Size = new Size(131, 232);
      this.manualPanel.TabIndex = 0;
      this.manualPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.manualPanel_Paint);
      this.manualPanel.Layout += new System.Windows.Forms.LayoutEventHandler(this.manualPanel_Layout);
      // 
      // MultiLineTextForm
      // 
      this.AutoScaleBaseSize = new Size(12, 28);
      this.ClientSize = new Size(292, 266);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.groupBox2,
                                                                  this.splitter1,
                                                                  this.groupBox1});
      this.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Regular, GraphicsUnit.Point, ((System.Byte)(0)));
      this.Name = "MultiLineTextForm";
      this.Text = "Multi-Line Text";
      this.Layout += new System.Windows.Forms.LayoutEventHandler(this.manualPanel_Layout);
      this.groupBox1.ResumeLayout(false);
      this.groupBox2.ResumeLayout(false);
      this.ResumeLayout(false);

    }
		#endregion

    string multiline = "a multi-line string:\nline 2\nline 3";

    void automaticPanel_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      RectangleF layoutRect = automaticPanel.ClientRectangle;
      g.DrawString(multiline, this.Font, Brushes.Black, layoutRect);

      SizeF size = g.MeasureString(multiline, this.Font, layoutRect.Size);
      g.DrawRectangle(Pens.Black, 0, 0, size.Width, size.Height);
    }

    void manualPanel_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      float y = 0;

      // Render using multiple calls to MeasureString
      //      foreach( string line in multiline.Split('\n') ) {
      //        float width = manualPanel.ClientRectangle.Width;
      //        float height = manualPanel.ClientRectangle.Height - y;
      //        RectangleF rect = new RectangleF(0, y, width, height);
      //        SizeF size = g.MeasureString(line, this.Font, rect.Size);
      //
      //        RectangleF layoutRect = new RectangleF(new PointF(0, y), size);
      //        g.DrawString(line, this.Font, Brushes.Black, layoutRect);
      //        g.DrawRectangle(Pens.Black, 0, y, size.Width, size.Height);
      //
      //        y += size.Height;
      //      }

      // Render using Font.GetHeight
      Pen[] pens = new Pen[] { Pens.Red, Pens.Green, Pens.Blue, };
      foreach( string line in multiline.Split('\n') ) {
        float width = manualPanel.ClientRectangle.Width;
        float height = manualPanel.ClientRectangle.Height - y;
        RectangleF layoutRect = new RectangleF(0, y, width, height);

        // Turn off auto-wrapping (we're doing it manually)
        StringFormat format = new StringFormat(StringFormatFlags.NoWrap | StringFormatFlags.DisplayFormatControl);
        g.DrawString(line, this.Font, Brushes.Black, layoutRect, format);

        SizeF size = g.MeasureString(line, this.Font, layoutRect.Size, format);
        //g.DrawRectangle(Pens.Black, 0, y, size.Width, size.Height);
        g.DrawRectangle(pens[(int)(y/this.Font.GetHeight(g))], 0, y, size.Width, size.Height);

        // Get ready for the next line
        y += this.Font.GetHeight(g);
      }

    }

    private void manualPanel_Layout(object sender, System.Windows.Forms.LayoutEventArgs e) {
      this.automaticPanel.Refresh();
      this.manualPanel.Refresh();
    }
  }
}












