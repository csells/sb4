using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using System.Windows.Forms;

[Description("Component to fire an event when time has changed by a certain delta")]
public class TimeWatcherComponent : Component {
  private System.Windows.Forms.Timer timer;
  private System.ComponentModel.IContainer components;

  public TimeWatcherComponent(IContainer container) {
    /// Required for Windows.Forms Class Composition Designer support
    if( container != null ) container.Add(this);
    InitializeComponent();

    // Additional constructor code
  }

  public TimeWatcherComponent() : this(null) {
  }

  #region Component Designer generated code
  /// <summary>
  /// Required method for Designer support - do not modify
  /// the contents of this method with the code editor.
  /// </summary>
  private void InitializeComponent() {
    this.components = new System.ComponentModel.Container();
    this.timer = new System.Windows.Forms.Timer(this.components);
    // 
    // timer
    // 
    this.timer.Tick += new System.EventHandler(this.timer_Tick);

  }
  #endregion

  public delegate void TimeChangedEventHandler(object sender, EventArgs e);
  public event TimeChangedEventHandler TimeChanged;

  [Description("Interval in milliseconds to check if time has changed")]
  [DefaultValue(100)]
  public int Interval {
    get {
      return timer.Interval;
    }
    set {
      timer.Interval = value;
    }
  }

  [Description("Enables generation of TimeChanged events")]
  [DefaultValue(false)]
  public bool Enabled {
    get {
      return timer.Enabled;
    }
    set {
      timer.Enabled = value;
    }
  }

  [Description("Number of milliseconds worthy of a TimeChanged event")]
  [DefaultValue(1000)]
  public int Delta {
    get {
      return _delta;
    }
    set {
      _delta = value;
    }
  }

  #region Implementation
  private int _delta = 1000;
  private DateTime _lastNotification = DateTime.MinValue;

  private void timer_Tick(object sender, System.EventArgs e) {
    DateTime now = DateTime.Now;
    TimeSpan diff = now - _lastNotification;

    // If the delta in time is enough to notify the container
    if( (diff.TotalMilliseconds >= _delta) &&
        (TimeChanged != null) ) {
      // Notify the container
      TimeChanged(this, EventArgs.Empty);

      // Cache the last notification for future comparisons
      _lastNotification = now;
    }
  }

  #endregion
}















