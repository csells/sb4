using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Components {
  /// <summary>
  /// Summary description for Form1.
  /// </summary>
  public class Form1 : System.Windows.Forms.Form {
    private System.Windows.Forms.ColorDialog colorDialog1;
    private System.Windows.Forms.ContextMenu contextMenu1;
    private System.Windows.Forms.OpenFileDialog openFileDialog1;
    private System.Windows.Forms.Timer timer1;
    private System.Windows.Forms.FontDialog fontDialog1;
    private System.Windows.Forms.SaveFileDialog saveFileDialog1;
    private System.Windows.Forms.Button button1;
    private System.Windows.Forms.Button button2;
    private System.Windows.Forms.Button button3;
    private System.Windows.Forms.Button button4;
    private System.Windows.Forms.TextBox fileNameTextBox;
    private System.Windows.Forms.MenuItem northMenuItem;
    private System.Windows.Forms.MenuItem eastMenuItem;
    private System.Windows.Forms.MenuItem southMenuItem;
    private System.Windows.Forms.MenuItem westMenuItem;
    private System.Windows.Forms.NotifyIcon compassNotifyIcon;
    private System.Windows.Forms.ImageList backgroundImageList;
    private System.ComponentModel.IContainer components;

    public Form1() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
      this.colorDialog1 = new System.Windows.Forms.ColorDialog();
      this.contextMenu1 = new System.Windows.Forms.ContextMenu();
      this.northMenuItem = new System.Windows.Forms.MenuItem();
      this.eastMenuItem = new System.Windows.Forms.MenuItem();
      this.southMenuItem = new System.Windows.Forms.MenuItem();
      this.westMenuItem = new System.Windows.Forms.MenuItem();
      this.backgroundImageList = new System.Windows.Forms.ImageList(this.components);
      this.compassNotifyIcon = new System.Windows.Forms.NotifyIcon(this.components);
      this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
      this.timer1 = new System.Windows.Forms.Timer(this.components);
      this.fontDialog1 = new System.Windows.Forms.FontDialog();
      this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
      this.button1 = new System.Windows.Forms.Button();
      this.button2 = new System.Windows.Forms.Button();
      this.button3 = new System.Windows.Forms.Button();
      this.button4 = new System.Windows.Forms.Button();
      this.fileNameTextBox = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // contextMenu1
      // 
      this.contextMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                 this.northMenuItem,
                                                                                 this.eastMenuItem,
                                                                                 this.southMenuItem,
                                                                                 this.westMenuItem});
      // 
      // northMenuItem
      // 
      this.northMenuItem.Index = 0;
      this.northMenuItem.Text = "&North";
      this.northMenuItem.Click += new System.EventHandler(this.northMenuItem_Click);
      // 
      // eastMenuItem
      // 
      this.eastMenuItem.Index = 1;
      this.eastMenuItem.Text = "&East";
      this.eastMenuItem.Click += new System.EventHandler(this.eastMenuItem_Click);
      // 
      // southMenuItem
      // 
      this.southMenuItem.Index = 2;
      this.southMenuItem.Text = "&South";
      this.southMenuItem.Click += new System.EventHandler(this.southMenuItem_Click);
      // 
      // westMenuItem
      // 
      this.westMenuItem.Index = 3;
      this.westMenuItem.Text = "&West";
      this.westMenuItem.Click += new System.EventHandler(this.westMenuItem_Click);
      // 
      // backgroundImageList
      // 
      this.backgroundImageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
      this.backgroundImageList.ImageSize = new System.Drawing.Size(16, 16);
      this.backgroundImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("backgroundImageList.ImageStream")));
      this.backgroundImageList.TransparentColor = System.Drawing.Color.Transparent;
      // 
      // compassNotifyIcon
      // 
      this.compassNotifyIcon.ContextMenu = this.contextMenu1;
      this.compassNotifyIcon.Icon = ((System.Drawing.Icon)(resources.GetObject("compassNotifyIcon.Icon")));
      this.compassNotifyIcon.Text = "North";
      this.compassNotifyIcon.Visible = true;
      this.compassNotifyIcon.Click += new System.EventHandler(this.compassNotifyIcon_Click);
      // 
      // timer1
      // 
      this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
      // 
      // saveFileDialog1
      // 
      this.saveFileDialog1.FileName = "doc1";
      // 
      // button1
      // 
      this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
      this.button1.Location = new System.Drawing.Point(82, 55);
      this.button1.Name = "button1";
      this.button1.Size = new System.Drawing.Size(128, 23);
      this.button1.TabIndex = 0;
      this.button1.Text = "Color Dialog";
      this.button1.Click += new System.EventHandler(this.chooseColor_Click);
      // 
      // button2
      // 
      this.button2.Anchor = System.Windows.Forms.AnchorStyles.None;
      this.button2.Location = new System.Drawing.Point(82, 87);
      this.button2.Name = "button2";
      this.button2.Size = new System.Drawing.Size(128, 23);
      this.button2.TabIndex = 0;
      this.button2.Text = "Font Dialog";
      this.button2.Click += new System.EventHandler(this.chooseFont_Click);
      // 
      // button3
      // 
      this.button3.Anchor = System.Windows.Forms.AnchorStyles.None;
      this.button3.Location = new System.Drawing.Point(82, 119);
      this.button3.Name = "button3";
      this.button3.Size = new System.Drawing.Size(128, 23);
      this.button3.TabIndex = 0;
      this.button3.Text = "Open File Dialog";
      this.button3.Click += new System.EventHandler(this.chooseFileToOpen_Click);
      // 
      // button4
      // 
      this.button4.Anchor = System.Windows.Forms.AnchorStyles.None;
      this.button4.Location = new System.Drawing.Point(82, 151);
      this.button4.Name = "button4";
      this.button4.Size = new System.Drawing.Size(128, 23);
      this.button4.TabIndex = 0;
      this.button4.Text = "Save File Dialog";
      this.button4.Click += new System.EventHandler(this.chooseFileToSave_Click);
      // 
      // fileNameTextBox
      // 
      this.fileNameTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
      this.fileNameTextBox.Location = new System.Drawing.Point(98, 191);
      this.fileNameTextBox.Name = "fileNameTextBox";
      this.fileNameTextBox.TabIndex = 1;
      this.fileNameTextBox.Text = "c:\\boot.ini";
      // 
      // Form1
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.ContextMenu = this.contextMenu1;
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.fileNameTextBox,
                                                                  this.button1,
                                                                  this.button2,
                                                                  this.button3,
                                                                  this.button4});
      this.Name = "Form1";
      this.Text = "Other Components";
      this.ResumeLayout(false);

    }
		#endregion

    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main() {
      Application.Run(new Form1());
    }

    // Use the ColorDialog
    void chooseColor_Click(object sender, EventArgs e) {
      // Set initial color
      this.colorDialog1.Color = this.BackColor;

      // Ask the user to pick a color
      if( this.colorDialog1.ShowDialog() == DialogResult.OK ) {
        // Pull out the user's choice
        this.BackColor = this.colorDialog1.Color;
      }
    }

    // Use the FontDialog
    void chooseFont_Click(object sender, EventArgs e) {
      // Set initial font
      this.fontDialog1.Font = this.Font;

      // Ask the user to pick a font
      if( this.fontDialog1.ShowDialog() == DialogResult.OK ) {
        // Pull out the user's choice
        this.Font = this.fontDialog1.Font;
      }
    }

    // Use the OpenFileDialog (common usage just like SaveFileDialog)
    void chooseFileToOpen_Click(object sender, EventArgs e) {
      // Set initial file name
      this.openFileDialog1.FileName = this.fileNameTextBox.Text;

      // Ask the user to pick a file
      if( this.openFileDialog1.ShowDialog() == DialogResult.OK ) {
        // Pull out the user's choice
        this.fileNameTextBox.Text = this.openFileDialog1.FileName;
      }
    }

    // Use the SaveFileDialog
    void chooseFileToSave_Click(object sender, EventArgs e) {
      // Set initial file name
      this.saveFileDialog1.FileName = this.fileNameTextBox.Text;

      // Ask the user to pick a file
      if( this.saveFileDialog1.ShowDialog() == DialogResult.OK ) {
        // Pull out the user's choice
        this.fileNameTextBox.Text = this.saveFileDialog1.FileName;
      }
    }

    // Icons
    Icon northIcon = new Icon(@"C:\vs.net\Common7\Graphics\icons\arrows\ARW02UP.ICO");
    Icon eastIcon = new Icon(@"C:\vs.net\Common7\Graphics\icons\arrows\ARW02RT.ICO");
    Icon southIcon = new Icon(@"C:\vs.net\Common7\Graphics\icons\arrows\ARW02DN.ICO");
    Icon westIcon = new Icon(@"C:\vs.net\Common7\Graphics\icons\arrows\ARW02LT.ICO");

    // Helper
    void SetDirection(string direction) {
      // Update notify icon
      compassNotifyIcon.Text = direction;
      switch( direction ) {
        case "North": compassNotifyIcon.Icon = northIcon; break;
        case "East": compassNotifyIcon.Icon = eastIcon; break;
        case "South": compassNotifyIcon.Icon = southIcon; break;
        case "West": compassNotifyIcon.Icon = westIcon; break;
      }

      // Set background from the image list
      int index = -1;
      switch( direction ) {
        case "North": index = 0; break;
        case "East": index = 1; break;
        case "South": index = 2; break;
        case "West": index = 3; break;
      }

      this.BackgroundImage = backgroundImageList.Images[index];
    }

    // Context menu item: North
    void northMenuItem_Click(object sender, EventArgs e) {
      SetDirection("North");
    }

    // Context menu item: East
    void eastMenuItem_Click(object sender, EventArgs e) {
      SetDirection("East");
    }

    // Context menu item: South
    void southMenuItem_Click(object sender, EventArgs e) {
      SetDirection("South");
    }

    // Context menu item: West
    void westMenuItem_Click(object sender, EventArgs e) {
      SetDirection("West");
    }

    //    // Click handler
    //    void compassNotifyIcon_Click(object sender, EventArgs e) {
    //      switch( compassNotifyIcon.Text ) {
    //        case "North": SetDirection("East"); break;
    //        case "East": SetDirection("South"); break;
    //        case "South": SetDirection("West"); break;
    //        case "West": SetDirection("North"); break;
    //      }
    //    }

    // Notify icon click handler
    void compassNotifyIcon_Click(object sender, EventArgs e) {
      // Toggle animation
      timer1.Enabled = !timer1.Enabled;
      timer1.Interval = 1000; // Animate once/second
    }

    void timer1_Tick(object sender, EventArgs e) {
      switch( compassNotifyIcon.Text ) {
        case "North": SetDirection("East"); break;
        case "East": SetDirection("South"); break;
        case "South": SetDirection("West"); break;
        case "West": SetDirection("North"); break;
      }
    }

  }
}












