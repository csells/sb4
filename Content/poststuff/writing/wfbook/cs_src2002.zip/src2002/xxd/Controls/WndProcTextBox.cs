using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace Controls
{
  public class WndProcTextBox : TextBox
  {
    public WndProcTextBox()
    {
      SetStyle(ControlStyles.EnableNotifyMessage, true);
    }

public delegate void ShowEventInfo(string info);
public event ShowEventInfo ShowEventInfoEvent = null;

    protected override void OnNotifyMessage(Message m)
    {
      if (ShowEventInfoEvent != null)
      {
        ShowEventInfoEvent(string.Format("Msg: HWND({0}) LPARAM({1}) WPARAM({2}) MSG({3})", 
          m.HWnd,
          m.LParam,
          m.WParam,
          m.Msg));
      }

      base.OnNotifyMessage(m);
    }
    }

}

