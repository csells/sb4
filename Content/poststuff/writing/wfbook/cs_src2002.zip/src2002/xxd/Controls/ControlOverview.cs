using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Controls
{
	/// <summary>
	/// Summary description for ControlOverview.
	/// </summary>
	public class ControlOverview : System.Windows.Forms.Form
	{
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.LinkLabel linkLabel1;
    private System.Windows.Forms.TextBox textBox1;
    private System.Windows.Forms.Button button1;
    private System.Windows.Forms.CheckBox checkBox1;
    private System.Windows.Forms.RadioButton radioButton1;
    private System.Windows.Forms.PictureBox pictureBox1;
    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.ListBox listBox1;
    private System.Windows.Forms.Panel panel2;
    private System.Windows.Forms.CheckedListBox checkedListBox1;
    private System.Windows.Forms.Panel panel3;
    private System.Windows.Forms.ComboBox comboBox1;
    private System.Windows.Forms.Panel panel4;
    private System.Windows.Forms.ListView listView1;
    private System.Windows.Forms.ImageList imageList1;
    private System.Windows.Forms.Panel panel5;
    private System.Windows.Forms.TreeView treeView1;
    private System.Windows.Forms.MonthCalendar monthCalendar1;
    private System.Windows.Forms.Panel panel6;
    private System.Windows.Forms.DateTimePicker dateTimePicker1;
    private System.Windows.Forms.HScrollBar hScrollBar1;
    private System.Windows.Forms.DomainUpDown domainUpDown1;
    private System.Windows.Forms.VScrollBar vScrollBar1;
    private System.Windows.Forms.NumericUpDown numericUpDown1;
    private System.Windows.Forms.TrackBar trackBar1;
    private System.Windows.Forms.ProgressBar progressBar1;
    private System.Windows.Forms.RichTextBox richTextBox1;
    private System.Windows.Forms.Panel panel7;
    private System.Windows.Forms.TabControl tabControl1;
    private System.Windows.Forms.TabPage tabPage1;
    private System.Windows.Forms.TabPage tabPage2;
    private System.Windows.Forms.TabPage tabPage3;
    private System.Windows.Forms.Button button2;
    private System.ComponentModel.IContainer components;

		public ControlOverview()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.components = new System.ComponentModel.Container();
      System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
                                                                                                                                                        new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "First Item", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0))))}, 0);
      System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
                                                                                                                                                        new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "Second Item", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0))))}, 1);
      System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
                                                                                                                                                        new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "Third Item", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0))))}, 2);
      System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
                                                                                                                                                        new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "Fourth Item", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0))))}, 2);
      System.Windows.Forms.ListViewItem listViewItem5 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
                                                                                                                                                        new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "Fifth Item", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0))))}, 0);
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ControlOverview));
      this.label1 = new System.Windows.Forms.Label();
      this.linkLabel1 = new System.Windows.Forms.LinkLabel();
      this.textBox1 = new System.Windows.Forms.TextBox();
      this.button1 = new System.Windows.Forms.Button();
      this.checkBox1 = new System.Windows.Forms.CheckBox();
      this.radioButton1 = new System.Windows.Forms.RadioButton();
      this.pictureBox1 = new System.Windows.Forms.PictureBox();
      this.panel1 = new System.Windows.Forms.Panel();
      this.listBox1 = new System.Windows.Forms.ListBox();
      this.panel2 = new System.Windows.Forms.Panel();
      this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
      this.panel3 = new System.Windows.Forms.Panel();
      this.comboBox1 = new System.Windows.Forms.ComboBox();
      this.panel4 = new System.Windows.Forms.Panel();
      this.listView1 = new System.Windows.Forms.ListView();
      this.imageList1 = new System.Windows.Forms.ImageList(this.components);
      this.panel5 = new System.Windows.Forms.Panel();
      this.treeView1 = new System.Windows.Forms.TreeView();
      this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
      this.panel6 = new System.Windows.Forms.Panel();
      this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
      this.hScrollBar1 = new System.Windows.Forms.HScrollBar();
      this.domainUpDown1 = new System.Windows.Forms.DomainUpDown();
      this.vScrollBar1 = new System.Windows.Forms.VScrollBar();
      this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
      this.trackBar1 = new System.Windows.Forms.TrackBar();
      this.progressBar1 = new System.Windows.Forms.ProgressBar();
      this.richTextBox1 = new System.Windows.Forms.RichTextBox();
      this.panel7 = new System.Windows.Forms.Panel();
      this.tabControl1 = new System.Windows.Forms.TabControl();
      this.tabPage1 = new System.Windows.Forms.TabPage();
      this.tabPage2 = new System.Windows.Forms.TabPage();
      this.tabPage3 = new System.Windows.Forms.TabPage();
      this.button2 = new System.Windows.Forms.Button();
      this.panel1.SuspendLayout();
      this.panel2.SuspendLayout();
      this.panel3.SuspendLayout();
      this.panel4.SuspendLayout();
      this.panel5.SuspendLayout();
      this.panel6.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
      this.panel7.SuspendLayout();
      this.tabControl1.SuspendLayout();
      this.SuspendLayout();
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(8, 8);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(144, 40);
      this.label1.TabIndex = 0;
      this.label1.Text = "label1";
      // 
      // linkLabel1
      // 
      this.linkLabel1.Location = new System.Drawing.Point(8, 56);
      this.linkLabel1.Name = "linkLabel1";
      this.linkLabel1.Size = new System.Drawing.Size(144, 40);
      this.linkLabel1.TabIndex = 1;
      this.linkLabel1.TabStop = true;
      this.linkLabel1.Text = "linkLabel1";
      this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
      // 
      // textBox1
      // 
      this.textBox1.Location = new System.Drawing.Point(0, 96);
      this.textBox1.Name = "textBox1";
      this.textBox1.Size = new System.Drawing.Size(152, 20);
      this.textBox1.TabIndex = 2;
      this.textBox1.Text = "textBox1";
      // 
      // button1
      // 
      this.button1.Location = new System.Drawing.Point(0, 120);
      this.button1.Name = "button1";
      this.button1.Size = new System.Drawing.Size(152, 23);
      this.button1.TabIndex = 3;
      this.button1.Text = "button1";
      this.button1.Click += new System.EventHandler(this.button1_Click);
      // 
      // checkBox1
      // 
      this.checkBox1.Location = new System.Drawing.Point(8, 144);
      this.checkBox1.Name = "checkBox1";
      this.checkBox1.TabIndex = 4;
      this.checkBox1.Text = "checkBox1";
      // 
      // radioButton1
      // 
      this.radioButton1.Location = new System.Drawing.Point(8, 168);
      this.radioButton1.Name = "radioButton1";
      this.radioButton1.TabIndex = 5;
      this.radioButton1.Text = "radioButton1";
      // 
      // pictureBox1
      // 
      this.pictureBox1.Location = new System.Drawing.Point(8, 192);
      this.pictureBox1.Name = "pictureBox1";
      this.pictureBox1.TabIndex = 6;
      this.pictureBox1.TabStop = false;
      // 
      // panel1
      // 
      this.panel1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                         this.listBox1});
      this.panel1.Location = new System.Drawing.Point(8, 256);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(136, 112);
      this.panel1.TabIndex = 7;
      // 
      // listBox1
      // 
      this.listBox1.Items.AddRange(new object[] {
                                                  "First Item",
                                                  "Second Item",
                                                  "Third Item",
                                                  "Fourth Item",
                                                  "Fifth Item"});
      this.listBox1.Location = new System.Drawing.Point(8, 8);
      this.listBox1.Name = "listBox1";
      this.listBox1.Size = new System.Drawing.Size(120, 95);
      this.listBox1.TabIndex = 0;
      this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
      // 
      // panel2
      // 
      this.panel2.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                         this.checkedListBox1});
      this.panel2.Location = new System.Drawing.Point(8, 376);
      this.panel2.Name = "panel2";
      this.panel2.Size = new System.Drawing.Size(136, 112);
      this.panel2.TabIndex = 8;
      // 
      // checkedListBox1
      // 
      this.checkedListBox1.Items.AddRange(new object[] {
                                                         "First Item",
                                                         "Second Item",
                                                         "Third Item",
                                                         "Fourth Item",
                                                         "Fifth Item"});
      this.checkedListBox1.Location = new System.Drawing.Point(8, 8);
      this.checkedListBox1.Name = "checkedListBox1";
      this.checkedListBox1.Size = new System.Drawing.Size(120, 94);
      this.checkedListBox1.TabIndex = 0;
      // 
      // panel3
      // 
      this.panel3.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                         this.comboBox1});
      this.panel3.Location = new System.Drawing.Point(8, 496);
      this.panel3.Name = "panel3";
      this.panel3.Size = new System.Drawing.Size(200, 128);
      this.panel3.TabIndex = 9;
      // 
      // comboBox1
      // 
      this.comboBox1.Items.AddRange(new object[] {
                                                   "First Item",
                                                   "Second Item",
                                                   "Third Item",
                                                   "Fourth Item",
                                                   "Fifth item"});
      this.comboBox1.Location = new System.Drawing.Point(8, 8);
      this.comboBox1.Name = "comboBox1";
      this.comboBox1.Size = new System.Drawing.Size(184, 21);
      this.comboBox1.TabIndex = 0;
      this.comboBox1.Text = "comboBox1";
      this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
      // 
      // panel4
      // 
      this.panel4.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                         this.listView1});
      this.panel4.Location = new System.Drawing.Point(160, 8);
      this.panel4.Name = "panel4";
      this.panel4.Size = new System.Drawing.Size(200, 128);
      this.panel4.TabIndex = 10;
      // 
      // listView1
      // 
      this.listView1.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
                                                                              listViewItem1,
                                                                              listViewItem2,
                                                                              listViewItem3,
                                                                              listViewItem4,
                                                                              listViewItem5});
      this.listView1.LargeImageList = this.imageList1;
      this.listView1.Location = new System.Drawing.Point(8, 8);
      this.listView1.Name = "listView1";
      this.listView1.Size = new System.Drawing.Size(184, 112);
      this.listView1.SmallImageList = this.imageList1;
      this.listView1.TabIndex = 0;
      this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
      // 
      // imageList1
      // 
      this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
      this.imageList1.ImageSize = new System.Drawing.Size(32, 32);
      this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
      this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
      // 
      // panel5
      // 
      this.panel5.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                         this.treeView1});
      this.panel5.Location = new System.Drawing.Point(160, 144);
      this.panel5.Name = "panel5";
      this.panel5.Size = new System.Drawing.Size(200, 128);
      this.panel5.TabIndex = 11;
      // 
      // treeView1
      // 
      this.treeView1.ImageIndex = -1;
      this.treeView1.Location = new System.Drawing.Point(8, 8);
      this.treeView1.Name = "treeView1";
      this.treeView1.SelectedImageIndex = -1;
      this.treeView1.Size = new System.Drawing.Size(184, 112);
      this.treeView1.TabIndex = 0;
      // 
      // monthCalendar1
      // 
      this.monthCalendar1.Location = new System.Drawing.Point(160, 280);
      this.monthCalendar1.Name = "monthCalendar1";
      this.monthCalendar1.TabIndex = 12;
      // 
      // panel6
      // 
      this.panel6.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                         this.dateTimePicker1});
      this.panel6.Location = new System.Drawing.Point(216, 448);
      this.panel6.Name = "panel6";
      this.panel6.Size = new System.Drawing.Size(216, 192);
      this.panel6.TabIndex = 13;
      // 
      // dateTimePicker1
      // 
      this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Time;
      this.dateTimePicker1.Location = new System.Drawing.Point(8, 8);
      this.dateTimePicker1.Name = "dateTimePicker1";
      this.dateTimePicker1.ShowUpDown = true;
      this.dateTimePicker1.TabIndex = 0;
      // 
      // hScrollBar1
      // 
      this.hScrollBar1.Location = new System.Drawing.Point(376, 8);
      this.hScrollBar1.Name = "hScrollBar1";
      this.hScrollBar1.Size = new System.Drawing.Size(176, 17);
      this.hScrollBar1.TabIndex = 14;
      // 
      // domainUpDown1
      // 
      this.domainUpDown1.Items.Add("First");
      this.domainUpDown1.Items.Add("Second");
      this.domainUpDown1.Items.Add("Third");
      this.domainUpDown1.Items.Add("Fourth");
      this.domainUpDown1.Items.Add("Fifth");
      this.domainUpDown1.Location = new System.Drawing.Point(376, 40);
      this.domainUpDown1.Name = "domainUpDown1";
      this.domainUpDown1.Size = new System.Drawing.Size(176, 20);
      this.domainUpDown1.TabIndex = 15;
      this.domainUpDown1.Text = "domainUpDown1";
      // 
      // vScrollBar1
      // 
      this.vScrollBar1.Location = new System.Drawing.Point(656, 8);
      this.vScrollBar1.Name = "vScrollBar1";
      this.vScrollBar1.Size = new System.Drawing.Size(17, 184);
      this.vScrollBar1.TabIndex = 16;
      // 
      // numericUpDown1
      // 
      this.numericUpDown1.Location = new System.Drawing.Point(376, 64);
      this.numericUpDown1.Name = "numericUpDown1";
      this.numericUpDown1.Size = new System.Drawing.Size(176, 20);
      this.numericUpDown1.TabIndex = 17;
      // 
      // trackBar1
      // 
      this.trackBar1.Location = new System.Drawing.Point(376, 96);
      this.trackBar1.Name = "trackBar1";
      this.trackBar1.Size = new System.Drawing.Size(200, 45);
      this.trackBar1.TabIndex = 18;
      this.trackBar1.ValueChanged += new System.EventHandler(this.trackBar1_ValueChanged);
      // 
      // progressBar1
      // 
      this.progressBar1.Location = new System.Drawing.Point(376, 152);
      this.progressBar1.Name = "progressBar1";
      this.progressBar1.Size = new System.Drawing.Size(240, 23);
      this.progressBar1.TabIndex = 19;
      // 
      // richTextBox1
      // 
      this.richTextBox1.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.richTextBox1.Location = new System.Drawing.Point(8, 8);
      this.richTextBox1.Name = "richTextBox1";
      this.richTextBox1.Size = new System.Drawing.Size(224, 96);
      this.richTextBox1.TabIndex = 20;
      this.richTextBox1.Text = "This is a rich edit box, please visit http://www.microsoft.com for more informati" +
        "on.";
      // 
      // panel7
      // 
      this.panel7.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                         this.richTextBox1});
      this.panel7.Location = new System.Drawing.Point(376, 184);
      this.panel7.Name = "panel7";
      this.panel7.Size = new System.Drawing.Size(240, 112);
      this.panel7.TabIndex = 14;
      // 
      // tabControl1
      // 
      this.tabControl1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                              this.tabPage1,
                                                                              this.tabPage2,
                                                                              this.tabPage3});
      this.tabControl1.Location = new System.Drawing.Point(400, 320);
      this.tabControl1.Name = "tabControl1";
      this.tabControl1.SelectedIndex = 0;
      this.tabControl1.TabIndex = 20;
      // 
      // tabPage1
      // 
      this.tabPage1.Location = new System.Drawing.Point(4, 22);
      this.tabPage1.Name = "tabPage1";
      this.tabPage1.Size = new System.Drawing.Size(192, 74);
      this.tabPage1.TabIndex = 0;
      this.tabPage1.Text = "tabPage1";
      // 
      // tabPage2
      // 
      this.tabPage2.Location = new System.Drawing.Point(4, 22);
      this.tabPage2.Name = "tabPage2";
      this.tabPage2.Size = new System.Drawing.Size(192, 74);
      this.tabPage2.TabIndex = 1;
      this.tabPage2.Text = "tabPage2";
      // 
      // tabPage3
      // 
      this.tabPage3.Location = new System.Drawing.Point(4, 22);
      this.tabPage3.Name = "tabPage3";
      this.tabPage3.Size = new System.Drawing.Size(192, 74);
      this.tabPage3.TabIndex = 2;
      this.tabPage3.Text = "tabPage3";
      // 
      // button2
      // 
      this.button2.Location = new System.Drawing.Point(440, 456);
      this.button2.Name = "button2";
      this.button2.Size = new System.Drawing.Size(152, 23);
      this.button2.TabIndex = 21;
      this.button2.Text = "Window Elements Dialog";
      this.button2.Click += new System.EventHandler(this.button2_Click);
      // 
      // ControlOverview
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(704, 670);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.button2,
                                                                  this.tabControl1,
                                                                  this.progressBar1,
                                                                  this.trackBar1,
                                                                  this.numericUpDown1,
                                                                  this.vScrollBar1,
                                                                  this.domainUpDown1,
                                                                  this.hScrollBar1,
                                                                  this.panel6,
                                                                  this.monthCalendar1,
                                                                  this.panel3,
                                                                  this.panel1,
                                                                  this.pictureBox1,
                                                                  this.radioButton1,
                                                                  this.checkBox1,
                                                                  this.button1,
                                                                  this.textBox1,
                                                                  this.linkLabel1,
                                                                  this.label1,
                                                                  this.panel2,
                                                                  this.panel4,
                                                                  this.panel5,
                                                                  this.panel7});
      this.Name = "ControlOverview";
      this.Text = "ControlOverview";
      this.Load += new System.EventHandler(this.ControlOverview_Load);
      this.panel1.ResumeLayout(false);
      this.panel2.ResumeLayout(false);
      this.panel3.ResumeLayout(false);
      this.panel4.ResumeLayout(false);
      this.panel5.ResumeLayout(false);
      this.panel6.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
      this.panel7.ResumeLayout(false);
      this.tabControl1.ResumeLayout(false);
      this.ResumeLayout(false);

    }
		#endregion

    private void ControlOverview_Load(object sender, System.EventArgs e)
    {
//      // Label
//      label1.Text = "This is some test text...";
//      label1.TextAlign = ContentAlignment.TopCenter;
//
//      // LinkLabel
//      // Will automatically parse common URL's
//      linkLabel1.Text = "http://sellsbrothers.com";
//
//      // Alternatively you could so do:
//
//      // Can add links manually to hide real addresses
//      linkLabel1.Text = "Click here to continue...";
//
//      // Create a new link at the 'here' word
//      linkLabel1.Links.Add(
//                            // Starting character of the word/phrase
//                            "Click ".Length,
//                            // Length of the word/phrase 
//                            "here".Length,  
//                            // data of the link (usually a string)
//                            "http://sellsbrothers.com");  
//      
//      // text box
//      MessageBox.Show(textBox1.Text);
//
//      // check box
//      if (checkBox1.Checked)
//        MessageBox.Show("Check box checked!");
//      else
//        MessageBox.Show("Check box is not checked");
//
//      // radio button
//      if (radioButton1.Checked)
//        MessageBox.Show("Radio button checked");
//      else
//        MessageBox.Show("Radio button unchecked");
//
//      // Picture box
//      pictureBox1.Image = new Bitmap(@"c:\windows\zapotec.bmp");
//
//      // List box
//      MessageBox.Show(string.Format("Selected Item is: {0}", 
//                      listBox1.SelectedItem));
//
//      // Combo box
//      MessageBox.Show(comboBox1.Text);
//    
//      // Change the view type
//      listView1.View = View.SmallIcon;
//    
//      // Tree view
//
//      // Create Tree Items
//      TreeNode topNode = treeView1.Nodes.Add("Top Item");
//
//      // Add child nodes in the top node
//      topNode.Nodes.Add("Child Node");
//      topNode.Nodes.Add("Another Child Node");
//
//        // Get all the Dates chosen 
//        // SelectionStart is beginning Date
//        // SelectionEnd is last date
//        // SelectionRange will return all the dates
//        MessageBox.Show(string.Format("Date(s): {0} - {1}",
//          monthCalendar1.SelectionStart.ToShortDateString(),
//          monthCalendar1.SelectionEnd.ToShortDateString()));
//
//      // Show the Date (or time) picked
//      MessageBox.Show(dateTimePicker1.Value.ToShortDateString());
//
//      hScrollBar1.Minimum = 0;
//      hScrollBar1.Maximum = 10;
//
//      vScrollBar1.Minimum = 0;
//      vScrollBar1.Maximum = 1000;

    }

    void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
    {
      // For URL's, usually just doing a start process works fine
        System.Diagnostics.Process.Start(e.Link.LinkData as string);
    }

    void button1_Click(object sender, System.EventArgs e)
    {
      //MessageBox.Show("Button1 Clicked!");
//      MessageBox.Show(domainUpDown1.Text);
//      MessageBox.Show(numericUpDown1.Value.ToString());
//
//      // Advance the Progress bar
//      progressBar1.Increment(1);
//
//      // Decrement the Progress bar
//      progressBar1.Increment(-1);
//
//      // Save the file
//      richTextBox1.SaveFile("myfile.rtf", RichTextBoxStreamType.RichText);
//
//      // Change the index to the third page (2 = 3rd page)
//      // Both lines do the same thing, select the page by index
//      // or page control name
//      tabControl1.SelectedIndex = 2;
//      tabControl1.SelectedTab = tabPage3; // Name of page control
    }

    void listBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
      // Item changed, so let the use know which one is selected
      MessageBox.Show(string.Format("Selected Item is: {0}", 
        listBox1.SelectedItem));
    }

    void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
      // Item changed, so let the use know which one is selected
      MessageBox.Show(string.Format("Selected Item is: {0}", 
        comboBox1.SelectedItem));
    }

    void listView1_SelectedIndexChanged(object sender, EventArgs e)
    {
      // Show the first of the selected items
      MessageBox.Show(string.Format("Selected Item is: {0}", 
        listView1.SelectedItems[0]));
    }

    private void trackBar1_ValueChanged(object sender, System.EventArgs e)
    {
      MessageBox.Show(trackBar1.Value.ToString());
    }

    private void button2_Click(object sender, System.EventArgs e)
    {
      (new WindowElementsForm()).Show();
    }
	}
}
