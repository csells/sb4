class HelpProvider {
  private void OnControlHelp(object sender, HelpEventArgs hevent) {
    Control control = (Control) sender;
    string helpString = this.GetHelpString(control);
    string helpKeyword = this.GetHelpKeyword(control);
    HelpNavigator helpNavigator = this.GetHelpNavigator(control);
    bool showHelp = this.GetShowHelp(control);

    if( !showHelp ) return;
    if( Control.MouseButtons != 0 && helpString != null && helpString.Length > 0 ) {
      Help.ShowPopup(control, helpString, hevent.MousePos);
      hevent.Handled = true;
    }

    if( !(hevent.Handled) && this.helpNamespace != null ) {
      if( helpKeyword != null && helpKeyword.Length > 0 ) {
        Help.ShowHelp(control, this.helpNamespace, helpNavigator, helpKeyword);
        hevent.Handled = true;
      }

      if( !hevent.Handled ) {
        Help.ShowHelp(control, this.helpNamespace, helpNavigator);
        hevent.Handled = true;
      }
    }

    if( !hevent.Handled && helpString != null && helpString.Length > 0 ) {
      Help.ShowPopup(control, helpString, hevent.MousePos);
      hevent.Handled = true;
    }

    if( !hevent.Handled && this.helpNamespace != null ) {
      Help.ShowHelp(control, this.helpNamespace);
      hevent.Handled = true;
    }
  }

}
