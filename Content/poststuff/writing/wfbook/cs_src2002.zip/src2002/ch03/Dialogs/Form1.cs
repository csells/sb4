using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Dialogs {
  /// <summary>
  /// Summary description for Form1.
  /// </summary>
  public class Form1 : System.Windows.Forms.Form {
    private System.Windows.Forms.ColorDialog colorDialog1;
    private System.Windows.Forms.FontDialog fontDialog1;
    private System.Windows.Forms.OpenFileDialog openFileDialog1;
    private System.Windows.Forms.PageSetupDialog pageSetupDialog1;
    private System.Windows.Forms.PrintDialog printDialog1;
    private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
    private System.Windows.Forms.SaveFileDialog saveFileDialog1;
    private System.Windows.Forms.Button colorDialogButton;
    private System.Windows.Forms.Button fontDialogButton;
    private System.Windows.Forms.Button openFileDialogButton;
    private System.Windows.Forms.Button pageSetupDialogButton;
    private System.Windows.Forms.Button printDialogButton;
    private System.Windows.Forms.Button printPreviewDialog;
    private System.Windows.Forms.Button saveFileDialogButton;
    private System.Windows.Forms.Button customDialogButton;
    private System.Windows.Forms.HelpProvider helpProvider1;
    private System.Windows.Forms.Button folderBrowserDialogButton;
    private System.Windows.Forms.ContextMenu contextMenu1;
    private System.Windows.Forms.MenuItem helpContentsMenuItem;
    private System.Windows.Forms.MenuItem helpIndexMenuItem;
    private System.Windows.Forms.MenuItem helpSearchMenuItem;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public Form1() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
      this.colorDialog1 = new System.Windows.Forms.ColorDialog();
      this.fontDialog1 = new System.Windows.Forms.FontDialog();
      this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
      this.pageSetupDialog1 = new System.Windows.Forms.PageSetupDialog();
      this.printDialog1 = new System.Windows.Forms.PrintDialog();
      this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
      this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
      this.colorDialogButton = new System.Windows.Forms.Button();
      this.fontDialogButton = new System.Windows.Forms.Button();
      this.openFileDialogButton = new System.Windows.Forms.Button();
      this.pageSetupDialogButton = new System.Windows.Forms.Button();
      this.printDialogButton = new System.Windows.Forms.Button();
      this.printPreviewDialog = new System.Windows.Forms.Button();
      this.saveFileDialogButton = new System.Windows.Forms.Button();
      this.customDialogButton = new System.Windows.Forms.Button();
      this.helpProvider1 = new System.Windows.Forms.HelpProvider();
      this.folderBrowserDialogButton = new System.Windows.Forms.Button();
      this.contextMenu1 = new System.Windows.Forms.ContextMenu();
      this.helpContentsMenuItem = new System.Windows.Forms.MenuItem();
      this.helpIndexMenuItem = new System.Windows.Forms.MenuItem();
      this.helpSearchMenuItem = new System.Windows.Forms.MenuItem();
      this.SuspendLayout();
      // 
      // printPreviewDialog1
      // 
      this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
      this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
      this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
      this.printPreviewDialog1.Enabled = true;
      this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
      this.printPreviewDialog1.Location = new System.Drawing.Point(22, 59);
      this.printPreviewDialog1.MaximumSize = new System.Drawing.Size(0, 0);
      this.printPreviewDialog1.Name = "printPreviewDialog1";
      this.printPreviewDialog1.Opacity = 1;
      this.printPreviewDialog1.TransparencyKey = System.Drawing.Color.Empty;
      this.printPreviewDialog1.Visible = false;
      // 
      // saveFileDialog1
      // 
      this.saveFileDialog1.FileName = "doc1";
      // 
      // colorDialogButton
      // 
      this.colorDialogButton.Location = new System.Drawing.Point(16, 16);
      this.colorDialogButton.Name = "colorDialogButton";
      this.colorDialogButton.Size = new System.Drawing.Size(136, 23);
      this.colorDialogButton.TabIndex = 0;
      this.colorDialogButton.Text = "Color Dialog";
      this.colorDialogButton.Click += new System.EventHandler(this.colorDialogButton_Click);
      // 
      // fontDialogButton
      // 
      this.fontDialogButton.Location = new System.Drawing.Point(16, 48);
      this.fontDialogButton.Name = "fontDialogButton";
      this.fontDialogButton.Size = new System.Drawing.Size(136, 23);
      this.fontDialogButton.TabIndex = 1;
      this.fontDialogButton.Text = "Font Dialog";
      this.fontDialogButton.Click += new System.EventHandler(this.fontDialogButton_Click);
      // 
      // openFileDialogButton
      // 
      this.openFileDialogButton.Location = new System.Drawing.Point(16, 80);
      this.openFileDialogButton.Name = "openFileDialogButton";
      this.openFileDialogButton.Size = new System.Drawing.Size(136, 23);
      this.openFileDialogButton.TabIndex = 2;
      this.openFileDialogButton.Text = "Open File Dialog";
      this.openFileDialogButton.Click += new System.EventHandler(this.openFileDialogButton_Click);
      // 
      // pageSetupDialogButton
      // 
      this.pageSetupDialogButton.Location = new System.Drawing.Point(16, 112);
      this.pageSetupDialogButton.Name = "pageSetupDialogButton";
      this.pageSetupDialogButton.Size = new System.Drawing.Size(136, 23);
      this.pageSetupDialogButton.TabIndex = 3;
      this.pageSetupDialogButton.Text = "Page Setup Dialog";
      this.pageSetupDialogButton.Click += new System.EventHandler(this.pageSetupDialogButton_Click);
      // 
      // printDialogButton
      // 
      this.printDialogButton.Location = new System.Drawing.Point(16, 144);
      this.printDialogButton.Name = "printDialogButton";
      this.printDialogButton.Size = new System.Drawing.Size(136, 23);
      this.printDialogButton.TabIndex = 4;
      this.printDialogButton.Text = "Print Dialog";
      this.printDialogButton.Click += new System.EventHandler(this.printDialogButton_Click);
      // 
      // printPreviewDialog
      // 
      this.printPreviewDialog.Location = new System.Drawing.Point(16, 176);
      this.printPreviewDialog.Name = "printPreviewDialog";
      this.printPreviewDialog.Size = new System.Drawing.Size(136, 23);
      this.printPreviewDialog.TabIndex = 5;
      this.printPreviewDialog.Text = "Print Preview Dialog";
      this.printPreviewDialog.Click += new System.EventHandler(this.printPreviewDialog_Click);
      // 
      // saveFileDialogButton
      // 
      this.saveFileDialogButton.Location = new System.Drawing.Point(16, 208);
      this.saveFileDialogButton.Name = "saveFileDialogButton";
      this.saveFileDialogButton.Size = new System.Drawing.Size(136, 23);
      this.saveFileDialogButton.TabIndex = 6;
      this.saveFileDialogButton.Text = "Save File Dialog";
      this.saveFileDialogButton.Click += new System.EventHandler(this.saveFileDialogButton_Click);
      // 
      // customDialogButton
      // 
      this.customDialogButton.Location = new System.Drawing.Point(16, 272);
      this.customDialogButton.Name = "customDialogButton";
      this.customDialogButton.Size = new System.Drawing.Size(136, 23);
      this.customDialogButton.TabIndex = 8;
      this.customDialogButton.Text = "Custom Dialog";
      this.customDialogButton.Click += new System.EventHandler(this.customDialogButton_Click);
      // 
      // folderBrowserDialogButton
      // 
      this.folderBrowserDialogButton.Location = new System.Drawing.Point(16, 240);
      this.folderBrowserDialogButton.Name = "folderBrowserDialogButton";
      this.folderBrowserDialogButton.Size = new System.Drawing.Size(136, 23);
      this.folderBrowserDialogButton.TabIndex = 7;
      this.folderBrowserDialogButton.Text = "Folder Browser Dialog";
      this.folderBrowserDialogButton.Click += new System.EventHandler(this.folderBrowserDialogButton_Click);
      // 
      // contextMenu1
      // 
      this.contextMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                 this.helpContentsMenuItem,
                                                                                 this.helpIndexMenuItem,
                                                                                 this.helpSearchMenuItem});
      // 
      // helpContentsMenuItem
      // 
      this.helpContentsMenuItem.Index = 0;
      this.helpContentsMenuItem.Text = "Help Contents";
      this.helpContentsMenuItem.Click += new System.EventHandler(this.helpContentsMenuItem_Click);
      // 
      // helpIndexMenuItem
      // 
      this.helpIndexMenuItem.Index = 1;
      this.helpIndexMenuItem.Text = "Help Index";
      this.helpIndexMenuItem.Click += new System.EventHandler(this.helpIndexMenuItem_Click);
      // 
      // helpSearchMenuItem
      // 
      this.helpSearchMenuItem.Index = 2;
      this.helpSearchMenuItem.Text = "Help Search";
      this.helpSearchMenuItem.Click += new System.EventHandler(this.helpSearchMenuItem_Click);
      // 
      // Form1
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(168, 304);
      this.ContextMenu = this.contextMenu1;
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.colorDialogButton,
                                                                  this.fontDialogButton,
                                                                  this.openFileDialogButton,
                                                                  this.pageSetupDialogButton,
                                                                  this.printDialogButton,
                                                                  this.printPreviewDialog,
                                                                  this.saveFileDialogButton,
                                                                  this.customDialogButton,
                                                                  this.folderBrowserDialogButton});
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.HelpButton = true;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "Form1";
      this.Text = "Dialogs";
      this.ResumeLayout(false);

    }
		#endregion

    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main() {
      Application.Run(new Form1());
    }

    void colorDialogButton_Click(object sender, EventArgs e) {
      //  ColorDialog dlg = new ColorDialog();
      //  dlg.Color = Color.Red;
      //  DialogResult res = dlg.ShowDialog();
      //  if( res == DialogResult.OK ) {
      //    MessageBox.Show("You picked " + dlg.Color.ToString(), "Color Picked");
      //  }
      colorDialog1.Color = Color.Red;
      DialogResult res = colorDialog1.ShowDialog();
      if( res == DialogResult.OK ) {
        MessageBox.Show("You picked " + colorDialog1.Color.ToString(), "Color Picked");
      }
    }

    private void fontDialogButton_Click(object sender, System.EventArgs e) {
      fontDialog1.ShowDialog();
    }

    private void folderBrowserDialogButton_Click(object sender, System.EventArgs e) {
      // NOTE: FolderBrowserDialog only in .NET 1.1+
    }

    private void openFileDialogButton_Click(object sender, System.EventArgs e) {
      //      openFileDialog1.ShowDialog();
      OpenFileDialog dlg = new OpenFileDialog();
      DialogResult res = dlg.ShowDialog();
      if( res == DialogResult.OK ) {
        MessageBox.Show("You picked: " + dlg.FileName);
      }
    }

    private void pageSetupDialogButton_Click(object sender, System.EventArgs e) {
      pageSetupDialog1.ShowDialog();
    }

    private void printDialogButton_Click(object sender, System.EventArgs e) {
      printDialog1.ShowDialog();
    }

    private void printPreviewDialog_Click(object sender, System.EventArgs e) {
      printPreviewDialog1.ShowDialog();
    }

    private void saveFileDialogButton_Click(object sender, System.EventArgs e) {
      saveFileDialog1.ShowDialog();
    }

    private void customDialogButton_Click(object sender, System.EventArgs e) {
      //      MyDialog dlg = new MyDialog();

      // Show as main window
      //      dlg.Text = "My Main Window";
      //      dlg.Show();

      // Show a sizeble modal dialog
      //      dlg.Text = "My Sizeable Modal Dialog";
      //      dlg.HelpButton = true;
      //      dlg.MinimizeBox = false;
      //      dlg.MaximizeBox = false;
      //      dlg.ShowInTaskbar = false;
      //      dlg.ShowDialog();

      // Show as a fixed-sized modal dialog
      //      dlg.Text = "My Fixed-Size Modal Dialog";
      //      dlg.FormBorderStyle = FormBorderStyle.FixedDialog;
      //      dlg.HelpButton = true;
      //      dlg.MinimizeBox = false;
      //      dlg.MaximizeBox = false;
      //      dlg.ShowInTaskbar = false;
      //      dlg.ShowDialog();

      // Show as a sizeable modeless dialog
      //      dlg.Text = "My Sizeable Modeless Dialog";
      //      dlg.HelpButton = true;
      //      dlg.MinimizeBox = false;
      //      dlg.MaximizeBox = false;
      //      dlg.ShowInTaskbar = false;
      //      dlg.Show();

      // Show as a sizeable modeless dialog
      //      dlg.Text = "My Fixed-Size Modeless Toolbox";
      //      dlg.HelpButton = true;
      //      dlg.MinimizeBox = false;
      //      dlg.MaximizeBox = false;
      //      dlg.ShowInTaskbar = false;
      //      dlg.FormBorderStyle = FormBorderStyle.FixedToolWindow;
      //      dlg.Show();

      LoanApplicationDialog dlg = new LoanApplicationDialog();
      dlg.ApplicantName = "Joe Borrower";
      dlg.ShowDialog();
      DialogResult res = dlg.DialogResult;
//      MessageBox.Show(res.ToString());
    }

void helpContentsMenuItem_Click(object sender, EventArgs e) {
  Help.ShowHelp(this, "dialogs.chm", HelpNavigator.TableOfContents);
}

void helpIndexMenuItem_Click(object sender, EventArgs e) {
  Help.ShowHelpIndex(this, "dialogs.chm");
}

void helpSearchMenuItem_Click(object sender, EventArgs e) {
  Help.ShowHelp(this, "dialogs.chm", HelpNavigator.Find, "");
}

  }
}
