using System;
using System.Globalization;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace DataBindingBug {
  /// <summary>
  /// Summary description for Form1.
  /// </summary>
  public class Form1 : System.Windows.Forms.Form {
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.Button button2;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.Button button3;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.TextBox simpleTextBox;
    private System.Windows.Forms.TextBox customTextBox;
    private System.ComponentModel.IContainer components;

    public Form1() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.label3 = new System.Windows.Forms.Label();
      this.simpleTextBox = new System.Windows.Forms.TextBox();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.button2 = new System.Windows.Forms.Button();
      this.label4 = new System.Windows.Forms.Label();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.customTextBox = new System.Windows.Forms.TextBox();
      this.label5 = new System.Windows.Forms.Label();
      this.button3 = new System.Windows.Forms.Button();
      this.label6 = new System.Windows.Forms.Label();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.SuspendLayout();
      // 
      // label3
      // 
      this.label3.Location = new System.Drawing.Point(24, 24);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(128, 23);
      this.label3.TabIndex = 0;
      this.label3.Text = "1. Change data here";
      // 
      // simpleTextBox
      // 
      this.simpleTextBox.Location = new System.Drawing.Point(160, 24);
      this.simpleTextBox.Name = "simpleTextBox";
      this.simpleTextBox.TabIndex = 1;
      this.simpleTextBox.Text = "textBox1";
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.simpleTextBox,
                                                                            this.label3,
                                                                            this.button2,
                                                                            this.label4});
      this.groupBox1.Location = new System.Drawing.Point(16, 16);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(272, 128);
      this.groupBox1.TabIndex = 4;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Binding against a simple type";
      // 
      // button2
      // 
      this.button2.Location = new System.Drawing.Point(24, 56);
      this.button2.Name = "button2";
      this.button2.Size = new System.Drawing.Size(128, 23);
      this.button2.TabIndex = 5;
      this.button2.Text = "2. .Set focus here";
      this.button2.TextAlign = System.Drawing.ContentAlignment.TopLeft;
      // 
      // label4
      // 
      this.label4.Location = new System.Drawing.Point(24, 88);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(152, 23);
      this.label4.TabIndex = 6;
      this.label4.Text = "3. Notice data changed";
      // 
      // groupBox2
      // 
      this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.customTextBox,
                                                                            this.label5,
                                                                            this.button3,
                                                                            this.label6});
      this.groupBox2.Location = new System.Drawing.Point(304, 16);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size(272, 128);
      this.groupBox2.TabIndex = 4;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Binding against a custom type";
      // 
      // customTextBox
      // 
      this.customTextBox.Location = new System.Drawing.Point(160, 24);
      this.customTextBox.Name = "customTextBox";
      this.customTextBox.TabIndex = 1;
      this.customTextBox.Text = "textBox1";
      // 
      // label5
      // 
      this.label5.Location = new System.Drawing.Point(24, 24);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(128, 23);
      this.label5.TabIndex = 0;
      this.label5.Text = "1. Change data here";
      // 
      // button3
      // 
      this.button3.Location = new System.Drawing.Point(24, 56);
      this.button3.Name = "button3";
      this.button3.Size = new System.Drawing.Size(128, 23);
      this.button3.TabIndex = 5;
      this.button3.Text = "2. .Set focus here";
      this.button3.TextAlign = System.Drawing.ContentAlignment.TopLeft;
      this.button3.Click += new System.EventHandler(this.button3_Click);
      // 
      // label6
      // 
      this.label6.Location = new System.Drawing.Point(24, 88);
      this.label6.Name = "label6";
      this.label6.Size = new System.Drawing.Size(152, 23);
      this.label6.TabIndex = 6;
      this.label6.Text = "3. Notice data *not* changed";
      // 
      // Form1
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(584, 158);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.groupBox1,
                                                                  this.groupBox2});
      this.Name = "Form1";
      this.Text = "Form1";
      this.Load += new System.EventHandler(this.Form1_Load);
      this.groupBox1.ResumeLayout(false);
      this.groupBox2.ResumeLayout(false);
      this.ResumeLayout(false);

    }
		#endregion

    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main() {
      Application.Run(new Form1());
    }

    class FractionTypeConverter : TypeConverter {
      public override bool
        CanConvertFrom(ITypeDescriptorContext context, Type sourceType) {
        return sourceType == typeof(string);
      }

      // defaults to "true" when asking for a string
      public override bool
        CanConvertTo(ITypeDescriptorContext context, Type destinationType) {
        return destinationType == typeof(string);
      }

      public override object
        ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value) {
        // Very simple, context, culture and error ignoring conversion
        string from = (string)value;
        int slash = from.IndexOf("/");
        int numerator = int.Parse(from.Substring(0, slash));
        int denominator = int.Parse(from.Substring(slash + 1));
        return new Fraction(numerator, denominator);
      }

      // default to using ToString
      public override object
        ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType) {
        if( destinationType != typeof(string) ) return null;
        Fraction number = (Fraction)value;
        return string.Format("{0}/{1}", number.Numerator, number.Denominator);
      }
    }

    [TypeConverterAttribute(typeof(FractionTypeConverter))]
      class Fraction {
      public Fraction(int numerator, int denominator) {
        this.numerator = numerator;
        this.denominator = denominator;
      }

      public int Numerator {
        get { return numerator; }
        set { value = numerator; }
      }

      public int Denominator {
        get { return denominator; }
        set { value = denominator; }
      }

      int numerator;
      int denominator;
    }

    class NameAndNumber {
      public event EventHandler NameChanged;
      public string Name {
        get { return name; }
        set {
          name = value;
          if( NameChanged != null ) NameChanged(this, EventArgs.Empty);
        }
      }

      public event EventHandler NumberChanged;
      public Fraction Number {
        get { return number; }
        set {
          number = value;
          if( NumberChanged != null ) NumberChanged(this, EventArgs.Empty);
        }
      }

      public override string ToString() {
        return string.Format("{0}: {1}/{2}", name, number.Numerator, number.Denominator);
      }

      string name = "Chris";
      Fraction number = new Fraction(452, 1);
    }

    class WorkAroundBinding : Binding {
      public WorkAroundBinding(string propertyName, object dataSource, string dataMember)
        : base(propertyName, dataSource, dataMember) {
      }

      protected override void OnFormat(ConvertEventArgs e) {
        System.Diagnostics.Debug.WriteLine(string.Format("WorkAroundBinding.OnFormat: sourceValue= '{0}', sourceType= {1}, desiredType= {2}", e.Value, e.Value.GetType(), e.DesiredType));
        base.OnFormat(e);
      }

      protected override void OnParse(ConvertEventArgs e) {
        System.Diagnostics.Debug.WriteLine(string.Format("WorkAroundBinding.OnParse: sourceValue= '{0}', sourceType= {1}, desiredType= {2}", e.Value, e.Value.GetType(), e.DesiredType));
        try {
          // Let the base class have a crack
          base.OnParse(e);
        }
        catch( InvalidCastException ) {
          // Take over for base class if it fails

          // If one of the base class event handlers converted it, we're done
          if(  e.Value.GetType().IsSubclassOf(e.DesiredType) ||
            (e.Value.GetType() == e.DesiredType) ||
            (e.Value is DBNull) ) {
            return;
          }

          // Ask the desired type for a type converter
          TypeConverter typeConverter = TypeDescriptor.GetConverter(e.DesiredType);
          if( (typeConverter !=  null) && typeConverter.CanConvertFrom(e.Value.GetType()) ) {
            e.Value = typeConverter.ConvertFrom(e.Value);
          }
        }
      }
    }

    // This will override the WorkAroundBinding (if it's hooked up)
    void ParseCustomType(object sender, ConvertEventArgs e) {
      // Let the type converter do the work
      TypeConverter converter = TypeDescriptor.GetConverter(e.DesiredType);
      if( converter == null ) return;
      if( !converter.CanConvertFrom(e.Value.GetType()) ) return;
      e.Value = converter.ConvertFrom(e.Value);
    }

    NameAndNumber source = new NameAndNumber();

    void Form1_Load(object sender, EventArgs e) {
      // Simple data types bind just fine
      simpleTextBox.DataBindings.Add("Text", source, "Name");

      // Simple data types bind with WorkAroundBinding, too
      //simpleTextBox.DataBindings.Add(new WorkAroundBinding("Text", source, "Name"));

      // Both methods fail in OnParse
      customTextBox.DataBindings.Add(new Binding("Text", source, "Number"));
//      Binding binding = customTextBox.DataBindings.Add("Text", source, "Number");
//      binding.Parse += new ConvertEventHandler(ParseCustomType);

      // WORKAROUND: Stops failure in OnParse
//      Binding binding = new WorkAroundBinding("Text", source, "Number");
//      customTextBox.DataBindings.Add(binding);
      //binding.Parse += new ConvertEventHandler(ParseCustomType);
    }

    private void button3_Click(object sender, System.EventArgs e) {
      MessageBox.Show(source.ToString());
    }

  }
}












