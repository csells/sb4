using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CustomDataSources
{
	/// <summary>
	/// Summary description for CustomItemDataSourceForm.
	/// </summary>
	public class CustomItemDataSourceForm : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public CustomItemDataSourceForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.setNameButton = new System.Windows.Forms.Button();
      this.textBox1 = new System.Windows.Forms.TextBox();
      this.label1 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.textBox2 = new System.Windows.Forms.TextBox();
      this.setNumberButton = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // setNameButton
      // 
      this.setNameButton.Location = new System.Drawing.Point(200, 8);
      this.setNameButton.Name = "setNameButton";
      this.setNameButton.Size = new System.Drawing.Size(40, 23);
      this.setNameButton.TabIndex = 2;
      this.setNameButton.Text = "Set";
      this.setNameButton.Click += new System.EventHandler(this.setNameButton_Click);
      // 
      // textBox1
      // 
      this.textBox1.Location = new System.Drawing.Point(64, 8);
      this.textBox1.Name = "textBox1";
      this.textBox1.Size = new System.Drawing.Size(120, 20);
      this.textBox1.TabIndex = 1;
      this.textBox1.Text = "";
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(8, 8);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(56, 23);
      this.label1.TabIndex = 0;
      this.label1.Text = "Name";
      this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // label2
      // 
      this.label2.Location = new System.Drawing.Point(8, 40);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(56, 23);
      this.label2.TabIndex = 3;
      this.label2.Text = "Number";
      this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // textBox2
      // 
      this.textBox2.Location = new System.Drawing.Point(64, 40);
      this.textBox2.Name = "textBox2";
      this.textBox2.Size = new System.Drawing.Size(120, 20);
      this.textBox2.TabIndex = 4;
      this.textBox2.Text = "";
      // 
      // setNumberButton
      // 
      this.setNumberButton.Location = new System.Drawing.Point(200, 40);
      this.setNumberButton.Name = "setNumberButton";
      this.setNumberButton.Size = new System.Drawing.Size(40, 23);
      this.setNumberButton.TabIndex = 5;
      this.setNumberButton.Text = "Set";
      this.setNumberButton.Click += new System.EventHandler(this.setNumberButton_Click);
      // 
      // CustomItemDataSourceForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(248, 70);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.setNameButton,
                                                                  this.textBox1,
                                                                  this.label1,
                                                                  this.label2,
                                                                  this.textBox2,
                                                                  this.setNumberButton});
      this.Name = "CustomItemDataSourceForm";
      this.Text = "Custom Item Data Source";
      this.Load += new System.EventHandler(this.CustomItemDataSourceForm_Load);
      this.ResumeLayout(false);

    }
		#endregion

    private System.Windows.Forms.Button setNameButton;
    private System.Windows.Forms.TextBox textBox1;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.TextBox textBox2;
    private System.Windows.Forms.Button setNumberButton;


    // Expose two properties for binding
    class NameAndNumber {
      // For bound controls
      public event EventHandler NameChanged;
      public string Name {
        get { return name; }
        set {
          name = value;
          // Notify bound control of changes
          if( NameChanged != null ) NameChanged(this, EventArgs.Empty);
        }
      }

      // For bound controls
      public event EventHandler NumberChanged;
      public int Number {
        get { return number; }
        set {
          number = value;
          // Notify bound control of changes
          if( NumberChanged != null ) NumberChanged(this, EventArgs.Empty);
        }
      }

      string name = "Chris";
      int number = 452;
    }

    NameAndNumber source = new NameAndNumber();

    void CustomItemDataSourceForm_Load(object sender, EventArgs e) {
      // Bind to public properties
      textBox1.DataBindings.Add("Text", source, "Name");
      textBox2.DataBindings.Add("Text", source, "Number");
    }

    void setNameButton_Click(object sender, EventArgs e) {
      // Changes replicated to textBox1.Text
      source.Name = "Joe";
    }

    void setNumberButton_Click(object sender, EventArgs e) {
      // Changes replicated to textBox2.Text
      source.Number = 226;
    }

	}
}













