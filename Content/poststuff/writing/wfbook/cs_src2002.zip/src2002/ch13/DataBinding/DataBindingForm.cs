using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace DataBinding {
  /// <summary>
  /// Summary description for Form1.
  /// </summary>
  public class DataBindingForm : System.Windows.Forms.Form {
    private System.Windows.Forms.TextBox textBox1;
    private System.Windows.Forms.ListBox listBox1;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public DataBindingForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.textBox1 = new System.Windows.Forms.TextBox();
      this.listBox1 = new System.Windows.Forms.ListBox();
      this.SuspendLayout();
      // 
      // textBox1
      // 
      this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.textBox1.Location = new System.Drawing.Point(16, 16);
      this.textBox1.Name = "textBox1";
      this.textBox1.Size = new System.Drawing.Size(264, 20);
      this.textBox1.TabIndex = 0;
      this.textBox1.Text = "textBox1";
      // 
      // listBox1
      // 
      this.listBox1.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.listBox1.IntegralHeight = false;
      this.listBox1.Location = new System.Drawing.Point(16, 48);
      this.listBox1.Name = "listBox1";
      this.listBox1.Size = new System.Drawing.Size(264, 160);
      this.listBox1.TabIndex = 3;
      // 
      // DataBindingForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 222);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.listBox1,
                                                                  this.textBox1});
      this.Name = "DataBindingForm";
      this.Text = "Data Binding";
      this.Load += new System.EventHandler(this.Form1_Load);
      this.ResumeLayout(false);

    }
		#endregion

    void Form1_Load(object sender, EventArgs e) {
      // Data source
      string stringDataSource = "Hello, There";

      // Binding
      Binding binding = new Binding("Text", stringDataSource, null);

      // Bind the control to the data source
      //textBox1.DataBindings.Add(binding);
      //textBox1.DataBindings.Add("Text", stringDataSource, null);

      // Simple binding to the listBox1.Font property
      Font fontDataSource = new Font("Lucida Console", 18);
      //textBox1.DataBindings.Add("Font", fontDataSource, null);
      //listBox1.DataBindings.Add("Font", fontDataSource, null);

      // List data source
      string[] itemsDataSource = {"apple", "pumpkin", "pie"};
      //      ArrayList itemsDataSource = new ArrayList();
      //      itemsDataSource.Add("apple");
      //      itemsDataSource.Add("pumpkin");
      //      itemsDataSource.Add("pie");
      textBox1.DataBindings.Add("Text", itemsDataSource, "Length");

      // Complex binding to listBox1 itself
      listBox1.DataSource = itemsDataSource;
      //listBox1.DisplayMember = "Length";

      // Show one item from the list at a time
      //textBox1.DataBindings.Add("Text", itemsDataSource, null);
    }

  }
}
