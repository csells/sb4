using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace DataGrids {
  /// <summary>
  /// Summary description for FilteredDataGridBindingForm.
  /// </summary>
  public class FilteredDataGridBindingForm : System.Windows.Forms.Form {
    private System.Windows.Forms.DataGrid dataGrid1;
    private System.Data.SqlClient.SqlDataAdapter sqlDataAdapter1;
    private System.Data.SqlClient.SqlCommand sqlSelectCommand1;
    private System.Data.SqlClient.SqlCommand sqlInsertCommand1;
    private System.Data.SqlClient.SqlCommand sqlUpdateCommand1;
    private System.Data.SqlClient.SqlCommand sqlDeleteCommand1;
    private System.Data.SqlClient.SqlConnection sqlConnection1;
    private DataGrids.CustomerSet customerSet1;
    private System.Windows.Forms.DataGridTableStyle customerTableStyles;
    private System.Windows.Forms.DataGridTableStyle orderTableStyles;
    private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn1;
    private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn2;
    private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn3;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public FilteredDataGridBindingForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
private void InitializeComponent() {
  this.dataGrid1 = new System.Windows.Forms.DataGrid();
  this.customerSet1 = new DataGrids.CustomerSet();
  this.sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
  this.sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
  this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
  this.sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
  this.sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
  this.sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
  this.customerTableStyles = new System.Windows.Forms.DataGridTableStyle();
  this.orderTableStyles = new System.Windows.Forms.DataGridTableStyle();
  this.dataGridTextBoxColumn1 = new System.Windows.Forms.DataGridTextBoxColumn();
  this.dataGridTextBoxColumn2 = new System.Windows.Forms.DataGridTextBoxColumn();
  this.dataGridTextBoxColumn3 = new System.Windows.Forms.DataGridTextBoxColumn();
  ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
  ((System.ComponentModel.ISupportInitialize)(this.customerSet1)).BeginInit();
  this.SuspendLayout();
  // 
  // dataGrid1
  // 
  this.dataGrid1.AlternatingBackColor = System.Drawing.SystemColors.Window;
  this.dataGrid1.BackgroundColor = System.Drawing.Color.Silver;
  this.dataGrid1.DataMember = "Customers";
  this.dataGrid1.DataSource = this.customerSet1;
  this.dataGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
  this.dataGrid1.GridLineColor = System.Drawing.SystemColors.Control;
  this.dataGrid1.HeaderBackColor = System.Drawing.SystemColors.Control;
  this.dataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
  this.dataGrid1.LinkColor = System.Drawing.SystemColors.HotTrack;
  this.dataGrid1.Name = "dataGrid1";
  this.dataGrid1.SelectionBackColor = System.Drawing.SystemColors.ActiveCaption;
  this.dataGrid1.SelectionForeColor = System.Drawing.SystemColors.ActiveCaptionText;
  this.dataGrid1.Size = new System.Drawing.Size(438, 386);
  this.dataGrid1.TabIndex = 0;
  this.dataGrid1.TableStyles.AddRange(new System.Windows.Forms.DataGridTableStyle[] {
                                                                                      this.customerTableStyles,
                                                                                      this.orderTableStyles});
  // 
  // customerSet1
  // 
  this.customerSet1.DataSetName = "CustomerSet";
  this.customerSet1.Locale = new System.Globalization.CultureInfo("en-US");
  this.customerSet1.Namespace = "http://tempuri.org/CustomerSet.xsd";
  // 
  // sqlDataAdapter1
  // 
  this.sqlDataAdapter1.DeleteCommand = this.sqlDeleteCommand1;
  this.sqlDataAdapter1.InsertCommand = this.sqlInsertCommand1;
  this.sqlDataAdapter1.SelectCommand = this.sqlSelectCommand1;
  this.sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
                                                                                          new System.Data.Common.DataTableMapping("Table", "Customers", new System.Data.Common.DataColumnMapping[] {
                                                                                                                                                                                                     new System.Data.Common.DataColumnMapping("CustomerID", "CustomerID"),
                                                                                                                                                                                                     new System.Data.Common.DataColumnMapping("CompanyName", "CompanyName"),
                                                                                                                                                                                                     new System.Data.Common.DataColumnMapping("ContactName", "ContactName"),
                                                                                                                                                                                                     new System.Data.Common.DataColumnMapping("ContactTitle", "ContactTitle"),
                                                                                                                                                                                                     new System.Data.Common.DataColumnMapping("Address", "Address"),
                                                                                                                                                                                                     new System.Data.Common.DataColumnMapping("City", "City"),
                                                                                                                                                                                                     new System.Data.Common.DataColumnMapping("Region", "Region"),
                                                                                                                                                                                                     new System.Data.Common.DataColumnMapping("PostalCode", "PostalCode"),
                                                                                                                                                                                                     new System.Data.Common.DataColumnMapping("Country", "Country"),
                                                                                                                                                                                                     new System.Data.Common.DataColumnMapping("Phone", "Phone"),
                                                                                                                                                                                                     new System.Data.Common.DataColumnMapping("Fax", "Fax")})});
  this.sqlDataAdapter1.UpdateCommand = this.sqlUpdateCommand1;
  // 
  // sqlDeleteCommand1
  // 
  this.sqlDeleteCommand1.CommandText = @"DELETE FROM Customers WHERE (CustomerID = @Original_CustomerID) AND (Address = @Original_Address OR @Original_Address IS NULL AND Address IS NULL) AND (City = @Original_City OR @Original_City IS NULL AND City IS NULL) AND (CompanyName = @Original_CompanyName) AND (ContactName = @Original_ContactName OR @Original_ContactName IS NULL AND ContactName IS NULL) AND (ContactTitle = @Original_ContactTitle OR @Original_ContactTitle IS NULL AND ContactTitle IS NULL) AND (Country = @Original_Country OR @Original_Country IS NULL AND Country IS NULL) AND (Fax = @Original_Fax OR @Original_Fax IS NULL AND Fax IS NULL) AND (Phone = @Original_Phone OR @Original_Phone IS NULL AND Phone IS NULL) AND (PostalCode = @Original_PostalCode OR @Original_PostalCode IS NULL AND PostalCode IS NULL) AND (Region = @Original_Region OR @Original_Region IS NULL AND Region IS NULL)";
  this.sqlDeleteCommand1.Connection = this.sqlConnection1;
  this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CustomerID", System.Data.SqlDbType.NVarChar, 5, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CustomerID", System.Data.DataRowVersion.Original, null));
  this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Address", System.Data.SqlDbType.NVarChar, 60, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Address", System.Data.DataRowVersion.Original, null));
  this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_City", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "City", System.Data.DataRowVersion.Original, null));
  this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CompanyName", System.Data.SqlDbType.NVarChar, 40, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CompanyName", System.Data.DataRowVersion.Original, null));
  this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ContactName", System.Data.SqlDbType.NVarChar, 30, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ContactName", System.Data.DataRowVersion.Original, null));
  this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ContactTitle", System.Data.SqlDbType.NVarChar, 30, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ContactTitle", System.Data.DataRowVersion.Original, null));
  this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Country", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Country", System.Data.DataRowVersion.Original, null));
  this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Fax", System.Data.SqlDbType.NVarChar, 24, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Fax", System.Data.DataRowVersion.Original, null));
  this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Phone", System.Data.SqlDbType.NVarChar, 24, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Phone", System.Data.DataRowVersion.Original, null));
  this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PostalCode", System.Data.SqlDbType.NVarChar, 10, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PostalCode", System.Data.DataRowVersion.Original, null));
  this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Region", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Region", System.Data.DataRowVersion.Original, null));
  // 
  // sqlConnection1
  // 
  this.sqlConnection1.ConnectionString = "data source=MUNGO\\NetSDK;initial catalog=Northwind;integrated security=SSPI;persi" +
    "st security info=False;workstation id=MUNGO;packet size=4096";
  // 
  // sqlInsertCommand1
  // 
  this.sqlInsertCommand1.CommandText = @"INSERT INTO Customers(CustomerID, CompanyName, ContactName, ContactTitle, Address, City, Region, PostalCode, Country, Phone, Fax) VALUES (@CustomerID, @CompanyName, @ContactName, @ContactTitle, @Address, @City, @Region, @PostalCode, @Country, @Phone, @Fax); SELECT CustomerID, CompanyName, ContactName, ContactTitle, Address, City, Region, PostalCode, Country, Phone, Fax FROM Customers WHERE (CustomerID = @CustomerID)";
  this.sqlInsertCommand1.Connection = this.sqlConnection1;
  this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CustomerID", System.Data.SqlDbType.NVarChar, 5, "CustomerID"));
  this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CompanyName", System.Data.SqlDbType.NVarChar, 40, "CompanyName"));
  this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ContactName", System.Data.SqlDbType.NVarChar, 30, "ContactName"));
  this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ContactTitle", System.Data.SqlDbType.NVarChar, 30, "ContactTitle"));
  this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Address", System.Data.SqlDbType.NVarChar, 60, "Address"));
  this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@City", System.Data.SqlDbType.NVarChar, 15, "City"));
  this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Region", System.Data.SqlDbType.NVarChar, 15, "Region"));
  this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PostalCode", System.Data.SqlDbType.NVarChar, 10, "PostalCode"));
  this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Country", System.Data.SqlDbType.NVarChar, 15, "Country"));
  this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Phone", System.Data.SqlDbType.NVarChar, 24, "Phone"));
  this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Fax", System.Data.SqlDbType.NVarChar, 24, "Fax"));
  // 
  // sqlSelectCommand1
  // 
  this.sqlSelectCommand1.CommandText = "SELECT CustomerID, CompanyName, ContactName, ContactTitle, Address, City, Region," +
    " PostalCode, Country, Phone, Fax FROM Customers";
  this.sqlSelectCommand1.Connection = this.sqlConnection1;
  // 
  // sqlUpdateCommand1
  // 
  this.sqlUpdateCommand1.CommandText = @"UPDATE Customers SET CustomerID = @CustomerID, CompanyName = @CompanyName, ContactName = @ContactName, ContactTitle = @ContactTitle, Address = @Address, City = @City, Region = @Region, PostalCode = @PostalCode, Country = @Country, Phone = @Phone, Fax = @Fax WHERE (CustomerID = @Original_CustomerID) AND (Address = @Original_Address OR @Original_Address IS NULL AND Address IS NULL) AND (City = @Original_City OR @Original_City IS NULL AND City IS NULL) AND (CompanyName = @Original_CompanyName) AND (ContactName = @Original_ContactName OR @Original_ContactName IS NULL AND ContactName IS NULL) AND (ContactTitle = @Original_ContactTitle OR @Original_ContactTitle IS NULL AND ContactTitle IS NULL) AND (Country = @Original_Country OR @Original_Country IS NULL AND Country IS NULL) AND (Fax = @Original_Fax OR @Original_Fax IS NULL AND Fax IS NULL) AND (Phone = @Original_Phone OR @Original_Phone IS NULL AND Phone IS NULL) AND (PostalCode = @Original_PostalCode OR @Original_PostalCode IS NULL AND PostalCode IS NULL) AND (Region = @Original_Region OR @Original_Region IS NULL AND Region IS NULL); SELECT CustomerID, CompanyName, ContactName, ContactTitle, Address, City, Region, PostalCode, Country, Phone, Fax FROM Customers WHERE (CustomerID = @CustomerID)";
  this.sqlUpdateCommand1.Connection = this.sqlConnection1;
  this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CustomerID", System.Data.SqlDbType.NVarChar, 5, "CustomerID"));
  this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CompanyName", System.Data.SqlDbType.NVarChar, 40, "CompanyName"));
  this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ContactName", System.Data.SqlDbType.NVarChar, 30, "ContactName"));
  this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ContactTitle", System.Data.SqlDbType.NVarChar, 30, "ContactTitle"));
  this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Address", System.Data.SqlDbType.NVarChar, 60, "Address"));
  this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@City", System.Data.SqlDbType.NVarChar, 15, "City"));
  this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Region", System.Data.SqlDbType.NVarChar, 15, "Region"));
  this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PostalCode", System.Data.SqlDbType.NVarChar, 10, "PostalCode"));
  this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Country", System.Data.SqlDbType.NVarChar, 15, "Country"));
  this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Phone", System.Data.SqlDbType.NVarChar, 24, "Phone"));
  this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Fax", System.Data.SqlDbType.NVarChar, 24, "Fax"));
  this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CustomerID", System.Data.SqlDbType.NVarChar, 5, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CustomerID", System.Data.DataRowVersion.Original, null));
  this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Address", System.Data.SqlDbType.NVarChar, 60, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Address", System.Data.DataRowVersion.Original, null));
  this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_City", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "City", System.Data.DataRowVersion.Original, null));
  this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CompanyName", System.Data.SqlDbType.NVarChar, 40, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CompanyName", System.Data.DataRowVersion.Original, null));
  this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ContactName", System.Data.SqlDbType.NVarChar, 30, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ContactName", System.Data.DataRowVersion.Original, null));
  this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ContactTitle", System.Data.SqlDbType.NVarChar, 30, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ContactTitle", System.Data.DataRowVersion.Original, null));
  this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Country", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Country", System.Data.DataRowVersion.Original, null));
  this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Fax", System.Data.SqlDbType.NVarChar, 24, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Fax", System.Data.DataRowVersion.Original, null));
  this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Phone", System.Data.SqlDbType.NVarChar, 24, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Phone", System.Data.DataRowVersion.Original, null));
  this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PostalCode", System.Data.SqlDbType.NVarChar, 10, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PostalCode", System.Data.DataRowVersion.Original, null));
  this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Region", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Region", System.Data.DataRowVersion.Original, null));
  // 
  // customerTableStyles
  // 
  this.customerTableStyles.DataGrid = this.dataGrid1;
  this.customerTableStyles.GridColumnStyles.AddRange(new System.Windows.Forms.DataGridColumnStyle[] {
                                                                                                      this.dataGridTextBoxColumn1,
                                                                                                      this.dataGridTextBoxColumn2,
                                                                                                      this.dataGridTextBoxColumn3});
  this.customerTableStyles.HeaderForeColor = System.Drawing.SystemColors.ControlText;
  this.customerTableStyles.MappingName = "Customers";
  // 
  // orderTableStyles
  // 
  this.orderTableStyles.DataGrid = this.dataGrid1;
  this.orderTableStyles.HeaderForeColor = System.Drawing.SystemColors.ControlText;
  this.orderTableStyles.MappingName = "Orders";
  // 
  // dataGridTextBoxColumn1
  // 
  this.dataGridTextBoxColumn1.Format = "";
  this.dataGridTextBoxColumn1.FormatInfo = null;
  this.dataGridTextBoxColumn1.HeaderText = "Company Name";
  this.dataGridTextBoxColumn1.MappingName = "CompanyName";
  this.dataGridTextBoxColumn1.Width = 75;
  // 
  // dataGridTextBoxColumn2
  // 
  this.dataGridTextBoxColumn2.Format = "";
  this.dataGridTextBoxColumn2.FormatInfo = null;
  this.dataGridTextBoxColumn2.HeaderText = "Contact Name";
  this.dataGridTextBoxColumn2.MappingName = "ContactName";
  this.dataGridTextBoxColumn2.Width = 75;
  // 
  // dataGridTextBoxColumn3
  // 
  this.dataGridTextBoxColumn3.Format = "";
  this.dataGridTextBoxColumn3.FormatInfo = null;
  this.dataGridTextBoxColumn3.HeaderText = "Phone";
  this.dataGridTextBoxColumn3.MappingName = "Phone";
  this.dataGridTextBoxColumn3.Width = 75;
  // 
  // FilteredDataGridBindingForm
  // 
  this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
  this.ClientSize = new System.Drawing.Size(438, 386);
  this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                              this.dataGrid1});
  this.Name = "FilteredDataGridBindingForm";
  this.Text = "FilteredDataGridBindingForm";
  this.Load += new System.EventHandler(this.FilteredDataGridBindingForm_Load);
  ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
  ((System.ComponentModel.ISupportInitialize)(this.customerSet1)).EndInit();
  this.ResumeLayout(false);

}
		#endregion

    void FilteredDataGridBindingForm_Load(object sender, EventArgs e) {
      // Fill the data set
      sqlDataAdapter1.Fill(customerSet1);    
    
//      // Create a new DataView to bind to
//      DataView view = new DataView(customerSet1.Tables[0]);
//
//      // Set the RowFilter and Sort Criteria
//      view.RowFilter = "Country = 'USA'";
//      view.Sort = "ContactName";
//
//      // Bind to the DataGrid
//      dataGrid1.DataSource = view;
    }

  }
}
