using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace DataGrids {
  /// <summary>
  /// Summary description for FullDataGridsForm.
  /// </summary>
  public class FullDataGridsForm : System.Windows.Forms.Form {
    private System.Windows.Forms.DataGrid dataGrid1;
    private System.Windows.Forms.ListBox listBox1;
    private System.Windows.Forms.DataGrid dataGrid2;
    private System.Windows.Forms.Button button1;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.Button button2;
    private System.Windows.Forms.Button button3;
    private System.Windows.Forms.Button button4;
    private System.Data.SqlClient.SqlDataAdapter sqlDataAdapter1;
    private System.Data.SqlClient.SqlCommand sqlSelectCommand1;
    private System.Data.SqlClient.SqlConnection sqlConnection1;
    private System.Windows.Forms.TextBox textBox1;
    private System.Windows.Forms.TextBox textBox2;
    private System.Windows.Forms.TextBox textBox3;
    private System.Windows.Forms.TextBox textBox4;
    private System.Windows.Forms.TextBox textBox5;
    private System.Windows.Forms.TextBox textBox6;
    private System.Windows.Forms.TextBox textBox7;
    private DataGrids.CustomerSet customerSet1;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public FullDataGridsForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.dataGrid1 = new System.Windows.Forms.DataGrid();
      this.customerSet1 = new DataGrids.CustomerSet();
      this.listBox1 = new System.Windows.Forms.ListBox();
      this.dataGrid2 = new System.Windows.Forms.DataGrid();
      this.button1 = new System.Windows.Forms.Button();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.button2 = new System.Windows.Forms.Button();
      this.button3 = new System.Windows.Forms.Button();
      this.button4 = new System.Windows.Forms.Button();
      this.sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
      this.sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
      this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
      this.textBox1 = new System.Windows.Forms.TextBox();
      this.textBox2 = new System.Windows.Forms.TextBox();
      this.textBox3 = new System.Windows.Forms.TextBox();
      this.textBox4 = new System.Windows.Forms.TextBox();
      this.textBox5 = new System.Windows.Forms.TextBox();
      this.textBox6 = new System.Windows.Forms.TextBox();
      this.textBox7 = new System.Windows.Forms.TextBox();
      ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.customerSet1)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dataGrid2)).BeginInit();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.SuspendLayout();
      // 
      // dataGrid1
      // 
      this.dataGrid1.AllowNavigation = false;
      this.dataGrid1.AlternatingBackColor = System.Drawing.Color.LightGray;
      this.dataGrid1.BackColor = System.Drawing.Color.Gainsboro;
      this.dataGrid1.BackgroundColor = System.Drawing.Color.Silver;
      this.dataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
      this.dataGrid1.CaptionBackColor = System.Drawing.Color.LightSteelBlue;
      this.dataGrid1.CaptionForeColor = System.Drawing.Color.MidnightBlue;
      this.dataGrid1.DataMember = "Customers.CustomersOrders";
      this.dataGrid1.DataSource = this.customerSet1;
      this.dataGrid1.FlatMode = true;
      this.dataGrid1.Font = new System.Drawing.Font("Tahoma", 8F);
      this.dataGrid1.ForeColor = System.Drawing.Color.Black;
      this.dataGrid1.GridLineColor = System.Drawing.Color.DimGray;
      this.dataGrid1.GridLineStyle = System.Windows.Forms.DataGridLineStyle.None;
      this.dataGrid1.HeaderBackColor = System.Drawing.Color.MidnightBlue;
      this.dataGrid1.HeaderFont = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
      this.dataGrid1.HeaderForeColor = System.Drawing.Color.White;
      this.dataGrid1.LinkColor = System.Drawing.Color.MidnightBlue;
      this.dataGrid1.Location = new System.Drawing.Point(7, 23);
      this.dataGrid1.Name = "dataGrid1";
      this.dataGrid1.ParentRowsBackColor = System.Drawing.Color.DarkGray;
      this.dataGrid1.ParentRowsForeColor = System.Drawing.Color.Black;
      this.dataGrid1.ReadOnly = true;
      this.dataGrid1.RowHeadersVisible = false;
      this.dataGrid1.SelectionBackColor = System.Drawing.Color.CadetBlue;
      this.dataGrid1.SelectionForeColor = System.Drawing.Color.White;
      this.dataGrid1.Size = new System.Drawing.Size(585, 121);
      this.dataGrid1.TabIndex = 0;
      // 
      // customerSet1
      // 
      this.customerSet1.DataSetName = "CustomerSet";
      this.customerSet1.Locale = new System.Globalization.CultureInfo("en-US");
      this.customerSet1.Namespace = "http://tempuri.org/CustomerSet.xsd";
      // 
      // listBox1
      // 
      this.listBox1.DataSource = this.customerSet1;
      this.listBox1.DisplayMember = "Customers.ContactName";
      this.listBox1.Location = new System.Drawing.Point(15, 15);
      this.listBox1.Name = "listBox1";
      this.listBox1.Size = new System.Drawing.Size(109, 69);
      this.listBox1.TabIndex = 1;
      // 
      // dataGrid2
      // 
      this.dataGrid2.AllowNavigation = false;
      this.dataGrid2.AlternatingBackColor = System.Drawing.Color.LightGray;
      this.dataGrid2.BackColor = System.Drawing.Color.Gainsboro;
      this.dataGrid2.BackgroundColor = System.Drawing.Color.Silver;
      this.dataGrid2.BorderStyle = System.Windows.Forms.BorderStyle.None;
      this.dataGrid2.CaptionBackColor = System.Drawing.Color.LightSteelBlue;
      this.dataGrid2.CaptionForeColor = System.Drawing.Color.MidnightBlue;
      this.dataGrid2.DataMember = "Customers.CustomersOrders.OrdersOrderDetails";
      this.dataGrid2.DataSource = this.customerSet1;
      this.dataGrid2.FlatMode = true;
      this.dataGrid2.Font = new System.Drawing.Font("Tahoma", 8F);
      this.dataGrid2.ForeColor = System.Drawing.Color.Black;
      this.dataGrid2.GridLineColor = System.Drawing.Color.DimGray;
      this.dataGrid2.GridLineStyle = System.Windows.Forms.DataGridLineStyle.None;
      this.dataGrid2.HeaderBackColor = System.Drawing.Color.MidnightBlue;
      this.dataGrid2.HeaderFont = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
      this.dataGrid2.HeaderForeColor = System.Drawing.Color.White;
      this.dataGrid2.LinkColor = System.Drawing.Color.MidnightBlue;
      this.dataGrid2.Location = new System.Drawing.Point(7, 23);
      this.dataGrid2.Name = "dataGrid2";
      this.dataGrid2.ParentRowsBackColor = System.Drawing.Color.DarkGray;
      this.dataGrid2.ParentRowsForeColor = System.Drawing.Color.Black;
      this.dataGrid2.ReadOnly = true;
      this.dataGrid2.RowHeadersVisible = false;
      this.dataGrid2.SelectionBackColor = System.Drawing.Color.CadetBlue;
      this.dataGrid2.SelectionForeColor = System.Drawing.Color.White;
      this.dataGrid2.Size = new System.Drawing.Size(570, 128);
      this.dataGrid2.TabIndex = 2;
      // 
      // button1
      // 
      this.button1.Location = new System.Drawing.Point(460, 8);
      this.button1.Name = "button1";
      this.button1.Size = new System.Drawing.Size(37, 22);
      this.button1.TabIndex = 3;
      this.button1.Text = "|<";
      this.button1.Click += new System.EventHandler(this.button1_Click);
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.groupBox2,
                                                                            this.dataGrid1});
      this.groupBox1.Location = new System.Drawing.Point(7, 106);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(599, 318);
      this.groupBox1.TabIndex = 4;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Orders";
      // 
      // groupBox2
      // 
      this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.dataGrid2});
      this.groupBox2.Location = new System.Drawing.Point(7, 151);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size(585, 160);
      this.groupBox2.TabIndex = 3;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Order Details";
      // 
      // button2
      // 
      this.button2.Location = new System.Drawing.Point(497, 8);
      this.button2.Name = "button2";
      this.button2.Size = new System.Drawing.Size(36, 22);
      this.button2.TabIndex = 5;
      this.button2.Text = "<";
      this.button2.Click += new System.EventHandler(this.button2_Click);
      // 
      // button3
      // 
      this.button3.Location = new System.Drawing.Point(533, 8);
      this.button3.Name = "button3";
      this.button3.Size = new System.Drawing.Size(37, 22);
      this.button3.TabIndex = 6;
      this.button3.Text = ">";
      this.button3.Click += new System.EventHandler(this.button3_Click);
      // 
      // button4
      // 
      this.button4.Location = new System.Drawing.Point(570, 8);
      this.button4.Name = "button4";
      this.button4.Size = new System.Drawing.Size(36, 22);
      this.button4.TabIndex = 7;
      this.button4.Text = ">|";
      this.button4.Click += new System.EventHandler(this.button4_Click);
      // 
      // sqlDataAdapter1
      // 
      this.sqlDataAdapter1.SelectCommand = this.sqlSelectCommand1;
      this.sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
                                                                                              new System.Data.Common.DataTableMapping("Table", "Customers", new System.Data.Common.DataColumnMapping[0]),
                                                                                              new System.Data.Common.DataTableMapping("Table1", "Orders", new System.Data.Common.DataColumnMapping[0]),
                                                                                              new System.Data.Common.DataTableMapping("Table2", "Order Details", new System.Data.Common.DataColumnMapping[0])});
      // 
      // sqlSelectCommand1
      // 
      this.sqlSelectCommand1.CommandText = "SELECT * FROM Customers;\r\nSELECT * FROM Orders;\r\nSELECT * FROM [Order Details];";
      this.sqlSelectCommand1.Connection = this.sqlConnection1;
      // 
      // sqlConnection1
      // 
      this.sqlConnection1.ConnectionString = "data source=MUNGO\\NetSDK;initial catalog=Northwind;integrated security=SSPI;persi" +
        "st security info=False;workstation id=MUNGO;packet size=4096";
      // 
      // textBox1
      // 
      this.textBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerSet1, "Customers.ContactName"));
      this.textBox1.Location = new System.Drawing.Point(132, 15);
      this.textBox1.Name = "textBox1";
      this.textBox1.Size = new System.Drawing.Size(306, 20);
      this.textBox1.TabIndex = 8;
      this.textBox1.Text = "";
      // 
      // textBox2
      // 
      this.textBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerSet1, "Customers.Address"));
      this.textBox2.Location = new System.Drawing.Point(132, 38);
      this.textBox2.Name = "textBox2";
      this.textBox2.Size = new System.Drawing.Size(306, 20);
      this.textBox2.TabIndex = 9;
      this.textBox2.Text = "";
      // 
      // textBox3
      // 
      this.textBox3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerSet1, "Customers.City"));
      this.textBox3.Location = new System.Drawing.Point(132, 61);
      this.textBox3.Name = "textBox3";
      this.textBox3.Size = new System.Drawing.Size(131, 20);
      this.textBox3.TabIndex = 10;
      this.textBox3.Text = "";
      // 
      // textBox4
      // 
      this.textBox4.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerSet1, "Customers.Region"));
      this.textBox4.Location = new System.Drawing.Point(263, 61);
      this.textBox4.Name = "textBox4";
      this.textBox4.Size = new System.Drawing.Size(51, 20);
      this.textBox4.TabIndex = 11;
      this.textBox4.Text = "";
      // 
      // textBox5
      // 
      this.textBox5.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerSet1, "Customers.PostalCode"));
      this.textBox5.Location = new System.Drawing.Point(314, 61);
      this.textBox5.Name = "textBox5";
      this.textBox5.Size = new System.Drawing.Size(124, 20);
      this.textBox5.TabIndex = 12;
      this.textBox5.Text = "";
      // 
      // textBox6
      // 
      this.textBox6.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerSet1, "Customers.Phone"));
      this.textBox6.Location = new System.Drawing.Point(132, 83);
      this.textBox6.Name = "textBox6";
      this.textBox6.Size = new System.Drawing.Size(131, 20);
      this.textBox6.TabIndex = 13;
      this.textBox6.Text = "";
      // 
      // textBox7
      // 
      this.textBox7.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerSet1, "Customers.Country"));
      this.textBox7.Location = new System.Drawing.Point(314, 83);
      this.textBox7.Name = "textBox7";
      this.textBox7.Size = new System.Drawing.Size(124, 20);
      this.textBox7.TabIndex = 14;
      this.textBox7.Text = "";
      // 
      // FullDataGridsForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(613, 431);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.textBox7,
                                                                  this.textBox6,
                                                                  this.textBox5,
                                                                  this.textBox4,
                                                                  this.textBox3,
                                                                  this.textBox2,
                                                                  this.textBox1,
                                                                  this.button4,
                                                                  this.button3,
                                                                  this.button2,
                                                                  this.groupBox1,
                                                                  this.button1,
                                                                  this.listBox1});
      this.Name = "FullDataGridsForm";
      this.Text = "FullDataGridsForm";
      this.Load += new System.EventHandler(this.FullDataGridsForm_Load);
      ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.customerSet1)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dataGrid2)).EndInit();
      this.groupBox1.ResumeLayout(false);
      this.groupBox2.ResumeLayout(false);
      this.ResumeLayout(false);

    }
		#endregion

    void FullDataGridsForm_Load(object sender, EventArgs e) {
      sqlDataAdapter1.Fill(customerSet1);
    }

    void button1_Click(object sender, EventArgs e) {
      BindingContext[customerSet1, "Customers"].Position = 0;
    }

    void button2_Click(object sender, EventArgs e) {
      --BindingContext[customerSet1, "Customers"].Position;
    }

    void button3_Click(object sender, EventArgs e) {
      ++BindingContext[customerSet1, "Customers"].Position;
    }

    void button4_Click(object sender, EventArgs e) {
      BindingContext[customerSet1, "Customers"].Position =
        BindingContext[customerSet1, "Customers"].Count - 1;
    }
  }
}
