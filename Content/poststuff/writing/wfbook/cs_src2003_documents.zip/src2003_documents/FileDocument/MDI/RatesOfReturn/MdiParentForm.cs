using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace RatesOfReturn {
  /// <summary>
  /// Summary description for MdiParentForm.
  /// </summary>
  public class MdiParentForm : System.Windows.Forms.Form {
    private System.Windows.Forms.MainMenu mainMenu1;
    private System.Windows.Forms.MenuItem menuItem1;
    private System.Windows.Forms.MenuItem fileNewMenuItem;
    private System.Windows.Forms.MenuItem fileOpenMenuItem;
    private System.Windows.Forms.MenuItem menuItem7;
    private System.Windows.Forms.MenuItem fileExitMenuItem;
    private System.Windows.Forms.MenuItem menuItem3;
    private System.Windows.Forms.MenuItem helpAboutMenuItem;
    private System.Windows.Forms.MenuItem menuItem2;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public MdiParentForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

    #region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.mainMenu1 = new System.Windows.Forms.MainMenu();
      this.menuItem1 = new System.Windows.Forms.MenuItem();
      this.fileNewMenuItem = new System.Windows.Forms.MenuItem();
      this.fileOpenMenuItem = new System.Windows.Forms.MenuItem();
      this.menuItem7 = new System.Windows.Forms.MenuItem();
      this.fileExitMenuItem = new System.Windows.Forms.MenuItem();
      this.menuItem3 = new System.Windows.Forms.MenuItem();
      this.helpAboutMenuItem = new System.Windows.Forms.MenuItem();
      this.menuItem2 = new System.Windows.Forms.MenuItem();
      // 
      // mainMenu1
      // 
      this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.menuItem1,
                                                                              this.menuItem2,
                                                                              this.menuItem3});
      // 
      // menuItem1
      // 
      this.menuItem1.Index = 0;
      this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.fileNewMenuItem,
                                                                              this.fileOpenMenuItem,
                                                                              this.menuItem7,
                                                                              this.fileExitMenuItem});
      this.menuItem1.MergeType = System.Windows.Forms.MenuMerge.MergeItems;
      this.menuItem1.Text = "&File";
      // 
      // fileNewMenuItem
      // 
      this.fileNewMenuItem.Index = 0;
      this.fileNewMenuItem.Shortcut = System.Windows.Forms.Shortcut.CtrlN;
      this.fileNewMenuItem.Text = "&New";
      this.fileNewMenuItem.Click += new System.EventHandler(this.fileNewMenuItem_Click);
      // 
      // fileOpenMenuItem
      // 
      this.fileOpenMenuItem.Index = 1;
      this.fileOpenMenuItem.Shortcut = System.Windows.Forms.Shortcut.CtrlO;
      this.fileOpenMenuItem.Text = "&Open...";
      this.fileOpenMenuItem.Click += new System.EventHandler(this.fileOpenMenuItem_Click);
      // 
      // menuItem7
      // 
      this.menuItem7.Index = 2;
      this.menuItem7.MergeOrder = 2;
      this.menuItem7.Text = "-";
      // 
      // fileExitMenuItem
      // 
      this.fileExitMenuItem.Index = 3;
      this.fileExitMenuItem.MergeOrder = 2;
      this.fileExitMenuItem.Text = "E&xit";
      this.fileExitMenuItem.Click += new System.EventHandler(this.fileExitMenuItem_Click);
      // 
      // menuItem3
      // 
      this.menuItem3.Index = 2;
      this.menuItem3.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.helpAboutMenuItem});
      this.menuItem3.Text = "&Help";
      // 
      // helpAboutMenuItem
      // 
      this.helpAboutMenuItem.Index = 0;
      this.helpAboutMenuItem.Text = "&About...";
      this.helpAboutMenuItem.Click += new System.EventHandler(this.helpAboutMenuItem_Click);
      // 
      // menuItem2
      // 
      this.menuItem2.Index = 1;
      this.menuItem2.MdiList = true;
      this.menuItem2.Text = "&Window";
      // 
      // MdiParentForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(424, 377);
      this.IsMdiContainer = true;
      this.Menu = this.mainMenu1;
      this.Name = "MdiParentForm";
      this.Text = "RatesOfReturn";

    }
    #endregion

    void fileNewMenuItem_Click(object sender, EventArgs e) {
      // Create and show a new child
      RatesOfReturnForm child = new RatesOfReturnForm();
      child.MdiParent = this;
      child.Show();
    }

    void fileOpenMenuItem_Click(object sender, EventArgs e) {
      OpenDocument(null);
    }

    // For use by Main in processing a file passed via the command line
    public void OpenDocument(string fileName) {
      // Let child do the opening
      RatesOfReturnForm child = new RatesOfReturnForm();
      if( child.OpenDocument(fileName) ) {
        child.MdiParent = this;
        child.Show();
      }
      else {
        child.Close();
      }
    }

    void fileExitMenuItem_Click(object sender, EventArgs e) {
      // Children will decide if this is allowed or not
      this.Close();
    }

    void helpAboutMenuItem_Click(object sender, EventArgs e) {
      MessageBox.Show("RatesOfReturn by Chris Sells, 2003\r\nEnjoy.", "About RatesOfReturn");
    }

  }
}
