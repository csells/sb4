// shellapi.cs
using System;
using System.Runtime.InteropServices;

class ShellApi {
  public enum ShellAddToRecentDocsFlags {
    Pidl = 0x001,
    Path = 0x002, // This is actually PathA
    //PathA = 0x002, // Avoiding these to ensure maximum reach
    //PathW = 0x003,
  }

  // NOTE: The reason for the CharSet.Ansi and limiting to just PathA in
  // the enum is to ensure that the flag and the CharSet match up
  [DllImport("shell32.dll", CharSet = CharSet.Ansi)]
  public static extern void SHAddToRecentDocs(ShellAddToRecentDocsFlags flag, string path);

  [DllImport("shell32.dll")]
  public static extern void SHAddToRecentDocs(ShellAddToRecentDocsFlags flag, IntPtr pidl);

  public static void AddToRecentDocs(string path) {
    // Use ANSI for maximum reach
    SHAddToRecentDocs(ShellAddToRecentDocsFlags.Path, path);
  }
}












