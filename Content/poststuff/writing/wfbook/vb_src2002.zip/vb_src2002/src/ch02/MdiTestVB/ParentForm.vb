Public Class ParentForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents cmdCascade As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem7 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents cmdWindowArrangeIcons As System.Windows.Forms.MenuItem
    Friend WithEvents cmdWindowTileChildrenVert As System.Windows.Forms.MenuItem
    Friend WithEvents cmdWindowTileChildrenHoriz As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem8 As System.Windows.Forms.MenuItem
    Friend WithEvents statusBar1 As System.Windows.Forms.StatusBar
    Friend WithEvents cmdFileNewChild As System.Windows.Forms.MenuItem
    Friend WithEvents cmdFileExit As System.Windows.Forms.MenuItem
    Friend WithEvents treeView1 As System.Windows.Forms.TreeView
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem9 As System.Windows.Forms.MenuItem
    Friend WithEvents splitter1 As System.Windows.Forms.Splitter
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cmdCascade = New System.Windows.Forms.MenuItem()
        Me.menuItem7 = New System.Windows.Forms.MenuItem()
        Me.menuItem3 = New System.Windows.Forms.MenuItem()
        Me.cmdWindowArrangeIcons = New System.Windows.Forms.MenuItem()
        Me.cmdWindowTileChildrenVert = New System.Windows.Forms.MenuItem()
        Me.cmdWindowTileChildrenHoriz = New System.Windows.Forms.MenuItem()
        Me.menuItem8 = New System.Windows.Forms.MenuItem()
        Me.statusBar1 = New System.Windows.Forms.StatusBar()
        Me.cmdFileNewChild = New System.Windows.Forms.MenuItem()
        Me.cmdFileExit = New System.Windows.Forms.MenuItem()
        Me.treeView1 = New System.Windows.Forms.TreeView()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu()
        Me.menuItem1 = New System.Windows.Forms.MenuItem()
        Me.menuItem9 = New System.Windows.Forms.MenuItem()
        Me.splitter1 = New System.Windows.Forms.Splitter()
        Me.SuspendLayout()
        '
        'cmdCascade
        '
        Me.cmdCascade.Index = 1
        Me.cmdCascade.Text = "&Cascade"
        '
        'menuItem7
        '
        Me.menuItem7.Index = 4
        Me.menuItem7.Text = "-"
        '
        'menuItem3
        '
        Me.menuItem3.Index = 1
        Me.menuItem3.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.cmdWindowArrangeIcons, Me.cmdCascade, Me.cmdWindowTileChildrenVert, Me.cmdWindowTileChildrenHoriz, Me.menuItem7, Me.menuItem8})
        Me.menuItem3.MergeOrder = 2
        Me.menuItem3.Text = "&Window"
        '
        'cmdWindowArrangeIcons
        '
        Me.cmdWindowArrangeIcons.Index = 0
        Me.cmdWindowArrangeIcons.Text = "&Arrange Icons"
        '
        'cmdWindowTileChildrenVert
        '
        Me.cmdWindowTileChildrenVert.Index = 2
        Me.cmdWindowTileChildrenVert.Text = "Tile Children &Vertically"
        '
        'cmdWindowTileChildrenHoriz
        '
        Me.cmdWindowTileChildrenHoriz.Index = 3
        Me.cmdWindowTileChildrenHoriz.Text = "Tile Children &Horizontally"
        '
        'menuItem8
        '
        Me.menuItem8.Index = 5
        Me.menuItem8.MdiList = True
        Me.menuItem8.Text = "Window&s"
        '
        'statusBar1
        '
        Me.statusBar1.Location = New System.Drawing.Point(0, 179)
        Me.statusBar1.Name = "statusBar1"
        Me.statusBar1.Size = New System.Drawing.Size(352, 22)
        Me.statusBar1.TabIndex = 4
        Me.statusBar1.Text = "Ready"
        '
        'cmdFileNewChild
        '
        Me.cmdFileNewChild.Index = 0
        Me.cmdFileNewChild.Shortcut = System.Windows.Forms.Shortcut.CtrlN
        Me.cmdFileNewChild.Text = "&New Child"
        '
        'cmdFileExit
        '
        Me.cmdFileExit.Index = 2
        Me.cmdFileExit.MergeOrder = 2
        Me.cmdFileExit.Text = "E&xit"
        '
        'treeView1
        '
        Me.treeView1.Dock = System.Windows.Forms.DockStyle.Left
        Me.treeView1.ImageIndex = -1
        Me.treeView1.Location = New System.Drawing.Point(3, 0)
        Me.treeView1.Name = "treeView1"
        Me.treeView1.Nodes.AddRange(New System.Windows.Forms.TreeNode() {New System.Windows.Forms.TreeNode("Children")})
        Me.treeView1.SelectedImageIndex = -1
        Me.treeView1.Size = New System.Drawing.Size(121, 179)
        Me.treeView1.TabIndex = 5
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1, Me.menuItem3})
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.cmdFileNewChild, Me.menuItem9, Me.cmdFileExit})
        Me.menuItem1.MergeType = System.Windows.Forms.MenuMerge.MergeItems
        Me.menuItem1.Text = "&File"
        '
        'menuItem9
        '
        Me.menuItem9.Index = 1
        Me.menuItem9.MergeOrder = 2
        Me.menuItem9.Text = "-"
        '
        'splitter1
        '
        Me.splitter1.Name = "splitter1"
        Me.splitter1.Size = New System.Drawing.Size(3, 179)
        Me.splitter1.TabIndex = 6
        Me.splitter1.TabStop = False
        '
        'ParentForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(352, 201)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.treeView1, Me.splitter1, Me.statusBar1})
        Me.IsMdiContainer = True
        Me.Menu = Me.mainMenu1
        Me.Name = "ParentForm"
        Me.Text = "MDI Parent"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Dim nextChild As Integer = 1


    Public Sub ChildClosed(ByVal sender As Object, ByVal e As EventArgs)
        Dim node As TreeNode
        For Each node In treeView1.Nodes(0).Nodes
            If node.Tag Is sender Then
                treeView1.Nodes(0).Nodes.Remove(node)
                Exit For
            End If
        Next
    End Sub

    Private Sub cmdFileNewChild_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdFileNewChild.Click
        ' Create and show new MDI child
        Dim child As Form = New ChildForm()
        child.Text = "MDI Child " & nextChild.ToString()
        AddHandler child.Closed, AddressOf ChildClosed
        nextChild = nextChild + 1
        child.MdiParent = Me
        child.Show()

        ' Add node to treeview
        Dim node As TreeNode = New TreeNode(child.Text)
        node.Tag = child
        treeView1.Nodes(0).Nodes.Add(node)
        treeView1.Nodes(0).Expand()
    End Sub

    Private Sub cmdFileExit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdFileExit.Click
        Close()
    End Sub

    Private Sub cmdWindowArrangeIcons_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdWindowArrangeIcons.Click
        Me.LayoutMdi(MdiLayout.ArrangeIcons)
    End Sub

    Private Sub cmdCascade_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCascade.Click
        Me.LayoutMdi(MdiLayout.Cascade)
    End Sub

    Private Sub cmdWindowTileChildrenVert_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdWindowTileChildrenVert.Click
        Me.LayoutMdi(MdiLayout.TileVertical)
    End Sub

    Private Sub cmdWindowTileChildrenHoriz_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdWindowTileChildrenHoriz.Click
        Me.LayoutMdi(MdiLayout.TileHorizontal)
    End Sub

    Private Sub treeView1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles treeView1.Click
        ' Activate MDI child based on selection in treeview
        Dim child As Form
        If TypeOf (treeView1.SelectedNode.Tag) Is Form Then
            child = CType(treeView1.SelectedNode.Tag, Form)
        End If

        If Not child Is Nothing Then child.Activate()

    End Sub
End Class
