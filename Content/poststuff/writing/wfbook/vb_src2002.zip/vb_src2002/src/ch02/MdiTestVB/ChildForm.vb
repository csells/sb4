Public Class ChildForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuItem11 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents cmdFileClose As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem13 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem5 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem4 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem6 As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu()
        Me.menuItem11 = New System.Windows.Forms.MenuItem()
        Me.menuItem1 = New System.Windows.Forms.MenuItem()
        Me.cmdFileClose = New System.Windows.Forms.MenuItem()
        Me.menuItem13 = New System.Windows.Forms.MenuItem()
        Me.menuItem5 = New System.Windows.Forms.MenuItem()
        Me.menuItem4 = New System.Windows.Forms.MenuItem()
        Me.menuItem6 = New System.Windows.Forms.MenuItem()
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem11, Me.menuItem13})
        '
        'menuItem11
        '
        Me.menuItem11.Index = 0
        Me.menuItem11.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1, Me.cmdFileClose})
        Me.menuItem11.MergeType = System.Windows.Forms.MenuMerge.MergeItems
        Me.menuItem11.Text = "&File"
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MergeOrder = 1
        Me.menuItem1.Text = "&Save"
        '
        'cmdFileClose
        '
        Me.cmdFileClose.Index = 1
        Me.cmdFileClose.MergeOrder = 1
        Me.cmdFileClose.Text = "&Close"
        '
        'menuItem13
        '
        Me.menuItem13.Index = 1
        Me.menuItem13.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem5, Me.menuItem4, Me.menuItem6})
        Me.menuItem13.MergeOrder = 1
        Me.menuItem13.Text = "&Edit"
        '
        'menuItem5
        '
        Me.menuItem5.Index = 0
        Me.menuItem5.Text = "Cu&t"
        '
        'menuItem4
        '
        Me.menuItem4.Index = 1
        Me.menuItem4.Text = "&Copy"
        '
        'menuItem6
        '
        Me.menuItem6.Index = 2
        Me.menuItem6.Text = "&Paste"
        '
        'ChildForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(168, 147)
        Me.Menu = Me.mainMenu1
        Me.Name = "ChildForm"
        Me.Text = "MDI Child"

    End Sub

#End Region

    Private Sub cmdFileClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdFileClose.Click
        Close()
    End Sub
End Class
