Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents tabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents tabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents textBox1 As System.Windows.Forms.TextBox
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents textBox2 As System.Windows.Forms.TextBox
    Friend WithEvents textBox3 As System.Windows.Forms.TextBox
    Friend WithEvents tabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents splitter1 As System.Windows.Forms.Splitter
    Friend WithEvents groupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents listBox1 As System.Windows.Forms.ListBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.tabControl1 = New System.Windows.Forms.TabControl()
        Me.tabPage1 = New System.Windows.Forms.TabPage()
        Me.textBox1 = New System.Windows.Forms.TextBox()
        Me.label1 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.label3 = New System.Windows.Forms.Label()
        Me.textBox2 = New System.Windows.Forms.TextBox()
        Me.textBox3 = New System.Windows.Forms.TextBox()
        Me.tabPage2 = New System.Windows.Forms.TabPage()
        Me.splitter1 = New System.Windows.Forms.Splitter()
        Me.groupBox1 = New System.Windows.Forms.GroupBox()
        Me.listBox1 = New System.Windows.Forms.ListBox()
        Me.tabControl1.SuspendLayout()
        Me.tabPage1.SuspendLayout()
        Me.groupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'tabControl1
        '
        Me.tabControl1.Controls.AddRange(New System.Windows.Forms.Control() {Me.tabPage1, Me.tabPage2})
        Me.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tabControl1.Location = New System.Drawing.Point(131, 0)
        Me.tabControl1.Name = "tabControl1"
        Me.tabControl1.SelectedIndex = 0
        Me.tabControl1.Size = New System.Drawing.Size(173, 134)
        Me.tabControl1.TabIndex = 5
        '
        'tabPage1
        '
        Me.tabPage1.Controls.AddRange(New System.Windows.Forms.Control() {Me.textBox1, Me.label1, Me.label2, Me.label3, Me.textBox2, Me.textBox3})
        Me.tabPage1.Location = New System.Drawing.Point(4, 22)
        Me.tabPage1.Name = "tabPage1"
        Me.tabPage1.Size = New System.Drawing.Size(165, 108)
        Me.tabPage1.TabIndex = 0
        Me.tabPage1.Text = "Name"
        '
        'textBox1
        '
        Me.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.textBox1.Location = New System.Drawing.Point(56, 8)
        Me.textBox1.Name = "textBox1"
        Me.textBox1.TabIndex = 7
        Me.textBox1.Text = "Joe"
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(8, 8)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(40, 20)
        Me.label1.TabIndex = 4
        Me.label1.Text = "First"
        Me.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(8, 40)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(40, 20)
        Me.label2.TabIndex = 2
        Me.label2.Text = "Middle"
        Me.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'label3
        '
        Me.label3.Location = New System.Drawing.Point(8, 72)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(40, 20)
        Me.label3.TabIndex = 3
        Me.label3.Text = "Last"
        Me.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'textBox2
        '
        Me.textBox2.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.textBox2.Location = New System.Drawing.Point(56, 40)
        Me.textBox2.Name = "textBox2"
        Me.textBox2.TabIndex = 6
        Me.textBox2.Text = "Bob"
        '
        'textBox3
        '
        Me.textBox3.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.textBox3.Location = New System.Drawing.Point(56, 72)
        Me.textBox3.Name = "textBox3"
        Me.textBox3.TabIndex = 5
        Me.textBox3.Text = "Programmer"
        '
        'tabPage2
        '
        Me.tabPage2.Location = New System.Drawing.Point(4, 22)
        Me.tabPage2.Name = "tabPage2"
        Me.tabPage2.Size = New System.Drawing.Size(165, 108)
        Me.tabPage2.TabIndex = 1
        Me.tabPage2.Text = "Address"
        Me.tabPage2.Visible = False
        '
        'splitter1
        '
        Me.splitter1.Location = New System.Drawing.Point(128, 0)
        Me.splitter1.Name = "splitter1"
        Me.splitter1.Size = New System.Drawing.Size(3, 134)
        Me.splitter1.TabIndex = 4
        Me.splitter1.TabStop = False
        '
        'groupBox1
        '
        Me.groupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.listBox1})
        Me.groupBox1.Dock = System.Windows.Forms.DockStyle.Left
        Me.groupBox1.Name = "groupBox1"
        Me.groupBox1.Size = New System.Drawing.Size(128, 134)
        Me.groupBox1.TabIndex = 3
        Me.groupBox1.TabStop = False
        Me.groupBox1.Text = "Select a person:"
        '
        'listBox1
        '
        Me.listBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.listBox1.IntegralHeight = False
        Me.listBox1.Items.AddRange(New Object() {"Chris", "Joe", "Pete", "Fred"})
        Me.listBox1.Location = New System.Drawing.Point(3, 16)
        Me.listBox1.Name = "listBox1"
        Me.listBox1.Size = New System.Drawing.Size(122, 115)
        Me.listBox1.TabIndex = 0
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(304, 134)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.tabControl1, Me.splitter1, Me.groupBox1})
        Me.Name = "Form1"
        Me.Text = "Grouping"
        Me.tabControl1.ResumeLayout(False)
        Me.tabPage1.ResumeLayout(False)
        Me.groupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

End Class
