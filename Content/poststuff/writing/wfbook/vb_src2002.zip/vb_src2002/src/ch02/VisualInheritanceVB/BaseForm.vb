Public Class BaseForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents fileExitMenuItem As System.Windows.Forms.MenuItem
    Protected WithEvents statusBar As System.Windows.Forms.StatusBar
    Friend WithEvents menuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents helpAboutMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.menuItem1 = New System.Windows.Forms.MenuItem()
        Me.fileExitMenuItem = New System.Windows.Forms.MenuItem()
        Me.statusBar = New System.Windows.Forms.StatusBar()
        Me.menuItem3 = New System.Windows.Forms.MenuItem()
        Me.helpAboutMenuItem = New System.Windows.Forms.MenuItem()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu()
        Me.SuspendLayout()
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.fileExitMenuItem})
        Me.menuItem1.Text = "&File"
        '
        'fileExitMenuItem
        '
        Me.fileExitMenuItem.Index = 0
        Me.fileExitMenuItem.Text = "E&xit"
        '
        'statusBar
        '
        Me.statusBar.Location = New System.Drawing.Point(0, 72)
        Me.statusBar.Name = "statusBar"
        Me.statusBar.Size = New System.Drawing.Size(176, 22)
        Me.statusBar.TabIndex = 1
        Me.statusBar.Text = "Ready"
        '
        'menuItem3
        '
        Me.menuItem3.Index = 1
        Me.menuItem3.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.helpAboutMenuItem})
        Me.menuItem3.Text = "&Help"
        '
        'helpAboutMenuItem
        '
        Me.helpAboutMenuItem.Index = 0
        Me.helpAboutMenuItem.Text = "&About..."
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1, Me.menuItem3})
        '
        'BaseForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(176, 94)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.statusBar})
        Me.Menu = Me.mainMenu1
        Me.Name = "BaseForm"
        Me.Text = "BaseForm"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub fileExitMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles fileExitMenuItem.Click
        Me.Close()
    End Sub

    Private Sub helpAboutMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles helpAboutMenuItem.Click
        MessageBox.Show("Ain't visual inheritance cool?", "About")
    End Sub

    Shared Sub Main()
        Application.Run(New BaseForm())
    End Sub
End Class
