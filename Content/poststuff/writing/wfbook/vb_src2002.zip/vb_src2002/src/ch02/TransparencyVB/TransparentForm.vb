Imports System.Drawing
Imports System.Drawing.Drawing2D


Public Class TransparentForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        Me.SetStyle(ControlStyles.ResizeRedraw, True)
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'TransparentForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(208, 68)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "TransparentForm"
        Me.Text = "Transparency Test"

    End Sub

#End Region

    Private Sub TransparentForm_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        Dim g As Graphics = e.Graphics

        Dim _pen As Pen = New Pen(Color.DarkBlue, 4)
        Dim rect As Rectangle = Me.ClientRectangle
        rect.Inflate(-2, -2)
        g.FillEllipse(Brushes.Yellow, rect)
        g.DrawEllipse(_pen, rect)
        _pen.Dispose()

        Dim _font As Font = New Font(Me.Font, FontStyle.Bold)
        Dim format As StringFormat = New StringFormat()
        format.Alignment = StringAlignment.Center
        format.LineAlignment = StringAlignment.Center
        ' RectangleF.op_implicit(rect) converts from a Rectangle (Me.ClientRectangle)
        ' to a RectangleF.  op_implicit is the Visual Basic .NET representation of
        ' the implicit conversion overload as available in C#
        g.DrawString("an ellipse", _font, Brushes.DarkBlue, RectangleF.op_Implicit(Me.ClientRectangle), format)
        _font.Dispose()
    End Sub

    Sub SetEllipseRegion()
        ' Assume: Me.FormBorderStyle = FormBorderStyle.None
        Dim rect As Rectangle = Me.ClientRectangle
        Dim path As GraphicsPath = New GraphicsPath()
        path.AddEllipse(RectangleF.op_Implicit(rect))
        Me.Region = New Region(path)
        path.Dispose()
    End Sub

    Private Sub TransparentForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        SetEllipseRegion()
    End Sub

    Private Sub TransparentForm_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.SizeChanged
        SetEllipseRegion()
    End Sub

    ' Dim downpoint As Point = Point.Empty

    Private Sub TransparentForm_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseDown
        ' If e.Button <> MouseButtons.Left Then Exit Sub
        ' downpoint = New Point(e.X, e.Y)
    End Sub

    Private Sub TransparentForm_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseMove
        ' If downpoint = Point.Empty Then Exit Sub
        ' Dim location As Point = New Point(me.Left + e.X - downpoint.X, me.Top + e.Y - downpoint.Y)
        ' Me.Location = location
    End Sub

    Private Sub TransparentForm_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseUp
        ' If e.Button <> MouseButtons.Left Then Exit Sub
        ' downpoint = Point.Empty
    End Sub

    Private Sub TransparentForm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        Dim location As Point = New Point(Me.Left, Me.Top)

        Select Case e.KeyCode
            Case Keys.I, Keys.Up
                location.Y = location.Y - 1

            Case Keys.J, Keys.Left
                location.X = location.X - 1

            Case Keys.K, Keys.Down
                location.Y = location.Y + 1

            Case Keys.L, Keys.Right
                location.X = location.X + 1
        End Select

        Me.Location = location
    End Sub

    'Protected Overrides Sub WndProc(ByRef m As System.Windows.Forms.Message)
    '    ' Let the base class have the first crack
    '    MyBase.WndProc(m)
    '    Dim WM_NCHITTEST As Integer = &H84
    '    If m.Msg <> WM_NCHITTEST Then Exit Sub

    '    ' If the user clicked on the client area,
    '    ' ask the OS to treat it as a click on the caption
    '    Dim HTCLIENT As Integer = 1
    '    Dim HTCAPTION As Integer = 2

    '    If m.Result.ToInt32() = HTCLIENT Then m.Result = New IntPtr(HTCAPTION)

    '    ' Check for a point along the edge
    '    ' TODO: just check along the edge
    '    Dim HTLEFT As Integer = 10
    '    Dim HTRIGHT As Integer = 11
    '    Dim HTTOP As Integer = 12
    '    Dim HTTOPLEFT As Integer = 13
    '    Dim HTTOPRIGHT As Integer = 14
    '    Dim HTBOTTOM As Integer = 15
    '    Dim HTBOTTOMLEFT As Integer = 16
    '    Dim HTBOTTOMRIGHT As Integer = 17

    '    ' Map point around center of ellipse
    '    Dim clientLocation As Point = Me.PointToClient(New Point(m.LParam.ToInt32))
    '    Dim x As Integer = clientLocation.X ' TODO
    '    Dim y As Integer = clientLocation.Y ' TODO

    '    ' Check for infinity and zero
    '    If x = 0 And y = 0 Then
    '        m.Result = New IntPtr(HTCAPTION)
    '        Exit Sub
    '    ElseIf x = 0 And y >= 0 Then
    '        m.Result = New IntPtr(HTRIGHT)
    '        Exit Sub
    '    ElseIf x = 0 Then
    '        m.Result = New IntPtr(HTLEFT)
    '        Exit Sub
    '    ElseIf y = 0 And x >= 0 Then
    '        m.Result = New IntPtr(HTTOP)
    '        Exit Sub
    '    ElseIf y = 0 Then
    '        m.Result = New IntPtr(HTBOTTOM)
    '        Exit Sub
    '    Else
    '        Debug.Assert(x <> 0 And y <> 0)
    '    End If

    '    Dim slopeAbs As Double = Math.Abs(CDbl(y) / CDbl(x))
    '    If x > 0 And y > 0 Then
    '        ' Q1
    '        If slopeAbs > 2 Then
    '            m.Result = New IntPtr(HTTOP)
    '        ElseIf slopeAbs < 0.5 Then
    '            m.Result = New IntPtr(HTRIGHT)
    '        Else
    '            m.Result = New IntPtr(HTTOPRIGHT)
    '        End If
    '    ElseIf x > 0 And y < 0 Then
    '        ' Q2
    '        If slopeAbs > 2 Then
    '            m.Result = New IntPtr(HTBOTTOM)
    '        ElseIf slopeAbs < 0.5 Then
    '            m.Result = New IntPtr(HTRIGHT)
    '        Else
    '            m.Result = New IntPtr(HTBOTTOMRIGHT)
    '        End If
    '    ElseIf x < 0 And y < 0 Then
    '        ' Q3
    '        If slopeAbs > 2 Then
    '            m.Result = New IntPtr(HTBOTTOM)
    '        ElseIf slopeAbs < 0.5 Then
    '            m.Result = New IntPtr(HTLEFT)
    '        Else
    '            m.Result = New IntPtr(HTBOTTOMLEFT)
    '        End If
    '    Else
    '        ' Q4
    '        Debug.Assert(x < 0 And y > 0)
    '        If slopeAbs > 2 Then
    '            m.Result = New IntPtr(HTTOP)
    '        ElseIf slopeAbs < 0.5 Then
    '            m.Result = New IntPtr(HTLEFT)
    '        Else
    '            m.Result = New IntPtr(HTTOPLEFT)
    '        End If
    '    End If

    'End Sub
End Class



































