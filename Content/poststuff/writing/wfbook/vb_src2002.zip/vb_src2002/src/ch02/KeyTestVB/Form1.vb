Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents keyDataLabel As System.Windows.Forms.Label
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents keyCodeLabel As System.Windows.Forms.Label
    Friend WithEvents modifiersLabel As System.Windows.Forms.Label
    Friend WithEvents label4 As System.Windows.Forms.Label
    Friend WithEvents keyValueLabel As System.Windows.Forms.Label
    Friend WithEvents label5 As System.Windows.Forms.Label
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents keyCharLabel As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.keyDataLabel = New System.Windows.Forms.Label()
        Me.label1 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.keyCodeLabel = New System.Windows.Forms.Label()
        Me.modifiersLabel = New System.Windows.Forms.Label()
        Me.label4 = New System.Windows.Forms.Label()
        Me.keyValueLabel = New System.Windows.Forms.Label()
        Me.label5 = New System.Windows.Forms.Label()
        Me.label3 = New System.Windows.Forms.Label()
        Me.keyCharLabel = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'keyDataLabel
        '
        Me.keyDataLabel.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.keyDataLabel.Location = New System.Drawing.Point(120, 8)
        Me.keyDataLabel.Name = "keyDataLabel"
        Me.keyDataLabel.Size = New System.Drawing.Size(228, 23)
        Me.keyDataLabel.TabIndex = 9
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(8, 8)
        Me.label1.Name = "label1"
        Me.label1.TabIndex = 5
        Me.label1.Text = "KeyData"
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(8, 40)
        Me.label2.Name = "label2"
        Me.label2.TabIndex = 6
        Me.label2.Text = "KeyCode"
        '
        'keyCodeLabel
        '
        Me.keyCodeLabel.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.keyCodeLabel.Location = New System.Drawing.Point(120, 40)
        Me.keyCodeLabel.Name = "keyCodeLabel"
        Me.keyCodeLabel.Size = New System.Drawing.Size(228, 23)
        Me.keyCodeLabel.TabIndex = 10
        '
        'modifiersLabel
        '
        Me.modifiersLabel.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.modifiersLabel.Location = New System.Drawing.Point(120, 72)
        Me.modifiersLabel.Name = "modifiersLabel"
        Me.modifiersLabel.Size = New System.Drawing.Size(228, 23)
        Me.modifiersLabel.TabIndex = 11
        '
        'label4
        '
        Me.label4.Location = New System.Drawing.Point(8, 72)
        Me.label4.Name = "label4"
        Me.label4.TabIndex = 4
        Me.label4.Text = "Modifiers"
        '
        'keyValueLabel
        '
        Me.keyValueLabel.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.keyValueLabel.Location = New System.Drawing.Point(120, 104)
        Me.keyValueLabel.Name = "keyValueLabel"
        Me.keyValueLabel.Size = New System.Drawing.Size(228, 23)
        Me.keyValueLabel.TabIndex = 8
        '
        'label5
        '
        Me.label5.Location = New System.Drawing.Point(8, 104)
        Me.label5.Name = "label5"
        Me.label5.TabIndex = 3
        Me.label5.Text = "KeyValue"
        '
        'label3
        '
        Me.label3.Location = New System.Drawing.Point(8, 136)
        Me.label3.Name = "label3"
        Me.label3.TabIndex = 2
        Me.label3.Text = "KeyChar"
        '
        'keyCharLabel
        '
        Me.keyCharLabel.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.keyCharLabel.Location = New System.Drawing.Point(120, 136)
        Me.keyCharLabel.Name = "keyCharLabel"
        Me.keyCharLabel.Size = New System.Drawing.Size(228, 23)
        Me.keyCharLabel.TabIndex = 7
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(328, 174)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.keyDataLabel, Me.label1, Me.label2, Me.keyCodeLabel, Me.modifiersLabel, Me.label4, Me.keyValueLabel, Me.label5, Me.label3, Me.keyCharLabel})
        Me.Name = "Form1"
        Me.Text = "KeyTest"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        keyDataLabel.Text = e.KeyData.ToString()
        keyCodeLabel.Text = e.KeyCode.ToString()
        modifiersLabel.Text = e.Modifiers.ToString()
        keyValueLabel.Text = e.KeyValue.ToString()
    End Sub

    Private Sub Form1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles MyBase.KeyPress
        keyCharLabel.Text = e.KeyChar.ToString()
    End Sub
End Class
