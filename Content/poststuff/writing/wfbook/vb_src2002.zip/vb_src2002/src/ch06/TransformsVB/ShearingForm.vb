Imports System.Drawing
Imports System.Drawing.Drawing2D


Public Class ShearingForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
        Me.Text = "ShearingForm"
    End Sub

#End Region


    Sub Foo(ByVal g As Graphics)
        Dim matrix As Matrix = New Matrix()
        matrix.Translate(10, 20)
        matrix.Scale(2, 3)
        matrix.Reset()
        matrix.Scale(2, 3)
        matrix.Translate(10, 20, MatrixOrder.Append)
        g.Transform = matrix
        g.DrawString("(0,0)", Me.Font, Brushes.Black, 0, 0)
    End Sub

    Sub ShearingForm_Paint(ByVal sender As Object, ByVal e As PaintEventArgs) Handles MyBase.Paint
        Dim g As Graphics = e.Graphics
        Dim width As Single = 200
        Dim height As Single = 50
        Dim format As StringFormat = New StringFormat()
        format.Alignment = StringAlignment.Center
        format.LineAlignment = StringAlignment.Center
        Dim rect As RectangleF = New RectangleF(0, 0, width, height)
        Dim matrix As Matrix = New Matrix()
        matrix.Translate(0, 0)
        matrix.Shear(0.0F, 0.0F)
        g.Transform = matrix
        g.DrawString("Shear(0,0)", Me.Font, Brushes.Black, rect, format)
        g.DrawRectangle(Pens.Black, rect.X, rect.Y, rect.Width, rect.Height)

        matrix = New Matrix()
        matrix.Shear(0.5F, 0.0F)
        matrix.Translate(width, 0)
        g.Transform = matrix
        g.DrawString("Shear(0.5,0)", Me.Font, Brushes.Black, rect, format)
        g.DrawRectangle(Pens.Black, rect.X, rect.Y, rect.Width, rect.Height)

        matrix = New Matrix()
        matrix.Translate(2 * width, 0)
        matrix.Shear(1.0F, 0.0F)
        g.Transform = matrix
        g.DrawString("Shear(1,0)", Me.Font, Brushes.Black, rect, format)
        g.DrawRectangle(Pens.Black, rect.X, rect.Y, rect.Width, rect.Height)
    End Sub
End Class
