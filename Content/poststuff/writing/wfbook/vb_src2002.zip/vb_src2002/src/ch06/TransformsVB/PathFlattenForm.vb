Imports System.Drawing
Imports System.Drawing.Drawing2D

Public Class PathFlattenForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'PathFlattenForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(416, 126)
        Me.Name = "PathFlattenForm"
        Me.Text = "PathFlattenForm"

    End Sub

#End Region


    Sub PathFlattenForm_Paint(ByVal sender As Object, ByVal e As PaintEventArgs) Handles MyBase.Paint
        Dim g As Graphics = e.Graphics
        Dim width As Single = Me.ClientSize.Width / 4.0F
        Dim height As Single = Me.ClientSize.Height
        Dim rect As RectangleF = New RectangleF(0, 0, width, height)
        Dim format As StringFormat = New StringFormat()
        format.Alignment = StringAlignment.Center
        format.LineAlignment = StringAlignment.Center

        Dim path As GraphicsPath = New GraphicsPath()
        path.Reset()
        path.AddEllipse(rect)
        g.DrawPath(Pens.Black, path)
        g.DrawString("Ellipse", Me.Font, Brushes.Black, rect, format)
        g.TranslateTransform(width, 0)

        path.Flatten(New Matrix(), 10)
        g.DrawPath(Pens.Black, path)
        g.DrawString("Flattened", Me.Font, Brushes.Black, rect, format)
        g.TranslateTransform(width, 0)

        path.Reset()
        path.AddEllipse(rect)

        Dim widenPen As Pen = New Pen(Color.Empty, 10)
        path.Widen(widenPen)
        g.DrawPath(Pens.Black, path)
        g.DrawString("Widened", Me.Font, Brushes.Black, rect, format)
        g.TranslateTransform(width, 0)

        path.Reset()
        path.AddEllipse(rect)

        Dim destPoints As PointF() = New PointF() {New PointF(width / 2, 0), New PointF(width, height), New PointF(0, height / 2)}
        Dim srcRect As RectangleF = New RectangleF(0, 0, width, height / 2)
        path.Warp(destPoints, srcRect)
        g.DrawPath(Pens.Black, path)
        g.DrawString("Warped", Me.Font, Brushes.Black, rect, format)
        g.TranslateTransform(width, 0)
    End Sub
End Class
