// MfcPadDoc.cpp : implementation of the CMfcPadDoc class
//

#include "stdafx.h"
#include "MfcPad.h"

#include "MfcPadDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMfcPadDoc

IMPLEMENT_DYNCREATE(CMfcPadDoc, CDocument)

BEGIN_MESSAGE_MAP(CMfcPadDoc, CDocument)
END_MESSAGE_MAP()


// CMfcPadDoc construction/destruction

CMfcPadDoc::CMfcPadDoc()
{
	// TODO: add one-time construction code here

}

CMfcPadDoc::~CMfcPadDoc()
{
}

BOOL CMfcPadDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}




// CMfcPadDoc serialization

void CMfcPadDoc::Serialize(CArchive& ar)
{
	// CEditView contains an edit control which handles all serialization
	reinterpret_cast<CEditView*>(m_viewList.GetHead())->SerializeRaw(ar);
}


// CMfcPadDoc diagnostics

#ifdef _DEBUG
void CMfcPadDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMfcPadDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CMfcPadDoc commands
