Imports System
Imports System.IO
Imports System.ComponentModel
Imports System.ComponentModel.Design
Imports System.Diagnostics
Imports System.Windows.Forms
Imports System.Runtime.Serialization
Imports System.Runtime.Serialization.Formatters.Binary

Public Class fileDocument
    Inherits System.ComponentModel.Component

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        ' integrate with container
        If Not Container Is Nothing Then Container.Add(Me)

        ' Required for designer suport
        InitializeComponent()
    End Sub

    Public Sub New()
        MyBase.New()

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents _saveFileDialog As System.Windows.Forms.SaveFileDialog
    Friend WithEvents _openFileDialog As System.Windows.Forms.OpenFileDialog
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me._saveFileDialog = New System.Windows.Forms.SaveFileDialog()
        Me._openFileDialog = New System.Windows.Forms.OpenFileDialog()
        '
        '_saveFileDialog
        '
        Me._saveFileDialog.FileName = "doc1"

    End Sub

#End Region

#Region "Public Events"
    Public Delegate Sub ChangedEventHandler(ByVal sender As Object, ByVal e As EventArgs)
    Public Event Changed As ChangedEventHandler
#End Region

#Region "Public Properties"

    Public Property Data() As Object
        Get

        End Get
        Set(ByVal Value As Object)

        End Set
    End Property
#End Region

#Region "Implementation"
    Private _fileOpenMenuItem As MenuItem = Nothing
    Private _fileSaveMenuItem As MenuItem = Nothing
    Private _fileSaveAsMenuItem As MenuItem = Nothing
    Private _fileCloseMenuItem As MenuItem = Nothing

    Protected _data As Object = Nothing
    Protected _dirty As Boolean = False
    Protected _fileName As String = ""
    Protected _host As Form = Nothing
    Protected _defaultExt As String = Nothing
    Protected _filter As String = Nothing
    Protected _master As fileDocument = Nothing

    Function Empty(ByVal s As String) As Boolean
        Return s Is Nothing Or s Is String.Empty
    End Function

    Protected ReadOnly Property ShowExtension() As Boolean
        Get
            'TODO: check the shell setting
            Return True
        End Get
    End Property

    Protected ReadOnly Property DefaultFileName() As String
        Get
            Return "Untitled" & IIf(Empty(defaultext), "", "." & defaultext)
        End Get
    End Property

    Protected ReadOnly Property CaptionFileName() As String
        Get
            Dim myfileName As String = fileName
            If Empty(filename) Then myfileName = DefaultFileName
            Return IIf(ShowExtension, Path.GetFileName(myfileName), Path.GetFileNameWithoutExtension(myfileName))
        End Get
        
    End Property
#End Region
End Class
