Public Class DigitalTimeEditorForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lblExample2 As System.Windows.Forms.Label
    Friend WithEvents btnAddFormatSpecifier As System.Windows.Forms.Button
    Friend WithEvents lblExample1 As System.Windows.Forms.Label
    Friend WithEvents txtFormat As System.Windows.Forms.TextBox
    Friend WithEvents lblExample As System.Windows.Forms.Label
    Friend WithEvents lblFormat As System.Windows.Forms.Label
    Friend WithEvents lstFormatSpecifiers As System.Windows.Forms.ComboBox
    Friend WithEvents timer As System.Windows.Forms.Timer
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnOK As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblExample2 = New System.Windows.Forms.Label()
        Me.btnAddFormatSpecifier = New System.Windows.Forms.Button()
        Me.lblExample1 = New System.Windows.Forms.Label()
        Me.txtFormat = New System.Windows.Forms.TextBox()
        Me.lblExample = New System.Windows.Forms.Label()
        Me.lblFormat = New System.Windows.Forms.Label()
        Me.lstFormatSpecifiers = New System.Windows.Forms.ComboBox()
        Me.timer = New System.Windows.Forms.Timer(Me.components)
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblExample2
        '
        Me.lblExample2.ForeColor = System.Drawing.Color.FromArgb(CType(0, Byte), CType(0, Byte), CType(192, Byte))
        Me.lblExample2.Location = New System.Drawing.Point(59, 64)
        Me.lblExample2.Name = "lblExample2"
        Me.lblExample2.Size = New System.Drawing.Size(296, 14)
        Me.lblExample2.TabIndex = 22
        Me.lblExample2.Text = "1/1/02 1:1:1 AM"
        '
        'btnAddFormatSpecifier
        '
        Me.btnAddFormatSpecifier.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.0!)
        Me.btnAddFormatSpecifier.Location = New System.Drawing.Point(214, 7)
        Me.btnAddFormatSpecifier.Name = "btnAddFormatSpecifier"
        Me.btnAddFormatSpecifier.Size = New System.Drawing.Size(29, 19)
        Me.btnAddFormatSpecifier.TabIndex = 18
        Me.btnAddFormatSpecifier.Text = "<<"
        '
        'lblExample1
        '
        Me.lblExample1.ForeColor = System.Drawing.Color.FromArgb(CType(0, Byte), CType(0, Byte), CType(192, Byte))
        Me.lblExample1.Location = New System.Drawing.Point(59, 37)
        Me.lblExample1.Name = "lblExample1"
        Me.lblExample1.Size = New System.Drawing.Size(296, 14)
        Me.lblExample1.TabIndex = 21
        Me.lblExample1.Text = "12/12/2002 12:12:12 AM"
        '
        'txtFormat
        '
        Me.txtFormat.Location = New System.Drawing.Point(61, 7)
        Me.txtFormat.Name = "txtFormat"
        Me.txtFormat.Size = New System.Drawing.Size(145, 20)
        Me.txtFormat.TabIndex = 17
        Me.txtFormat.Text = ""
        '
        'lblExample
        '
        Me.lblExample.Location = New System.Drawing.Point(7, 37)
        Me.lblExample.Name = "lblExample"
        Me.lblExample.TabIndex = 20
        Me.lblExample.Text = "Examples:"
        '
        'lblFormat
        '
        Me.lblFormat.Location = New System.Drawing.Point(7, 9)
        Me.lblFormat.Name = "lblFormat"
        Me.lblFormat.TabIndex = 16
        Me.lblFormat.Text = "Format:"
        '
        'lstFormatSpecifiers
        '
        Me.lstFormatSpecifiers.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.lstFormatSpecifiers.Location = New System.Drawing.Point(251, 7)
        Me.lstFormatSpecifiers.Name = "lstFormatSpecifiers"
        Me.lstFormatSpecifiers.Size = New System.Drawing.Size(145, 21)
        Me.lstFormatSpecifiers.TabIndex = 19
        '
        'btnCancel
        '
        Me.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnCancel.Location = New System.Drawing.Point(321, 69)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.TabIndex = 15
        Me.btnCancel.Text = "Cancel"
        '
        'btnOK
        '
        Me.btnOK.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnOK.Location = New System.Drawing.Point(234, 69)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.TabIndex = 14
        Me.btnOK.Text = "OK"
        '
        'DigitalTimeEditorForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(402, 98)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnAddFormatSpecifier, Me.lblExample1, Me.txtFormat, Me.lblExample, Me.lblFormat, Me.lstFormatSpecifiers, Me.btnCancel, Me.btnOK, Me.lblExample2})
        Me.Name = "DigitalTimeEditorForm"
        Me.Text = "Digital Time Editor Form"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private _digitalTimeFormat As String
    Private _exampleDateTime1 As DateTime = New DateTime(2002, 12, 31, 12, 59, 59)
    Private _exampleDateTime2 As DateTime = New DateTime(2002, 1, 1, 1, 1, 1)

    Public Property DigitalTimeFormat() As String
        Get
            Return _digitalTimeFormat
        End Get
        Set(ByVal Value As String)
            _digitalTimeFormat = Value
        End Set
    End Property

    Protected Overrides Sub OnLoad(ByVal e As System.EventArgs)
        MyBase.OnLoad(e)

        ' Set the textbox from the property
        txtFormat.Text = _digitalTimeFormat

        ' Build the examples based on the format
        lblExample1.Text = _exampleDateTime1.ToString(txtFormat.Text)
        lblExample2.Text = _exampleDateTime2.ToString(txtFormat.Text)

        ' Build the list
        Dim lst As DataTable = New DataTable("List")
        lst.Columns.Add(New DataColumn("Value", GetType(String)))
        lst.Columns.Add(New DataColumn("Display", GetType(String)))
        lst.Rows.Add(New Object() {"/", "/  (Date Separator)"})
        lst.Rows.Add(New Object() {":", ":  (Time Separator)"})
        lst.Rows.Add(New Object() {"d", "d  (Day: 1-31)"})
        lst.Rows.Add(New Object() {"dd", "dd  (Day: 01-31)"})
        lst.Rows.Add(New Object() {"ddd", "ddd  (Day Mon-Sun)"})
        lst.Rows.Add(New Object() {"H", "H  (Hour: 0-23)"})
        lst.Rows.Add(New Object() {"h", "h  (Hour: 1-12)"})
        lst.Rows.Add(New Object() {"HH", "HH  (Hour: 00-23)"})
        lst.Rows.Add(New Object() {"hh", "hh  (Hour: 01-12)"})
        lst.Rows.Add(New Object() {"M", "M   (Month: 1-12)"})
        lst.Rows.Add(New Object() {"m", "m  (Minute: 0-59)"})
        lst.Rows.Add(New Object() {"mm", "mm  (Minute: 00-59)"})
        lst.Rows.Add(New Object() {"MM", "MM  (Month: 01-12)"})
        lst.Rows.Add(New Object() {"MMM", "MMM  (Month: Jan-Dec)"})
        lst.Rows.Add(New Object() {"s", "s  (Second: 0-59)"})
        lst.Rows.Add(New Object() {"ss", "ss  (Second: 00-59)"})
        lst.Rows.Add(New Object() {"tt", "tt  (AM/PM)"})
        lst.Rows.Add(New Object() {"y", "y  (Year: 1-99)"})
        lst.Rows.Add(New Object() {"yy", "yy  (Year: 01-99)"})
        lst.Rows.Add(New Object() {"yyyy", "yyyy  (Year: 2001-2099)"})
        lstFormatSpecifiers.DataSource = lst
        lstFormatSpecifiers.ValueMember = "Value"
        lstFormatSpecifiers.DisplayMember = "Display"
    End Sub

    Private Sub btnOK_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnOK.Click
        DialogResult = Windows.Forms.DialogResult.OK
        _digitalTimeFormat = txtFormat.Text
        Me.Close()
    End Sub


    Private Sub btnAddFormatSpecifier_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAddFormatSpecifier.Click
        ' Add selected format specifier
        If lstFormatSpecifiers.Text <> "" Then
            txtFormat.Text = txtFormat.Text + lstFormatSpecifiers.SelectedValue
            txtFormat.Select(txtFormat.Text.Length, 0)
            txtFormat.Focus()
        End If
    End Sub


    Private Sub txtFormat_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtFormat.TextChanged
        lblExample1.Text = _exampleDateTime1.ToString(txtFormat.Text)
        lblExample2.Text = _exampleDateTime2.ToString(txtFormat.Text)
    End Sub
End Class
