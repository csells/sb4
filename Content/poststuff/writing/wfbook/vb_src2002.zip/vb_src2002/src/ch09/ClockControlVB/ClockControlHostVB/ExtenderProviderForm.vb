Public Class ExtenderProviderForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents clockControl1 As ClockControlLibrary.ClockControl
    Friend WithEvents pictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents pictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents pictureBox1 As System.Windows.Forms.PictureBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(ExtenderProviderForm))
        Me.clockControl1 = New ClockControlLibrary.ClockControl()
        Me.pictureBox3 = New System.Windows.Forms.PictureBox()
        Me.pictureBox2 = New System.Windows.Forms.PictureBox()
        Me.pictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.clockControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'clockControl1
        '
        Me.clockControl1.DigitalTimeFormat = "dd/MM/yyyy hh:mm:ss tt"
        Me.clockControl1.Face = ClockControlLibrary.ClockFace.Digital
        Me.clockControl1.FirstAlarm = New Date(2003, 1, 11, 18, 57, 58, 105)
        Me.clockControl1.Location = New System.Drawing.Point(9, 200)
        Me.clockControl1.Name = "clockControl1"
        Me.clockControl1.SecondAlarm = New Date(2003, 1, 11, 19, 7, 58, 105)
        Me.clockControl1.Size = New System.Drawing.Size(361, 54)
        Me.clockControl1.TabIndex = 7
        Me.clockControl1.Text = "clockControl1"
        '
        'pictureBox3
        '
        Me.pictureBox3.Image = CType(resources.GetObject("pictureBox3.Image"), System.Drawing.Bitmap)
        Me.pictureBox3.Location = New System.Drawing.Point(251, 9)
        Me.pictureBox3.Name = "pictureBox3"
        Me.pictureBox3.Size = New System.Drawing.Size(119, 184)
        Me.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pictureBox3.TabIndex = 6
        Me.pictureBox3.TabStop = False
        Me.clockControl1.SetTimeZoneModifier(Me.pictureBox3, "-19")
        '
        'pictureBox2
        '
        Me.pictureBox2.Image = CType(resources.GetObject("pictureBox2.Image"), System.Drawing.Bitmap)
        Me.pictureBox2.Location = New System.Drawing.Point(130, 9)
        Me.pictureBox2.Name = "pictureBox2"
        Me.pictureBox2.Size = New System.Drawing.Size(118, 184)
        Me.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pictureBox2.TabIndex = 5
        Me.pictureBox2.TabStop = False
        Me.clockControl1.SetTimeZoneModifier(Me.pictureBox2, "0")
        '
        'pictureBox1
        '
        Me.pictureBox1.Image = CType(resources.GetObject("pictureBox1.Image"), System.Drawing.Bitmap)
        Me.pictureBox1.Location = New System.Drawing.Point(9, 9)
        Me.pictureBox1.Name = "pictureBox1"
        Me.pictureBox1.Size = New System.Drawing.Size(118, 184)
        Me.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.pictureBox1.TabIndex = 4
        Me.pictureBox1.TabStop = False
        Me.clockControl1.SetTimeZoneModifier(Me.pictureBox1, "-11")
        '
        'ExtenderProviderForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(378, 263)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.clockControl1, Me.pictureBox3, Me.pictureBox2, Me.pictureBox1})
        Me.Name = "ExtenderProviderForm"
        Me.Text = "ExtenderProviderForm"
        CType(Me.clockControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

End Class
