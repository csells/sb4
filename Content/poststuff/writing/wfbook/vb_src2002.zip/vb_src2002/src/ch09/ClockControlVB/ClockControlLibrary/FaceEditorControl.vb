Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.Data
Imports System.Windows.Forms
Imports System.Windows.Forms.Design


Friend Class FaceEditorControl
    Inherits System.Windows.Forms.UserControl

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'UserControl overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents picDigital As System.Windows.Forms.PictureBox
    Friend WithEvents picAnalog As System.Windows.Forms.PictureBox
    Friend WithEvents picBoth As System.Windows.Forms.PictureBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FaceEditorControl))
        Me.picDigital = New System.Windows.Forms.PictureBox()
        Me.picAnalog = New System.Windows.Forms.PictureBox()
        Me.picBoth = New System.Windows.Forms.PictureBox()
        Me.SuspendLayout()
        '
        'picDigital
        '
        Me.picDigital.BackColor = System.Drawing.SystemColors.Highlight
        Me.picDigital.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.picDigital.Image = CType(resources.GetObject("picDigital.Image"), System.Drawing.Bitmap)
        Me.picDigital.Location = New System.Drawing.Point(151, 8)
        Me.picDigital.Name = "picDigital"
        Me.picDigital.Size = New System.Drawing.Size(65, 65)
        Me.picDigital.TabIndex = 11
        Me.picDigital.TabStop = False
        '
        'picAnalog
        '
        Me.picAnalog.BackColor = System.Drawing.SystemColors.Highlight
        Me.picAnalog.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.picAnalog.Image = CType(resources.GetObject("picAnalog.Image"), System.Drawing.Bitmap)
        Me.picAnalog.Location = New System.Drawing.Point(79, 8)
        Me.picAnalog.Name = "picAnalog"
        Me.picAnalog.Size = New System.Drawing.Size(65, 65)
        Me.picAnalog.TabIndex = 10
        Me.picAnalog.TabStop = False
        '
        'picBoth
        '
        Me.picBoth.BackColor = System.Drawing.SystemColors.Highlight
        Me.picBoth.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.picBoth.Image = CType(resources.GetObject("picBoth.Image"), System.Drawing.Bitmap)
        Me.picBoth.Location = New System.Drawing.Point(7, 8)
        Me.picBoth.Name = "picBoth"
        Me.picBoth.Size = New System.Drawing.Size(65, 65)
        Me.picBoth.TabIndex = 9
        Me.picBoth.TabStop = False
        '
        'FaceEditorControl
        '
        Me.BackColor = System.Drawing.Color.FromArgb(CType(236, Byte), CType(233, Byte), CType(216, Byte))
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.picDigital, Me.picAnalog, Me.picBoth})
        Me.Name = "FaceEditorControl"
        Me.Size = New System.Drawing.Size(223, 80)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private _face As ClockFace = ClockFace.Both
    Private _editorService As IWindowsFormsEditorService = Nothing

    Public Sub New(ByVal editorService As IWindowsFormsEditorService)
        InitializeComponent()
        _editorService = editorService
    End Sub


    Private Sub picBoth_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles picBoth.Click
        _face = ClockFace.Both
        ' Close the UI editor upon value selection
        _editorService.CloseDropDown()
    End Sub


    Private Sub picAnalog_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles picAnalog.Click
        _face = ClockFace.Analog
        ' Close the UI editor upon value selection
        _editorService.CloseDropDown()
    End Sub


    Private Sub picDigital_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles picDigital.Click
        _face = ClockFace.Digital
        ' Close the UI editor upon value selection
        _editorService.CloseDropDown()
    End Sub

    Protected Overrides Sub OnPaint(ByVal e As System.Windows.Forms.PaintEventArgs)
        ' Get currently selected control
        Dim selected As PictureBox
        If _face = ClockFace.Both Then
            selected = Me.picBoth
        ElseIf _face = ClockFace.Analog Then
            selected = Me.picAnalog
        Else
            selected = Me.picDigital
        End If

        ' Paint the border
        Dim g As Graphics = e.Graphics
        Dim _pen As Pen = New Pen(Color.Gray, 1)
        _pen.DashStyle = DashStyle.Dash
        g.DrawLine(_pen, New Point(selected.Left - 2, selected.Top - 2), New Point(selected.Left + selected.Width + 1, selected.Top - 2))
        g.DrawLine(_pen, New Point(selected.Left + selected.Width + 1, selected.Top - 2), New Point(selected.Left + selected.Width + 1, selected.Top + selected.Height + 1))
        g.DrawLine(_pen, New Point(selected.Left + selected.Width + 1, selected.Top + selected.Height + 1), New Point(selected.Left - 2, selected.Top + selected.Height + 1))
        g.DrawLine(_pen, New Point(selected.Left - 2, selected.Top + selected.Height + 1), New Point(selected.Left - 2, selected.Top - 2))
        _pen.Dispose()

        MyBase.OnPaint(e)
    End Sub

    Public Property Face() As ClockFace
        Get
            Return _face
        End Get
        Set(ByVal Value As ClockFace)
            _face = Value
            If _face = ClockFace.Both Then
                Me.picBoth.BackColor = Color.Red
                Exit Property
            End If
            If _face = ClockFace.Analog Then
                Me.picAnalog.BackColor = Color.Red
                Exit Property
            End If
            If _face = ClockFace.Digital Then
                Me.picDigital.BackColor = Color.Red
                Exit Property
            End If
        End Set
    End Property
End Class
