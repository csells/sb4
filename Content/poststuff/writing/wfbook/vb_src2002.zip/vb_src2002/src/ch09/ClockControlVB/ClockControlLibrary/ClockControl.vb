Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.ComponentModel.Design
Imports System.ComponentModel.Design.Serialization
Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.Drawing.Design
Imports System.Globalization
Imports System.Reflection
Imports System.Windows.Forms
Imports System.Windows.Forms.Design

#Region "ClockControlDesigner"

Public Class ClockControlDesigner
    Inherits ControlDesigner

    Private _clockControl As ClockControl = Nothing
    Private _showBorder As Boolean = True
    Private _showBorderVerb As DesignerVerb = Nothing

    Public Overrides Sub Initialize(ByVal component As IComponent)
        MyBase.Initialize(component)

        ' Get clock control shortcut reference
        _clockControl = CType(component, ClockControl)
    End Sub

    Protected Overrides Sub OnPaintAdornments(ByVal e As PaintEventArgs)
        MyBase.OnPaintAdornments(e)

        ' Don't show border if hidden or does not have an Analog face
        If Not (_showBorder) Or _clockControl.Face = ClockFace.Digital Then Exit Sub

        ' Draw border
        Dim g As Graphics = e.Graphics
        Dim _pen As Pen = New Pen(Color.Gray, 1)
        _pen.DashStyle = DashStyle.Dash
        g.DrawRectangle(_pen, 0, 0, _clockControl.Width - 1, _clockControl.Height - 1)
        _pen.Dispose()
    End Sub

    Private Function GetVerbText() As String
        Return IIf(_showBorder, "Hide Border", "Show Border")
    End Function

    Public Overrides ReadOnly Property Verbs() As DesignerVerbCollection
        Get
            ' Return new list of context menu items
            Dim _verbs As DesignerVerbCollection = New DesignerVerbCollection()
            _showBorderVerb = New DesignerVerb(GetVerbText(), New EventHandler(AddressOf ShowBorderClicked))
            _verbs.Add(_showBorderVerb)
            Return _verbs
        End Get
    End Property

    Private Sub ShowBorderClicked(ByVal sender As Object, ByVal e As EventArgs)
        ' Toggle property value
        ShowBorder = Not ShowBorder
    End Sub

    ' Provide implementation of ShowBorder to provide
    ' storage for created ShowBorder property
    Private Property ShowBorder() As Boolean
        Get
            Return _showBorder
        End Get
        Set(ByVal Value As Boolean)
            ' Change property value
            Dim prop As PropertyDescriptor = TypeDescriptor.GetProperties(GetType(ClockControl))("ShowBorder")
            Me.RaiseComponentChanging(prop)
            _showBorder = Value
            Me.RaiseComponentChanged(prop, Not (_showBorder), _showBorder)

            ' Toggle Show/Hide Border verb entry in context menu
            Dim menuservice As IMenuCommandService = CType(Me.GetService(GetType(IMenuCommandService)), IMenuCommandService)
            If Not menuservice Is Nothing Then
                ' Recreate Show/Hide Border verb
                If menuservice.Verbs.IndexOf(_showBorderVerb) >= 0 Then
                    menuservice.Verbs.Remove(_showBorderVerb)
                    _showBorderVerb = New DesignerVerb(GetVerbText(), New EventHandler(AddressOf ShowBorderClicked))
                    menuservice.Verbs.Add(_showBorderVerb)
                End If
            End If

            ' Update clock UI
            _clockControl.Refresh()
        End Set
    End Property

    Protected Overrides Sub PreFilterProperties(ByVal properties As IDictionary)
        MyBase.PreFilterProperties(properties)

        ' Create design-time-only property entry and add it to the 
        ' property browser's Design category
        properties("ShowBorder") = TypeDescriptor.CreateProperty(GetType(ClockControlDesigner), _
                                                                 "ShowBorder", _
                                                                 GetType(Boolean), _
                                                                 CategoryAttribute.Design, _
                                                                 DesignOnlyAttribute.Yes)
    End Sub

End Class
#End Region

#Region "HandConverter"
Public Class HandConverter
    Inherits ExpandableObjectConverter

    ' Don't need to override CanConvertTo if converting to string, as that's what base TypeConverter does
    ' Do need to override CanConvertFrom since it's base converts from InstanceDescriptor

    Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext, ByVal destinationType As Type) As Boolean
        If destinationType Is GetType(InstanceDescriptor) Then Return True
        Return MyBase.CanConvertTo(context, destinationType)
    End Function

    Public Overloads Overrides Function CanConvertFrom(ByVal context As ITypeDescriptorContext, ByVal sourceType As Type) As Boolean
        ' We can convert from a string to a Hand type
        If sourceType Is GetType(String) Then Return True
        Return MyBase.CanConvertFrom(context, sourceType)
    End Function

    Public Overloads Overrides Function ConvertFrom(ByVal context As ITypeDescriptorContext, ByVal info As CultureInfo, ByVal value As Object) As Object
        ' If converting from a string
        If TypeOf value Is String Then
            ' Build a Hand type
            Try
                ' Get hand property
                Dim propertyList As String = CStr(value)
                Dim properties As String() = propertyList.Split(";")
                Return New Hand(Color.FromName(properties(0).Trim()), Convert.ToInt32(properties(1)))
            Catch
            End Try
            Throw New ArgumentException("The arguments were not valid.")
        End If
        Return MyBase.ConvertFrom(context, info, value)

    End Function

    Public Overloads Overrides Function ConvertTo(ByVal context As ITypeDescriptorContext, ByVal culture As CultureInfo, ByVal value As Object, ByVal destinationType As Type)
        ' If source value is a hand type
        If TypeOf value Is Hand Then
            ' Conver to string
            If destinationType Is GetType(String) Then
                Dim _hand As Hand = CType(value, Hand)
                Dim mycolor As String = IIf(_hand.HandColor.IsNamedColor, _hand.HandColor.Name, _hand.HandColor.R + ", " + _hand.HandColor.G + ", " + _hand.HandColor.B)
                Return String.Format("{0}; {1}", mycolor, _hand.Width.ToString())
            End If

            ' Convert to InstanceDescriptor
            If destinationType Is GetType(InstanceDescriptor) Then
                Dim _hand As Hand = CType(value, Hand)
                Dim properties(2) As Object
                Dim types(2) As Type
                ' Color
                types(0) = GetType(Color)
                properties(0) = _hand.HandColor

                ' Width
                types(1) = GetType(Integer)
                properties(1) = _hand.Width

                ' Build constructor
                Dim ci As ConstructorInfo = GetType(Hand).GetConstructor(types)
                Return New InstanceDescriptor(ci, properties)
            End If
        End If
        ' Base ConvertTo if neither string nor InstanceDescriptor required
        Return MyBase.ConvertTo(context, culture, value, destinationType)
    End Function

    Public Overloads Overrides Function CreateInstance(ByVal context As ITypeDescriptorContext, ByVal propertyValues As IDictionary) As Object
        Return New Hand(CType(propertyValues("Color"), Color), CInt(propertyValues("Width")))
    End Function

    Public Overloads Overrides Function GetCreateInstanceSupported(ByVal context As ITypeDescriptorContext) As Boolean
        Return True
    End Function
End Class
#End Region

#Region "Hand"
Public Class Hand
    Private _color As Color = Color.Black
    Private _width As Integer = 1
    Public Sub New(ByVal newcolor As Color, ByVal width As Integer)
        _color = newcolor
        _width = width
    End Sub

    Public Property HandColor() As Color
        Get
            Return _color
        End Get
        Set(ByVal Value As Color)
            _color = Value
        End Set
    End Property

    Public Property Width() As Integer
        Get
            Return _width
        End Get
        Set(ByVal Value As Integer)
            _width = Value
        End Set
    End Property
End Class
#End Region

#Region "DigitalTimeFormatEditor"
Public Class DigitalTimeFormatEditor
    Inherits System.Drawing.Design.UITypeEditor

    Public Overloads Overrides Function GetEditStyle(ByVal context As ITypeDescriptorContext) As UITypeEditorEditStyle
        If Not context Is Nothing Then
            Return UITypeEditorEditStyle.Modal
        End If
        Return MyBase.GetEditStyle(context)
    End Function

    Public Overloads Overrides Function EditValue(ByVal context As ITypeDescriptorContext, ByVal provider As IServiceProvider, ByVal value As Object) As Object
        If (Not context Is Nothing) And (Not provider Is Nothing) Then
            ' Access the property browser's UI display service, IWindowsFormsEditorService
            Dim editorService As IWindowsFormsEditorService = CType(provider.GetService(GetType(IWindowsFormsEditorService)), IWindowsFormsEditorService)
            If Not editorService Is Nothing Then
                ' Create an instance of the UI editor
                Dim modalEditor As DigitalTimeEditorForm = New DigitalTimeEditorForm()
                ' Pass the UI editor the current property value
                modalEditor.DigitalTimeFormat = CStr(value)
                ' Display the UI editor
                If editorService.ShowDialog(modalEditor) = DialogResult.OK Then
                    ' Return the new property value from the editor
                    Return modalEditor.DigitalTimeFormat
                End If
            End If
        End If
        Return MyBase.EditValue(context, provider, value)
    End Function
End Class
#End Region

#Region "FaceEditor"
Public Class FaceEditor
    Inherits System.Drawing.Design.UITypeEditor

    Public Overloads Overrides Function GetEditStyle(ByVal context As ITypeDescriptorContext) As UITypeEditorEditStyle
        If Not context Is Nothing Then
            Return UITypeEditorEditStyle.DropDown
        End If
        Return (MyBase.GetEditStyle(context))
    End Function

    Public Overloads Overrides Function EditValue(ByVal context As ITypeDescriptorContext, ByVal provider As IServiceProvider, ByVal value As Object) As Object
        If (Not context Is Nothing) And (Not provider Is Nothing) Then
            ' Access the property browser's UI display service, IWindowsFormsEditorService
            Dim editorService As IWindowsFormsEditorService = CType(provider.GetService(GetType(IWindowsFormsEditorService)), IWindowsFormsEditorService)
            If Not editorService Is Nothing Then
                ' Create an instance of the UI editor, passing a reference to the editor service
                Dim dropDownEditor As FaceEditorControl = New FaceEditorControl(editorService)
                ' Pass the UI editor the current property value
                dropDownEditor.Face = CType(value, ClockFace)
                ' Display the UI editor
                editorService.DropDownControl(dropDownEditor)
                ' Return the new property value from the editor
                Return dropDownEditor.Face
            End If
        End If
        Return MyBase.EditValue(context, provider, value)
    End Function


End Class
#End Region

#Region "AlarmType Enumeration"
Public Enum AlarmType
    First
    Second
End Enum
#End Region

#Region "ClockFace Enumeration"
Public Enum ClockFace
    Analog = 0
    Digital = 1
    Both = 2
End Enum
#End Region



<ToolboxBitmap(GetType(ClockControlLibrary.ClockControl), "images.ClockControl.ico"), _
DefaultEvent("SoundTheAlarm"), _
DefaultProperty("Face"), _
ProvideProperty("TimeZoneModifier", GetType(Control)), _
Designer(GetType(ClockControlDesigner))> _
Public Class ClockControl
    Inherits System.Windows.Forms.Control
    Implements ISupportInitialize, IExtenderProvider

    Private _firstAlarm As DateTime = DateTime.Now
    Private _firstAlarmSounded As Boolean = False
    Private _secondAlarm As DateTime = DateTime.Now.AddMinutes(10)
    Private _secondAlarmSounded As Boolean = False
    Private _isItTimeForABreak As Boolean = True
    Private _timer As Timer = New Timer()
    Private _timeZoneModifier As Integer = 0
    Private _timeZoneModifiers As Hashtable = New Hashtable()
    Private _digitalTimeFormat As String = "dd/MM/yyyy hh:mm:ss tt"
    Private _face As ClockFace = ClockFace.Both
    Private _hourHand As Hand = New Hand(Color.Black, 1)
    Private _minuteHand As Hand = New Hand(Color.Black, 1)
    Private _secondHand As Hand = New Hand(Color.Red, 1)

    ' SoundTheAlarm event
    Public Delegate Sub onSoundTheAlarm(ByVal sender As Object, ByVal type As AlarmType)

    <Category("Notification")> _
    Public Event SoundTheAlarm As onSoundTheAlarm




#Region " Component Designer generated code "

    Public Sub New()
        ' Reduce flicker
        Me.SetStyle(ControlStyles.DoubleBuffer, True)
        Me.SetStyle(ControlStyles.AllPaintingInWmPaint, True)

        ' Redraw when resized
        Me.SetStyle(ControlStyles.ResizeRedraw, True)
    End Sub

    Protected Overloads Overrides Sub OnCreateControl()
        If Not DesignMode Then
            ' Initialize timer
            _timer.Interval = 1000
            AddHandler _timer.Tick, New EventHandler(AddressOf Me.timer_Tick)
            _timer.Enabled = True
        End If
    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            ' Clean up any resources being used
            _timer.Dispose()
            MyBase.Dispose(disposing)
        End If
    End Sub



#End Region



#Region "ISupportInitialize"

    Public Sub BeginInit() Implements System.ComponentModel.ISupportInitialize.BeginInit

    End Sub

    Public Sub EndInit() Implements ISupportInitialize.EndInit
        If Not Me.DesignMode Then
            ' Check alarm values
            If _firstAlarm >= _secondAlarm Then Throw New Exception("First alarm must come before the second alarm")
        End If
    End Sub

#End Region

#Region "IExtenderProvider"
    Public Function CanExtend(ByVal extendee As Object) As Boolean Implements IExtenderProvider.CanExtend
        ' Don't extend self
        If extendee Is Me Then Return False

        ' Extend suitable controls
        Return (TypeOf extendee Is PictureBox) Or (TypeOf extendee Is Panel)

    End Function

    <Category("Behavior"), _
    Description("Sets the timezone difference from the current time"), _
    DefaultValue("")> _
    Public Function GetTimeZoneModifier(ByVal extendee As Control) As String
        Return Convert.ToString(_timeZoneModifiers(extendee))
    End Function

    Public Sub SetTimeZoneModifier(ByVal extendee As Control, ByVal value As Object)
        Dim timeZoneModifier As String = CStr(value)
        ' If property isn't provided
        If ((timeZoneModifier = "") Or (timeZoneModifier Is Nothing)) Then
            ' Remove it
            _timeZoneModifiers.Remove(extendee)
            If Not Me.DesignMode Then RemoveHandler extendee.Click, New EventHandler(AddressOf extendee_Click)
        Else
            ' Add it, convert it to Int32 to make sure it's the right type
            _timeZoneModifiers(extendee) = Convert.ToInt32(timeZoneModifier)
            If Not Me.DesignMode Then AddHandler extendee.Click, New EventHandler(AddressOf extendee_Click)
        End If
    End Sub

    Private Sub extendee_Click(ByVal sender As Object, ByVal e As EventArgs)
        ' Update the time-zone
        _timeZoneModifier = CInt(_timeZoneModifiers(sender))
    End Sub
#End Region

#Region "Properties"
    <Browsable(False), _
    DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)> _
    Public Property IsItTimeForABreak() As Boolean
        Get
            Return _isItTimeForABreak
        End Get
        Set(ByVal Value As Boolean)
            _isItTimeForABreak = False
        End Set
    End Property

    <Category("Behavior"), _
    Description("First alarm...for the light-sleepers.")> _
    Public Property FirstAlarm() As DateTime
        Get
            Return _firstAlarm
        End Get
        Set(ByVal Value As DateTime)
            _firstAlarm = Value
        End Set
    End Property

    <Category("Behavior"), _
    Description("Second alarm...for the late_nighters.")> _
    Public Property SecondAlarm() As DateTime
        Get
            Return _secondAlarm
        End Get
        Set(ByVal Value As DateTime)
            _secondAlarm = Value
        End Set
    End Property

    <Category("Appearance"), _
    Description("The digital time format, constructed from .NET format specifiers"), _
    DefaultValue("dd//MM/yyyy hh:mm:ss tt"), _
    Editor(GetType(DigitalTimeEditorForm), GetType(System.Drawing.Design.UITypeEditor))> _
    Public Property DigitalTimeFormat() As String
        Get
            Return _digitalTimeFormat
        End Get
        Set(ByVal Value As String)
            _digitalTimeFormat = Value
            Me.Refresh()
        End Set
    End Property

    <Category("Appearance"), _
    Description("Determines which style of clock face to display"), _
    DefaultValue(ClockFace.Both), _
    Editor(GetType(FaceEditor), GetType(UITypeEditor))> _
    Public Property Face() As ClockFace
        Get
            Return _face
        End Get
        Set(ByVal Value As ClockFace)
            _face = Value
            Me.Refresh()
        End Set
    End Property

    <Category("Appearance"), _
    Description("Sets the color and size of the Hour Hand")> _
    Public Property HourHand() As Hand
        Get
            Return _hourHand
        End Get
        Set(ByVal Value As Hand)
            _hourHand = Value
            Me.Refresh()
        End Set
    End Property

    Private Function ShouldSerializeHourHand() As Boolean
        Return (Not (_hourHand.HandColor.Equals(Color.Black)) Or (_hourHand.Width <> 1))
    End Function

    Private Sub ResetHourHand()
        HourHand = New Hand(Color.Black, 1)
    End Sub

    <Category("Appearance"), _
    Description("Sets the color and size of the Minute Hand")> _
    Public Property MinuteHand() As Hand
        Get
            Return _minuteHand
        End Get
        Set(ByVal Value As Hand)
            _minuteHand = Value
            Me.Refresh()
        End Set
    End Property

    Private Function ShouldSerializeMinuteHand() As Boolean
        Return (Not (_minuteHand.HandColor.Equals(Color.Black)) Or (_minuteHand.Width <> 1))
    End Function

    Private Sub ResetMinuteHand()
        MinuteHand = New Hand(Color.Black, 1)
    End Sub

    <Category("Appearance"), _
    Description("Sets the color and size of the Second Hand")> _
    Public Property SecondHand() As Hand
        Get
            Return _secondHand
        End Get
        Set(ByVal Value As Hand)
            _secondHand = Value
            Me.Refresh()
        End Set
    End Property

    Private Function ShouldSerializeSecondHand() As Boolean
        Return (Not (_secondHand.HandColor.Equals(Color.Black)) Or (_secondHand.Width <> 1))
    End Function

    Private Sub ResetSecondHand()
        SecondHand = New Hand(Color.Black, 1)
    End Sub

#End Region

#Region "Event Handlers"
    Protected Overloads Overrides Sub OnPaint(ByVal pe As PaintEventArgs)
        ' Get specified date/time if control in design-time,
        ' or current date/time if control is in run-time
        Dim now As DateTime
        If Me.DesignMode Then
            ' Get pretty date/time for design-time
            now = New DateTime(2002, 12, 31, 15, 0, 20, 0)
        Else
            ' Get current date/time and apply the time zone modifier
            now = DateTime.Now.AddHours(_timeZoneModifier)
        End If

        ' Paint the clocks
        Dim g As Graphics = pe.Graphics
        Dim clientSize As Size = Me.ClientRectangle.Size
        Dim xRadius As Integer = clientSize.Width / 2
        Dim yRadius As Integer = clientSize.Height / 2
        Dim degrees As Double
        Dim x As Integer
        Dim y As Integer

        ' Make things pretty
        g.SmoothingMode = SmoothingMode.AntiAlias

        ' Digital or Analog Face
        Dim facePen As Pen = New Pen(Color.Black, 2)
        If _face <> ClockFace.Digital Then
            g.DrawEllipse(facePen, facePen.Width, facePen.Width, clientSize.Width - facePen.Width * 2, clientSize.Height - facePen.Width * 2)
            Dim faceBrush As SolidBrush = New SolidBrush(Color.White)
            g.FillEllipse(faceBrush, facePen.Width, facePen.Width, clientSize.Width - facePen.Width * 2, clientSize.Height - facePen.Width * 2)
            faceBrush.Dispose()
        Else
            g.DrawRectangle(facePen, facePen.Width, facePen.Width, clientSize.Width - facePen.Width * 2, clientSize.Height - facePen.Width * 2)
            Dim faceBrush As SolidBrush = New SolidBrush(Color.White)
            g.FillRectangle(facebrush, facePen.Width, facePen.Width, clientSize.Width - facePen.Width * 2, clientSize.Height - facePen.Width * 2)
            facebrush.Dispose()
        End If
        facePen.Dispose()

        ' Paint analog clock?
        If _face <> ClockFace.Digital Then

            ' Hour hand
            Dim hourHandPen As Pen = New Pen(_hourHand.HandColor, _hourHand.Width)
            degrees = (90.0 - ((now.Hour / 3.0) + (now.Minute / 180.0)) * 90.0) * (Math.PI / 180.0)
            x = CInt(Math.Round((xRadius / 3.0) * Math.Cos(degrees)))
            y = CInt(-(Math.Round((yRadius / 3.0) * Math.Sin(degrees))))
            g.DrawLine(hourHandPen, xRadius, yRadius, x + xRadius, y + yRadius)
            hourHandPen.Dispose()

            ' Minute hand
            Dim minuteHandPen As Pen = New Pen(_minuteHand.HandColor, _minuteHand.Width)
            degrees = (90.0 - (now.Minute / 15.0) * 90.0) * (Math.PI / 180.0)
            x = CInt(Math.Round((xRadius / 2.0) * Math.Cos(degrees)))
            y = CInt(-(Math.Round((yRadius / 2.0) * Math.Sin(degrees))))
            g.DrawLine(minuteHandPen, xRadius, yRadius, x + xRadius, y + yRadius)
            minuteHandPen.Dispose()

            ' Second hand
            Dim secondHandPen As Pen = New Pen(_secondHand.HandColor, _secondHand.Width)
            degrees = (90.0 - (now.Second / 15.0) * 90.0) * (Math.PI / 180.0)
            x = CInt(Math.Round((xRadius / 3.0) * Math.Cos(degrees)))
            y = CInt(-(Math.Round((yRadius / 3.0) * Math.Sin(degrees))))
            g.DrawLine(secondHandPen, xRadius, yRadius, x + xRadius, y + yRadius)
            secondHandPen.Dispose()
        End If

        ' Paint digital clock?
        If _face <> ClockFace.Analog Then
            Dim format As StringFormat = New StringFormat()
            format.Alignment = StringAlignment.Center
            Dim clearance As Double = IIf(_face = ClockFace.Digital, 1.0F, 1.5F)
            g.DrawString(now.ToString(_digitalTimeFormat), Me.Font, Brushes.Black, xRadius, yRadius * clearance, format)
        End If

        ' Let the base implementation do its thing
        MyBase.OnPaint(pe)
    End Sub

    Private Sub timer_Tick(ByVal sender As Object, ByVal e As EventArgs)
        ' Refresh the clock face
        Me.Refresh()

        ' Sound the first alarm? (copmaring to the second)
        If (Not _firstAlarmSounded And (DateTime.Now.ToString("hh:mm:ss") = _firstAlarm.ToString("hh:mm:ss"))) Then
            _firstAlarmSounded = True
            RaiseEvent SoundTheAlarm(Me, AlarmType.First)
        End If

        ' Sound the second alarm? (comparing to the first)
        If (Not _secondAlarmSounded And (DateTime.Now.ToString("hh:mm:ss") = _secondAlarm.ToString("hh:mm:ss"))) Then
            _secondAlarmSounded = True
            RaiseEvent SoundTheAlarm(Me, AlarmType.Second)
        End If
    End Sub
#End Region





End Class
