Imports System

Public Delegate Sub WorkStarted()
Public Delegate Sub WorkProgressing()
Public Delegate Function WorkCompleted() As Integer


Public Class Worker

    Public Event started As WorkStarted
    Public Event progressing As WorkProgressing
    Public completed As WorkCompleted

    Public Sub DoWork()
        Console.WriteLine("Worker: work started")
        RaiseEvent started()

        Console.WriteLine("Worker: work progressing")
        RaiseEvent progressing()

        Console.WriteLine("Worker: work completed")
        If Not (completed Is Nothing) Then
            Dim wc As WorkCompleted
            For Each wc In completed.GetInvocationList()
                Dim res As IAsyncResult = wc.BeginInvoke(New AsyncCallback(AddressOf WorkGraded), wc)
            Next
        End If
    End Sub

    Public Sub WorkGraded(ByVal res As IAsyncResult)
        Dim wc As WorkCompleted = CType(res.AsyncState, WorkCompleted)
        Dim grade As Integer = wc.EndInvoke(res)
        Console.WriteLine("Worker grade = " & grade.ToString())
    End Sub
End Class

Public Class Boss
    Public Function WorkCompleted() As Integer
        System.Threading.Thread.Sleep(3000)
        Console.WriteLine("Better...")
        Return 4 ' out of 10
    End Function
End Class

Public Class Universe
    Shared Sub WorkerStartedWork()
        Console.WriteLine("Universe notices worker starting work")
    End Sub

    Shared Function WorkerCompletedWork() As Integer
        System.Threading.Thread.Sleep(4000)
        Console.WriteLine("Universe pleased with worker's work")
        Return 7
    End Function

    Shared Sub Main()
        Dim peter As Worker = New Worker()
        Dim theboss As Boss = New Boss()

        Dim d1, d2 As WorkCompleted
        d1 = AddressOf theboss.WorkCompleted
        d2 = AddressOf Universe.WorkerCompletedWork

        peter.completed = CType(System.Delegate.Combine(d1, d2), WorkCompleted)
        AddHandler peter.started, AddressOf Universe.WorkerStartedWork
        peter.DoWork()

        Console.WriteLine("Main: worker completed work")
        Console.ReadLine()
    End Sub
End Class