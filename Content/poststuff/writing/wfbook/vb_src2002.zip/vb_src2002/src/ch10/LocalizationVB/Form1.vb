Imports System
Imports System.Data
Imports System.Globalization
Imports System.Windows.Forms


Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents columnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents listView1 As System.Windows.Forms.ListView
    Friend WithEvents columnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents columnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents columnHeader2 As System.Windows.Forms.ColumnHeader
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.columnHeader3 = New System.Windows.Forms.ColumnHeader()
        Me.listView1 = New System.Windows.Forms.ListView()
        Me.columnHeader1 = New System.Windows.Forms.ColumnHeader()
        Me.columnHeader4 = New System.Windows.Forms.ColumnHeader()
        Me.columnHeader2 = New System.Windows.Forms.ColumnHeader()
        Me.SuspendLayout()
        '
        'columnHeader3
        '
        Me.columnHeader3.Text = "Date"
        Me.columnHeader3.Width = 84
        '
        'listView1
        '
        Me.listView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.columnHeader1, Me.columnHeader4, Me.columnHeader2, Me.columnHeader3})
        Me.listView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.listView1.Name = "listView1"
        Me.listView1.Size = New System.Drawing.Size(352, 266)
        Me.listView1.TabIndex = 1
        Me.listView1.View = System.Windows.Forms.View.Details
        '
        'columnHeader1
        '
        Me.columnHeader1.Text = "Culture English Name"
        Me.columnHeader1.Width = 143
        '
        'columnHeader4
        '
        Me.columnHeader4.Text = "Name"
        '
        'columnHeader2
        '
        Me.columnHeader2.Text = "Currency"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(352, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.listView1})
        Me.Name = "Form1"
        Me.Text = "Localized Currencies and Dates"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim amount As Double = 4.52
        Dim _date As DateTime = DateTime.Now

        Dim info As CultureInfo
        For Each info In CultureInfo.GetCultures(CultureTypes.AllCultures)
            Dim item As ListViewItem = listView1.Items.Add(info.EnglishName)
            item.SubItems.Add(info.Name)
            If Not info.IsNeutralCulture Then
                item.SubItems.Add(amount.ToString("C", info.NumberFormat))
                item.SubItems.Add(_date.ToString("d", info.DateTimeFormat))
            End If
        Next
    End Sub
End Class
