' This sample demonstrates the following:
'
' -How to use DX to play a MIDI file from managed code
' -How to use the ComponentModel to get resources disposed when the parent form is closed
' -How to properly managed a COM object using ReleaseComObject
' -How to build an unmanaged resource-only DLL
' -How to link unmanaged resources into a managed assembly from within VS.NET
'
' NOTE: This sample depends on the most excellent ntcopyres from
' http://www.codeguru.com/cpp_mfc/rsrc-simple.html to copy the resources
' (a compiled version is part of this sample). Unfortunately, since Win9x
' doesn't support the UpdateResource function, this sample requires an NT-based
' implementation of the Win32 API.
'
' NOTE: The auto-building doesn't seem to work if I do Ctrl-F5 from w/in VS.NET
' because VS.NET seems to relink, but not cause the build step in the resource
' project to run (but why?)
Imports System.Reflection

Public Class Form1
    Inherits System.Windows.Forms.Form

    Private player As MidiPlaybackTestVB.MidiPlayer


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents cmdStop As System.Windows.Forms.Button
    Friend WithEvents cmdStart As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cmdStop = New System.Windows.Forms.Button()
        Me.cmdStart = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'cmdStop
        '
        Me.cmdStop.Location = New System.Drawing.Point(111, 16)
        Me.cmdStop.Name = "cmdStop"
        Me.cmdStop.TabIndex = 3
        Me.cmdStop.Text = "Stop"
        '
        'cmdStart
        '
        Me.cmdStart.Location = New System.Drawing.Point(23, 16)
        Me.cmdStart.Name = "cmdStart"
        Me.cmdStart.TabIndex = 2
        Me.cmdStart.Text = "Start"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(208, 54)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdStop, Me.cmdStart})
        Me.Name = "Form1"
        Me.Text = "MIDI Playback"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        player = New MidiPlayer()
        player.LoadFromResource([Assembly].GetExecutingAssembly().Location, "SAMPLE4.MID")
    End Sub

    Private Sub cmdStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdStop.Click
        player.PlayStop()

    End Sub

    Private Sub cmdStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdStart.Click
        player.Start()

    End Sub
End Class
