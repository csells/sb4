Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.IO
Imports System.IO.IsolatedStorage
Imports System.Text
Imports System.Runtime.Serialization
Imports System.Runtime.Serialization.Formatters
Imports System.Runtime.Serialization.Formatters.Soap
Imports System.Runtime.Serialization.Formatters.Binary

Public Class Test
    Shared Sub DoSerialize1()
        Dim s As String = "Wahoo!"
        Dim n As Integer = 452
        Dim mstream As Stream = New MemoryStream()
        ' Write to the stream
        Dim bytes1() As Byte = UnicodeEncoding.Unicode.GetBytes(s)
        Dim bytes2() As Byte = BitConverter.GetBytes(n)
        mstream.Write(bytes1, 0, bytes1.Length)
        mstream.Write(bytes2, 0, bytes2.Length)

        ' Reset the stream to the beginning
        mstream.Seek(0, SeekOrigin.Begin)

        ' Read from the stream
        Dim bytes3(mstream.Length - 4) As Byte
        Dim bytes4(4) As Byte
        mstream.Read(bytes3, 0, bytes3.Length)
        mstream.Read(bytes4, 0, bytes4.Length)

        ' Do something with the data
        MessageBox.Show(UnicodeEncoding.Unicode.GetString(bytes3) + " " + BitConverter.ToInt32(bytes4, 0))
    End Sub

    Shared Sub DoSerialize2()
        Dim s As String = "Wahoo!"
        Dim n As Integer = 452
        Dim mstream As Stream = New MemoryStream()

        ' Write to the stream
        Dim writer As StreamWriter = New StreamWriter(mstream)
        writer.WriteLine(s)
        writer.WriteLine(n)
        writer.Flush() ' Flush the buffer

        ' Reset the stream to the beginning
        mstream.Seek(0, SeekOrigin.Begin)

        ' Read from the stream
        Dim reader As StreamReader = New StreamReader(mstream)
        Dim s2 As String = reader.ReadLine()
        Dim n2 As String = Integer.Parse(reader.ReadLine())

        ' Do something with the data
        MessageBox.Show(s2 + " " + n2)
    End Sub

    Shared Sub DoSerialize3()
        Dim s As String = "Wahoo!"
        Dim n As Integer = 452
        Dim mstream As Stream = New MemoryStream()

        ' Write to the stream
        Dim writer As BinaryWriter = New BinaryWriter(mstream)
        writer.Write(s)
        writer.Write(n)
        writer.Flush() ' Flush the buffer

        ' Reset the stream to the beginning
        mstream.Seek(0, SeekOrigin.Begin)

        ' Read from the stream
        Dim reader As BinaryReader = New BinaryReader(mstream)
        Dim s2 As String = reader.ReadString()
        Dim n2 As Integer = reader.ReadInt32()

        ' Do something with the data
        MessageBox.Show(s2 + " " + n2)
    End Sub

    Class MyData
        Implements ISerializable

        Dim s As String = "Wahoo!"
        Dim n As Integer = 6
        Dim _oldStrings As ArrayList = New ArrayList() ' v2.0 addition
        Shared version As String = "2.0"

        Public Property TheString() As String
            Get
                Return s
            End Get
            Set(ByVal Value As String)
                _oldStrings.Add(s)
                s = Value
                n = s.Length
            End Set
        End Property

        Public ReadOnly Property Length() As Integer
            Get
                Return n
            End Get
        End Property

        Public ReadOnly Property OldStrings() As ArrayList
            Get
                Return _oldStrings
            End Get
        End Property

        Public Sub New()

        End Sub

        Public Sub New(ByVal info As SerializationInfo, ByVal context As StreamingContext)
            ' Read the data based on the version
            Dim version As String = info.GetString("MyString")

            Select Case version
                Case "1.0"
                    s = info.GetString("MyString")
                    n = s.Length
                Case "2.0"
                    s = info.GetString("MyString")
                    n = s.Length
                    _oldStrings = CType(info.GetValue("OldStrings", GetType(ArrayList)), ArrayList)
            End Select
        End Sub

        Public Sub GetObjectData(ByVal info As SerializationInfo, ByVal context As StreamingContext) Implements ISerializable.GetObjectData
            ' Tag the data with a version
            info.AddValue("Version", version)
            info.AddValue("MyString", s)
            info.AddValue("OldStrings", _oldStrings)
        End Sub
    End Class

    Shared Sub DoSerialize4()
        Dim data As MyData = New MyData()
        data.TheString = "Yahoo!"
        data.TheString = "Yodal!"
        data.TheString = "Local!"
        data.TheString = "Stop yelling!"
        Dim mstream As Stream = New FileStream("C:\temp\mydata.xml", FileMode.Create)
        ' write to the stream
        Dim formatter As IFormatter = New SoapFormatter()
        formatter.Serialize(mstream, data)

        ' Reset the stream to the beginning
        mstream.Seek(0, SeekOrigin.Begin)

        ' Read from the stream
        Dim data2 As MyData = CType(formatter.Deserialize(mstream), MyData)

        ' Do something with the data
        MessageBox.Show(data2.TheString + " " + data2.Length)
        Dim olds As String
        For Each olds In data2.OldStrings
            MessageBox.Show(olds, "Old String")
        Next
    End Sub
End Class
