Imports System.Drawing
Imports System.Drawing.Drawing2D


Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        Me.SetStyle(ControlStyles.ResizeRedraw, True)
        Me.SetStyle(ControlStyles.DoubleBuffer, True)
        Me.SetStyle(ControlStyles.AllPaintingInWmPaint, True)
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
        Me.Text = "Form1"
    End Sub

#End Region

    Private Function GetRoundedRectPath(ByVal rect As Rectangle, ByVal radius As Integer) As GraphicsPath
        Dim diameter As Integer = 2 * radius
        Dim arcRect As Rectangle = New Rectangle(rect.Location, New Size(diameter, diameter))
        Dim path As GraphicsPath = New GraphicsPath()

        path.AddArc(arcRect, 180, 90)

        arcRect.X = rect.Right - diameter
        path.AddArc(arcRect, 270, 90)

        arcRect.Y = rect.Bottom - diameter
        path.AddArc(arcRect, 0, 90)

        arcRect.X = rect.Left
        path.AddArc(arcRect, 90, 90)

        path.CloseFigure()

        Return path
    End Function

    Private Function GetClosedBezierPath(ByVal rect As Rectangle, ByVal points As Point()) As GraphicsPath
        Dim path As GraphicsPath = New GraphicsPath()
        path.AddBeziers(points)
        path.CloseFigure()
        Return path
    End Function

    Private Function GetDonutPath(ByVal rect As Rectangle, ByVal holeRadius As Integer) As GraphicsPath
        Dim path As GraphicsPath = New GraphicsPath()
        path.AddEllipse(rect)
        Dim centerPoint As Point = New Point(rect.Left + rect.Width / 2, rect.Top + rect.Height / 2)
        Dim holeRect As Rectangle = New Rectangle(centerPoint.X - holeRadius, centerPoint.Y - holeRadius, holeRadius * 2, holeRadius * 2)
        path.AddEllipse(holeRect)

        Dim format As StringFormat = New StringFormat()
        format.Alignment = StringAlignment.Center
        format.LineAlignment = StringAlignment.Center
        path.AddString("oooooh, donuts...", Me.Font.FontFamily, CInt(Me.Font.Style), Me.Font.Height, RectangleF.op_Implicit(rect), format)

        Return path
    End Function

    Private Function GetStringPath(ByVal s As String, ByVal dpi As Single, ByVal rect As RectangleF, ByVal font As Font, ByVal format As StringFormat) As GraphicsPath
        Dim path As GraphicsPath = New GraphicsPath()
        Dim emSize As Single = dpi * font.SizeInPoints / 72
        path.AddString(s, font.FontFamily, CInt(font.Style), emSize, rect, format)
        Return path
    End Function

    Private Sub Form1_Paint(ByVal sender As Object, ByVal e As PaintEventArgs) Handles MyBase.Paint
        Dim g As Graphics = e.Graphics
        Dim width As Integer = Me.ClientRectangle.Width
        Dim height As Integer = Me.ClientRectangle.Height
        Dim rect As Rectangle = New Rectangle(10, 10, width - 20, height - 20)
        Dim format As StringFormat = New StringFormat()
        format.Alignment = StringAlignment.Center
        format.LineAlignment = StringAlignment.Center
        Dim path As GraphicsPath = GetRoundedRectPath(rect, width / 10)
        'Dim path As GraphicsPath = GetClosedBezierPath(rect, New Point() {New Point(25, height - 25), New Point(width - 25, height - 25), New Point(25, 25), New Point(width - 25, 25)})

        'Dim path As GraphicsPath = GetDonutPath(rect, width / 5)
        g.FillPath(Brushes.Yellow, path)
        g.DrawPath(Pens.Black, path)

    End Sub
End Class
