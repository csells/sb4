Imports System.Drawing
Imports System.Drawing.Drawing2D


Public Class JoinsForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
        Me.Text = "JoinsForm"
    End Sub

#End Region



    Private Sub JoinsForm_Paint(ByVal sender As Object, ByVal e As PaintEventArgs) Handles MyBase.Paint
        Dim g As Graphics = e.Graphics
        Dim joinNames As String() = System.Enum.GetNames(GetType(LineJoin))
        Array.Sort(joinNames)

        Dim x As Integer = 0
        Dim y As Integer = 0
        Dim width As Integer = Me.ClientRectangle.Width / 2
        Dim height As Integer = Me.ClientRectangle.Height / ((joinNames.Length) / 2)
        Dim blackBrush As Brush = Brushes.Black
        Dim blackPen As Pen = Pens.Black
        Dim whitePen As Pen = Pens.White

        Dim joinName As String
        For Each joinName In joinNames
            Dim pen As Pen = New Pen(Color.Black, 12)
            pen.LineJoin = CType(System.Enum.Parse(GetType(LineJoin), joinName), LineJoin)
            g.DrawRectangle(pen, New Rectangle(x + 20, y + 20, width - 40, height - 40))
            g.DrawRectangle(whitePen, New Rectangle(x + 20, y + 20, width - 40, height - 40))
            Dim format As StringFormat = New StringFormat()
            format.Alignment = StringAlignment.Center
            format.LineAlignment = StringAlignment.Center
            g.DrawString(joinName, Me.Font, blackBrush, New RectangleF(x, y, width, height), format)

            x = x + width
            If x > Me.ClientRectangle.Width - width Then
                y = y + height
                x = 0
            End If
        Next
    End Sub


End Class
