Imports System.Drawing
Imports System.Drawing.Drawing2D

Public Class LineCapsForm

    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
        Me.Text = "LineCapsForm"
    End Sub

#End Region


    Private Sub LineCapsForm_Paint(ByVal sender As Object, ByVal e As PaintEventArgs) Handles MyBase.Paint
        Dim g As Graphics = e.Graphics
        Dim capNames As String() = System.Enum.GetNames(GetType(LineCap))
        Array.Sort(capNames)

        Dim x As Integer = 0
        Dim y As Integer = 0
        Dim width As Integer = Me.ClientRectangle.Width / 2
        Dim height As Integer = Me.ClientRectangle.Height / ((capNames.Length) / 2)
        Dim blackBrush As Brush = Brushes.Black
        Dim whitePen As Pen = Pens.White

        Dim capName As String
        For Each capName In capNames
            Dim pen As Pen = New Pen(Color.Black, 12)
            pen.EndCap = CType(System.Enum.Parse(GetType(LineCap), capName), LineCap)
            If pen.EndCap <> LineCap.AnchorMask Then

                If pen.EndCap = LineCap.Custom Then
                    pen.CustomEndCap = New AdjustableArrowCap(3, 3, False)
                End If
                g.DrawLine(pen, x, CInt(y + height * 2 / 3), CInt(x + width * 2 / 3), CInt(y + height * 2 / 3))
                g.DrawLine(whitePen, x, CInt(y + height * 2 / 3), CInt(x + width * 2 / 3), CInt(y + height * 2 / 3))
                g.DrawString(capName, Me.Font, blackBrush, x, y)

                x = x + width
                If x > Me.ClientRectangle.Width - width Then
                    y = y + height
                    x = 0
                End If

            End If

        Next
    End Sub
End Class
