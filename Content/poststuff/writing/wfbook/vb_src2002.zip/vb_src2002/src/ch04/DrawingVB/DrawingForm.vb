Imports System.Drawing
Imports System.Drawing.Drawing2D

Public Class DrawingForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents drawEllipseButton As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.drawEllipseButton = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'drawEllipseButton
        '
        Me.drawEllipseButton.Location = New System.Drawing.Point(43, 32)
        Me.drawEllipseButton.Name = "drawEllipseButton"
        Me.drawEllipseButton.TabIndex = 1
        Me.drawEllipseButton.Text = "Draw Ellipse"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(160, 86)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.drawEllipseButton})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Dim drawEllipse As Boolean = False

    Private Sub drawEllipseButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles drawEllipseButton.Click
        drawEllipse = Not drawEllipse
        Me.Refresh()
    End Sub

    Private Sub DrawingForm_Paint(ByVal sender As Object, ByVal e As PaintEventArgs) Handles MyBase.Paint
        Dim blue25PercentOpaque As Color = Color.FromArgb(255 * 1 / 4, 0, 0, 255)
        Dim blue75PercentOpaque As Color = Color.FromArgb(-1090518785)
        Dim white As Color = Color.FromArgb(255, 255, 255)
        Dim black As Color = Color.FromArgb(0, 0, 0)
        Dim blue1 As Color = Color.BlueViolet
        Dim blue2 As Color = Color.FromKnownColor(KnownColor.ActiveBorder)
        Dim blue3 As Color = Color.FromName("ActiveBorder")
        Dim htmlBlue As Color = ColorTranslator.FromHtml("#0000ff")

        If Not drawEllipse Then Return
        Dim g As Graphics = e.Graphics
        Dim b As Brush = New SolidBrush(blue25PercentOpaque)
        g.FillEllipse(b, Me.ClientRectangle)

    End Sub

End Class
