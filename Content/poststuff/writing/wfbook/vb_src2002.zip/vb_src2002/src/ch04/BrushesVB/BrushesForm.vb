Imports System
Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data


Public Class BrushesForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'BrushesForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Name = "BrushesForm"
        Me.Text = "Form1"

    End Sub

#End Region



    Enum LinearGradientMode
        BackwardDiagonal
        ForwardDiagonal
        Horizontal
        Vertical
    End Enum

    Private Sub BrushesForm_Paint(ByVal sender As Object, ByVal e As PaintEventArgs) Handles MyBase.Paint
        Dim g As Graphics = e.Graphics
        Dim x As Integer = 0
        Dim y As Integer = 0
        Dim width As Integer = Me.ClientRectangle.Width
        Dim height As Integer = Me.ClientRectangle.Height / 5
        Dim whiteBrush As Brush = System.Drawing.Brushes.White
        Dim blackBrush As Brush = System.Drawing.Brushes.Black

        Dim b As Brush = New SolidBrush(Color.DarkBlue)
        g.FillRectangle(b, x, y, width, height)
        g.DrawString(b.ToString(), Me.Font, whiteBrush, x, y)
        y = y + height

        Dim file As String = "c:\windows\Santa Fe Stucco.bmp"
        b = New TextureBrush(New Bitmap(file))
        g.FillRectangle(b, x, y, width, height)
        g.DrawString(b.ToString(), Me.Font, whiteBrush, x, y)
        y = y + height

        b = New HatchBrush(HatchStyle.Divot, Color.DarkBlue, Color.White)
        g.FillRectangle(b, x, y, width, height)
        g.DrawString(b.ToString(), Me.Font, blackBrush, x, y)
        y = y + height

        b = New LinearGradientBrush(New Rectangle(x, y, width, height), Color.DarkBlue, Color.White, 45)
        g.FillRectangle(b, x, y, width, height)
        g.DrawString(b.ToString(), Me.Font, blackBrush, x, y)
        y = y + height

        Dim points As Point() = New Point() {New Point(x, y), New Point(x + width, y), New Point(x + width, y + height), New Point(x, y + height)}
        b = New PathGradientBrush(points)
        g.FillRectangle(b, x, y, width, height)
        g.DrawString(b.ToString(), Me.Font, blackBrush, x, y)
        y = y + height


    End Sub


End Class
