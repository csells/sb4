Imports System
Imports System.Windows.Forms
Imports System.Configuration
Imports System.Collections.Specialized
Imports System.Reflection
Imports System.ComponentModel
Imports Microsoft.Win32

Public Class Registry_MainForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents piTextBox As System.Windows.Forms.TextBox
    Friend WithEvents label1 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.piTextBox = New System.Windows.Forms.TextBox()
        Me.label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'piTextBox
        '
        Me.piTextBox.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.piTextBox.Location = New System.Drawing.Point(82, 16)
        Me.piTextBox.Name = "piTextBox"
        Me.piTextBox.Size = New System.Drawing.Size(200, 20)
        Me.piTextBox.TabIndex = 3
        Me.piTextBox.Text = ""
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(10, 16)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(64, 23)
        Me.label1.TabIndex = 2
        Me.label1.Text = "Today's pi"
        '
        'Registry_MainForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 54)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.piTextBox, Me.label1})
        Me.Name = "Registry_MainForm"
        Me.Text = "Settings Test"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Registry_MainForm_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        ' Save the form's position before it closes
        Dim key As RegistryKey = Application.UserAppDataRegistry
        ' Restore the window state to save location and
        ' client size at restored state
        Dim state As FormWindowState = Me.WindowState
        Me.WindowState = FormWindowState.Normal

        key.SetValue("MainForm.Location", ToString(Me.Location))
        key.SetValue("MainForm.ClientSize", ToString(Me.ClientSize))
        key.SetValue("MainForm.WindowState", ToString(state))

    End Sub

    ' Convert an object to a string
    Private Shadows Function ToString(ByVal obj As Object) As String
        Dim converter As TypeConverter = TypeDescriptor.GetConverter(obj.GetType())
        Return converter.ConvertToString(obj)
    End Function

    ' Convert a string to an object
    Private Function FromString(ByVal obj As Object, ByVal t As Type) As Object
        Dim converter As TypeConverter = TypeDescriptor.GetConverter(t)
        Return converter.ConvertFromString(obj.ToString())
    End Function

    Private Sub Registry_MainForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim reader As AppSettingsReader = New AppSettingsReader()
        Dim pi As Decimal = CDec(reader.GetValue("pi", GetType(Decimal)))
        piTextBox.Text = pi.ToString()

        ' Restore the form's position
        Dim key As RegistryKey = Application.UserAppDataRegistry
        Try
            ' Don't let them form's position be set automatically
            Me.StartPosition = FormStartPosition.Manual

            Me.Location = CType(FromString(key.GetValue("MainForm.Location"), GetType(Point)), Point)
            Me.ClientSize = CType(FromString(key.GetValue("MainForm.ClientSize"), GetType(Size)), Size)
            Me.WindowState = CType(FromString(key.GetValue("MainForm.WindowState"), GetType(FormWindowState)), FormWindowState)

        Catch ex As Exception
            ' Don't let missing settings scare the user
            MessageBox.Show(ex.Message, ex.GetType().Name)
        End Try
    End Sub
End Class
