' MultiMdiApplicationContext.vb
' Inspired by Brian Randell
' Copryright (c) 2003, Chris Sells and Justin Gehtland

Imports System
Imports System.Collections
Imports System.Windows.Forms

Namespace SellsBrothers
    Public Class MultiMdiApplicationContext
        Inherits ApplicationContext

        Dim _topLevelForms As ArrayList = New ArrayList()
        Dim windowMenuMap As Hashtable = New Hashtable()

        Public Sub AddTopLevelForm(ByVal theform As Form)
            ' Initial main form may add itself twice, but that's ok
            If _topLevelForms.Contains(theform) Then Exit Sub

            ' Add form to collection of forms and
            ' watch for it to activate and close
            _topLevelForms.Add(theform)
            AddHandler theform.Activated, New EventHandler(AddressOf Form_Activated)
            AddHandler theform.Closed, New EventHandler(AddressOf Form_Closed)

            ' Set initial main form to activate
            If _topLevelForms.Count = 1 Then MyBase.MainForm = theform
        End Sub

        Public Sub Form_Activated(ByVal sender As Object, ByVal e As EventArgs)
            ' Whichever form activated last is the "main" form
            MyBase.MainForm = CType(sender, Form)
        End Sub

        Public Sub Form_Closed(ByVal sender As Object, ByVal e As EventArgs)
            ' Remove form from the lsit
            _topLevelForms.Remove(sender)

            ' Set a new "main" if necessary
            If CType(sender, Form) Is MyBase.MainForm And Me._topLevelForms.Count > 0 Then
                Me.MainForm = CType(TopLevelForms(0), Form)
            End If
        End Sub

        Public Sub AddWindowMenu(ByVal menu As MenuItem)
            ' Add at least one dummy menu item to get pop-up event
            If menu.MenuItems.Count = 0 Then menu.MenuItems.Add("dummy")

            ' Subscribe to pop-up event
            AddHandler menu.Popup, New EventHandler(AddressOf WindowMenu_Popup)
        End Sub

        Public Sub WindowMenu_Popup(ByVal sender As Object, ByVal e As EventArgs)
            ' Build menu from list of top-level windows
            Dim menu As MenuItem = CType(sender, MenuItem)
            menu.MenuItems.Clear()
            windowMenuMap.Clear()

            Dim f As Form
            For Each f In Me.topLevelForms
                Dim item As MenuItem = menu.MenuItems.Add(f.Text)
                AddHandler item.Click, New EventHandler(AddressOf WindowMenuItem_Click)

                ' Check currently active window
                If f Is Form.ActiveForm Then item.Checked = True

                ' Associate each menu item back to the form
                windowMenuMap.Add(item, f)
            Next
        End Sub

        Public Sub WindowMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
            ' Activate top-level form based on selection
            Dim f As Form = CType(windowMenuMap(sender), Form)
            f.Activate()
        End Sub

        Public ReadOnly Property TopLevelForms() As Form()
            Get
                Dim f As Form() = CType(_topLevelForms.ToArray(GetType(Form)), Form())
            End Get
        End Property
    End Class

End Namespace
