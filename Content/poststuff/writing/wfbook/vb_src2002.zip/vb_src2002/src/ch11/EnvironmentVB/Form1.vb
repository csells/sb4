Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents companyNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents productNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents productVersionTextBox As System.Windows.Forms.TextBox
    Friend WithEvents label4 As System.Windows.Forms.Label
    Friend WithEvents executablePathTextBox As System.Windows.Forms.TextBox
    Friend WithEvents label5 As System.Windows.Forms.Label
    Friend WithEvents startupPathTextBox As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.companyNameTextBox = New System.Windows.Forms.TextBox()
        Me.label1 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.label3 = New System.Windows.Forms.Label()
        Me.productNameTextBox = New System.Windows.Forms.TextBox()
        Me.productVersionTextBox = New System.Windows.Forms.TextBox()
        Me.label4 = New System.Windows.Forms.Label()
        Me.executablePathTextBox = New System.Windows.Forms.TextBox()
        Me.label5 = New System.Windows.Forms.Label()
        Me.startupPathTextBox = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'companyNameTextBox
        '
        Me.companyNameTextBox.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.companyNameTextBox.Location = New System.Drawing.Point(122, 16)
        Me.companyNameTextBox.Name = "companyNameTextBox"
        Me.companyNameTextBox.Size = New System.Drawing.Size(308, 20)
        Me.companyNameTextBox.TabIndex = 9
        Me.companyNameTextBox.Text = "textBox1"
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(18, 16)
        Me.label1.Name = "label1"
        Me.label1.TabIndex = 5
        Me.label1.Text = "Company Name"
        Me.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(18, 40)
        Me.label2.Name = "label2"
        Me.label2.TabIndex = 6
        Me.label2.Text = "Product Name"
        Me.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'label3
        '
        Me.label3.Location = New System.Drawing.Point(18, 64)
        Me.label3.Name = "label3"
        Me.label3.TabIndex = 2
        Me.label3.Text = "Product Version"
        Me.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'productNameTextBox
        '
        Me.productNameTextBox.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.productNameTextBox.Location = New System.Drawing.Point(122, 40)
        Me.productNameTextBox.Name = "productNameTextBox"
        Me.productNameTextBox.Size = New System.Drawing.Size(308, 20)
        Me.productNameTextBox.TabIndex = 10
        Me.productNameTextBox.Text = "textBox1"
        '
        'productVersionTextBox
        '
        Me.productVersionTextBox.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.productVersionTextBox.Location = New System.Drawing.Point(122, 64)
        Me.productVersionTextBox.Name = "productVersionTextBox"
        Me.productVersionTextBox.Size = New System.Drawing.Size(308, 20)
        Me.productVersionTextBox.TabIndex = 11
        Me.productVersionTextBox.Text = "textBox1"
        '
        'label4
        '
        Me.label4.Location = New System.Drawing.Point(18, 88)
        Me.label4.Name = "label4"
        Me.label4.TabIndex = 4
        Me.label4.Text = "Executable Path"
        Me.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'executablePathTextBox
        '
        Me.executablePathTextBox.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.executablePathTextBox.Location = New System.Drawing.Point(122, 88)
        Me.executablePathTextBox.Name = "executablePathTextBox"
        Me.executablePathTextBox.Size = New System.Drawing.Size(308, 20)
        Me.executablePathTextBox.TabIndex = 8
        Me.executablePathTextBox.Text = "textBox1"
        '
        'label5
        '
        Me.label5.Location = New System.Drawing.Point(18, 112)
        Me.label5.Name = "label5"
        Me.label5.TabIndex = 3
        Me.label5.Text = "Startup Path"
        Me.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'startupPathTextBox
        '
        Me.startupPathTextBox.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.startupPathTextBox.Location = New System.Drawing.Point(122, 112)
        Me.startupPathTextBox.Name = "startupPathTextBox"
        Me.startupPathTextBox.Size = New System.Drawing.Size(308, 20)
        Me.startupPathTextBox.TabIndex = 7
        Me.startupPathTextBox.Text = "textBox1"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(448, 150)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.companyNameTextBox, Me.label1, Me.label2, Me.label3, Me.productNameTextBox, Me.productVersionTextBox, Me.label4, Me.executablePathTextBox, Me.label5, Me.startupPathTextBox})
        Me.Name = "Form1"
        Me.Text = "About Box"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Shared Sub Main(ByVal args As String())
        Dim flag As Boolean = False
        Dim name As String = ""
        Dim number As Integer = 0

        Dim i As Integer
        For i = 0 To args.Length - 1
            Select Case args(i)
                Case "/flag"
                    flag = True
                Case "/name"
                    i += 1
                    name = args(i)
                Case "/number"
                    i += 1
                    number = Integer.Parse(args(i))
                Case Else
                    MessageBox.Show("invalid args!")
                    Exit Sub
            End Select
        Next

        MessageBox.Show(flag.ToString(), "Flag")
        MessageBox.Show(name, "Name")
        MessageBox.Show(number.ToString(), "Number")

        Application.Run(New Form1())

    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.companyNameTextBox.Text = Application.CompanyName
        Me.productNameTextBox.Text = Application.ProductName
        Me.productVersionTextBox.Text = Application.ProductVersion
        Me.executablePathTextBox.Text = Application.ExecutablePath
        Me.startupPathTextBox.Text = Application.StartupPath
    End Sub
End Class
