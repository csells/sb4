Imports System
Imports System.Windows.Forms
Imports System.IO
Imports Microsoft.Win32
Imports SellsBrothers

Namespace MultiSDI
    Public Class TopLevelForm
        Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

        Public Sub New()
            MyBase.New()

            'This call is required by the Windows Form Designer.
            InitializeComponent()

            'Add any initialization after the InitializeComponent() call

        End Sub

        'Form overrides dispose to clean up the component list.
        Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
            If disposing Then
                If Not (components Is Nothing) Then
                    components.Dispose()
                End If
            End If
            MyBase.Dispose(disposing)
        End Sub

        'Required by the Windows Form Designer
        Private components As System.ComponentModel.IContainer

        'NOTE: The following procedure is required by the Windows Form Designer
        'It can be modified using the Windows Form Designer.  
        'Do not modify it using the code editor.
        Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
        Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
        Friend WithEvents fileNewWindowMenuItem As System.Windows.Forms.MenuItem
        Friend WithEvents fileCloseWindowMenuItem As System.Windows.Forms.MenuItem
        Friend WithEvents windowMenu As System.Windows.Forms.MenuItem
        Friend WithEvents textBox1 As System.Windows.Forms.TextBox
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
            Me.mainMenu1 = New System.Windows.Forms.MainMenu()
            Me.menuItem1 = New System.Windows.Forms.MenuItem()
            Me.fileNewWindowMenuItem = New System.Windows.Forms.MenuItem()
            Me.fileCloseWindowMenuItem = New System.Windows.Forms.MenuItem()
            Me.windowMenu = New System.Windows.Forms.MenuItem()
            Me.textBox1 = New System.Windows.Forms.TextBox()
            Me.SuspendLayout()
            '
            'mainMenu1
            '
            Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1, Me.windowMenu})
            '
            'menuItem1
            '
            Me.menuItem1.Index = 0
            Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.fileNewWindowMenuItem, Me.fileCloseWindowMenuItem})
            Me.menuItem1.Text = "&File"
            '
            'fileNewWindowMenuItem
            '
            Me.fileNewWindowMenuItem.Index = 0
            Me.fileNewWindowMenuItem.Shortcut = System.Windows.Forms.Shortcut.CtrlN
            Me.fileNewWindowMenuItem.Text = "&New Window"
            '
            'fileCloseWindowMenuItem
            '
            Me.fileCloseWindowMenuItem.Index = 1
            Me.fileCloseWindowMenuItem.Text = "&Close Window"
            '
            'windowMenu
            '
            Me.windowMenu.Index = 1
            Me.windowMenu.Text = "&Window"
            '
            'textBox1
            '
            Me.textBox1.Dock = System.Windows.Forms.DockStyle.Fill
            Me.textBox1.Multiline = True
            Me.textBox1.Name = "textBox1"
            Me.textBox1.Size = New System.Drawing.Size(292, 287)
            Me.textBox1.TabIndex = 1
            Me.textBox1.Text = ""
            '
            'TopLevelForm
            '
            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.ClientSize = New System.Drawing.Size(292, 287)
            Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.textBox1})
            Me.Menu = Me.mainMenu1
            Me.Name = "TopLevelForm"
            Me.Text = "Top-Level Form"
            Me.ResumeLayout(False)

        End Sub

#End Region

        ' Need application context to manage top-level forms
        Shared context As MultiMdiApplicationContext = New MultiMdiApplicationContext()

        Shared Sub Main(ByVal args As String())
            ' Check if someone has hi-jacked the .tlf extension
            Dim mapExtension As Boolean = True
            Dim key As RegistryKey = Registry.ClassesRoot.OpenSubKey(".tlf")
            If Not key Is Nothing AndAlso key.GetValue(Nothing).ToString().ToLower() <> "tlffile" Then
                Dim ask As String = "Associate .tlf with this application?"
                Dim res As DialogResult = MessageBox.Show(ask, "Oops!", MessageBoxButtons.YesNo)
                If res = System.Windows.Forms.DialogResult.No Then mapExtension = False
                key.Close()
            End If


            If mapExtension Then
                ' Map .tlf extension to a ProgID
                key = Registry.ClassesRoot.CreateSubKey(".tlf")
                key.SetValue(Nothing, "tlffile")
                key.Close()

                ' Map ProgID to an Open action for the shell
                Dim cmdkey As String = "tlffile\shell\open\command"
                key = Registry.ClassesRoot.CreateSubKey(cmdkey)
                key.SetValue(Nothing, Application.ExecutablePath & " ""%L""")
                key.Close()
            End If

            ' Add initial form
            Dim initialForm As TopLevelForm = New TopLevelForm()
            context.AddTopLevelForm(initialForm)

            ' Let initial instance show another top-level form (if necessary)



        End Sub

    End Class

End Namespace
