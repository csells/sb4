Imports System.Data
Imports System.Data.SqlClient


Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents sqlDeleteCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents sqlConnection1 As System.Data.SqlClient.SqlConnection
    Friend WithEvents customersAdapter As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents sqlInsertCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents sqlSelectCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents sqlUpdateCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents updateSelectedRowMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents sqlUpdateCommand2 As System.Data.SqlClient.SqlCommand
    Friend WithEvents commitChangesMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents sqlInsertCommand2 As System.Data.SqlClient.SqlCommand
    Friend WithEvents ordersListBox As System.Windows.Forms.ListBox
    Friend WithEvents addRowMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents sqlSelectCommand2 As System.Data.SqlClient.SqlCommand
    Friend WithEvents deleteSelectedRowMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents customersListBox As System.Windows.Forms.ListBox
    Friend WithEvents contextMenu1 As System.Windows.Forms.ContextMenu
    Friend WithEvents splitter1 As System.Windows.Forms.Splitter
    Friend WithEvents sqlDeleteCommand2 As System.Data.SqlClient.SqlCommand
    Friend WithEvents ordersAdapter As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents customerSet1 As CustomerSet


    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.sqlDeleteCommand1 = New System.Data.SqlClient.SqlCommand()
        Me.sqlConnection1 = New System.Data.SqlClient.SqlConnection()
        Me.customersAdapter = New System.Data.SqlClient.SqlDataAdapter()
        Me.sqlInsertCommand1 = New System.Data.SqlClient.SqlCommand()
        Me.sqlSelectCommand1 = New System.Data.SqlClient.SqlCommand()
        Me.sqlUpdateCommand1 = New System.Data.SqlClient.SqlCommand()
        Me.updateSelectedRowMenuItem = New System.Windows.Forms.MenuItem()
        Me.sqlUpdateCommand2 = New System.Data.SqlClient.SqlCommand()
        Me.commitChangesMenuItem = New System.Windows.Forms.MenuItem()
        Me.sqlInsertCommand2 = New System.Data.SqlClient.SqlCommand()
        Me.ordersListBox = New System.Windows.Forms.ListBox()
        Me.addRowMenuItem = New System.Windows.Forms.MenuItem()
        Me.sqlSelectCommand2 = New System.Data.SqlClient.SqlCommand()
        Me.deleteSelectedRowMenuItem = New System.Windows.Forms.MenuItem()
        Me.customersListBox = New System.Windows.Forms.ListBox()
        Me.contextMenu1 = New System.Windows.Forms.ContextMenu()
        Me.splitter1 = New System.Windows.Forms.Splitter()
        Me.sqlDeleteCommand2 = New System.Data.SqlClient.SqlCommand()
        Me.ordersAdapter = New System.Data.SqlClient.SqlDataAdapter()
        Me.customerSet1 = New CustomerSet()
        Me.SuspendLayout()
        '
        'sqlDeleteCommand1
        '
        Me.sqlDeleteCommand1.CommandText = "DELETE FROM Customers WHERE (CustomerID = @Original_CustomerID) AND (Address = @O" & _
        "riginal_Address OR @Original_Address IS NULL AND Address IS NULL) AND (City = @O" & _
        "riginal_City OR @Original_City IS NULL AND City IS NULL) AND (CompanyName = @Ori" & _
        "ginal_CompanyName) AND (ContactName = @Original_ContactName OR @Original_Contact" & _
        "Name IS NULL AND ContactName IS NULL) AND (ContactTitle = @Original_ContactTitle" & _
        " OR @Original_ContactTitle IS NULL AND ContactTitle IS NULL) AND (Country = @Ori" & _
        "ginal_Country OR @Original_Country IS NULL AND Country IS NULL) AND (Fax = @Orig" & _
        "inal_Fax OR @Original_Fax IS NULL AND Fax IS NULL) AND (Phone = @Original_Phone " & _
        "OR @Original_Phone IS NULL AND Phone IS NULL) AND (PostalCode = @Original_Postal" & _
        "Code OR @Original_PostalCode IS NULL AND PostalCode IS NULL) AND (Region = @Orig" & _
        "inal_Region OR @Original_Region IS NULL AND Region IS NULL)"
        Me.sqlDeleteCommand1.Connection = Me.sqlConnection1
        Me.sqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CustomerID", System.Data.SqlDbType.NVarChar, 5, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CustomerID", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Address", System.Data.SqlDbType.NVarChar, 60, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Address", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_City", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "City", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CompanyName", System.Data.SqlDbType.NVarChar, 40, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CompanyName", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ContactName", System.Data.SqlDbType.NVarChar, 30, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ContactName", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ContactTitle", System.Data.SqlDbType.NVarChar, 30, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ContactTitle", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Country", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Country", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Fax", System.Data.SqlDbType.NVarChar, 24, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Fax", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Phone", System.Data.SqlDbType.NVarChar, 24, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Phone", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_PostalCode", System.Data.SqlDbType.NVarChar, 10, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PostalCode", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Region", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Region", System.Data.DataRowVersion.Original, Nothing))
        '
        'sqlConnection1
        '
        Me.sqlConnection1.ConnectionString = "data source=MUNGO\NetSDK;initial catalog=Northwind;integrated security=SSPI;persi" & _
        "st security info=False;workstation id=MUNGO;packet size=4096"
        '
        'customersAdapter
        '
        Me.customersAdapter.DeleteCommand = Me.sqlDeleteCommand1
        Me.customersAdapter.InsertCommand = Me.sqlInsertCommand1
        Me.customersAdapter.SelectCommand = Me.sqlSelectCommand1
        Me.customersAdapter.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Customers", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("CustomerID", "CustomerID"), New System.Data.Common.DataColumnMapping("CompanyName", "CompanyName"), New System.Data.Common.DataColumnMapping("ContactName", "ContactName"), New System.Data.Common.DataColumnMapping("ContactTitle", "ContactTitle"), New System.Data.Common.DataColumnMapping("Address", "Address"), New System.Data.Common.DataColumnMapping("City", "City"), New System.Data.Common.DataColumnMapping("Region", "Region"), New System.Data.Common.DataColumnMapping("PostalCode", "PostalCode"), New System.Data.Common.DataColumnMapping("Country", "Country"), New System.Data.Common.DataColumnMapping("Phone", "Phone"), New System.Data.Common.DataColumnMapping("Fax", "Fax")})})
        Me.customersAdapter.UpdateCommand = Me.sqlUpdateCommand1
        '
        'sqlInsertCommand1
        '
        Me.sqlInsertCommand1.CommandText = "INSERT INTO Customers(CustomerID, CompanyName, ContactName, ContactTitle, Address" & _
        ", City, Region, PostalCode, Country, Phone, Fax) VALUES (@CustomerID, @CompanyNa" & _
        "me, @ContactName, @ContactTitle, @Address, @City, @Region, @PostalCode, @Country" & _
        ", @Phone, @Fax); SELECT CustomerID, CompanyName, ContactName, ContactTitle, Addr" & _
        "ess, City, Region, PostalCode, Country, Phone, Fax FROM Customers WHERE (Custome" & _
        "rID = @CustomerID)"
        Me.sqlInsertCommand1.Connection = Me.sqlConnection1
        Me.sqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CustomerID", System.Data.SqlDbType.NVarChar, 5, "CustomerID"))
        Me.sqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CompanyName", System.Data.SqlDbType.NVarChar, 40, "CompanyName"))
        Me.sqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ContactName", System.Data.SqlDbType.NVarChar, 30, "ContactName"))
        Me.sqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ContactTitle", System.Data.SqlDbType.NVarChar, 30, "ContactTitle"))
        Me.sqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Address", System.Data.SqlDbType.NVarChar, 60, "Address"))
        Me.sqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@City", System.Data.SqlDbType.NVarChar, 15, "City"))
        Me.sqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Region", System.Data.SqlDbType.NVarChar, 15, "Region"))
        Me.sqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PostalCode", System.Data.SqlDbType.NVarChar, 10, "PostalCode"))
        Me.sqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Country", System.Data.SqlDbType.NVarChar, 15, "Country"))
        Me.sqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Phone", System.Data.SqlDbType.NVarChar, 24, "Phone"))
        Me.sqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Fax", System.Data.SqlDbType.NVarChar, 24, "Fax"))
        '
        'sqlSelectCommand1
        '
        Me.sqlSelectCommand1.CommandText = "SELECT CustomerID, CompanyName, ContactName, ContactTitle, Address, City, Region," & _
        " PostalCode, Country, Phone, Fax FROM Customers"
        Me.sqlSelectCommand1.Connection = Me.sqlConnection1
        '
        'sqlUpdateCommand1
        '
        Me.sqlUpdateCommand1.CommandText = "UPDATE Customers SET CustomerID = @CustomerID, CompanyName = @CompanyName, Contac" & _
        "tName = @ContactName, ContactTitle = @ContactTitle, Address = @Address, City = @" & _
        "City, Region = @Region, PostalCode = @PostalCode, Country = @Country, Phone = @P" & _
        "hone, Fax = @Fax WHERE (CustomerID = @Original_CustomerID) AND (Address = @Origi" & _
        "nal_Address OR @Original_Address IS NULL AND Address IS NULL) AND (City = @Origi" & _
        "nal_City OR @Original_City IS NULL AND City IS NULL) AND (CompanyName = @Origina" & _
        "l_CompanyName) AND (ContactName = @Original_ContactName OR @Original_ContactName" & _
        " IS NULL AND ContactName IS NULL) AND (ContactTitle = @Original_ContactTitle OR " & _
        "@Original_ContactTitle IS NULL AND ContactTitle IS NULL) AND (Country = @Origina" & _
        "l_Country OR @Original_Country IS NULL AND Country IS NULL) AND (Fax = @Original" & _
        "_Fax OR @Original_Fax IS NULL AND Fax IS NULL) AND (Phone = @Original_Phone OR @" & _
        "Original_Phone IS NULL AND Phone IS NULL) AND (PostalCode = @Original_PostalCode" & _
        " OR @Original_PostalCode IS NULL AND PostalCode IS NULL) AND (Region = @Original" & _
        "_Region OR @Original_Region IS NULL AND Region IS NULL); SELECT CustomerID, Comp" & _
        "anyName, ContactName, ContactTitle, Address, City, Region, PostalCode, Country, " & _
        "Phone, Fax FROM Customers WHERE (CustomerID = @CustomerID)"
        Me.sqlUpdateCommand1.Connection = Me.sqlConnection1
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CustomerID", System.Data.SqlDbType.NVarChar, 5, "CustomerID"))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CompanyName", System.Data.SqlDbType.NVarChar, 40, "CompanyName"))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ContactName", System.Data.SqlDbType.NVarChar, 30, "ContactName"))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ContactTitle", System.Data.SqlDbType.NVarChar, 30, "ContactTitle"))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Address", System.Data.SqlDbType.NVarChar, 60, "Address"))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@City", System.Data.SqlDbType.NVarChar, 15, "City"))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Region", System.Data.SqlDbType.NVarChar, 15, "Region"))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PostalCode", System.Data.SqlDbType.NVarChar, 10, "PostalCode"))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Country", System.Data.SqlDbType.NVarChar, 15, "Country"))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Phone", System.Data.SqlDbType.NVarChar, 24, "Phone"))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Fax", System.Data.SqlDbType.NVarChar, 24, "Fax"))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CustomerID", System.Data.SqlDbType.NVarChar, 5, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CustomerID", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Address", System.Data.SqlDbType.NVarChar, 60, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Address", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_City", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "City", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CompanyName", System.Data.SqlDbType.NVarChar, 40, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CompanyName", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ContactName", System.Data.SqlDbType.NVarChar, 30, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ContactName", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ContactTitle", System.Data.SqlDbType.NVarChar, 30, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ContactTitle", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Country", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Country", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Fax", System.Data.SqlDbType.NVarChar, 24, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Fax", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Phone", System.Data.SqlDbType.NVarChar, 24, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Phone", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_PostalCode", System.Data.SqlDbType.NVarChar, 10, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PostalCode", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Region", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Region", System.Data.DataRowVersion.Original, Nothing))
        '
        'updateSelectedRowMenuItem
        '
        Me.updateSelectedRowMenuItem.Index = 1
        Me.updateSelectedRowMenuItem.Text = "&Update Selected Row"
        '
        'sqlUpdateCommand2
        '
        Me.sqlUpdateCommand2.CommandText = "UPDATE Orders SET CustomerID = @CustomerID, EmployeeID = @EmployeeID, OrderDate =" & _
        " @OrderDate, RequiredDate = @RequiredDate, ShippedDate = @ShippedDate, ShipVia =" & _
        " @ShipVia, Freight = @Freight, ShipName = @ShipName, ShipAddress = @ShipAddress," & _
        " ShipCity = @ShipCity, ShipRegion = @ShipRegion, ShipPostalCode = @ShipPostalCod" & _
        "e, ShipCountry = @ShipCountry WHERE (OrderID = @Original_OrderID) AND (CustomerI" & _
        "D = @Original_CustomerID OR @Original_CustomerID IS NULL AND CustomerID IS NULL)" & _
        " AND (EmployeeID = @Original_EmployeeID OR @Original_EmployeeID IS NULL AND Empl" & _
        "oyeeID IS NULL) AND (Freight = @Original_Freight OR @Original_Freight IS NULL AN" & _
        "D Freight IS NULL) AND (OrderDate = @Original_OrderDate OR @Original_OrderDate I" & _
        "S NULL AND OrderDate IS NULL) AND (RequiredDate = @Original_RequiredDate OR @Ori" & _
        "ginal_RequiredDate IS NULL AND RequiredDate IS NULL) AND (ShipAddress = @Origina" & _
        "l_ShipAddress OR @Original_ShipAddress IS NULL AND ShipAddress IS NULL) AND (Shi" & _
        "pCity = @Original_ShipCity OR @Original_ShipCity IS NULL AND ShipCity IS NULL) A" & _
        "ND (ShipCountry = @Original_ShipCountry OR @Original_ShipCountry IS NULL AND Shi" & _
        "pCountry IS NULL) AND (ShipName = @Original_ShipName OR @Original_ShipName IS NU" & _
        "LL AND ShipName IS NULL) AND (ShipPostalCode = @Original_ShipPostalCode OR @Orig" & _
        "inal_ShipPostalCode IS NULL AND ShipPostalCode IS NULL) AND (ShipRegion = @Origi" & _
        "nal_ShipRegion OR @Original_ShipRegion IS NULL AND ShipRegion IS NULL) AND (Ship" & _
        "Via = @Original_ShipVia OR @Original_ShipVia IS NULL AND ShipVia IS NULL) AND (S" & _
        "hippedDate = @Original_ShippedDate OR @Original_ShippedDate IS NULL AND ShippedD" & _
        "ate IS NULL); SELECT OrderID, CustomerID, EmployeeID, OrderDate, RequiredDate, S" & _
        "hippedDate, ShipVia, Freight, ShipName, ShipAddress, ShipCity, ShipRegion, ShipP" & _
        "ostalCode, ShipCountry FROM Orders WHERE (OrderID = @OrderID)"
        Me.sqlUpdateCommand2.Connection = Me.sqlConnection1
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CustomerID", System.Data.SqlDbType.NVarChar, 5, "CustomerID"))
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@EmployeeID", System.Data.SqlDbType.Int, 4, "EmployeeID"))
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@OrderDate", System.Data.SqlDbType.DateTime, 8, "OrderDate"))
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RequiredDate", System.Data.SqlDbType.DateTime, 8, "RequiredDate"))
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ShippedDate", System.Data.SqlDbType.DateTime, 8, "ShippedDate"))
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ShipVia", System.Data.SqlDbType.Int, 4, "ShipVia"))
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Freight", System.Data.SqlDbType.Money, 8, "Freight"))
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ShipName", System.Data.SqlDbType.NVarChar, 40, "ShipName"))
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ShipAddress", System.Data.SqlDbType.NVarChar, 60, "ShipAddress"))
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ShipCity", System.Data.SqlDbType.NVarChar, 15, "ShipCity"))
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ShipRegion", System.Data.SqlDbType.NVarChar, 15, "ShipRegion"))
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ShipPostalCode", System.Data.SqlDbType.NVarChar, 10, "ShipPostalCode"))
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ShipCountry", System.Data.SqlDbType.NVarChar, 15, "ShipCountry"))
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_OrderID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "OrderID", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CustomerID", System.Data.SqlDbType.NVarChar, 5, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CustomerID", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_EmployeeID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "EmployeeID", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Freight", System.Data.SqlDbType.Money, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Freight", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_OrderDate", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "OrderDate", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_RequiredDate", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "RequiredDate", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ShipAddress", System.Data.SqlDbType.NVarChar, 60, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ShipAddress", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ShipCity", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ShipCity", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ShipCountry", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ShipCountry", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ShipName", System.Data.SqlDbType.NVarChar, 40, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ShipName", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ShipPostalCode", System.Data.SqlDbType.NVarChar, 10, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ShipPostalCode", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ShipRegion", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ShipRegion", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ShipVia", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ShipVia", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ShippedDate", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ShippedDate", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@OrderID", System.Data.SqlDbType.Int, 4, "OrderID"))
        '
        'customerSet1
        '
        Me.customerSet1.DataSetName = "CustomerSet"
        Me.customerSet1.Locale = New System.Globalization.CultureInfo("en-US")
        Me.customerSet1.Namespace = "http://tempuri.org/CustomerSet.xsd"
        '
        'commitChangesMenuItem
        '
        Me.commitChangesMenuItem.Index = 3
        Me.commitChangesMenuItem.Text = "&Commit Changes"
        '
        'sqlInsertCommand2
        '
        Me.sqlInsertCommand2.CommandText = "INSERT INTO Orders(CustomerID, EmployeeID, OrderDate, RequiredDate, ShippedDate, " & _
        "ShipVia, Freight, ShipName, ShipAddress, ShipCity, ShipRegion, ShipPostalCode, S" & _
        "hipCountry) VALUES (@CustomerID, @EmployeeID, @OrderDate, @RequiredDate, @Shippe" & _
        "dDate, @ShipVia, @Freight, @ShipName, @ShipAddress, @ShipCity, @ShipRegion, @Shi" & _
        "pPostalCode, @ShipCountry); SELECT OrderID, CustomerID, EmployeeID, OrderDate, R" & _
        "equiredDate, ShippedDate, ShipVia, Freight, ShipName, ShipAddress, ShipCity, Shi" & _
        "pRegion, ShipPostalCode, ShipCountry FROM Orders WHERE (OrderID = @@IDENTITY)"
        Me.sqlInsertCommand2.Connection = Me.sqlConnection1
        Me.sqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CustomerID", System.Data.SqlDbType.NVarChar, 5, "CustomerID"))
        Me.sqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@EmployeeID", System.Data.SqlDbType.Int, 4, "EmployeeID"))
        Me.sqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@OrderDate", System.Data.SqlDbType.DateTime, 8, "OrderDate"))
        Me.sqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RequiredDate", System.Data.SqlDbType.DateTime, 8, "RequiredDate"))
        Me.sqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ShippedDate", System.Data.SqlDbType.DateTime, 8, "ShippedDate"))
        Me.sqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ShipVia", System.Data.SqlDbType.Int, 4, "ShipVia"))
        Me.sqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Freight", System.Data.SqlDbType.Money, 8, "Freight"))
        Me.sqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ShipName", System.Data.SqlDbType.NVarChar, 40, "ShipName"))
        Me.sqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ShipAddress", System.Data.SqlDbType.NVarChar, 60, "ShipAddress"))
        Me.sqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ShipCity", System.Data.SqlDbType.NVarChar, 15, "ShipCity"))
        Me.sqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ShipRegion", System.Data.SqlDbType.NVarChar, 15, "ShipRegion"))
        Me.sqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ShipPostalCode", System.Data.SqlDbType.NVarChar, 10, "ShipPostalCode"))
        Me.sqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ShipCountry", System.Data.SqlDbType.NVarChar, 15, "ShipCountry"))
        '
        'ordersListBox
        '
        Me.ordersListBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ordersListBox.IntegralHeight = False
        Me.ordersListBox.Location = New System.Drawing.Point(0, 91)
        Me.ordersListBox.Name = "ordersListBox"
        Me.ordersListBox.Size = New System.Drawing.Size(288, 99)
        Me.ordersListBox.TabIndex = 5
        '
        'addRowMenuItem
        '
        Me.addRowMenuItem.Index = 0
        Me.addRowMenuItem.Text = "&Add Row"
        '
        'sqlSelectCommand2
        '
        Me.sqlSelectCommand2.CommandText = "SELECT OrderID, CustomerID, EmployeeID, OrderDate, RequiredDate, ShippedDate, Shi" & _
        "pVia, Freight, ShipName, ShipAddress, ShipCity, ShipRegion, ShipPostalCode, Ship" & _
        "Country FROM Orders"
        Me.sqlSelectCommand2.Connection = Me.sqlConnection1
        '
        'deleteSelectedRowMenuItem
        '
        Me.deleteSelectedRowMenuItem.Index = 2
        Me.deleteSelectedRowMenuItem.Text = "&Delete Selected Row"
        '
        'customersListBox
        '
        Me.customersListBox.ContextMenu = Me.contextMenu1
        Me.customersListBox.Dock = System.Windows.Forms.DockStyle.Top
        Me.customersListBox.IntegralHeight = False
        Me.customersListBox.Location = New System.Drawing.Point(0, 3)
        Me.customersListBox.Name = "customersListBox"
        Me.customersListBox.Size = New System.Drawing.Size(288, 88)
        Me.customersListBox.TabIndex = 3
        '
        'contextMenu1
        '
        Me.contextMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.addRowMenuItem, Me.updateSelectedRowMenuItem, Me.deleteSelectedRowMenuItem, Me.commitChangesMenuItem})
        '
        'splitter1
        '
        Me.splitter1.Dock = System.Windows.Forms.DockStyle.Top
        Me.splitter1.Name = "splitter1"
        Me.splitter1.Size = New System.Drawing.Size(288, 3)
        Me.splitter1.TabIndex = 4
        Me.splitter1.TabStop = False
        '
        'sqlDeleteCommand2
        '
        Me.sqlDeleteCommand2.CommandText = "DELETE FROM Orders WHERE (OrderID = @Original_OrderID) AND (CustomerID = @Origina" & _
        "l_CustomerID OR @Original_CustomerID IS NULL AND CustomerID IS NULL) AND (Employ" & _
        "eeID = @Original_EmployeeID OR @Original_EmployeeID IS NULL AND EmployeeID IS NU" & _
        "LL) AND (Freight = @Original_Freight OR @Original_Freight IS NULL AND Freight IS" & _
        " NULL) AND (OrderDate = @Original_OrderDate OR @Original_OrderDate IS NULL AND O" & _
        "rderDate IS NULL) AND (RequiredDate = @Original_RequiredDate OR @Original_Requir" & _
        "edDate IS NULL AND RequiredDate IS NULL) AND (ShipAddress = @Original_ShipAddres" & _
        "s OR @Original_ShipAddress IS NULL AND ShipAddress IS NULL) AND (ShipCity = @Ori" & _
        "ginal_ShipCity OR @Original_ShipCity IS NULL AND ShipCity IS NULL) AND (ShipCoun" & _
        "try = @Original_ShipCountry OR @Original_ShipCountry IS NULL AND ShipCountry IS " & _
        "NULL) AND (ShipName = @Original_ShipName OR @Original_ShipName IS NULL AND ShipN" & _
        "ame IS NULL) AND (ShipPostalCode = @Original_ShipPostalCode OR @Original_ShipPos" & _
        "talCode IS NULL AND ShipPostalCode IS NULL) AND (ShipRegion = @Original_ShipRegi" & _
        "on OR @Original_ShipRegion IS NULL AND ShipRegion IS NULL) AND (ShipVia = @Origi" & _
        "nal_ShipVia OR @Original_ShipVia IS NULL AND ShipVia IS NULL) AND (ShippedDate =" & _
        " @Original_ShippedDate OR @Original_ShippedDate IS NULL AND ShippedDate IS NULL)" & _
        ""
        Me.sqlDeleteCommand2.Connection = Me.sqlConnection1
        Me.sqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_OrderID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "OrderID", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CustomerID", System.Data.SqlDbType.NVarChar, 5, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CustomerID", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_EmployeeID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "EmployeeID", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Freight", System.Data.SqlDbType.Money, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Freight", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_OrderDate", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "OrderDate", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_RequiredDate", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "RequiredDate", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ShipAddress", System.Data.SqlDbType.NVarChar, 60, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ShipAddress", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ShipCity", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ShipCity", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ShipCountry", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ShipCountry", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ShipName", System.Data.SqlDbType.NVarChar, 40, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ShipName", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ShipPostalCode", System.Data.SqlDbType.NVarChar, 10, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ShipPostalCode", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ShipRegion", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ShipRegion", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ShipVia", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ShipVia", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ShippedDate", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ShippedDate", System.Data.DataRowVersion.Original, Nothing))
        '
        'ordersAdapter
        '
        Me.ordersAdapter.DeleteCommand = Me.sqlDeleteCommand2
        Me.ordersAdapter.InsertCommand = Me.sqlInsertCommand2
        Me.ordersAdapter.SelectCommand = Me.sqlSelectCommand2
        Me.ordersAdapter.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Orders", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("OrderID", "OrderID"), New System.Data.Common.DataColumnMapping("CustomerID", "CustomerID"), New System.Data.Common.DataColumnMapping("EmployeeID", "EmployeeID"), New System.Data.Common.DataColumnMapping("OrderDate", "OrderDate"), New System.Data.Common.DataColumnMapping("RequiredDate", "RequiredDate"), New System.Data.Common.DataColumnMapping("ShippedDate", "ShippedDate"), New System.Data.Common.DataColumnMapping("ShipVia", "ShipVia"), New System.Data.Common.DataColumnMapping("Freight", "Freight"), New System.Data.Common.DataColumnMapping("ShipName", "ShipName"), New System.Data.Common.DataColumnMapping("ShipAddress", "ShipAddress"), New System.Data.Common.DataColumnMapping("ShipCity", "ShipCity"), New System.Data.Common.DataColumnMapping("ShipRegion", "ShipRegion"), New System.Data.Common.DataColumnMapping("ShipPostalCode", "ShipPostalCode"), New System.Data.Common.DataColumnMapping("ShipCountry", "ShipCountry")})})
        Me.ordersAdapter.UpdateCommand = Me.sqlUpdateCommand2
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(288, 190)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.ordersListBox, Me.customersListBox, Me.splitter1})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Connection already created
        ' Adapters already created
        ' Data set already created

        ' Fill the data set
        Me.customersAdapter.Fill(Me.customerSet1, "Customers")
        Me.ordersAdapter.Fill(Me.customerSet1, "Orders")

        ' Commands for updating already created
        ' Unique constraint already added
        ' Relation already established
        ' Expression column alread added

        ' Populate Listboxes
        PopulateListBoxes()
    End Sub

    Sub PopulateListBoxes()
        customersListBox.Items.Clear()

        ' Enumerate typed customers
        Dim row As CustomerSet.CustomersRow
        For Each row In Me.customerSet1.Customers.Rows
            If row.RowState And DataRowState.Deleted = 0 Then
                ' Use the typed expression column
                customersListBox.Items.Add(row.ContactTitleName)
            End If
        Next

        PopulateChildListBox()
    End Sub

    Sub PopulateChildListBox()
        ordersListBox.Items.Clear()
        Dim index As Integer = customersListBox.SelectedIndex
        If index = -1 Then Exit Sub

        ' Get row from dataset
        Dim parent As CustomerSet.CustomersRow = Me.customerSet1.Customers(index)

        ' Enumerate typed child order rows using
        ' typed relation method GetOrdersRow
        Dim row As CustomerSet.OrdersRow
        For Each row In parent.GetOrdersRows()
            If row.RowState And DataRowState.Deleted = 0 Then
                ' Use typed properties
                ordersListBox.Items.Add(row.OrderID & ", " & row.OrderDate)
            End If
        Next
    End Sub


    Private Sub customersListBox_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles customersListBox.SelectedIndexChanged
        PopulateChildListBox()
    End Sub

    Private Sub addRowMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles addRowMenuItem.Click
        ' Add a new typed row
        Dim row As CustomerSet.CustomersRow = Me.customerSet1.Customers.NewCustomersRow()
        row.CustomerID = "SELLSB"
        row.CompanyName = "Sells Brothers, Inc."
        row.ContactName = "Chris Sells"
        row.ContactTitle = "Chief Cook and Bottle Washer"
        row.Address = "555 Not My Street"
        row.City = "Beaverton"
        row.CustRegion = "OR"
        row.PostalCode = "97007"
        row.Country = "USA"
        row.Phone = "503-555-1234"
        row.Fax = "503-555-4321"
        Me.customerSet1.Customers.AddCustomersRow(row)

        ' Update listboxes
        PopulateListBoxes()

    End Sub

    Private Sub updateSelectedRowMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles updateSelectedRowMenuItem.Click
        Dim index As Integer = customersListBox.SelectedIndex
        If index = -1 Then Exit Sub

        ' Update a typed row
        Dim row As CustomerSet.CustomersRow = Me.customerSet1.Customers(index)
        row.ContactTitle = "CEO"

        ' Update listboxes
        PopulateListBoxes()

    End Sub

    Private Sub deleteSelectedRowMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles deleteSelectedRowMenuItem.Click
        Dim index As Integer = customersListBox.SelectedIndex
        If index = -1 Then Exit Sub

        ' Mark a typed row as deleted
        Dim row As CustomerSet.CustomersRow = Me.customerSet1.Customers(index)
        row.Delete()

        ' Update listboxes
        PopulateListBoxes()

    End Sub

    Private Sub commitChangesMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles commitChangesMenuItem.Click
        Try
            ' Update a typed table
            Me.customersAdapter.Update(Me.customerSet1.Customers)
        Catch ex As SqlException
            MessageBox.Show(ex.Message, "Error(s) Committing Customer Changes")
        End Try

        Try
            ' Update a typed table
            Me.ordersAdapter.Update(Me.customerSet1.Orders)
        Catch ex As SqlException
            MessageBox.Show(ex.Message, "Error(s) Committing Order Changes")
        End Try

        ' Update listboxes
        PopulateListBoxes()
    End Sub

    
End Class
