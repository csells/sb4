Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Text


Public Class MultiTableForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents deleteSelectedRowMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents commitChangesMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents addRowMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents ordersListBox As System.Windows.Forms.ListBox
    Friend WithEvents splitter1 As System.Windows.Forms.Splitter
    Friend WithEvents customersListBox As System.Windows.Forms.ListBox
    Friend WithEvents contextMenu1 As System.Windows.Forms.ContextMenu
    Friend WithEvents updateSelectedRowMenuItem As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.deleteSelectedRowMenuItem = New System.Windows.Forms.MenuItem()
        Me.commitChangesMenuItem = New System.Windows.Forms.MenuItem()
        Me.addRowMenuItem = New System.Windows.Forms.MenuItem()
        Me.ordersListBox = New System.Windows.Forms.ListBox()
        Me.splitter1 = New System.Windows.Forms.Splitter()
        Me.customersListBox = New System.Windows.Forms.ListBox()
        Me.contextMenu1 = New System.Windows.Forms.ContextMenu()
        Me.updateSelectedRowMenuItem = New System.Windows.Forms.MenuItem()
        Me.SuspendLayout()
        '
        'deleteSelectedRowMenuItem
        '
        Me.deleteSelectedRowMenuItem.Index = 2
        Me.deleteSelectedRowMenuItem.Text = "&Delete Selected Row"
        '
        'commitChangesMenuItem
        '
        Me.commitChangesMenuItem.Index = 3
        Me.commitChangesMenuItem.Text = "&Commit Changes"
        '
        'addRowMenuItem
        '
        Me.addRowMenuItem.Index = 0
        Me.addRowMenuItem.Text = "&Add Row"
        '
        'ordersListBox
        '
        Me.ordersListBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ordersListBox.IntegralHeight = False
        Me.ordersListBox.Name = "ordersListBox"
        Me.ordersListBox.Size = New System.Drawing.Size(312, 318)
        Me.ordersListBox.TabIndex = 5
        '
        'splitter1
        '
        Me.splitter1.Dock = System.Windows.Forms.DockStyle.Top
        Me.splitter1.Location = New System.Drawing.Point(0, 136)
        Me.splitter1.Name = "splitter1"
        Me.splitter1.Size = New System.Drawing.Size(312, 3)
        Me.splitter1.TabIndex = 4
        Me.splitter1.TabStop = False
        '
        'customersListBox
        '
        Me.customersListBox.ContextMenu = Me.contextMenu1
        Me.customersListBox.Dock = System.Windows.Forms.DockStyle.Top
        Me.customersListBox.IntegralHeight = False
        Me.customersListBox.Name = "customersListBox"
        Me.customersListBox.Size = New System.Drawing.Size(312, 136)
        Me.customersListBox.TabIndex = 3
        '
        'contextMenu1
        '
        Me.contextMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.addRowMenuItem, Me.updateSelectedRowMenuItem, Me.deleteSelectedRowMenuItem, Me.commitChangesMenuItem})
        '
        'updateSelectedRowMenuItem
        '
        Me.updateSelectedRowMenuItem.Index = 1
        Me.updateSelectedRowMenuItem.Text = "&Update Selected Row"
        '
        'MultiTableForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(312, 318)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.splitter1, Me.customersListBox, Me.ordersListBox})
        Me.Name = "MultiTableForm"
        Me.Text = "Multi-Table Data Sets"
        Me.ResumeLayout(False)

    End Sub

#End Region

    ' Configure the connection
    Dim conn As SqlConnection = New SqlConnection("data source=MUNGO\NETSDK;initial catalog=northwind;integrated security=SSPI")

    ' Create the adapters
    Dim customersAdapter As SqlDataAdapter = New SqlDataAdapter()
    Dim ordersAdapter As SqlDataAdapter = New SqlDataAdapter()

    ' A data set for use by the form
    Dim ds As DataSet = New DataSet()

    Sub PopulateListBoxes()
        ' Cleat the listbox
        customersListBox.Items.Clear()

        ' Enumerate cached data
        Dim row As DataRow
        For Each row In ds.Tables("customers").Rows
            If row.RowState And DataRowState.Deleted <> 0 Then
                Dim id As String = row("CustomerID", DataRowVersion.Original).ToString()
                customersListBox.Items.Add("***deleted***: " & id)
            Else
                ' Use the expression instead of composing the string
                'Dim item As String = row("ContactTitle") & ", " & row("ContactName")
                Dim item As String = row("ContactTitleName").ToString()
                'item += String.Format(" ({2})", row.RowState)
                If row.HasErrors Then item += "(***" & row.RowError & "***)"
                customersListBox.Items.Add(item)
            End If
        Next
        PopulateChildListBox()
    End Sub

    Sub PopulateChildListBox()
        ' Clear the listbox
        ordersListBox.Items.Clear()

        ' Get the currently selected parent custom row
        Dim index As Integer = customersListBox.SelectedIndex
        If index = -1 Then Exit Sub

        ' Get row from data set
        Dim parent As DataRow = ds.Tables("Customers").Rows(index)

        ' Enumerate child rows
        Dim row As DataRow
        For Each row In parent.GetChildRows("CustomersOrders")
            If row.RowState And DataRowState.Deleted <> 0 Then
                Dim id As String = row("OrderID", DataRowVersion.Original).ToString()
                ordersListBox.Items.Add("***deleted***: " & id)
            Else
                Dim item As String = row("OrderID") & ", " & row("OrderDate") & ", " & row("CustomerContactName")
                'item += String.Format(" ({2})", row.RowState)
                If row.HasErrors Then item += "(***" & row.RowError & "***)"
                ordersListBox.Items.Add(item)
            End If
        Next
    End Sub

    Private Sub MultiTableForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Create the Customer adapter from the connection
        customersAdapter.SelectCommand = conn.CreateCommand()
        customersAdapter.SelectCommand.CommandText = "select * from customers"

        ' Fill the data set w/ the customers table
        customersAdapter.Fill(ds, "Customers")

        ' Create the Customer adapter from the connection
        ordersAdapter.SelectCommand = conn.CreateCommand()
        ordersAdapter.SelectCommand.CommandText = "select * from orders"

        ' Fill the data set w/ the Orders table
        ordersAdapter.Fill(ds, "Orders")

        ' Need one command builder for each adapter
        ' in anticipation of eventually committing changes
        Dim scb1 As SqlCommandBuilder = New SqlCommandBuilder(customersAdapter)
        Dim scb2 As SqlCommandBuilder = New SqlCommandBuilder(ordersAdapter)

        ' Get reference of the tables
        Dim customers As DataTable = ds.Tables("Customers")
        Dim orders As DataTable = ds.Tables("Orders")

        ' Add a constraint
        Dim constraint As UniqueConstraint = New UniqueConstraint(customers.Columns("CustomerID"))
        customers.Constraints.Add(constraint)

        ' Create the relation
        Dim relation As DataRelation = New DataRelation("CustomersOrders", _
                                                        customers.Columns("CustoemrID"), _
                                                        orders.Columns("CustomerID"))

        ' Add the relation
        ds.Relations.Add(relation)

        ' Create the expression column
        Dim exp As DataColumn = New DataColumn()
        exp.ColumnName = "ContactTitleName"
        exp.DataType = GetType(String)
        exp.Expression = "ContactTitle + ', ' + ContactName"

        ' Add it to the customer table
        ds.Tables("Customers").Columns.Add(exp)

        ' Create the expression column
        Dim exp2 As DataColumn = New DataColumn()
        exp2.ColumnName = "CustomerContactName"
        exp2.DataType = GetType(String)
        exp2.Expression = "parent(CustomersOrders).ContactName"

        ' add it to the orders table
        ds.Tables("Orders").Columns.Add(exp2)

        ' Populate listboxes
        PopulateListBoxes()
    End Sub

    Private Sub addRowMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles addRowMenuItem.Click
        ' Ask table for an empty DataRow
        Dim row As DataRow = ds.Tables(0).NewRow()

        ' Fill datarow
        row("CustomerID") = "SELLSB"
        row("CompanyName") = "Sells Brothers, Inc."
        row("ContactName") = "Chris Sells"
        row("ContactTitle") = "Chief Cook and Bottle Washer"
        row("Address") = "555 Not My Street"
        row("City") = "Beaverton"
        row("Region") = "OR"
        row("PostalCode") = "97007"
        row("Country") = "USA"
        row("Phone") = "503-555-1234"
        row("Fax") = "503-555-4321"

        ' Add datarow to the table
        ds.Tables(0).Rows.Add(row)

        ' Update listboxes
        PopulateListBoxes()
    End Sub

    Private Sub updateSelectedRowMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles updateSelectedRowMenuItem.Click
        ' Get selection index from listbox
        Dim index As Integer = customersListBox.SelectedIndex
        If index = -1 Then Exit Sub

        ' Get row from dataset
        Dim row As DataRow = ds.Tables(0).Rows(index)

        ' Update the row as appropriate
        row("ContactTitle") = "CEO"

        Dim tablechanges As DataTable = ds.Tables(0).GetChanges(DataRowState.Modified)
        If Not tablechanges Is Nothing Then
            Dim changedrow As DataRow
            For Each changedrow In tablechanges.Rows
                MessageBox.Show(changedrow("CustomerID") & " modified")
            Next
        End If

        ' Update listboxes
        PopulateListBoxes()
    End Sub

    Private Sub deleteSelectedRowMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles deleteSelectedRowMenuItem.Click
        ' Get selection index from listbox
        Dim index As Integer = customersListBox.SelectedIndex
        If index = -1 Then Exit Sub

        ' get row from dataset
        Dim row As DataRow = ds.Tables(0).Rows(index)

        ' Mark the row as deleted
        row.Delete()

        Dim tablechanges As DataTable = ds.Tables(0).GetChanges(DataRowState.Deleted)
        If Not tablechanges Is Nothing Then
            Dim deletedrow As DataRow
            For Each deletedrow In tablechanges.Rows
                MessageBox.Show("***deleted***" & deletedrow("CustomerID", DataRowVersion.Original))
            Next
        End If

        ' Update listboxes
        PopulateListBoxes()
    End Sub

    Private Sub commitChangesMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles commitChangesMenuItem.Click
        ' Commit customer changes back to the data source
        Try
            customersAdapter.Update(ds, "Customers")
        Catch ex As SqlException
            MessageBox.Show(ex.Message, "Error(s) Committing Customer Changes")
        End Try

        ' Commit orders changes back to the data source
        Try
            ordersAdapter.Update(ds, "Orders")
        Catch ex As SqlException
            MessageBox.Show(ex.Message, "Error(s) Committing Order Changes")
        End Try

        ' Update listboxes
        PopulateListBoxes()
    End Sub

    Private Sub customersListBox_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles customersListBox.SelectedIndexChanged
        PopulateChildListBox()
    End Sub
End Class
