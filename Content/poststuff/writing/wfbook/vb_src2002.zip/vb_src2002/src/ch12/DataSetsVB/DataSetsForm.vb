Imports System.Data
Imports System.Data.SqlClient
Imports System.Text


Public Class DataSetsForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents commitChangesMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents listBox1 As System.Windows.Forms.ListBox
    Friend WithEvents contextMenu1 As System.Windows.Forms.ContextMenu
    Friend WithEvents addRowMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents updateSelectedRowMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents deleteSelectedRowMenuItem As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.commitChangesMenuItem = New System.Windows.Forms.MenuItem()
        Me.listBox1 = New System.Windows.Forms.ListBox()
        Me.contextMenu1 = New System.Windows.Forms.ContextMenu()
        Me.addRowMenuItem = New System.Windows.Forms.MenuItem()
        Me.updateSelectedRowMenuItem = New System.Windows.Forms.MenuItem()
        Me.deleteSelectedRowMenuItem = New System.Windows.Forms.MenuItem()
        Me.SuspendLayout()
        '
        'commitChangesMenuItem
        '
        Me.commitChangesMenuItem.Index = 3
        Me.commitChangesMenuItem.Text = "&Commit Changes"
        '
        'listBox1
        '
        Me.listBox1.ContextMenu = Me.contextMenu1
        Me.listBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.listBox1.IntegralHeight = False
        Me.listBox1.Name = "listBox1"
        Me.listBox1.Size = New System.Drawing.Size(292, 266)
        Me.listBox1.TabIndex = 1
        '
        'contextMenu1
        '
        Me.contextMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.addRowMenuItem, Me.updateSelectedRowMenuItem, Me.deleteSelectedRowMenuItem, Me.commitChangesMenuItem})
        '
        'addRowMenuItem
        '
        Me.addRowMenuItem.Index = 0
        Me.addRowMenuItem.Text = "&Add Row"
        '
        'updateSelectedRowMenuItem
        '
        Me.updateSelectedRowMenuItem.Index = 1
        Me.updateSelectedRowMenuItem.Text = "&Update Selected Row"
        '
        'deleteSelectedRowMenuItem
        '
        Me.deleteSelectedRowMenuItem.Index = 2
        Me.deleteSelectedRowMenuItem.Text = "&Delete Selected Row"
        '
        'DataSetsForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.listBox1})
        Me.Name = "DataSetsForm"
        Me.Text = "DataSetsForm"
        Me.ResumeLayout(False)

    End Sub

#End Region

    ' A data set for use by the form
    Dim ds As DataSet = New DataSet()

    Sub PopulateListBox()
        ' clear the listbox
        listBox1.Items.Clear()

        ' Enumerate cached data
        Dim row As DataRow
        For Each row In ds.Tables(0).Rows
            If row.RowState And DataRowState.Deleted <> 0 Then
                Dim id As String = row("CustomerID", DataRowVersion.Original).ToString()
                listBox1.Items.Add("***deleted***: " & id)
            Else
                Dim item As String = row("ContactTitle") & ", " & row("ContactName")
                If row.HasErrors Then item += "(***" & row.RowError & "***)"
                listBox1.Items.Add(item)
            End If
        Next
    End Sub

    Private Sub DataSetsForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Configure the connection
        Dim conn As SqlConnection = New SqlConnection("data source=MUNGO\NETSDK;initial catalog=northwind;integrated security=SSPI")

        ' Create the adapter from the connection
        Dim adapter As SqlDataAdapter = New SqlDataAdapter(conn.CreateCommand())
        adapter.SelectCommand.CommandText = "select * from customers"

        ' Fill the data set w/ the customers table
        adapter.Fill(ds)

        ' Populate listbox
        PopulateListBox()
    End Sub

    Private Sub addRowMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles addRowMenuItem.Click
        ' Ask table for an empty datarow
        Dim row As DataRow = ds.Tables(0).NewRow()

        ' Fill datarow
        row("CustomerID") = "SELLSDB"
        row("CompanyName") = "Sells Brothers, Inc."
        row("ContactName") = "Chris Sells"
        row("COntactTitle") = "Chief Cook and Bottle Washer"
        row("Address") = "555 Not My Street"
        row("City") = "Beaverton"
        row("Region") = "OR"
        row("PostalCode") = "97007"
        row("Country") = "USA"
        row("Phone") = "503-555-1234"
        row("Fax") = "503-555-4321"

        ' Add datarow to the table
        ds.Tables(0).Rows.Add(row)

        ' Update listbox
        PopulateListBox()
    End Sub

    Private Sub updateSelectedRowMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles updateSelectedRowMenuItem.Click
        ' Get selection index from listbox
        Dim index As Integer = listBox1.SelectedIndex
        If index = -1 Then Exit Sub

        ' Get row from dataset
        Dim row As DataRow = ds.Tables(0).Rows(index)

        ' Update the row as appropriate
        row("ContactTitle") = "CEO"

        Dim tableChanges As DataTable = ds.Tables(0).GetChanges(DataRowState.Modified)
        If Not tableChanges Is Nothing Then
            Dim changedRow As DataRow
            For Each changedRow In tableChanges.Rows
                MessageBox.Show(changedRow("CustomerID") & " modified")
            Next
        End If
    End Sub


    Private Sub deleteSelectedRowMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles deleteSelectedRowMenuItem.Click
        ' Get selection index from listbox
        Dim index As Integer = listBox1.SelectedIndex
        If index = -1 Then Exit Sub

        ' Get row from dataset
        Dim row As DataRow = ds.Tables(0).Rows(index)

        ' Remove the row from the dataset
        'ds.Tables(0).Rows.Remove(row)

        ' Mark the row as deleted
        row.Delete()

        Dim tableChanges As DataTable = ds.Tables(0).GetChanges(DataRowState.Deleted)
        If Not tableChanges Is Nothing Then
            Dim deletedrow As DataRow
            For Each deletedrow In tableChanges.Rows
                MessageBox.Show("***deleted***" & deletedrow("CustomerID", DataRowVersion.Original))
            Next
        End If

        ' Update listbox
        PopulateListBox()
    End Sub

    Private Sub commitChangesMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles commitChangesMenuItem.Click
        ' Configure the connection
        Dim conn As SqlConnection = New SqlConnection("data source=MUNGO\NETSDK;initial catalog=northwind;integrated security=SSPI")

        ' Create the adapter from the connection w/ a select command
        Dim adapter As SqlDataAdapter = New SqlDataAdapter("select * from customers", conn)

        ' Let command builder build commands for insert, update and delete
        Dim scb As SqlCommandBuilder = New SqlCommandBuilder(adapter)

        ' Commit changes back to the data source
        Try
            adapter.Update(ds)
        Catch ex As SqlException
            MessageBox.Show(ex.Message, "Error(s) Committing Changes")
        End Try

        ' Update listbox
        PopulateListBox()
    End Sub
End Class
