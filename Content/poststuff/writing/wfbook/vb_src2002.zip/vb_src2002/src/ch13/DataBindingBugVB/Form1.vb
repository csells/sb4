Imports System
Imports System.Globalization
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data


Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents groupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents simpleTextBox As System.Windows.Forms.TextBox
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents button2 As System.Windows.Forms.Button
    Friend WithEvents label4 As System.Windows.Forms.Label
    Friend WithEvents groupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents customTextBox As System.Windows.Forms.TextBox
    Friend WithEvents label5 As System.Windows.Forms.Label
    Friend WithEvents button3 As System.Windows.Forms.Button
    Friend WithEvents label6 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.groupBox1 = New System.Windows.Forms.GroupBox()
        Me.simpleTextBox = New System.Windows.Forms.TextBox()
        Me.label3 = New System.Windows.Forms.Label()
        Me.button2 = New System.Windows.Forms.Button()
        Me.label4 = New System.Windows.Forms.Label()
        Me.groupBox2 = New System.Windows.Forms.GroupBox()
        Me.customTextBox = New System.Windows.Forms.TextBox()
        Me.label5 = New System.Windows.Forms.Label()
        Me.button3 = New System.Windows.Forms.Button()
        Me.label6 = New System.Windows.Forms.Label()
        Me.groupBox1.SuspendLayout()
        Me.groupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'groupBox1
        '
        Me.groupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.simpleTextBox, Me.label3, Me.button2, Me.label4})
        Me.groupBox1.Location = New System.Drawing.Point(12, 15)
        Me.groupBox1.Name = "groupBox1"
        Me.groupBox1.Size = New System.Drawing.Size(272, 128)
        Me.groupBox1.TabIndex = 6
        Me.groupBox1.TabStop = False
        Me.groupBox1.Text = "Binding against a simple type"
        '
        'simpleTextBox
        '
        Me.simpleTextBox.Location = New System.Drawing.Point(160, 24)
        Me.simpleTextBox.Name = "simpleTextBox"
        Me.simpleTextBox.TabIndex = 1
        Me.simpleTextBox.Text = "textBox1"
        '
        'label3
        '
        Me.label3.Location = New System.Drawing.Point(24, 24)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(128, 23)
        Me.label3.TabIndex = 0
        Me.label3.Text = "1. Change data here"
        '
        'button2
        '
        Me.button2.Location = New System.Drawing.Point(24, 56)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(128, 23)
        Me.button2.TabIndex = 5
        Me.button2.Text = "2. .Set focus here"
        Me.button2.TextAlign = System.Drawing.ContentAlignment.TopLeft
        '
        'label4
        '
        Me.label4.Location = New System.Drawing.Point(24, 88)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(152, 23)
        Me.label4.TabIndex = 6
        Me.label4.Text = "3. Notice data changed"
        '
        'groupBox2
        '
        Me.groupBox2.Controls.AddRange(New System.Windows.Forms.Control() {Me.customTextBox, Me.label5, Me.button3, Me.label6})
        Me.groupBox2.Location = New System.Drawing.Point(300, 15)
        Me.groupBox2.Name = "groupBox2"
        Me.groupBox2.Size = New System.Drawing.Size(272, 128)
        Me.groupBox2.TabIndex = 5
        Me.groupBox2.TabStop = False
        Me.groupBox2.Text = "Binding against a custom type"
        '
        'customTextBox
        '
        Me.customTextBox.Location = New System.Drawing.Point(160, 24)
        Me.customTextBox.Name = "customTextBox"
        Me.customTextBox.TabIndex = 1
        Me.customTextBox.Text = "textBox1"
        '
        'label5
        '
        Me.label5.Location = New System.Drawing.Point(24, 24)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(128, 23)
        Me.label5.TabIndex = 0
        Me.label5.Text = "1. Change data here"
        '
        'button3
        '
        Me.button3.Location = New System.Drawing.Point(24, 56)
        Me.button3.Name = "button3"
        Me.button3.Size = New System.Drawing.Size(128, 23)
        Me.button3.TabIndex = 5
        Me.button3.Text = "2. .Set focus here"
        Me.button3.TextAlign = System.Drawing.ContentAlignment.TopLeft
        '
        'label6
        '
        Me.label6.Location = New System.Drawing.Point(24, 88)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(152, 23)
        Me.label6.TabIndex = 6
        Me.label6.Text = "3. Notice data *not* changed"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(584, 158)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.groupBox1, Me.groupBox2})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.groupBox1.ResumeLayout(False)
        Me.groupBox2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region


    Class FractionTypeConverter
        Inherits TypeConverter

        Public Overloads Overrides Function CanConvertFrom(ByVal context As ITypeDescriptorContext, ByVal sourceType As Type) As Boolean
            Return sourceType Is GetType(String)
        End Function

        ' defaults to "true" when asking for a string
        Public Overloads Overrides Function CanConvertTo(ByVal context As ITypeDescriptorContext, ByVal destinationType As Type) As Boolean
            Return destinationType Is GetType(String)
        End Function

        Public Overloads Overrides Function ConvertFrom(ByVal context As ITypeDescriptorContext, ByVal culture As CultureInfo, ByVal value As Object) As Object
            ' Very simple, context, culture and error ignoring conversion
            Dim from As String = CStr(value)
            Dim slash As Integer = from.IndexOf("/")
            Dim numerator As Integer = Integer.Parse(from.Substring(0, slash))
            Dim denominator As Integer = Integer.Parse(from.Substring(slash + 1))
            Return New Fraction(numerator, denominator)
        End Function

        ' default to using ToString
        Public Overloads Overrides Function ConvertTo(ByVal context As ITypeDescriptorContext, ByVal culture As CultureInfo, ByVal value As Object, ByVal destinationType As Type) As Object
            If Not destinationType Is GetType(String) Then Return Nothing
            Dim number As Fraction = CType(value, Fraction)
            Return String.Format("{0}/{1}", number.Numerator, number.Denominator)
        End Function
    End Class

    <TypeConverter(GetType(FractionTypeConverter))> _
    Public Class Fraction
        Private _numerator As Integer
        Private _denominator As Integer

        Public Sub New(ByVal numerator As Integer, ByVal denominator As Integer)
            Me.Numerator = numerator
            Me.Denominator = denominator
        End Sub

        Public Property Numerator() As Integer
            Get
                Return _numerator
            End Get
            Set(ByVal Value As Integer)
                _numerator = Value
            End Set
        End Property

        Public Property Denominator() As Integer
            Get
                Return _denominator
            End Get
            Set(ByVal Value As Integer)
                _denominator = Value
            End Set
        End Property
    End Class

    Public Class NameAndNumber
        Dim _name As String = "Chris"
        Dim _number As Fraction = New Fraction(452, 1)

        Public Event NameChanged As EventHandler
        Public Event NumberChanged As EventHandler

        Public Property Name() As String
            Get
                Return _name
            End Get
            Set(ByVal Value As String)
                _name = Value
                RaiseEvent NameChanged(Me, EventArgs.Empty)
            End Set
        End Property

        Public Property Number() As Fraction
            Get
                Return _number
            End Get
            Set(ByVal Value As Fraction)
                _number = Value
                RaiseEvent NumberChanged(Me, EventArgs.Empty)
            End Set
        End Property

        Public Overloads Overrides Function ToString() As String
            Return String.Format("{0}: {1}/{2}", Me.Name, Me.Number.Numerator, Me.Number.Denominator)
        End Function
    End Class

    Public Class WorkAroundBinding
        Inherits Binding
        Public Sub New(ByVal propertyName As String, ByVal dataSource As Object, ByVal dataMember As String)
            MyBase.New(propertyName, dataSource, dataMember)
        End Sub

        Protected Overloads Overrides Sub OnFormat(ByVal e As ConvertEventArgs)
            System.Diagnostics.Debug.WriteLine(String.Format("WorkAroundBinding.OnFormat: sourceValue= '{0}', sourceType= {1}, desiredType= {2}", e.Value, e.Value.GetType(), e.DesiredType))
            MyBase.OnFormat(e)
        End Sub

        Protected Overloads Overrides Sub OnParse(ByVal e As ConvertEventArgs)
            System.Diagnostics.Debug.WriteLine(String.Format("WorkAroundBinding.OnParse: sourceValue= '{0}', sourceType= {1}, desiredType= {2}", e.Value, e.Value.GetType(), e.DesiredType))
            Try
                ' Let the base class have a crack
                MyBase.OnParse(e)
            Catch ex As InvalidCastException
                ' Take over for base class if it fails

                ' If one of the base class event handlers voncerted it, we're done
                If (e.Value.GetType().IsSubclassOf(e.DesiredType) Or e.Value.GetType() Is e.DesiredType Or e.Value Is GetType(DBNull)) Then
                    Exit Sub
                End If

                ' Ask the desired type for a type converter
                Dim _typeConverter As TypeConverter = TypeDescriptor.GetConverter(e.DesiredType)
                If Not _typeConverter Is Nothing And _typeConverter.CanConvertFrom(e.Value.GetType()) Then
                    e.Value = _typeConverter.ConvertFrom(e.Value)
                End If

            End Try
        End Sub
    End Class

    ' This will override the WorkAroundBinding (if it's hooked up)
    Sub ParseCustomType(ByVal sender As Object, ByVal e As ConvertEventArgs)
        ' Let the type converter do the work
        Dim converter As TypeConverter = TypeDescriptor.GetConverter(e.DesiredType)
        If converter Is Nothing Then Exit Sub
        If Not converter.CanConvertFrom(e.Value.GetType()) Then Exit Sub
        e.Value = converter.ConvertFrom(e.Value)
    End Sub

    Dim source As NameAndNumber = New NameAndNumber()


    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Simple data types bind just fine
        simpleTextBox.DataBindings.Add("Text", source, "Name")

        ' Simple data types bind with WorkAroundBinding, too
        'simpleTextBox.DataBindings.Add(New WorkAroundBinding("Text", source, "Name"))

        ' Both methods fail in OnParse
        'customTextBox.DataBindings.Add(New Binding("Text", source, "Number"))
        'Dim _binding As Binding = customTextBox.DataBindings.Add("Text", source, "Number")
        'AddHandler _binding.Parse, New ConvertEventHandler(AddressOf ParseCustomType)

        ' WORKAROUND: Stops failure in OnParse
        Dim _binding As Binding = New WorkAroundBinding("Text", source, "Number")
        customTextBox.DataBindings.Add(_binding)
        'AddHandler _binding.Parse, New ConvertEventHandler(AddressOf ParseCustomType)

    End Sub

    Private Sub button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles button3.Click
        MessageBox.Show(source.ToString())
    End Sub
End Class
