Imports System.Text.RegularExpressions

Public Class ControlBehavior
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents groupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents label5 As System.Windows.Forms.Label
    Friend WithEvents label4 As System.Windows.Forms.Label
    Friend WithEvents textBox4 As System.Windows.Forms.TextBox
    Friend WithEvents groupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents button3 As System.Windows.Forms.Button
    Friend WithEvents textBox3 As System.Windows.Forms.TextBox
    Friend WithEvents groupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents button2 As System.Windows.Forms.Button
    Friend WithEvents textBox2 As System.Windows.Forms.TextBox
    Friend WithEvents groupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    Friend WithEvents progressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents radioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents checkBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents activeCtlLabel As System.Windows.Forms.Label
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents textBox1 As System.Windows.Forms.TextBox
    Friend WithEvents timer1 As System.Windows.Forms.Timer
    Friend WithEvents errorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents toolTip1 As System.Windows.Forms.ToolTip
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.groupBox4 = New System.Windows.Forms.GroupBox()
        Me.label5 = New System.Windows.Forms.Label()
        Me.label4 = New System.Windows.Forms.Label()
        Me.textBox4 = New System.Windows.Forms.TextBox()
        Me.groupBox3 = New System.Windows.Forms.GroupBox()
        Me.button3 = New System.Windows.Forms.Button()
        Me.textBox3 = New System.Windows.Forms.TextBox()
        Me.groupBox2 = New System.Windows.Forms.GroupBox()
        Me.button2 = New System.Windows.Forms.Button()
        Me.textBox2 = New System.Windows.Forms.TextBox()
        Me.groupBox1 = New System.Windows.Forms.GroupBox()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.progressBar1 = New System.Windows.Forms.ProgressBar()
        Me.radioButton1 = New System.Windows.Forms.RadioButton()
        Me.checkBox1 = New System.Windows.Forms.CheckBox()
        Me.button1 = New System.Windows.Forms.Button()
        Me.activeCtlLabel = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.label1 = New System.Windows.Forms.Label()
        Me.textBox1 = New System.Windows.Forms.TextBox()
        Me.timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.errorProvider1 = New System.Windows.Forms.ErrorProvider()
        Me.toolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.groupBox4.SuspendLayout()
        Me.groupBox3.SuspendLayout()
        Me.groupBox2.SuspendLayout()
        Me.groupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'groupBox4
        '
        Me.groupBox4.Controls.AddRange(New System.Windows.Forms.Control() {Me.label5, Me.label4, Me.textBox4})
        Me.groupBox4.Location = New System.Drawing.Point(7, 385)
        Me.groupBox4.Name = "groupBox4"
        Me.groupBox4.Size = New System.Drawing.Size(329, 106)
        Me.groupBox4.TabIndex = 7
        Me.groupBox4.TabStop = False
        Me.groupBox4.Text = "Keyboard Handling"
        '
        'label5
        '
        Me.label5.Location = New System.Drawing.Point(15, 76)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(299, 22)
        Me.label5.TabIndex = 2
        Me.label5.Text = "label5"
        '
        'label4
        '
        Me.label4.Location = New System.Drawing.Point(15, 53)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(299, 22)
        Me.label4.TabIndex = 1
        Me.label4.Text = "label4"
        '
        'textBox4
        '
        Me.textBox4.Location = New System.Drawing.Point(15, 23)
        Me.textBox4.Name = "textBox4"
        Me.textBox4.Size = New System.Drawing.Size(292, 20)
        Me.textBox4.TabIndex = 0
        Me.textBox4.Text = "textBox4"
        '
        'groupBox3
        '
        Me.groupBox3.Controls.AddRange(New System.Windows.Forms.Control() {Me.button3, Me.textBox3})
        Me.groupBox3.Location = New System.Drawing.Point(7, 256)
        Me.groupBox3.Name = "groupBox3"
        Me.groupBox3.Size = New System.Drawing.Size(329, 95)
        Me.groupBox3.TabIndex = 6
        Me.groupBox3.TabStop = False
        Me.groupBox3.Text = "Drag-n-Drop"
        '
        'button3
        '
        Me.button3.Location = New System.Drawing.Point(7, 61)
        Me.button3.Name = "button3"
        Me.button3.Size = New System.Drawing.Size(69, 21)
        Me.button3.TabIndex = 2
        Me.button3.Text = "Howdie"
        '
        'textBox3
        '
        Me.textBox3.AllowDrop = True
        Me.textBox3.Location = New System.Drawing.Point(7, 23)
        Me.textBox3.Multiline = True
        Me.textBox3.Name = "textBox3"
        Me.textBox3.Size = New System.Drawing.Size(307, 30)
        Me.textBox3.TabIndex = 0
        Me.textBox3.Text = "textbox3"
        '
        'groupBox2
        '
        Me.groupBox2.Controls.AddRange(New System.Windows.Forms.Control() {Me.button2, Me.textBox2})
        Me.groupBox2.Location = New System.Drawing.Point(7, 150)
        Me.groupBox2.Name = "groupBox2"
        Me.groupBox2.Size = New System.Drawing.Size(329, 99)
        Me.groupBox2.TabIndex = 5
        Me.groupBox2.TabStop = False
        Me.groupBox2.Text = "Validating Controls"
        '
        'button2
        '
        Me.button2.Location = New System.Drawing.Point(227, 61)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(87, 21)
        Me.button2.TabIndex = 1
        Me.button2.Text = "Does Nothing"
        '
        'textBox2
        '
        Me.textBox2.Location = New System.Drawing.Point(7, 30)
        Me.textBox2.Name = "textBox2"
        Me.textBox2.Size = New System.Drawing.Size(256, 20)
        Me.textBox2.TabIndex = 0
        Me.textBox2.Text = "textBox2"
        '
        'groupBox1
        '
        Me.groupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblStatus, Me.progressBar1, Me.radioButton1, Me.checkBox1, Me.button1, Me.activeCtlLabel, Me.label2, Me.label1, Me.textBox1})
        Me.groupBox1.Location = New System.Drawing.Point(7, 7)
        Me.groupBox1.Name = "groupBox1"
        Me.groupBox1.Size = New System.Drawing.Size(329, 136)
        Me.groupBox1.TabIndex = 4
        Me.groupBox1.TabStop = False
        Me.groupBox1.Text = "Focus and The Active Control"
        '
        'lblStatus
        '
        Me.lblStatus.Location = New System.Drawing.Point(7, 106)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(307, 22)
        Me.lblStatus.TabIndex = 5
        Me.lblStatus.Text = "label3"
        Me.lblStatus.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'progressBar1
        '
        Me.progressBar1.Location = New System.Drawing.Point(7, 68)
        Me.progressBar1.Name = "progressBar1"
        Me.progressBar1.Size = New System.Drawing.Size(307, 8)
        Me.progressBar1.TabIndex = 4
        '
        'radioButton1
        '
        Me.radioButton1.Location = New System.Drawing.Point(102, 45)
        Me.radioButton1.Name = "radioButton1"
        Me.radioButton1.Size = New System.Drawing.Size(95, 23)
        Me.radioButton1.TabIndex = 3
        Me.radioButton1.Text = "radioButton1"
        '
        'checkBox1
        '
        Me.checkBox1.Location = New System.Drawing.Point(7, 45)
        Me.checkBox1.Name = "checkBox1"
        Me.checkBox1.Size = New System.Drawing.Size(95, 23)
        Me.checkBox1.TabIndex = 2
        Me.checkBox1.Text = "checkBox1"
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(227, 30)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(68, 22)
        Me.button1.TabIndex = 1
        Me.button1.Text = "button1"
        '
        'activeCtlLabel
        '
        Me.activeCtlLabel.Location = New System.Drawing.Point(132, 83)
        Me.activeCtlLabel.Name = "activeCtlLabel"
        Me.activeCtlLabel.Size = New System.Drawing.Size(189, 22)
        Me.activeCtlLabel.TabIndex = 3
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(7, 83)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(125, 22)
        Me.label2.TabIndex = 2
        Me.label2.Text = "The Active Control is:"
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(7, 23)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(81, 21)
        Me.label1.TabIndex = 1
        Me.label1.Text = "label1"
        '
        'textBox1
        '
        Me.textBox1.Location = New System.Drawing.Point(102, 23)
        Me.textBox1.Name = "textBox1"
        Me.textBox1.Size = New System.Drawing.Size(92, 20)
        Me.textBox1.TabIndex = 0
        Me.textBox1.Text = "textBox1"
        '
        'timer1
        '
        Me.timer1.Interval = 250
        '
        'ControlBehavior
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(343, 499)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.groupBox4, Me.groupBox3, Me.groupBox2, Me.groupBox1})
        Me.Name = "ControlBehavior"
        Me.Text = "ControlBehavior"
        Me.groupBox4.ResumeLayout(False)
        Me.groupBox3.ResumeLayout(False)
        Me.groupBox2.ResumeLayout(False)
        Me.groupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button3.Click

    End Sub

#Region "ActiveControl"
    Sub timer1_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles timer1.Tick
        activeCtlLabel.Text = ActiveControl.Name
    End Sub
    Sub textbox1_Leave(ByVal sender As Object, ByVal e As EventArgs) Handles textBox1.Leave
        lblStatus.Text = "Left textbox1"
    End Sub
    Sub textbox1_Enter(ByVal sender As Object, ByVal e As EventArgs) Handles textBox1.EnabledChanged
        lblStatus.Text = "Entered textbox1"
    End Sub
    Sub button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles button1.Click
        textBox1.Focus()
    End Sub
#End Region


#Region "Validation"
    Sub textbox2_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles textBox2.Validating
        If textBox2.Text.Length = 0 Or textBox2.Text.StartsWith(" ") Then
            e.Cancel = True
            errorProvider1.SetError(textBox2, "TextBox cannot be empty or start with a space")

        End If
    End Sub
    Sub textbox2_Validated(ByVal sender As Object, ByVal e As EventArgs) Handles textBox2.Validated
        errorProvider1.SetError(textBox2, "")
    End Sub
#End Region

#Region "Drag-n-Drop"
    Sub textbox3_DragEnter(ByVal sender As Object, ByVal e As DragEventArgs) Handles textBox3.DragEnter
        TestDropType(e)
    End Sub

    Sub textbox3_DragLeave(ByVal sender As Object, ByVal e As EventArgs) Handles textBox3.DragLeave

    End Sub

    Const LMOUSE As Integer = 1
    Const RMOUSE As Integer = 2
    Const SHIFT As Integer = 4
    Const CTRL As Integer = 8
    Const MMOUSE As Integer = 16
    Const ALT As Integer = 32

    Sub TestDropType(ByVal e As DragEventArgs)
        If e.Data.GetDataPresent(GetType(String)) Then
            If (e.KeyState And CTRL) = CTRL Then
                e.Effect = DragDropEffects.Copy
            Else
                e.Effect = DragDropEffects.Move
            End If
        Else
            e.Effect = DragDropEffects.None
        End If
    End Sub

    Sub textbox3_DragOver(ByVal sender As Object, ByVal e As DragEventArgs) Handles textBox3.DragOver
        TestDropType(e)
    End Sub

    Sub textbox3_DragDrop(ByVal sender As Object, ByVal e As DragEventArgs) Handles textBox3.DragDrop
        Dim s As String = e.Data.GetData(GetType(String))
        If (e.Effect And DragDropEffects.Copy) = DragDropEffects.Copy Then
            textBox3.Text = s
        ElseIf (e.Effect And DragDropEffects.Move) = DragDropEffects.Move Then
            textBox3.Text = s
        End If
    End Sub

    Sub textbox3_QueryContinueDrag(ByVal sender As Object, ByVal e As System.Windows.Forms.QueryContinueDragEventArgs) Handles textBox3.QueryContinueDrag
        e.Action = DragAction.Cancel
    End Sub

    Sub button3_MouseDown(ByVal sender As Object, ByVal e As MouseEventArgs) Handles button3.MouseDown
        Dim effects As DragDropEffects = DoDragDrop(button3.Text, DragDropEffects.Copy Or DragDropEffects.Move)
        If effects = DragDropEffects.Move Then
            button3.Text = ""
        End If
    End Sub
#End Region

#Region "Key Handling"
    Private simpleEmailAllowEx As Regex = New Regex("[a-zA-Z@\.\b]+")
    Sub textbox4_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs) Handles textBox4.KeyPress
        Dim mods As String = ""
        If (Control.ModifierKeys And Keys.Shift) = Keys.Shift Then mods = mods & "Shift "
        If (Control.ModifierKeys And Keys.Alt) = Keys.Alt Then mods = mods & "Alt "
        If (Control.ModifierKeys And Keys.Control) = Keys.Control Then mods = mods & "Ctrl "
        label4.Text = mods

        If (simpleEmailAllowEx.Match(e.KeyChar.ToString()).Success = False) Then
            e.Handled = True
        End If
    End Sub

    Sub textbox4_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs) Handles textBox4.KeyDown
        label4.Text = String.Format("key: {0}, Alt({1}), Shift ({2}), Ctrl({3})", Convert.ToChar(e.KeyValue).ToString(), e.Alt, e.Shift, e.Control)

    End Sub

    Sub textbox4_KeyUp(ByVal sender As Object, ByVal e As KeyEventArgs) Handles textBox4.KeyUp
        label5.Text = String.Format("key: {0}, Alt({1}), Shift ({2}), Ctrl({3})", Convert.ToChar(e.KeyValue).ToString(), e.Alt, e.Shift, e.Control)

    End Sub
#End Region

    Private Sub button3_QueryContinueDrag(ByVal sender As Object, ByVal e As System.Windows.Forms.QueryContinueDragEventArgs) Handles button3.QueryContinueDrag
        e.Action = DragAction.Cancel
    End Sub
End Class
