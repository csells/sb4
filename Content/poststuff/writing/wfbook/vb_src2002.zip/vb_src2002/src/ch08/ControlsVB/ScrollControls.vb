
Public Class ScrollControls
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents NewScrollingCtrl1 As ControlsVB.NewScrollingCtrl
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.NewScrollingCtrl1 = New ControlsVB.NewScrollingCtrl(Me.components)
        Me.SuspendLayout()
        '
        'NewScrollingCtrl1
        '
        Me.NewScrollingCtrl1.AutoScroll = True
        Me.NewScrollingCtrl1.AutoScrollMinSize = New System.Drawing.Size(94, 14)
        Me.NewScrollingCtrl1.Location = New System.Drawing.Point(32, 72)
        Me.NewScrollingCtrl1.Name = "NewScrollingCtrl1"
        Me.NewScrollingCtrl1.Size = New System.Drawing.Size(64, 120)
        Me.NewScrollingCtrl1.TabIndex = 0
        Me.NewScrollingCtrl1.Text = "NewScrollingCtrl1"
        '
        'ScrollControls
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(144, 270)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.NewScrollingCtrl1})
        Me.Name = "ScrollControls"
        Me.Text = "ScrollControls"
        Me.ResumeLayout(False)

    End Sub

#End Region

End Class
