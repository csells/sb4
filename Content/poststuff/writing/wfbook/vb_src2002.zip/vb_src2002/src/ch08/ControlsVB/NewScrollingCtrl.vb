Imports System.Drawing
Imports System.Windows.Forms


Public Class NewScrollingCtrl
    Inherits ScrollableControl

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        Me.SetStyle(ControlStyles.SupportsTransparentBackColor Or ControlStyles.UserPaint Or ControlStyles.Opaque Or ControlStyles.ResizeRedraw, True)
    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
    End Sub

#End Region

    Protected Overrides Sub OnPaint(ByVal pe As System.Windows.Forms.PaintEventArgs)
        Dim backBrush As Brush = New SolidBrush(Me.BackColor)
        Dim circleBrush As Brush = New SolidBrush(Color.Red)
        Dim foreBrush As Brush = New SolidBrush(Me.ForeColor)

        Dim rect As RectangleF = New RectangleF(Me.DisplayRectangle.X, Me.DisplayRectangle.Y, Me.DisplayRectangle.Width, Me.DisplayRectangle.Height)
        Dim format As StringFormat = New StringFormat()
        format.Alignment = StringAlignment.Center
        format.LineAlignment = StringAlignment.Center
        format.FormatFlags = StringFormatFlags.NoWrap


        pe.Graphics.FillRectangle(backBrush, rect)
        pe.Graphics.FillEllipse(circleBrush, rect)
        pe.Graphics.DrawString(Me.Text, Me.Font, foreBrush, rect, format)

        foreBrush.Dispose()
        circleBrush.Dispose()
        backBrush.Dispose()

        MyBase.OnPaint(pe)

    End Sub


    Sub SetScrollMinSize()
        Dim g As Graphics = Me.CreateGraphics
        Dim sizeF As SizeF = g.MeasureString(Me.Text, Me.Font)
        Dim size As Size = New Size(CInt(Math.Ceiling(sizeF.Width)), CInt(Math.Ceiling(sizeF.Height)))
        Me.AutoScrollMinSize = size
    End Sub

    Protected Overrides Sub OnTextChanged(ByVal e As System.EventArgs)
        MyBase.OnTextChanged(e)
        Me.Invalidate()
        SetScrollMinSize()
    End Sub

    Protected Overrides Sub OnFontChanged(ByVal e As System.EventArgs)
        MyBase.OnFontChanged(e)
        Me.Invalidate()
        SetScrollMinSize()
    End Sub

    Protected Overrides Sub OnForeColorChanged(ByVal e As System.EventArgs)
        MyBase.OnForeColorChanged(e)
        Me.Invalidate()
    End Sub

    Protected Overrides Sub OnBackColorChanged(ByVal e As System.EventArgs)
        Me.OnBackColorChanged(e)
        Me.Invalidate()
    End Sub
End Class
