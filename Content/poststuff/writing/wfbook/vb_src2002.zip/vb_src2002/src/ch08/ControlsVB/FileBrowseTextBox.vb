Public Class FileBrowseTextBox
    Inherits System.Windows.Forms.UserControl

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'UserControl overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents openFile As System.Windows.Forms.OpenFileDialog
    Friend WithEvents browseButton As System.Windows.Forms.Button
    Friend WithEvents FileTextBox1 As ControlsVB.FileTextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.openFile = New System.Windows.Forms.OpenFileDialog()
        Me.browseButton = New System.Windows.Forms.Button()
        Me.FileTextBox1 = New ControlsVB.FileTextBox(Me.components)
        Me.SuspendLayout()
        '
        'openFile
        '
        Me.openFile.AddExtension = False
        Me.openFile.ShowReadOnly = True
        Me.openFile.Title = "Select File..."
        '
        'browseButton
        '
        Me.browseButton.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.browseButton.Location = New System.Drawing.Point(304, 1)
        Me.browseButton.Name = "browseButton"
        Me.browseButton.Size = New System.Drawing.Size(24, 23)
        Me.browseButton.TabIndex = 2
        Me.browseButton.Text = "..."
        '
        'FileTextBox1
        '
        Me.FileTextBox1.ForeColor = System.Drawing.Color.Red
        Me.FileTextBox1.Name = "FileTextBox1"
        Me.FileTextBox1.Size = New System.Drawing.Size(304, 20)
        Me.FileTextBox1.TabIndex = 3
        Me.FileTextBox1.Text = "FileTextBox1"
        '
        'FileBrowseTextBox
        '
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.FileTextBox1, Me.browseButton})
        Me.Name = "FileBrowseTextBox"
        Me.Size = New System.Drawing.Size(328, 24)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub browseButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles browseButton.Click
        If Me.openFile.ShowDialog = DialogResult.OK Then
            FileTextBox1.Text = Me.openFile.FileName
        End If
    End Sub
End Class
