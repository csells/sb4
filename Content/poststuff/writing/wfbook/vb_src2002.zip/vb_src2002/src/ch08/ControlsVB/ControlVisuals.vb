Public Class ControlVisuals
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents bigImageList As System.Windows.Forms.ImageList
    Friend WithEvents smallImageList As System.Windows.Forms.ImageList
    Friend WithEvents groupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents theTextBox As System.Windows.Forms.TextBox
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents groupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents button10 As System.Windows.Forms.Button
    Friend WithEvents button9 As System.Windows.Forms.Button
    Friend WithEvents button8 As System.Windows.Forms.Button
    Friend WithEvents button4 As System.Windows.Forms.Button
    Friend WithEvents button5 As System.Windows.Forms.Button
    Friend WithEvents button7 As System.Windows.Forms.Button
    Friend WithEvents groupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents treeView1 As System.Windows.Forms.TreeView
    Friend WithEvents groupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents listView1 As System.Windows.Forms.ListView
    Friend WithEvents button6 As System.Windows.Forms.Button
    Friend WithEvents groupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents button3 As System.Windows.Forms.Button
    Friend WithEvents button2 As System.Windows.Forms.Button
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents textBox1 As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(ControlVisuals))
        Me.bigImageList = New System.Windows.Forms.ImageList(Me.components)
        Me.smallImageList = New System.Windows.Forms.ImageList(Me.components)
        Me.groupBox2 = New System.Windows.Forms.GroupBox()
        Me.theTextBox = New System.Windows.Forms.TextBox()
        Me.label2 = New System.Windows.Forms.Label()
        Me.groupBox3 = New System.Windows.Forms.GroupBox()
        Me.button10 = New System.Windows.Forms.Button()
        Me.button9 = New System.Windows.Forms.Button()
        Me.button8 = New System.Windows.Forms.Button()
        Me.button4 = New System.Windows.Forms.Button()
        Me.button5 = New System.Windows.Forms.Button()
        Me.button7 = New System.Windows.Forms.Button()
        Me.groupBox4 = New System.Windows.Forms.GroupBox()
        Me.treeView1 = New System.Windows.Forms.TreeView()
        Me.groupBox5 = New System.Windows.Forms.GroupBox()
        Me.listView1 = New System.Windows.Forms.ListView()
        Me.button6 = New System.Windows.Forms.Button()
        Me.groupBox1 = New System.Windows.Forms.GroupBox()
        Me.button3 = New System.Windows.Forms.Button()
        Me.button2 = New System.Windows.Forms.Button()
        Me.button1 = New System.Windows.Forms.Button()
        Me.label1 = New System.Windows.Forms.Label()
        Me.textBox1 = New System.Windows.Forms.TextBox()
        Me.groupBox2.SuspendLayout()
        Me.groupBox3.SuspendLayout()
        Me.groupBox4.SuspendLayout()
        Me.groupBox5.SuspendLayout()
        Me.groupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'bigImageList
        '
        Me.bigImageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.bigImageList.ImageSize = New System.Drawing.Size(32, 32)
        Me.bigImageList.ImageStream = CType(resources.GetObject("bigImageList.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.bigImageList.TransparentColor = System.Drawing.Color.Transparent
        '
        'smallImageList
        '
        Me.smallImageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.smallImageList.ImageSize = New System.Drawing.Size(16, 16)
        Me.smallImageList.ImageStream = CType(resources.GetObject("smallImageList.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.smallImageList.TransparentColor = System.Drawing.Color.Transparent
        '
        'groupBox2
        '
        Me.groupBox2.Controls.AddRange(New System.Windows.Forms.Control() {Me.theTextBox, Me.label2})
        Me.groupBox2.Location = New System.Drawing.Point(19, 118)
        Me.groupBox2.Name = "groupBox2"
        Me.groupBox2.Size = New System.Drawing.Size(402, 61)
        Me.groupBox2.TabIndex = 6
        Me.groupBox2.TabStop = False
        Me.groupBox2.Text = "Accessibility"
        '
        'theTextBox
        '
        Me.theTextBox.AccessibleDescription = "Full name of the user."
        Me.theTextBox.AccessibleName = "FullName"
        Me.theTextBox.AccessibleRole = System.Windows.Forms.AccessibleRole.Text
        Me.theTextBox.Location = New System.Drawing.Point(117, 23)
        Me.theTextBox.Name = "theTextBox"
        Me.theTextBox.Size = New System.Drawing.Size(270, 20)
        Me.theTextBox.TabIndex = 1
        Me.theTextBox.Text = ""
        '
        'label2
        '
        Me.label2.AccessibleDescription = "Label for the Name Textbox."
        Me.label2.AccessibleName = "TextBoxLabel"
        Me.label2.AccessibleRole = System.Windows.Forms.AccessibleRole.StaticText
        Me.label2.Location = New System.Drawing.Point(15, 23)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(91, 21)
        Me.label2.TabIndex = 0
        Me.label2.Text = "Name:"
        '
        'groupBox3
        '
        Me.groupBox3.Controls.AddRange(New System.Windows.Forms.Control() {Me.button10, Me.button9, Me.button8, Me.button4})
        Me.groupBox3.Location = New System.Drawing.Point(19, 186)
        Me.groupBox3.Name = "groupBox3"
        Me.groupBox3.Size = New System.Drawing.Size(402, 131)
        Me.groupBox3.TabIndex = 8
        Me.groupBox3.TabStop = False
        Me.groupBox3.Text = "Owner Drawn Controls"
        '
        'button10
        '
        Me.button10.Location = New System.Drawing.Point(16, 96)
        Me.button10.Name = "button10"
        Me.button10.Size = New System.Drawing.Size(184, 23)
        Me.button10.TabIndex = 7
        Me.button10.Text = "StatusBar"
        '
        'button9
        '
        Me.button9.Location = New System.Drawing.Point(16, 72)
        Me.button9.Name = "button9"
        Me.button9.Size = New System.Drawing.Size(184, 23)
        Me.button9.TabIndex = 6
        Me.button9.Text = "Variable Size Listbox"
        '
        'button8
        '
        Me.button8.Location = New System.Drawing.Point(16, 48)
        Me.button8.Name = "button8"
        Me.button8.Size = New System.Drawing.Size(184, 23)
        Me.button8.TabIndex = 5
        Me.button8.Text = "Fixed Size Listbox"
        '
        'button4
        '
        Me.button4.Location = New System.Drawing.Point(16, 24)
        Me.button4.Name = "button4"
        Me.button4.Size = New System.Drawing.Size(184, 23)
        Me.button4.TabIndex = 4
        Me.button4.Text = "Button"
        '
        'button5
        '
        Me.button5.Location = New System.Drawing.Point(220, 805)
        Me.button5.Name = "button5"
        Me.button5.Size = New System.Drawing.Size(110, 21)
        Me.button5.TabIndex = 7
        Me.button5.Text = "Populate ListView"
        '
        'button7
        '
        Me.button7.Location = New System.Drawing.Point(140, 805)
        Me.button7.Name = "button7"
        Me.button7.Size = New System.Drawing.Size(80, 21)
        Me.button7.TabIndex = 11
        Me.button7.Text = "SwitchViews"
        '
        'groupBox4
        '
        Me.groupBox4.Controls.AddRange(New System.Windows.Forms.Control() {Me.treeView1})
        Me.groupBox4.Location = New System.Drawing.Point(20, 333)
        Me.groupBox4.Name = "groupBox4"
        Me.groupBox4.Size = New System.Drawing.Size(296, 250)
        Me.groupBox4.TabIndex = 10
        Me.groupBox4.TabStop = False
        Me.groupBox4.Text = "ImageList and Tree Control"
        '
        'treeView1
        '
        Me.treeView1.ImageList = Me.smallImageList
        Me.treeView1.Location = New System.Drawing.Point(7, 23)
        Me.treeView1.Name = "treeView1"
        Me.treeView1.Size = New System.Drawing.Size(273, 217)
        Me.treeView1.TabIndex = 1
        '
        'groupBox5
        '
        Me.groupBox5.Controls.AddRange(New System.Windows.Forms.Control() {Me.listView1})
        Me.groupBox5.Location = New System.Drawing.Point(20, 589)
        Me.groupBox5.Name = "groupBox5"
        Me.groupBox5.Size = New System.Drawing.Size(296, 208)
        Me.groupBox5.TabIndex = 12
        Me.groupBox5.TabStop = False
        Me.groupBox5.Text = "ImageList and ListView"
        '
        'listView1
        '
        Me.listView1.LargeImageList = Me.bigImageList
        Me.listView1.Location = New System.Drawing.Point(8, 24)
        Me.listView1.Name = "listView1"
        Me.listView1.Size = New System.Drawing.Size(271, 168)
        Me.listView1.SmallImageList = Me.smallImageList
        Me.listView1.TabIndex = 0
        '
        'button6
        '
        Me.button6.Location = New System.Drawing.Point(20, 805)
        Me.button6.Name = "button6"
        Me.button6.Size = New System.Drawing.Size(117, 21)
        Me.button6.TabIndex = 9
        Me.button6.Text = "Populate TreeView"
        '
        'groupBox1
        '
        Me.groupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.button3, Me.button2, Me.button1, Me.label1, Me.textBox1})
        Me.groupBox1.Location = New System.Drawing.Point(19, 12)
        Me.groupBox1.Name = "groupBox1"
        Me.groupBox1.Size = New System.Drawing.Size(402, 99)
        Me.groupBox1.TabIndex = 5
        Me.groupBox1.TabStop = False
        Me.groupBox1.Text = "Ambient Properties"
        '
        'button3
        '
        Me.button3.Location = New System.Drawing.Point(307, 68)
        Me.button3.Name = "button3"
        Me.button3.Size = New System.Drawing.Size(88, 22)
        Me.button3.TabIndex = 4
        Me.button3.Text = "Reset"
        '
        'button2
        '
        Me.button2.Location = New System.Drawing.Point(161, 68)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(139, 22)
        Me.button2.TabIndex = 3
        Me.button2.Text = "Change Control Props"
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(7, 68)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(146, 22)
        Me.button1.TabIndex = 2
        Me.button1.Text = "Change Container Props"
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(7, 23)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(92, 21)
        Me.label1.TabIndex = 1
        Me.label1.Text = "A Label:"
        '
        'textBox1
        '
        Me.textBox1.Location = New System.Drawing.Point(110, 23)
        Me.textBox1.Name = "textBox1"
        Me.textBox1.Size = New System.Drawing.Size(91, 20)
        Me.textBox1.TabIndex = 0
        Me.textBox1.Text = "A TextBox"
        '
        'ControlVisuals
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(440, 838)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.groupBox2, Me.groupBox3, Me.button5, Me.button7, Me.groupBox4, Me.groupBox5, Me.button6, Me.groupBox1})
        Me.Name = "ControlVisuals"
        Me.Text = "ControlVisuals"
        Me.groupBox2.ResumeLayout(False)
        Me.groupBox3.ResumeLayout(False)
        Me.groupBox4.ResumeLayout(False)
        Me.groupBox5.ResumeLayout(False)
        Me.groupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region "Owner Drawn"
    Sub button4_click(ByVal sender As Object, ByVal e As EventArgs) Handles button4.Click
        Dim odbf As OwnerDrawnButton = New OwnerDrawnButton()
        odbf.ShowDialog()
    End Sub
    Sub button8_click(ByVal sender As Object, ByVal e As EventArgs) Handles button8.Click
        Dim odbf As OwnerDrawnFixedListBox = New OwnerDrawnFixedListBox()
        odbf.ShowDialog()
    End Sub
    Sub button9_click(ByVal sender As Object, ByVal e As EventArgs) Handles button9.Click
        Dim odbf As OwnerDrawnVariableListBox = New OwnerDrawnVariableListBox()
        odbf.ShowDialog()
    End Sub
    Sub button10_click(ByVal sender As Object, ByVal e As EventArgs) Handles button10.Click
        Dim odbf As OwnerDrawnStatusBar = New OwnerDrawnStatusBar()
        odbf.ShowDialog()
    End Sub
#End Region

#Region "Ambient Properties"
    Sub button1_click(ByVal sender As Object, ByVal e As EventArgs) Handles button1.Click
        groupBox1.Font = New Font("Times New Roman", 14)
    End Sub
    Sub button2_click(ByVal sender As Object, ByVal e As EventArgs) Handles button2.Click
        label1.Font = Me.Font
        textBox1.Font = Me.Font
    End Sub
    Sub button3_click(ByVal sender As Object, ByVal e As EventArgs) Handles button3.Click
        groupBox1.ResetFont()
        label1.ResetFont()
        textBox1.ResetFont()
    End Sub
#End Region

#Region "ImageLists"
    Sub button6_click(ByVal sender As Object, ByVal e As EventArgs) Handles button6.Click
        Dim top As TreeNode = New TreeNode("One")
        top.ImageIndex = 0
        top.SelectedImageIndex = 1

        treeView1.Nodes.Add(top)

        Dim firstChild As TreeNode = New TreeNode("Two")
        firstChild.ImageIndex = 1
        firstChild.SelectedImageIndex = 2

        top.Nodes.Add(firstChild)

        Dim secondChild As TreeNode = New TreeNode("Three")
        secondChild.ImageIndex = 2
        secondChild.SelectedImageIndex = 0

        top.Nodes.Add(secondChild)

    End Sub
    Sub button5_click(ByVal sender As Object, ByVal e As EventArgs) Handles button5.Click
        Dim one As ListViewItem = New ListViewItem("One")
        one.ImageIndex = 0

        Dim two As ListViewItem = New ListViewItem("Two")
        two.ImageIndex = 1

        Dim three As ListViewItem = New ListViewItem("Three")
        three.ImageIndex = 2

        listView1.Items.Add(one)
        listView1.Items.Add(two)
        listView1.Items.Add(three)

    End Sub
    Sub button7_click(ByVal sender As Object, ByVal e As EventArgs) Handles button7.Click
        Select Case listView1.View
            Case View.LargeIcon
                listView1.View = View.SmallIcon
            Case View.SmallIcon
                listView1.View = View.List
            Case View.List
                listView1.View = View.Details
            Case View.Details
                listView1.View = View.LargeIcon
        End Select
    End Sub
#End Region
End Class
