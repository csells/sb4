Imports System.Drawing
Imports System.Drawing.Printing

Public Class MainForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents printButton As System.Windows.Forms.Button
    Friend WithEvents previewButton As System.Windows.Forms.Button
    Friend WithEvents previewControlButton As System.Windows.Forms.Button
    Friend WithEvents pageSetupButton As System.Windows.Forms.Button
    Friend WithEvents pageSetupDialog1 As System.Windows.Forms.PageSetupDialog
    Friend WithEvents printDialog1 As System.Windows.Forms.PrintDialog
    Friend WithEvents printDocument1 As System.Drawing.Printing.PrintDocument
    Friend WithEvents printPreviewDialog1 As System.Windows.Forms.PrintPreviewDialog
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(MainForm))
        Me.printButton = New System.Windows.Forms.Button()
        Me.previewButton = New System.Windows.Forms.Button()
        Me.previewControlButton = New System.Windows.Forms.Button()
        Me.pageSetupButton = New System.Windows.Forms.Button()
        Me.pageSetupDialog1 = New System.Windows.Forms.PageSetupDialog()
        Me.printDialog1 = New System.Windows.Forms.PrintDialog()
        Me.printDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.printPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.SuspendLayout()
        '
        'printButton
        '
        Me.printButton.Location = New System.Drawing.Point(24, 16)
        Me.printButton.Name = "printButton"
        Me.printButton.Size = New System.Drawing.Size(112, 23)
        Me.printButton.TabIndex = 3
        Me.printButton.Text = "Print"
        '
        'previewButton
        '
        Me.previewButton.Location = New System.Drawing.Point(24, 80)
        Me.previewButton.Name = "previewButton"
        Me.previewButton.Size = New System.Drawing.Size(112, 23)
        Me.previewButton.TabIndex = 6
        Me.previewButton.Text = "Preview Dialog"
        '
        'previewControlButton
        '
        Me.previewControlButton.Location = New System.Drawing.Point(24, 48)
        Me.previewControlButton.Name = "previewControlButton"
        Me.previewControlButton.Size = New System.Drawing.Size(112, 23)
        Me.previewControlButton.TabIndex = 4
        Me.previewControlButton.Text = "Preview Control"
        '
        'pageSetupButton
        '
        Me.pageSetupButton.Location = New System.Drawing.Point(24, 112)
        Me.pageSetupButton.Name = "pageSetupButton"
        Me.pageSetupButton.Size = New System.Drawing.Size(112, 23)
        Me.pageSetupButton.TabIndex = 5
        Me.pageSetupButton.Text = "Page Setup"
        '
        'pageSetupDialog1
        '
        Me.pageSetupDialog1.MinMargins = New System.Drawing.Printing.Margins(50, 50, 50, 50)
        Me.pageSetupDialog1.ShowHelp = True
        '
        'printDialog1
        '
        Me.printDialog1.Document = Me.printDocument1
        '
        'printDocument1
        '
        '
        'printPreviewDialog1
        '
        Me.printPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.printPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.printPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.printPreviewDialog1.Enabled = True
        Me.printPreviewDialog1.Icon = CType(resources.GetObject("printPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.printPreviewDialog1.Location = New System.Drawing.Point(44, 58)
        Me.printPreviewDialog1.MaximumSize = New System.Drawing.Size(0, 0)
        Me.printPreviewDialog1.Name = "printPreviewDialog1"
        Me.printPreviewDialog1.Opacity = 1
        Me.printPreviewDialog1.TransparencyKey = System.Drawing.Color.Empty
        Me.printPreviewDialog1.Visible = False
        '
        'MainForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(160, 150)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.printButton, Me.previewButton, Me.previewControlButton, Me.pageSetupButton})
        Me.Name = "MainForm"
        Me.Text = "MainForm"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Dim fileName As String = "myFile.txt"

    Dim totalPages As Integer = 13
    Dim page As Integer
    Dim maxPage As Integer
    Dim myFont As Font = Nothing

    Private Sub printButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles printButton.Click
        printDocument1.DocumentName = fileName
        printDocument1.PrinterSettings.FromPage = 1
        printDocument1.PrinterSettings.ToPage = totalPages
        printDocument1.PrinterSettings.MinimumPage = 1
        printDocument1.PrinterSettings.MaximumPage = totalPages
        printDialog1.AllowSomePages = True
        If printDialog1.ShowDialog() = DialogResult.OK Then
            If printDialog1.PrinterSettings.PrintRange = Drawing.Printing.PrintRange.SomePages Then
                page = printDocument1.PrinterSettings.FromPage
                maxPage = printDocument1.PrinterSettings.ToPage
            Else
                page = 1
                maxPage = totalPages
            End If
        End If
        printDocument1.Print()
    End Sub

    Sub printDocument1_PrintPage(ByVal sender As Object, ByVal e As PrintPageEventArgs) Handles printDocument1.PrintPage
        Dim g As Graphics = e.Graphics
        g.DrawString("Hello, " & vbCrLf & "Printer" & vbCrLf & "Page: " & page, myFont, Brushes.Black, RectangleF.op_Implicit(e.MarginBounds))
        page = page + 1
        e.HasMorePages = (page <= maxPage)
    End Sub


    Private Sub previewControlButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles previewControlButton.Click
        page = 1
        maxPage = totalPages
        printPreviewDialog1.Document = printDocument1
        printPreviewDialog1.ShowDialog()
    End Sub

    Private Sub previewButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles previewButton.Click
        page = 1
        maxPage = totalPages
        Dim dlg As CustomPrintPreviewDialog = New CustomPrintPreviewDialog()
        dlg.Document = printDocument1
        dlg.ShowDialog()
    End Sub

    Private Sub pageSetupButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pageSetupButton.Click
        pageSetupDialog1.Document = printDocument1
        pageSetupDialog1.ShowDialog()
    End Sub

    Private Sub printDocument1_BeginPrint(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintEventArgs) Handles printDocument1.BeginPrint
        myFont = New Font("Lucide Console", 72)
    End Sub

    Private Sub printDocument1_EndPrint(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintEventArgs) Handles printDocument1.EndPrint
        myFont.Dispose()
        myFont = Nothing
    End Sub
End Class
