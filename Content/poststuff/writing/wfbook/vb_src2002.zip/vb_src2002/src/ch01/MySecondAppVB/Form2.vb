Public Class Form2
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents viewOptionsMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents helpAboutMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents textBox1 As System.Windows.Forms.TextBox
    Friend WithEvents menuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents fileSaveMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents treeView1 As System.Windows.Forms.TreeView
    Friend WithEvents saveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents splitter1 As System.Windows.Forms.Splitter
    Friend WithEvents statusBar1 As System.Windows.Forms.StatusBar
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.viewOptionsMenuItem = New System.Windows.Forms.MenuItem()
        Me.menuItem2 = New System.Windows.Forms.MenuItem()
        Me.helpAboutMenuItem = New System.Windows.Forms.MenuItem()
        Me.textBox1 = New System.Windows.Forms.TextBox()
        Me.menuItem3 = New System.Windows.Forms.MenuItem()
        Me.fileSaveMenuItem = New System.Windows.Forms.MenuItem()
        Me.treeView1 = New System.Windows.Forms.TreeView()
        Me.saveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.menuItem1 = New System.Windows.Forms.MenuItem()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu()
        Me.splitter1 = New System.Windows.Forms.Splitter()
        Me.statusBar1 = New System.Windows.Forms.StatusBar()
        Me.SuspendLayout()
        '
        'viewOptionsMenuItem
        '
        Me.viewOptionsMenuItem.Index = 0
        Me.viewOptionsMenuItem.Text = "&Options..."
        '
        'menuItem2
        '
        Me.menuItem2.Index = 2
        Me.menuItem2.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.helpAboutMenuItem})
        Me.menuItem2.Text = "&Help"
        '
        'helpAboutMenuItem
        '
        Me.helpAboutMenuItem.Index = 0
        Me.helpAboutMenuItem.Text = "&About..."
        '
        'textBox1
        '
        Me.textBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.textBox1.Location = New System.Drawing.Point(121, 0)
        Me.textBox1.Multiline = True
        Me.textBox1.Name = "textBox1"
        Me.textBox1.Size = New System.Drawing.Size(151, 89)
        Me.textBox1.TabIndex = 7
        Me.textBox1.Text = ""
        '
        'menuItem3
        '
        Me.menuItem3.Index = 0
        Me.menuItem3.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.fileSaveMenuItem})
        Me.menuItem3.Text = "&File"
        '
        'fileSaveMenuItem
        '
        Me.fileSaveMenuItem.Index = 0
        Me.fileSaveMenuItem.Text = "&Save..."
        '
        'treeView1
        '
        Me.treeView1.Dock = System.Windows.Forms.DockStyle.Left
        Me.treeView1.ImageIndex = -1
        Me.treeView1.Name = "treeView1"
        Me.treeView1.Nodes.AddRange(New System.Windows.Forms.TreeNode() {New System.Windows.Forms.TreeNode("Dock", New System.Windows.Forms.TreeNode() {New System.Windows.Forms.TreeNode("=", New System.Windows.Forms.TreeNode() {New System.Windows.Forms.TreeNode("Left")})})})
        Me.treeView1.SelectedImageIndex = -1
        Me.treeView1.Size = New System.Drawing.Size(121, 89)
        Me.treeView1.TabIndex = 5
        '
        'saveFileDialog1
        '
        Me.saveFileDialog1.FileName = "doc1"
        '
        'menuItem1
        '
        Me.menuItem1.Index = 1
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.viewOptionsMenuItem})
        Me.menuItem1.Text = "&View"
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem3, Me.menuItem1, Me.menuItem2})
        '
        'splitter1
        '
        Me.splitter1.Location = New System.Drawing.Point(121, 0)
        Me.splitter1.Name = "splitter1"
        Me.splitter1.Size = New System.Drawing.Size(3, 67)
        Me.splitter1.TabIndex = 6
        Me.splitter1.TabStop = False
        '
        'statusBar1
        '
        Me.statusBar1.Location = New System.Drawing.Point(121, 67)
        Me.statusBar1.Name = "statusBar1"
        Me.statusBar1.Size = New System.Drawing.Size(151, 22)
        Me.statusBar1.TabIndex = 4
        Me.statusBar1.Text = "Dock = Bottom"
        '
        'Form2
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(272, 89)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.splitter1, Me.statusBar1, Me.textBox1, Me.treeView1})
        Me.Menu = Me.mainMenu1
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Dim _color As Color = Color.LightGreen



    Private Sub viewOptionsMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles viewOptionsMenuItem.Click
        Dim dlg As OptionsDialog = New OptionsDialog()
        dlg.FavoriteColor = Me.ForeColor
        If dlg.ShowDialog() = DialogResult.OK Then
            Me.ForeColor = dlg.FavoriteColor
        End If
    End Sub

    Private Sub helpAboutMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles helpAboutMenuItem.Click
        Dim dlg As AboutDialog = New AboutDialog()
        dlg.ShowDialog()
    End Sub
End Class
