Public Class OptionsDialog
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents okButton As System.Windows.Forms.Button
    Friend WithEvents changeColorButton As System.Windows.Forms.Button
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents errorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents colorDialog1 As System.Windows.Forms.ColorDialog
    Friend WithEvents _cancelButton As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.okButton = New System.Windows.Forms.Button()
        Me.changeColorButton = New System.Windows.Forms.Button()
        Me._cancelButton = New System.Windows.Forms.Button()
        Me.label1 = New System.Windows.Forms.Label()
        Me.errorProvider1 = New System.Windows.Forms.ErrorProvider()
        Me.colorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.SuspendLayout()
        '
        'okButton
        '
        Me.okButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.okButton.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.okButton.Location = New System.Drawing.Point(32, 64)
        Me.okButton.Name = "okButton"
        Me.okButton.TabIndex = 5
        Me.okButton.Text = "OK"
        '
        'changeColorButton
        '
        Me.changeColorButton.Location = New System.Drawing.Point(120, 8)
        Me.changeColorButton.Name = "changeColorButton"
        Me.changeColorButton.TabIndex = 4
        Me.changeColorButton.Text = "Change..."
        '
        '_cancelButton
        '
        Me._cancelButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me._cancelButton.CausesValidation = False
        Me._cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me._cancelButton.Location = New System.Drawing.Point(120, 64)
        Me._cancelButton.Name = "_cancelButton"
        Me._cancelButton.TabIndex = 6
        Me._cancelButton.Text = "Cancel"
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(8, 8)
        Me.label1.Name = "label1"
        Me.label1.TabIndex = 3
        Me.label1.Text = "Favorite Color"
        Me.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'errorProvider1
        '
        Me.errorProvider1.DataMember = Nothing
        '
        'OptionsDialog
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(208, 102)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me._cancelButton, Me.label1, Me.okButton, Me.changeColorButton})
        Me.Name = "OptionsDialog"
        Me.Text = "OptionsDialog"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub changeColorButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles changeColorButton.Click
        If colorDialog1.ShowDialog() = DialogResult.OK Then
            changeColorButton.BackColor = colorDialog1.Color
        End If
    End Sub

    Private Sub changeColorButton_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles changeColorButton.Validating
        Dim greenness As Byte = changeColorButton.BackColor.G
        Dim err As String = ""
        If greenness < Color.LightGreen.G Then
            err = "I'm sorry, we were going for leafy, leafy..."
            e.Cancel = True
        End If
        errorProvider1.SetError(changeColorButton, err)
    End Sub

    Public Property FavoriteColor() As Color
        Get
            Return colorDialog1.Color
        End Get
        Set(ByVal Value As Color)
            changeColorButton.BackColor = Value
            colorDialog1.Color = Value
        End Set
    End Property

    Private Sub cancelButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _cancelButton.Click

    End Sub
End Class
