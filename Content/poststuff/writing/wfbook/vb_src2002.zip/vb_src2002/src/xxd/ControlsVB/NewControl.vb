Imports System.Drawing
Imports System.Windows.Forms


Public Class NewControl
    Inherits System.Windows.Forms.Control

#Region " Component Designer generated code "

    Public Sub New()
        MyBase.New()

        ' This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        SetStyle(ControlStyles.UserPaint Or ControlStyles.ResizeRedraw, True)
    End Sub

    'Control overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Control Designer
    Private components As System.ComponentModel.IContainer

    ' NOTE: The following procedure is required by the Component Designer
    ' It can be modified using the Component Designer.  Do not modify it
    ' using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
    End Sub

#End Region

    Protected Overrides Sub OnPaint(ByVal pe As System.Windows.Forms.PaintEventArgs)
        ' Create brushes to paint with (from chapter 4)
        Dim backBrush As Brush = New SolidBrush(Me.BackColor)
        Dim circleBrush As Brush = New SolidBrush(Color.Red)
        Dim foreBrush As Brush = New SolidBrush(Me.ForeColor)

        ' Set up our drawing surface
        Dim rect As RectangleF = New RectangleF(ClientRectangle.X, _
                                                ClientRectangle.Y, _
                                                ClientRectangle.Width, _
                                                ClientRectangle.Height)

        ' Specify that our string is centered
        ' horizontally and vertically
        Dim format As StringFormat = New StringFormat()
        format.Alignment = StringAlignment.Center
        format.LineAlignment = StringAlignment.Center

        ' Draw the background and the circle
        pe.Graphics.FillRectangle(backBrush, rect)
        pe.Graphics.FillEllipse(circleBrush, rect)

        ' Draw the string from members of base Control
        pe.Graphics.DrawString(Me.Text, _
                               Me.Font, _
                               foreBrush, _
                               rect, _
                               format)

        ' Clean our brushes
        foreBrush.Dispose()
        circleBrush.Dispose()
        backBrush.Dispose()

        ' Notify listeners last
        MyBase.OnPaint(pe)
    End Sub

    Protected Overrides Sub OnTextChanged(ByVal e As System.EventArgs)
        MyBase.OnTextChanged(e)

        ' Cause a paint to happen
        Invalidate()
    End Sub

    Protected Overrides Sub OnFontChanged(ByVal e As System.EventArgs)
        MyBase.OnFontChanged(e)

        ' Cause a paint to happen
        Invalidate()
    End Sub

    Protected Overrides Sub OnForeColorChanged(ByVal e As System.EventArgs)
        MyBase.OnForeColorChanged(e)

        ' Cause a paint to happen
        Invalidate()
    End Sub

    Protected Overrides Sub OnBackColorChanged(ByVal e As System.EventArgs)
        MyBase.OnBackColorChanged(e)

        ' Cause a paint to happen
        Invalidate()
    End Sub

    Dim oldCursor As Cursor = Nothing


    Protected Overrides Sub OnMouseEnter(ByVal e As System.EventArgs)
        MyBase.OnMouseEnter(e)

        ' Set the mouse icon
        oldCursor = Me.Cursor
        Me.Cursor = Cursors.Hand
    End Sub

    Protected Overrides Sub OnMouseLeave(ByVal e As System.EventArgs)
        MyBase.OnMouseLeave(e)

        ' Set the mouse icon
        Me.Cursor = oldCursor
    End Sub
End Class
