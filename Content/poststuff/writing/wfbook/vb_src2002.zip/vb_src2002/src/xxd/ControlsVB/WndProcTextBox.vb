Imports System
Imports System.Windows.Forms
Imports System.IO
Imports System.Drawing

Public Class WndProcTextBox
    Inherits TextBox

    Public Sub New()
        setstyle(ControlStyles.EnableNotifyMessage, True)
    End Sub

    Public Delegate Sub ShowEventInfo(ByVal info As String)
    Public Event ShowEventInfoEvent As ShowEventInfo



    Protected Overrides Sub OnNotifyMessage(ByVal m As System.Windows.Forms.Message)
        RaiseEvent ShowEventInfoEvent(String.Format("Msg: HWND({0}) LPARAM({1}) WPARAM({2}) MSG({3})", _
            m.HWnd, _
            m.LParam, _
            m.WParam, _
            m.Msg))

        MyBase.OnNotifyMessage(m)
    End Sub
End Class
