Imports System
Imports System.Drawing
Imports System.Data
Imports System.Windows.Forms

Public Class NewScrollingCtrl
    Inherits ScrollableControl

    Public Sub New()
        setstyle(ControlStyles.SupportsTransparentBackColor Or ControlStyles.UserPaint Or ControlStyles.Opaque Or ControlStyles.ResizeRedraw, True)
    End Sub

    Protected Overrides Sub OnPaint(ByVal e As System.Windows.Forms.PaintEventArgs)
        ' Create the brushes to paint with (from chapter 4)
        Dim backBrush As Brush = New SolidBrush(Me.BackColor)
        Dim circleBrush As Brush = New SolidBrush(Color.Red)
        Dim foreBrush As Brush = New SolidBrush(Me.ForeColor)

        ' Set up our drawing surface
        Dim rect As RectangleF = New RectangleF(DisplayRectangle.X, _
                                                DisplayRectangle.Y, _
                                                DisplayRectangle.Width, _
                                                DisplayRectangle.Height)

        ' Specify that our string is centered
        ' horizontally and vertically
        Dim format As StringFormat = New StringFormat()
        format.Alignment = StringAlignment.Center
        format.LineAlignment = StringAlignment.Center
        format.FormatFlags = StringFormatFlags.NoWrap

        ' Draw the background and the circle
        e.Graphics.FillRectangle(backBrush, rect)
        e.Graphics.FillEllipse(circleBrush, rect)

        ' Draw the string from the members of base Control
        e.Graphics.DrawString(Me.Text, Me.Font, foreBrush, rect, format)

        ' Clean our brushes
        foreBrush.Dispose()
        circleBrush.Dispose()
        backBrush.Dispose()

        ' Notify listeners last
        MyBase.OnPaint(e)
    End Sub

    Protected Overrides Sub OnFontChanged(ByVal e As System.EventArgs)
        MyBase.OnFontChanged(e)

        ' Cause a paint to happen
        Invalidate()

        ' Set the scroll size
        SetScrollMinSize()
    End Sub

    Protected Overrides Sub OnForeColorChanged(ByVal e As System.EventArgs)
        MyBase.OnForeColorChanged(e)

        ' Cause a paint to happen
        Invalidate()
    End Sub

    Protected Overrides Sub OnBackColorChanged(ByVal e As System.EventArgs)
        MyBase.OnBackColorChanged(e)

        ' Cause a paint to happen
        Invalidate()
    End Sub

    Sub SetScrollMinSize()
        ' create a graphics object to measure with
        Dim g As Graphics = Me.CreateGraphics()

        ' determine the size of the text
        Dim _sizef As SizeF = g.MeasureString(Me.Text, Me.Font)
        Dim _size As Size = New Size(CInt(Math.Ceiling(_sizef.Width)), CInt(Math.Ceiling(_sizef.Height)))

        ' Set the minimum size to the text size
        Me.AutoScrollMinSize = _size
    End Sub
End Class
