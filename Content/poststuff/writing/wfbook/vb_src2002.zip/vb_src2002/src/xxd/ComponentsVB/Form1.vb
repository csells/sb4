Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents fileNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents openFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents northMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents saveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents westMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents southMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents button3 As System.Windows.Forms.Button
    Friend WithEvents contextMenu1 As System.Windows.Forms.ContextMenu
    Friend WithEvents eastMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents button2 As System.Windows.Forms.Button
    Friend WithEvents compassNotifyIcon As System.Windows.Forms.NotifyIcon
    Friend WithEvents timer1 As System.Windows.Forms.Timer
    Friend WithEvents button4 As System.Windows.Forms.Button
    Friend WithEvents fontDialog1 As System.Windows.Forms.FontDialog
    Friend WithEvents backgroundImageList As System.Windows.Forms.ImageList
    Friend WithEvents colorDialog1 As System.Windows.Forms.ColorDialog
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.fileNameTextBox = New System.Windows.Forms.TextBox()
        Me.openFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.northMenuItem = New System.Windows.Forms.MenuItem()
        Me.saveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.westMenuItem = New System.Windows.Forms.MenuItem()
        Me.southMenuItem = New System.Windows.Forms.MenuItem()
        Me.button3 = New System.Windows.Forms.Button()
        Me.contextMenu1 = New System.Windows.Forms.ContextMenu()
        Me.eastMenuItem = New System.Windows.Forms.MenuItem()
        Me.button2 = New System.Windows.Forms.Button()
        Me.compassNotifyIcon = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.button4 = New System.Windows.Forms.Button()
        Me.fontDialog1 = New System.Windows.Forms.FontDialog()
        Me.backgroundImageList = New System.Windows.Forms.ImageList(Me.components)
        Me.colorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.button1 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'fileNameTextBox
        '
        Me.fileNameTextBox.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.fileNameTextBox.Location = New System.Drawing.Point(-128, 216)
        Me.fileNameTextBox.Name = "fileNameTextBox"
        Me.fileNameTextBox.TabIndex = 6
        Me.fileNameTextBox.Text = "c:\boot.ini"
        '
        'northMenuItem
        '
        Me.northMenuItem.Index = 0
        Me.northMenuItem.Text = "&North"
        '
        'saveFileDialog1
        '
        Me.saveFileDialog1.FileName = "doc1"
        '
        'westMenuItem
        '
        Me.westMenuItem.Index = 3
        Me.westMenuItem.Text = "&West"
        '
        'southMenuItem
        '
        Me.southMenuItem.Index = 2
        Me.southMenuItem.Text = "&South"
        '
        'button3
        '
        Me.button3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.button3.Location = New System.Drawing.Point(-144, 144)
        Me.button3.Name = "button3"
        Me.button3.Size = New System.Drawing.Size(128, 23)
        Me.button3.TabIndex = 5
        Me.button3.Text = "Open File Dialog"
        '
        'contextMenu1
        '
        Me.contextMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.northMenuItem, Me.eastMenuItem, Me.southMenuItem, Me.westMenuItem})
        '
        'eastMenuItem
        '
        Me.eastMenuItem.Index = 1
        Me.eastMenuItem.Text = "&East"
        '
        'button2
        '
        Me.button2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.button2.Location = New System.Drawing.Point(-144, 112)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(128, 23)
        Me.button2.TabIndex = 2
        Me.button2.Text = "Font Dialog"
        '
        'compassNotifyIcon
        '
        Me.compassNotifyIcon.ContextMenu = Me.contextMenu1
        Me.compassNotifyIcon.Icon = CType(resources.GetObject("compassNotifyIcon.Icon"), System.Drawing.Icon)
        Me.compassNotifyIcon.Text = "North"
        Me.compassNotifyIcon.Visible = True
        '
        'button4
        '
        Me.button4.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.button4.Location = New System.Drawing.Point(-144, 176)
        Me.button4.Name = "button4"
        Me.button4.Size = New System.Drawing.Size(128, 23)
        Me.button4.TabIndex = 4
        Me.button4.Text = "Save File Dialog"
        '
        'backgroundImageList
        '
        Me.backgroundImageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.backgroundImageList.ImageSize = New System.Drawing.Size(16, 16)
        Me.backgroundImageList.ImageStream = CType(resources.GetObject("backgroundImageList.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.backgroundImageList.TransparentColor = System.Drawing.Color.Transparent
        '
        'button1
        '
        Me.button1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.button1.Location = New System.Drawing.Point(-144, 80)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(128, 23)
        Me.button1.TabIndex = 3
        Me.button1.Text = "Color Dialog"
        '
        'TextBox1
        '
        Me.TextBox1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TextBox1.Location = New System.Drawing.Point(98, 191)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.TabIndex = 11
        Me.TextBox1.Text = "c:\boot.ini"
        '
        'Button5
        '
        Me.Button5.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Button5.Location = New System.Drawing.Point(82, 55)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(128, 23)
        Me.Button5.TabIndex = 10
        Me.Button5.Text = "Color Dialog"
        '
        'Button6
        '
        Me.Button6.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Button6.Location = New System.Drawing.Point(82, 87)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(128, 23)
        Me.Button6.TabIndex = 9
        Me.Button6.Text = "Font Dialog"
        '
        'Button7
        '
        Me.Button7.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Button7.Location = New System.Drawing.Point(82, 119)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(128, 23)
        Me.Button7.TabIndex = 7
        Me.Button7.Text = "Open File Dialog"
        '
        'Button8
        '
        Me.Button8.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Button8.Location = New System.Drawing.Point(82, 151)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(128, 23)
        Me.Button8.TabIndex = 8
        Me.Button8.Text = "Save File Dialog"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.TextBox1, Me.Button5, Me.Button6, Me.Button7, Me.Button8, Me.fileNameTextBox, Me.button3, Me.button2, Me.button4, Me.button1})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    ' Use the ColorDialog
    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        ' Set initial color
        Me.colorDialog1.Color = Me.BackColor

        ' Ask the user to pick a color
        If Me.colorDialog1.ShowDialog = DialogResult.OK Then
            ' Pull out the user's choice
            Me.BackColor = Me.colorDialog1.Color
        End If
    End Sub

    ' Use the fontdialog
    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        ' set initial font
        Me.fontDialog1.Font = Me.Font

        ' Ask the user to pick a font
        If Me.fontDialog1.ShowDialog = DialogResult.OK Then
            ' Pull out the user's choices
            Me.Font = Me.fontDialog1.Font
        End If
    End Sub

    ' Use the OpenFileDialog (common usage just like SaveFileDialog)
    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        ' Set initial file name
        Me.openFileDialog1.FileName = Me.fileNameTextBox.Text

        ' Ask the user to pick a file
        If Me.openFileDialog1.ShowDialog = DialogResult.OK Then
            ' pull out the user's choice
            Me.fileNameTextBox.Text = Me.openFileDialog1.FileName
        End If
    End Sub

    ' Use the SaveFileDialog
    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        ' Set the initial file name
        Me.saveFileDialog1.FileName = Me.fileNameTextBox.Text

        ' Ask the user to pick a file
        If Me.saveFileDialog1.ShowDialog = DialogResult.OK Then
            ' Pull out the user's choice
            Me.fileNameTextBox.Text = Me.saveFileDialog1.FileName
        End If
    End Sub

    ' Icons
    Dim northIcon As Icon = New Icon("C:\vs.net\Common7\Graphics\icons\arrows\ARW02UP.ICO")
    Dim eastIcon As Icon = New Icon("C:\vs.net\Common7\Graphics\icons\arrows\ARW02RT.ICO")
    Dim southIcon As Icon = New Icon("C:\vs.net\Common7\Graphics\icons\arrows\ARW02DN.ICO")
    Dim westIcon As Icon = New Icon("C:\vs.net\Common7\Graphics\icons\arrows\ARW02LT.ICO")

    Dim index As Integer = -1

    ' Helper
    Sub SetDirection(ByVal direction As String)
        ' Update notify icon, set background from image list
        compassNotifyIcon.Text = direction
        Select Case direction
            Case "North"
                compassNotifyIcon.Icon = northIcon
                index = 0
            Case "East"
                compassNotifyIcon.Icon = eastIcon
                index = 1
            Case "South"
                compassNotifyIcon.Icon = southIcon
                index = 2
            Case "West"
                compassNotifyIcon.Icon = westIcon
                index = 3
        End Select

        Me.BackgroundImage = backgroundImageList.Images(index)

    End Sub

    Private Sub northMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles northMenuItem.Click
        SetDirection("North")
    End Sub

    Private Sub eastMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles eastMenuItem.Click
        SetDirection("East")
    End Sub

    Private Sub westMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles westMenuItem.Click
        SetDirection("West")
    End Sub

    Private Sub southMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles southMenuItem.Click
        SetDirection("South")
    End Sub

    ' Notify icon click handler
    Private Sub compassNotifyIcon_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles compassNotifyIcon.Click
        ' Toggle animation
        timer1.Enabled = Not timer1.Enabled
        timer1.Interval = 1000 ' Animate once/second
    End Sub

    Private Sub timer1_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles timer1.Tick
        Select Case compassNotifyIcon.Text
            Case "North"
                SetDirection("East")
            Case "East"
                SetDirection("South")
            Case "South"
                SetDirection("West")
            Case "West"
                SetDirection("North")
        End Select
    End Sub
End Class
