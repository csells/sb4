Imports System.Windows.Forms
Imports System.IO
Imports System.Drawing

Public Class FileTextBox
    Inherits TextBox

    Public Sub New()

    End Sub

    Protected Overrides Sub OnTextChanged(ByVal e As System.EventArgs)
        ' if the file does not exist, color the text red
        If Not File.Exists(Me.Text) Then
            Me.ForeColor = Color.Red
        Else ' make it black
            Me.ForeColor = Color.Black
        End If

        ' Call the base class
        MyBase.OnTextChanged(e)
    End Sub
End Class
