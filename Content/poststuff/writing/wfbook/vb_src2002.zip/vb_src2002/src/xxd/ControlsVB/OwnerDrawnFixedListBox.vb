Public Class OwnerDrawnFixedListBox
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents listBox1 As System.Windows.Forms.ListBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.listBox1 = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'listBox1
        '
        Me.listBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.listBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.listBox1.ItemHeight = 18
        Me.listBox1.Items.AddRange(New Object() {"Foo", "Bar", "Quux"})
        Me.listBox1.Location = New System.Drawing.Point(8, 16)
        Me.listBox1.Name = "listBox1"
        Me.listBox1.Size = New System.Drawing.Size(248, 166)
        Me.listBox1.TabIndex = 3
        '
        'OwnerDrawnFixedListBox
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(264, 198)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.listBox1})
        Me.Name = "OwnerDrawnFixedListBox"
        Me.Text = "OwnerDrawnFixedListBox"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub listBox1_DrawItem(ByVal sender As Object, ByVal e As System.Windows.Forms.DrawItemEventArgs) Handles listBox1.DrawItem
        ' Draw the background
        e.DrawBackground()

        Dim drawFont As Font = Nothing

        ' Draw with a Times New Roman Bold Italic Font if Selected
        If e.State And DrawItemState.Selected = DrawItemState.Selected Then
            drawFont = New Font("Times New Roman", 14, FontStyle.Bold Or FontStyle.Italic)
        Else
            drawFont = e.Font
        End If

        ' Draw the string
        e.Graphics.DrawString(listBox1.Items(e.Index).ToString(), _
                                drawFont, _
                                New SolidBrush(e.ForeColor), e.Bounds.X, e.Bounds.Y)

        ' Draw the focus rectangle
        e.DrawFocusRectangle()

    End Sub
End Class
