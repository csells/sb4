Public Class ControlOverview
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents progressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents trackBar1 As System.Windows.Forms.TrackBar
    Friend WithEvents numericUpDown1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents panel6 As System.Windows.Forms.Panel
    Friend WithEvents dateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents monthCalendar1 As System.Windows.Forms.MonthCalendar
    Friend WithEvents button2 As System.Windows.Forms.Button
    Friend WithEvents tabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents tabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents tabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents tabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents vScrollBar1 As System.Windows.Forms.VScrollBar
    Friend WithEvents domainUpDown1 As System.Windows.Forms.DomainUpDown
    Friend WithEvents hScrollBar1 As System.Windows.Forms.HScrollBar
    Friend WithEvents panel3 As System.Windows.Forms.Panel
    Friend WithEvents comboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents panel1 As System.Windows.Forms.Panel
    Friend WithEvents listBox1 As System.Windows.Forms.ListBox
    Friend WithEvents pictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents radioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents checkBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents panel2 As System.Windows.Forms.Panel
    Friend WithEvents checkedListBox1 As System.Windows.Forms.CheckedListBox
    Friend WithEvents panel4 As System.Windows.Forms.Panel
    Friend WithEvents listView1 As System.Windows.Forms.ListView
    Friend WithEvents imageList1 As System.Windows.Forms.ImageList
    Friend WithEvents panel7 As System.Windows.Forms.Panel
    Friend WithEvents richTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents textBox1 As System.Windows.Forms.TextBox
    Friend WithEvents linkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents panel5 As System.Windows.Forms.Panel
    Friend WithEvents treeView1 As System.Windows.Forms.TreeView
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ListViewItem1 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New System.Windows.Forms.ListViewItem.ListViewSubItem() {New System.Windows.Forms.ListViewItem.ListViewSubItem(Nothing, "First Item", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))}, 0)
        Dim ListViewItem2 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New System.Windows.Forms.ListViewItem.ListViewSubItem() {New System.Windows.Forms.ListViewItem.ListViewSubItem(Nothing, "Second Item", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))}, 1)
        Dim ListViewItem3 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New System.Windows.Forms.ListViewItem.ListViewSubItem() {New System.Windows.Forms.ListViewItem.ListViewSubItem(Nothing, "Third Item", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))}, 2)
        Dim ListViewItem4 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New System.Windows.Forms.ListViewItem.ListViewSubItem() {New System.Windows.Forms.ListViewItem.ListViewSubItem(Nothing, "Fourth Item", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))}, 2)
        Dim ListViewItem5 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New System.Windows.Forms.ListViewItem.ListViewSubItem() {New System.Windows.Forms.ListViewItem.ListViewSubItem(Nothing, "Fifth Item", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))}, 0)
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(ControlOverview))
        Me.progressBar1 = New System.Windows.Forms.ProgressBar()
        Me.trackBar1 = New System.Windows.Forms.TrackBar()
        Me.numericUpDown1 = New System.Windows.Forms.NumericUpDown()
        Me.panel6 = New System.Windows.Forms.Panel()
        Me.dateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.monthCalendar1 = New System.Windows.Forms.MonthCalendar()
        Me.button2 = New System.Windows.Forms.Button()
        Me.tabControl1 = New System.Windows.Forms.TabControl()
        Me.tabPage1 = New System.Windows.Forms.TabPage()
        Me.tabPage2 = New System.Windows.Forms.TabPage()
        Me.tabPage3 = New System.Windows.Forms.TabPage()
        Me.vScrollBar1 = New System.Windows.Forms.VScrollBar()
        Me.domainUpDown1 = New System.Windows.Forms.DomainUpDown()
        Me.hScrollBar1 = New System.Windows.Forms.HScrollBar()
        Me.panel3 = New System.Windows.Forms.Panel()
        Me.comboBox1 = New System.Windows.Forms.ComboBox()
        Me.panel1 = New System.Windows.Forms.Panel()
        Me.listBox1 = New System.Windows.Forms.ListBox()
        Me.pictureBox1 = New System.Windows.Forms.PictureBox()
        Me.radioButton1 = New System.Windows.Forms.RadioButton()
        Me.checkBox1 = New System.Windows.Forms.CheckBox()
        Me.panel2 = New System.Windows.Forms.Panel()
        Me.checkedListBox1 = New System.Windows.Forms.CheckedListBox()
        Me.panel4 = New System.Windows.Forms.Panel()
        Me.listView1 = New System.Windows.Forms.ListView()
        Me.imageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.panel7 = New System.Windows.Forms.Panel()
        Me.richTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.button1 = New System.Windows.Forms.Button()
        Me.textBox1 = New System.Windows.Forms.TextBox()
        Me.linkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.label1 = New System.Windows.Forms.Label()
        Me.panel5 = New System.Windows.Forms.Panel()
        Me.treeView1 = New System.Windows.Forms.TreeView()
        CType(Me.trackBar1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panel6.SuspendLayout()
        Me.tabControl1.SuspendLayout()
        Me.panel3.SuspendLayout()
        Me.panel1.SuspendLayout()
        Me.panel2.SuspendLayout()
        Me.panel4.SuspendLayout()
        Me.panel7.SuspendLayout()
        Me.panel5.SuspendLayout()
        Me.SuspendLayout()
        '
        'progressBar1
        '
        Me.progressBar1.Location = New System.Drawing.Point(392, 163)
        Me.progressBar1.Name = "progressBar1"
        Me.progressBar1.Size = New System.Drawing.Size(240, 23)
        Me.progressBar1.TabIndex = 42
        '
        'trackBar1
        '
        Me.trackBar1.Location = New System.Drawing.Point(392, 107)
        Me.trackBar1.Name = "trackBar1"
        Me.trackBar1.Size = New System.Drawing.Size(200, 45)
        Me.trackBar1.TabIndex = 41
        '
        'numericUpDown1
        '
        Me.numericUpDown1.Location = New System.Drawing.Point(392, 75)
        Me.numericUpDown1.Name = "numericUpDown1"
        Me.numericUpDown1.Size = New System.Drawing.Size(176, 20)
        Me.numericUpDown1.TabIndex = 40
        '
        'panel6
        '
        Me.panel6.Controls.AddRange(New System.Windows.Forms.Control() {Me.dateTimePicker1})
        Me.panel6.Location = New System.Drawing.Point(232, 459)
        Me.panel6.Name = "panel6"
        Me.panel6.Size = New System.Drawing.Size(216, 192)
        Me.panel6.TabIndex = 35
        '
        'dateTimePicker1
        '
        Me.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Time
        Me.dateTimePicker1.Location = New System.Drawing.Point(8, 8)
        Me.dateTimePicker1.Name = "dateTimePicker1"
        Me.dateTimePicker1.ShowUpDown = True
        Me.dateTimePicker1.TabIndex = 0
        '
        'monthCalendar1
        '
        Me.monthCalendar1.Location = New System.Drawing.Point(176, 291)
        Me.monthCalendar1.Name = "monthCalendar1"
        Me.monthCalendar1.TabIndex = 34
        '
        'button2
        '
        Me.button2.Location = New System.Drawing.Point(456, 467)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(152, 23)
        Me.button2.TabIndex = 44
        Me.button2.Text = "Window Elements Dialog"
        '
        'tabControl1
        '
        Me.tabControl1.Controls.AddRange(New System.Windows.Forms.Control() {Me.tabPage1, Me.tabPage2, Me.tabPage3})
        Me.tabControl1.Location = New System.Drawing.Point(416, 331)
        Me.tabControl1.Name = "tabControl1"
        Me.tabControl1.SelectedIndex = 0
        Me.tabControl1.TabIndex = 43
        '
        'tabPage1
        '
        Me.tabPage1.Location = New System.Drawing.Point(4, 22)
        Me.tabPage1.Name = "tabPage1"
        Me.tabPage1.Size = New System.Drawing.Size(192, 74)
        Me.tabPage1.TabIndex = 0
        Me.tabPage1.Text = "tabPage1"
        '
        'tabPage2
        '
        Me.tabPage2.Location = New System.Drawing.Point(4, 22)
        Me.tabPage2.Name = "tabPage2"
        Me.tabPage2.Size = New System.Drawing.Size(192, 74)
        Me.tabPage2.TabIndex = 1
        Me.tabPage2.Text = "tabPage2"
        Me.tabPage2.Visible = False
        '
        'tabPage3
        '
        Me.tabPage3.Location = New System.Drawing.Point(4, 22)
        Me.tabPage3.Name = "tabPage3"
        Me.tabPage3.Size = New System.Drawing.Size(192, 74)
        Me.tabPage3.TabIndex = 2
        Me.tabPage3.Text = "tabPage3"
        Me.tabPage3.Visible = False
        '
        'vScrollBar1
        '
        Me.vScrollBar1.Location = New System.Drawing.Point(672, 19)
        Me.vScrollBar1.Name = "vScrollBar1"
        Me.vScrollBar1.Size = New System.Drawing.Size(17, 184)
        Me.vScrollBar1.TabIndex = 39
        '
        'domainUpDown1
        '
        Me.domainUpDown1.Items.Add("First")
        Me.domainUpDown1.Items.Add("Second")
        Me.domainUpDown1.Items.Add("Third")
        Me.domainUpDown1.Items.Add("Fourth")
        Me.domainUpDown1.Items.Add("Fifth")
        Me.domainUpDown1.Location = New System.Drawing.Point(392, 51)
        Me.domainUpDown1.Name = "domainUpDown1"
        Me.domainUpDown1.Size = New System.Drawing.Size(176, 20)
        Me.domainUpDown1.TabIndex = 38
        Me.domainUpDown1.Text = "domainUpDown1"
        '
        'hScrollBar1
        '
        Me.hScrollBar1.Location = New System.Drawing.Point(392, 19)
        Me.hScrollBar1.Name = "hScrollBar1"
        Me.hScrollBar1.Size = New System.Drawing.Size(176, 17)
        Me.hScrollBar1.TabIndex = 37
        '
        'panel3
        '
        Me.panel3.Controls.AddRange(New System.Windows.Forms.Control() {Me.comboBox1})
        Me.panel3.Location = New System.Drawing.Point(24, 507)
        Me.panel3.Name = "panel3"
        Me.panel3.Size = New System.Drawing.Size(200, 128)
        Me.panel3.TabIndex = 31
        '
        'comboBox1
        '
        Me.comboBox1.Items.AddRange(New Object() {"First Item", "Second Item", "Third Item", "Fourth Item", "Fifth item"})
        Me.comboBox1.Location = New System.Drawing.Point(8, 8)
        Me.comboBox1.Name = "comboBox1"
        Me.comboBox1.Size = New System.Drawing.Size(184, 21)
        Me.comboBox1.TabIndex = 0
        Me.comboBox1.Text = "comboBox1"
        '
        'panel1
        '
        Me.panel1.Controls.AddRange(New System.Windows.Forms.Control() {Me.listBox1})
        Me.panel1.Location = New System.Drawing.Point(24, 267)
        Me.panel1.Name = "panel1"
        Me.panel1.Size = New System.Drawing.Size(136, 112)
        Me.panel1.TabIndex = 29
        '
        'listBox1
        '
        Me.listBox1.Items.AddRange(New Object() {"First Item", "Second Item", "Third Item", "Fourth Item", "Fifth Item"})
        Me.listBox1.Location = New System.Drawing.Point(8, 8)
        Me.listBox1.Name = "listBox1"
        Me.listBox1.Size = New System.Drawing.Size(120, 95)
        Me.listBox1.TabIndex = 0
        '
        'pictureBox1
        '
        Me.pictureBox1.Location = New System.Drawing.Point(24, 203)
        Me.pictureBox1.Name = "pictureBox1"
        Me.pictureBox1.TabIndex = 28
        Me.pictureBox1.TabStop = False
        '
        'radioButton1
        '
        Me.radioButton1.Location = New System.Drawing.Point(24, 179)
        Me.radioButton1.Name = "radioButton1"
        Me.radioButton1.TabIndex = 27
        Me.radioButton1.Text = "radioButton1"
        '
        'checkBox1
        '
        Me.checkBox1.Location = New System.Drawing.Point(24, 155)
        Me.checkBox1.Name = "checkBox1"
        Me.checkBox1.TabIndex = 26
        Me.checkBox1.Text = "checkBox1"
        '
        'panel2
        '
        Me.panel2.Controls.AddRange(New System.Windows.Forms.Control() {Me.checkedListBox1})
        Me.panel2.Location = New System.Drawing.Point(24, 387)
        Me.panel2.Name = "panel2"
        Me.panel2.Size = New System.Drawing.Size(136, 112)
        Me.panel2.TabIndex = 30
        '
        'checkedListBox1
        '
        Me.checkedListBox1.Items.AddRange(New Object() {"First Item", "Second Item", "Third Item", "Fourth Item", "Fifth Item"})
        Me.checkedListBox1.Location = New System.Drawing.Point(8, 8)
        Me.checkedListBox1.Name = "checkedListBox1"
        Me.checkedListBox1.Size = New System.Drawing.Size(120, 94)
        Me.checkedListBox1.TabIndex = 0
        '
        'panel4
        '
        Me.panel4.Controls.AddRange(New System.Windows.Forms.Control() {Me.listView1})
        Me.panel4.Location = New System.Drawing.Point(176, 19)
        Me.panel4.Name = "panel4"
        Me.panel4.Size = New System.Drawing.Size(200, 128)
        Me.panel4.TabIndex = 32
        '
        'listView1
        '
        Me.listView1.Items.AddRange(New System.Windows.Forms.ListViewItem() {ListViewItem1, ListViewItem2, ListViewItem3, ListViewItem4, ListViewItem5})
        Me.listView1.LargeImageList = Me.imageList1
        Me.listView1.Location = New System.Drawing.Point(8, 8)
        Me.listView1.Name = "listView1"
        Me.listView1.Size = New System.Drawing.Size(184, 112)
        Me.listView1.SmallImageList = Me.imageList1
        Me.listView1.TabIndex = 0
        '
        'imageList1
        '
        Me.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.imageList1.ImageSize = New System.Drawing.Size(32, 32)
        Me.imageList1.ImageStream = CType(resources.GetObject("imageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imageList1.TransparentColor = System.Drawing.Color.Transparent
        '
        'panel7
        '
        Me.panel7.Controls.AddRange(New System.Windows.Forms.Control() {Me.richTextBox1})
        Me.panel7.Location = New System.Drawing.Point(392, 195)
        Me.panel7.Name = "panel7"
        Me.panel7.Size = New System.Drawing.Size(240, 112)
        Me.panel7.TabIndex = 36
        '
        'richTextBox1
        '
        Me.richTextBox1.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.richTextBox1.Location = New System.Drawing.Point(8, 8)
        Me.richTextBox1.Name = "richTextBox1"
        Me.richTextBox1.Size = New System.Drawing.Size(224, 96)
        Me.richTextBox1.TabIndex = 20
        Me.richTextBox1.Text = "This is a rich edit box, please visit http://www.microsoft.com for more informati" & _
        "on."
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(16, 131)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(152, 23)
        Me.button1.TabIndex = 25
        Me.button1.Text = "button1"
        '
        'textBox1
        '
        Me.textBox1.Location = New System.Drawing.Point(16, 107)
        Me.textBox1.Name = "textBox1"
        Me.textBox1.Size = New System.Drawing.Size(152, 20)
        Me.textBox1.TabIndex = 24
        Me.textBox1.Text = "textBox1"
        '
        'linkLabel1
        '
        Me.linkLabel1.Location = New System.Drawing.Point(24, 67)
        Me.linkLabel1.Name = "linkLabel1"
        Me.linkLabel1.Size = New System.Drawing.Size(144, 40)
        Me.linkLabel1.TabIndex = 23
        Me.linkLabel1.TabStop = True
        Me.linkLabel1.Text = "linkLabel1"
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(24, 19)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(144, 40)
        Me.label1.TabIndex = 22
        Me.label1.Text = "label1"
        '
        'panel5
        '
        Me.panel5.Controls.AddRange(New System.Windows.Forms.Control() {Me.treeView1})
        Me.panel5.Location = New System.Drawing.Point(176, 155)
        Me.panel5.Name = "panel5"
        Me.panel5.Size = New System.Drawing.Size(200, 128)
        Me.panel5.TabIndex = 33
        '
        'treeView1
        '
        Me.treeView1.ImageIndex = -1
        Me.treeView1.Location = New System.Drawing.Point(8, 8)
        Me.treeView1.Name = "treeView1"
        Me.treeView1.SelectedImageIndex = -1
        Me.treeView1.Size = New System.Drawing.Size(184, 112)
        Me.treeView1.TabIndex = 0
        '
        'ControlOverview
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(704, 670)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.trackBar1, Me.numericUpDown1, Me.panel6, Me.monthCalendar1, Me.button2, Me.tabControl1, Me.vScrollBar1, Me.domainUpDown1, Me.hScrollBar1, Me.panel3, Me.panel1, Me.pictureBox1, Me.radioButton1, Me.checkBox1, Me.panel2, Me.panel4, Me.panel7, Me.button1, Me.textBox1, Me.linkLabel1, Me.label1, Me.panel5, Me.progressBar1})
        Me.Name = "ControlOverview"
        Me.Text = "ControlOverview"
        CType(Me.trackBar1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panel6.ResumeLayout(False)
        Me.tabControl1.ResumeLayout(False)
        Me.panel3.ResumeLayout(False)
        Me.panel1.ResumeLayout(False)
        Me.panel2.ResumeLayout(False)
        Me.panel4.ResumeLayout(False)
        Me.panel7.ResumeLayout(False)
        Me.panel5.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles button2.Click
        Dim dlg As WindowElementsForm = New WindowElementsForm()
        dlg.ShowDialog()
    End Sub

    Private Sub trackBar1_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles trackBar1.ValueChanged
        MessageBox.Show(trackBar1.Value.ToString())
    End Sub

    Private Sub listView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles listView1.SelectedIndexChanged
        ' Show the first of the selected items
        MessageBox.Show(String.Format("Selected Item is: {0}", _
            listView1.SelectedItems(0)))
    End Sub

    Private Sub comboBox1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles comboBox1.SelectedIndexChanged
        ' Item changed, so let the user know which one is selected
        MessageBox.Show(String.Format("Selected Item is: {0}", _
            comboBox1.SelectedItem))
    End Sub

    Private Sub listBox1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles listBox1.SelectedIndexChanged
        ' Item changed, so let the user know which one is selected
        MessageBox.Show(String.Format("Selected Item is: {0}", _
            listBox1.SelectedItem))
    End Sub

    Private Sub button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles button1.Click
        'MessageBox.Show("Button1 clicked!")
        'MessageBox.Show(domainUpDown1.Text)
        'MessageBox.Show(numericUpDown1.Value.ToString())

        '' Advance the progress bar
        'progressBar1.Increment(1)

        '' Decrement the progress bar
        'progressBar1.Increment(-1)

        '' Save the file
        'richTextBox1.SaveFile("myfile.rtf", RichTextBoxStreamType.RichText)

        '' Change the index to the third page (2 = 3rd page)
        '' Both lines do the same thing, select the page by index
        '' or page control name
        'tabControl1.SelectedIndex = 2
        'tabControl1.SelectedTab = tabPage3 ' Name of page control
    End Sub

    Private Sub linkLabel1_LinkClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles linkLabel1.LinkClicked
        ' For URL's, usually just doing a start process works fine
        System.Diagnostics.Process.Start(CStr(e.Link.LinkData))
    End Sub

    Private Sub ControlOverview_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '' Label
        'label1.Text = "This is some test text..."
        'label1.TextAlign = ContentAlignment.TopCenter

        '' LinkLabel
        '' Will automatically parse common URLs
        'linkLabel1.Text = "http://sellsbrothers.com"

        '' Alternatively, you could do so:

        '' Can add links manually to hide read addresses
        'linkLabel1.Text = "Click here to continue..."

        '' Create a new link at the 'here' word
        'linkLabel1.Links.Add( _
        '                      "Click ".Length, _
        '                      "here".Length, _
        '                      "http://sellsbrothers.com")

        '' text box
        'MessageBox.Show(textBox1.Text)

        '' check box
        'If checkBox1.Checked Then
        '    MessageBox.Show("Check box checked!")
        'Else
        '    MessageBox.Show("Check box is not checked")
        'End If

        '' radio button
        'If radioButton1.Checked Then
        '    MessageBox.Show("Radio button checked!")
        'Else
        '    MessageBox.Show("Radio button is not checked")
        'End If

        '' picture box
        'pictureBox1.Image = New Bitmap("C:\windows\zapotec.bmp")

        '' list box
        'messagebox.Show(string.Format("Selected Item is: {0}", _
        '                listbox1.SelectedItem)

        '' combo box
        'MessageBox.Show(comboBox1.Text)

        '' change the view type
        'listView1.View = View.SmallIcon

        '' tree view

        '' create tree items
        'Dim topNode As TreeNode = treeView1.Nodes.Add("Top Item")

        '' add child nodes in the top node
        'topNode.Nodes.Add("Child Node")
        'topNode.Nodes.Add("Another Child Node")

        '' Get all the Dates chosen
        '' SelectionStart is beginning Date
        '' SelectionEnd is last date
        '' SelectionRange will return all the dates
        'MessageBox.Show(String.Format("Date(s): {0} - {1}", _
        '            monthCalendar1.SelectionStart.ToShortDateString(), _
        '            monthCalendar1.SelectionEnd.ToShortDateString()))

        '' Show the Date (or time) picked
        'MessageBox.Show(dateTimePicker1.Value.ToShortDateString())

        'hScrollBar1.Minimum = 0
        'hScrollBar1.Maximum = 10

        'vScrollBar1.Minimum = 0
        'vScrollBar1.Maximum = 1000

    End Sub
End Class
