Imports System
Imports System.ComponentModel
Imports System.Collections
Imports System.Diagnostics
Imports System.Windows.Forms

Public Delegate Sub TimeChangedEventHandler(ByVal sender As Object, ByVal e As EventArgs)

<Description("Component to fire an event when time has changed by a certain delta")> _
Public Class TimeWatcherComponent
    Inherits System.ComponentModel.Component

    Private _delta As Integer
    Private _lastNotification As DateTime = DateTime.MinValue

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)

    End Sub

#End Region


    Public Event TimeChanged As TimeChangedEventHandler

    <Description("Interval in milliseconds to check if time has changed"), DefaultValue(100)> _
    Public Property Interval() As Integer
        Get
            Return Timer1.Interval
        End Get
        Set(ByVal Value As Integer)
            Timer1.Interval = Value
        End Set
    End Property

    <Description("Enables generation of TimeChanged events"), DefaultValue(True)> _
    Public Property Enabled() As Boolean
        Get
            Return Timer1.Enabled
        End Get
        Set(ByVal Value As Boolean)
            Timer1.Enabled = Value
        End Set
    End Property

    <Description("Number of milliseconds worthy of a TimeChanged event"), DefaultValue(1000)> _
    Public Property Delta() As Integer
        Get
            Return _delta
        End Get
        Set(ByVal Value As Integer)
            _delta = Value
        End Set
    End Property

#Region "Implementation"
    Private Sub Timer1_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Dim now As DateTime = DateTime.Now
        Dim diff As TimeSpan = now.Subtract(_lastNotification)

        ' If the delta in time is enough to notify the container
        If diff.TotalMilliseconds >= _delta Then
            ' Notify the contain
            RaiseEvent TimeChanged(Me, EventArgs.Empty)

            ' Cache the last notification for future comparisons
            _lastNotification = now
        End If

    End Sub
#End Region


End Class
