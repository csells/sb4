Public Class WindowElementsForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents statusBarPanel1 As System.Windows.Forms.StatusBarPanel
    Friend WithEvents toolBarButton3 As System.Windows.Forms.ToolBarButton
    Friend WithEvents menuItem12 As System.Windows.Forms.MenuItem
    Friend WithEvents toolBarButton2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem4 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem5 As System.Windows.Forms.MenuItem
    Friend WithEvents listBox1 As System.Windows.Forms.ListBox
    Friend WithEvents menuItem11 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem10 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem7 As System.Windows.Forms.MenuItem
    Friend WithEvents splitter1 As System.Windows.Forms.Splitter
    Friend WithEvents toolBarButton4 As System.Windows.Forms.ToolBarButton
    Friend WithEvents contextMenu1 As System.Windows.Forms.ContextMenu
    Friend WithEvents menuItem6 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem8 As System.Windows.Forms.MenuItem
    Friend WithEvents contextMenu2 As System.Windows.Forms.ContextMenu
    Friend WithEvents menuItem9 As System.Windows.Forms.MenuItem
    Friend WithEvents statusBar1 As System.Windows.Forms.StatusBar
    Friend WithEvents statusBarPanel2 As System.Windows.Forms.StatusBarPanel
    Friend WithEvents statusBarPanel3 As System.Windows.Forms.StatusBarPanel
    Friend WithEvents statusBarPanel4 As System.Windows.Forms.StatusBarPanel
    Friend WithEvents imageList1 As System.Windows.Forms.ImageList
    Friend WithEvents toolBarButton1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents toolBar1 As System.Windows.Forms.ToolBar
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(WindowElementsForm))
        Me.statusBarPanel1 = New System.Windows.Forms.StatusBarPanel()
        Me.toolBarButton3 = New System.Windows.Forms.ToolBarButton()
        Me.menuItem12 = New System.Windows.Forms.MenuItem()
        Me.toolBarButton2 = New System.Windows.Forms.ToolBarButton()
        Me.menuItem1 = New System.Windows.Forms.MenuItem()
        Me.menuItem2 = New System.Windows.Forms.MenuItem()
        Me.menuItem3 = New System.Windows.Forms.MenuItem()
        Me.menuItem4 = New System.Windows.Forms.MenuItem()
        Me.menuItem5 = New System.Windows.Forms.MenuItem()
        Me.listBox1 = New System.Windows.Forms.ListBox()
        Me.menuItem11 = New System.Windows.Forms.MenuItem()
        Me.menuItem10 = New System.Windows.Forms.MenuItem()
        Me.menuItem7 = New System.Windows.Forms.MenuItem()
        Me.splitter1 = New System.Windows.Forms.Splitter()
        Me.toolBarButton4 = New System.Windows.Forms.ToolBarButton()
        Me.contextMenu1 = New System.Windows.Forms.ContextMenu()
        Me.menuItem6 = New System.Windows.Forms.MenuItem()
        Me.menuItem8 = New System.Windows.Forms.MenuItem()
        Me.contextMenu2 = New System.Windows.Forms.ContextMenu()
        Me.menuItem9 = New System.Windows.Forms.MenuItem()
        Me.statusBar1 = New System.Windows.Forms.StatusBar()
        Me.statusBarPanel2 = New System.Windows.Forms.StatusBarPanel()
        Me.statusBarPanel3 = New System.Windows.Forms.StatusBarPanel()
        Me.statusBarPanel4 = New System.Windows.Forms.StatusBarPanel()
        Me.imageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.toolBarButton1 = New System.Windows.Forms.ToolBarButton()
        Me.toolBar1 = New System.Windows.Forms.ToolBar()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu()
        CType(Me.statusBarPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.statusBarPanel2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.statusBarPanel3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.statusBarPanel4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'statusBarPanel1
        '
        Me.statusBarPanel1.Text = "Ready..."
        Me.statusBarPanel1.Width = 60
        '
        'toolBarButton3
        '
        Me.toolBarButton3.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'menuItem12
        '
        Me.menuItem12.Index = 3
        Me.menuItem12.Text = "P&roperties"
        '
        'toolBarButton2
        '
        Me.toolBarButton2.ImageIndex = 1
        Me.toolBarButton2.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton
        Me.toolBarButton2.Text = "Toggle"
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem2, Me.menuItem3, Me.menuItem4, Me.menuItem5})
        Me.menuItem1.Text = "&File"
        Me.menuItem1.Visible = False
        '
        'menuItem2
        '
        Me.menuItem2.Index = 0
        Me.menuItem2.Text = "&Open"
        '
        'menuItem3
        '
        Me.menuItem3.Index = 1
        Me.menuItem3.Text = "&Close"
        '
        'menuItem4
        '
        Me.menuItem4.Index = 2
        Me.menuItem4.Text = "-"
        '
        'menuItem5
        '
        Me.menuItem5.Index = 3
        Me.menuItem5.Text = "E&xit"
        '
        'listBox1
        '
        Me.listBox1.Location = New System.Drawing.Point(5, 152)
        Me.listBox1.Name = "listBox1"
        Me.listBox1.Size = New System.Drawing.Size(120, 95)
        Me.listBox1.TabIndex = 4
        Me.listBox1.Visible = False
        '
        'menuItem11
        '
        Me.menuItem11.Index = 2
        Me.menuItem11.Text = "-"
        '
        'menuItem10
        '
        Me.menuItem10.Index = 1
        Me.menuItem10.Text = "&Paste"
        '
        'menuItem7
        '
        Me.menuItem7.Index = 1
        Me.menuItem7.Text = "Cyanide"
        '
        'splitter1
        '
        Me.splitter1.Location = New System.Drawing.Point(0, 39)
        Me.splitter1.Name = "splitter1"
        Me.splitter1.Size = New System.Drawing.Size(3, 226)
        Me.splitter1.TabIndex = 5
        Me.splitter1.TabStop = False
        Me.splitter1.Visible = False
        '
        'toolBarButton4
        '
        Me.toolBarButton4.DropDownMenu = Me.contextMenu1
        Me.toolBarButton4.ImageIndex = 2
        Me.toolBarButton4.Style = System.Windows.Forms.ToolBarButtonStyle.DropDownButton
        Me.toolBarButton4.Text = "Pick your poison"
        '
        'contextMenu1
        '
        Me.contextMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem6, Me.menuItem7, Me.menuItem8})
        '
        'menuItem6
        '
        Me.menuItem6.Index = 0
        Me.menuItem6.Text = "Arsenic"
        '
        'menuItem8
        '
        Me.menuItem8.Index = 2
        Me.menuItem8.Text = "Rat Poison"
        '
        'contextMenu2
        '
        Me.contextMenu2.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem9, Me.menuItem10, Me.menuItem11, Me.menuItem12})
        '
        'menuItem9
        '
        Me.menuItem9.Index = 0
        Me.menuItem9.Text = "&Copy"
        '
        'statusBar1
        '
        Me.statusBar1.Location = New System.Drawing.Point(0, 265)
        Me.statusBar1.Name = "statusBar1"
        Me.statusBar1.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.statusBarPanel1, Me.statusBarPanel2, Me.statusBarPanel3, Me.statusBarPanel4})
        Me.statusBar1.ShowPanels = True
        Me.statusBar1.Size = New System.Drawing.Size(292, 22)
        Me.statusBar1.TabIndex = 7
        Me.statusBar1.Text = "statusBar1"
        '
        'statusBarPanel2
        '
        Me.statusBarPanel2.Alignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.statusBarPanel2.Text = "INS"
        Me.statusBarPanel2.Width = 30
        '
        'statusBarPanel3
        '
        Me.statusBarPanel3.Alignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.statusBarPanel3.Text = "DEL"
        Me.statusBarPanel3.Width = 30
        '
        'statusBarPanel4
        '
        Me.statusBarPanel4.Alignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.statusBarPanel4.Text = "OVR"
        Me.statusBarPanel4.Width = 30
        '
        'imageList1
        '
        Me.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.imageList1.ImageSize = New System.Drawing.Size(16, 16)
        Me.imageList1.ImageStream = CType(resources.GetObject("imageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imageList1.TransparentColor = System.Drawing.Color.Transparent
        '
        'toolBarButton1
        '
        Me.toolBarButton1.ImageIndex = 0
        Me.toolBarButton1.Text = "TestBtn"
        '
        'toolBar1
        '
        Me.toolBar1.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.toolBarButton1, Me.toolBarButton2, Me.toolBarButton3, Me.toolBarButton4})
        Me.toolBar1.DropDownArrows = True
        Me.toolBar1.ImageList = Me.imageList1
        Me.toolBar1.Name = "toolBar1"
        Me.toolBar1.ShowToolTips = True
        Me.toolBar1.Size = New System.Drawing.Size(292, 39)
        Me.toolBar1.TabIndex = 6
        Me.toolBar1.Visible = False
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1})
        '
        'WindowElementsForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 287)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.listBox1, Me.splitter1, Me.statusBar1, Me.toolBar1})
        Me.Menu = Me.mainMenu1
        Me.Name = "WindowElementsForm"
        Me.Text = "WindowElementsForm"
        CType(Me.statusBarPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.statusBarPanel2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.statusBarPanel3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.statusBarPanel4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub WindowElementsForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Set the mimimum size from the left side (or top)
        splitter1.MinSize = 50

        ' Set the minimum size from the right side (or bottom)
        splitter1.MinExtra = 50
    End Sub

    ' Open Menu Item
    Private Sub menuItem2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles menuItem2.Click
        ' ...
    End Sub

    ' TestBtn clicked
    Private Sub toolBar1_ButtonClick(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles toolBar1.ButtonClick
        ' ...
    End Sub

    ' Insert selected
    Private Sub menuItem6_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles menuItem6.Click
        ' ...
    End Sub

    ' Paste
    Private Sub menuItem10_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles menuItem10.Click
        ' ...
        ' Set the text in one of the panels
        statusBar1.Panels(0).Text = "Working..."
    End Sub
End Class
