Public Class OwnerDrawnStatusBar
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents statusBar1 As System.Windows.Forms.StatusBar
    Friend WithEvents statusBarPanel1 As System.Windows.Forms.StatusBarPanel
    Friend WithEvents statusBarPanel2 As System.Windows.Forms.StatusBarPanel
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.statusBar1 = New System.Windows.Forms.StatusBar()
        Me.statusBarPanel1 = New System.Windows.Forms.StatusBarPanel()
        Me.statusBarPanel2 = New System.Windows.Forms.StatusBarPanel()
        CType(Me.statusBarPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.statusBarPanel2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'statusBar1
        '
        Me.statusBar1.Location = New System.Drawing.Point(0, 62)
        Me.statusBar1.Name = "statusBar1"
        Me.statusBar1.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.statusBarPanel1, Me.statusBarPanel2})
        Me.statusBar1.ShowPanels = True
        Me.statusBar1.Size = New System.Drawing.Size(360, 32)
        Me.statusBar1.TabIndex = 4
        Me.statusBar1.Text = "statusBar1"
        '
        'statusBarPanel1
        '
        Me.statusBarPanel1.Text = "Next Panel is OwnerDrawn -->"
        Me.statusBarPanel1.Width = 190
        '
        'statusBarPanel2
        '
        Me.statusBarPanel2.Style = System.Windows.Forms.StatusBarPanelStyle.OwnerDraw
        Me.statusBarPanel2.Text = "statusBarPanel2"
        Me.statusBarPanel2.Width = 113
        '
        'OwnerDrawnStatusBar
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(360, 94)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.statusBar1})
        Me.Name = "OwnerDrawnStatusBar"
        Me.Text = "OwnerDrawnStatusBar"
        CType(Me.statusBarPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.statusBarPanel2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub statusBar1_DrawItem(ByVal sender As Object, ByVal sbdevent As System.Windows.Forms.StatusBarDrawItemEventArgs) Handles statusBar1.DrawItem
        Dim b As Brush = New SolidBrush(sbdevent.ForeColor)
        Dim format As StringFormat = New StringFormat()
        format.LineAlignment = StringAlignment.Center
        format.Alignment = StringAlignment.Center

        ' Draw a grey background
        ' sbdevent.DrawBackground() doesn't work because we
        ' took responsibility for all the drawing
        sbdevent.Graphics.DrawRectangle(New Pen(sbdevent.BackColor), sbdevent.Bounds)

        ' Draw button with text
        ControlPaint.DrawButton(sbdevent.Graphics, _
            sbdevent.Bounds.Left + 5, _
            sbdevent.Bounds.Top + 5, _
            sbdevent.Bounds.Width - 10, _
            sbdevent.Bounds.Height - 10, _
            ButtonState.Normal)
        sbdevent.Graphics.DrawString("Press Me", sbdevent.Font, b, sbdevent.Bounds.X, sbdevent.Bounds.Y, format)

        ' Clean up our resources
        b.Dispose()

        ' Draw the icon
        ' sbdevent.Graphics.DrawIconUnstretched(Me.Icon, sbdevent.Bounds)

    End Sub
End Class
