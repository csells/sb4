Public Class LoanApplicationDialog
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents okButton As System.Windows.Forms.Button
    Friend WithEvents applicantNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend Shadows WithEvents cancelButton As System.Windows.Forms.Button
    Friend WithEvents applicantPhoneNoTextBox As System.Windows.Forms.TextBox
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents applicantLoanAmountTextBox As System.Windows.Forms.TextBox
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents errorProvider As System.Windows.Forms.ErrorProvider
    Friend WithEvents helpProvider1 As System.Windows.Forms.HelpProvider
    Friend WithEvents infoProvider As System.Windows.Forms.ErrorProvider
    Friend WithEvents toolTip1 As System.Windows.Forms.ToolTip
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(LoanApplicationDialog))
        Me.okButton = New System.Windows.Forms.Button()
        Me.applicantNameTextBox = New System.Windows.Forms.TextBox()
        Me.label1 = New System.Windows.Forms.Label()
        Me.cancelButton = New System.Windows.Forms.Button()
        Me.applicantPhoneNoTextBox = New System.Windows.Forms.TextBox()
        Me.label2 = New System.Windows.Forms.Label()
        Me.applicantLoanAmountTextBox = New System.Windows.Forms.TextBox()
        Me.label3 = New System.Windows.Forms.Label()
        Me.errorProvider = New System.Windows.Forms.ErrorProvider()
        Me.helpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.infoProvider = New System.Windows.Forms.ErrorProvider()
        Me.toolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.SuspendLayout()
        '
        'okButton
        '
        Me.okButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.okButton.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.okButton.Location = New System.Drawing.Point(113, 126)
        Me.okButton.Name = "okButton"
        Me.okButton.TabIndex = 9
        Me.okButton.Text = "OK"
        '
        'applicantNameTextBox
        '
        Me.applicantNameTextBox.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.applicantNameTextBox.Location = New System.Drawing.Point(129, 18)
        Me.applicantNameTextBox.Name = "applicantNameTextBox"
        Me.applicantNameTextBox.Size = New System.Drawing.Size(144, 20)
        Me.applicantNameTextBox.TabIndex = 7
        Me.applicantNameTextBox.Text = ""
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(17, 18)
        Me.label1.Name = "label1"
        Me.label1.TabIndex = 3
        Me.label1.Text = "Applicant Name"
        Me.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cancelButton
        '
        Me.cancelButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.cancelButton.CausesValidation = False
        Me.cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cancelButton.Location = New System.Drawing.Point(201, 126)
        Me.cancelButton.Name = "cancelButton"
        Me.cancelButton.TabIndex = 10
        Me.cancelButton.Text = "Cancel"
        '
        'applicantPhoneNoTextBox
        '
        Me.applicantPhoneNoTextBox.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.applicantPhoneNoTextBox.Location = New System.Drawing.Point(129, 50)
        Me.applicantPhoneNoTextBox.Name = "applicantPhoneNoTextBox"
        Me.applicantPhoneNoTextBox.Size = New System.Drawing.Size(144, 20)
        Me.applicantPhoneNoTextBox.TabIndex = 6
        Me.applicantPhoneNoTextBox.Text = ""
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(17, 50)
        Me.label2.Name = "label2"
        Me.label2.TabIndex = 4
        Me.label2.Text = "Applicant Phone #"
        Me.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'applicantLoanAmountTextBox
        '
        Me.applicantLoanAmountTextBox.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.applicantLoanAmountTextBox.Location = New System.Drawing.Point(129, 82)
        Me.applicantLoanAmountTextBox.Name = "applicantLoanAmountTextBox"
        Me.applicantLoanAmountTextBox.Size = New System.Drawing.Size(144, 20)
        Me.applicantLoanAmountTextBox.TabIndex = 8
        Me.applicantLoanAmountTextBox.Text = ""
        Me.toolTip1.SetToolTip(Me.applicantLoanAmountTextBox, "Please enter a loan amount")
        '
        'label3
        '
        Me.label3.Location = New System.Drawing.Point(17, 82)
        Me.label3.Name = "label3"
        Me.label3.TabIndex = 5
        Me.label3.Text = "Loan Amount"
        Me.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'errorProvider
        '
        Me.errorProvider.DataMember = Nothing
        '
        'helpProvider1
        '
        Me.helpProvider1.HelpNamespace = "dialogs.chm"
        '
        'infoProvider
        '
        Me.infoProvider.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink
        Me.infoProvider.Icon = CType(resources.GetObject("infoProvider.Icon"), System.Drawing.Icon)
        '
        'LoanApplicationDialog
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 166)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.okButton, Me.applicantNameTextBox, Me.label1, Me.cancelButton, Me.applicantPhoneNoTextBox, Me.label2, Me.applicantLoanAmountTextBox, Me.label3})
        Me.Name = "LoanApplicationDialog"
        Me.Text = "LoanApplicationDialog"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub okButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles okButton.Click
        'Validate each control manually
        Dim control As Control
        For Each control In Me.Controls
            control.Focus()
            If Not Me.Validate() Then
                Me.DialogResult = DialogResult.None
                Return
            End If
        Next
    End Sub

    Private Sub cancelButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cancelButton.Click
        'Me.DialogResult = DialogResult.Cancel
        'Me.Close()
    End Sub
    'If Me.Modal Then
    '    'Show as a fixed-sized modal dialog
    '    Me.FormBorderStyle = FormBorderStyle.FixedDialog
    'Else
    '    'Show as a sizeable modeless dialog
    '    Me.FormBorderStyle = FormBorderStyle.Sizable
    'End If
    Private Sub LoanApplicationDialog_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Use tooltips to populate the "information provider"
        Dim control As Control
        Dim toolTip As String
        For Each control In Me.Controls
            toolTip = toolTip1.GetToolTip(control)
            If toolTip.Length > 0 Then infoProvider.SetError(control, toolTip)
        Next
    End Sub
    'Dim controlSender As Control = sender
    'Dim toolTip As String = toolTip1.GetToolTip(controlSender)

    'Dim textboxSender As TextBox = sender
    'If textboxSender.Text.Length = 0 Then
    '    errorProvider.SetError(controlSender, toolTip)
    '    e.Cancel = True
    'Else
    '    errorProvider.SetError(controlSender, Nothing)
    'End If
    'Dim sError As String = ""
    'If applicantNameTextBox.Text.Length = 0 Then
    '    sError = "Please enter a name"
    '    e.Cancel = True
    'End If
    'Dim controlSender As Control = sender
    'errorProvider.SetError(CType(sender, Control), sError)
    Private Sub applicantNameTextBox_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles applicantNameTextBox.Validating
        Dim toolTip As String = toolTip1.GetToolTip(CType(sender, Control))
        If CType(sender, TextBox).Text.Length = 0 Then
            'Show the error when there is no text in the text box
            errorProvider.SetError(CType(sender, Control), toolTip)
            infoProvider.SetError(CType(sender, Control), "")
            e.Cancel = True
        Else
            'Show the info when there is text in the text box
            errorProvider.SetError(CType(sender, Control), "")
            infoProvider.SetError(CType(sender, Control), toolTip)
        End If
    End Sub

    Private Sub applicantLoanAmountTextBox_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles applicantLoanAmountTextBox.Validating
        Dim controlSender As Control = sender
        Dim toolTip As String = toolTip1.GetToolTip(controlSender)

        Dim textboxSender As TextBox = sender
        If textboxSender.Text.Length = 0 Then
            errorProvider.SetError(controlSender, toolTip)
            e.Cancel = True
        Else
            errorProvider.SetError(controlSender, Nothing)
        End If
    End Sub

    Public Property ApplicantName() As String
        Get
            Return applicantNameTextBox.Text
        End Get
        Set(ByVal Value As String)
            applicantNameTextBox.Text = Value
        End Set
    End Property
    'Dim controlNeedingHelp As Control

    ''Convert screen coordinates to client coordinates
    'Dim pt As Point = Me.PointToClient(hlpevent.MousePos)

    ''Look for control user clicked on
    'For Each controlNeedingHelp In Me.Controls
    '    If controlNeedingHelp.Bounds.Contains(pt) Then Exit For
    'Next

    ''Show help
    'Dim help As String = toolTip1.GetToolTip(controlNeedingHelp)
    'If help.Length = 0 Then Exit Sub
    'MessageBox.Show(help, "Help")
    'hlpevent.Handled = True
    ''If no mouse button being clicked, F1 got us here
    'If Control.MouseButtons = MouseButtons.None Then
    '    'open a help file...
    'Else
    '    'show the message box
    'End If
    'If Control.MouseButtons = MouseButtons.None Then
    '    'open a help file
    '    'Help button got us here
    'Else
    '    'Look for control user clicked on
    '    Dim pt As Point = Me.PointToClient(hlpevent.MousePos)
    '    Dim control As Control
    '    For Each control In Me.Controls
    '        If control.Bounds.Contains(pt) Then
    '            Dim sHelp As String = toolTip1.GetToolTip(control)
    '            If sHelp.Length > 0 Then
    '                Help.ShowPopup(Me, sHelp, hlpevent.MousePos)
    '                hlpevent.Handled = True
    '                Exit For
    '            End If
    '        End If
    '    Next
    'End If
    ''F1
    'If Control.MouseButtons = MouseButtons.None Then
    '    Help.ShowHelp(Me, System.IO.Path.GetFullPath("loanApplicationDialog.htm"))
    '    hlpevent.Handled = True
    'End If
    '...
    Private Sub LoanApplicationDialog_HelpRequested(ByVal sender As Object, ByVal hlpevent As System.Windows.Forms.HelpEventArgs) Handles MyBase.HelpRequested
        'F1
        If Control.MouseButtons = MouseButtons.None Then
            Dim subtopic As String = ""
            If Me.ActiveControl Is Me.applicantNameTextBox Then subtopic = "name"
            If Me.ActiveControl Is Me.applicantPhoneNoTextBox Then subtopic = "phoneNo"
            If Me.ActiveControl Is Me.applicantLoanAmountTextBox Then subtopic = "loanAmount"
            Help.ShowHelp(Me, "dialogs.chm", "loanApplicationDialog.htm#" & subtopic)
            hlpevent.Handled = True
        End If
        '...
    End Sub
End Class
