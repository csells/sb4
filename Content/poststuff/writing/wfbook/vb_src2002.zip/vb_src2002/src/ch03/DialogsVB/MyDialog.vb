Public Class MyDialog
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents colorDialogButton As System.Windows.Forms.Button
    Friend WithEvents fontDialogButton As System.Windows.Forms.Button
    Friend WithEvents openFileDialogButton As System.Windows.Forms.Button
    Friend WithEvents pageSetupDialogButton As System.Windows.Forms.Button
    Friend WithEvents printDialogButton As System.Windows.Forms.Button
    Friend WithEvents printPreviewDialog As System.Windows.Forms.Button
    Friend WithEvents saveFileDialogButton As System.Windows.Forms.Button
    Friend WithEvents customDialogButton As System.Windows.Forms.Button
    Friend WithEvents folderBrowserDialogButton As System.Windows.Forms.Button
    Friend WithEvents pageSetupDialog1 As System.Windows.Forms.PageSetupDialog
    Friend WithEvents saveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents openFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents printPreviewDialog1 As System.Windows.Forms.PrintPreviewDialog
    Friend WithEvents helpProvider1 As System.Windows.Forms.HelpProvider
    Friend WithEvents contextMenu1 As System.Windows.Forms.ContextMenu
    Friend WithEvents helpContentsMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents helpIndexMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents helpSearchMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents colorDialog1 As System.Windows.Forms.ColorDialog
    Friend WithEvents printDialog1 As System.Windows.Forms.PrintDialog
    Friend WithEvents fontDialog1 As System.Windows.Forms.FontDialog
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(MyDialog))
        Me.colorDialogButton = New System.Windows.Forms.Button()
        Me.fontDialogButton = New System.Windows.Forms.Button()
        Me.openFileDialogButton = New System.Windows.Forms.Button()
        Me.pageSetupDialogButton = New System.Windows.Forms.Button()
        Me.printDialogButton = New System.Windows.Forms.Button()
        Me.printPreviewDialog = New System.Windows.Forms.Button()
        Me.saveFileDialogButton = New System.Windows.Forms.Button()
        Me.customDialogButton = New System.Windows.Forms.Button()
        Me.folderBrowserDialogButton = New System.Windows.Forms.Button()
        Me.pageSetupDialog1 = New System.Windows.Forms.PageSetupDialog()
        Me.saveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.openFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.printPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.helpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.contextMenu1 = New System.Windows.Forms.ContextMenu()
        Me.helpContentsMenuItem = New System.Windows.Forms.MenuItem()
        Me.helpIndexMenuItem = New System.Windows.Forms.MenuItem()
        Me.helpSearchMenuItem = New System.Windows.Forms.MenuItem()
        Me.colorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.printDialog1 = New System.Windows.Forms.PrintDialog()
        Me.fontDialog1 = New System.Windows.Forms.FontDialog()
        Me.SuspendLayout()
        '
        'colorDialogButton
        '
        Me.colorDialogButton.Location = New System.Drawing.Point(15, 12)
        Me.colorDialogButton.Name = "colorDialogButton"
        Me.colorDialogButton.Size = New System.Drawing.Size(136, 23)
        Me.colorDialogButton.TabIndex = 9
        Me.colorDialogButton.Text = "Color Dialog"
        '
        'fontDialogButton
        '
        Me.fontDialogButton.Location = New System.Drawing.Point(15, 44)
        Me.fontDialogButton.Name = "fontDialogButton"
        Me.fontDialogButton.Size = New System.Drawing.Size(136, 23)
        Me.fontDialogButton.TabIndex = 10
        Me.fontDialogButton.Text = "Font Dialog"
        '
        'openFileDialogButton
        '
        Me.openFileDialogButton.Location = New System.Drawing.Point(15, 76)
        Me.openFileDialogButton.Name = "openFileDialogButton"
        Me.openFileDialogButton.Size = New System.Drawing.Size(136, 23)
        Me.openFileDialogButton.TabIndex = 11
        Me.openFileDialogButton.Text = "Open File Dialog"
        '
        'pageSetupDialogButton
        '
        Me.pageSetupDialogButton.Location = New System.Drawing.Point(15, 108)
        Me.pageSetupDialogButton.Name = "pageSetupDialogButton"
        Me.pageSetupDialogButton.Size = New System.Drawing.Size(136, 23)
        Me.pageSetupDialogButton.TabIndex = 12
        Me.pageSetupDialogButton.Text = "Page Setup Dialog"
        '
        'printDialogButton
        '
        Me.printDialogButton.Location = New System.Drawing.Point(15, 140)
        Me.printDialogButton.Name = "printDialogButton"
        Me.printDialogButton.Size = New System.Drawing.Size(136, 23)
        Me.printDialogButton.TabIndex = 13
        Me.printDialogButton.Text = "Print Dialog"
        '
        'printPreviewDialog
        '
        Me.printPreviewDialog.Location = New System.Drawing.Point(15, 172)
        Me.printPreviewDialog.Name = "printPreviewDialog"
        Me.printPreviewDialog.Size = New System.Drawing.Size(136, 23)
        Me.printPreviewDialog.TabIndex = 14
        Me.printPreviewDialog.Text = "Print Preview Dialog"
        '
        'saveFileDialogButton
        '
        Me.saveFileDialogButton.Location = New System.Drawing.Point(15, 204)
        Me.saveFileDialogButton.Name = "saveFileDialogButton"
        Me.saveFileDialogButton.Size = New System.Drawing.Size(136, 23)
        Me.saveFileDialogButton.TabIndex = 15
        Me.saveFileDialogButton.Text = "Save File Dialog"
        '
        'customDialogButton
        '
        Me.customDialogButton.Location = New System.Drawing.Point(15, 268)
        Me.customDialogButton.Name = "customDialogButton"
        Me.customDialogButton.Size = New System.Drawing.Size(136, 23)
        Me.customDialogButton.TabIndex = 17
        Me.customDialogButton.Text = "Custom Dialog"
        '
        'folderBrowserDialogButton
        '
        Me.folderBrowserDialogButton.Location = New System.Drawing.Point(15, 236)
        Me.folderBrowserDialogButton.Name = "folderBrowserDialogButton"
        Me.folderBrowserDialogButton.Size = New System.Drawing.Size(136, 23)
        Me.folderBrowserDialogButton.TabIndex = 16
        Me.folderBrowserDialogButton.Text = "Folder Browser Dialog"
        '
        'saveFileDialog1
        '
        Me.saveFileDialog1.FileName = "doc1"
        '
        'printPreviewDialog1
        '
        Me.printPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.printPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.printPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.printPreviewDialog1.Enabled = True
        Me.printPreviewDialog1.Icon = CType(resources.GetObject("printPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.printPreviewDialog1.Location = New System.Drawing.Point(66, 87)
        Me.printPreviewDialog1.MaximumSize = New System.Drawing.Size(0, 0)
        Me.printPreviewDialog1.Name = "printPreviewDialog1"
        Me.printPreviewDialog1.Opacity = 1
        Me.printPreviewDialog1.TransparencyKey = System.Drawing.Color.Empty
        Me.printPreviewDialog1.Visible = False
        '
        'contextMenu1
        '
        Me.contextMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.helpContentsMenuItem, Me.helpIndexMenuItem, Me.helpSearchMenuItem})
        '
        'helpContentsMenuItem
        '
        Me.helpContentsMenuItem.Index = 0
        Me.helpContentsMenuItem.Text = "Help Contents"
        '
        'helpIndexMenuItem
        '
        Me.helpIndexMenuItem.Index = 1
        Me.helpIndexMenuItem.Text = "Help Index"
        '
        'helpSearchMenuItem
        '
        Me.helpSearchMenuItem.Index = 2
        Me.helpSearchMenuItem.Text = "Help Search"
        '
        'MyDialog
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(166, 302)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.colorDialogButton, Me.fontDialogButton, Me.openFileDialogButton, Me.pageSetupDialogButton, Me.printDialogButton, Me.printPreviewDialog, Me.saveFileDialogButton, Me.customDialogButton, Me.folderBrowserDialogButton})
        Me.Name = "MyDialog"
        Me.Text = "MyDialog"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub colorDialogButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles colorDialogButton.Click
        colorDialog1.Color = Color.Red
        Dim res As DialogResult = colorDialog1.ShowDialog()
        If res = DialogResult.OK Then
            MessageBox.Show("You picked " & colorDialog1.Color.ToString(), "Color Picked")
        End If
    End Sub

    Private Sub fontDialogButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles fontDialogButton.Click
        fontDialog1.ShowDialog()
    End Sub

    Private Sub openFileDialogButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles openFileDialogButton.Click
        Dim dlg As OpenFileDialog = New OpenFileDialog()
        Dim res As DialogResult = dlg.ShowDialog()
        If res = DialogResult.OK Then
            MessageBox.Show("You picked: " & dlg.FileName)
        End If
    End Sub

    Private Sub pageSetupDialogButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pageSetupDialogButton.Click
        pageSetupDialog1.ShowDialog()
    End Sub

    Private Sub printDialogButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles printDialogButton.Click
        printDialog1.ShowDialog()
    End Sub

    Private Sub printPreviewDialog_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintPreviewDialog.Click
        printPreviewDialog1.ShowDialog()
    End Sub

    Private Sub saveFileDialogButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles saveFileDialogButton.Click
        saveFileDialog1.ShowDialog()
    End Sub

    Private Sub customDialogButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles customDialogButton.Click
        Dim dlg As LoanApplicationDialog = New LoanApplicationDialog()
        dlg.ApplicantName = "Joe Borrower"
        Dim res As DialogResult = dlg.ShowDialog()
    End Sub

    Private Sub helpContentsMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles helpContentsMenuItem.Click
        Help.ShowHelp(Me, "dialogs.chm", HelpNavigator.TableOfContents)
    End Sub

    Private Sub helpIndexMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles helpIndexMenuItem.Click
        Help.ShowHelpIndex(Me, "dialogs.chm")
    End Sub

    Private Sub helpSearchMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles helpSearchMenuItem.Click
        Help.ShowHelp(Me, "dialogs.chm", HelpNavigator.Find, "")
    End Sub


    Private WithEvents pdlg As PropertiesDialog

    Private Sub folderBrowserDialogButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles folderBrowserDialogButton.Click
        pdlg = New PropertiesDialog()
        pdlg.Show()
    End Sub

    Private Sub pdlg_Accept(ByVal sender As Object, ByVal e As System.EventArgs) Handles pdlg.Accept
        MessageBox.Show("Accepted")
    End Sub
End Class
