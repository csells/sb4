Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents formBorderStyleLabel As System.Windows.Forms.Label
    Friend WithEvents controlBoxLabel As System.Windows.Forms.Label
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents label4 As System.Windows.Forms.Label
    Friend WithEvents label5 As System.Windows.Forms.Label
    Friend WithEvents label6 As System.Windows.Forms.Label
    Friend WithEvents helpButtonLabel As System.Windows.Forms.Label
    Friend WithEvents minimizeBoxLabel As System.Windows.Forms.Label
    Friend WithEvents maximizeBoxLabel As System.Windows.Forms.Label
    Friend WithEvents showInTaskBarLabel As System.Windows.Forms.Label
    Friend WithEvents sizeGripStyleLabel As System.Windows.Forms.Label
    Friend WithEvents label8 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.formBorderStyleLabel = New System.Windows.Forms.Label()
        Me.controlBoxLabel = New System.Windows.Forms.Label()
        Me.label1 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.label3 = New System.Windows.Forms.Label()
        Me.label4 = New System.Windows.Forms.Label()
        Me.label5 = New System.Windows.Forms.Label()
        Me.label6 = New System.Windows.Forms.Label()
        Me.helpButtonLabel = New System.Windows.Forms.Label()
        Me.minimizeBoxLabel = New System.Windows.Forms.Label()
        Me.maximizeBoxLabel = New System.Windows.Forms.Label()
        Me.showInTaskBarLabel = New System.Windows.Forms.Label()
        Me.sizeGripStyleLabel = New System.Windows.Forms.Label()
        Me.label8 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'formBorderStyleLabel
        '
        Me.formBorderStyleLabel.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.formBorderStyleLabel.Location = New System.Drawing.Point(128, 36)
        Me.formBorderStyleLabel.Name = "formBorderStyleLabel"
        Me.formBorderStyleLabel.Size = New System.Drawing.Size(104, 23)
        Me.formBorderStyleLabel.TabIndex = 13
        Me.formBorderStyleLabel.Text = "label8"
        Me.formBorderStyleLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'controlBoxLabel
        '
        Me.controlBoxLabel.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.controlBoxLabel.Location = New System.Drawing.Point(128, 12)
        Me.controlBoxLabel.Name = "controlBoxLabel"
        Me.controlBoxLabel.Size = New System.Drawing.Size(104, 23)
        Me.controlBoxLabel.TabIndex = 10
        Me.controlBoxLabel.Text = "label7"
        Me.controlBoxLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(16, 12)
        Me.label1.Name = "label1"
        Me.label1.TabIndex = 8
        Me.label1.Text = "ControlBox"
        Me.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(16, 36)
        Me.label2.Name = "label2"
        Me.label2.TabIndex = 9
        Me.label2.Text = "FormBorderStyle"
        Me.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'label3
        '
        Me.label3.Location = New System.Drawing.Point(16, 60)
        Me.label3.Name = "label3"
        Me.label3.TabIndex = 7
        Me.label3.Text = "HelpButton"
        Me.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'label4
        '
        Me.label4.Location = New System.Drawing.Point(16, 84)
        Me.label4.Name = "label4"
        Me.label4.TabIndex = 4
        Me.label4.Text = "MinimizeBox"
        Me.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'label5
        '
        Me.label5.Location = New System.Drawing.Point(16, 108)
        Me.label5.Name = "label5"
        Me.label5.TabIndex = 3
        Me.label5.Text = "MaximizeBox"
        Me.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'label6
        '
        Me.label6.Location = New System.Drawing.Point(16, 132)
        Me.label6.Name = "label6"
        Me.label6.TabIndex = 6
        Me.label6.Text = "ShowInTaskBar"
        Me.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'helpButtonLabel
        '
        Me.helpButtonLabel.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.helpButtonLabel.Location = New System.Drawing.Point(128, 60)
        Me.helpButtonLabel.Name = "helpButtonLabel"
        Me.helpButtonLabel.Size = New System.Drawing.Size(104, 23)
        Me.helpButtonLabel.TabIndex = 14
        Me.helpButtonLabel.Text = "label8"
        Me.helpButtonLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'minimizeBoxLabel
        '
        Me.minimizeBoxLabel.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.minimizeBoxLabel.Location = New System.Drawing.Point(128, 84)
        Me.minimizeBoxLabel.Name = "minimizeBoxLabel"
        Me.minimizeBoxLabel.Size = New System.Drawing.Size(104, 23)
        Me.minimizeBoxLabel.TabIndex = 15
        Me.minimizeBoxLabel.Text = "label8"
        Me.minimizeBoxLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'maximizeBoxLabel
        '
        Me.maximizeBoxLabel.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.maximizeBoxLabel.Location = New System.Drawing.Point(128, 108)
        Me.maximizeBoxLabel.Name = "maximizeBoxLabel"
        Me.maximizeBoxLabel.Size = New System.Drawing.Size(104, 23)
        Me.maximizeBoxLabel.TabIndex = 16
        Me.maximizeBoxLabel.Text = "label8"
        Me.maximizeBoxLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'showInTaskBarLabel
        '
        Me.showInTaskBarLabel.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.showInTaskBarLabel.Location = New System.Drawing.Point(128, 132)
        Me.showInTaskBarLabel.Name = "showInTaskBarLabel"
        Me.showInTaskBarLabel.Size = New System.Drawing.Size(104, 23)
        Me.showInTaskBarLabel.TabIndex = 11
        Me.showInTaskBarLabel.Text = "label8"
        Me.showInTaskBarLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'sizeGripStyleLabel
        '
        Me.sizeGripStyleLabel.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.sizeGripStyleLabel.Location = New System.Drawing.Point(128, 156)
        Me.sizeGripStyleLabel.Name = "sizeGripStyleLabel"
        Me.sizeGripStyleLabel.Size = New System.Drawing.Size(104, 23)
        Me.sizeGripStyleLabel.TabIndex = 12
        Me.sizeGripStyleLabel.Text = "label8"
        Me.sizeGripStyleLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'label8
        '
        Me.label8.Location = New System.Drawing.Point(16, 156)
        Me.label8.Name = "label8"
        Me.label8.TabIndex = 5
        Me.label8.Text = "SizeGripStyle"
        Me.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(248, 190)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.formBorderStyleLabel, Me.controlBoxLabel, Me.label1, Me.label2, Me.label3, Me.label4, Me.label5, Me.label6, Me.helpButtonLabel, Me.minimizeBoxLabel, Me.maximizeBoxLabel, Me.showInTaskBarLabel, Me.sizeGripStyleLabel, Me.label8})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        controlBoxLabel.Text = Me.ControlBox.ToString()
        formBorderStyleLabel.Text = Me.FormBorderStyle.ToString()
        helpButtonLabel.Text = Me.HelpButton.ToString()
        maximizeBoxLabel.Text = Me.MaximizeBox.ToString()
        minimizeBoxLabel.Text = Me.MinimizeBox.ToString()
        showInTaskBarLabel.Text = Me.ShowInTaskbar.ToString()
        sizeGripStyleLabel.Text = Me.SizeGripStyle.ToString()
    End Sub
End Class
