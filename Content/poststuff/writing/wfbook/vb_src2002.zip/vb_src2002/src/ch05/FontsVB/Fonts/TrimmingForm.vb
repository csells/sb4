Imports System.Drawing
Imports System.Drawing.Text


Public Class TrimmingForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
        Me.Text = "TrimmingForm"
    End Sub

#End Region

    Private Sub TrimmingForm_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        Dim g As Graphics = e.Graphics
        Dim s As String = "a long string that could be trimmed any old place"
        Dim file As String = "C:\a\long\file\name\that\could\be\trimmed\any\old\place.ext"

        Dim trimmings As StringTrimming() = New StringTrimming() {StringTrimming.None, _
                                     StringTrimming.Character, _
                                     StringTrimming.EllipsisCharacter, _
                                     StringTrimming.Word, _
                                     StringTrimming.EllipsisWord, _
                                     StringTrimming.EllipsisPath}
        Dim y As Single = 0
        Dim format As StringFormat = New StringFormat()
        format.FormatFlags = StringFormatFlags.LineLimit

        Dim size As SizeF = g.MeasureString(StringTrimming.EllipsisCharacter.ToString(), Me.Font)
        format.SetTabStops(0, New Single() {size.Width + 10, 0})

        Dim trimming As StringTrimming
        For Each trimming In trimmings
            format.Trimming = trimming
            Dim line As String = trimming.ToString() & ":" & vbTab & s
            If trimming = StringTrimming.EllipsisPath Then
                line = trimming.ToString() & ":" & vbTab & file
            End If
            Dim rect As RectangleF = New RectangleF(0, y, Me.ClientRectangle.Width, Me.Font.GetHeight(g) * 1.5)
            g.DrawString(line, Me.Font, Brushes.Black, rect, format)
            y = y + Me.Font.GetHeight(g)
        Next
    End Sub
End Class
