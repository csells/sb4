Imports System.Drawing
Imports System.Drawing.Drawing2D

Public Class OutlineFontsForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'OutlineFontsForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(46, 109)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 72.0!)
        Me.Name = "OutlineFontsForm"
        Me.Text = "OutlineFontsForm"

    End Sub

#End Region


    Private Function GetStringPath(ByVal s As String, ByVal dpi As Single, ByVal rect As RectangleF, ByVal font As Font, ByVal format As StringFormat) As graphicspath
        Dim path As GraphicsPath = New GraphicsPath()
        Dim emSize As Single = dpi * font.SizeInPoints / 72
        path.AddString(s, font.FontFamily, CInt(font.Style), emSize, rect, format)
        Return path
    End Function


    Private Sub OutlineFontsForm_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        Dim g As Graphics = e.Graphics
        Dim s As String = "Outline"
        Dim rect As RectangleF = RectangleF.op_Implicit(Me.ClientRectangle)
        Dim font As Font = Me.Font
        Dim format As StringFormat = StringFormat.GenericTypographic
        Dim dpi As Single = g.DpiY
        Dim path As GraphicsPath = GetStringPath(s, dpi, rect, font, format)
        g.DrawPath(Pens.Black, path)
    End Sub
End Class
