Public Class TextContrastForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'TextContrastForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Name = "TextContrastForm"
        Me.Text = "TextContrastForm"

    End Sub

#End Region

    Private Sub TextContrastForm_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        Dim g As Graphics = e.Graphics
        Dim s As String = "Howdy, Partner"
        Dim format As StringFormat = New StringFormat()
        format.FormatFlags = StringFormatFlags.NoWrap
        Dim y As Single = 0
        Dim i As Integer
        For i = 0 To 12 Step 4
            g.TextContrast = i
            Dim line As String = "Contrast = " & i.ToString() & ": " & s
            g.DrawString(line, Me.Font, Brushes.Black, 0, y, format)
            y = y + Me.Font.GetHeight(g) + 10
        Next
    End Sub
End Class
