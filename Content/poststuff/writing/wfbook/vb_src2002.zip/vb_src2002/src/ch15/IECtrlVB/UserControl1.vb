Imports System
Imports System.Runtime.InteropServices
Imports System.Security
Imports System.Security.Permissions

Public Delegate Sub OuchCallback(ByVal degree As Integer)

<InterfaceType(ComInterfaceType.InterfaceIsIDispatch)> _
Public Interface IOuchEvents
    <DispId(1)> Sub OuchEvent(ByVal degree As Integer)
End Interface

<ComSourceInterfaces(GetType(IOuchEvents))> _
Public Class UserControl1
    Inherits System.Windows.Forms.UserControl

    Private prefix As String = ""

    Public Event OuchEvent As OuchCallback

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'UserControl1 overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents groupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents label1 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.groupBox1 = New System.Windows.Forms.GroupBox()
        Me.label1 = New System.Windows.Forms.Label()
        Me.groupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'groupBox1
        '
        Me.groupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.label1})
        Me.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.groupBox1.Name = "groupBox1"
        Me.groupBox1.Size = New System.Drawing.Size(150, 150)
        Me.groupBox1.TabIndex = 1
        Me.groupBox1.TabStop = False
        Me.groupBox1.Text = "groupBox1"
        '
        'label1
        '
        Me.label1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.label1.Location = New System.Drawing.Point(3, 16)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(144, 131)
        Me.label1.TabIndex = 1
        Me.label1.Text = "Click me!"
        Me.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'UserControl1
        '
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.groupBox1})
        Me.Name = "UserControl1"
        Me.groupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region


    Public Sub SaySomething(ByVal something As String)
        MessageBox.Show(prefix & something)
    End Sub

    Public Function HavePermission(ByVal perm As IPermission) As Boolean
        Try
            perm.Demand()
        Catch ex As SecurityException
            Return False
        End Try

        Return True

    End Function

    Private Sub label1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles label1.Click
        ' Make sure we have permission to call unmanaged code
        Dim flag As SecurityPermissionFlag = SecurityPermissionFlag.UnmanagedCode
        Dim perm As SecurityPermission = New SecurityPermission(flag)
        If Not HavePermission(perm) Then Exit Sub

        ' Grant managed hosting code permission to call unamanged code
        perm.Assert()
        RaiseEvent OuchEvent(10)
    End Sub

    Public Property SomethingPrefix() As String
        Get
            Return prefix
        End Get
        Set(ByVal Value As String)
            prefix = Value
        End Set
    End Property
End Class
