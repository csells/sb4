' WebCommandLineHelper.cs: Contributed by Chris Sells
' Inspired by Rob Macdonald [rob@SALTERTON.COM]

#Region "Copyright � 2002 The Genghis Group"

'* This software is provided 'as-is', without any express or implied warranty.
'* In no event will the authors be held liable for any damages arising from the
'* use of this software.
'*
'* Permission is granted to anyone to use this software for any purpose,
'* including commercial applications, subject to the following restrictions:
'*
'* 1. The origin of this software must not be misrepresented; you must not claim
'* that you wrote the original software. If you use this software in a product,
'* an acknowledgment in the product documentation is required, as shown here:
'*
'* Portions copyright � 2002 The Genghis Group (http://www.genghisgroup.com/).
'*
'* 2. No substantial portion of the source code of this library may be redistributed
'* without the express written permission of the copyright holders, where
'* "substantial" is defined as enough code to be recognizably from this library.

#End Region
#Region "Features"
' This class is meant to be used to hide the difference between command line args
' when the app is launched locally via the shell or when it's launched remotely
' via an URL.
#End Region
#Region "Limitations"
' -Requires EnvironmentPermission.
' -Should catch exceptions when permissions not present?
#End Region
#Region "Usage"

'Class App
'{
'    // Can be launched as EXE, e.g. foo.exe one two three
'    // Can be launched as URL, e.g. http://localhost/foo/foo.exe?one%20two%20three
'    static void Main(string[] args)
'    {
'        args = WebCommandLineHelper.CommandLineArgs(args);

'        string argstring = "";
'        foreach( string arg in args ) argstring += arg + "\r\n";
'        MessageBox.Show(argstring, "Args from " + (WebCommandLineHelper.LaunchedFromUrl ? "URL" : "EXE"));
'    }
'}

#End Region
#Region "History"
' 11/1/02:
' -Updated by Chris Sells [csells@sellsbrothers.com] to use be configurable
'  to use client-side arguments via the # symbol as well as of server-side
'  arguments via the ? symbol. Also updated to stop parsing arguments like
'  they were server-side, no splitting of arguments separated by & symbols.
'  Instead, it splits args based on quotes and spaces, like a command line.
'
' 10/1/02:
'  -Updated by Chris Sells [csells@sellsbrothers.com] to fix the current
'   AppDomain's APP_CONFIG_FILE to exclude URL arguments, otherwise the
'   custom .config appsettings can't be obtained, because the APP_CONFIG_FILE
'   variable is pre-loaded to include the entire URL, include the args.
'   This fix was inspired by Dave Thorson [davethorson@attbi.com]. Thanks, Dave!
#End Region


Imports System
Imports System.Web
Imports System.Security
Imports System.Diagnostics
Imports System.Collections
Imports System.Text

Namespace Genghis.Web
    Public Class WebCommandLineHelper
        Public Shared Function Empty(ByVal s As String) As String
            Return s Is Nothing Or s.Length = 0
        End Function

        Shared separationChar As Char = "?"
        Public Shared Property SeparationCharacter() As Char
            Get
                Return separationChar
            End Get
            Set(ByVal Value As Char)
                separationChar = Value
            End Set
        End Property

        Public Shared ReadOnly Property LaunchedFromUrl() As Boolean
            Get
                Try
                    ' Check if we have a site
                    Dim url As String = CStr(AppDomain.CurrentDomain.GetData("APPBASE"))
                    System.Security.Policy.Site.CreateFromUrl(url)
                    Return True
                Catch ae As ArgumentException
                    Return False
                End Try
            End Get
        End Property

        ' NOTE: This depends on where ieexec.exe usage
        Public Shared Function GetLaunchUrlWithArgs() As String
            Dim cl As String() = Environment.GetCommandLineArgs()
            Debug.Assert(cl(0).ToLower().IndexOf("\ieexec") <> -1)
            If cl.Length > 1 Then Return HttpUtility.UrlDecode(cl(1))
            Return Nothing
        End Function

        Public Shared Function GetLaunchUrlNoArgs() As String
            Dim url As String = GetLaunchUrlWithArgs()
            If Empty(url) Then Return Nothing
            Dim delimiter As Integer = url.IndexOf(separationChar)
            If delimiter < 0 Then Return url
            Return url.Substring(0, delimiter)
        End Function

        Public Shared Function GetLaunchUrlOnlyArgs() As String
            Dim url As String = GetLaunchUrlWithArgs()
            If Empty(url) Then Return Nothing
            Dim delim As Integer = url.IndexOf(separationChar)
            If delim < 0 Then Return Nothing
            Return url.Substring(delim + 1)
        End Function

        Public Shared Sub EnableUrlCommandLineArgs()
            ' NOTE: If an URL used to launch an EXE has arguments, those
            ' arguments will make their way into the AppDomain's AppPath,
            ' screwing all kinds of things up, e.g. finding the EXE's .config
            ' file. Make sure to call this function *before* executing code
            ' that relies on the AppPath, e.g. pulling items from the .config
            ' file or pulling in referenced assemblies.
            AppDomain.CurrentDomain.SetData("APP_CONFIG_FILE", GetLaunchUrlNoArgs() & ".config")
        End Sub

        Public Shared Function CommandLineArgs(ByVal argsFromMain As String()) As String()
            Return CommandLineArgs(argsFromMain, True)
        End Function

        Public Shared Function IsWhiteSpace(ByVal ch As Char) As Boolean
            Return ch = " " Or ch = vbTab Or ch = vbCr Or ch = vbLf Or ch = vbCrLf
        End Function

        Public Shared Function CommandLineArgs(ByVal argsfrommain As String(), ByVal benableUrlCommandLineArgs As Boolean) As String()
            If Not LaunchedFromUrl Then Return argsfrommain

            ' NOTE: Fix issues w/ passing command line args via an URL
            If benableUrlCommandLineArgs Then EnableUrlCommandLineArgs()

            Dim argList As ArrayList = New ArrayList()
            Dim currParam As StringBuilder = New StringBuilder()
            Dim inQuotes As Boolean = False
            Dim argString As String = GetLaunchUrlOnlyArgs()
            If Empty(argString) Then
                Dim emptystrings As String()
                Return emptystrings
            End If

            ' Parse paramters looking for quotes
            Dim ch As Char
            For Each ch In argString
                If ch = """" Then
                    inQuotes = Not inQuotes
                ElseIf IsWhiteSpace(ch) And Not inQuotes Then
                    If currParam.Length <> 0 Then
                        argList.Add(currParam.ToString())
                        currParam = New StringBuilder()
                    End If
                Else
                    currParam.Append(ch)
                End If
            Next

            ' Get last parameter
            If currParam.Length <> 0 Then argList.Add(currParam.ToString())

            Return CType(argList.ToArray(GetType(String)), String())

        End Function

    End Class

End Namespace

