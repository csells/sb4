Public Class App
    ' Can be launched as EXE, e.g. foo.exe one two three
    ' Can be launched as URL, e.g. http://localhost/foo/foo.exe?one%20two%20three
    Shared Sub Main(ByVal args As String())

    End Sub

End Class
