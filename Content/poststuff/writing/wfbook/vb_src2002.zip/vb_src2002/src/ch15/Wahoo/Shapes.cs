using System;
using System.Drawing;
using System.Collections;
using System.Diagnostics;

namespace Wahoo
{
	abstract class Shape
	{
        protected Shape(Game game, Color color, Position[] positions)
        {
            _game = game;
            _color = color;
            _positions = positions;
        }

        public void Draw(Graphics g)
        {
            _positions[_position].Draw(_game, g, _color, _row, _col);
        }

        public int Row
        {
            get { return _row; }
        }

        public int Column
        {
            get { return _col; }
        }

        public int Width
        {
            get { return _positions[_position].Width; }
        }

        public int Height
        {
            get { return _positions[_position].Height; }
        }

        public Color Color
        {
            get { return _color; }
        }

        public bool CellFilled(int row, int col)
        {
            return _positions[_position].CellFilled(row, col);
        }

        public bool Down()
        {
            // Check if one more move will put us below the bottom
            if( _row + Height + 1 > _game.Rows ) return false;

            // Check for collisions
            if( Collides(_row + 1, _col) ) return false;

            // Move down a row
            ++_row;
            return true;
        }

        public bool Left()
        {
            // Check if one more move right will put us beyond the edge
            if( _col - 1 < 0 ) return false;

            // Check for collisions
            if( Collides(_row, _col - 1) ) return false;

            // Move over one column
            --_col;
            return true;
        }

        public bool Right()
        {
            // Check if one more move right will put us beyond the edge
            if( _col + Width + 1 > _game.Columns ) return false;

            // Check for collisions
            if( Collides(_row, _col + 1) ) return false;

            // Move over one column
            ++_col;
            return true;
        }

        private bool Rotate(int dir)
        {
            int newPosition = _position + dir;
            if( newPosition >= _positions.Length ) newPosition -= _positions.Length;
            else if( newPosition < 0 ) newPosition += _positions.Length;

            // Can't rotate if it would collide
            if( Collides(_row, _col, newPosition) ) return false;
    
            _position = newPosition;
            return true;
        }

        public bool RotateLeft()
        {
            return Rotate(-1);
        }

        public bool RotateRight()
        {
            return Rotate(1);
        }

        protected bool Collides(int row, int col)
        {
            return Collides(row, col, _position);
        }

        protected bool Collides(int row, int col, int position)
        {
            return _positions[position].Collides(_game, row, col);
        }

        protected Game          _game;
        protected Color         _color;
        protected int           _row = 0;
        protected int           _col = 0;
        protected int           _position = 0;
        protected Position[]    _positions;

        protected class Position
        {
            public Position(params string[] masks)
            {
                _masks = new BitArray[masks.Length];
                for( int i = 0; i != masks.Length; ++i )
                {
                    _masks[i] = new BitArray(masks[i].Length);
                    for( int j = 0; j != masks[i].Length; ++j )
                    {
                        switch( masks[i][j] )
                        {
                            case '0': /* bit already set to false */ break;
                            case '1': _masks[i][j] = true; break;
                            default: Debug.Assert(false, "Only 0s and 1s accepted in bitmasks"); break;
                        }
                    }
                }
            }

            public void Draw(Game game, Graphics g, Color color, int rowOffset, int colOffset)
            {
                for( int row = 0; row != _masks.Length; ++row )
                {
                    for( int col = 0; col != _masks[row].Length; ++col )
                    {
                        if( _masks[row][col] )
                        {
                            game.DrawCell(g, color, row + rowOffset, col + colOffset);
                        }
                    }
                }
            }

            public bool Collides(Game game, int rowOffset, int colOffset)
            {
                for( int row = 0; row != _masks.Length; ++row )
                {
                    for( int col = 0; col != _masks[row].Length; ++col )
                    {
                        // If mask is set at this position and cell is filled, that's a collision
                        if( _masks[row][col] && game.CellFilled(row + rowOffset, col + colOffset) ) return true;
                    }
                }

                return false;
            }

            public bool CellFilled(int row, int col)
            {
                return _masks[row][col];
            }

            public int Width
            {
                get { return _masks[0].Length; }
            }

            public int Height
            {
                get { return _masks.Length; }
            }

            private BitArray[]  _masks;
        }
    }

    class ShapeT : Shape
    {
        public ShapeT(Game game) :
            base(game,
                 Color.Red,
                 new Position[] {
                                    new Position("010",
                                                 "111"),

                                    new Position("10",
                                                 "11",
                                                 "10"),

                                    new Position("111",
                                                 "010"),

                                    new Position("01",
                                                 "11",
                                                 "01"),
                                })
        {
        }
    }

    class ShapeCrook1 : Shape
    {
        public ShapeCrook1(Game game) :
            base(game,
                 Color.Green,
                 new Position[] {
                                    new Position("110",
                                                 "011"),

                                    new Position("01",
                                                 "11",
                                                 "10")
                                    })
        {
        }
    }

    class ShapeCrook2 : Shape
    {
        public ShapeCrook2(Game game) :
            base(game,
                 Color.Navy,
                 new Position[] {
                                    new Position("011",
                                                 "110"),

                                    new Position("10",
                                                 "11",
                                                 "01")
                                    })
        {
        }
    }

    class ShapeL1 : Shape
    {
        public ShapeL1(Game game) :
            base(game,
                 Color.Blue,
                 new Position[] {
                                    new Position("001",
                                                 "111"),

                                    new Position("10",
                                                 "10",
                                                 "11"),

                                    new Position("111",
                                                 "100"),

                                    new Position("11",
                                                 "01",
                                                 "01")
                                    })
        {
        }
    }

    class ShapeL2 : Shape
    {
        public ShapeL2(Game game) :
            base(game,
                 Color.Aqua,
                 new Position[] {
                                    new Position("100",
                                                 "111"),

                                    new Position("11",
                                                 "10",
                                                 "10"),

                                    new Position("111",
                                                 "001"),

                                    new Position("01",
                                                 "01",
                                                 "11")
                                    })
        {
        }
    }

    class ShapeLine : Shape
    {
        public ShapeLine(Game game) :
            base(game,
                 Color.Purple,
                 new Position[] {
                                    new Position("1111"),

                                    new Position("1",
                                                 "1",
                                                 "1",
                                                 "1")
                                    })
        {
        }
    }

    class ShapeBox : Shape
    {
        public ShapeBox(Game game) :
            base(game,
                 Color.Lime,
                 new Position[] {
                                    new Position("11",
                                                 "11")
                                    })
        {
        }
    }
}















