using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Caching;
using System.Web.Services;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Soap;
using System.Web.Services.Protocols;
using System.Xml;

namespace WahooScores
{
    /// <summary>
    /// Track Wahoo scores
    /// </summary>
    [WebService(Namespace="http://sellsbrothers.com/WahooScoresService/")]
    public class WahooScoresService : System.Web.Services.WebService, IDisposable
    {
        [Serializable]
        public struct WahooScore
        {
            public WahooScore(string name, int score) { Name = name; Score = score; }

            public string  Name;
            public int     Score;
        }

        private class ScoreSorter : IComparer
        {
            #region Implementation of IComparer
            public int Compare(object x, object y)
            {
                WahooScore  score1 = (WahooScore)x;
                WahooScore  score2 = (WahooScore)y;
                if( score1.Score < score2.Score ) return 1;
                else if( score1.Score > score2.Score ) return -1;
                else return 0;
            }
        
            #endregion
        }

        // Avoid exposing implementation details in Release mode
        private class DiscreetSoapException : SoapException
        {
            public DiscreetSoapException(string fault) :
                this(fault, "Server", "http://schemas.xmlsoap.org/soap/envelope/")
            {
            }

            public DiscreetSoapException(string fault, string faultCode) :
                this(fault, faultCode, "http://schemas.xmlsoap.org/soap/envelope/")
            {
            }

            public DiscreetSoapException(string fault, string faultCode, string faultNamespace) :
                base(fault, new XmlQualifiedName(faultCode, faultNamespace))
            {
            }

            // Turn off the munging that SoapExpection does to expose implementation details
            // in the SOAP faultstring. That's great when we're in debug mode, but in release
            // mode, we shouldn't expose such details.
            // NOTE: We could also turn SoapExceptions faultstring munging off by turning
            // custom errors on in the web.config file:
            // <system.web><customErrors mode="On" /></system.web>
            public override string ToString()
            {
#if DEBUG
                return base.ToString();
#else
                return Message;
#endif
            }
        }


        static WahooScoresService()
        {
            // Load cached high scores
            LoadScores();
        }

        public WahooScoresService()
        {
            //CODEGEN: This call is required by the ASP.NET Web Services Designer
            InitializeComponent();
        }

        // Score storage
        // NOTE: This implementation requires a user with permissions to read/write files, e.g.
        // machine.config:
        // <system.web><processModel userName="SYSTEM" ... />...</system.web>
        #region

        static private string ScoresFileName
        {
            get
            {
                return HttpContext.Current.Request.PhysicalApplicationPath + @"datastore\WahooScores.txt";
            }
        }

        static private WahooScore[] LoadScores()
        {
            WahooScore[]    scores = new WahooScore[_maxScores];

            try
            {
                using( FileStream file = new FileStream(ScoresFileName, FileMode.Open) )
                {
                    IFormatter  formatter = new SoapFormatter();
                    scores = (WahooScore[])formatter.Deserialize(file);
                }
            }
            catch
            {
                for( int i = 0; i != _maxScores; ++i )
                {
                    scores[i] = new WahooScore("nobody", 0);
                }
            }

            return scores;
        }

        private void SaveScores(WahooScore[] scores)
        {
            using( FileStream file = new FileStream(ScoresFileName, FileMode.Create) )
            {
                IFormatter  formatter = new SoapFormatter();
                formatter.Serialize(file, scores);
            }
        }
        #endregion

		#region Component Designer generated code
		
        //Required by the Web Services Designer 
        private IContainer components = null;
				
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        private void InitializeComponent()
        {
        }

        /// Clean up any resources being used.
        protected override void Dispose( bool disposing )
        {
            if(disposing && components != null)
            {
                components.Dispose();
            }

            base.Dispose(disposing);		
        }
		
		#endregion

        /// <summary>
        /// Store a new high score
        /// </summary>
        [WebMethod]
        public void RegisterScore(string name, int score)
        {
            HttpContext context = HttpContext.Current;
            Cache       cache = context.Cache;

            try
            {
                // Synchronize access to the scores
                context.Application.Lock();

                WahooScore[]    scores = GetScores();

                // Check to see if score makes the cut
                if( scores[_maxScores - 1].Score >= score )
                {
                    //throw new ApplicationException("Sorry, but your score is too low to make the top " + _maxScores);
                    throw new DiscreetSoapException("Sorry, " + name + ", but your score of " + score + " is too low to make the top " + _maxScores);
                }

                // Add score by bumping off the bottom guy
                scores[_maxScores - 1] = new WahooScore(name, score);

                // Sort list
                Array.Sort(scores, new ScoreSorter());

                // Save high scores now in case bad stuff happens later
                SaveScores(scores);

                // Cache the scores
                cache["scores"] = scores;
            }
            finally
            {
                context.Application.UnLock();
            }
        }
    
        /// <summary>
        /// Return scores sorted highest to lowest
        /// </summary>
        [WebMethod]
        public WahooScore[] GetScores()
        {
            Cache           cache = HttpContext.Current.Cache;
            WahooScore[]    scores;
            
            try
            {
                HttpContext.Current.Application.Lock();

                scores = (WahooScore[])cache["scores"];
                if( scores == null )
                {
                    cache["scores"] = scores = LoadScores();
                }
            }
            finally
            {
                HttpContext.Current.Application.UnLock();
            }

            return scores;
        }

        // Only keep the big ones
        const byte  _maxScores = 10;
    }
}













