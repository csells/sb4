Imports System.Drawing
Imports System.Drawing.Drawing2D

Public Class SkewingForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents upButton As System.Windows.Forms.Button
    Friend WithEvents panel1 As System.Windows.Forms.Panel
    Friend WithEvents downButton As System.Windows.Forms.Button
    Friend WithEvents leftButton As System.Windows.Forms.Button
    Friend WithEvents rightButton As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.upButton = New System.Windows.Forms.Button()
        Me.panel1 = New System.Windows.Forms.Panel()
        Me.downButton = New System.Windows.Forms.Button()
        Me.leftButton = New System.Windows.Forms.Button()
        Me.rightButton = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'upButton
        '
        Me.upButton.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.upButton.Location = New System.Drawing.Point(132, 10)
        Me.upButton.Name = "upButton"
        Me.upButton.Size = New System.Drawing.Size(24, 23)
        Me.upButton.TabIndex = 5
        Me.upButton.Text = "^"
        '
        'panel1
        '
        Me.panel1.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panel1.Location = New System.Drawing.Point(36, 43)
        Me.panel1.Name = "panel1"
        Me.panel1.Size = New System.Drawing.Size(216, 184)
        Me.panel1.TabIndex = 2
        '
        'downButton
        '
        Me.downButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.downButton.Location = New System.Drawing.Point(132, 234)
        Me.downButton.Name = "downButton"
        Me.downButton.Size = New System.Drawing.Size(24, 23)
        Me.downButton.TabIndex = 6
        Me.downButton.Text = "v"
        '
        'leftButton
        '
        Me.leftButton.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.leftButton.Location = New System.Drawing.Point(6, 124)
        Me.leftButton.Name = "leftButton"
        Me.leftButton.Size = New System.Drawing.Size(24, 23)
        Me.leftButton.TabIndex = 3
        Me.leftButton.Text = "<"
        '
        'rightButton
        '
        Me.rightButton.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.rightButton.Location = New System.Drawing.Point(262, 124)
        Me.rightButton.Name = "rightButton"
        Me.rightButton.Size = New System.Drawing.Size(24, 23)
        Me.rightButton.TabIndex = 4
        Me.rightButton.Text = ">"
        '
        'SkewingForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.upButton, Me.panel1, Me.downButton, Me.leftButton, Me.rightButton})
        Me.Name = "SkewingForm"
        Me.Text = "SkewingForm"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Dim bmp As Bitmap = New Bitmap("C:\windows\soap bubbles.bmp")
    Dim offset As Size = New Size(0, 0)

    Private Sub panel1_Paint(ByVal sender As Object, ByVal e As PaintEventArgs) Handles panel1.Paint
        Dim g As Graphics = e.Graphics
        Dim rect As Rectangle = Me.panel1.ClientRectangle
        Dim points As Point() = New Point() { _
            New Point(rect.Left + offset.Width, rect.Top + offset.Height), _
            New Point(rect.Right, rect.Top + offset.Height), _
            New Point(rect.Left, rect.Bottom - offset.Height)}
        g.DrawImage(bmp, points)
    End Sub

    Private Sub upButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles upButton.Click
        offset.Height = offset.Height + 10
        panel1.Refresh()
    End Sub


    Private Sub leftButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles leftButton.Click
        offset.Width = offset.Width - 10
        panel1.Refresh()
    End Sub

    Private Sub downButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles downButton.Click
        offset.Height = offset.Height - 10
        panel1.Refresh()
    End Sub

    Private Sub rightButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rightButton.Click
        offset.Width = offset.Width + 10
        panel1.Refresh()
    End Sub
End Class
