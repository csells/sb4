Public Class MainForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents button2 As System.Windows.Forms.Button
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents button3 As System.Windows.Forms.Button
    Friend WithEvents button4 As System.Windows.Forms.Button
    Friend WithEvents button5 As System.Windows.Forms.Button
    Friend WithEvents button6 As System.Windows.Forms.Button
    Friend WithEvents button7 As System.Windows.Forms.Button
    Friend WithEvents button8 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.button2 = New System.Windows.Forms.Button()
        Me.button1 = New System.Windows.Forms.Button()
        Me.button3 = New System.Windows.Forms.Button()
        Me.button4 = New System.Windows.Forms.Button()
        Me.button5 = New System.Windows.Forms.Button()
        Me.button6 = New System.Windows.Forms.Button()
        Me.button7 = New System.Windows.Forms.Button()
        Me.button8 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'button2
        '
        Me.button2.Location = New System.Drawing.Point(15, 44)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(112, 23)
        Me.button2.TabIndex = 7
        Me.button2.Text = "Panning"
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(15, 12)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(112, 23)
        Me.button1.TabIndex = 2
        Me.button1.Text = "Scaling vs. Clipping"
        '
        'button3
        '
        Me.button3.Location = New System.Drawing.Point(15, 76)
        Me.button3.Name = "button3"
        Me.button3.Size = New System.Drawing.Size(112, 23)
        Me.button3.TabIndex = 8
        Me.button3.Text = "Skewing"
        '
        'button4
        '
        Me.button4.Location = New System.Drawing.Point(15, 108)
        Me.button4.Name = "button4"
        Me.button4.Size = New System.Drawing.Size(112, 23)
        Me.button4.TabIndex = 9
        Me.button4.Text = "Re-Coloring"
        '
        'button5
        '
        Me.button5.Location = New System.Drawing.Point(15, 140)
        Me.button5.Name = "button5"
        Me.button5.Size = New System.Drawing.Size(112, 23)
        Me.button5.TabIndex = 6
        Me.button5.Text = "Transparency"
        '
        'button6
        '
        Me.button6.Location = New System.Drawing.Point(15, 172)
        Me.button6.Name = "button6"
        Me.button6.Size = New System.Drawing.Size(112, 23)
        Me.button6.TabIndex = 3
        Me.button6.Text = "Animation"
        '
        'button7
        '
        Me.button7.Location = New System.Drawing.Point(15, 204)
        Me.button7.Name = "button7"
        Me.button7.Size = New System.Drawing.Size(112, 23)
        Me.button7.TabIndex = 4
        Me.button7.Text = "Drawing to Images"
        '
        'button8
        '
        Me.button8.Location = New System.Drawing.Point(15, 236)
        Me.button8.Name = "button8"
        Me.button8.Size = New System.Drawing.Size(112, 23)
        Me.button8.TabIndex = 5
        Me.button8.Text = "Icons"
        '
        'MainForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(142, 270)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.button2, Me.button1, Me.button3, Me.button4, Me.button5, Me.button6, Me.button7, Me.button8})
        Me.Name = "MainForm"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        Dim scf As ScalingClippingForm = New ScalingClippingForm()
        scf.ShowDialog()
    End Sub

    Private Sub button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button3.Click
        Dim sf As SkewingForm = New SkewingForm()
        sf.ShowDialog()
    End Sub

    Private Sub button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button4.Click
        Dim rf As RecoloringForm = New RecoloringForm()
        rf.ShowDialog()
    End Sub

    Private Sub button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button5.Click
        Dim tf As TransparencyForm = New TransparencyForm()
        tf.ShowDialog()
    End Sub

    Private Sub button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button6.Click
        Dim af As AnimationForm = New AnimationForm()
        af.ShowDialog()
    End Sub

    Private Sub button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button7.Click
        Dim dtif As DrawingToImagesForm = New DrawingToImagesForm()
        dtif.ShowDialog()
    End Sub

    Private Sub button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button8.Click
        Dim icf As IconsForm = New IconsForm()
        icf.ShowDialog()
    End Sub

    Private Sub button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button2.Click
        Dim pf As PanningForm = New PanningForm()
        pf.ShowDialog()
    End Sub
End Class
