Imports System.Drawing
Imports System.Drawing.Drawing2D

Public Class AlignmentsForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
        Me.Text = "AlignmentsForm"
    End Sub

#End Region


    Private Sub AlignmentsForm_Paint(ByVal sender As Object, ByVal e As PaintEventArgs) Handles MyBase.Paint
        Dim g As Graphics = e.Graphics
        Dim alignNames As String() = System.Enum.GetNames(GetType(PenAlignment))
        Array.Sort(alignNames)

        Dim x As Integer = 0
        Dim y As Integer = 0
        Dim width As Integer = Me.ClientRectangle.Width
        Dim height As Integer = Me.ClientRectangle.Height
        Dim blackBrush As Brush = Brushes.Black
        Dim redPen As Pen = Pens.Red

        Dim alignName As String
        For Each alignName In alignNames
            Dim pen As Pen = New Pen(Color.White, 13)
            If Not (pen.Alignment <> PenAlignment.Center And pen.Alignment <> PenAlignment.Inset) Then
                g.DrawEllipse(pen, x + 10, y + 10, width - 20, height - 20)
                g.DrawEllipse(redPen, x + 10, y + 10, width - 20, height - 20)
                Dim format As StringFormat = New StringFormat()
                format.Alignment = StringAlignment.Center
                format.LineAlignment = StringAlignment.Center
                g.DrawString(alignName, Me.Font, blackBrush, New RectangleF(x, y, width, height), format)
                y = y + height
            End If
        Next
    End Sub
End Class
