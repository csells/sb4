Imports System.Drawing
Imports System.Drawing.Drawing2D

Public Class TextureBrushesForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
        Me.Text = "TextureBrushesForm"
    End Sub

#End Region

    Private Sub TextureBrushesForm_Paint(ByVal sender As Object, ByVal e As PaintEventArgs) Handles MyBase.Paint
        Dim g As Graphics = e.Graphics
        Dim x As Integer = 0
        Dim y As Integer = 0
        Dim width As Integer = Me.ClientRectangle.Width
        Dim height As Integer = Me.ClientRectangle.Height / 6
        Dim blackBrush As Brush = Brushes.Black
        Dim blackPen As Pen = Pens.Black
        Dim file As String = "C:\Program Files\Microsoft Visual Studio .NET\Common7\Graphics\bitmaps\assorted\BEANY.BMP"

        Dim b As Brush = New TextureBrush(New Bitmap(file), Drawing.Drawing2D.WrapMode.Clamp)
        g.FillRectangle(b, x, y, width, height)
        g.DrawRectangle(blackPen, x, y, width, height)
        g.DrawString(CType(b, TextureBrush).WrapMode.ToString(), Me.Font, blackBrush, x, y)
        y = y + height

        b = New TextureBrush(New Bitmap(file), Drawing.Drawing2D.WrapMode.Tile)
        g.FillRectangle(b, x, y, width, height)
        g.DrawRectangle(blackPen, x, y, width, height)
        g.DrawString(CType(b, TextureBrush).WrapMode.ToString(), Me.Font, blackBrush, x, y)
        y = y + height

        b = New TextureBrush(New Bitmap(file), Drawing.Drawing2D.WrapMode.TileFlipX)
        g.FillRectangle(b, x, y, width, height)
        g.DrawRectangle(blackPen, x, y, width, height)
        g.DrawString(CType(b, TextureBrush).WrapMode.ToString(), Me.Font, blackBrush, x, y)
        y = y + height

        b = New TextureBrush(New Bitmap(file), Drawing.Drawing2D.WrapMode.TileFlipY)
        g.FillRectangle(b, x, y, width, height)
        g.DrawRectangle(blackPen, x, y, width, height)
        g.DrawString(CType(b, TextureBrush).WrapMode.ToString(), Me.Font, blackBrush, x, y)
        y = y + height

        b = New TextureBrush(New Bitmap(file), Drawing.Drawing2D.WrapMode.TileFlipXY)
        g.FillRectangle(b, x, y, width, height * 2)
        g.DrawRectangle(blackPen, x, y, width, height * 2)
        g.DrawString(CType(b, TextureBrush).WrapMode.ToString(), Me.Font, blackBrush, x, y)
        y = y + height

    End Sub

End Class
