Imports System.Drawing
Imports System.Drawing.Imaging

Public Class DrawingToImagesForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents saveButton As System.Windows.Forms.Button
    Friend WithEvents panel1 As System.Windows.Forms.Panel
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.saveButton = New System.Windows.Forms.Button()
        Me.panel1 = New System.Windows.Forms.Panel()
        Me.SuspendLayout()
        '
        'saveButton
        '
        Me.saveButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.saveButton.Location = New System.Drawing.Point(104, 238)
        Me.saveButton.Name = "saveButton"
        Me.saveButton.TabIndex = 3
        Me.saveButton.Text = "Save"
        '
        'panel1
        '
        Me.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.panel1.Name = "panel1"
        Me.panel1.Size = New System.Drawing.Size(292, 224)
        Me.panel1.TabIndex = 2
        '
        'DrawingToImagesForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.saveButton, Me.panel1})
        Me.Name = "DrawingToImagesForm"
        Me.Text = "DrawingToImagesForm"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Dim offset As Integer

    Private Sub saveButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles saveButton.Click
        Dim rect As Rectangle = New Rectangle(0, 0, 100, 100)
        Dim displayGraphics As Graphics = Me.CreateGraphics()
        Dim img As Image = New Bitmap(rect.Width, rect.Height, displayGraphics)
        Dim imageGraphics As Graphics = Graphics.FromImage(img)
        imageGraphics.FillRectangle(Brushes.Black, rect)
        Dim format As StringFormat = New StringFormat()
        format.Alignment = StringAlignment.Center
        format.LineAlignment = StringAlignment.Center
        imageGraphics.DrawString("Drawing to an image", panel1.Font, Brushes.White, RectangleF.op_Implicit(rect), format)
        Dim file As String = "C:\temp\image.png"
        img.Save(file)

        MessageBox.Show("Saved to file: " & file)

    End Sub
    Private Sub panel1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles panel1.Paint
        Dim g As Graphics = e.Graphics
        Dim rect As Rectangle = Me.panel1.ClientRectangle
        Dim img As Image = New Bitmap(rect.Width, rect.Height, g)
        Dim imageGraphics As Graphics = Graphics.FromImage(img)
        imageGraphics.FillRectangle(Brushes.White, rect)
        Dim format As StringFormat = New StringFormat()
        format.Alignment = StringAlignment.Center
        format.LineAlignment = StringAlignment.Center
        imageGraphics.DrawString("Drawing to an image", panel1.Font, Brushes.Black, RectangleF.op_Implicit(rect), format)
        g.DrawImage(img, rect)
    End Sub

    Private Sub DrawingToImagesForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        offset = Me.ClientRectangle.Height - Me.panel1.Height
    End Sub

    Private Sub DrawingToImagesForm_Layout(ByVal sender As Object, ByVal e As LayoutEventArgs) Handles MyBase.Layout
        Me.panel1.Height = Me.ClientRectangle.Height - offset
    End Sub
End Class
