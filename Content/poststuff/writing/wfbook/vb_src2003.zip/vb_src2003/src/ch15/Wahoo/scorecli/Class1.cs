using System;
using System.Text;
using scorecli.localhost;
using System.Web.Services.Protocols;
using System.Xml;

class App
{
    static void DumpScores(WahooScore[] scores)
    {
        StringBuilder    sb = new StringBuilder();
        for( int i = 0; i != Math.Min(scores.Length, 10); ++i )
        {
            sb.AppendFormat("{0}.\t{1}\t{2}\r\n", i + 1, scores[i].Score, scores[i].Name);
        }

        Console.Write(sb.ToString());
    }

    static void Main(string[] args)
    {

        WahooScoresService  service = new WahooScoresService();
        //service.Url = "http://localhost:8080/WahooScores/WahooScores.asmx";

        try
        {
            DumpScores(service.GetScores());
            service.RegisterScore("three", 3000);
            service.RegisterScore("six", 6000);
            service.RegisterScore("two", 2000);
            service.RegisterScore("four", 4000);
            service.RegisterScore("one", 1000);
            service.RegisterScore("eight", 8000);
            service.RegisterScore("five", 5000);
            service.RegisterScore("seven", 7000);
            service.RegisterScore("nine", 9000);
            DumpScores(service.GetScores());
            service.RegisterScore("zero", 0);
        }
        catch( SoapException e )
        {
            Console.WriteLine(e.Message);
        }
    }
}