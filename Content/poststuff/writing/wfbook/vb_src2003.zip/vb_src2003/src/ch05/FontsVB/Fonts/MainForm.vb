Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents button2 As System.Windows.Forms.Button
    Friend WithEvents button3 As System.Windows.Forms.Button
    Friend WithEvents button4 As System.Windows.Forms.Button
    Friend WithEvents button5 As System.Windows.Forms.Button
    Friend WithEvents button6 As System.Windows.Forms.Button
    Friend WithEvents button7 As System.Windows.Forms.Button
    Friend WithEvents button8 As System.Windows.Forms.Button
    Friend WithEvents button9 As System.Windows.Forms.Button
    Friend WithEvents button10 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.button1 = New System.Windows.Forms.Button()
        Me.button2 = New System.Windows.Forms.Button()
        Me.button3 = New System.Windows.Forms.Button()
        Me.button4 = New System.Windows.Forms.Button()
        Me.button5 = New System.Windows.Forms.Button()
        Me.button6 = New System.Windows.Forms.Button()
        Me.button7 = New System.Windows.Forms.Button()
        Me.button8 = New System.Windows.Forms.Button()
        Me.button9 = New System.Windows.Forms.Button()
        Me.button10 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(7, 8)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(130, 23)
        Me.button1.TabIndex = 7
        Me.button1.Text = "Font Families"
        '
        'button2
        '
        Me.button2.Location = New System.Drawing.Point(7, 40)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(130, 23)
        Me.button2.TabIndex = 6
        Me.button2.Text = "Font Sizes"
        '
        'button3
        '
        Me.button3.Location = New System.Drawing.Point(7, 72)
        Me.button3.Name = "button3"
        Me.button3.Size = New System.Drawing.Size(130, 23)
        Me.button3.TabIndex = 8
        Me.button3.Text = "Multi-Line Text"
        '
        'button4
        '
        Me.button4.Location = New System.Drawing.Point(7, 104)
        Me.button4.Name = "button4"
        Me.button4.Size = New System.Drawing.Size(130, 23)
        Me.button4.TabIndex = 10
        Me.button4.Text = "Line Limit"
        '
        'button5
        '
        Me.button5.Location = New System.Drawing.Point(7, 136)
        Me.button5.Name = "button5"
        Me.button5.Size = New System.Drawing.Size(130, 23)
        Me.button5.TabIndex = 9
        Me.button5.Text = "Trimming"
        '
        'button6
        '
        Me.button6.Location = New System.Drawing.Point(7, 168)
        Me.button6.Name = "button6"
        Me.button6.Size = New System.Drawing.Size(130, 23)
        Me.button6.TabIndex = 2
        Me.button6.Text = "Digit Substitution"
        '
        'button7
        '
        Me.button7.Location = New System.Drawing.Point(7, 200)
        Me.button7.Name = "button7"
        Me.button7.Size = New System.Drawing.Size(130, 23)
        Me.button7.TabIndex = 1
        Me.button7.Text = "Text Rendering Hints"
        '
        'button8
        '
        Me.button8.Location = New System.Drawing.Point(7, 232)
        Me.button8.Name = "button8"
        Me.button8.Size = New System.Drawing.Size(130, 23)
        Me.button8.TabIndex = 3
        Me.button8.Text = "Text Contrast"
        '
        'button9
        '
        Me.button9.Location = New System.Drawing.Point(7, 264)
        Me.button9.Name = "button9"
        Me.button9.Size = New System.Drawing.Size(130, 23)
        Me.button9.TabIndex = 5
        Me.button9.Text = "Outline Fonts"
        '
        'button10
        '
        Me.button10.Location = New System.Drawing.Point(7, 296)
        Me.button10.Name = "button10"
        Me.button10.Size = New System.Drawing.Size(130, 23)
        Me.button10.TabIndex = 4
        Me.button10.Text = "Shadow Fonts"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(144, 326)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.button1, Me.button2, Me.button3, Me.button4, Me.button5, Me.button6, Me.button7, Me.button8, Me.button9, Me.button10})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        Dim fff As FontFamiliesForm = New FontFamiliesForm()
        fff.ShowDialog()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button2.Click
        Dim fsf As FontSizesForm = New FontSizesForm()
        fsf.ShowDialog()

    End Sub

    Private Sub button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button3.Click
        Dim mlt As MultiLineTextForm = New MultiLineTextForm()
        mlt.ShowDialog()

    End Sub

    Private Sub button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button4.Click
        Dim llf As LineLimitForm = New LineLimitForm()
        llf.ShowDialog()

    End Sub

    Private Sub button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button5.Click
        Dim tf As TrimmingForm = New TrimmingForm()
        tf.ShowDialog()

    End Sub

    Private Sub button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button6.Click
        Dim dsf As DigitSubstitutionForm = New DigitSubstitutionForm()
        dsf.ShowDialog()

    End Sub

    Private Sub button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button7.Click
        Dim trhf As TextRenderingHintsForm = New TextRenderingHintsForm()
        trhf.ShowDialog()

    End Sub

    Private Sub button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button8.Click
        Dim tcf As TextContrastForm = New TextContrastForm()
        tcf.ShowDialog()

    End Sub

    Private Sub button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button9.Click
        Dim of As OutlineFontsForm = New OutlineFontsForm()
        of.ShowDialog()

    End Sub

    Private Sub button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button10.Click
        Dim sff As ShadowFontsForm = New ShadowFontsForm()
        sff.ShowDialog()

    End Sub
End Class
