Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Globalization

Public Class DigitSubstitutionForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'DigitSubstitutionForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Name = "DigitSubstitutionForm"
        Me.Text = "DigitSubstitutionForm"

    End Sub

#End Region


    Private Sub DigitSubstitutionForm_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        Dim g As Graphics = e.Graphics
        Dim digits As String = "0 1 2 3 4 5 6 7 8 9 0"
        Dim methods As StringDigitSubstitute() = {StringDigitSubstitute.None, StringDigitSubstitute.National, StringDigitSubstitute.Traditional, StringDigitSubstitute.User}

        Dim y As Single
        Dim culture As CultureInfo = New CultureInfo("th-TH")
        Dim format As StringFormat = New StringFormat()
        Dim method As StringDigitSubstitute
        For Each method In methods
            format.SetDigitSubstitution(culture.LCID, method)
            g.DrawString(method.ToString() & ": " & digits, Me.Font, Brushes.Black, 0, y, format)
            y = y + Me.Font.GetHeight(g)
        Next
    End Sub
End Class
