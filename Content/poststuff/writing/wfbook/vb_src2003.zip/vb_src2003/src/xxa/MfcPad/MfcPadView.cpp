// MfcPadView.cpp : implementation of the CMfcPadView class
//

#include "stdafx.h"
#include "MfcPad.h"

#include "MfcPadDoc.h"
#include "MfcPadView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMfcPadView

IMPLEMENT_DYNCREATE(CMfcPadView, CEditView)

BEGIN_MESSAGE_MAP(CMfcPadView, CEditView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CEditView::OnFilePrintPreview)
END_MESSAGE_MAP()

// CMfcPadView construction/destruction

CMfcPadView::CMfcPadView()
{
	// TODO: add construction code here

}

CMfcPadView::~CMfcPadView()
{
}

BOOL CMfcPadView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	BOOL bPreCreated = CEditView::PreCreateWindow(cs);
	cs.style &= ~(ES_AUTOHSCROLL|WS_HSCROLL);	// Enable word-wrapping

	return bPreCreated;
}


// CMfcPadView printing

BOOL CMfcPadView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default CEditView preparation
	return CEditView::OnPreparePrinting(pInfo);
}

void CMfcPadView::OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo)
{
	// Default CEditView begin printing
	CEditView::OnBeginPrinting(pDC, pInfo);
}

void CMfcPadView::OnEndPrinting(CDC* pDC, CPrintInfo* pInfo)
{
	// Default CEditView end printing
	CEditView::OnEndPrinting(pDC, pInfo);
}


// CMfcPadView diagnostics

#ifdef _DEBUG
void CMfcPadView::AssertValid() const
{
	CEditView::AssertValid();
}

void CMfcPadView::Dump(CDumpContext& dc) const
{
	CEditView::Dump(dc);
}

CMfcPadDoc* CMfcPadView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMfcPadDoc)));
	return (CMfcPadDoc*)m_pDocument;
}
#endif //_DEBUG


// CMfcPadView message handlers
