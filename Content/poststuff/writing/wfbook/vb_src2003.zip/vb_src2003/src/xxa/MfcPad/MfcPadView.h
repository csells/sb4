// MfcPadView.h : interface of the CMfcPadView class
//


#pragma once


class CMfcPadView : public CEditView
{
protected: // create from serialization only
	CMfcPadView();
	DECLARE_DYNCREATE(CMfcPadView)

// Attributes
public:
	CMfcPadDoc* GetDocument() const;

// Operations
public:

// Overrides
	public:
virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// Implementation
public:
	virtual ~CMfcPadView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in MfcPadView.cpp
inline CMfcPadDoc* CMfcPadView::GetDocument() const
   { return reinterpret_cast<CMfcPadDoc*>(m_pDocument); }
#endif

