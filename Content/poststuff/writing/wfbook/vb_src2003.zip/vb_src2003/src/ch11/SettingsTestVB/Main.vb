Imports System.Windows.Forms

Public Class App
    Shared Sub Main()
        ' Parse the value manually
        '      Dim settings as NameValueCollection = ConfigurationSettings.AppSettings
        '      Dim pi1 as Decimal = Decimal.Parse(settings("pi"))
        '      MessageBox.Show(pi1.ToString())

        '      ' Let AppSettingsReader parse the value
        '      Dim reader as AppSettingsReader = New AppSettingsReader()
        '      Dim pi2 As Decimal = CType(reader.GetValue("pi", gettype(Decimal)), Decimal)
        '      MessageBox.Show(pi2.ToString())

        'Application.Run(New SettingsTest.Registry_MainForm())
        'Application.Run(New SettingsTest.SpecialFolders_MainForm())

        Application.Run(New IsolatedStorage_MainForm())
    End Sub
End Class
