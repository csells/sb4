' InitialInstanceActivator.cs
' Inspired by Mike Woodring
' Copyright (c) 2003, Chris Sells
' Notes:
' -Uses Application.UserAppDataPath to pick a unique string composed
'  of the app name, the app version and the user name. This
'  gets us a unique mutex name, channel name and port number for each
'  user running each app of a specific version.
' Usage:

Imports System
Imports System.Windows.Forms
Imports System.Threading
Imports System.Runtime.Remoting
Imports System.Runtime.Remoting.Lifetime
Imports System.Runtime.Remoting.Channels
Imports System.Runtime.Remoting.Channels.Tcp

Namespace SellsBrothers
    ' Signature of method to call when another instance is detected
    Public Delegate Sub OtherInstanceCallback(ByVal args As String())




    Public Class InitialINstanceActivator
        Public Shared ReadOnly Property ChannelName() As String
            Get
                Return Application.UserAppDataPath.ToLower().Replace("\", "_")
            End Get
        End Property

        Public Shared ReadOnly Property Port() As Integer
            Get
                ' Pick a port based on an application-specific string
                ' that also falls into an acceptable range
                Return Math.Abs(ChannelName.GetHashCode() / 2) Mod (Short.MaxValue - 1024) + 1024

            End Get
        End Property

        Public Shared ReadOnly Property MutexName() As String
            Get
                Return ChannelName
            End Get
        End Property

        Public Overloads Shared Function Activate(ByVal mainForm As Form) As Boolean
            Return Activate(New ApplicationContext(mainForm), Nothing, Nothing)
        End Function

        Public Overloads Shared Function Activate(ByVal mainForm As Form, ByVal callback As OtherInstanceCallback, ByVal args As String())
            Return Activate(New ApplicationContext(mainForm), callback, args)
        End Function

        Public Overloads Shared Function Activate(ByVal context As ApplicationContext, ByVal callback As OtherInstanceCallback, ByVal args As String())
            ' Check for existing instance
            Dim firstInstance As Boolean = False
            Dim _mutex As Mutex = New Mutex(True, MutexName, firstInstance)

            If Not firstInstance Then
                ' Open remoting channel exposed from initial instance
                Dim url As String = String.Format("tcp://localhost:{0}/{1}", Port, ChannelName)
                Dim activator As MainFormActivator = CType(RemotingServices.Connect(GetType(MainFormActivator), url), MainFormActivator)

                ' Send arguments to initial instance and exit this one
                activator.OnOtherINstance(args)
                Return True
            End If

            ' Expose remoting channel to accept arguments from other instances
            ChannelServices.RegisterChannel(New TcpChannel(Port))
            RemotingServices.Marshal(New MainFormActivator(context, callback), ChannelName)
            Return False
        End Function

        Public Class MainFormActivator
            Inherits MarshalByRefObject

            Dim context As ApplicationContext
            Dim callback As OtherInstanceCallback

            Public Sub New(ByVal context As ApplicationContext, ByVal callback As OtherInstanceCallback)
                Me.context = context
                Me.callback = callback
            End Sub

            Public Overrides Function InitializeLifetimeService() As Object
                ' We want an infinite lifetime as far as the
                ' remoting infrastructure is concerned
                ' (Thanks to Mike Woodring for pointing this out)
                Dim lease As ILease = CType(MyBase.InitializeLifetimeService(), ILease)
                lease.InitialLeaseTime = TimeSpan.Zero
                Return lease
            End Function

            Public Sub OnOtherInstance(ByVal args As String())
                ' Transition to the UI thread
                If Me.context.MainForm.InvokeRequired Then
                    Dim _callback As OtherInstanceCallback = New OtherInstanceCallback(AddressOf OnOtherInstance)
                    Me.context.MainForm.Invoke(callback, New Object() {args})
                    Exit Sub
                End If

                ' Let the UI thread know about the other instance
                Me.callback(args)

                ' Activate the main form
                context.MainForm.Activate()
            End Sub
        End Class
    End Class
End Namespace

