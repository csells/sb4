Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents button4 As System.Windows.Forms.Button
    Friend WithEvents button3 As System.Windows.Forms.Button
    Friend WithEvents button2 As System.Windows.Forms.Button
    Friend WithEvents button1 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.button4 = New System.Windows.Forms.Button()
        Me.button3 = New System.Windows.Forms.Button()
        Me.button2 = New System.Windows.Forms.Button()
        Me.button1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'button4
        '
        Me.button4.Location = New System.Drawing.Point(24, 127)
        Me.button4.Name = "button4"
        Me.button4.Size = New System.Drawing.Size(144, 23)
        Me.button4.TabIndex = 7
        Me.button4.Text = "Show MessageBox"
        '
        'button3
        '
        Me.button3.Location = New System.Drawing.Point(24, 90)
        Me.button3.Name = "button3"
        Me.button3.Size = New System.Drawing.Size(144, 23)
        Me.button3.TabIndex = 6
        Me.button3.Text = "Throw Exception"
        '
        'button2
        '
        Me.button2.Location = New System.Drawing.Point(24, 53)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(144, 23)
        Me.button2.TabIndex = 5
        Me.button2.Text = "Application.ExitThread"
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(24, 16)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(144, 23)
        Me.button1.TabIndex = 4
        Me.button1.Text = "Application.Exit"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(192, 166)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.button4, Me.button3, Me.button2, Me.button1})
        Me.Name = "Form1"
        Me.Text = "Applications"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Shared Sub App_Exit(ByVal sender As Object, ByVal e As EventArgs)
        System.Diagnostics.Debug.WriteLine("App_Exit")
    End Sub

    Shared Sub App_Idle(ByVal sender As Object, ByVal e As EventArgs)
        System.Diagnostics.Debug.WriteLine("App_Idle")
    End Sub

    Shared Sub App_ThreadingException(ByVal sender As Object, ByVal e As System.Threading.ThreadExceptionEventArgs)
        System.Diagnostics.Debug.WriteLine("App_ThreadException")
        Dim msg As String = "A problem has occurred in this application." & vbCrLf & vbCrLf & _
            vbTab & e.Exception.Message & vbCrLf & vbCrLf & _
            "Would you like to continue the application so that " & vbCrLf & _
            "you can save your work?"
        Dim res As DialogResult = MessageBox.Show(msg, "Unexpected Error", MessageBoxButtons.YesNo)
        If res = System.Windows.Forms.DialogResult.Yes Then Exit Sub
        Application.Exit()
    End Sub

    Shared Sub DumpThreadID(ByVal name As String)
        System.Diagnostics.Debug.WriteLine(name & " thread id= " & System.AppDomain.GetCurrentThreadId().ToString())
    End Sub

    Shared Sub DummyThreadStart()
        DumpThreadID("Dummy Thread")
        AddHandler Application.ThreadExit, New EventHandler(AddressOf App_ThreadExit)
    End Sub

    Shared Sub Main()
        AddHandler Application.ThreadException, New System.Threading.ThreadExceptionEventHandler(AddressOf App_ThreadingException)
        AddHandler Application.Idle, New EventHandler(AddressOf App_Idle)
        AddHandler Application.ThreadExit, New EventHandler(AddressOf App_ThreadExit)
        AddHandler Application.ApplicationExit, New EventHandler(AddressOf App_Exit)

        DumpThreadID("UI Thread")
        Dim dummythread As System.Threading.Thread = New System.Threading.Thread(New System.Threading.ThreadStart(AddressOf DummyThreadStart))
        dummythread.Start()

        ' Run the application
        Application.Run(New Form1())

    End Sub

    Shared Sub App_ThreadExit(ByVal sender As Object, ByVal e As EventArgs)
        System.Diagnostics.Debug.WriteLine("App_ThreadExit on thread id= " & System.AppDomain.GetCurrentThreadId().ToString())
    End Sub

    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        System.Diagnostics.Debug.WriteLine("Calling Application.Exit()")
        Application.Exit()
    End Sub
    Private Sub button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button2.Click
        System.Diagnostics.Debug.WriteLine("Calling Application.ExitThread()")
        Application.ExitThread()
    End Sub
    Private Sub button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button3.Click
        System.Diagnostics.Debug.WriteLine("Throwing an exception")
        Throw New System.IO.FileLoadException()
    End Sub
    Private Sub button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button4.Click
        MessageBox.Show("Hi")
    End Sub

    Private Sub Form1_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        System.Diagnostics.Debug.WriteLine("Form1 closing")
    End Sub
End Class
