Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Configuration
Imports System.Collections.Specialized
Imports System.IO
Imports System.Runtime.Serialization
Imports System.Runtime.Serialization.Formatters
Imports System.Runtime.Serialization.Formatters.Soap

Public Class SpecialFolders_MainForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents piTextBox As System.Windows.Forms.TextBox
    Friend WithEvents label1 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.piTextBox = New System.Windows.Forms.TextBox()
        Me.label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'piTextBox
        '
        Me.piTextBox.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.piTextBox.Location = New System.Drawing.Point(82, 16)
        Me.piTextBox.Name = "piTextBox"
        Me.piTextBox.Size = New System.Drawing.Size(200, 20)
        Me.piTextBox.TabIndex = 3
        Me.piTextBox.Text = ""
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(10, 16)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(64, 23)
        Me.label1.TabIndex = 2
        Me.label1.Text = "Today's pi"
        '
        'SpecialFolders_MainForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 54)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.piTextBox, Me.label1})
        Me.Name = "SpecialFolders_MainForm"
        Me.Text = "Settings Test"
        Me.ResumeLayout(False)

    End Sub

#End Region

    ' Custom type to manage serializable form data
    <Serializable()> _
    Public Class FormData
        Public Location As Point
        Public ClientSize As Size
        Public WindowState As FormWindowState

        Public Sub New(ByVal f As Form)
            Me.Location = f.Location
            Me.ClientSize = f.ClientSize
            Me.WindowState = f.WindowState
        End Sub
    End Class

    Private Sub SpecialFolders_MainForm_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        ' Save the form's position before it closes
        Dim fileName As String = Application.LocalUserAppDataPath + "\MainForm.txt"
        System.Diagnostics.Debug.WriteLine(fileName)

        Dim s As Stream = New FileStream(fileName, FileMode.Create)
        ' Restore the window state to save location and
        ' client size at restored state
        Dim state As FormWindowState = Me.WindowState
        Me.WindowState = FormWindowState.Normal

        ' Serialize custom FormData object
        Dim formatter As IFormatter = New SoapFormatter()
        formatter.Serialize(s, New FormData(Me))
        s.Close()
    End Sub

    Private Sub SpecialFolders_MainForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim reader As AppSettingsReader = New AppSettingsReader()
        Dim pi As Decimal = CDec(reader.GetValue("pi", GetType(Decimal)))
        piTextBox.Text = pi.ToString()

        ' Restore the form's position
        Try
            Dim fileName As String = Application.LocalUserAppDataPath + "\MainForm.txt"
            Dim s As Stream = New FileStream(fileName, FileMode.Open)
            ' Don't let the form's position be set automatically
            Me.StartPosition = FormStartPosition.Manual

            ' Deserialize custom FormData object
            Dim formatter As IFormatter = New SoapFormatter()
            Dim data As FormData = CType(formatter.Deserialize(s), FormData)

            ' Set data from FormData object
            Me.Location = data.Location
            Me.ClientSize = data.ClientSize
            Me.WindowState = data.WindowState

            s.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.GetType().Name)
        End Try
    End Sub
End Class
