Imports System.Windows.Forms
Imports System.IO



Public Class WndProcTextBox
    Inherits TextBox

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        Me.SetStyle(ControlStyles.EnableNotifyMessage, True)
    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
    End Sub

#End Region

    Public Delegate Sub ShowEventInfo(ByVal info As String)
    Public Event ShowEventInfoEvent As ShowEventInfo



    Protected Overrides Sub OnNotifyMessage(ByVal m As System.Windows.Forms.Message)
        RaiseEvent ShowEventInfoEvent(String.Format("Msg: HWND({0}) LPARAM({1}) WPARAM({2}) MSG({3})", m.HWnd, m.LParam, m.WParam, m.Msg))
        MyBase.OnNotifyMessage(m)
    End Sub
End Class


