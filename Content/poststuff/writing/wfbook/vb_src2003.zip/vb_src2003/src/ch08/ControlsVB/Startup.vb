Public Class Startup
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents button9 As System.Windows.Forms.Button
    Friend WithEvents button8 As System.Windows.Forms.Button
    Friend WithEvents button7 As System.Windows.Forms.Button
    Friend WithEvents button6 As System.Windows.Forms.Button
    Friend WithEvents button5 As System.Windows.Forms.Button
    Friend WithEvents button4 As System.Windows.Forms.Button
    Friend WithEvents button3 As System.Windows.Forms.Button
    Friend WithEvents button2 As System.Windows.Forms.Button
    Friend WithEvents button1 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.button9 = New System.Windows.Forms.Button()
        Me.button8 = New System.Windows.Forms.Button()
        Me.button7 = New System.Windows.Forms.Button()
        Me.button6 = New System.Windows.Forms.Button()
        Me.button5 = New System.Windows.Forms.Button()
        Me.button4 = New System.Windows.Forms.Button()
        Me.button3 = New System.Windows.Forms.Button()
        Me.button2 = New System.Windows.Forms.Button()
        Me.button1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'button9
        '
        Me.button9.Location = New System.Drawing.Point(7, 261)
        Me.button9.Name = "button9"
        Me.button9.Size = New System.Drawing.Size(263, 21)
        Me.button9.TabIndex = 17
        Me.button9.Text = "Using WndProc"
        '
        'button8
        '
        Me.button8.Location = New System.Drawing.Point(6, 233)
        Me.button8.Name = "button8"
        Me.button8.Size = New System.Drawing.Size(263, 21)
        Me.button8.TabIndex = 16
        Me.button8.Text = "User Controls"
        '
        'button7
        '
        Me.button7.Location = New System.Drawing.Point(6, 202)
        Me.button7.Name = "button7"
        Me.button7.Size = New System.Drawing.Size(263, 22)
        Me.button7.TabIndex = 15
        Me.button7.Text = "Controls Derived from other Controls"
        '
        'button6
        '
        Me.button6.Location = New System.Drawing.Point(6, 172)
        Me.button6.Name = "button6"
        Me.button6.Size = New System.Drawing.Size(263, 22)
        Me.button6.TabIndex = 14
        Me.button6.Text = "Scrolling Controls"
        '
        'button5
        '
        Me.button5.Location = New System.Drawing.Point(6, 142)
        Me.button5.Name = "button5"
        Me.button5.Size = New System.Drawing.Size(263, 22)
        Me.button5.TabIndex = 13
        Me.button5.Text = "Custom Controls"
        '
        'button4
        '
        Me.button4.Location = New System.Drawing.Point(6, 111)
        Me.button4.Name = "button4"
        Me.button4.Size = New System.Drawing.Size(263, 22)
        Me.button4.TabIndex = 12
        Me.button4.Text = "Control Interaction"
        '
        'button3
        '
        Me.button3.Location = New System.Drawing.Point(6, 81)
        Me.button3.Name = "button3"
        Me.button3.Size = New System.Drawing.Size(263, 22)
        Me.button3.TabIndex = 11
        Me.button3.Text = "Control Behavior"
        '
        'button2
        '
        Me.button2.Location = New System.Drawing.Point(6, 51)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(263, 22)
        Me.button2.TabIndex = 10
        Me.button2.Text = "Control Visuals"
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(6, 21)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(263, 21)
        Me.button1.TabIndex = 9
        Me.button1.Text = "Control Overview"
        '
        'Startup
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(277, 302)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.button9, Me.button8, Me.button7, Me.button6, Me.button5, Me.button4, Me.button3, Me.button2, Me.button1})
        Me.Name = "Startup"
        Me.Text = "Startup"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button9.Click
        Dim wpf As WndProcForm = New WndProcForm()
        wpf.ShowDialog()
    End Sub
    Private Sub button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button5.Click
        Dim ccf As CustomControls = New CustomControls()
        ccf.ShowDialog()
    End Sub
    Private Sub button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button2.Click
        Dim cvf As ControlVisuals = New ControlVisuals()
        cvf.ShowDialog()
    End Sub
    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        Dim cof As ControlOverview = New ControlOverview()
        cof.ShowDialog()
    End Sub
    Private Sub button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button6.Click
        Dim scf As ScrollControls = New ScrollControls()
        scf.ShowDialog()
    End Sub
    Private Sub button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button3.Click
        Dim cbf As ControlBehavior = New ControlBehavior()
        cbf.ShowDialog()
    End Sub
    Private Sub button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button7.Click
        Dim sccf As SubclassControls = New SubclassControls()
        sccf.ShowDialog()
    End Sub
    Private Sub button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button4.Click
        Dim cif As ControlInteraction = New ControlInteraction()
        cif.ShowDialog()
    End Sub
    Private Sub button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button8.Click
        Dim ucf As UserControls = New UserControls()
        ucf.ShowDialog()
    End Sub
End Class
