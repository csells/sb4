Imports System.Drawing
Imports System.Drawing.Drawing2D


Public Class MatrixMarginsForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents statusBar1 As System.Windows.Forms.StatusBar
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.statusBar1 = New System.Windows.Forms.StatusBar()
        Me.SuspendLayout()
        '
        'statusBar1
        '
        Me.statusBar1.Location = New System.Drawing.Point(0, 244)
        Me.statusBar1.Name = "statusBar1"
        Me.statusBar1.Size = New System.Drawing.Size(292, 22)
        Me.statusBar1.TabIndex = 1
        Me.statusBar1.Text = "statusBar1"
        '
        'MatrixMarginsForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.statusBar1})
        Me.Name = "MatrixMarginsForm"
        Me.Text = "MatrixMarginsForm"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Dim s As String = "For example, it�s not important that the ruler at the top of the document I�m typing this sentence into is currently showing an inch as 1 9/16 inches. What is important is the proportion of the dimensions of each line in proportion to the units shown as 'inches' as compared to the width and height of each line as I type. The principle of WYSIWYG (What You See Is What You Get) says that I should be able to print something very similar to what I�m seeing on the screen . When my word processing program shows a line wrapping at a certain word when I get close to the 6 � inches area inside of my margins (my page settings are set to standard 8 � inch wide paper with a 1 inch margin on each side), I want that same wrap to happen at the same word when I print. To make that happen, we need to be able to write a program that can wrap text at units other than pixels, as shown in Figure 1."

    Private Function InchesToPixels(ByVal inches As Single) As Single
        Dim g As Graphics = Me.CreateGraphics()
        Return inches * g.DpiY
    End Function

    Function InchesToPixels(ByVal rect As RectangleF) As RectangleF
        Return New RectangleF(InchesToPixels(rect.X), InchesToPixels(rect.Y), InchesToPixels(rect.Width), InchesToPixels(rect.Height))
    End Function

    Function PixelsToInches(ByVal pixels As Single) As Single
        Dim g As Graphics = Me.CreateGraphics
        Return pixels / g.DpiY
    End Function

    Sub PaintInInches(ByVal g As Graphics)
        Dim matrix As Matrix = New Matrix()
        matrix.Scale(g.DpiX, g.DpiY)
        g.Transform = matrix

        Dim rulerFont As Font = New Font("MS Sans Serif", 8.25F / g.DpiY)
        Dim blackPen As Pen = New Pen(Color.Black, 0)
        Dim rulerFontHeight As Single = rulerFont.GetHeight(g)
        Dim rulerRect As RectangleF = New RectangleF(0, 0, 6.5F, rulerFontHeight * 1.5F)
        g.DrawRectangle(blackPen, rulerRect.X, rulerRect.Y, rulerRect.Width, rulerRect.Height)
        Dim i As Single
        For i = 1 To 6
            Dim rect As RectangleF = New RectangleF(i - rulerFontHeight, 0, rulerFontHeight * 2, rulerFontHeight)
            Dim format As StringFormat = New StringFormat()
            format.Alignment = StringAlignment.Center
            g.DrawString(i.ToString(), rulerFont, Brushes.Black, rect, format)
        Next

        For i = 0.5 To 6.5 Step 1
            g.DrawLine(blackPen, i, 0, i, rulerFontHeight / 2)
        Next

        Dim textFont As Font = New Font("Times New Roman", 0.11F)
        Dim textRect As RectangleF = New RectangleF(0, rulerRect.Height, 6.5F, PixelsToInches(Me.ClientRectangle.Height) - rulerRect.Height)
        g.FillRectangle(Brushes.White, textRect)
        g.DrawRectangle(blackPen, textRect.X, textRect.Y, textRect.Width, textRect.Height)
        g.DrawString(s, textFont, Brushes.Black, textRect)

    End Sub

    Sub ScaleExample(ByVal e As PaintEventArgs)
        Dim myPen As Pen = New Pen(Color.Blue, 1)
        Dim myPen2 As Pen = New Pen(Color.Red, 1)
        e.Graphics.DrawRectangle(myPen, 50, 50, 100, 100)
        Dim myMatrix As Matrix = New Matrix()
        myMatrix.Scale(3, 2, MatrixOrder.Append)
        e.Graphics.Transform = myMatrix
        e.Graphics.DrawRectangle(myPen2, 50, 50, 100, 100)
    End Sub

    Sub Margins_Paint(ByVal sender As Object, ByVal e As PaintEventArgs) Handles MyBase.Paint
        PaintInInches(e.Graphics)
    End Sub

    Sub ShowClientSize()
        Dim g As Graphics = Me.CreateGraphics
        Dim matrix As Matrix = New Matrix()
        matrix.Scale(g.DpiX, g.DpiY)
        g.Transform = matrix
        Dim bottomRight As PointF() = New PointF() {New PointF(Me.ClientSize.Width, Me.ClientSize.Height)}
        g.TransformPoints(CoordinateSpace.World, CoordinateSpace.Device, bottomRight)
        statusBar1.Text = String.Format("ClientSize= {0} pixels, {1} inches", Me.ClientSize, bottomRight(0))
    End Sub

    Sub MarginsForm_Resize(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Resize
        ShowClientSize()
    End Sub

    Sub MatrixMarginsForm_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        ShowClientSize()
    End Sub
End Class
