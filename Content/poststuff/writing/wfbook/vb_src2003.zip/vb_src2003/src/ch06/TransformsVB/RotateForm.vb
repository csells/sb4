Imports System.Drawing
Imports System.Drawing.Drawing2D


Public Class RotateForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'RotateForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(280, 214)
        Me.Name = "RotateForm"
        Me.Text = "RotateForm"

    End Sub

#End Region


    Sub RotateForm_Paint(ByVal sender As Object, ByVal e As PaintEventArgs) Handles MyBase.Paint
        Dim g As Graphics = e.Graphics
        Dim x As Integer = 25
        Dim y As Integer = 25
        Dim width As Integer = 250
        Dim height As Integer = 250
        Dim textWidth As Single = g.MeasureString("00", Me.Font).Width
        Dim length As Single = Math.Min(width - x, height - x) - textWidth
        Dim textRect As RectangleF = New RectangleF(x + length, y - Me.Font.GetHeight(g) / 2, length, textWidth)
        Dim format As StringFormat = New StringFormat()
        format.Alignment = StringAlignment.Near
        format.LineAlignment = StringAlignment.Center

        Dim i As Integer
        For i = 0 To 90 Step 10
            Dim matrix As Matrix = New Matrix()
            matrix.RotateAt(i, New PointF(x, y))
            g.Transform = matrix
            g.DrawLine(Pens.Black, x, y, x + length, y)
            g.DrawString(i.ToString(), Me.Font, Brushes.Black, textRect, format)
        Next
    End Sub
End Class
