Imports System.Drawing
Imports System.Drawing.Drawing2D

Public Class ClippingRegionForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
        Me.Text = "ClippingRegionForm"
    End Sub

#End Region


    Dim rnd As Random = New Random()


    Private Sub ClippingRegionForm_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        Dim g As Graphics = e.Graphics
        Dim format As StringFormat = New StringFormat()
        format.Alignment = StringAlignment.Center
        format.LineAlignment = StringAlignment.Center

        Dim path As GraphicsPath = New GraphicsPath()
        path.AddEllipse(Me.ClientRectangle)
        Dim region As Region = New Region(path)
        g.DrawPath(Pens.Red, path)
        g.Clip = region
        Dim rect As Rectangle = Me.ClientRectangle
        rect.Offset(10, 10)
        rect.Width = rect.Width - 20
        rect.Height = rect.Height - 20
        g.FillRectangle(Brushes.Black, rect)
        g.DrawString("Rectangle clipped to Ellipse", Me.Font, Brushes.White, RectangleF.op_Implicit(rect), format)

    End Sub
End Class
