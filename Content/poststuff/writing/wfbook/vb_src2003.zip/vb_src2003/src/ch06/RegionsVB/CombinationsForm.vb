Imports System.Drawing
Imports System.Drawing.Drawing2D


Public Class CombinationsForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'CombinationsForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(544, 118)
        Me.Name = "CombinationsForm"
        Me.Text = "CombinationsForm"

    End Sub

#End Region

    Private Sub CombinationsForm_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        Dim g As Graphics = e.Graphics
        Dim width As Single = Me.ClientSize.Width / 5
        Dim height As Single = Me.ClientSize.Height
        Dim rect As RectangleF = New RectangleF(0, 0, width, height)
        Dim format As StringFormat = New StringFormat()
        format.Alignment = StringAlignment.Center
        format.LineAlignment = StringAlignment.Center

        Dim path1 As GraphicsPath = New GraphicsPath()
        Dim path2 As GraphicsPath = New GraphicsPath()

        Dim path1Rect As RectangleF = New RectangleF(0, 0, width * 2.0F / 3.0F, height)
        Dim path2rect As RectangleF = path1Rect
        path2rect.Offset(width * 1.0F / 3.0F, 0)
        path1.AddEllipse(path1Rect)
        path2.AddEllipse(path2rect)

        Dim region As Region = New Region(path1)
        region.Union(path2)
        g.FillRegion(Brushes.Red, region)
        g.DrawString("Union", Me.Font, Brushes.Black, rect, format)
        g.DrawRectangle(Pens.Black, rect.X, rect.Y, rect.Width, rect.Height)
        g.TranslateTransform(width, 0)

        region = New Region(path1)
        region.Intersect(path2)
        g.FillRegion(Brushes.Red, region)
        g.DrawString("Intersect", Me.Font, Brushes.Black, rect, format)
        g.DrawRectangle(Pens.Black, rect.X, rect.Y, rect.Width, rect.Height)
        g.TranslateTransform(width, 0)

        region = New Region(path1)
        region.Exclude(path2)
        g.FillRegion(Brushes.Red, region)
        g.DrawString("Exclude", Me.Font, Brushes.Black, rect, format)
        g.DrawRectangle(Pens.Black, rect.X, rect.Y, rect.Width, rect.Height)
        g.TranslateTransform(width, 0)

        region = New Region(path1)
        region.Complement(path2)
        g.FillRegion(Brushes.Red, region)
        g.DrawString("Complement", Me.Font, Brushes.Black, rect, format)
        g.DrawRectangle(Pens.Black, rect.X, rect.Y, rect.Width, rect.Height)
        g.TranslateTransform(width, 0)

        region = New Region(path1)
        region.Xor(path2)
        g.FillRegion(Brushes.Red, region)
        g.DrawString("Xor", Me.Font, Brushes.Black, rect, format)
        g.DrawRectangle(Pens.Black, rect.X, rect.Y, rect.Width, rect.Height)
        g.TranslateTransform(width, 0)

    End Sub
End Class
