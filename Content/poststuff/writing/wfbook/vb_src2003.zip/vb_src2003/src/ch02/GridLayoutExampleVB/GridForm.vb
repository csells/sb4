Public Class GridForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents button2 As System.Windows.Forms.Button
    Friend WithEvents button3 As System.Windows.Forms.Button
    Friend WithEvents button4 As System.Windows.Forms.Button
    Friend WithEvents button5 As System.Windows.Forms.Button
    Friend WithEvents button6 As System.Windows.Forms.Button
    Friend WithEvents button7 As System.Windows.Forms.Button
    Friend WithEvents button8 As System.Windows.Forms.Button
    Friend WithEvents button9 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.button1 = New System.Windows.Forms.Button()
        Me.button2 = New System.Windows.Forms.Button()
        Me.button3 = New System.Windows.Forms.Button()
        Me.button4 = New System.Windows.Forms.Button()
        Me.button5 = New System.Windows.Forms.Button()
        Me.button6 = New System.Windows.Forms.Button()
        Me.button7 = New System.Windows.Forms.Button()
        Me.button8 = New System.Windows.Forms.Button()
        Me.button9 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(8, 8)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(75, 75)
        Me.button1.TabIndex = 7
        Me.button1.Text = "1"
        '
        'button2
        '
        Me.button2.Location = New System.Drawing.Point(88, 8)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(75, 75)
        Me.button2.TabIndex = 6
        Me.button2.Text = "2"
        '
        'button3
        '
        Me.button3.Location = New System.Drawing.Point(168, 8)
        Me.button3.Name = "button3"
        Me.button3.Size = New System.Drawing.Size(75, 75)
        Me.button3.TabIndex = 9
        Me.button3.Text = "3"
        '
        'button4
        '
        Me.button4.Location = New System.Drawing.Point(8, 88)
        Me.button4.Name = "button4"
        Me.button4.Size = New System.Drawing.Size(75, 75)
        Me.button4.TabIndex = 8
        Me.button4.Text = "4"
        '
        'button5
        '
        Me.button5.Location = New System.Drawing.Point(88, 88)
        Me.button5.Name = "button5"
        Me.button5.Size = New System.Drawing.Size(75, 75)
        Me.button5.TabIndex = 5
        Me.button5.Text = "5"
        '
        'button6
        '
        Me.button6.Location = New System.Drawing.Point(168, 88)
        Me.button6.Name = "button6"
        Me.button6.Size = New System.Drawing.Size(75, 75)
        Me.button6.TabIndex = 2
        Me.button6.Text = "6"
        '
        'button7
        '
        Me.button7.Location = New System.Drawing.Point(8, 168)
        Me.button7.Name = "button7"
        Me.button7.Size = New System.Drawing.Size(75, 75)
        Me.button7.TabIndex = 1
        Me.button7.Text = "7"
        '
        'button8
        '
        Me.button8.Location = New System.Drawing.Point(88, 168)
        Me.button8.Name = "button8"
        Me.button8.Size = New System.Drawing.Size(75, 75)
        Me.button8.TabIndex = 4
        Me.button8.Text = "8"
        '
        'button9
        '
        Me.button9.Location = New System.Drawing.Point(168, 168)
        Me.button9.Name = "button9"
        Me.button9.Size = New System.Drawing.Size(75, 75)
        Me.button9.TabIndex = 3
        Me.button9.Text = "9"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(248, 246)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.button1, Me.button2, Me.button3, Me.button4, Me.button5, Me.button6, Me.button7, Me.button8, Me.button9})
        Me.Name = "Form1"
        Me.Text = "Grid Layout Example"
        Me.ResumeLayout(False)

    End Sub

#End Region



    Private Sub GridForm_Layout(ByVal sender As Object, ByVal e As System.Windows.Forms.LayoutEventArgs) Handles MyBase.Layout
        Dim buttons As Button() = New Button() {button1, button2, button3, button4, button5, button6, button7, button8, button9}
        Dim cx As Integer = ClientRectangle.Width / 3
        Dim cy As Integer = ClientRectangle.Height / 3
        Dim row As Integer = 0
        Do While row < 3
            Dim col As Integer = 0
            Do While col < 3
                Dim b As Button = buttons(col * 3 + row)
                b.SetBounds(cx * row, cy * col, cx, cy)
                col = col + 1
            Loop
            row = row + 1
        Loop

        SetClientSizeCore(cx * 3, cy * 3)
    End Sub
End Class
