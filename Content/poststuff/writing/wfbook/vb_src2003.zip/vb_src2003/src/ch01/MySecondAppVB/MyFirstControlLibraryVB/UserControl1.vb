Public Class UserControl1
    Inherits System.Windows.Forms.UserControl

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'UserControl1 overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents textBox1 As System.Windows.Forms.TextBox
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents textBox2 As System.Windows.Forms.TextBox
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents textBox3 As System.Windows.Forms.TextBox
    Friend WithEvents label4 As System.Windows.Forms.Label
    Friend WithEvents textBox4 As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.textBox1 = New System.Windows.Forms.TextBox()
        Me.label1 = New System.Windows.Forms.Label()
        Me.textBox2 = New System.Windows.Forms.TextBox()
        Me.label2 = New System.Windows.Forms.Label()
        Me.label3 = New System.Windows.Forms.Label()
        Me.textBox3 = New System.Windows.Forms.TextBox()
        Me.label4 = New System.Windows.Forms.Label()
        Me.textBox4 = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'textBox1
        '
        Me.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.textBox1.Location = New System.Drawing.Point(80, 9)
        Me.textBox1.Name = "textBox1"
        Me.textBox1.Size = New System.Drawing.Size(160, 20)
        Me.textBox1.TabIndex = 8
        Me.textBox1.Text = ""
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(8, 9)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(64, 23)
        Me.label1.TabIndex = 7
        Me.label1.Text = "Street"
        '
        'textBox2
        '
        Me.textBox2.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.textBox2.Location = New System.Drawing.Point(80, 33)
        Me.textBox2.Name = "textBox2"
        Me.textBox2.Size = New System.Drawing.Size(160, 20)
        Me.textBox2.TabIndex = 10
        Me.textBox2.Text = ""
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(8, 33)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(64, 23)
        Me.label2.TabIndex = 4
        Me.label2.Text = "City"
        '
        'label3
        '
        Me.label3.Location = New System.Drawing.Point(8, 57)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(64, 23)
        Me.label3.TabIndex = 5
        Me.label3.Text = "State"
        '
        'textBox3
        '
        Me.textBox3.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.textBox3.Location = New System.Drawing.Point(80, 57)
        Me.textBox3.Name = "textBox3"
        Me.textBox3.Size = New System.Drawing.Size(160, 20)
        Me.textBox3.TabIndex = 11
        Me.textBox3.Text = ""
        '
        'label4
        '
        Me.label4.Location = New System.Drawing.Point(8, 81)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(64, 23)
        Me.label4.TabIndex = 6
        Me.label4.Text = "Zip"
        '
        'textBox4
        '
        Me.textBox4.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.textBox4.Location = New System.Drawing.Point(80, 81)
        Me.textBox4.Name = "textBox4"
        Me.textBox4.Size = New System.Drawing.Size(160, 20)
        Me.textBox4.TabIndex = 9
        Me.textBox4.Text = ""
        '
        'UserControl1
        '
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.textBox1, Me.label1, Me.textBox2, Me.label2, Me.label3, Me.textBox3, Me.label4, Me.textBox4})
        Me.Name = "UserControl1"
        Me.Size = New System.Drawing.Size(248, 112)
        Me.ResumeLayout(False)

    End Sub

#End Region

End Class
