Imports System
Imports System.Windows.Forms

Class MyFirstForm
    Inherits Form

    Private WithEvents mybutton As Button

    Public Sub New()
        Me.Text = "Hello, WinForms!"
        mybutton = New Button()
        mybutton.Text = "Click Me!"
        Me.Controls.Add(mybutton)
    End Sub

    Public Sub mybutton_Click(sender As Object, e As EventArgs) Handles mybutton.Click
        MessageBox.Show("That's a strong, confident click you've got...")
    End Sub

End Class

Class MyFirstApp
    Shared Sub Main()
        Dim myform As Form = New MyFirstForm()
        Application.Run(myform)
    End Sub
End Class
