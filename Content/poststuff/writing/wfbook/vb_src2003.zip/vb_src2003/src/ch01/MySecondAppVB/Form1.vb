Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Configuration
Imports System.Resources


Public Class MainForm
    Inherits System.Windows.Forms.Form


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        UserControl1.BackgroundImage = Me.BackgroundImage
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents textBox2 As System.Windows.Forms.TextBox
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents textBox1 As System.Windows.Forms.TextBox
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents button2 As System.Windows.Forms.Button
    Friend WithEvents UserControl1 As MyFirstControlLibraryVB.UserControl1
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(MainForm))
        Me.textBox2 = New System.Windows.Forms.TextBox()
        Me.button1 = New System.Windows.Forms.Button()
        Me.textBox1 = New System.Windows.Forms.TextBox()
        Me.label1 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.button2 = New System.Windows.Forms.Button()
        Me.UserControl1 = New MyFirstControlLibraryVB.UserControl1()
        Me.SuspendLayout()
        '
        'textBox2
        '
        Me.textBox2.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.textBox2.Location = New System.Drawing.Point(81, 32)
        Me.textBox2.Name = "textBox2"
        Me.textBox2.Size = New System.Drawing.Size(292, 20)
        Me.textBox2.TabIndex = 6
        Me.textBox2.Text = ""
        '
        'button1
        '
        Me.button1.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.button1.Location = New System.Drawing.Point(213, 288)
        Me.button1.Name = "button1"
        Me.button1.TabIndex = 8
        Me.button1.Text = "OK"
        '
        'textBox1
        '
        Me.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.textBox1.Location = New System.Drawing.Point(81, 8)
        Me.textBox1.Name = "textBox1"
        Me.textBox1.Size = New System.Drawing.Size(292, 20)
        Me.textBox1.TabIndex = 5
        Me.textBox1.Text = ""
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(9, 8)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(64, 23)
        Me.label1.TabIndex = 3
        Me.label1.Text = "First Name"
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(9, 32)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(64, 23)
        Me.label2.TabIndex = 4
        Me.label2.Text = "Last Name"
        '
        'button2
        '
        Me.button2.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.button2.Location = New System.Drawing.Point(301, 288)
        Me.button2.Name = "button2"
        Me.button2.TabIndex = 7
        Me.button2.Text = "Cancel"
        '
        'UserControl1
        '
        Me.UserControl1.Location = New System.Drawing.Point(16, 72)
        Me.UserControl1.Name = "UserControl1"
        Me.UserControl1.Size = New System.Drawing.Size(344, 112)
        Me.UserControl1.TabIndex = 9
        '
        'MainForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Bitmap)
        Me.ClientSize = New System.Drawing.Size(384, 318)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.UserControl1, Me.textBox2, Me.button1, Me.textBox1, Me.label1, Me.label2, Me.button2})
        Me.Name = "MainForm"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Shared Sub Main()
        ' Application.Run(New MainForm())
        Application.Run(New Form2())
    End Sub

    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        Dim _button As Button = CType(sender, Button)
        MessageBox.Show(_button.Text + " was clicked")
    End Sub

    Private Sub button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button2.Click
        Dim _button As Button = CType(sender, Button)
        MessageBox.Show(_button.Text + " was clicked")
    End Sub

    Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim dlg As AboutDialog = New AboutDialog()
    End Sub
End Class
