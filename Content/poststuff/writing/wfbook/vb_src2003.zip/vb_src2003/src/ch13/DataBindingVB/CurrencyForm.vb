Public Class CurrencyForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents statusBar1 As System.Windows.Forms.StatusBar
    Friend WithEvents listBox1 As System.Windows.Forms.ListBox
    Friend WithEvents addButton As System.Windows.Forms.Button
    Friend WithEvents startButton As System.Windows.Forms.Button
    Friend WithEvents positionButton As System.Windows.Forms.Button
    Friend WithEvents textBox1 As System.Windows.Forms.TextBox
    Friend WithEvents previousButton As System.Windows.Forms.Button
    Friend WithEvents nextButton As System.Windows.Forms.Button
    Friend WithEvents endButton As System.Windows.Forms.Button
    Friend WithEvents textBox2 As System.Windows.Forms.TextBox
    Friend WithEvents updateButton As System.Windows.Forms.Button
    Friend WithEvents deleteButton As System.Windows.Forms.Button
    Friend WithEvents showButton As System.Windows.Forms.Button
    Friend WithEvents customersAdapter As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents sqlDeleteCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents sqlConnection1 As System.Data.SqlClient.SqlConnection
    Friend WithEvents sqlInsertCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents sqlSelectCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents sqlUpdateCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents customerSet1 As DataBindingVB.CustomerSet

    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.statusBar1 = New System.Windows.Forms.StatusBar()
        Me.listBox1 = New System.Windows.Forms.ListBox()
        Me.addButton = New System.Windows.Forms.Button()
        Me.startButton = New System.Windows.Forms.Button()
        Me.positionButton = New System.Windows.Forms.Button()
        Me.textBox1 = New System.Windows.Forms.TextBox()
        Me.previousButton = New System.Windows.Forms.Button()
        Me.nextButton = New System.Windows.Forms.Button()
        Me.endButton = New System.Windows.Forms.Button()
        Me.textBox2 = New System.Windows.Forms.TextBox()
        Me.updateButton = New System.Windows.Forms.Button()
        Me.deleteButton = New System.Windows.Forms.Button()
        Me.showButton = New System.Windows.Forms.Button()
        Me.customersAdapter = New System.Data.SqlClient.SqlDataAdapter()
        Me.sqlDeleteCommand1 = New System.Data.SqlClient.SqlCommand()
        Me.sqlConnection1 = New System.Data.SqlClient.SqlConnection()
        Me.sqlInsertCommand1 = New System.Data.SqlClient.SqlCommand()
        Me.sqlSelectCommand1 = New System.Data.SqlClient.SqlCommand()
        Me.sqlUpdateCommand1 = New System.Data.SqlClient.SqlCommand()
        Me.SuspendLayout()
        '
        'statusBar1
        '
        Me.statusBar1.Location = New System.Drawing.Point(0, 216)
        Me.statusBar1.Name = "statusBar1"
        Me.statusBar1.Size = New System.Drawing.Size(264, 22)
        Me.statusBar1.TabIndex = 21
        Me.statusBar1.Text = "statusBar1"
        '
        'listBox1
        '
        Me.listBox1.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.listBox1.DisplayMember = "Customers.ContactTitleName"
        Me.listBox1.IntegralHeight = False
        Me.listBox1.Location = New System.Drawing.Point(8, 104)
        Me.listBox1.Name = "listBox1"
        Me.listBox1.Size = New System.Drawing.Size(248, 96)
        Me.listBox1.TabIndex = 20
        Me.listBox1.ValueMember = "Customers.CustomerID"
        '
        'addButton
        '
        Me.addButton.Location = New System.Drawing.Point(16, 72)
        Me.addButton.Name = "addButton"
        Me.addButton.Size = New System.Drawing.Size(48, 23)
        Me.addButton.TabIndex = 19
        Me.addButton.Text = "Add"
        '
        'startButton
        '
        Me.startButton.Location = New System.Drawing.Point(8, 40)
        Me.startButton.Name = "startButton"
        Me.startButton.Size = New System.Drawing.Size(40, 23)
        Me.startButton.TabIndex = 11
        Me.startButton.Text = "|<"
        '
        'positionButton
        '
        Me.positionButton.Location = New System.Drawing.Point(112, 40)
        Me.positionButton.Name = "positionButton"
        Me.positionButton.Size = New System.Drawing.Size(40, 23)
        Me.positionButton.TabIndex = 13
        Me.positionButton.Text = "Pos"
        '
        'textBox1
        '
        Me.textBox1.Location = New System.Drawing.Point(8, 8)
        Me.textBox1.Name = "textBox1"
        Me.textBox1.Size = New System.Drawing.Size(120, 20)
        Me.textBox1.TabIndex = 9
        Me.textBox1.Text = "textBox1"
        '
        'previousButton
        '
        Me.previousButton.Location = New System.Drawing.Point(56, 40)
        Me.previousButton.Name = "previousButton"
        Me.previousButton.Size = New System.Drawing.Size(40, 23)
        Me.previousButton.TabIndex = 12
        Me.previousButton.Text = "<"
        '
        'nextButton
        '
        Me.nextButton.Location = New System.Drawing.Point(168, 40)
        Me.nextButton.Name = "nextButton"
        Me.nextButton.Size = New System.Drawing.Size(40, 23)
        Me.nextButton.TabIndex = 14
        Me.nextButton.Text = ">"
        '
        'endButton
        '
        Me.endButton.Location = New System.Drawing.Point(216, 40)
        Me.endButton.Name = "endButton"
        Me.endButton.Size = New System.Drawing.Size(40, 23)
        Me.endButton.TabIndex = 15
        Me.endButton.Text = ">|"
        '
        'textBox2
        '
        Me.textBox2.Location = New System.Drawing.Point(136, 8)
        Me.textBox2.Name = "textBox2"
        Me.textBox2.Size = New System.Drawing.Size(120, 20)
        Me.textBox2.TabIndex = 10
        Me.textBox2.Text = "textBox1"
        '
        'updateButton
        '
        Me.updateButton.Location = New System.Drawing.Point(72, 72)
        Me.updateButton.Name = "updateButton"
        Me.updateButton.Size = New System.Drawing.Size(56, 23)
        Me.updateButton.TabIndex = 16
        Me.updateButton.Text = "Update"
        '
        'deleteButton
        '
        Me.deleteButton.Location = New System.Drawing.Point(136, 72)
        Me.deleteButton.Name = "deleteButton"
        Me.deleteButton.Size = New System.Drawing.Size(56, 23)
        Me.deleteButton.TabIndex = 17
        Me.deleteButton.Text = "Delete"
        '
        'showButton
        '
        Me.showButton.Location = New System.Drawing.Point(200, 72)
        Me.showButton.Name = "showButton"
        Me.showButton.Size = New System.Drawing.Size(56, 23)
        Me.showButton.TabIndex = 18
        Me.showButton.Text = "Show"
        '
        'customersAdapter
        '
        Me.customersAdapter.DeleteCommand = Me.sqlDeleteCommand1
        Me.customersAdapter.InsertCommand = Me.sqlInsertCommand1
        Me.customersAdapter.SelectCommand = Me.sqlSelectCommand1
        Me.customersAdapter.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Customers", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("CustomerID", "CustomerID"), New System.Data.Common.DataColumnMapping("CompanyName", "CompanyName"), New System.Data.Common.DataColumnMapping("ContactName", "ContactName"), New System.Data.Common.DataColumnMapping("ContactTitle", "ContactTitle"), New System.Data.Common.DataColumnMapping("Address", "Address"), New System.Data.Common.DataColumnMapping("City", "City"), New System.Data.Common.DataColumnMapping("Region", "Region"), New System.Data.Common.DataColumnMapping("PostalCode", "PostalCode"), New System.Data.Common.DataColumnMapping("Country", "Country"), New System.Data.Common.DataColumnMapping("Phone", "Phone"), New System.Data.Common.DataColumnMapping("Fax", "Fax")})})
        Me.customersAdapter.UpdateCommand = Me.sqlUpdateCommand1
        '
        'sqlDeleteCommand1
        '
        Me.sqlDeleteCommand1.CommandText = "DELETE FROM Customers WHERE (CustomerID = @Original_CustomerID) AND (Address = @O" & _
        "riginal_Address OR @Original_Address IS NULL AND Address IS NULL) AND (City = @O" & _
        "riginal_City OR @Original_City IS NULL AND City IS NULL) AND (CompanyName = @Ori" & _
        "ginal_CompanyName) AND (ContactName = @Original_ContactName OR @Original_Contact" & _
        "Name IS NULL AND ContactName IS NULL) AND (ContactTitle = @Original_ContactTitle" & _
        " OR @Original_ContactTitle IS NULL AND ContactTitle IS NULL) AND (Country = @Ori" & _
        "ginal_Country OR @Original_Country IS NULL AND Country IS NULL) AND (Fax = @Orig" & _
        "inal_Fax OR @Original_Fax IS NULL AND Fax IS NULL) AND (Phone = @Original_Phone " & _
        "OR @Original_Phone IS NULL AND Phone IS NULL) AND (PostalCode = @Original_Postal" & _
        "Code OR @Original_PostalCode IS NULL AND PostalCode IS NULL) AND (Region = @Orig" & _
        "inal_Region OR @Original_Region IS NULL AND Region IS NULL)"
        Me.sqlDeleteCommand1.Connection = Me.sqlConnection1
        Me.sqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CustomerID", System.Data.SqlDbType.NVarChar, 5, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CustomerID", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Address", System.Data.SqlDbType.NVarChar, 60, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Address", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_City", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "City", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CompanyName", System.Data.SqlDbType.NVarChar, 40, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CompanyName", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ContactName", System.Data.SqlDbType.NVarChar, 30, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ContactName", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ContactTitle", System.Data.SqlDbType.NVarChar, 30, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ContactTitle", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Country", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Country", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Fax", System.Data.SqlDbType.NVarChar, 24, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Fax", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Phone", System.Data.SqlDbType.NVarChar, 24, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Phone", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_PostalCode", System.Data.SqlDbType.NVarChar, 10, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PostalCode", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Region", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Region", System.Data.DataRowVersion.Original, Nothing))
        '
        'sqlConnection1
        '
        Me.sqlConnection1.ConnectionString = "data source=MUNGO\NetSDK;initial catalog=Northwind;integrated security=SSPI;persi" & _
        "st security info=False;workstation id=MUNGO;packet size=4096"
        '
        'sqlInsertCommand1
        '
        Me.sqlInsertCommand1.CommandText = "INSERT INTO Customers(CustomerID, CompanyName, ContactName, ContactTitle, Address" & _
        ", City, Region, PostalCode, Country, Phone, Fax) VALUES (@CustomerID, @CompanyNa" & _
        "me, @ContactName, @ContactTitle, @Address, @City, @Region, @PostalCode, @Country" & _
        ", @Phone, @Fax); SELECT CustomerID, CompanyName, ContactName, ContactTitle, Addr" & _
        "ess, City, Region, PostalCode, Country, Phone, Fax FROM Customers WHERE (Custome" & _
        "rID = @CustomerID)"
        Me.sqlInsertCommand1.Connection = Me.sqlConnection1
        Me.sqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CustomerID", System.Data.SqlDbType.NVarChar, 5, "CustomerID"))
        Me.sqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CompanyName", System.Data.SqlDbType.NVarChar, 40, "CompanyName"))
        Me.sqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ContactName", System.Data.SqlDbType.NVarChar, 30, "ContactName"))
        Me.sqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ContactTitle", System.Data.SqlDbType.NVarChar, 30, "ContactTitle"))
        Me.sqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Address", System.Data.SqlDbType.NVarChar, 60, "Address"))
        Me.sqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@City", System.Data.SqlDbType.NVarChar, 15, "City"))
        Me.sqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Region", System.Data.SqlDbType.NVarChar, 15, "Region"))
        Me.sqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PostalCode", System.Data.SqlDbType.NVarChar, 10, "PostalCode"))
        Me.sqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Country", System.Data.SqlDbType.NVarChar, 15, "Country"))
        Me.sqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Phone", System.Data.SqlDbType.NVarChar, 24, "Phone"))
        Me.sqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Fax", System.Data.SqlDbType.NVarChar, 24, "Fax"))
        '
        'sqlSelectCommand1
        '
        Me.sqlSelectCommand1.CommandText = "SELECT CustomerID, CompanyName, ContactName, ContactTitle, Address, City, Region," & _
        " PostalCode, Country, Phone, Fax FROM Customers"
        Me.sqlSelectCommand1.Connection = Me.sqlConnection1
        '
        'sqlUpdateCommand1
        '
        Me.sqlUpdateCommand1.CommandText = "UPDATE Customers SET CustomerID = @CustomerID, CompanyName = @CompanyName, Contac" & _
        "tName = @ContactName, ContactTitle = @ContactTitle, Address = @Address, City = @" & _
        "City, Region = @Region, PostalCode = @PostalCode, Country = @Country, Phone = @P" & _
        "hone, Fax = @Fax WHERE (CustomerID = @Original_CustomerID) AND (Address = @Origi" & _
        "nal_Address OR @Original_Address IS NULL AND Address IS NULL) AND (City = @Origi" & _
        "nal_City OR @Original_City IS NULL AND City IS NULL) AND (CompanyName = @Origina" & _
        "l_CompanyName) AND (ContactName = @Original_ContactName OR @Original_ContactName" & _
        " IS NULL AND ContactName IS NULL) AND (ContactTitle = @Original_ContactTitle OR " & _
        "@Original_ContactTitle IS NULL AND ContactTitle IS NULL) AND (Country = @Origina" & _
        "l_Country OR @Original_Country IS NULL AND Country IS NULL) AND (Fax = @Original" & _
        "_Fax OR @Original_Fax IS NULL AND Fax IS NULL) AND (Phone = @Original_Phone OR @" & _
        "Original_Phone IS NULL AND Phone IS NULL) AND (PostalCode = @Original_PostalCode" & _
        " OR @Original_PostalCode IS NULL AND PostalCode IS NULL) AND (Region = @Original" & _
        "_Region OR @Original_Region IS NULL AND Region IS NULL); SELECT CustomerID, Comp" & _
        "anyName, ContactName, ContactTitle, Address, City, Region, PostalCode, Country, " & _
        "Phone, Fax FROM Customers WHERE (CustomerID = @CustomerID)"
        Me.sqlUpdateCommand1.Connection = Me.sqlConnection1
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CustomerID", System.Data.SqlDbType.NVarChar, 5, "CustomerID"))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CompanyName", System.Data.SqlDbType.NVarChar, 40, "CompanyName"))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ContactName", System.Data.SqlDbType.NVarChar, 30, "ContactName"))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ContactTitle", System.Data.SqlDbType.NVarChar, 30, "ContactTitle"))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Address", System.Data.SqlDbType.NVarChar, 60, "Address"))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@City", System.Data.SqlDbType.NVarChar, 15, "City"))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Region", System.Data.SqlDbType.NVarChar, 15, "Region"))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PostalCode", System.Data.SqlDbType.NVarChar, 10, "PostalCode"))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Country", System.Data.SqlDbType.NVarChar, 15, "Country"))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Phone", System.Data.SqlDbType.NVarChar, 24, "Phone"))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Fax", System.Data.SqlDbType.NVarChar, 24, "Fax"))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CustomerID", System.Data.SqlDbType.NVarChar, 5, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CustomerID", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Address", System.Data.SqlDbType.NVarChar, 60, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Address", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_City", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "City", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_CompanyName", System.Data.SqlDbType.NVarChar, 40, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CompanyName", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ContactName", System.Data.SqlDbType.NVarChar, 30, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ContactName", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ContactTitle", System.Data.SqlDbType.NVarChar, 30, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ContactTitle", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Country", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Country", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Fax", System.Data.SqlDbType.NVarChar, 24, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Fax", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Phone", System.Data.SqlDbType.NVarChar, 24, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Phone", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_PostalCode", System.Data.SqlDbType.NVarChar, 10, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PostalCode", System.Data.DataRowVersion.Original, Nothing))
        Me.sqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Region", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Region", System.Data.DataRowVersion.Original, Nothing))
        '
        'customerSet1
        '
        Me.customerSet1.DataSetName = "CustomerSet"
        Me.customerSet1.Locale = New System.Globalization.CultureInfo("en-US")
        Me.customerSet1.Namespace = "http://tempuri.org/CustomerSet.xsd"
        '
        'CurrencyForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(264, 238)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.statusBar1, Me.listBox1, Me.addButton, Me.startButton, Me.positionButton, Me.textBox1, Me.previousButton, Me.nextButton, Me.endButton, Me.textBox2, Me.updateButton, Me.deleteButton, Me.showButton})
        Me.Name = "CurrencyForm"
        Me.Text = "CurrencyForm"
        Me.ResumeLayout(False)

    End Sub

#End Region



    Private Sub CurrencyForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Custom format and parse the ContactTitle
        ' NOTE: subscribe to this before filling the data set
        Dim _binding As Binding = textBox1.DataBindings("Text")
        AddHandler _binding.Format, New ConvertEventHandler(AddressOf textbox1_Format)
        AddHandler _binding.Parse, New ConvertEventHandler(AddressOf textBox1_Parse)

        ' ' Create a sorting view
        ' Dim sortView As DataView = New DataView(customerSet1.Customers)
        ' sortView.Sort = "ContactTitle ASC, ContactName DESC"
        ' 
        ' ' Create a filtering view
        ' Dim filterView As DataView = New DataView(customerSet1.Customers)
        ' filterView.RowFilter = "ContactTitle = 'Owner'"
        '
        ' ' Bind to the view
        ' listBox1.DataSource = sortView
        ' listBox1.DisplayMember = "ContactTitleName"

        ' Set the sorting and filtering criteria of the default view
        customerSet1.Customers.DefaultView.Sort = "ContactName DESC"
        customerSet1.Customers.DefaultView.RowFilter = "ContactTitle = 'Owner'"

        ' Fill the data set
        customersAdapter.Fill(customerSet1, "Customers")

        ' 1. Bind to data + table.column (good!)
        ' textBox1.DataBindings.Add( _
        '   "Text", customerSet1, "Customers.ContactTitleName")

        ' 2. Bidn the table + column (BAD!)
        ' txtBox1.DataBindings.Add( _
        '   "Text", customerSet1.Customers, "ContactTitleName")
    End Sub

    Public Sub textBox1_Format(ByVal sender As Object, ByVal e As ConvertEventArgs)
        ' Show ContactTitle as all caps
        System.Diagnostics.Debug.Assert(e.DesiredType Is GetType(String))
        e.Value = e.Value.ToString().ToUpper()
    End Sub

    Public Sub textBox1_Parse(ByVal sender As Object, ByVal e As ConvertEventArgs)
        ' Convert ContactTitle to mixed case
        e.Value = MixedCase(e.Value.ToString())
    End Sub

    Shared Function IsAlpha(ByVal ch As Char) As Boolean
        Return (ch > "A" And ch <= "Z") Or (ch >= "a" And ch <= "z")
    End Function

    Public Function MixedCase(ByVal s As String) As String
        Dim sb As System.Text.StringBuilder = New System.Text.StringBuilder()
        Dim needInitialCap As Boolean = True
        Dim i As Integer = 0
        For i = 0 To s.Length
            If IsAlpha(s.Chars(i)) Then
                If needInitialCap Then
                    sb.Append(s.Chars(i).ToString().ToUpper())
                    needInitialCap = False
                Else
                    sb.Append(s.Chars(i).ToString().ToLower())
                End If
            Else
                sb.Append(s.Chars(i))
                needInitialCap = True
            End If

            i += 1
        Next
    End Function


    Private Sub positionButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles positionButton.Click
        ' Dim _binding As Binding = textBox1.DataBindings("Text")
        ' Dim manager As BindingManagerBase = _binding.BindingManagerBase
        Dim manager As BindingManagerBase = Me.BindingContext(customerSet1, "Customers")

        ' Get current position
        Dim pos As Integer = manager.Position
        MessageBox.Show(pos.ToString(), "Current Position")

        ' Check the binding manager
        Dim manager1 As BindingManagerBase = textBox1.DataBindings("Text").BindingManagerBase
        Dim manager2 As BindingManagerBase = textBox2.DataBindings("Text").BindingManagerBase
        Dim manager3 As BindingManagerBase = Me.BindingContext(customerSet1, "Customers")
        ' BAD!
        Dim manager4 As BindingManagerBase = Me.BindingContext(customerSet1.Customers)
        System.Diagnostics.Debug.Assert(manager1 Is manager2)
        System.Diagnostics.Debug.Assert(manager2 Is manager3)
        System.Diagnostics.Debug.Assert(Not (manager3 Is manager4))
    End Sub

    Private Sub startButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles startButton.Click
        ' Reset the position
        ' Dim _binding As Binding = textBox1.DataBindings("Text")
        ' Dim manager as BindingManagerBase = _binding.BindingManagerBase
        Dim manager As BindingManagerBase = Me.BindingContext(customerSet1, "Customers")
        manager.Position = 0
    End Sub

    Private Sub previousButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles previousButton.Click
        ' Decrement the position
        ' Dim _binding As Binding = textBox1.DataBindings("Text")
        ' Dim manager as BindingManagerBase = _binding.BindingManagerBase
        Dim manager As BindingManagerBase = Me.BindingContext(customerSet1, "Customers")
        manager.Position -= 1
    End Sub

    Private Sub nextButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles nextButton.Click
        ' Increment the position
        ' Dim _binding As Binding = textBox1.DataBindings("Text")
        ' Dim manager as BindingManagerBase = _binding.BindingManagerBase
        Dim manager As BindingManagerBase = Me.BindingContext(customerSet1, "Customers")
        manager.Position += 1
    End Sub

    Private Sub endButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles endButton.Click
        ' Set position to end
        ' Dim _binding As Binding = textBox1.DataBindings("Text")
        ' Dim manager as BindingManagerBase = _binding.BindingManagerBase
        Dim manager As BindingManagerBase = Me.BindingContext(customerSet1, "Customers")
        manager.Position = manager.Count - 1
    End Sub

    Private Sub addButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles addButton.Click
        ' Add a new row
        Dim row As CustomerSet.CustomersRow = Me.customerSet1.Customers.NewCustomersRow()
        row.CustomerID = "SELLSDB"
        row.CompanyName = "Sells Brothers, Inc."
        row.ContactName = "Chris Sells"
        row.ContactTitle = "Chief Cook and Bottle Washer"
        row.Address = "555 Not My Street"
        row.City = "Beaverton"
        row.CustRegion = "OR"
        row.PostalCode = "97007"
        row.Country = "USA"
        row.Phone = "503-555-1234"
        row.Fax = "503-555-4321"
        Me.customerSet1.Customers.AddCustomersRow(row)

        ' Controls automatically updated
        ' (except some controls, e.g. listbox, need a nudge)
        Dim manager As CurrencyManager = Me.BindingContext(customerSet1, "Customers")
        If Not manager Is Nothing Then manager.Refresh()
    End Sub

    Private Sub updateButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles updateButton.Click
        ' Update the current row
        Dim manager As BindingManagerBase = Me.BindingContext(customerSet1, "Customers")
        Dim view As DataRowView = CType(manager.Current, DataRowView)
        Dim row As CustomerSet.CustomersRow = CType(view.Row, CustomerSet.CustomersRow)
        row.ContactTitle = "CEO"

        ' Controls automatically updated
    End Sub

    Private Sub deleteButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles deleteButton.Click
        ' Mark the current row as deleted
        Dim manager As BindingManagerBase = Me.BindingContext(customerSet1, "Customers")
        Dim view As DataRowView = CType(manager.Current, DataRowView)
        Dim row As CustomerSet.CustomersRow = CType(view.Row, CustomerSet.CustomersRow)
        row.Delete()

        ' Controls automatically updated
        ' (no special treatment needed to avoid deleted rows!)
    End Sub

    Private Sub showButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles showButton.Click
        ' Get the binding manager
        Dim manager As BindingManagerBase = Me.BindingContext(customerSet1, "Customers")

        ' Get the current row via the view
        Dim view As DataRowView = CType(manager.Current, DataRowView)
        Dim row As CustomerSet.CustomersRow = CType(view.Row, CustomerSet.CustomersRow)

        MessageBox.Show(row.ContactTitleName, "Current Row")
    End Sub

    Private Sub textBox1_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles textBox1.Leave
        ' Force the current edit to end
        Dim manager As BindingManagerBase = Me.BindingContext(customerSet1, "Customers")
        manager.EndCurrentEdit()
        ' manager.CancelCurrentEdit()
    End Sub

    Private Sub listBox1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles listBox1.SelectedIndexChanged
        If listBox1.SelectedValue Is Nothing Then Exit Sub

        ' Get the currently selected row's CustomerID using ValueMember
        statusBar1.Text = "Selected CustomerID= " & listBox1.SelectedValue

        ' Get the currently selected row's CustomerID using current item
        Dim view As DataRowView = CType(listBox1.SelectedItem, DataRowView)
        Dim row As CustomerSet.CustomersRow = CType(view.Row, CustomerSet.CustomersRow)
        statusBar1.Text = "Selected CustomerID= " & row.CustomerID
    End Sub
End Class
