Public Class FullDataBinding
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents textBox7 As System.Windows.Forms.TextBox
    Friend WithEvents textBox6 As System.Windows.Forms.TextBox
    Friend WithEvents textBox5 As System.Windows.Forms.TextBox
    Friend WithEvents textBox4 As System.Windows.Forms.TextBox
    Friend WithEvents textBox3 As System.Windows.Forms.TextBox
    Friend WithEvents textBox2 As System.Windows.Forms.TextBox
    Friend WithEvents textBox1 As System.Windows.Forms.TextBox
    Friend WithEvents button4 As System.Windows.Forms.Button
    Friend WithEvents sqlDataAdapter1 As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents sqlSelectCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents sqlConnection1 As System.Data.SqlClient.SqlConnection
    Friend WithEvents button3 As System.Windows.Forms.Button
    Friend WithEvents button2 As System.Windows.Forms.Button
    Friend WithEvents groupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents groupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents dataGrid2 As System.Windows.Forms.DataGrid
    Friend WithEvents dataGrid1 As System.Windows.Forms.DataGrid
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents listBox1 As System.Windows.Forms.ListBox
    Friend WithEvents customerSet1 As DataGridsVB.CustomerSet


    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.textBox7 = New System.Windows.Forms.TextBox()
        Me.textBox6 = New System.Windows.Forms.TextBox()
        Me.textBox5 = New System.Windows.Forms.TextBox()
        Me.textBox4 = New System.Windows.Forms.TextBox()
        Me.textBox3 = New System.Windows.Forms.TextBox()
        Me.textBox2 = New System.Windows.Forms.TextBox()
        Me.textBox1 = New System.Windows.Forms.TextBox()
        Me.button4 = New System.Windows.Forms.Button()
        Me.sqlDataAdapter1 = New System.Data.SqlClient.SqlDataAdapter()
        Me.sqlSelectCommand1 = New System.Data.SqlClient.SqlCommand()
        Me.sqlConnection1 = New System.Data.SqlClient.SqlConnection()
        Me.button3 = New System.Windows.Forms.Button()
        Me.button2 = New System.Windows.Forms.Button()
        Me.groupBox1 = New System.Windows.Forms.GroupBox()
        Me.groupBox2 = New System.Windows.Forms.GroupBox()
        Me.dataGrid2 = New System.Windows.Forms.DataGrid()
        Me.dataGrid1 = New System.Windows.Forms.DataGrid()
        Me.button1 = New System.Windows.Forms.Button()
        Me.customerSet1 = New CustomerSet()
        Me.listBox1 = New System.Windows.Forms.ListBox()
        Me.groupBox1.SuspendLayout()
        Me.groupBox2.SuspendLayout()
        CType(Me.dataGrid2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dataGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'textBox7
        '
        Me.textBox7.Location = New System.Drawing.Point(317, 86)
        Me.textBox7.Name = "textBox7"
        Me.textBox7.Size = New System.Drawing.Size(124, 20)
        Me.textBox7.TabIndex = 27
        Me.textBox7.Text = ""
        '
        'textBox6
        '
        Me.textBox6.Location = New System.Drawing.Point(135, 86)
        Me.textBox6.Name = "textBox6"
        Me.textBox6.Size = New System.Drawing.Size(131, 20)
        Me.textBox6.TabIndex = 26
        Me.textBox6.Text = ""
        '
        'textBox5
        '
        Me.textBox5.Location = New System.Drawing.Point(317, 64)
        Me.textBox5.Name = "textBox5"
        Me.textBox5.Size = New System.Drawing.Size(124, 20)
        Me.textBox5.TabIndex = 25
        Me.textBox5.Text = ""
        '
        'textBox4
        '
        Me.textBox4.Location = New System.Drawing.Point(266, 64)
        Me.textBox4.Name = "textBox4"
        Me.textBox4.Size = New System.Drawing.Size(51, 20)
        Me.textBox4.TabIndex = 24
        Me.textBox4.Text = ""
        '
        'textBox3
        '
        Me.textBox3.Location = New System.Drawing.Point(135, 64)
        Me.textBox3.Name = "textBox3"
        Me.textBox3.Size = New System.Drawing.Size(131, 20)
        Me.textBox3.TabIndex = 23
        Me.textBox3.Text = ""
        '
        'textBox2
        '
        Me.textBox2.Location = New System.Drawing.Point(135, 41)
        Me.textBox2.Name = "textBox2"
        Me.textBox2.Size = New System.Drawing.Size(306, 20)
        Me.textBox2.TabIndex = 22
        Me.textBox2.Text = ""
        '
        'textBox1
        '
        Me.textBox1.Location = New System.Drawing.Point(135, 18)
        Me.textBox1.Name = "textBox1"
        Me.textBox1.Size = New System.Drawing.Size(306, 20)
        Me.textBox1.TabIndex = 21
        Me.textBox1.Text = ""
        '
        'button4
        '
        Me.button4.Location = New System.Drawing.Point(573, 11)
        Me.button4.Name = "button4"
        Me.button4.Size = New System.Drawing.Size(36, 22)
        Me.button4.TabIndex = 20
        Me.button4.Text = ">|"
        '
        'sqlDataAdapter1
        '
        Me.sqlDataAdapter1.SelectCommand = Me.sqlSelectCommand1
        Me.sqlDataAdapter1.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Customers", New System.Data.Common.DataColumnMapping(-1) {}), New System.Data.Common.DataTableMapping("Table1", "Orders", New System.Data.Common.DataColumnMapping(-1) {}), New System.Data.Common.DataTableMapping("Table2", "Order Details", New System.Data.Common.DataColumnMapping(-1) {})})
        '
        'sqlSelectCommand1
        '
        Me.sqlSelectCommand1.CommandText = "SELECT * FROM Customers;" & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & "SELECT * FROM Orders;" & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & "SELECT * FROM [Order Details];"
        Me.sqlSelectCommand1.Connection = Me.sqlConnection1
        '
        'sqlConnection1
        '
        Me.sqlConnection1.ConnectionString = "data source=MUNGO\NetSDK;initial catalog=Northwind;integrated security=SSPI;persi" & _
        "st security info=False;workstation id=MUNGO;packet size=4096"
        '
        'button3
        '
        Me.button3.Location = New System.Drawing.Point(536, 11)
        Me.button3.Name = "button3"
        Me.button3.Size = New System.Drawing.Size(37, 22)
        Me.button3.TabIndex = 19
        Me.button3.Text = ">>"
        '
        'button2
        '
        Me.button2.Location = New System.Drawing.Point(500, 11)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(36, 22)
        Me.button2.TabIndex = 18
        Me.button2.Text = "<<"
        '
        'groupBox1
        '
        Me.groupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.groupBox2, Me.dataGrid1})
        Me.groupBox1.Location = New System.Drawing.Point(10, 109)
        Me.groupBox1.Name = "groupBox1"
        Me.groupBox1.Size = New System.Drawing.Size(599, 318)
        Me.groupBox1.TabIndex = 17
        Me.groupBox1.TabStop = False
        Me.groupBox1.Text = "Orders"
        '
        'customerSet1
        '
        Me.customerSet1.DataSetName = "CustomerSet"
        Me.customerSet1.Locale = New System.Globalization.CultureInfo("en-US")
        Me.customerSet1.Namespace = "http://tempuri.org/CustomerSet.xsd"
        '
        'groupBox2
        '
        Me.groupBox2.Controls.AddRange(New System.Windows.Forms.Control() {Me.dataGrid2})
        Me.groupBox2.Location = New System.Drawing.Point(7, 151)
        Me.groupBox2.Name = "groupBox2"
        Me.groupBox2.Size = New System.Drawing.Size(585, 160)
        Me.groupBox2.TabIndex = 3
        Me.groupBox2.TabStop = False
        Me.groupBox2.Text = "Order Details"
        '
        'dataGrid2
        '
        Me.dataGrid2.AllowNavigation = False
        Me.dataGrid2.AlternatingBackColor = System.Drawing.Color.WhiteSmoke
        Me.dataGrid2.BackColor = System.Drawing.Color.Gainsboro
        Me.dataGrid2.BackgroundColor = System.Drawing.Color.DarkGray
        Me.dataGrid2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.dataGrid2.CaptionBackColor = System.Drawing.Color.DarkKhaki
        Me.dataGrid2.CaptionFont = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold)
        Me.dataGrid2.CaptionForeColor = System.Drawing.Color.Black
        Me.dataGrid2.DataMember = "CustomersOrders.OrdersOrderDetails"
        Me.dataGrid2.FlatMode = True
        Me.dataGrid2.Font = New System.Drawing.Font("Times New Roman", 9.0!)
        Me.dataGrid2.ForeColor = System.Drawing.Color.Black
        Me.dataGrid2.GridLineColor = System.Drawing.Color.Silver
        Me.dataGrid2.HeaderBackColor = System.Drawing.Color.Black
        Me.dataGrid2.HeaderFont = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold)
        Me.dataGrid2.HeaderForeColor = System.Drawing.Color.White
        Me.dataGrid2.LinkColor = System.Drawing.Color.DarkSlateBlue
        Me.dataGrid2.Location = New System.Drawing.Point(7, 23)
        Me.dataGrid2.Name = "dataGrid2"
        Me.dataGrid2.ParentRowsBackColor = System.Drawing.Color.LightGray
        Me.dataGrid2.ParentRowsForeColor = System.Drawing.Color.Black
        Me.dataGrid2.ReadOnly = True
        Me.dataGrid2.RowHeadersVisible = False
        Me.dataGrid2.SelectionBackColor = System.Drawing.Color.Firebrick
        Me.dataGrid2.SelectionForeColor = System.Drawing.Color.White
        Me.dataGrid2.Size = New System.Drawing.Size(570, 128)
        Me.dataGrid2.TabIndex = 2
        '
        'dataGrid1
        '
        Me.dataGrid1.AllowNavigation = False
        Me.dataGrid1.AlternatingBackColor = System.Drawing.Color.WhiteSmoke
        Me.dataGrid1.BackColor = System.Drawing.Color.Gainsboro
        Me.dataGrid1.BackgroundColor = System.Drawing.Color.DarkGray
        Me.dataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.dataGrid1.CaptionBackColor = System.Drawing.Color.DarkKhaki
        Me.dataGrid1.CaptionFont = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold)
        Me.dataGrid1.CaptionForeColor = System.Drawing.Color.Black
        Me.dataGrid1.DataMember = "CustomersOrders"
        Me.dataGrid1.FlatMode = True
        Me.dataGrid1.Font = New System.Drawing.Font("Times New Roman", 9.0!)
        Me.dataGrid1.ForeColor = System.Drawing.Color.Black
        Me.dataGrid1.GridLineColor = System.Drawing.Color.Silver
        Me.dataGrid1.HeaderBackColor = System.Drawing.Color.Black
        Me.dataGrid1.HeaderFont = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold)
        Me.dataGrid1.HeaderForeColor = System.Drawing.Color.White
        Me.dataGrid1.LinkColor = System.Drawing.Color.DarkSlateBlue
        Me.dataGrid1.Location = New System.Drawing.Point(7, 23)
        Me.dataGrid1.Name = "dataGrid1"
        Me.dataGrid1.ParentRowsBackColor = System.Drawing.Color.LightGray
        Me.dataGrid1.ParentRowsForeColor = System.Drawing.Color.Black
        Me.dataGrid1.ReadOnly = True
        Me.dataGrid1.RowHeadersVisible = False
        Me.dataGrid1.SelectionBackColor = System.Drawing.Color.Firebrick
        Me.dataGrid1.SelectionForeColor = System.Drawing.Color.White
        Me.dataGrid1.Size = New System.Drawing.Size(585, 121)
        Me.dataGrid1.TabIndex = 0
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(463, 11)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(37, 22)
        Me.button1.TabIndex = 16
        Me.button1.Text = "|<"
        '
        'listBox1
        '
        Me.listBox1.DisplayMember = "CompanyName"
        Me.listBox1.Location = New System.Drawing.Point(18, 18)
        Me.listBox1.Name = "listBox1"
        Me.listBox1.Size = New System.Drawing.Size(109, 69)
        Me.listBox1.TabIndex = 15
        '
        'FullDataBinding
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(613, 431)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.textBox5, Me.textBox4, Me.textBox3, Me.textBox2, Me.textBox1, Me.button4, Me.button3, Me.button2, Me.groupBox1, Me.button1, Me.listBox1, Me.textBox7, Me.textBox6})
        Me.Name = "FullDataBinding"
        Me.Text = "FullDataBinding"
        Me.groupBox1.ResumeLayout(False)
        Me.groupBox2.ResumeLayout(False)
        CType(Me.dataGrid2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dataGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub FullDataBinding_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        sqlDataAdapter1.Fill(customerSet1)
    End Sub


    Private Sub button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles button1.Click
        BindingContext(customerSet1.Customers).Position = 0
    End Sub

    Private Sub button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles button2.Click
        BindingContext(customerSet1.Customers).Position -= 1
    End Sub

    Private Sub button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles button3.Click
        BindingContext(customerSet1.Customers).Position += 1
    End Sub

    Private Sub button4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles button4.Click
        BindingContext(customerSet1.Customers).Position = BindingContext(customerSet1.Customers).Count - 1
    End Sub
End Class
