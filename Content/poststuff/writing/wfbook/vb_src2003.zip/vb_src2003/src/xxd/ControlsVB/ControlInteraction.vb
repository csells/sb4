Public Class ControlInteraction
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents groupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents axTabStrip1 As AxMSForms.AxTabStrip
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(ControlInteraction))
        Me.groupBox1 = New System.Windows.Forms.GroupBox()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.axTabStrip1 = New AxMSForms.AxTabStrip()
        CType(Me.axTabStrip1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'groupBox1
        '
        Me.groupBox1.Location = New System.Drawing.Point(7, 7)
        Me.groupBox1.Name = "groupBox1"
        Me.groupBox1.Size = New System.Drawing.Size(314, 212)
        Me.groupBox1.TabIndex = 1
        Me.groupBox1.TabStop = False
        Me.groupBox1.Text = "Hosting COM Components"
        '
        'ListBox1
        '
        Me.ListBox1.Location = New System.Drawing.Point(104, 0)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(8, 4)
        Me.ListBox1.TabIndex = 2
        '
        'axTabStrip1
        '
        Me.axTabStrip1.Location = New System.Drawing.Point(18, 28)
        Me.axTabStrip1.Name = "axTabStrip1"
        Me.axTabStrip1.OcxState = CType(resources.GetObject("axTabStrip1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.axTabStrip1.Size = New System.Drawing.Size(293, 171)
        Me.axTabStrip1.TabIndex = 3
        '
        'ControlInteraction
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(328, 227)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.axTabStrip1, Me.ListBox1, Me.groupBox1})
        Me.Name = "ControlInteraction"
        Me.Text = "ControlInteraction"
        CType(Me.axTabStrip1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

End Class
