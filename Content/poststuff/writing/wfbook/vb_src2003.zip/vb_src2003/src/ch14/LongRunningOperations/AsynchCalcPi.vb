Imports System.Text

Public Class AsynchCalcPi
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents piProgressBar As System.Windows.Forms.ProgressBar
    Friend WithEvents piTextBox As System.Windows.Forms.TextBox
    Friend WithEvents panel1 As System.Windows.Forms.Panel
    Friend WithEvents calcButton As System.Windows.Forms.Button
    Friend WithEvents digitsUpDown As System.Windows.Forms.NumericUpDown
    Friend WithEvents label1 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.piProgressBar = New System.Windows.Forms.ProgressBar()
        Me.piTextBox = New System.Windows.Forms.TextBox()
        Me.panel1 = New System.Windows.Forms.Panel()
        Me.calcButton = New System.Windows.Forms.Button()
        Me.digitsUpDown = New System.Windows.Forms.NumericUpDown()
        Me.label1 = New System.Windows.Forms.Label()
        Me.panel1.SuspendLayout()
        CType(Me.digitsUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'piProgressBar
        '
        Me.piProgressBar.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.piProgressBar.Location = New System.Drawing.Point(0, 143)
        Me.piProgressBar.Maximum = 1
        Me.piProgressBar.Name = "piProgressBar"
        Me.piProgressBar.Size = New System.Drawing.Size(232, 23)
        Me.piProgressBar.TabIndex = 5
        '
        'piTextBox
        '
        Me.piTextBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.piTextBox.Location = New System.Drawing.Point(0, 40)
        Me.piTextBox.Multiline = True
        Me.piTextBox.Name = "piTextBox"
        Me.piTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.piTextBox.Size = New System.Drawing.Size(232, 126)
        Me.piTextBox.TabIndex = 4
        Me.piTextBox.Text = "3"
        '
        'panel1
        '
        Me.panel1.Controls.AddRange(New System.Windows.Forms.Control() {Me.calcButton, Me.digitsUpDown, Me.label1})
        Me.panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.panel1.Name = "panel1"
        Me.panel1.Size = New System.Drawing.Size(232, 40)
        Me.panel1.TabIndex = 3
        '
        'calcButton
        '
        Me.calcButton.Location = New System.Drawing.Point(144, 8)
        Me.calcButton.Name = "calcButton"
        Me.calcButton.TabIndex = 2
        Me.calcButton.Text = "Calc"
        '
        'digitsUpDown
        '
        Me.digitsUpDown.Location = New System.Drawing.Point(80, 8)
        Me.digitsUpDown.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.digitsUpDown.Name = "digitsUpDown"
        Me.digitsUpDown.Size = New System.Drawing.Size(56, 20)
        Me.digitsUpDown.TabIndex = 1
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(8, 8)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(64, 23)
        Me.label1.TabIndex = 0
        Me.label1.Text = "Digits of Pi"
        '
        'AsynchCalcPi
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(232, 166)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.piProgressBar, Me.piTextBox, Me.panel1})
        Me.Name = "AsynchCalcPi"
        Me.Text = "Digits of Pi"
        Me.panel1.ResumeLayout(False)
        CType(Me.digitsUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region


    Public Enum CalcState
        Pending
        Calculating
        Canceled
    End Enum

    Public state As CalcState = CalcState.Pending

    Public Class ShowProgressArgs
        Inherits EventArgs

        Public Pi As String
        Public TotalDigits As Integer
        Public DigitsSoFar As Integer
        Public Cancel As Boolean

        Public Sub New(ByVal sPi As String, ByVal iTotalDigits As Integer, ByVal iDigitsSoFar As Integer)
            Me.Pi = sPi
            Me.TotalDigits = iTotalDigits
            Me.DigitsSoFar = iDigitsSoFar
        End Sub
    End Class

    Delegate Sub ShowProgessHandler(ByVal sender As Object, ByVal e As ShowProgressArgs)

    Public Sub ShowProgress(ByVal sender As Object, ByVal e As ShowProgressArgs)
        ' Make sure we're on the UI thread
        If Me.InvokeRequired = False Then
            piTextBox.Text = e.Pi
            piProgressBar.Maximum = e.TotalDigits
            piProgressBar.Value = e.DigitsSoFar

            ' Check for cancel
            e.Cancel = (state = CalcState.Canceled)

            ' Check for completion
            If e.Cancel OrElse (e.DigitsSoFar = e.TotalDigits) Then
                state = CalcState.Pending
                calcButton.Text = "Calc"
                calcButton.Enabled = True
            End If
        Else ' Transfer control to the UI thread
            Dim myShowProgress As ShowProgessHandler = New ShowProgessHandler(AddressOf ShowProgress)
            Invoke(myShowProgress, New Object() {sender, e})
        End If
    End Sub

    Public Sub CalcPi(ByVal digits As Integer)
        Dim pi As StringBuilder = New StringBuilder("3", digits + 2)
        Dim sender As Object = System.Threading.Thread.CurrentThread
        Dim e As ShowProgressArgs = New ShowProgressArgs(pi.ToString(), digits, 0)

        ' Show progress (ignoring Cancel so soon)
        ShowProgress(sender, e)

        If digits > 0 Then
            pi.Append(".")

            Dim i As Integer
            For i = 0 To digits - 1 Step 9
                Dim nineDigits As Integer = NineDigitsOfPi.StartingAt(i + 1)
                Dim digitCount As Integer = Math.Min(digits - i, 9)
                Dim ds As String = String.Format("{0:D9}", nineDigits)
                pi.Append(ds.Substring(0, digitCount))

                ' Show progress (checking for cancel)
                e.Pi = pi.ToString()
                e.DigitsSoFar = i + digitCount
                ShowProgress(sender, e)
                If e.Cancel Then Return
            Next
        End If
    End Sub

    Delegate Sub CalcPiDelegate(ByVal digits As Integer)

    Private Sub calcButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles calcButton.Click
        ' Synch method
        '       CalcPi(CInt(digitsUpDown.Value))
        '       return

        ' Calc button does double duty as Cancel button
        Select Case state
            ' Start a new calculation
        Case CalcState.Pending
                ' Allow cancelling
                state = CalcState.Calculating
                calcButton.Text = "Cancel"

                ' Asynch delegate method
                Dim asynchCalcPi As CalcPiDelegate = New CalcPiDelegate(AddressOf CalcPi)
                asynchCalcPi.BeginInvoke(CInt(digitsUpDown.Value), Nothing, Nothing)

                ' Cancel a running calculation
            Case CalcState.Calculating
                state = CalcState.Canceled
                calcButton.Enabled = False

                ' Shouldn't be able to press calc button while it's canceling
            Case CalcState.Canceled
                Debug.Assert(False)

        End Select
    End Sub
End Class
