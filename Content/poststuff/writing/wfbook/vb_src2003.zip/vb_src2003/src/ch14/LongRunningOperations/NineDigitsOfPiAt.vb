' NineDigitsOfPiAt.cs

'
' Computation of the n'th decimal digit of pi with very little memory.
' Written by Fabrice Bellard on January 8, 1997.
' Ported to C# by Chris Sells on May 5, 2002.
' Ported to VB.NET by Justin Gehtland on May 27, 2002
' 
' We use a slightly modified version of the method described by Simon
' Plouffe in "On the Computation of the n'th decimal digit of various
' transcendental numbers" (November 1996). We have modified the algorithm
' to get a running time of O(n^2) instead of O(n^3log(n)^3).
' 
' This program uses mostly integer arithmetic. It may be slow on some
' hardwares where integer multiplications and divisons must be done
' by software.
'
Public Class NineDigitsOfPi
    Public Shared Function mul_mod(ByVal a As Long, ByVal b As Long, ByVal m As Integer) As Integer
        Return CInt((a * b) Mod m)
    End Function

    ' return the inverse of x and y
    Public Shared Function inv_mod(ByVal x As Integer, ByVal y As Integer) As Integer
        Dim q As Integer = 0
        Dim u As Integer = x
        Dim v As Integer = y
        Dim a As Integer = 0
        Dim c As Integer = 1
        Dim t As Integer = 0

        Do
            q = CInt(Math.Floor(v / u))
            t = c
            c = a - q * c
            a = t

            t = u
            u = v - q * u
            v = t
        Loop While u <> 0

        a = a Mod y
        If a < 0 Then a = y + a

        Return a
    End Function

    ' return (a^b) mod m
    Public Shared Function pow_mod(ByVal a As Integer, ByVal b As Integer, ByVal m As Integer) As Integer
        Dim r As Integer = 1
        Dim aa As Integer = a

        While True
            If ((b And &H1) <> 0) Then r = mul_mod(r, aa, m)
            b = b >> 1
            If (b = 0) Then Exit While
            aa = mul_mod(aa, aa, m)
        End While

        Return r
    End Function

    ' return true if n is prime
    Public Shared Function is_prime(ByVal n As Integer) As Boolean
        If ((n Mod 2) = 0) Then Return False

        Dim r As Integer = CInt(Math.Sqrt(n))
        Dim i As Integer
        For i = 3 To r Step 2
            If ((n Mod i) = 0) Then Return False
        Next

        Return True
    End Function

    ' return the prime number immediately after n
    Public Shared Function next_prime(ByVal n As Integer) As Integer
        Do
            n = n + 1
        Loop While Not is_prime(n)

        Return n
    End Function

    Public Shared Function StartingAt(ByVal n As Integer) As Integer
        Dim av As Integer = 0
        Dim vmax As Integer = 0
        Dim nN As Integer = CInt((n + 20) * Math.Log(10) / Math.Log(2)) - 1
        Dim num As Integer = 0
        Dim den As Integer = 0
        Dim kq As Integer = 0
        Dim kq2 As Integer = 0
        Dim t As Integer = 0
        Dim v As Integer = 0
        Dim s As Integer = 0
        Dim sum As Double = 0.0

        Dim a As Integer = 3
        Do While a <= 2 * nN
            vmax = CInt(Math.Log(2 * nN) / Math.Log(a))
            av = 1

            Dim i As Integer
            For i = 0 To vmax - 1
                av = av * a
            Next

            s = 0
            num = 1
            den = 1
            v = 0
            kq = 1
            kq2 = 1

            Dim k As Integer
            For k = 1 To nN
                t = k
                If (kq >= a) Then
                    Do
                        t = CInt(Math.Floor(t / a))
                        v = v - 1
                    Loop While ((t Mod a) = 0)

                    kq = 0
                End If

                kq = kq + 1
                num = mul_mod(num, t, av)

                t = 2 * k - 1
                If kq2 >= a Then
                    If kq2 = a Then
                        Do
                            t = CInt(Math.Floor(t / a))
                            v = v + 1
                        Loop While ((t Mod a) = 0)

                    End If
                    kq2 = kq2 - a

                End If

                den = mul_mod(den, t, av)
                kq2 = kq2 + 2

                If v > 0 Then
                    t = inv_mod(den, av)
                    t = mul_mod(t, num, av)
                    t = mul_mod(t, k, av)
                    Dim j As Integer
                    For j = v To vmax - 1
                        t = mul_mod(t, a, av)
                    Next
                    s = s + t
                    If s >= av Then s = s - av
                End If


            Next

            t = pow_mod(10, n - 1, av)
            s = mul_mod(s, t, av)
            sum = (sum + CDbl(s) / CDbl(av)) Mod 1.0

            a = next_prime(a)
        Loop

        Return CInt(sum * 1000000000.0)

    End Function
End Class
