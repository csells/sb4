Public Class CustomControl1
    Inherits Control

    Public Sub New()

    End Sub

    Protected Overrides Sub OnPaint(ByVal e As System.Windows.Forms.PaintEventArgs)
        ' TODO: Add custom paint code here

        ' Calling the base class OnPaint
        MyBase.OnPaint(e)
    End Sub
End Class
