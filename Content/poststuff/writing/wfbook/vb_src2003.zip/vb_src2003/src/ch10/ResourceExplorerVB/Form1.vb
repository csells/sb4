Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.IO ' FileStream
Imports System.Reflection ' Assembly
Imports System.Resources ' Resource readers

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents fileOpenMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents helpAboutMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents statusBar1 As System.Windows.Forms.StatusBar
    Friend WithEvents menuItem5 As System.Windows.Forms.MenuItem
    Friend WithEvents fileExitMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents openFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents resourcesTreeView As System.Windows.Forms.TreeView
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.fileOpenMenuItem = New System.Windows.Forms.MenuItem()
        Me.helpAboutMenuItem = New System.Windows.Forms.MenuItem()
        Me.statusBar1 = New System.Windows.Forms.StatusBar()
        Me.menuItem5 = New System.Windows.Forms.MenuItem()
        Me.fileExitMenuItem = New System.Windows.Forms.MenuItem()
        Me.openFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu()
        Me.menuItem1 = New System.Windows.Forms.MenuItem()
        Me.menuItem3 = New System.Windows.Forms.MenuItem()
        Me.resourcesTreeView = New System.Windows.Forms.TreeView()
        Me.SuspendLayout()
        '
        'fileOpenMenuItem
        '
        Me.fileOpenMenuItem.Index = 0
        Me.fileOpenMenuItem.Shortcut = System.Windows.Forms.Shortcut.CtrlO
        Me.fileOpenMenuItem.Text = "&Open..."
        '
        'helpAboutMenuItem
        '
        Me.helpAboutMenuItem.Index = 0
        Me.helpAboutMenuItem.Text = "&About..."
        '
        'statusBar1
        '
        Me.statusBar1.Location = New System.Drawing.Point(0, 192)
        Me.statusBar1.Name = "statusBar1"
        Me.statusBar1.Size = New System.Drawing.Size(472, 22)
        Me.statusBar1.TabIndex = 3
        '
        'menuItem5
        '
        Me.menuItem5.Index = 1
        Me.menuItem5.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.helpAboutMenuItem})
        Me.menuItem5.Text = "&Help"
        '
        'fileExitMenuItem
        '
        Me.fileExitMenuItem.Index = 2
        Me.fileExitMenuItem.Text = "E&xit"
        '
        'openFileDialog1
        '
        Me.openFileDialog1.Filter = "Resource Files (*.exe, *.dll, *.resx, *.resources)|*.exe;*.dll;*.resx;*.resources" & _
        "|All Files (*.*)|*.*"
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1, Me.menuItem5})
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.fileOpenMenuItem, Me.menuItem3, Me.fileExitMenuItem})
        Me.menuItem1.Text = "&File"
        '
        'menuItem3
        '
        Me.menuItem3.Index = 1
        Me.menuItem3.Text = "-"
        '
        'resourcesTreeView
        '
        Me.resourcesTreeView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.resourcesTreeView.ImageIndex = -1
        Me.resourcesTreeView.Name = "resourcesTreeView"
        Me.resourcesTreeView.SelectedImageIndex = -1
        Me.resourcesTreeView.Size = New System.Drawing.Size(472, 214)
        Me.resourcesTreeView.Sorted = True
        Me.resourcesTreeView.TabIndex = 2
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(472, 214)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.statusBar1, Me.resourcesTreeView})
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "Resource Explorer"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Sub LoadResourcesFromFile(ByVal fileName As String)
        resourcesTreeView.Nodes.Clear()
        Dim root As TreeNode = resourcesTreeView.Nodes.Add(Path.GetFileName(fileName))

        Select Case System.IO.Path.GetExtension(fileName).ToLower()
            Case ".exe", ".dll"
                LoadResourcesFromAssemblyFile(root, fileName)
            Case ".resx"
                LoadResourcesFromResxFile(root, fileName)
            Case ".resources"
                LoadResourcesFromResourcesFile(root, fileName)
            Case Else
                MessageBox.Show("Unknown file format")
        End Select

        root.Expand()
    End Sub

    Sub LoadResourcesFromAssemblyFile(ByVal parent As TreeNode, ByVal fileName As String)
        Dim assem As [Assembly] = [Assembly].LoadFrom(fileName)
        Dim resourceName As String
        For Each resourceName In assem.GetManifestResourceNames
            Dim node As TreeNode = parent.Nodes.Add(resourceName)
            If resourceName.ToLower().EndsWith(".resources") Then
                Dim s As Stream = assem.GetManifestResourceStream(resourceName)
                LoadResourcesFromResourcesStream(node, s)
                s.Close()
            End If
        Next
    End Sub

    Sub LoadResourcesFromResxFile(ByVal parent As TreeNode, ByVal fileName As String)
        Dim reader As ResXResourceReader = New ResXResourceReader(fileName)
        Dim entry As DictionaryEntry
        For Each entry In reader
            Dim node As TreeNode = parent.Nodes.Add(String.Format("{0} ({1})", entry.Key.ToString(), entry.Value.GetType()))
            node.Tag = entry.Value
        Next
        reader.Close()
    End Sub

    Sub LoadResourcesFromResourcesFile(ByVal parent As TreeNode, ByVal fileName As String)
        Dim s As FileStream = New FileStream(fileName, FileMode.Open, FileAccess.Read)
        LoadResourcesFromResourcesStream(parent, s)
        s.Close()
    End Sub

    Sub LoadResourcesFromResourcesStream(ByVal parent As TreeNode, ByVal s As Stream)
        Dim reader As ResourceReader = New ResourceReader(s)
        Dim entry As DictionaryEntry
        For Each entry In reader
            Dim node As TreeNode = parent.Nodes.Add(String.Format("{0} ({1})", entry.Key.ToString(), IIf(Not entry.Value Is Nothing, entry.Value.GetType().ToString(), "<none>")))
            node.Tag = entry.Value
        Next
        reader.Close()
    End Sub

    Sub ShowSelectedNode()
        Dim node As TreeNode = resourcesTreeView.SelectedNode
        If node Is Nothing Then Exit Sub
        ' TODO: Show the contents
        'MessageBox.Show(node.Text)

    End Sub

    Private Sub fileOpenMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles fileOpenMenuItem.Click
        If openFileDialog1.ShowDialog = DialogResult.OK Then
            LoadResourcesFromFile(openFileDialog1.FileName)
        End If
    End Sub

    Private Sub fileExitMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles fileExitMenuItem.Click
        Me.Close()
    End Sub

    Private Sub helpAboutMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles helpAboutMenuItem.Click
        MessageBox.Show("From the Chris Sells and Justin Gehtland Winforms book(s)" & vbCrLf & "Enjoy")

    End Sub

    Private Sub resourcesTreeView_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles resourcesTreeView.DoubleClick
        ShowSelectedNode()
    End Sub

    Private Sub resourcesTreeView_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles resourcesTreeView.KeyDown
        If Me Is Form.ActiveForm And (e.KeyCode And Keys.Enter = Keys.Enter) Then ShowSelectedNode()
    End Sub

    Private Sub resourcesTreeView_AfterSelect(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles resourcesTreeView.AfterSelect
        statusBar1.Text = ""
        Dim node As TreeNode = resourcesTreeView.SelectedNode
        If node Is Nothing Then Exit Sub
        Dim value As Object = node.Tag
        If value Is Nothing Then Exit Sub
        statusBar1.Text = value.ToString()
    End Sub
End Class
