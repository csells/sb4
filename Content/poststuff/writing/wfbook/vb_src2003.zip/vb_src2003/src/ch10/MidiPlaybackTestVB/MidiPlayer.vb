' A simple wrapper around the DirectX 7 MIDI-playback service
' NOTE: I'm using DX7 instead of DX8 because DX7 works on DX8 machines, but not vice versa

Imports System
Imports System.ComponentModel
Imports System.Runtime.InteropServices
Imports DxVBLib


Public Class MidiPlayer
    Inherits System.ComponentModel.Component

    Private dx As DirectX7 = New DirectX7Class()
    Private loader As DirectMusicLoader
    Private perf As DirectMusicPerformance
    Private seg As DirectMusicSegment
    Private segstate As DirectMusicSegmentState

#Region " Component Designer generated code "

    

    Public Sub New()
        ' A loader object is what parses the data from a file
        ' on the hard drive to the area in memory
        loader = dx.DirectMusicLoaderCreate

        ' A performance controls the music. It looks after
        ' sending data to the music port, setting options
        ' converting time sigs. etc...
        ' A performance is what organises the events
        ' think of it as a conductor - syncronising things
        ' setting things up; looking after the individual pieces
        ' of music.
        perf = dx.DirectMusicPerformanceCreate

        ' Set its options - these options should be standard
        ' across most projects
        perf.Init(Nothing, 0)
        perf.SetPort(-1, 80)
        perf.SetMasterAutoDownload(True)

        Volume = 75

    End Sub

 

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal isManagedDispose As Boolean)
        ' Otherwise, it's the finalizer firing and all
        ' of our managed references will be handled for us
        If isManagedDispose Then
            PlayStop()

            If Not perf Is Nothing Then
                perf.CloseDown()

                If Not seg Is Nothing Then
                    Marshal.ReleaseComObject(seg)
                    seg = Nothing
                End If

                Marshal.ReleaseComObject(perf)
                perf = Nothing
            End If
        End If

        ' Let the base class have a chance, too
        MyBase.Dispose(isManagedDispose)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
    End Sub

#End Region
    Public WriteOnly Property Volume() As Integer
        Set(ByVal Value As Integer)
            ' The value can be any number between 0 (mute) and 100 (max)
            ' The formula just uses this number to create a volume DM can understand
            If Value < 0 Or Value > 100 Then Throw New ApplicationException("Volume must be between 0 and 100")
            perf.SetMasterVolume(Value * 42 - 3000)
        End Set
    End Property

    Public Sub LoadFromFile(ByVal filename As String)
        ' A segment is where the actual data is stored;
        ' like a buffer or a surface in other DirectX objects
        ' Use the loader object to create us a music buffer
        ' NOTE: needs to be of type "DMSEG"
        seg = loader.LoadSegment(filename)

        ' Set the format of the segment to be a MIDI
        seg.SetStandardMidiFile()
    End Sub

    ' TODO: Need to support numeric IDs, too
    ' (i.e. using a managed implementation of MAKEINTRESOURCE)
    Public Sub LoadFromResource(ByVal filename As String, ByVal id As String)
        ' NOTE: if this fails, try passing in the ID as upper case
        seg = loader.LoadSegmentFromResource(filename, id)
        seg.SetStandardMidiFile()
    End Sub

    Public Sub Start()
        If seg Is Nothing Then Throw New ApplicationException("Must load a MIDI resource before starting")

        ' Make sure we're stopped before starting
        PlayStop()

        ' This variable lets us know what the music is
        ' doing. At the simplest level this is "am I playing?"
        ' "am i stopped?" etc.
        ' This is all it takes to start playing.
        ' The last variable states where to start playing from;
        ' in this case "0", which means the beginning.
        segstate = perf.PlaySegment(seg, 0, 0)
    End Sub

    Public Sub PlayStop()
        If Not perf Is Nothing Then
            perf.Stop(seg, segstate, 0, 0)
            If Not segstate Is Nothing Then
                Marshal.ReleaseComObject(segstate)
                segstate = Nothing
            End If
        End If
    End Sub



End Class
