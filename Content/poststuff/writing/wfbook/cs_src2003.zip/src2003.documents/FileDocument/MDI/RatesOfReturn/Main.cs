using System;
using System.IO;
using System.Windows.Forms;
using Microsoft.Win32; // Registry

namespace RatesOfReturn {
  class App {
    [STAThread]
    static void Main(string[] args) {
      // Check command line
      if( args.Length > 1 ) {
        MessageBox.Show("usage: ratesOfReturn.exe [file]", "RatesOfReturn");
        return;
      }

      // Register custom extension with the shell
      using( RegistryKey key =
               Registry.ClassesRoot.CreateSubKey(".ror") ) {
        // Map custom  extension to a ProgID
        key.SetValue(null, "rorfile");
      }

      // Register open command with the shell
      string cmdkey = @"rorfile\shell\open\command";
      using( RegistryKey key =
               Registry.ClassesRoot.CreateSubKey(cmdkey) ) {
        // Map ProgID to an Open action for the shell
        key.SetValue(null, Application.ExecutablePath + " \"%L\"");
      }

      //      // Register document icon with the shell
      //      string icokey = @"rorfile\DefaultIcon";
      //      using( RegistryKey key =
      //               Registry.ClassesRoot.CreateSubKey(icokey) ) {
      //        // Map ProgID to a document icon for the shell
      //        key.SetValue(null, @"%SystemRoot%\system32\shell32.dll,-10");
      //      }

      // Load main form, taking command line into account
      MdiParentForm form = new MdiParentForm();
      if( args.Length == 1 ) {
        form.OpenDocument(Path.GetFullPath(args[0]));
      }

      Application.Run(form);
    }
  }
}
