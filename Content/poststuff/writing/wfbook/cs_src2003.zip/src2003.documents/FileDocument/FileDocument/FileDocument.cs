// FileDocument.cs: Contributed by Chris Sells [csells@sellsbrothers.com]
// A helper for dirty bit/current file name management
#region Copyright � 2002-2003 The Genghis Group
/*
 * This software is provided 'as-is', without any express or implied warranty.
 * In no event will the authors be held liable for any damages arising from the
 * use of this software.
 * 
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, subject to the following restrictions:
 * 
 * 1. The origin of this software must not be misrepresented; you must not claim
 * that you wrote the original software. If you use this software in a product,
 * an acknowledgment in the product documentation is required, as shown here:
 * 
 * Portions Copyright � 2002-2003 The Genghis Group (http://www.genghisgroup.com/).
 * 
 * 2. No substantial portion of the source code of this library may be redistributed
 * without the express written permission of the copyright holders, where
 * "substantial" is defined as enough code to be recognizably from this library. 
*/
#endregion
#region Limitations
// -Doesn't support multiple views of the same file document
#endregion
#region TODO
//  -watch for re-opening already open file (needed for MDI and single-instance apps)
//  -register print command in shell
//  -register custom shell actions?
//  -reflect shell setting to "hide extensions for known file types" in the caption
//  -integrate with the MRU list
//  -escape & in captions for MDI Window menu?
//  -delay updating caption while newing, opening, saving, etc. even if container
//   sets dirty bit while data being read, so that dirty bit doesn't flash at user
//   during open
//  -when a FileDocument is first initialized, it fires NewDocument, regardless
//   of whether a LoadDocument is coming or not. However, when Open is called on
//   the FileDocument, it doesn't fire the NewDocument event, which means that
//   sometimes NewDocument+ReadDocument are fired in succession and sometimes
//   just ReadDocument is fired. Is this a problem?
#endregion

using System;
using System.IO;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Diagnostics;
using System.Windows.Forms;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using Microsoft.Win32; // Registry
using System.Runtime.InteropServices;
using System.Reflection;

namespace Genghis.Windows.Forms {
  public class FileDocument : Component, ISupportInitialize {
    public FileDocument() : this(null) {
    }

    public FileDocument(IContainer container) {
      // Integrate with container
      if( container != null ) container.Add(this);

      // Required for Designer support
      InitializeComponent();
    }

    #region Windows Form Designer generated code
    private void InitializeComponent() {
      this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
      this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
      // 
      // saveFileDialog
      // 
      this.saveFileDialog.FileName = "doc1";

    }
    #endregion

    #region Public Events
    public event EventHandler DocumentChanged;
    public event EventHandler NewDocument;
    public event SerializeDocumentEventHandler WriteDocument;
    public event SerializeDocumentEventHandler ReadDocument;
    #endregion

    #region Public Properties
    [DefaultValue(null)]
    [Browsable(false)]
    public object Data {
      get { return this.data; }
      set { this.data = value; }
    }

    // TODO: Check for data to expose Changed event to update this automatically
    [DefaultValue(false)]
    [Browsable(false)]
    public bool Dirty {
      get { return this.dirty; }
      set {
        Debug.Assert(this.Site != null);
    
        // If we're being set to dirty, that implies change (even if we're already dirty)
        if( this.dirty && this.DocumentChanged != null ) this.DocumentChanged(this, EventArgs.Empty);

        // No need to update caption if we're already at this state
        if( this.dirty == value ) return;
        this.dirty = value;
        SetCaption();
      }
    }

    [DefaultValue(null)]
    [Browsable(false)]
    public string FileName {
      get { return this.fileName; }
      set {
        // No need to update caption if we're already at this state
        if( this.fileName == value ) return;
        this.fileName = value;
        SetCaption();
      }
    }

    [DefaultValue(null)]
    public string DefaultExt {
      get { return this.defaultExt; }

      set {
        this.defaultExt = value;
        if( Empty(defaultExt) ) return;

        // Drop leading dot
        while( this.defaultExt.StartsWith(".") ) this.defaultExt = this.defaultExt.Substring(1);
      }
    }

    [DefaultValue(null)]
    public string DefaultExtDescription {
      get { return this.defaultExtDesc; }
      set { this.defaultExtDesc = value; }
    }

    [DefaultValue(null)]
    [Description("e.g \"C# files (*.cs)|*.cs|All files (*.*)|*.*\"")]
    public string Filter {
      get {
        // Cruft up a filter if none has been set at design-time
        if( Empty(this.filter) && !Empty(this.defaultExt) && !DesignMode ) {
          return string.Format("{0} files (*.{1})|*.{1}|All files|*.*", Application.ProductName, defaultExt);
        }

        return this.filter;
      }

      set {
        this.filter = value;
      }
    }

    // From Ian Griffiths (thanks, Ian!)
    [Browsable(false)]
    public Form HostingForm {
      get {
        if( (host == null) && this.DesignMode ) {
          // See if we're being hosted in VS.NET (or something similar)
          IDesignerHost designer = this.GetService(typeof(IDesignerHost)) as IDesignerHost;
          if( designer != null ) host = designer.RootComponent as Form;
        }

        return host;
      }

      set {
        // Detach from host's Load/Closing event
        if( host != null ) {
          host.Closing -= new CancelEventHandler(host_Closing);
        }

        // Cache the hosting form
        host = value;

        // Attach to host's Load/Closing event
        if( host != null ) {
          // To refresh caption in MDI child case
          host.Load += new EventHandler(host_Load);

          // To handle dirty bit
          host.Closing += new CancelEventHandler(host_Closing);
        }

        // Set the host's caption
        SetCaption();
      }
    }

    [DefaultValue(false)]
    public bool RegisterDefaultExtensionWithShell {
      get { return this.registerDefaultExt; }
      set { this.registerDefaultExt = value; }
    }

    static void SetMenuItem(ref MenuItem thisItem, MenuItem newItem, EventHandler click) {
      // Unhook from the old one
      if( thisItem != null ) thisItem.Click -= click;

      // Hook to the new one
      thisItem = newItem;
      if( thisItem != null ) thisItem.Click += click;
    }

    [DefaultValue(null)]
    public MenuItem FileNewMenuItem {
      get { return this.fileNewMenuItem; }
      set {
        SetMenuItem(ref this.fileNewMenuItem, value, new EventHandler(fileNewMenuItem_Click));
      }
    }

    [DefaultValue(null)]
    public MenuItem FileOpenMenuItem {
      get { return this.fileOpenMenuItem; }
      set {
        SetMenuItem(ref this.fileOpenMenuItem, value, new EventHandler(fileOpenMenuItem_Click));
      }
    }

    [DefaultValue(null)]
    public MenuItem FileSaveMenuItem {
      get { return this.fileSaveMenuItem; }
      set {
        SetMenuItem(ref this.fileSaveMenuItem, value, new EventHandler(fileSaveMenuItem_Click));
      }
    }

    [DefaultValue(null)]
    public MenuItem FileSaveAsMenuItem {
      get { return this.fileSaveAsMenuItem; }
      set {
        SetMenuItem(ref this.fileSaveAsMenuItem, value, new EventHandler(fileSaveAsMenuItem_Click));
      }
    }

    [DefaultValue(null)]
    public MenuItem FileSaveCopyAsMenuItem {
      get { return this.fileSaveCopyAsMenuItem; }
      set {
        SetMenuItem(ref this.fileSaveCopyAsMenuItem, value, new EventHandler(fileSaveCopyAsMenuItem_Click));
      }
    }

    [DefaultValue(null)]
    public MenuItem FileCloseMenuItem {
      get { return this.fileCloseMenuItem; }
      set {
        SetMenuItem(ref this.fileCloseMenuItem, value, new EventHandler(fileCloseMenuItem_Click));
      }
    }

    // TODO: Toolbar buttons, too
    //    public ToolBarButton FileOpenButton
    //    {
    //    }

    [DefaultValue(null)]
    [Browsable(false)]
    public IFormatter Formatter {
      get { return this.formatter; }
      set { this.formatter = value; }
    }
    #endregion

    #region Public Methods
    public bool New() {
      // Check to see if we can close
      if( !Close() ) return false;

      // Reset
      this.Data = null;
      this.Dirty = false;
      this.FileName = null;

      // Let subscribers know there's a new document in town
      if( this.NewDocument != null ) this.NewDocument(this, EventArgs.Empty);

      return true;
    }

    public bool Open() {
      return Open(null);
    }

    public bool Open(string newFileName) {
      // Check if we can close current file
      if( !Close() ) return false;

      // Get a file name
      if( Empty(newFileName) ) {
        // Set up dialog
        this.openFileDialog.DefaultExt = DefaultExt;
        this.openFileDialog.Filter = Filter;

        // Get the file to open
        DialogResult res = openFileDialog.ShowDialog(this.host);
        if( res != DialogResult.OK ) return false;

        newFileName = this.openFileDialog.FileName;
      }

      // Read the data
      try {
        Read(newFileName);
      }
      catch( Exception e ) {
        MessageBox.Show(host, "Can't open file: " + newFileName + "\r\n" + e.Message, Application.ProductName);
        return false;
      }

      // Clear dirty bit, cache the file name and set the caption
      this.Dirty = false;
      this.FileName = newFileName;

      // Put the file into the Start->Documents list
      AddToRecentDocs(newFileName);

      // Success
      return true;
    }

    public bool Save() {
      return Save(SaveType.Save);
    }

    public bool SaveAs() {
      return Save(SaveType.SaveAs);
    }

    public bool SaveCopyAs() {
      return Save(SaveType.SaveCopyAs);
    }

    public bool Close() {
      // It's all about the dirty bit...
      if( !this.Dirty ) return true;

      DialogResult res = MessageBox.Show(host, "Save changes?", Application.ProductName, MessageBoxButtons.YesNoCancel);
      switch( res ) {
        case DialogResult.Yes: return Save();
        case DialogResult.No: return true;
        case DialogResult.Cancel: return false;
        default: Debug.Assert(false); return false;
      }
    }

    #endregion

    #region Implementation
    bool Empty(string s) { return ((s == null) || (s == string.Empty)); }

    protected bool ShowExtension {
      get {
        // TODO: Check the shell setting
        return true;
      }
    }

    protected string DefaultFileName {
      get { return "Untitled" + (Empty(this.DefaultExt) ? "" : "." + this.DefaultExt); }
    }

    protected string CaptionFileName {
      get {
        string fileName = this.FileName;
        if( Empty(this.fileName) ) fileName = this.DefaultFileName;
        return (ShowExtension ? Path.GetFileName(fileName) : Path.GetFileNameWithoutExtension(fileName));
      }
    }

    protected void SetCaption() {
      if( this.host == null ) return;

      // Format = "<fileName>*"
      if( this.host.IsMdiChild ) {
        this.host.Text = string.Format("{0}{1}", this.CaptionFileName, (this.Dirty ? "*" : ""));
      }
        // Format = "<appName> - [<fileName>*]"
      else {
        this.host.Text = string.Format("{0} - [{1}{2}]", Application.ProductName, this.CaptionFileName, (this.Dirty ? "*" : ""));
      }
    }

    protected enum SaveType {
      Save,
      SaveAs,
      SaveCopyAs,
    }

    protected bool Save(SaveType type) {
      // Get the file name
      string newFileName = this.FileName;
      if( (type == SaveType.SaveAs) || (type == SaveType.SaveCopyAs) || Empty(newFileName) ) {
        // Set up the dialog
        this.saveFileDialog.DefaultExt = DefaultExt;
        this.saveFileDialog.Filter = Filter;
        if( !Empty(newFileName) ) {
          this.saveFileDialog.InitialDirectory = Path.GetDirectoryName(newFileName);
          this.saveFileDialog.FileName = Path.GetFileName(newFileName);
        }
        else {
          this.saveFileDialog.FileName = this.DefaultFileName;
        }

        DialogResult res = this.saveFileDialog.ShowDialog(this.host);
        if( res != DialogResult.OK ) return false;
        newFileName = this.saveFileDialog.FileName;
      }

      // Write the data
      try {
        Write(newFileName);
      }
      catch( Exception e ) {
        MessageBox.Show(host, "Can't save file: " + newFileName + "\r\n" + e.Message, Application.ProductName);
        return false;
      }

      if( type != SaveType.SaveCopyAs ) {
        // Clear the dirty bit, cache the new file name and set the caption
        this.Dirty = false;
        this.FileName = newFileName;
      }

      // Put the file into the Start->Documents list
      AddToRecentDocs(newFileName);

      // Success
      return true;
    }

    protected void Write(string fileName) {
      using( Stream stream = new FileStream(fileName, FileMode.Create, FileAccess.Write) ) {
        // Let event subscribers serialize first
        if( this.WriteDocument != null ) {
          SerializeDocumentEventArgs e = new SerializeDocumentEventArgs(fileName, stream);
          this.WriteDocument(this, e);
          if( e.Handled ) return;
        }

        // If subscribers don't serialize, we will
        if( this.formatter != null ) {
          this.formatter.Serialize(stream, Data);
        }
      }
    }

    protected void Read(string fileName) {
      using( Stream stream = new FileStream(fileName, FileMode.Open, FileAccess.Read) ) {
        // Let event subscribers serialize first
        if( this.ReadDocument != null ) {
          SerializeDocumentEventArgs e = new SerializeDocumentEventArgs(fileName, stream);
          this.ReadDocument(this, e);
          if( e.Handled ) return;
        }

        // If subscribers don't serialize, we will
        if( this.formatter != null ) {
          this.Data = formatter.Deserialize(stream);
        }
      }
    }

    object data = null;
    bool dirty = false;
    string fileName = "";
    Form host = null;
    string defaultExt = null;
    string defaultExtDesc = null;
    bool registerDefaultExt = false;
    string filter = null;
    IFormatter formatter = new BinaryFormatter();
    MenuItem fileNewMenuItem = null;
    MenuItem fileOpenMenuItem = null;
    MenuItem fileSaveMenuItem = null;
    MenuItem fileSaveAsMenuItem = null;
    MenuItem fileSaveCopyAsMenuItem = null;
    MenuItem fileCloseMenuItem = null;
    System.Windows.Forms.OpenFileDialog openFileDialog;
    System.Windows.Forms.SaveFileDialog saveFileDialog;

    void host_Load(object sender, EventArgs e) {
      // Update in case the host is an MDI child
      // NOTE: we do this to avoid setting the MdiParent
      // property on the child 'til the open was a success.
      // Otherwise, child shows up and goes away, which is annoying
      SetCaption();
    }

    void host_Closing(object sender, CancelEventArgs e) {
      // No need to check if this has already been canceled
      if( e.Cancel ) return;

      // Check to see if we can close the document
      if( !Close() ) e.Cancel = true;
    }

    void fileNewMenuItem_Click(object sender, EventArgs e) {
      New();
    }

    void fileOpenMenuItem_Click(object sender, EventArgs e) {
      Open();
    }

    void fileSaveMenuItem_Click(object sender, EventArgs e) {
      Save();
    }

    void fileSaveAsMenuItem_Click(object sender, EventArgs e) {
      SaveAs();
    }

    void fileSaveCopyAsMenuItem_Click(object sender, EventArgs e) {
      SaveCopyAs();
    }

    void fileCloseMenuItem_Click(object sender, EventArgs e) {
      // Let Closing event handler decide
      if( this.host != null ) this.host.Close();
    }

    void CheckRegisterDefaultExtension() {
      if( !this.registerDefaultExt || Empty(this.defaultExt) ) return;

      // Register custom extension with the shell
      string progID = this.defaultExt + "file";
      using( RegistryKey key = Registry.ClassesRoot.CreateSubKey("." + this.defaultExt) ) {
        // Map custom  extension to a ProgID
        key.SetValue(null, progID);
      }

      // Set ProgID description
      if( !Empty(this.DefaultExtDescription) ) {
        using( RegistryKey key = Registry.ClassesRoot.CreateSubKey(progID) ) {
          key.SetValue(null, this.DefaultExtDescription);
        }
      }

      // Register open command with the shell
      string cmdkey = progID + @"\shell\open\command";
      using( RegistryKey key = Registry.ClassesRoot.CreateSubKey(cmdkey) ) {
        // Map ProgID to an Open action for the shell
        key.SetValue(null, string.Format("\"{0}\" \"%L\"", Application.ExecutablePath));
      }

      // TODO: associate icon set via FileDocument component with shell
      // by dumping .ico into a file (if not already there) and registering it
      // with the shell
      //      // Register document icon with the shell
      //      string icokey = progID + @"\DefaultIcon";
      //      using( RegistryKey key = Registry.ClassesRoot.CreateSubKey(icokey) ) {
      //        // Map ProgID to a document icon for the shell
      //        key.SetValue(null, @"%SystemRoot%\system32\shell32.dll,-10");
      //      }
    }
    #endregion

    #region ISupportInitialize Members
    public void BeginInit() {
    }

    public void EndInit() {
      // Called after container is done initializing all properties
      CheckRegisterDefaultExtension();
      New();
    }
    #endregion

    #region Shell Interop
    enum ShellAddToRecentDocsFlags {
      Pidl = 0x001,
      Path = 0x002, // This is actually PathA
      //PathA = 0x002, // Avoiding these to ensure maximum reach
      //PathW = 0x003,
    }

    // NOTE: The reason for the CharSet.Ansi and limiting to just PathA in
    // the enum is to ensure that the flag and the CharSet match up
    [DllImport("shell32.dll", CharSet = CharSet.Ansi)]
    static extern void SHAddToRecentDocs(ShellAddToRecentDocsFlags flag, string path);

    static void AddToRecentDocs(string path) {
      // Use ANSI for maximum reach
      SHAddToRecentDocs(ShellAddToRecentDocsFlags.Path, path);
    }
    #endregion
  }

  public delegate void SerializeDocumentEventHandler(object sender, SerializeDocumentEventArgs e);

  public class SerializeDocumentEventArgs : EventArgs {
    private string fileName = null;
    public string FileName {
      get { return this.fileName; }
    }

    private Stream stream = null;
    public Stream Stream {
      get { return this.stream; }
    }

    public bool Handled = true;

    public SerializeDocumentEventArgs(string fileName, Stream stream) {
      this.fileName = fileName;
      this.stream = stream;
    }
  }

}





