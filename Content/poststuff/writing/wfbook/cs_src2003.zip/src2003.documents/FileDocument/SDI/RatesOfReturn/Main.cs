using System;
using System.IO;
using System.Windows.Forms;

namespace RatesOfReturn {
  class App {
    [STAThread]
    static void Main(string[] args) {
      // Check command line
      if( args.Length > 1 ) {
        MessageBox.Show("usage: ratesOfReturn.exe [file]", "RatesOfReturn");
        return;
      }

      // Load main form, taking command line into account
      RatesOfReturnForm form = new RatesOfReturnForm();
      if( args.Length == 1 ) {
        form.OpenDocument(Path.GetFullPath(args[0]));
      }

      Application.Run(form);
    }
  }
}
