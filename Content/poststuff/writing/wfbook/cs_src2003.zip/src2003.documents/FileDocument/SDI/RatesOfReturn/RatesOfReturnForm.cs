// RatesOfReturnForm.cs: shows average and annualized rates of return for a series of returns
// Used "Formatting the Windows Forms DataGrid Control in Visual Basic," by Seth Grossman
// to figure out how to do the custom formatting on the DataGrid control
// (hint: the Format property of the data grid column in the key)
// http://www.msdnaa.net/Resources/display.aspx?ResID=1997

using System;
using System.Diagnostics;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Soap; // Requires assembly reference
using Genghis.Windows.Forms;

namespace RatesOfReturn {
  public class RatesOfReturnForm : System.Windows.Forms.Form {
    System.Windows.Forms.DataGrid dataGrid1;
    System.Windows.Forms.StatusBar statusBar1;
    System.Data.DataView dataView1;
    System.Windows.Forms.StatusBar statusBar2;
    System.Windows.Forms.DataGridTableStyle dataGridTableStyle1;
    RatesOfReturn.PeriodReturnsSet periodReturnsSet1;
    System.Windows.Forms.DataGridTextBoxColumn periodColumn;
    System.Windows.Forms.DataGridTextBoxColumn returnColumn;
    System.Windows.Forms.DataGridTextBoxColumn principleColumn;
    System.Windows.Forms.MainMenu mainMenu1;
    System.Windows.Forms.MenuItem menuItem1;
    System.Windows.Forms.MenuItem fileNewMenuItem;
    System.Windows.Forms.MenuItem fileOpenMenuItem;
    System.Windows.Forms.MenuItem fileSaveMenuItem;
    System.Windows.Forms.MenuItem fileSaveAsMenuItem;
    System.Windows.Forms.MenuItem fileSaveCopyAsMenuItem;
    System.Windows.Forms.MenuItem menuItem7;
    System.Windows.Forms.MenuItem fileExitMenuItem;
    System.Windows.Forms.MenuItem menuItem3;
    System.Windows.Forms.MenuItem helpAboutMenuItem;
    private Genghis.Windows.Forms.FileDocument fileDocument1;
    private System.ComponentModel.IContainer components;

    public RatesOfReturnForm() {
      // Required for Windows Form Designer support
      InitializeComponent();

      // Set up the data and the formatter
      // so that the FileDocument can write the data
      // by itself (we still need to read, though)
      fileDocument1.Data = this.periodReturnsSet1;
      fileDocument1.Formatter = new SoapFormatter();
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

    #region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    void InitializeComponent() {
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(RatesOfReturnForm));
      this.dataGrid1 = new System.Windows.Forms.DataGrid();
      this.dataView1 = new System.Data.DataView();
      this.periodReturnsSet1 = new RatesOfReturn.PeriodReturnsSet();
      this.dataGridTableStyle1 = new System.Windows.Forms.DataGridTableStyle();
      this.periodColumn = new System.Windows.Forms.DataGridTextBoxColumn();
      this.returnColumn = new System.Windows.Forms.DataGridTextBoxColumn();
      this.principleColumn = new System.Windows.Forms.DataGridTextBoxColumn();
      this.statusBar1 = new System.Windows.Forms.StatusBar();
      this.statusBar2 = new System.Windows.Forms.StatusBar();
      this.mainMenu1 = new System.Windows.Forms.MainMenu();
      this.menuItem1 = new System.Windows.Forms.MenuItem();
      this.fileNewMenuItem = new System.Windows.Forms.MenuItem();
      this.fileOpenMenuItem = new System.Windows.Forms.MenuItem();
      this.fileSaveMenuItem = new System.Windows.Forms.MenuItem();
      this.fileSaveAsMenuItem = new System.Windows.Forms.MenuItem();
      this.fileSaveCopyAsMenuItem = new System.Windows.Forms.MenuItem();
      this.menuItem7 = new System.Windows.Forms.MenuItem();
      this.fileExitMenuItem = new System.Windows.Forms.MenuItem();
      this.menuItem3 = new System.Windows.Forms.MenuItem();
      this.helpAboutMenuItem = new System.Windows.Forms.MenuItem();
      this.fileDocument1 = new Genghis.Windows.Forms.FileDocument(this.components);
      ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dataView1)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.periodReturnsSet1)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.fileDocument1)).BeginInit();
      this.SuspendLayout();
      // 
      // dataGrid1
      // 
      this.dataGrid1.CaptionFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
      this.dataGrid1.CaptionText = "Enter one return for each period";
      this.dataGrid1.DataMember = "";
      this.dataGrid1.DataSource = this.dataView1;
      this.dataGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dataGrid1.Location = new System.Drawing.Point(0, 0);
      this.dataGrid1.Name = "dataGrid1";
      this.dataGrid1.Size = new System.Drawing.Size(292, 222);
      this.dataGrid1.TabIndex = 0;
      this.dataGrid1.TableStyles.AddRange(new System.Windows.Forms.DataGridTableStyle[] {
                                                                                          this.dataGridTableStyle1});
      // 
      // dataView1
      // 
      this.dataView1.Table = this.periodReturnsSet1.PeriodReturn;
      this.dataView1.ListChanged += new System.ComponentModel.ListChangedEventHandler(this.dataView1_ListChanged);
      // 
      // periodReturnsSet1
      // 
      this.periodReturnsSet1.DataSetName = "PeriodReturnsSet";
      this.periodReturnsSet1.Locale = new System.Globalization.CultureInfo("en-US");
      // 
      // dataGridTableStyle1
      // 
      this.dataGridTableStyle1.DataGrid = this.dataGrid1;
      this.dataGridTableStyle1.GridColumnStyles.AddRange(new System.Windows.Forms.DataGridColumnStyle[] {
                                                                                                          this.periodColumn,
                                                                                                          this.returnColumn,
                                                                                                          this.principleColumn});
      this.dataGridTableStyle1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dataGridTableStyle1.MappingName = "PeriodReturn";
      // 
      // periodColumn
      // 
      this.periodColumn.Format = "";
      this.periodColumn.FormatInfo = null;
      this.periodColumn.HeaderText = "Period";
      this.periodColumn.MappingName = "Period";
      this.periodColumn.NullText = "";
      this.periodColumn.Width = 75;
      // 
      // returnColumn
      // 
      this.returnColumn.Format = "#.000%;-#.000%;n/a";
      this.returnColumn.FormatInfo = null;
      this.returnColumn.HeaderText = "Return";
      this.returnColumn.MappingName = "Return";
      this.returnColumn.NullText = "(return)";
      this.returnColumn.Width = 75;
      // 
      // principleColumn
      // 
      this.principleColumn.Format = "$#,0.00";
      this.principleColumn.FormatInfo = null;
      this.principleColumn.HeaderText = "Principle";
      this.principleColumn.MappingName = "Principle";
      this.principleColumn.NullText = "";
      this.principleColumn.Width = 75;
      // 
      // statusBar1
      // 
      this.statusBar1.Location = new System.Drawing.Point(0, 244);
      this.statusBar1.Name = "statusBar1";
      this.statusBar1.Size = new System.Drawing.Size(292, 22);
      this.statusBar1.TabIndex = 1;
      // 
      // statusBar2
      // 
      this.statusBar2.Location = new System.Drawing.Point(0, 222);
      this.statusBar2.Name = "statusBar2";
      this.statusBar2.Size = new System.Drawing.Size(292, 22);
      this.statusBar2.SizingGrip = false;
      this.statusBar2.TabIndex = 2;
      // 
      // mainMenu1
      // 
      this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.menuItem1,
                                                                              this.menuItem3});
      // 
      // menuItem1
      // 
      this.menuItem1.Index = 0;
      this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.fileNewMenuItem,
                                                                              this.fileOpenMenuItem,
                                                                              this.fileSaveMenuItem,
                                                                              this.fileSaveAsMenuItem,
                                                                              this.fileSaveCopyAsMenuItem,
                                                                              this.menuItem7,
                                                                              this.fileExitMenuItem});
      this.menuItem1.MergeType = System.Windows.Forms.MenuMerge.MergeItems;
      this.menuItem1.Text = "&File";
      // 
      // fileNewMenuItem
      // 
      this.fileNewMenuItem.Index = 0;
      this.fileNewMenuItem.Shortcut = System.Windows.Forms.Shortcut.CtrlN;
      this.fileNewMenuItem.Text = "&New";
      // 
      // fileOpenMenuItem
      // 
      this.fileOpenMenuItem.Index = 1;
      this.fileOpenMenuItem.Shortcut = System.Windows.Forms.Shortcut.CtrlO;
      this.fileOpenMenuItem.Text = "&Open...";
      // 
      // fileSaveMenuItem
      // 
      this.fileSaveMenuItem.Index = 2;
      this.fileSaveMenuItem.MergeOrder = 1;
      this.fileSaveMenuItem.Shortcut = System.Windows.Forms.Shortcut.CtrlS;
      this.fileSaveMenuItem.Text = "&Save";
      // 
      // fileSaveAsMenuItem
      // 
      this.fileSaveAsMenuItem.Index = 3;
      this.fileSaveAsMenuItem.MergeOrder = 1;
      this.fileSaveAsMenuItem.Text = "Save &As...";
      // 
      // fileSaveCopyAsMenuItem
      // 
      this.fileSaveCopyAsMenuItem.Index = 4;
      this.fileSaveCopyAsMenuItem.Text = "Sa&ve Copy As...";
      // 
      // menuItem7
      // 
      this.menuItem7.Index = 5;
      this.menuItem7.Text = "-";
      // 
      // fileExitMenuItem
      // 
      this.fileExitMenuItem.Index = 6;
      this.fileExitMenuItem.Text = "E&xit";
      this.fileExitMenuItem.Click += new System.EventHandler(this.fileExitMenuItem_Click);
      // 
      // menuItem3
      // 
      this.menuItem3.Index = 1;
      this.menuItem3.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.helpAboutMenuItem});
      this.menuItem3.Text = "&Help";
      // 
      // helpAboutMenuItem
      // 
      this.helpAboutMenuItem.Index = 0;
      this.helpAboutMenuItem.Text = "&About...";
      this.helpAboutMenuItem.Click += new System.EventHandler(this.helpAboutMenuItem_Click);
      // 
      // fileDocument1
      // 
      this.fileDocument1.DefaultExt = "ror";
      this.fileDocument1.DefaultExtDescription = "Average and annualized returns";
      this.fileDocument1.FileNewMenuItem = this.fileNewMenuItem;
      this.fileDocument1.FileOpenMenuItem = this.fileOpenMenuItem;
      this.fileDocument1.FileSaveAsMenuItem = this.fileSaveAsMenuItem;
      this.fileDocument1.FileSaveCopyAsMenuItem = this.fileSaveCopyAsMenuItem;
      this.fileDocument1.FileSaveMenuItem = this.fileSaveMenuItem;
      this.fileDocument1.Filter = "";
      this.fileDocument1.HostingForm = this;
      this.fileDocument1.RegisterDefaultExtensionWithShell = true;
      this.fileDocument1.ReadDocument += new Genghis.Windows.Forms.SerializeDocumentEventHandler(this.fileDocument1_ReadDocument);
      this.fileDocument1.NewDocument += new System.EventHandler(this.fileDocument1_NewDocument);
      // 
      // RatesOfReturnForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Controls.Add(this.dataGrid1);
      this.Controls.Add(this.statusBar2);
      this.Controls.Add(this.statusBar1);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Menu = this.mainMenu1;
      this.Name = "RatesOfReturnForm";
      this.Text = "RatesOfReturn";
      ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dataView1)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.periodReturnsSet1)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.fileDocument1)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    bool processingListChanged = false;

    // TODO: allow entry of data in percentages
    void dataView1_ListChanged(object sender, ListChangedEventArgs e) {
      if( processingListChanged ) return;
      int periods = this.periodReturnsSet1.PeriodReturn.Rows.Count - 1;
      if( periods < 0 ) return;

      try {
        // Avoid re-entrancy when setting row properties below
        processingListChanged = true;

        // Make sure first row rate of return stays as it is
        ((PeriodReturnsSet.PeriodReturnRow)this.periodReturnsSet1.PeriodReturn.Rows[0]).Return = 0M;
        if( periods == 0 ) return;

        // Recalc returns
        Decimal principle = ((PeriodReturnsSet.PeriodReturnRow)this.periodReturnsSet1.PeriodReturn.Rows[0]).Principle;
        Decimal sumOfReturns = 0;
        Decimal productOfReturns = 1;
        for( short period = 1; period != this.periodReturnsSet1.PeriodReturn.Rows.Count; ++period ) {
          PeriodReturnsSet.PeriodReturnRow row = (PeriodReturnsSet.PeriodReturnRow)this.periodReturnsSet1.PeriodReturn.Rows[period];
          sumOfReturns += row.Return;
          productOfReturns *= (1 + row.Return);

          // Update the read-only row properties
          principle *= (1 + row.Return);
          row.Principle = principle;
        }

        Decimal averageReturn = sumOfReturns / periods;
        Decimal annualizedReturn = (Decimal)(Math.Pow((double)productOfReturns, 1.0/(double)periods)) - 1.0M;

        statusBar2.Text = string.Format("Average Rate of Return= {0:#.000%}", averageReturn);
        statusBar1.Text = string.Format("Annualized Rate of Return = {0:#.000%}", annualizedReturn);

        // Update the dirty bit
        fileDocument1.Dirty = true;
      }
      finally {
        processingListChanged = false;
      }
    }

    // For opening document from command line arguments
    public bool OpenDocument(string fileName) {
      return fileDocument1.Open(fileName);
    }

    void fileExitMenuItem_Click(object sender, EventArgs e) {
      // Let FileDocument component decide if this is OK
      this.Close();
    }

    void helpAboutMenuItem_Click(object sender, EventArgs e) {
      MessageBox.Show("RatesOfReturn by Chris Sells, 2003\r\nEnjoy.", "About RatesOfReturn");
    }

    void ClearDataSet() {
      // Clear existing data
      // TODO: why does this cause problems?
      //this.periodReturnsSet1.Clear();
      while( this.periodReturnsSet1.PeriodReturn.Rows.Count != 0 ) {
        PeriodReturnsSet.PeriodReturnRow row = (PeriodReturnsSet.PeriodReturnRow)this.periodReturnsSet1.PeriodReturn.Rows[0];
        this.periodReturnsSet1.PeriodReturn.RemovePeriodReturnRow(row);
      }
    }

    void fileDocument1_NewDocument(object sender, EventArgs e) {
      // Clear existing data
      ClearDataSet();

      // Set initial document data and state
      this.periodReturnsSet1.PeriodReturn.AddPeriodReturnRow("start", 0M, 1000M);
    }

    void fileDocument1_ReadDocument(object sender, SerializeDocumentEventArgs e) {
      // Deserialize object from text format
      // using the FileDocument's formatter
      IFormatter formatter = this.fileDocument1.Formatter;
      PeriodReturnsSet
        ds = (PeriodReturnsSet)formatter.Deserialize(e.Stream);

      // Clear existing data
      ClearDataSet();

      // Merge in new data, keeping data bindings intact
      this.periodReturnsSet1.Merge(ds);
    }

    // Let FileDocument component handle WriteDocument itself
    //    void fileDocument1_WriteDocument(object sender, SerializeDocumentEventArgs e) {
    //      // Serialize object to text format
    //      IFormatter formatter = new SoapFormatter();
    //      formatter.Serialize(e.Stream, this.periodReturnsSet1);
    //    }

  }
}



