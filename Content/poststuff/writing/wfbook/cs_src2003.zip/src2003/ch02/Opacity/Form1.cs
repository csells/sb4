using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Opacity {
  /// <summary>
  /// Summary description for Form1.
  /// </summary>
  public class Form1 : System.Windows.Forms.Form {
    private System.Windows.Forms.Timer timer1;
    private System.Windows.Forms.Label label1;
    private System.ComponentModel.IContainer components;

    public Form1() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
      this.Text = "Opacity = " + this.Opacity;
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.components = new System.ComponentModel.Container();
      System.Configuration.AppSettingsReader configurationAppSettings = new System.Configuration.AppSettingsReader();
      this.timer1 = new System.Windows.Forms.Timer(this.components);
      this.label1 = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // timer1
      // 
      this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(96, 24);
      this.label1.Name = "label1";
      this.label1.TabIndex = 0;
      this.label1.Text = "Click On Me!";
      this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // Form1
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 70);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.label1});
      this.Name = "Form1";
      this.Opacity = ((System.Double)(configurationAppSettings.GetValue("Form1.Opacity", typeof(System.Double))));
      this.Text = "Opacity = 0.5";
      this.TopMost = true;
      this.Activated += new System.EventHandler(this.Form1_Activated);
      this.Deactivate += new System.EventHandler(this.Form1_Deactivate);
      this.ResumeLayout(false);

    }
		#endregion

    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main() {
      Application.Run(new Form1());
    }

    void Form1_Activated(object sender, EventArgs e) {
      //timer1.Enabled = true;
    }

    void timer1_Tick(object sender, EventArgs e) {
      if( this.Opacity < 1.0 ) this.Opacity += 0.1;
      this.Text = "Opacity = " + this.Opacity.ToString();
    }

    void Form1_Deactivate(object sender, EventArgs e) {
      timer1.Enabled = false;
      //this.Opacity = 0.5;
      //this.Text = "Opacity = " + this.Opacity.ToString();
    }
  }
}
