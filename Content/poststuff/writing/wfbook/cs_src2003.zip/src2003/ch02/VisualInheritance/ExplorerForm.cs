using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;

using System.Windows.Forms;


namespace VisualInheritance
{
	public class ExplorerForm : VisualInheritance.BaseForm
	{
    private System.Windows.Forms.TreeView treeView1;
    private System.Windows.Forms.Splitter splitter1;
    private System.Windows.Forms.ListView listView1;
		private System.ComponentModel.IContainer components = null;

		public ExplorerForm()
		{
			// This call is required by the Windows Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
                                                                                                                                                        new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "-Derives from BaseForm", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0))))}, -1);
      System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
                                                                                                                                                        new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "-Overrides Text property", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0))))}, -1);
      System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
                                                                                                                                                        new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "-Overrides Size property", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0))))}, -1);
      System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
                                                                                                                                                        new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "-Adds a TreeView control", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0))))}, -1);
      System.Windows.Forms.ListViewItem listViewItem5 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
                                                                                                                                                        new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "-Adds a Splitter control", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0))))}, -1);
      System.Windows.Forms.ListViewItem listViewItem6 = new System.Windows.Forms.ListViewItem(new System.Windows.Forms.ListViewItem.ListViewSubItem[] {
                                                                                                                                                        new System.Windows.Forms.ListViewItem.ListViewSubItem(null, "-Adds a ListView control", System.Drawing.SystemColors.WindowText, System.Drawing.SystemColors.Window, new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0))))}, -1);
      this.treeView1 = new System.Windows.Forms.TreeView();
      this.splitter1 = new System.Windows.Forms.Splitter();
      this.listView1 = new System.Windows.Forms.ListView();
      this.SuspendLayout();
      // 
      // treeView1
      // 
      this.treeView1.Dock = System.Windows.Forms.DockStyle.Left;
      this.treeView1.ImageIndex = -1;
      this.treeView1.Name = "treeView1";
      this.treeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
                                                                          new System.Windows.Forms.TreeNode("Node0"),
                                                                          new System.Windows.Forms.TreeNode("Node1", new System.Windows.Forms.TreeNode[] {
                                                                                                                                                           new System.Windows.Forms.TreeNode("Node4", new System.Windows.Forms.TreeNode[] {
                                                                                                                                                                                                                                            new System.Windows.Forms.TreeNode("Node5", new System.Windows.Forms.TreeNode[] {
                                                                                                                                                                                                                                                                                                                             new System.Windows.Forms.TreeNode("Node6")})})}),
                                                                          new System.Windows.Forms.TreeNode("Node2"),
                                                                          new System.Windows.Forms.TreeNode("Node3")});
      this.treeView1.SelectedImageIndex = -1;
      this.treeView1.Size = new System.Drawing.Size(121, 107);
      this.treeView1.TabIndex = 1;
      // 
      // splitter1
      // 
      this.splitter1.Location = new System.Drawing.Point(121, 0);
      this.splitter1.Name = "splitter1";
      this.splitter1.Size = new System.Drawing.Size(3, 107);
      this.splitter1.TabIndex = 2;
      this.splitter1.TabStop = false;
      // 
      // listView1
      // 
      this.listView1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.listView1.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
                                                                              listViewItem1,
                                                                              listViewItem2,
                                                                              listViewItem3,
                                                                              listViewItem4,
                                                                              listViewItem5,
                                                                              listViewItem6});
      this.listView1.Location = new System.Drawing.Point(124, 0);
      this.listView1.Name = "listView1";
      this.listView1.Size = new System.Drawing.Size(172, 107);
      this.listView1.TabIndex = 3;
      this.listView1.View = System.Windows.Forms.View.List;
      // 
      // ExplorerForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(296, 129);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.listView1,
                                                                  this.splitter1,
                                                                  this.treeView1});
      this.Name = "ExplorerForm";
      this.Text = "ExplorerForm";
      this.ResumeLayout(false);

    }
		#endregion
	}
}

