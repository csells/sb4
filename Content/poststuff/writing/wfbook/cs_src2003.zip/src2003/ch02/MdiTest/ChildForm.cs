using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace WindowsApplication33 {
  /// <summary>
  /// Summary description for Form2.
  /// </summary>
  public class ChildForm : System.Windows.Forms.Form {
    private System.Windows.Forms.MainMenu mainMenu1;
    private System.Windows.Forms.MenuItem menuItem4;
    private System.Windows.Forms.MenuItem menuItem5;
    private System.Windows.Forms.MenuItem menuItem6;
    private System.Windows.Forms.MenuItem cmdFileClose;
    private System.Windows.Forms.MenuItem menuItem11;
    private System.Windows.Forms.MenuItem menuItem13;
    private System.Windows.Forms.MenuItem menuItem1;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public ChildForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.mainMenu1 = new System.Windows.Forms.MainMenu();
      this.menuItem11 = new System.Windows.Forms.MenuItem();
      this.menuItem1 = new System.Windows.Forms.MenuItem();
      this.cmdFileClose = new System.Windows.Forms.MenuItem();
      this.menuItem13 = new System.Windows.Forms.MenuItem();
      this.menuItem5 = new System.Windows.Forms.MenuItem();
      this.menuItem4 = new System.Windows.Forms.MenuItem();
      this.menuItem6 = new System.Windows.Forms.MenuItem();
      // 
      // mainMenu1
      // 
      this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.menuItem11,
                                                                              this.menuItem13});
      // 
      // menuItem11
      // 
      this.menuItem11.Index = 0;
      this.menuItem11.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                               this.menuItem1,
                                                                               this.cmdFileClose});
      this.menuItem11.MergeType = System.Windows.Forms.MenuMerge.MergeItems;
      this.menuItem11.Text = "&File";
      // 
      // menuItem1
      // 
      this.menuItem1.Index = 0;
      this.menuItem1.MergeOrder = 1;
      this.menuItem1.Text = "&Save";
      // 
      // cmdFileClose
      // 
      this.cmdFileClose.Index = 1;
      this.cmdFileClose.MergeOrder = 1;
      this.cmdFileClose.Text = "&Close";
      this.cmdFileClose.Click += new System.EventHandler(this.cmdFileClose_Click);
      // 
      // menuItem13
      // 
      this.menuItem13.Index = 1;
      this.menuItem13.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                               this.menuItem5,
                                                                               this.menuItem4,
                                                                               this.menuItem6});
      this.menuItem13.MergeOrder = 1;
      this.menuItem13.Text = "&Edit";
      // 
      // menuItem5
      // 
      this.menuItem5.Index = 0;
      this.menuItem5.Text = "Cu&t";
      // 
      // menuItem4
      // 
      this.menuItem4.Index = 1;
      this.menuItem4.Text = "&Copy";
      // 
      // menuItem6
      // 
      this.menuItem6.Index = 2;
      this.menuItem6.Text = "&Paste";
      // 
      // ChildForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(168, 126);
      this.Menu = this.mainMenu1;
      this.Name = "ChildForm";
      this.Text = "MDI Child";

    }
		#endregion

    private void cmdFileClose_Click(object sender, System.EventArgs e) {
      Close();
    }
  }
}
