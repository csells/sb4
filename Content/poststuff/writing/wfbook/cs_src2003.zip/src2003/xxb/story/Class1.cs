using System;

delegate void WorkStarted();
delegate void WorkProgressing();
delegate int WorkCompleted();

class Worker {
  public void DoWork() {
    Console.WriteLine("Worker: work started");
    if( started != null ) started();

    Console.WriteLine("Worker: work progressing");
    if( progressing != null ) progressing();

    Console.WriteLine("Worker: work completed");
    if( completed != null ) {
      foreach( WorkCompleted wc in completed.GetInvocationList() ) {
        wc.BeginInvoke(new AsyncCallback(WorkGraded), wc);
      }
    }
  }

  void WorkGraded(IAsyncResult res) {
    WorkCompleted wc = (WorkCompleted)res.AsyncState;
    int grade = wc.EndInvoke(res);
    Console.WriteLine("Worker grade= " + grade);
  }

  public event WorkStarted started;
  public event WorkProgressing progressing;
  public event WorkCompleted completed;
}

class Boss {
  public int WorkCompleted() {
    System.Threading.Thread.Sleep(3000);
    Console.WriteLine("Better..."); return 6; /* out of 10 */
  }
}

class Universe {
  static void WorkerStartedWork() {
    Console.WriteLine("Universe notices worker starting work");
  }

  static int WorkerCompletedWork() {
    System.Threading.Thread.Sleep(4000);
    Console.WriteLine("Universe is pleased with worker's work");
    return 7;
  }

  static void Main() {
    Worker peter = new Worker();
    Boss boss = new Boss();
    peter.completed += new WorkCompleted(boss.WorkCompleted);
    peter.started += new WorkStarted(Universe.WorkerStartedWork);
    peter.completed += new WorkCompleted(Universe.WorkerCompletedWork);
    peter.DoWork();

    Console.WriteLine("Main: worker completed work");
    Console.ReadLine();
  }
}
