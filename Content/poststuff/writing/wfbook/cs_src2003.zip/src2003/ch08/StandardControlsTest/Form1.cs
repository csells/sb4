using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace StandardControlsTest {
  /// <summary>
  /// Summary description for Form1.
  /// </summary>
  public class Form1 : System.Windows.Forms.Form {
    private System.Windows.Forms.MainMenu mainMenu1;
    private System.Windows.Forms.MenuItem menuItem1;
    private System.Windows.Forms.MenuItem fileExitMenuItem;
    private System.Windows.Forms.ToolBar toolBar1;
    private System.Windows.Forms.ToolBarButton fileExitToolBarButton;
    private System.Windows.Forms.MenuItem menuItem2;
    private System.Windows.Forms.ToolBarButton helpAboutToolBarButton;
    private System.Windows.Forms.MenuItem helpAboutMenuItem;
    private System.Windows.Forms.TreeView treeView1;
    private System.Windows.Forms.ListView listView1;
    private System.Windows.Forms.ColumnHeader columnHeader1;
    private System.Windows.Forms.ColumnHeader columnHeader2;
    private System.Windows.Forms.ListBox listBox1;
    private System.Windows.Forms.DataGrid dataGrid1;
    private System.Windows.Forms.ComboBox comboBox1;
    private System.Windows.Forms.ImageList imageList1;
    private System.ComponentModel.IContainer components;

    public Form1() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
      this.mainMenu1 = new System.Windows.Forms.MainMenu();
      this.menuItem1 = new System.Windows.Forms.MenuItem();
      this.fileExitMenuItem = new System.Windows.Forms.MenuItem();
      this.menuItem2 = new System.Windows.Forms.MenuItem();
      this.helpAboutMenuItem = new System.Windows.Forms.MenuItem();
      this.toolBar1 = new System.Windows.Forms.ToolBar();
      this.fileExitToolBarButton = new System.Windows.Forms.ToolBarButton();
      this.helpAboutToolBarButton = new System.Windows.Forms.ToolBarButton();
      this.treeView1 = new System.Windows.Forms.TreeView();
      this.imageList1 = new System.Windows.Forms.ImageList(this.components);
      this.listView1 = new System.Windows.Forms.ListView();
      this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
      this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
      this.listBox1 = new System.Windows.Forms.ListBox();
      this.dataGrid1 = new System.Windows.Forms.DataGrid();
      this.comboBox1 = new System.Windows.Forms.ComboBox();
      ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
      this.SuspendLayout();
      // 
      // mainMenu1
      // 
      this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.menuItem1,
                                                                              this.menuItem2});
      // 
      // menuItem1
      // 
      this.menuItem1.Index = 0;
      this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.fileExitMenuItem});
      this.menuItem1.Text = "&File";
      // 
      // fileExitMenuItem
      // 
      this.fileExitMenuItem.Index = 0;
      this.fileExitMenuItem.Text = "E&xit";
      this.fileExitMenuItem.Click += new System.EventHandler(this.fileExitMenuItem_Click);
      // 
      // menuItem2
      // 
      this.menuItem2.Index = 1;
      this.menuItem2.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.helpAboutMenuItem});
      this.menuItem2.Text = "&Help";
      // 
      // helpAboutMenuItem
      // 
      this.helpAboutMenuItem.Index = 0;
      this.helpAboutMenuItem.Text = "&About...";
      this.helpAboutMenuItem.Click += new System.EventHandler(this.helpAboutMenuItem_Click);
      // 
      // toolBar1
      // 
      this.toolBar1.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
                                                                                this.fileExitToolBarButton,
                                                                                this.helpAboutToolBarButton});
      this.toolBar1.DropDownArrows = true;
      this.toolBar1.Name = "toolBar1";
      this.toolBar1.ShowToolTips = true;
      this.toolBar1.Size = new System.Drawing.Size(432, 25);
      this.toolBar1.TabIndex = 1;
      this.toolBar1.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.toolBar1_ButtonClick);
      // 
      // treeView1
      // 
      this.treeView1.ImageList = this.imageList1;
      this.treeView1.Location = new System.Drawing.Point(160, 160);
      this.treeView1.Name = "treeView1";
      this.treeView1.TabIndex = 2;
      this.treeView1.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterSelect);
      // 
      // imageList1
      // 
      this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
      this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
      this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
      this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
      // 
      // listView1
      // 
      this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
                                                                                this.columnHeader1,
                                                                                this.columnHeader2});
      this.listView1.FullRowSelect = true;
      this.listView1.Location = new System.Drawing.Point(16, 40);
      this.listView1.Name = "listView1";
      this.listView1.Size = new System.Drawing.Size(184, 97);
      this.listView1.TabIndex = 3;
      this.listView1.View = System.Windows.Forms.View.Details;
      // 
      // columnHeader1
      // 
      this.columnHeader1.Text = "Name";
      this.columnHeader1.Width = 64;
      // 
      // columnHeader2
      // 
      this.columnHeader2.Text = "Age";
      // 
      // listBox1
      // 
      this.listBox1.Location = new System.Drawing.Point(16, 160);
      this.listBox1.Name = "listBox1";
      this.listBox1.Size = new System.Drawing.Size(120, 95);
      this.listBox1.TabIndex = 4;
      this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
      // 
      // dataGrid1
      // 
      this.dataGrid1.DataMember = "";
      this.dataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dataGrid1.Location = new System.Drawing.Point(216, 40);
      this.dataGrid1.Name = "dataGrid1";
      this.dataGrid1.Size = new System.Drawing.Size(200, 96);
      this.dataGrid1.TabIndex = 5;
      // 
      // comboBox1
      // 
      this.comboBox1.Location = new System.Drawing.Point(296, 160);
      this.comboBox1.Name = "comboBox1";
      this.comboBox1.Size = new System.Drawing.Size(121, 21);
      this.comboBox1.TabIndex = 6;
      this.comboBox1.Text = "comboBox1";
      this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
      // 
      // Form1
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(432, 245);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.comboBox1,
                                                                  this.dataGrid1,
                                                                  this.listBox1,
                                                                  this.listView1,
                                                                  this.treeView1,
                                                                  this.toolBar1});
      this.Menu = this.mainMenu1;
      this.Name = "Form1";
      this.Text = "Form1";
      this.Load += new System.EventHandler(this.Form1_Load);
      ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
      this.ResumeLayout(false);

    }
		#endregion

    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main() {
      Application.Run(new Form1());
    }

    void button1_Click(object sender, EventArgs e) {
      MessageBox.Show("Ouch!");
    }

    void FileExit() {
      this.Close();
    }

    void HelpAbout() {
      MessageBox.Show("The standard controls are cool");
    }

    void fileExitMenuItem_Click(object sender, EventArgs e) {
      FileExit();
    }

    void helpAboutMenuItem_Click(object sender, EventArgs e) {
      HelpAbout();
    }

    void toolBar1_ButtonClick(object sender, ToolBarButtonClickEventArgs e) {
      if( e.Button == fileExitToolBarButton ) {
        FileExit();
      }
      else if( e.Button == helpAboutToolBarButton ) {
        HelpAbout();
      }
    }

    class Person {
      string name;
      int age;

      public Person(string name, int age) {
        this.name = name;
        this.age = age;
      }

      public string Name {
        get { return name; }
        set { name = value; }
      }

      public int Age {
        get { return age; }
        set { age = value; }
      }

      public override string ToString() {
        return string.Format("{0} is {1} years old", Name, Age);
      }
    }

    class TaggedItem {
      public object Item;
      public object Tag;

      public TaggedItem(object item, object tag) {
        this.Item = item;
        this.Tag = tag;
      }

      public override string ToString() {
        return Item.ToString();
      }
    }

    void Form1_Load(object sender, EventArgs e) {
      TreeNode parentNode = new TreeNode();
      parentNode.Text = "Chris";
      parentNode.ImageIndex = 0; // Dad image
      parentNode.SelectedImageIndex = 0;

      // Add a node to the root of the tree
      treeView1.Nodes.Add(parentNode);

      TreeNode childNode = new TreeNode();
      childNode.Text = "John";
      childNode.ImageIndex = 1; // Son image
      childNode.SelectedImageIndex = 1;

      // Add a node under an existing node
      parentNode.Nodes.Add(childNode);
    }

    void listBox1_SelectedIndexChanged(object sender, EventArgs e) {
      // Get the selected object
      object selection = listBox1.Items[listBox1.SelectedIndex];
      MessageBox.Show(selection.ToString());

      // The object is still the same type as when we added it
      Person boy = (Person)selection;
      MessageBox.Show(boy.ToString());
    }

    void treeView1_AfterSelect(object sender, TreeViewEventArgs e) {
      TreeNode selection = treeView1.SelectedNode;
      object tag = selection.Tag;
      if( tag == null ) return;
      MessageBox.Show(tag.ToString());
    }

    void comboBox1_SelectedIndexChanged(object sender, EventArgs e) {
      TaggedItem selection =
        (TaggedItem)comboBox1.Items[comboBox1.SelectedIndex];
      object item = selection.Item;
      object tag = selection.Tag;
      MessageBox.Show(item.ToString());
      // Use tag for something...
      MessageBox.Show(tag.ToString());
    }

  }
}







