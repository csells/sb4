using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Controls
{
	/// <summary>
	/// Summary description for OwnerDrawnVariableListBox.
	/// </summary>
	public class OwnerDrawnVariableListBox : System.Windows.Forms.Form
	{
    private System.Windows.Forms.ListBox listBox2;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public OwnerDrawnVariableListBox()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.listBox2 = new System.Windows.Forms.ListBox();
      this.SuspendLayout();
      // 
      // listBox2
      // 
      this.listBox2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
      this.listBox2.Items.AddRange(new object[] {
                                                  "Huey",
                                                  "Dewy",
                                                  "Louis"});
      this.listBox2.Location = new System.Drawing.Point(8, 16);
      this.listBox2.Name = "listBox2";
      this.listBox2.Size = new System.Drawing.Size(280, 192);
      this.listBox2.TabIndex = 4;
      this.listBox2.MeasureItem += new System.Windows.Forms.MeasureItemEventHandler(this.listBox2_MeasureItem);
      this.listBox2.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.listBox2_DrawItem);
      // 
      // OwnerDrawnVariableListBox
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 222);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.listBox2});
      this.Name = "OwnerDrawnVariableListBox";
      this.Text = "OwnerDrawnVariableListBox";
      this.ResumeLayout(false);

    }
		#endregion

    private void listBox2_DrawItem(object sender, System.Windows.Forms.DrawItemEventArgs e)
    {
      // Draw the background
      e.DrawBackground();

      // If the item is an even item, draw twice as big too
      Font textFont;
      if (e.Index % 2 == 0) textFont = new Font(e.Font.FontFamily, e.Font.Size * 2);
      else textFont = e.Font;
      
      // Draw the string
      e.Graphics.DrawString(listBox2.Items[e.Index].ToString(), 
        textFont, 
        new SolidBrush(e.ForeColor), 
        e.Bounds);

      // Draw the focus rectangle
      e.DrawFocusRectangle();
    }

    private void listBox2_MeasureItem(object sender, System.Windows.Forms.MeasureItemEventArgs e)
    {
      // Make every even item double Height
      if (e.Index % 2 == 0)
      {
        e.ItemHeight *= 2;
      }
    }
	}
}
