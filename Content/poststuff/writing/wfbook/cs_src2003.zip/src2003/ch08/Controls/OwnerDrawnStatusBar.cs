using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Controls
{
	/// <summary>
	/// Summary description for OwnerDrawnStatusBar.
	/// </summary>
	public class OwnerDrawnStatusBar : System.Windows.Forms.Form
	{
    private System.Windows.Forms.StatusBar statusBar1;
    private System.Windows.Forms.StatusBarPanel statusBarPanel1;
    private System.Windows.Forms.StatusBarPanel statusBarPanel2;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public OwnerDrawnStatusBar()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(OwnerDrawnStatusBar));
      this.statusBar1 = new System.Windows.Forms.StatusBar();
      this.statusBarPanel1 = new System.Windows.Forms.StatusBarPanel();
      this.statusBarPanel2 = new System.Windows.Forms.StatusBarPanel();
      ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).BeginInit();
      this.SuspendLayout();
      // 
      // statusBar1
      // 
      this.statusBar1.Location = new System.Drawing.Point(0, 62);
      this.statusBar1.Name = "statusBar1";
      this.statusBar1.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
                                                                                  this.statusBarPanel1,
                                                                                  this.statusBarPanel2});
      this.statusBar1.ShowPanels = true;
      this.statusBar1.Size = new System.Drawing.Size(360, 32);
      this.statusBar1.TabIndex = 3;
      this.statusBar1.Text = "statusBar1";
      this.statusBar1.DrawItem += new System.Windows.Forms.StatusBarDrawItemEventHandler(this.statusBar1_DrawItem);
      // 
      // statusBarPanel1
      // 
      this.statusBarPanel1.Text = "Next Panel is OwnerDrawn -->";
      this.statusBarPanel1.Width = 190;
      // 
      // statusBarPanel2
      // 
      this.statusBarPanel2.Style = System.Windows.Forms.StatusBarPanelStyle.OwnerDraw;
      this.statusBarPanel2.Text = "statusBarPanel2";
      this.statusBarPanel2.Width = 113;
      // 
      // OwnerDrawnStatusBar
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(360, 94);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.statusBar1});
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "OwnerDrawnStatusBar";
      this.Text = "OwnerDrawnStatusBar";
      ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).EndInit();
      this.ResumeLayout(false);

    }
		#endregion

void statusBar1_DrawItem(object sender, StatusBarDrawItemEventArgs e)
{
  Brush brush = new SolidBrush(e.ForeColor);
  StringFormat format = new StringFormat();
  format.LineAlignment = StringAlignment.Center;
  format.Alignment = StringAlignment.Center;

  // Draw a grey background
  // e.DrawBackground() doesn't work because we
  // took responsibility for all the drawing
  e.Graphics.DrawRectangle(new Pen(e.BackColor), e.Bounds);

  // Draw Button with Text
  ControlPaint.DrawButton(e.Graphics, 
    e.Bounds.Left + 5, 
    e.Bounds.Top + 5, 
    e.Bounds.Width - 10,
    e.Bounds.Height - 10,
    ButtonState.Normal);
  e.Graphics.DrawString("Press Me", e.Font, brush, e.Bounds, format);

  // Clean up our Resources
  brush.Dispose();

//    // Draw the icon
//    e.Graphics.DrawIconUnstretched(this.Icon, e.Bounds);

}
	}
}
