using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace Controls
{
  public class FileTextBox : TextBox
  {
    public FileTextBox()
    {
    }

    protected override void OnTextChanged(EventArgs e)
    {
      // If the file does not exist, color the text red
      if (!File.Exists(this.Text))
      {
        this.ForeColor = Color.Red;
      }
      else // Make it black
      {
        this.ForeColor = Color.Black;
      }

      // Call the base class
      base.OnTextChanged(e);
    }
  }
}

