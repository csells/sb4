using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Controls
{
	/// <summary>
	/// Summary description for NewControl.
	/// </summary>
  public class NewControl : Control
  {
    public NewControl()
    {
      SetStyle(ControlStyles.UserPaint | 
                ControlStyles.ResizeRedraw, 
                true);
    }

    protected override void OnPaint(PaintEventArgs pe)
    {
      // Create the brushes to paint with (From Chapter 4)
      Brush backBrush = new SolidBrush(this.BackColor);
      Brush circleBrush = new SolidBrush(Color.Red);
      Brush foreBrush = new SolidBrush(this.ForeColor);

      // Set up our drawing surface
      RectangleF rect = new RectangleF(ClientRectangle.X,
                                       ClientRectangle.Y,
                                       ClientRectangle.Width,
                                       ClientRectangle.Height);

      // Specify that our string is centered 
      // horizontally and vertically
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Center;

      // Draw the background and the circle
      pe.Graphics.FillRectangle(backBrush, rect);
      pe.Graphics.FillEllipse(circleBrush, rect);

      // Draw the string from members of base Control
      pe.Graphics.DrawString(this.Text, 
                              this.Font, 
                              foreBrush, 
                              rect, 
                              format);
      
      // Clean our Brushes
      foreBrush.Dispose();
      circleBrush.Dispose();
      backBrush.Dispose();

      // Notify listeners last
      base.OnPaint(pe);
    }

    protected override void OnTextChanged(System.EventArgs e)
    {
      base.OnTextChanged(e);
      
      // Cause a paint to happen
      Invalidate();
    }

    protected override void OnFontChanged(System.EventArgs e)
    {
      base.OnFontChanged(e);

      // Cause a paint to happen
      Invalidate();
    }

    protected override void OnForeColorChanged(System.EventArgs e)
    {
      base.OnForeColorChanged(e);
      
      // Cause a paint to happen
      Invalidate();
    }

    protected override void OnBackColorChanged(System.EventArgs e)
    {
      base.OnBackColorChanged(e);
      
      // Cause a paint to happen
      Invalidate();
    }

    Cursor oldCursor = null;

    protected override void OnMouseEnter(EventArgs e)
    {
      base.OnMouseEnter(e);

      // Set the mouse icon
      oldCursor = this.Cursor;
      this.Cursor = Cursors.Hand;
    }

    protected override void OnMouseLeave(EventArgs e)
    {
      base.OnMouseLeave(e);

      // Set the mouse icon
      this.Cursor = oldCursor;

    }

	}
}
