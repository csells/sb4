using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Controls
{
	/// <summary>
	/// Summary description for SubclassControls.
	/// </summary>
	public class SubclassControls : System.Windows.Forms.Form
	{
    private Controls.FileTextBox fileTextBox1;
    private System.Windows.Forms.Button button1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public SubclassControls()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.fileTextBox1 = new Controls.FileTextBox();
      this.button1 = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // fileTextBox1
      // 
      this.fileTextBox1.ForeColor = System.Drawing.Color.Red;
      this.fileTextBox1.Location = new System.Drawing.Point(16, 16);
      this.fileTextBox1.Name = "fileTextBox1";
      this.fileTextBox1.Size = new System.Drawing.Size(232, 22);
      this.fileTextBox1.TabIndex = 0;
      this.fileTextBox1.Text = "fileTextBox1";
      // 
      // button1
      // 
      this.button1.Location = new System.Drawing.Point(176, 48);
      this.button1.Name = "button1";
      this.button1.TabIndex = 1;
      this.button1.Text = "Go";
      // 
      // SubclassControls
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(6, 15);
      this.ClientSize = new System.Drawing.Size(264, 80);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.button1,
                                                                  this.fileTextBox1});
      this.Name = "SubclassControls";
      this.Text = "Subclass Controls";
      this.ResumeLayout(false);

    }
		#endregion
	}
}
