using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Controls
{
	/// <summary>
	/// Summary description for ControlInteraction.
	/// </summary>
	public class ControlInteraction : System.Windows.Forms.Form
	{
    private System.Windows.Forms.GroupBox groupBox1;
    private AxSHDocVw.AxWebBrowser axWebBrowser1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ControlInteraction()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ControlInteraction));
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.axWebBrowser1 = new AxSHDocVw.AxWebBrowser();
      this.groupBox1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.axWebBrowser1)).BeginInit();
      this.SuspendLayout();
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.axWebBrowser1);
      this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox1.Location = new System.Drawing.Point(0, 0);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(299, 208);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Hosting COM Components";
      // 
      // axWebBrowser1
      // 
      this.axWebBrowser1.ContainingControl = this;
      this.axWebBrowser1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.axWebBrowser1.Enabled = true;
      this.axWebBrowser1.Location = new System.Drawing.Point(3, 16);
      this.axWebBrowser1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axWebBrowser1.OcxState")));
      this.axWebBrowser1.Size = new System.Drawing.Size(293, 189);
      this.axWebBrowser1.TabIndex = 0;
      // 
      // ControlInteraction
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(299, 208);
      this.Controls.Add(this.groupBox1);
      this.Name = "ControlInteraction";
      this.Text = "ControlInteraction";
      this.Load += new System.EventHandler(this.ControlInteraction_Load);
      this.groupBox1.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.axWebBrowser1)).EndInit();
      this.ResumeLayout(false);

    }
		#endregion

    private void ControlInteraction_Load(object sender, System.EventArgs e) {
      object dummy = null;
      axWebBrowser1.Navigate("http://www.sellsbrothers.com", ref dummy, ref dummy, ref dummy, ref dummy);
    }
	}
}
