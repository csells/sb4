using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Controls
{
	/// <summary>
	/// Summary description for WindowElementsForm.
	/// </summary>
	public class WindowElementsForm : System.Windows.Forms.Form
	{
    private System.Windows.Forms.ListBox listBox1;
    private System.Windows.Forms.Splitter splitter1;
    private System.Windows.Forms.MainMenu mainMenu1;
    private System.Windows.Forms.MenuItem menuItem1;
    private System.Windows.Forms.MenuItem menuItem2;
    private System.Windows.Forms.MenuItem menuItem3;
    private System.Windows.Forms.MenuItem menuItem4;
    private System.Windows.Forms.MenuItem menuItem5;
    private System.Windows.Forms.ToolBar toolBar1;
    private System.Windows.Forms.ToolBarButton toolBarButton1;
    private System.Windows.Forms.ImageList imageList1;
    private System.Windows.Forms.ToolBarButton toolBarButton2;
    private System.Windows.Forms.ToolBarButton toolBarButton3;
    private System.Windows.Forms.ToolBarButton toolBarButton4;
    private System.Windows.Forms.ContextMenu contextMenu1;
    private System.Windows.Forms.MenuItem menuItem6;
    private System.Windows.Forms.MenuItem menuItem7;
    private System.Windows.Forms.MenuItem menuItem8;
    private System.Windows.Forms.ContextMenu contextMenu2;
    private System.Windows.Forms.MenuItem menuItem9;
    private System.Windows.Forms.MenuItem menuItem10;
    private System.Windows.Forms.MenuItem menuItem11;
    private System.Windows.Forms.MenuItem menuItem12;
    private System.Windows.Forms.StatusBar statusBar1;
    private System.Windows.Forms.StatusBarPanel statusBarPanel1;
    private System.Windows.Forms.StatusBarPanel statusBarPanel2;
    private System.Windows.Forms.StatusBarPanel statusBarPanel3;
    private System.Windows.Forms.StatusBarPanel statusBarPanel4;
    private System.ComponentModel.IContainer components;

		public WindowElementsForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(WindowElementsForm));
      this.listBox1 = new System.Windows.Forms.ListBox();
      this.splitter1 = new System.Windows.Forms.Splitter();
      this.mainMenu1 = new System.Windows.Forms.MainMenu();
      this.menuItem1 = new System.Windows.Forms.MenuItem();
      this.menuItem2 = new System.Windows.Forms.MenuItem();
      this.menuItem3 = new System.Windows.Forms.MenuItem();
      this.menuItem4 = new System.Windows.Forms.MenuItem();
      this.menuItem5 = new System.Windows.Forms.MenuItem();
      this.toolBar1 = new System.Windows.Forms.ToolBar();
      this.toolBarButton1 = new System.Windows.Forms.ToolBarButton();
      this.imageList1 = new System.Windows.Forms.ImageList(this.components);
      this.toolBarButton2 = new System.Windows.Forms.ToolBarButton();
      this.toolBarButton3 = new System.Windows.Forms.ToolBarButton();
      this.toolBarButton4 = new System.Windows.Forms.ToolBarButton();
      this.contextMenu1 = new System.Windows.Forms.ContextMenu();
      this.menuItem6 = new System.Windows.Forms.MenuItem();
      this.menuItem7 = new System.Windows.Forms.MenuItem();
      this.menuItem8 = new System.Windows.Forms.MenuItem();
      this.contextMenu2 = new System.Windows.Forms.ContextMenu();
      this.menuItem9 = new System.Windows.Forms.MenuItem();
      this.menuItem10 = new System.Windows.Forms.MenuItem();
      this.menuItem11 = new System.Windows.Forms.MenuItem();
      this.menuItem12 = new System.Windows.Forms.MenuItem();
      this.statusBar1 = new System.Windows.Forms.StatusBar();
      this.statusBarPanel1 = new System.Windows.Forms.StatusBarPanel();
      this.statusBarPanel2 = new System.Windows.Forms.StatusBarPanel();
      this.statusBarPanel3 = new System.Windows.Forms.StatusBarPanel();
      this.statusBarPanel4 = new System.Windows.Forms.StatusBarPanel();
      ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel3)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel4)).BeginInit();
      this.SuspendLayout();
      // 
      // listBox1
      // 
      this.listBox1.Location = new System.Drawing.Point(88, 152);
      this.listBox1.Name = "listBox1";
      this.listBox1.Size = new System.Drawing.Size(120, 95);
      this.listBox1.TabIndex = 0;
      this.listBox1.Visible = false;
      // 
      // splitter1
      // 
      this.splitter1.Name = "splitter1";
      this.splitter1.Size = new System.Drawing.Size(3, 266);
      this.splitter1.TabIndex = 1;
      this.splitter1.TabStop = false;
      this.splitter1.Visible = false;
      // 
      // mainMenu1
      // 
      this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.menuItem1});
      // 
      // menuItem1
      // 
      this.menuItem1.Index = 0;
      this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.menuItem2,
                                                                              this.menuItem3,
                                                                              this.menuItem4,
                                                                              this.menuItem5});
      this.menuItem1.Text = "&File";
      this.menuItem1.Visible = false;
      // 
      // menuItem2
      // 
      this.menuItem2.Index = 0;
      this.menuItem2.Text = "&Open";
      this.menuItem2.Click += new System.EventHandler(this.menuItem2_Click);
      // 
      // menuItem3
      // 
      this.menuItem3.Index = 1;
      this.menuItem3.Text = "&Close";
      // 
      // menuItem4
      // 
      this.menuItem4.Index = 2;
      this.menuItem4.Text = "-";
      // 
      // menuItem5
      // 
      this.menuItem5.Index = 3;
      this.menuItem5.Text = "E&xit";
      // 
      // toolBar1
      // 
      this.toolBar1.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
                                                                                this.toolBarButton1,
                                                                                this.toolBarButton2,
                                                                                this.toolBarButton3,
                                                                                this.toolBarButton4});
      this.toolBar1.DropDownArrows = true;
      this.toolBar1.ImageList = this.imageList1;
      this.toolBar1.Location = new System.Drawing.Point(3, 0);
      this.toolBar1.Name = "toolBar1";
      this.toolBar1.ShowToolTips = true;
      this.toolBar1.Size = new System.Drawing.Size(289, 39);
      this.toolBar1.TabIndex = 2;
      this.toolBar1.Visible = false;
      this.toolBar1.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.toolBar1_ButtonClick);
      // 
      // toolBarButton1
      // 
      this.toolBarButton1.ImageIndex = 0;
      this.toolBarButton1.Text = "TestBtn";
      // 
      // imageList1
      // 
      this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
      this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
      this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
      this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
      // 
      // toolBarButton2
      // 
      this.toolBarButton2.ImageIndex = 1;
      this.toolBarButton2.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
      this.toolBarButton2.Text = "Toggle";
      // 
      // toolBarButton3
      // 
      this.toolBarButton3.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
      // 
      // toolBarButton4
      // 
      this.toolBarButton4.DropDownMenu = this.contextMenu1;
      this.toolBarButton4.ImageIndex = 2;
      this.toolBarButton4.Style = System.Windows.Forms.ToolBarButtonStyle.DropDownButton;
      this.toolBarButton4.Text = "Pick your poison";
      // 
      // contextMenu1
      // 
      this.contextMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                 this.menuItem6,
                                                                                 this.menuItem7,
                                                                                 this.menuItem8});
      // 
      // menuItem6
      // 
      this.menuItem6.Index = 0;
      this.menuItem6.Text = "Arsenic";
      this.menuItem6.Click += new System.EventHandler(this.menuItem6_Click);
      // 
      // menuItem7
      // 
      this.menuItem7.Index = 1;
      this.menuItem7.Text = "Cyanide";
      // 
      // menuItem8
      // 
      this.menuItem8.Index = 2;
      this.menuItem8.Text = "Rat Poison";
      // 
      // contextMenu2
      // 
      this.contextMenu2.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                 this.menuItem9,
                                                                                 this.menuItem10,
                                                                                 this.menuItem11,
                                                                                 this.menuItem12});
      // 
      // menuItem9
      // 
      this.menuItem9.Index = 0;
      this.menuItem9.Text = "&Copy";
      // 
      // menuItem10
      // 
      this.menuItem10.Index = 1;
      this.menuItem10.Text = "&Paste";
      this.menuItem10.Click += new System.EventHandler(this.menuItem10_Click);
      // 
      // menuItem11
      // 
      this.menuItem11.Index = 2;
      this.menuItem11.Text = "-";
      // 
      // menuItem12
      // 
      this.menuItem12.Index = 3;
      this.menuItem12.Text = "P&roperties";
      // 
      // statusBar1
      // 
      this.statusBar1.Location = new System.Drawing.Point(3, 244);
      this.statusBar1.Name = "statusBar1";
      this.statusBar1.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
                                                                                  this.statusBarPanel1,
                                                                                  this.statusBarPanel2,
                                                                                  this.statusBarPanel3,
                                                                                  this.statusBarPanel4});
      this.statusBar1.ShowPanels = true;
      this.statusBar1.Size = new System.Drawing.Size(289, 22);
      this.statusBar1.TabIndex = 3;
      this.statusBar1.Text = "statusBar1";
      // 
      // statusBarPanel1
      // 
      this.statusBarPanel1.Text = "Ready...";
      this.statusBarPanel1.Width = 60;
      // 
      // statusBarPanel2
      // 
      this.statusBarPanel2.Alignment = System.Windows.Forms.HorizontalAlignment.Center;
      this.statusBarPanel2.Text = "INS";
      this.statusBarPanel2.Width = 30;
      // 
      // statusBarPanel3
      // 
      this.statusBarPanel3.Alignment = System.Windows.Forms.HorizontalAlignment.Center;
      this.statusBarPanel3.Text = "DEL";
      this.statusBarPanel3.Width = 30;
      // 
      // statusBarPanel4
      // 
      this.statusBarPanel4.Alignment = System.Windows.Forms.HorizontalAlignment.Center;
      this.statusBarPanel4.Text = "OVR";
      this.statusBarPanel4.Width = 30;
      // 
      // WindowElementsForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.ContextMenu = this.contextMenu2;
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.statusBar1,
                                                                  this.toolBar1,
                                                                  this.splitter1,
                                                                  this.listBox1});
      this.Menu = this.mainMenu1;
      this.Name = "WindowElementsForm";
      this.Text = "WindowElementsForm";
      this.Load += new System.EventHandler(this.WindowElementsForm_Load);
      ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel3)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel4)).EndInit();
      this.ResumeLayout(false);

    }
		#endregion

    private void WindowElementsForm_Load(object sender, System.EventArgs e)
    {
      // Set the minimum size from the left side (or top)
      splitter1.MinSize = 50;

      // Set the minimum size from the right side (or bottom)
      splitter1.MinExtra = 50;

    }

      // Open Menu Item
      void menuItem2_Click(object sender, EventArgs e)
      {
        // ...
      }

      // TestBtn clicked
      void toolBar1_ButtonClick(object sender, ToolBarButtonClickEventArgs e)
      {
        // ...
      }

      // Insert selected
      private void menuItem6_Click(object sender, System.EventArgs e)
      {
        // ...
      }

    // Paste 
    private void menuItem10_Click(object sender, System.EventArgs e)
    {
      // ...
      // Set the text in one of the panels
      statusBar1.Panels[0].Text = "Working...";

    }
	}
}
