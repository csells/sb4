using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Controls
{
	/// <summary>
	/// Summary description for OwnerDrawnFixedListBox.
	/// </summary>
	public class OwnerDrawnFixedListBox : System.Windows.Forms.Form
	{
    private System.Windows.Forms.ListBox listBox1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public OwnerDrawnFixedListBox()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.listBox1 = new System.Windows.Forms.ListBox();
      this.SuspendLayout();
      // 
      // listBox1
      // 
      this.listBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
      this.listBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.listBox1.ItemHeight = 18;
      this.listBox1.Items.AddRange(new object[] {
                                                  "Foo",
                                                  "Bar",
                                                  "Quux"});
      this.listBox1.Location = new System.Drawing.Point(8, 8);
      this.listBox1.Name = "listBox1";
      this.listBox1.Size = new System.Drawing.Size(248, 166);
      this.listBox1.TabIndex = 2;
      this.listBox1.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.listBox1_DrawItem);
      // 
      // OwnerDrawnFixedListBox
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(264, 198);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.listBox1});
      this.Name = "OwnerDrawnFixedListBox";
      this.Text = "OwnerDrawnFixedListBox";
      this.ResumeLayout(false);

    }
		#endregion

    void listBox1_DrawItem(object sender, DrawItemEventArgs e)
    {
      // Draw the background
      e.DrawBackground();

      Font drawFont = null;
      
      // Draw with a Times new Roman Bold Italic Font if Selected
      if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
      {
        drawFont = new Font("Times New Roman", 
                            14, 
                            FontStyle.Bold | FontStyle.Italic);
      }
      else
      {
        drawFont = e.Font;
      }

      // Draw the string
      e.Graphics.DrawString(listBox1.Items[e.Index].ToString(), 
        drawFont, 
        new SolidBrush(e.ForeColor), 
        e.Bounds);

      // Draw the focus rectangle
      e.DrawFocusRectangle();
    }
	}
}
