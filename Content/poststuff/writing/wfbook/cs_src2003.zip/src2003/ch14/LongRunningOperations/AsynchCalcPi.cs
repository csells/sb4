using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Text;
using System.Threading;
using System.Diagnostics;

namespace AsynchCalcPi {
  /// <summary>
  /// Summary description for AsynchCalcPiForm.
  /// </summary>
  public class AsynchCalcPiForm : System.Windows.Forms.Form {
    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Button calcButton;
    private System.Windows.Forms.NumericUpDown digitsUpDown;
    private System.Windows.Forms.TextBox piTextBox;
    private System.Windows.Forms.ProgressBar piProgressBar;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    enum CalcState {
      Pending,
      Calculating,
      Canceled,
    }

    CalcState state = CalcState.Pending;

    public AsynchCalcPiForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

    #region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.panel1 = new System.Windows.Forms.Panel();
      this.calcButton = new System.Windows.Forms.Button();
      this.digitsUpDown = new System.Windows.Forms.NumericUpDown();
      this.label1 = new System.Windows.Forms.Label();
      this.piTextBox = new System.Windows.Forms.TextBox();
      this.piProgressBar = new System.Windows.Forms.ProgressBar();
      this.panel1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.digitsUpDown)).BeginInit();
      this.SuspendLayout();
      // 
      // panel1
      // 
      this.panel1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                         this.calcButton,
                                                                         this.digitsUpDown,
                                                                         this.label1});
      this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(232, 40);
      this.panel1.TabIndex = 0;
      // 
      // calcButton
      // 
      this.calcButton.Location = new System.Drawing.Point(144, 8);
      this.calcButton.Name = "calcButton";
      this.calcButton.TabIndex = 2;
      this.calcButton.Text = "Calc";
      this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
      // 
      // digitsUpDown
      // 
      this.digitsUpDown.Location = new System.Drawing.Point(80, 8);
      this.digitsUpDown.Maximum = new System.Decimal(new int[] {
                                                                 10000,
                                                                 0,
                                                                 0,
                                                                 0});
      this.digitsUpDown.Name = "digitsUpDown";
      this.digitsUpDown.Size = new System.Drawing.Size(56, 20);
      this.digitsUpDown.TabIndex = 1;
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(8, 8);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(64, 23);
      this.label1.TabIndex = 0;
      this.label1.Text = "Digits of Pi";
      // 
      // piTextBox
      // 
      this.piTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
      this.piTextBox.Location = new System.Drawing.Point(0, 40);
      this.piTextBox.Multiline = true;
      this.piTextBox.Name = "piTextBox";
      this.piTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.piTextBox.Size = new System.Drawing.Size(232, 103);
      this.piTextBox.TabIndex = 1;
      this.piTextBox.Text = "3";
      // 
      // piProgressBar
      // 
      this.piProgressBar.Dock = System.Windows.Forms.DockStyle.Bottom;
      this.piProgressBar.Location = new System.Drawing.Point(0, 143);
      this.piProgressBar.Maximum = 1;
      this.piProgressBar.Name = "piProgressBar";
      this.piProgressBar.Size = new System.Drawing.Size(232, 23);
      this.piProgressBar.TabIndex = 2;
      // 
      // AsynchCalcPiForm
      // 
      this.AcceptButton = this.calcButton;
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(232, 166);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.piTextBox,
                                                                  this.panel1,
                                                                  this.piProgressBar});
      this.Name = "AsynchCalcPiForm";
      this.Text = "Digits of Pi";
      this.panel1.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.digitsUpDown)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main() {
      Application.Run(new AsynchCalcPiForm());
    }

    class ShowProgressArgs : EventArgs {
      public string Pi;
      public int TotalDigits;
      public int DigitsSoFar;
      public bool Cancel;

      public ShowProgressArgs(string pi, int totalDigits, int digitsSoFar) {
        this.Pi = pi;
        this.TotalDigits = totalDigits;
        this.DigitsSoFar = digitsSoFar;
      }
    }

    delegate void ShowProgressHandler(object sender, ShowProgressArgs e);

    void ShowProgress(object sender, ShowProgressArgs e) {
      // Make sure we're on the UI thread
      if( this.InvokeRequired == false ) {
        piTextBox.Text = e.Pi;
        piProgressBar.Maximum = e.TotalDigits;
        piProgressBar.Value = e.DigitsSoFar;

        // Check for Cancel
        e.Cancel = (state == CalcState.Canceled);

        // Check for completion
        if( e.Cancel || (e.DigitsSoFar == e.TotalDigits) ) {
          state = CalcState.Pending;
          calcButton.Text = "Calc";
          calcButton.Enabled = true;

        }
      }
        // Transfer control to the UI thread
      else {
        ShowProgressHandler
          showProgress =
          new ShowProgressHandler(ShowProgress);
        Invoke(showProgress, new object[] { sender, e});

        // Show progress asynchronously
        //        IAsyncResult res = 
        //          BeginInvoke(showProgress, new object[] { pi, totalDigits, digitsSoFar, inoutCancel});
        //
        //        // Wait for results
        //        while( !res.IsCompleted  ) System.Threading.Thread.Sleep(100);
        //
        //        // Harvest results
        //        cancel = (bool)inoutCancel;
        //        object methodResults = EndInvoke(res);
        // Do something with results...
      }
    }

    void CalcPi(int digits) {
      StringBuilder pi = new StringBuilder("3", digits + 2);
      object sender = System.Threading.Thread.CurrentThread;
      ShowProgressArgs e = new ShowProgressArgs(pi.ToString(), digits, 0);

      // Show progress (ignoring Cancel so soon)
      ShowProgress(sender, e);

      if( digits > 0 ) {
        pi.Append(".");

        for( int i = 0; i < digits; i += 9 ) {
          int nineDigits = NineDigitsOfPi.StartingAt(i+1);
          int digitCount = Math.Min(digits - i, 9);
          string ds = string.Format("{0:D9}", nineDigits);
          pi.Append(ds.Substring(0, digitCount));

          // Show progress (checking for Cancel)
          e.Pi = pi.ToString();
          e.DigitsSoFar = i + digitCount;
          ShowProgress(sender, e);
          if( e.Cancel ) break;
        }
      }
    }

    delegate void CalcPiDelegate(int digits);

    // Just to call EndInvoke as the docs say we have to:
    // http://msdn.microsoft.com/library/default.asp?url=/library/en-us/cpguide/html/cpovrasynchronousprogrammingoverview.asp
    void CallEndInvoke(IAsyncResult result) {
      try {
        CalcPiDelegate del = (CalcPiDelegate)result.AsyncState;
        del.EndInvoke(result);
      }
      catch( Exception ex ) {
        // Don't let failed worker thread scare user...
        Debug.WriteLine(string.Format("Failed worker thread: {0}", ex.Message));
      }
    }

    void calcButton_Click(object sender, System.EventArgs e) {
      // Synch method
      //            CalcPi((int)digitsUpDown.Value);
      //            return;

      // Calc button does double duty as Cancel button
      switch( state ) {
          // Start a new calculation
        case CalcState.Pending:
          // Allow canceling
          state = CalcState.Calculating;
          calcButton.Text = "Cancel";

          // Asynch delegate method
          // (getting a callback to call EndInvoke)
          CalcPiDelegate  calcPi = new CalcPiDelegate(CalcPi);
          calcPi.BeginInvoke((int)digitsUpDown.Value, new AsyncCallback(CallEndInvoke), calcPi);
          break;

          // Cancel a running calculation
        case CalcState.Calculating:
          state = CalcState.Canceled;
          calcButton.Enabled = false;
          break;

          // Shouldn't be able to press Calc button while it's canceling
        case CalcState.Canceled:
          Debug.Assert(false);
          break;
      }
    }
  }
}














