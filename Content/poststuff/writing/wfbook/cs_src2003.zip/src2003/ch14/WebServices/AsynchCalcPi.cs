using System;
using System.Net;
using System.ComponentModel;
using System.Windows.Forms;
using System.Text;
using System.Threading;
using System.Diagnostics;

namespace AsynchCalcPi {
  public class AsynchCalcPiForm : System.Windows.Forms.Form {
    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Button calcButton;
    private System.Windows.Forms.NumericUpDown digitsUpDown;
    private System.Windows.Forms.TextBox piTextBox;

    private System.ComponentModel.Container components = null;

    public AsynchCalcPiForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.panel1 = new System.Windows.Forms.Panel();
      this.calcButton = new System.Windows.Forms.Button();
      this.digitsUpDown = new System.Windows.Forms.NumericUpDown();
      this.label1 = new System.Windows.Forms.Label();
      this.piTextBox = new System.Windows.Forms.TextBox();
      this.panel1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.digitsUpDown)).BeginInit();
      this.SuspendLayout();
      // 
      // panel1
      // 
      this.panel1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                         this.calcButton,
                                                                         this.digitsUpDown,
                                                                         this.label1});
      this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(232, 40);
      this.panel1.TabIndex = 0;
      // 
      // calcButton
      // 
      this.calcButton.Location = new System.Drawing.Point(144, 8);
      this.calcButton.Name = "calcButton";
      this.calcButton.TabIndex = 2;
      this.calcButton.Text = "Calc";
      this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
      // 
      // digitsUpDown
      // 
      this.digitsUpDown.Location = new System.Drawing.Point(80, 8);
      this.digitsUpDown.Maximum = new System.Decimal(new int[] {
                                                                 10000,
                                                                 0,
                                                                 0,
                                                                 0});
      this.digitsUpDown.Name = "digitsUpDown";
      this.digitsUpDown.Size = new System.Drawing.Size(56, 20);
      this.digitsUpDown.TabIndex = 1;
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(8, 8);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(64, 23);
      this.label1.TabIndex = 0;
      this.label1.Text = "Digits of Pi";
      // 
      // piTextBox
      // 
      this.piTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
      this.piTextBox.Location = new System.Drawing.Point(0, 40);
      this.piTextBox.Multiline = true;
      this.piTextBox.Name = "piTextBox";
      this.piTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.piTextBox.Size = new System.Drawing.Size(232, 126);
      this.piTextBox.TabIndex = 1;
      this.piTextBox.Text = "3";
      // 
      // AsynchCalcPiForm
      // 
      this.AcceptButton = this.calcButton;
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(232, 166);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.piTextBox,
                                                                  this.panel1});
      this.Name = "AsynchCalcPiForm";
      this.Text = "Digits of Pi";
      this.panel1.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.digitsUpDown)).EndInit();
      this.ResumeLayout(false);

    }
		#endregion

    [STAThread]
    static void Main() {
      Application.Run(new AsynchCalcPiForm());
    }

    enum CalcState {
      Pending,
      Calculating,
      Canceled,
    }

    CalcState state = CalcState.Pending;
    localhost.CalcPiService service = new localhost.CalcPiService();

    void calcButton_Click(object sender, System.EventArgs e) {
      switch( state ) {
          // Start a new calculation
        case CalcState.Pending:
          // Allow canceling
          state = CalcState.Calculating;
          calcButton.Text = "Cancel";

          // Start web service request
          service.BeginCalcPi(
            (int)digitsUpDown.Value, new AsyncCallback(PiCalculated), null);
          break;

          // Cancel a running calculation
        case CalcState.Calculating:
          state = CalcState.Canceled;
          calcButton.Enabled = false;
          service.Abort(); // Fail all outstanding requests
          break;

          // Shouldn't be able to press Calc button while it's canceling
        case CalcState.Canceled:
          Debug.Assert(false);
          break;
      }

    }

    delegate void ShowPiDelegate(string pi);

    void ShowPi(string pi) {
      if( this.InvokeRequired == false ) {
        piTextBox.Text = pi;
        state = CalcState.Pending;
        calcButton.Text = "Calc";
        calcButton.Enabled = true;
      }
      else {
        ShowPiDelegate showPi = new ShowPiDelegate(ShowPi);
        this.BeginInvoke(showPi, new object[] {pi});
      }
    }

    void PiCalculated(IAsyncResult res) {
      try {
        ShowPi(service.EndCalcPi(res));
      }
      catch( WebException ex ) {
        ShowPi(ex.Message);
      }
    }

  }
}














