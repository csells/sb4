using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Printing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Printing {
  /// <summary>
  /// Summary description for Form1.
  /// </summary>
  public class MainForm : System.Windows.Forms.Form {
    private System.Windows.Forms.Button printButton;
    private System.Drawing.Printing.PrintDocument printDocument1;
    private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
    private System.Windows.Forms.Button previewButton;
    private System.Windows.Forms.Button previewControlButton;
    private System.Windows.Forms.PageSetupDialog pageSetupDialog1;
    private System.Windows.Forms.Button pageSetupButton;
    private System.Windows.Forms.PrintDialog printDialog1;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public MainForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(MainForm));
      this.printButton = new System.Windows.Forms.Button();
      this.printDocument1 = new System.Drawing.Printing.PrintDocument();
      this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
      this.previewButton = new System.Windows.Forms.Button();
      this.previewControlButton = new System.Windows.Forms.Button();
      this.pageSetupDialog1 = new System.Windows.Forms.PageSetupDialog();
      this.pageSetupButton = new System.Windows.Forms.Button();
      this.printDialog1 = new System.Windows.Forms.PrintDialog();
      this.SuspendLayout();
      // 
      // printButton
      // 
      this.printButton.Location = new System.Drawing.Point(24, 16);
      this.printButton.Name = "printButton";
      this.printButton.Size = new System.Drawing.Size(112, 23);
      this.printButton.TabIndex = 0;
      this.printButton.Text = "Print";
      this.printButton.Click += new System.EventHandler(this.printButton_Click);
      // 
      // printDocument1
      // 
      this.printDocument1.BeginPrint += new System.Drawing.Printing.PrintEventHandler(this.printDocument1_BeginPrint);
      this.printDocument1.EndPrint += new System.Drawing.Printing.PrintEventHandler(this.printDocument1_EndPrint);
      this.printDocument1.QueryPageSettings += new System.Drawing.Printing.QueryPageSettingsEventHandler(this.printDocument1_QueryPageSettings);
      this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
      // 
      // printPreviewDialog1
      // 
      this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
      this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
      this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
      this.printPreviewDialog1.Enabled = true;
      this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
      this.printPreviewDialog1.Location = new System.Drawing.Point(148, 17);
      this.printPreviewDialog1.MaximumSize = new System.Drawing.Size(0, 0);
      this.printPreviewDialog1.Name = "printPreviewDialog1";
      this.printPreviewDialog1.Opacity = 1;
      this.printPreviewDialog1.TransparencyKey = System.Drawing.Color.Empty;
      this.printPreviewDialog1.Visible = false;
      // 
      // previewButton
      // 
      this.previewButton.Location = new System.Drawing.Point(24, 80);
      this.previewButton.Name = "previewButton";
      this.previewButton.Size = new System.Drawing.Size(112, 23);
      this.previewButton.TabIndex = 2;
      this.previewButton.Text = "Preview Dialog";
      this.previewButton.Click += new System.EventHandler(this.previewButton_Click);
      // 
      // previewControlButton
      // 
      this.previewControlButton.Location = new System.Drawing.Point(24, 48);
      this.previewControlButton.Name = "previewControlButton";
      this.previewControlButton.Size = new System.Drawing.Size(112, 23);
      this.previewControlButton.TabIndex = 1;
      this.previewControlButton.Text = "Preview Control";
      this.previewControlButton.Click += new System.EventHandler(this.customPreviewButton_Click);
      // 
      // pageSetupDialog1
      // 
      this.pageSetupDialog1.MinMargins = new System.Drawing.Printing.Margins(50, 50, 50, 50);
      this.pageSetupDialog1.ShowHelp = true;
      // 
      // pageSetupButton
      // 
      this.pageSetupButton.Location = new System.Drawing.Point(24, 112);
      this.pageSetupButton.Name = "pageSetupButton";
      this.pageSetupButton.Size = new System.Drawing.Size(112, 23);
      this.pageSetupButton.TabIndex = 2;
      this.pageSetupButton.Text = "Page Setup";
      this.pageSetupButton.Click += new System.EventHandler(this.pageSetupButton_Click);
      // 
      // printDialog1
      // 
      this.printDialog1.Document = this.printDocument1;
      // 
      // MainForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(160, 150);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.printButton,
                                                                  this.previewButton,
                                                                  this.previewControlButton,
                                                                  this.pageSetupButton});
      this.Name = "MainForm";
      this.Text = "Printing";
      this.ResumeLayout(false);

    }
		#endregion

    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main() {
      Application.Run(new MainForm());
    }

    string fileName = "myFile.txt";

    int totalPages = 13;
    int page;
    int maxPage;
    bool preview = false;

    void printButton_Click(object sender, System.EventArgs e) {
      printDocument1.DocumentName = fileName;
      //MessageBox.Show(printDocument1.PrintController.ToString());
      //      PrintController standard = new StandardPrintController();
      //      // Can change the title from "Printing" to something else
      //      PrintController status = new PrintControllerWithStatusDialog(standard, "Printing");
      //      PrintController preview = new PreviewPrintController();
      //      printDocument1.PrintController = status;
      // Let the user choose the printer
      printDocument1.PrinterSettings.FromPage = 1;
      printDocument1.PrinterSettings.ToPage = totalPages;
      printDocument1.PrinterSettings.MinimumPage = 1;
      printDocument1.PrinterSettings.MaximumPage = totalPages;
      printDialog1.AllowSomePages = true;
      if( printDialog1.ShowDialog() == DialogResult.OK ) {
        if( printDialog1.PrinterSettings.PrintRange ==
          PrintRange.SomePages ) {
          // Set first page to print to FromPage
          page = printDocument1.PrinterSettings.FromPage;

          // Set last page to print to ToPage
          maxPage = printDocument1.PrinterSettings.ToPage;
        }
        else {
          // Print all pages
          page = 1;
          maxPage = totalPages;
        }

        // Print from first page to last page
        preview = false;
        printDocument1.Print();
      }
    }

    // Get real page bounds based on printable area of the page
    static
      Rectangle GetRealPageBounds(PrintPageEventArgs e, bool preview) {
      // Return in units of 1/100th of an inch
      if( preview ) return e.PageBounds;

      // Translate to units of 1/100th of an inch
      RectangleF vpb = e.Graphics.VisibleClipBounds;
      PointF[]
        bottomRight = { new PointF(vpb.Size.Width, vpb.Size.Height) };
      e.Graphics.TransformPoints(
        CoordinateSpace.Device, CoordinateSpace.Page, bottomRight);
      float dpiX = e.Graphics.DpiX;
      float dpiY = e.Graphics.DpiY;
      return new Rectangle(
        0,
        0,
        (int)(bottomRight[0].X * 100 /  dpiX),
        (int)(bottomRight[0].Y * 100 / dpiY));
    }

    [System.Runtime.InteropServices.DllImport("gdi32.dll")]
    static extern int GetDeviceCaps(IntPtr hdc, DeviceCapsIndex index);
    enum DeviceCapsIndex {
      PhysicalOffsetX = 112,
      PhysicalOffsetY = 113,
    }

    // Adjust MarginBounds rectangle when printing based
    // on the physical characteristics of the printer
    static
      Rectangle GetRealMarginBounds(PrintPageEventArgs e, bool preview) {
      if( preview ) return e.MarginBounds;

      int cx = 0;
      int cy = 0;
      IntPtr hdc = e.Graphics.GetHdc();

      try {
        // Both of these come back as device units and are not
        // scaled to 1/100th of an inch
        cx = GetDeviceCaps(hdc, DeviceCapsIndex.PhysicalOffsetX);
        cy = GetDeviceCaps(hdc, DeviceCapsIndex.PhysicalOffsetY);
      }
      finally {
        e.Graphics.ReleaseHdc(hdc);
      }

      // Create the real margin bounds by scaling the offset
      // by the printer resolution and then rescaling it
      // back to 1/100th of an inch
      Rectangle marginBounds = e.MarginBounds;
      int dpiX = (int)e.Graphics.DpiX;
      int dpiY = (int)e.Graphics.DpiY;
      marginBounds.Offset(-cx * 100 / dpiX , -cy * 100 / dpiY);
      return marginBounds;
    }

    static RectangleF TranslateBounds(Graphics g, Rectangle bounds) {
      // Translate from units of 1/100th of an inch to page units
      float dpiX = g.DpiX;
      float dpiY = g.DpiY;
      PointF[] pts = new PointF[2];
      pts[0] =
        new PointF(bounds.X * dpiX / 100, bounds.Y * dpiY / 100);
      pts[1] =
        new PointF(bounds.Width * dpiX / 100, bounds.Height * dpiX / 100);
      g.TransformPoints(
        CoordinateSpace.Page, CoordinateSpace.Device, pts);
      return new RectangleF(
        pts[0].X,
        pts[0].Y,
        pts[1].X,
        pts[1].Y);
    }

    void printDocument1_PrintPage(object sender, PrintPageEventArgs e) {
      Graphics g = e.Graphics;
      g.PageUnit = GraphicsUnit.Inch;

      // print current page...
      //      g.DrawString("Hello,\nPrinter\nPage: " + page, font, Brushes.Black, e.MarginBounds);

      // Check if there are more pages to print
      ++page;
      e.HasMorePages = page <= maxPage;

      //      Rectangle pageBounds = e.PageBounds;
      //      pageBounds.Inflate(-1, -1);
      //      g.DrawRectangle(Pens.Black, pageBounds);
      //      g.DrawString("PageBounds", font, Brushes.Black, pageBounds);
      //      g.DrawRectangle(Pens.Black, e.MarginBounds);
      //
      //      g.DrawString("MarginBounds", font, Brushes.Black, e.MarginBounds);
      //      g.DrawRectangle(Pens.Black, e.MarginBounds);

      //      g.DrawString("VisibleClipBounds", font, Brushes.Black, g.VisibleClipBounds);
      //      g.DrawRectangle(Pens.Black, g.VisibleClipBounds.X, g.VisibleClipBounds.Y, g.VisibleClipBounds.Width, g.VisibleClipBounds.Height);

      StringFormat nearFormat = new StringFormat();
      nearFormat.Alignment = StringAlignment.Near;
      nearFormat.LineAlignment = StringAlignment.Near;

      StringFormat farFormat = new StringFormat();
      farFormat.Alignment = StringAlignment.Far;
      farFormat.LineAlignment = StringAlignment.Far;

      using( Pen thinPen = new Pen(Color.Black, 0) ) {
        RectangleF pageBounds = GetRealPageBounds(e, preview);
        pageBounds = TranslateBounds(g, Rectangle.Truncate(pageBounds));
        g.DrawRectangle(
          thinPen,
          pageBounds.X,
          pageBounds.Y,
          pageBounds.Width,
          pageBounds.Height);

        // Draw a header in the upper left
        g.DrawString("header", font, Brushes.Black, pageBounds, nearFormat);

        // Draw a footer in the lower right
        g.DrawString("footer", font, Brushes.Black, pageBounds, farFormat);

        RectangleF marginBounds = GetRealMarginBounds(e, preview);
        marginBounds = TranslateBounds(g, Rectangle.Truncate(marginBounds));
        g.DrawString("content", font, Brushes.Black, marginBounds);
        g.DrawRectangle(thinPen, marginBounds.X, marginBounds.Y, marginBounds.Width, marginBounds.Height);
      }
    }

    void previewButton_Click(object sender, EventArgs e) {
      page = 1;
      maxPage = totalPages;
      printPreviewDialog1.Document = printDocument1;
      preview = true;
      printPreviewDialog1.ShowDialog();
    }

    private void customPreviewButton_Click(object sender, System.EventArgs e) {
      page = 1;
      maxPage = totalPages;
      CustomPrintPreviewDialog dlg = new CustomPrintPreviewDialog();
      dlg.Document = printDocument1;
      preview = true;
      dlg.ShowDialog();
    }

    void printDocument1_QueryPageSettings(object sender, QueryPageSettingsEventArgs e) {
      // Set margins to .5" all the way around
      //e.PageSettings.Margins = new Margins(50, 50, 50, 50);
    }

    Font font = null;

    void printDocument1_BeginPrint(object sender, PrintEventArgs e) {
      // Create font for printing
      font = new Font("Lucida Console", 72);
    }

    void printDocument1_EndPrint(object sender, PrintEventArgs e) {
      // Reclaim font
      font.Dispose();
      font = null;
    }

    void pageSetupButton_Click(object sender, EventArgs e) {
      // Let the user select page settings
      pageSetupDialog1.Document = printDocument1;
      pageSetupDialog1.ShowDialog();
    }

  }
}
