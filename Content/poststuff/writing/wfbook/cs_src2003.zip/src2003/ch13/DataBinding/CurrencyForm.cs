using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace DataBinding {
  /// <summary>
  /// Summary description for CurrencyForm.
  /// </summary>
  public class CurrencyForm : System.Windows.Forms.Form {
    private System.Data.SqlClient.SqlCommand sqlSelectCommand1;
    private System.Data.SqlClient.SqlCommand sqlInsertCommand1;
    private System.Data.SqlClient.SqlCommand sqlUpdateCommand1;
    private System.Data.SqlClient.SqlCommand sqlDeleteCommand1;
    private System.Data.SqlClient.SqlConnection sqlConnection1;
    private DataBinding.CustomerSet customerSet1;
    private System.Data.SqlClient.SqlDataAdapter customersAdapter;
    private System.Windows.Forms.TextBox textBox1;
    private System.Windows.Forms.Button positionButton;
    private System.Windows.Forms.Button startButton;
    private System.Windows.Forms.Button previousButton;
    private System.Windows.Forms.Button nextButton;
    private System.Windows.Forms.Button endButton;
    private System.Windows.Forms.TextBox textBox2;
    private System.Windows.Forms.Button addButton;
    private System.Windows.Forms.Button updateButton;
    private System.Windows.Forms.Button deleteButton;
    private System.Windows.Forms.ListBox listBox1;
    private System.Windows.Forms.Button showButton;
    private System.Windows.Forms.StatusBar statusBar1;
    private System.Windows.Forms.Button replaceDataSetButton;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public CurrencyForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.customersAdapter = new System.Data.SqlClient.SqlDataAdapter();
      this.sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
      this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
      this.sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
      this.sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
      this.sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
      this.customerSet1 = new DataBinding.CustomerSet();
      this.textBox1 = new System.Windows.Forms.TextBox();
      this.positionButton = new System.Windows.Forms.Button();
      this.startButton = new System.Windows.Forms.Button();
      this.previousButton = new System.Windows.Forms.Button();
      this.nextButton = new System.Windows.Forms.Button();
      this.endButton = new System.Windows.Forms.Button();
      this.textBox2 = new System.Windows.Forms.TextBox();
      this.addButton = new System.Windows.Forms.Button();
      this.updateButton = new System.Windows.Forms.Button();
      this.deleteButton = new System.Windows.Forms.Button();
      this.listBox1 = new System.Windows.Forms.ListBox();
      this.showButton = new System.Windows.Forms.Button();
      this.statusBar1 = new System.Windows.Forms.StatusBar();
      this.replaceDataSetButton = new System.Windows.Forms.Button();
      ((System.ComponentModel.ISupportInitialize)(this.customerSet1)).BeginInit();
      this.SuspendLayout();
      // 
      // customersAdapter
      // 
      this.customersAdapter.DeleteCommand = this.sqlDeleteCommand1;
      this.customersAdapter.InsertCommand = this.sqlInsertCommand1;
      this.customersAdapter.SelectCommand = this.sqlSelectCommand1;
      this.customersAdapter.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
                                                                                               new System.Data.Common.DataTableMapping("Table", "Customers", new System.Data.Common.DataColumnMapping[] {
                                                                                                                                                                                                          new System.Data.Common.DataColumnMapping("CustomerID", "CustomerID"),
                                                                                                                                                                                                          new System.Data.Common.DataColumnMapping("CompanyName", "CompanyName"),
                                                                                                                                                                                                          new System.Data.Common.DataColumnMapping("ContactName", "ContactName"),
                                                                                                                                                                                                          new System.Data.Common.DataColumnMapping("ContactTitle", "ContactTitle"),
                                                                                                                                                                                                          new System.Data.Common.DataColumnMapping("Address", "Address"),
                                                                                                                                                                                                          new System.Data.Common.DataColumnMapping("City", "City"),
                                                                                                                                                                                                          new System.Data.Common.DataColumnMapping("Region", "Region"),
                                                                                                                                                                                                          new System.Data.Common.DataColumnMapping("PostalCode", "PostalCode"),
                                                                                                                                                                                                          new System.Data.Common.DataColumnMapping("Country", "Country"),
                                                                                                                                                                                                          new System.Data.Common.DataColumnMapping("Phone", "Phone"),
                                                                                                                                                                                                          new System.Data.Common.DataColumnMapping("Fax", "Fax")})});
      this.customersAdapter.UpdateCommand = this.sqlUpdateCommand1;
      // 
      // sqlDeleteCommand1
      // 
      this.sqlDeleteCommand1.CommandText = @"DELETE FROM Customers WHERE (CustomerID = @Original_CustomerID) AND (Address = @Original_Address OR @Original_Address IS NULL AND Address IS NULL) AND (City = @Original_City OR @Original_City IS NULL AND City IS NULL) AND (CompanyName = @Original_CompanyName) AND (ContactName = @Original_ContactName OR @Original_ContactName IS NULL AND ContactName IS NULL) AND (ContactTitle = @Original_ContactTitle OR @Original_ContactTitle IS NULL AND ContactTitle IS NULL) AND (Country = @Original_Country OR @Original_Country IS NULL AND Country IS NULL) AND (Fax = @Original_Fax OR @Original_Fax IS NULL AND Fax IS NULL) AND (Phone = @Original_Phone OR @Original_Phone IS NULL AND Phone IS NULL) AND (PostalCode = @Original_PostalCode OR @Original_PostalCode IS NULL AND PostalCode IS NULL) AND (Region = @Original_Region OR @Original_Region IS NULL AND Region IS NULL)";
      this.sqlDeleteCommand1.Connection = this.sqlConnection1;
      this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CustomerID", System.Data.SqlDbType.NVarChar, 5, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CustomerID", System.Data.DataRowVersion.Original, null));
      this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Address", System.Data.SqlDbType.NVarChar, 60, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Address", System.Data.DataRowVersion.Original, null));
      this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_City", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "City", System.Data.DataRowVersion.Original, null));
      this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CompanyName", System.Data.SqlDbType.NVarChar, 40, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CompanyName", System.Data.DataRowVersion.Original, null));
      this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ContactName", System.Data.SqlDbType.NVarChar, 30, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ContactName", System.Data.DataRowVersion.Original, null));
      this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ContactTitle", System.Data.SqlDbType.NVarChar, 30, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ContactTitle", System.Data.DataRowVersion.Original, null));
      this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Country", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Country", System.Data.DataRowVersion.Original, null));
      this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Fax", System.Data.SqlDbType.NVarChar, 24, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Fax", System.Data.DataRowVersion.Original, null));
      this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Phone", System.Data.SqlDbType.NVarChar, 24, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Phone", System.Data.DataRowVersion.Original, null));
      this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PostalCode", System.Data.SqlDbType.NVarChar, 10, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PostalCode", System.Data.DataRowVersion.Original, null));
      this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Region", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Region", System.Data.DataRowVersion.Original, null));
      // 
      // sqlConnection1
      // 
      this.sqlConnection1.ConnectionString = "data source=MUNGO\\NetSDK;initial catalog=Northwind;integrated security=SSPI;persi" +
        "st security info=False;workstation id=MUNGO;packet size=4096";
      // 
      // sqlInsertCommand1
      // 
      this.sqlInsertCommand1.CommandText = @"INSERT INTO Customers(CustomerID, CompanyName, ContactName, ContactTitle, Address, City, Region, PostalCode, Country, Phone, Fax) VALUES (@CustomerID, @CompanyName, @ContactName, @ContactTitle, @Address, @City, @Region, @PostalCode, @Country, @Phone, @Fax); SELECT CustomerID, CompanyName, ContactName, ContactTitle, Address, City, Region, PostalCode, Country, Phone, Fax FROM Customers WHERE (CustomerID = @CustomerID)";
      this.sqlInsertCommand1.Connection = this.sqlConnection1;
      this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CustomerID", System.Data.SqlDbType.NVarChar, 5, "CustomerID"));
      this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CompanyName", System.Data.SqlDbType.NVarChar, 40, "CompanyName"));
      this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ContactName", System.Data.SqlDbType.NVarChar, 30, "ContactName"));
      this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ContactTitle", System.Data.SqlDbType.NVarChar, 30, "ContactTitle"));
      this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Address", System.Data.SqlDbType.NVarChar, 60, "Address"));
      this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@City", System.Data.SqlDbType.NVarChar, 15, "City"));
      this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Region", System.Data.SqlDbType.NVarChar, 15, "Region"));
      this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PostalCode", System.Data.SqlDbType.NVarChar, 10, "PostalCode"));
      this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Country", System.Data.SqlDbType.NVarChar, 15, "Country"));
      this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Phone", System.Data.SqlDbType.NVarChar, 24, "Phone"));
      this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Fax", System.Data.SqlDbType.NVarChar, 24, "Fax"));
      // 
      // sqlSelectCommand1
      // 
      this.sqlSelectCommand1.CommandText = "SELECT CustomerID, CompanyName, ContactName, ContactTitle, Address, City, Region," +
        " PostalCode, Country, Phone, Fax FROM Customers";
      this.sqlSelectCommand1.Connection = this.sqlConnection1;
      // 
      // sqlUpdateCommand1
      // 
      this.sqlUpdateCommand1.CommandText = @"UPDATE Customers SET CustomerID = @CustomerID, CompanyName = @CompanyName, ContactName = @ContactName, ContactTitle = @ContactTitle, Address = @Address, City = @City, Region = @Region, PostalCode = @PostalCode, Country = @Country, Phone = @Phone, Fax = @Fax WHERE (CustomerID = @Original_CustomerID) AND (Address = @Original_Address OR @Original_Address IS NULL AND Address IS NULL) AND (City = @Original_City OR @Original_City IS NULL AND City IS NULL) AND (CompanyName = @Original_CompanyName) AND (ContactName = @Original_ContactName OR @Original_ContactName IS NULL AND ContactName IS NULL) AND (ContactTitle = @Original_ContactTitle OR @Original_ContactTitle IS NULL AND ContactTitle IS NULL) AND (Country = @Original_Country OR @Original_Country IS NULL AND Country IS NULL) AND (Fax = @Original_Fax OR @Original_Fax IS NULL AND Fax IS NULL) AND (Phone = @Original_Phone OR @Original_Phone IS NULL AND Phone IS NULL) AND (PostalCode = @Original_PostalCode OR @Original_PostalCode IS NULL AND PostalCode IS NULL) AND (Region = @Original_Region OR @Original_Region IS NULL AND Region IS NULL); SELECT CustomerID, CompanyName, ContactName, ContactTitle, Address, City, Region, PostalCode, Country, Phone, Fax FROM Customers WHERE (CustomerID = @CustomerID)";
      this.sqlUpdateCommand1.Connection = this.sqlConnection1;
      this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CustomerID", System.Data.SqlDbType.NVarChar, 5, "CustomerID"));
      this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@CompanyName", System.Data.SqlDbType.NVarChar, 40, "CompanyName"));
      this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ContactName", System.Data.SqlDbType.NVarChar, 30, "ContactName"));
      this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ContactTitle", System.Data.SqlDbType.NVarChar, 30, "ContactTitle"));
      this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Address", System.Data.SqlDbType.NVarChar, 60, "Address"));
      this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@City", System.Data.SqlDbType.NVarChar, 15, "City"));
      this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Region", System.Data.SqlDbType.NVarChar, 15, "Region"));
      this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@PostalCode", System.Data.SqlDbType.NVarChar, 10, "PostalCode"));
      this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Country", System.Data.SqlDbType.NVarChar, 15, "Country"));
      this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Phone", System.Data.SqlDbType.NVarChar, 24, "Phone"));
      this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Fax", System.Data.SqlDbType.NVarChar, 24, "Fax"));
      this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CustomerID", System.Data.SqlDbType.NVarChar, 5, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CustomerID", System.Data.DataRowVersion.Original, null));
      this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Address", System.Data.SqlDbType.NVarChar, 60, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Address", System.Data.DataRowVersion.Original, null));
      this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_City", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "City", System.Data.DataRowVersion.Original, null));
      this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_CompanyName", System.Data.SqlDbType.NVarChar, 40, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "CompanyName", System.Data.DataRowVersion.Original, null));
      this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ContactName", System.Data.SqlDbType.NVarChar, 30, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ContactName", System.Data.DataRowVersion.Original, null));
      this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_ContactTitle", System.Data.SqlDbType.NVarChar, 30, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "ContactTitle", System.Data.DataRowVersion.Original, null));
      this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Country", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Country", System.Data.DataRowVersion.Original, null));
      this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Fax", System.Data.SqlDbType.NVarChar, 24, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Fax", System.Data.DataRowVersion.Original, null));
      this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Phone", System.Data.SqlDbType.NVarChar, 24, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Phone", System.Data.DataRowVersion.Original, null));
      this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_PostalCode", System.Data.SqlDbType.NVarChar, 10, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "PostalCode", System.Data.DataRowVersion.Original, null));
      this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Region", System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Region", System.Data.DataRowVersion.Original, null));
      // 
      // customerSet1
      // 
      this.customerSet1.DataSetName = "CustomerSet";
      this.customerSet1.Locale = new System.Globalization.CultureInfo("en-US");
      this.customerSet1.Namespace = "http://tempuri.org/CustomerSet.xsd";
      // 
      // textBox1
      // 
      this.textBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerSet1, "Customers.ContactTitle"));
      this.textBox1.Location = new System.Drawing.Point(8, 16);
      this.textBox1.Name = "textBox1";
      this.textBox1.Size = new System.Drawing.Size(120, 20);
      this.textBox1.TabIndex = 0;
      this.textBox1.Text = "textBox1";
      this.textBox1.Leave += new System.EventHandler(this.textBox1_Leave);
      // 
      // positionButton
      // 
      this.positionButton.Location = new System.Drawing.Point(112, 48);
      this.positionButton.Name = "positionButton";
      this.positionButton.Size = new System.Drawing.Size(40, 23);
      this.positionButton.TabIndex = 3;
      this.positionButton.Text = "Pos";
      this.positionButton.Click += new System.EventHandler(this.positionButton_Click);
      // 
      // startButton
      // 
      this.startButton.Location = new System.Drawing.Point(8, 48);
      this.startButton.Name = "startButton";
      this.startButton.Size = new System.Drawing.Size(40, 23);
      this.startButton.TabIndex = 1;
      this.startButton.Text = "|<";
      this.startButton.Click += new System.EventHandler(this.startButton_Click);
      // 
      // previousButton
      // 
      this.previousButton.Location = new System.Drawing.Point(56, 48);
      this.previousButton.Name = "previousButton";
      this.previousButton.Size = new System.Drawing.Size(40, 23);
      this.previousButton.TabIndex = 2;
      this.previousButton.Text = "<";
      this.previousButton.Click += new System.EventHandler(this.previousButton_Click);
      // 
      // nextButton
      // 
      this.nextButton.Location = new System.Drawing.Point(168, 48);
      this.nextButton.Name = "nextButton";
      this.nextButton.Size = new System.Drawing.Size(40, 23);
      this.nextButton.TabIndex = 4;
      this.nextButton.Text = ">";
      this.nextButton.Click += new System.EventHandler(this.nextButton_Click);
      // 
      // endButton
      // 
      this.endButton.Location = new System.Drawing.Point(216, 48);
      this.endButton.Name = "endButton";
      this.endButton.Size = new System.Drawing.Size(40, 23);
      this.endButton.TabIndex = 5;
      this.endButton.Text = ">|";
      this.endButton.Click += new System.EventHandler(this.endButton_Click);
      // 
      // textBox2
      // 
      this.textBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerSet1, "Customers.ContactName"));
      this.textBox2.Location = new System.Drawing.Point(136, 16);
      this.textBox2.Name = "textBox2";
      this.textBox2.Size = new System.Drawing.Size(120, 20);
      this.textBox2.TabIndex = 0;
      this.textBox2.Text = "textBox1";
      // 
      // addButton
      // 
      this.addButton.Location = new System.Drawing.Point(8, 80);
      this.addButton.Name = "addButton";
      this.addButton.Size = new System.Drawing.Size(56, 23);
      this.addButton.TabIndex = 6;
      this.addButton.Text = "Add";
      this.addButton.Click += new System.EventHandler(this.addButton_Click);
      // 
      // updateButton
      // 
      this.updateButton.Location = new System.Drawing.Point(64, 80);
      this.updateButton.Name = "updateButton";
      this.updateButton.Size = new System.Drawing.Size(56, 23);
      this.updateButton.TabIndex = 6;
      this.updateButton.Text = "Update";
      this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
      // 
      // deleteButton
      // 
      this.deleteButton.Location = new System.Drawing.Point(120, 80);
      this.deleteButton.Name = "deleteButton";
      this.deleteButton.Size = new System.Drawing.Size(56, 23);
      this.deleteButton.TabIndex = 6;
      this.deleteButton.Text = "Delete";
      this.deleteButton.Click += new System.EventHandler(this.deleteButton_Click);
      // 
      // listBox1
      // 
      this.listBox1.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.listBox1.DataSource = this.customerSet1;
      this.listBox1.DisplayMember = "Customers.ContactTitleName";
      this.listBox1.IntegralHeight = false;
      this.listBox1.Location = new System.Drawing.Point(8, 112);
      this.listBox1.Name = "listBox1";
      this.listBox1.Size = new System.Drawing.Size(248, 96);
      this.listBox1.TabIndex = 7;
      this.listBox1.ValueMember = "Customers.CustomerID";
      this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
      // 
      // showButton
      // 
      this.showButton.Location = new System.Drawing.Point(176, 80);
      this.showButton.Name = "showButton";
      this.showButton.Size = new System.Drawing.Size(56, 23);
      this.showButton.TabIndex = 6;
      this.showButton.Text = "Show";
      this.showButton.Click += new System.EventHandler(this.showButton_Click);
      // 
      // statusBar1
      // 
      this.statusBar1.Location = new System.Drawing.Point(0, 216);
      this.statusBar1.Name = "statusBar1";
      this.statusBar1.Size = new System.Drawing.Size(264, 22);
      this.statusBar1.TabIndex = 8;
      this.statusBar1.Text = "statusBar1";
      // 
      // replaceDataSetButton
      // 
      this.replaceDataSetButton.Location = new System.Drawing.Point(232, 80);
      this.replaceDataSetButton.Name = "replaceDataSetButton";
      this.replaceDataSetButton.Size = new System.Drawing.Size(24, 23);
      this.replaceDataSetButton.TabIndex = 6;
      this.replaceDataSetButton.Text = "!";
      this.replaceDataSetButton.Click += new System.EventHandler(this.replaceDataSetButton_Click);
      // 
      // CurrencyForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(264, 238);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.statusBar1,
                                                                  this.listBox1,
                                                                  this.addButton,
                                                                  this.startButton,
                                                                  this.positionButton,
                                                                  this.textBox1,
                                                                  this.previousButton,
                                                                  this.nextButton,
                                                                  this.endButton,
                                                                  this.textBox2,
                                                                  this.updateButton,
                                                                  this.deleteButton,
                                                                  this.showButton,
                                                                  this.replaceDataSetButton});
      this.Name = "CurrencyForm";
      this.Text = "Data Binding to Data Sets";
      this.Load += new System.EventHandler(this.CurrencyForm_Load);
      ((System.ComponentModel.ISupportInitialize)(this.customerSet1)).EndInit();
      this.ResumeLayout(false);

    }
		#endregion

    void CurrencyForm_Load(object sender, EventArgs e) {
      // Custom format and parse the ContactTitle
      // NOTE: subscribe to this before filling the data set
      Binding binding = textBox1.DataBindings["Text"];
      binding.Format += new ConvertEventHandler(textBox1_Format);
      binding.Parse += new ConvertEventHandler(textBox1_Parse);

      //      // Create a sorting view
      //      DataView sortView = new DataView(customerSet1.Customers);
      //      sortView.Sort = "ContactTitle ASC, ContactName DESC";
      //
//            // Create a filtering view
//            DataView filterView = new DataView(customerSet1.Customers);
//            filterView.RowFilter = "ContactTitle = 'Owner'";
//            listBox1.DataSource = filterView;
//            listBox1.DisplayMember = "ContactTitleName";
      //
      //      // Bind to the view
      //      listBox1.DataSource = sortView;
      //      listBox1.DisplayMember = "ContactTitleName";

      // Set the sorting and filtering criteria of the default view
      customerSet1.Customers.DefaultView.Sort = "ContactName DESC";
      customerSet1.Customers.DefaultView.RowFilter =
        "ContactTitle = 'Owner'";

      // Fill the data set
      customersAdapter.Fill(customerSet1, "Customers");

      // 1. Bind to data + table.column (good!)
      //textBox1.DataBindings.Add(
      //  "Text", customerSet1, "Customers.ContactTitleName");

      // 2. Bind the table + column (BAD!)
      //textBox1.DataBindings.Add(
      //  "Text", customerSet1.Customers, "ContactTitleName");
    }

    void textBox1_Format(object sender, ConvertEventArgs e) {
      // Show ContactTitle as all caps
      System.Diagnostics.Debug.Assert(e.DesiredType == typeof(String));
      e.Value = e.Value.ToString().ToUpper();
    }

    void textBox1_Parse(object sender, ConvertEventArgs e) {
      // Convert ContactTitle to mixed case
      e.Value = MixedCase(e.Value.ToString());
    }

    static bool IsAlpha(char ch) {
      return (ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z');
    }

    string MixedCase(string s) {
      System.Text.StringBuilder sb = new System.Text.StringBuilder();
      bool needInitialCap = true;
      for( int i = 0; i != s.Length; ++i ) {
        if( IsAlpha(s[i]) ) {
          if( needInitialCap ) {
            sb.Append(s[i].ToString().ToUpper());
            needInitialCap = false;
          }
          else {
            sb.Append(s[i].ToString().ToLower());
          }
        }
        else {
          sb.Append(s[i]);
          needInitialCap = true;
        }
      }

      return sb.ToString();
    }

    void positionButton_Click(object sender, EventArgs e) {
      //Binding binding = textBox1.DataBindings["Text"];
      //BindingManagerBase manager = binding.BindingManagerBase;
      BindingManagerBase manager = this.BindingContext[customerSet1, "Customers"];

      // Get current position
      int pos = manager.Position;
      MessageBox.Show(pos.ToString(), "Current Position");

      // Check the binding manager
      BindingManagerBase manager1 =
        textBox1.DataBindings["Text"].BindingManagerBase;
      BindingManagerBase manager2 =
        textBox2.DataBindings["Text"].BindingManagerBase;
      BindingManagerBase manager3 =
        this.BindingContext[customerSet1, "Customers"];
      // BAD!
      BindingManagerBase manager4 =
        this.BindingContext[customerSet1.Customers];
      System.Diagnostics.Debug.Assert(manager1 == manager2);
      System.Diagnostics.Debug.Assert(manager2 == manager3);
      System.Diagnostics.Debug.Assert(manager3 != manager4);
    }

    void startButton_Click(object sender, EventArgs e) {
      // Reset the position
      //Binding binding = textBox1.DataBindings["Text"];
      //BindingManagerBase manager = binding.BindingManagerBase;
      BindingManagerBase manager = this.BindingContext[customerSet1, "Customers"];
      manager.Position = 0;
    }

    void previousButton_Click(object sender, EventArgs e) {
      // Decrement the position
      //Binding binding = textBox1.DataBindings["Text"];
      //BindingManagerBase manager = binding.BindingManagerBase;
      BindingManagerBase manager = this.BindingContext[customerSet1, "Customers"];
      --manager.Position; // No need to worry about being <0
    }

    void nextButton_Click(object sender, EventArgs e) {
      // Increment the position
      //Binding binding = textBox1.DataBindings["Text"];
      //BindingManagerBase manager = binding.BindingManagerBase;
      BindingManagerBase manager = this.BindingContext[customerSet1, "Customers"];
      ++manager.Position; // No need to worry about being >Count
    }

    void endButton_Click(object sender, EventArgs e) {
      // Set position to end
      //Binding binding = textBox1.DataBindings["Text"];
      //BindingManagerBase manager = binding.BindingManagerBase;
      BindingManagerBase manager = this.BindingContext[customerSet1, "Customers"];
      manager.Position = manager.Count - 1;
    }

    void addButton_Click(object sender, EventArgs e) {
      // Add a new row
      CustomerSet.CustomersRow row =
        this.customerSet1.Customers.NewCustomersRow();
      row.CustomerID = "SELLSB";
      row.CompanyName = "Sells Brothers, Inc.";
      row.ContactName = "Chris Sells";
      row.ContactTitle = "Chief Cook and Bottle Washer";
      row.Address = "555 Not My Street";
      row.City = "Beaverton";
      row.Region = "OR";
      row.PostalCode = "97007";
      row.Country = "USA";
      row.Phone = "503-555-1234";
      row.Fax = "503-555-4321";
      this.customerSet1.Customers.AddCustomersRow(row);

      // Controls automatically updated
      // (except some controls, e.g. listbox, need a nudge)
      CurrencyManager manager =
        this.BindingContext[customerSet1, "Customers"]
        as CurrencyManager;
      if( manager != null ) manager.Refresh();
    }

    void updateButton_Click(object sender, EventArgs e) {
      // Update the current row
      BindingManagerBase manager =
        this.BindingContext[customerSet1, "Customers"];
      DataRowView view = (DataRowView)manager.Current;
      CustomerSet.CustomersRow row = (CustomerSet.CustomersRow)view.Row;
      row.ContactTitle = "CEO";

      // Controls automatically updated
    }

    void deleteButton_Click(object sender, EventArgs e) {
      // Mark the current row as deleted
      BindingManagerBase manager =
        this.BindingContext[customerSet1, "Customers"];
      DataRowView view = (DataRowView)manager.Current;
      CustomerSet.CustomersRow row = (CustomerSet.CustomersRow)view.Row;
      row.Delete();

      // Controls automatically updated
      // (no special treatment needed to avoid deleted rows!)
    }

    void showButton_Click(object sender, EventArgs e) {
      // Get the binding manager
      BindingManagerBase manager =
        this.BindingContext[customerSet1, "Customers"];

      // Get the current row via the view
      DataRowView view = (DataRowView)manager.Current;
      CustomerSet.CustomersRow row = (CustomerSet.CustomersRow)view.Row;

      MessageBox.Show(row.ContactTitleName, "Current Row");
    }

    void textBox1_Leave(object sender, EventArgs e) {
      // Force the current edit to end
      BindingManagerBase manager =
        this.BindingContext[customerSet1, "Customers"];
      manager.EndCurrentEdit();
      //manager.CancelCurrentEdit();
    }

    void listBox1_SelectedIndexChanged(object sender, EventArgs e) {
      if( listBox1.SelectedValue == null ) return;

      // Get the currently selected row's CustomerID using ValueMember
      statusBar1.Text = "Selected CustomerID= " + listBox1.SelectedValue;

      if( listBox1.SelectedValue == null ) return;

      // Get the currently selected row's CustomerID using current item
      DataRowView view = (DataRowView)listBox1.SelectedItem;
      CustomerSet.CustomersRow row = (CustomerSet.CustomersRow)view.Row;
      statusBar1.Text = "Selected CustomerID= " + row.CustomerID;
    }

    void replaceDataSetButton_Click(object sender, EventArgs e) {
      DialogResult res = MessageBox.Show("Replace current data set?", "DataBinding", MessageBoxButtons.YesNo);
      if( res == DialogResult.No ) return;

      // Replace current data set with new one
      CustomerSet newCustomers = new CustomerSet();
      CustomerSet.CustomersRow row = newCustomers.Customers.NewCustomersRow();
      row.CustomerID = "SELLSB1";
      row.CompanyName = "Sells Brothers, Inc.";
      row.ContactName = "Chris Sells";
      row.ContactTitle = "Chief Cook and Bottle Washer";
      row.Address = "555 Not My Street";
      row.City = "Beaverton";
      row.Region = "OR";
      row.PostalCode = "97007";
      row.Country = "USA";
      row.Phone = "503-555-1234";
      row.Fax = "503-555-4321";
      newCustomers.Customers.AddCustomersRow(row);

      row = newCustomers.Customers.NewCustomersRow();
      row.CustomerID = "SELLSB2";
      row.CompanyName = "Sells Brothers, Inc.";
      row.ContactName = "Chris Sells2";
      row.ContactTitle = "Chief Cook and Bottle Washer";
      row.Address = "555 Not My Street";
      row.City = "Beaverton";
      row.Region = "OR";
      row.PostalCode = "97007";
      row.Country = "USA";
      row.Phone = "503-555-1234";
      row.Fax = "503-555-4321";
      newCustomers.Customers.AddCustomersRow(row);

      // Replacing the old data set with a new one doesn't work,
      // as all of the controls are still bound to the old data set
      //this.customerSet1 = newCustomers; // WON'T WORK

      // Replacing the contents of the existing data set with the
      // contents of the new data set leaves all of the data bindings
      // in place
      BindingManagerBase manager = this.BindingContext[customerSet1, "Customers"];
      manager.SuspendBinding();
      this.customerSet1.Clear();
      this.customerSet1.Merge(newCustomers.Customers);
      manager.ResumeBinding();
    }



  }
}










