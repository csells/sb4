using System;
using System.Globalization;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CustomDataSources {
  /// <summary>
  /// Summary description for CustomItemDataSourceForm2.
  /// </summary>
  public class CustomItemDataSourceForm2 : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public CustomItemDataSourceForm2() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.label1 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.textBox1 = new System.Windows.Forms.TextBox();
      this.textBox2 = new System.Windows.Forms.TextBox();
      this.setNameButton = new System.Windows.Forms.Button();
      this.setNumberButton = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(16, 16);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(56, 23);
      this.label1.TabIndex = 0;
      this.label1.Text = "Name";
      this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // label2
      // 
      this.label2.Location = new System.Drawing.Point(16, 48);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(56, 23);
      this.label2.TabIndex = 3;
      this.label2.Text = "Number";
      this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // textBox1
      // 
      this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.textBox1.Location = new System.Drawing.Point(72, 16);
      this.textBox1.Name = "textBox1";
      this.textBox1.Size = new System.Drawing.Size(120, 20);
      this.textBox1.TabIndex = 1;
      this.textBox1.Text = "";
      // 
      // textBox2
      // 
      this.textBox2.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.textBox2.Location = new System.Drawing.Point(72, 48);
      this.textBox2.Name = "textBox2";
      this.textBox2.Size = new System.Drawing.Size(120, 20);
      this.textBox2.TabIndex = 4;
      this.textBox2.Text = "";
      // 
      // setNameButton
      // 
      this.setNameButton.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
      this.setNameButton.Location = new System.Drawing.Point(208, 16);
      this.setNameButton.Name = "setNameButton";
      this.setNameButton.Size = new System.Drawing.Size(40, 23);
      this.setNameButton.TabIndex = 2;
      this.setNameButton.Text = "Set";
      this.setNameButton.Click += new System.EventHandler(this.setNameButton_Click);
      // 
      // setNumberButton
      // 
      this.setNumberButton.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
      this.setNumberButton.Location = new System.Drawing.Point(208, 48);
      this.setNumberButton.Name = "setNumberButton";
      this.setNumberButton.Size = new System.Drawing.Size(40, 23);
      this.setNumberButton.TabIndex = 5;
      this.setNumberButton.Text = "Set";
      this.setNumberButton.Click += new System.EventHandler(this.setNumberButton_Click);
      // 
      // CustomItemDataSourceForm2
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(256, 86);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.setNameButton,
                                                                  this.textBox1,
                                                                  this.label1,
                                                                  this.label2,
                                                                  this.textBox2,
                                                                  this.setNumberButton});
      this.Name = "CustomItemDataSourceForm2";
      this.Text = "Custom Item Data Source";
      this.Load += new System.EventHandler(this.CustomItemDataSourceForm2_Load);
      this.ResumeLayout(false);

    }
		#endregion

    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.TextBox textBox1;
    private System.Windows.Forms.TextBox textBox2;
    private System.Windows.Forms.Button setNameButton;
    private System.Windows.Forms.Button setNumberButton;

    class FractionTypeConverter : TypeConverter {
      public override bool
        CanConvertFrom(
        ITypeDescriptorContext context,
        Type sourceType) {
        return sourceType == typeof(string);
      }

      public override bool
        CanConvertTo(
        ITypeDescriptorContext context,
        Type destinationType) {
        return destinationType == typeof(string);
      }

      public override object
        ConvertFrom(
        ITypeDescriptorContext context,
        CultureInfo culture,
        object value) {

        // Very simple context, culture and error-ignoring conversion
        string from = (string)value;
        int slash = from.IndexOf("/");
        int numerator = int.Parse(from.Substring(0, slash));
        int denominator = int.Parse(from.Substring(slash + 1));
        return new Fraction(numerator, denominator);
      }

      public override object
        ConvertTo(
        ITypeDescriptorContext context,
        CultureInfo culture,
        object value,
        Type destinationType) {
        if( destinationType != typeof(string) ) return null;
        Fraction number = (Fraction)value;
        return string.Format("{0}/{1}", number.Numerator, number.Denominator);
      }
    }

    [TypeConverterAttribute(typeof(FractionTypeConverter))]
      class Fraction {
      public Fraction(int numerator, int denominator) {
        this.numerator = numerator;
        this.denominator = denominator;
      }

      public int Numerator {
        get { return this.numerator; }
        set { this.numerator = value; }
      }

      public int Denominator {
        get { return this.denominator; }
        set { this.denominator = value; }
      }

      //      public override string ToString() {
      //        return string.Format("{0}/{1}", numerator, denominator);
      //      }

      int numerator;
      int denominator;
    }

    // Expose two properties for binding
    class NameAndNumber {
      // For bound controls
      public event EventHandler NameChanged;
      public string Name {
        get { return name; }
        set {
          name = value;
          // Notify bound control of changes
          if( NameChanged != null ) NameChanged(this, EventArgs.Empty);
        }
      }

      // For bound controls
      public event EventHandler NumberChanged;
      public Fraction Number {
        get { return number; }
        set {
          number = value;
          // Notify bound control of changes
          if( NumberChanged != null ) NumberChanged(this, EventArgs.Empty);
        }
      }

      string name = "Chris";
      Fraction number = new Fraction(452, 1);
    }

    NameAndNumber source = new NameAndNumber();

    void CustomItemDataSourceForm2_Load(object sender, EventArgs e) {
      textBox1.DataBindings.Add("Text", source, "Name");

      //      // Bind to a property of a custom type
      //      // and handle the parsing
      //      Binding binding =
      //        textBox2.DataBindings.Add("Text", source, "Number");
      //      binding.Parse += new ConvertEventHandler(textBox2_Parse);

      // Let the custom binding handling the parsing work-around
      Binding binding =
        new WorkAroundBinding("Text", source, "Number");
      textBox2.DataBindings.Add(binding);
    }

    //    void textBox2_Parse(object sender, ConvertEventArgs e) {
    //      //  string from = (string)e.Value;
    //      //  int slash = from.IndexOf("/");
    //      //  int numerator = int.Parse(from.Substring(0, slash));
    //      //  int denominator = int.Parse(from.Substring(slash + 1));
    //      //  e.Value = new Fraction(numerator, denominator);
    //
    //      // Let the type converter do the work
    //      TypeConverter converter = TypeDescriptor.GetConverter(e.DesiredType);
    //      if( converter == null ) return;
    //      if( !converter.CanConvertFrom(e.Value.GetType()) ) return;
    //      e.Value = converter.ConvertFrom(e.Value);
    //    }

    class WorkAroundBinding : Binding {
      public WorkAroundBinding(string name, object src, string member)
        : base(name, src, member) {
      }

      protected override void OnParse(ConvertEventArgs e) {
        try {
          // Let the base class have a crack
          base.OnParse(e);
        }
        catch( InvalidCastException ) {
          // Take over for base class if it fails

          // If one of the base class event handlers converted it,
          // we're done
          if(  e.Value.GetType().IsSubclassOf(e.DesiredType) ||
            (e.Value.GetType() == e.DesiredType) ||
            (e.Value is DBNull) ) {
            return;
          }

          // Ask the desired type for a type converter
          TypeConverter converter =
            TypeDescriptor.GetConverter(e.DesiredType);
          if( (converter !=  null) &&
            converter.CanConvertFrom(e.Value.GetType()) ) {
            e.Value = converter.ConvertFrom(e.Value);
          }
        }
      }
    }

    void setNameButton_Click(object sender, EventArgs e) {
      // Changes replicated to textBox1.Text
      source.Name = "Joe";
    }

    void setNumberButton_Click(object sender, EventArgs e) {
      source.Number = new Fraction(452, 2);
    }

  }
}













