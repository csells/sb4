using System;
using System.Globalization;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CustomDataSources {
  /// <summary>
  /// Summary description for CustomListDataSourceForm.
  /// </summary>
  public class CustomListDataSourceForm : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public CustomListDataSourceForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.listBox1 = new System.Windows.Forms.ListBox();
      this.statusBar1 = new System.Windows.Forms.StatusBar();
      this.SuspendLayout();
      // 
      // listBox1
      // 
      this.listBox1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.listBox1.IntegralHeight = false;
      this.listBox1.Name = "listBox1";
      this.listBox1.Size = new System.Drawing.Size(256, 144);
      this.listBox1.TabIndex = 0;
      this.listBox1.SelectedValueChanged += new System.EventHandler(this.listBox1_SelectedValueChanged);
      // 
      // statusBar1
      // 
      this.statusBar1.Location = new System.Drawing.Point(0, 144);
      this.statusBar1.Name = "statusBar1";
      this.statusBar1.Size = new System.Drawing.Size(256, 22);
      this.statusBar1.TabIndex = 1;
      this.statusBar1.Text = "statusBar1";
      // 
      // CustomListDataSourceForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(256, 166);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.listBox1,
                                                                  this.statusBar1});
      this.Name = "CustomListDataSourceForm";
      this.Text = "Custom List Data Source";
      this.Load += new System.EventHandler(this.CustomListDataSourceForm_Load);
      this.ResumeLayout(false);

    }
		#endregion

    private System.Windows.Forms.ListBox listBox1;
    private System.Windows.Forms.StatusBar statusBar1;

    class FractionTypeConverter : TypeConverter {
      public override bool
        CanConvertFrom(
        ITypeDescriptorContext context,
        Type sourceType) {
        return sourceType == typeof(string);
      }

      public override bool
        CanConvertTo(
        ITypeDescriptorContext context,
        Type destinationType) {
        return destinationType == typeof(string);
      }

      public override object
        ConvertFrom(
        ITypeDescriptorContext context,
        CultureInfo culture,
        object value) {

        // Very simple context, culture and error-ignoring conversion
        string from = (string)value;
        int slash = from.IndexOf("/");
        int numerator = int.Parse(from.Substring(0, slash));
        int denominator = int.Parse(from.Substring(slash + 1));
        return new Fraction(numerator, denominator);
      }

      public override object
        ConvertTo(
        ITypeDescriptorContext context,
        CultureInfo culture,
        object value,
        Type destinationType) {
        if( destinationType != typeof(string) ) return null;
        Fraction number = (Fraction)value;
        return string.Format("{0}/{1}", number.Numerator, number.Denominator);
      }
    }

    [TypeConverterAttribute(typeof(FractionTypeConverter))]
      class Fraction {
      public Fraction(int numerator, int denominator) {
        this.numerator = numerator;
        this.denominator = denominator;
      }

      public int Numerator {
        get { return this.numerator; }
        set { this.numerator = value; }
      }

      public int Denominator {
        get { return this.denominator; }
        set { this.denominator = value; }
      }

      public override string ToString() {
        return string.Format("{0}/{1}", numerator, denominator);
      }

      int numerator;
      int denominator;
    }

    // Expose two properties for binding
    class NameAndNumber {
      public NameAndNumber(string name, int number) {
        this.name = name;
        this.number = new Fraction(number, 1);
      }

      // For bound controls
      public event EventHandler NameChanged;
      public string Name {
        get { return name; }
        set {
          name = value;
          // Notify bound control of changes
          if( NameChanged != null ) NameChanged(this, EventArgs.Empty);
        }
      }

      // For bound controls
      public event EventHandler NumberChanged;
      public Fraction Number {
        get { return number; }
        set {
          number = value;
          // Notify bound control of changes
          if( NumberChanged != null ) NumberChanged(this, EventArgs.Empty);
        }
      }

      public override string ToString() {
        return this.name + ", " + this.number;
      }

      string name = "Chris";
      Fraction number = new Fraction(452, 1);
    }

    NameAndNumber[] source = { new NameAndNumber("John", 8), new NameAndNumber("Tom", 7) };

    void CustomListDataSourceForm_Load(object sender, EventArgs e) {
      // Bind a collection of custom data sources complexly
      listBox1.DataSource = source;
      listBox1.DisplayMember = "Name";
      listBox1.ValueMember = "Number";
    }

    void listBox1_SelectedValueChanged(object sender, EventArgs e) {
      // Show selected value as selected index changes
      statusBar1.Text = "selected Number= " + listBox1.SelectedValue;
    }

  }
}













