using System;
using System.Globalization;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CustomDataSources {
  /// <summary>
  /// Summary description for CustomListDataSourceForm2.
  /// </summary>
  public class CustomListDataSourceForm2 : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public CustomListDataSourceForm2() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.dataGrid1 = new System.Windows.Forms.DataGrid();
      ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
      this.SuspendLayout();
      // 
      // dataGrid1
      // 
      this.dataGrid1.DataMember = "";
      this.dataGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dataGrid1.Name = "dataGrid1";
      this.dataGrid1.Size = new System.Drawing.Size(256, 166);
      this.dataGrid1.TabIndex = 0;
      // 
      // CustomListDataSourceForm2
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(256, 166);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.dataGrid1});
      this.Name = "CustomListDataSourceForm2";
      this.Text = "Custom List Data Source";
      this.Load += new System.EventHandler(this.CustomListDataSourceForm2_Load);
      ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
      this.ResumeLayout(false);

    }
		#endregion

    private System.Windows.Forms.DataGrid dataGrid1;

    // Lowest level objects:
    class Fraction {
      public Fraction(int numerator, int denominator) {
        this.numerator = numerator;
        this.denominator = denominator;
      }

      public int Numerator {
        get { return this.numerator; }
        set { this.numerator = value; }
      }

      public int Denominator {
        get { return this.denominator; }
        set { this.denominator = value; }
      }

      public override string ToString() {
        return string.Format("{0}/{1}", numerator, denominator);
      }

      int numerator;
      int denominator;
    }

    // Top-level objects:
    class NameAndNumbers {
      public NameAndNumbers(string name) {
        this.name = name;
      }

      public event EventHandler NameChanged;
      public string Name {
        get { return name; }
        set {
          name = value;
          if( NameChanged != null ) NameChanged(this, EventArgs.Empty);
        }
      }

      // Expose second-level hierarchy:
      // NOTE: DataGrid doesn't bind to arrays
      //public Fraction[] Numbers {
      public ArrayList Numbers {
        get { return this.numbers; }
      }

      // Add to second-level hierarchy
      public void AddNumber(Fraction number) {
        this.numbers.Add(number);
      }

      public override string ToString() {
        return this.name;
      }

      string name = "Chris";
      ArrayList numbers = new ArrayList(); // sub-objects
    }

    // Top-level collection:
    ArrayList source = new ArrayList();

    void CustomListDataSourceForm2_Load(object sender, EventArgs e) {
      // Populate the hierarchy
      NameAndNumbers nan1 = new NameAndNumbers("John");
      nan1.AddNumber(new Fraction(1, 2));
      nan1.AddNumber(new Fraction(2, 3));
      nan1.AddNumber(new Fraction(3, 4));
      source.Add(nan1);

      NameAndNumbers nan2 = new NameAndNumbers("Tom");
      nan2.AddNumber(new Fraction(4, 5));
      nan2.AddNumber(new Fraction(5, 6));
      source.Add(nan2);

      // Bind a collection of custom data sources complexly
      dataGrid1.DataSource = source;
    }

  }
}












