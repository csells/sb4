using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace ClockControlHost {
  /// <summary>
  /// Summary description for ClockControlHostForm.
  /// </summary>
  public class ClockControlHostForm : System.Windows.Forms.Form {
    private ClockControlLibrary.ClockControl clockControl1;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public ClockControlHostForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
        this.clockControl1 = new ClockControlLibrary.ClockControl();
        ((System.ComponentModel.ISupportInitialize)(this.clockControl1)).BeginInit();
        this.SuspendLayout();
        // 
        // clockControl1
        // 
        this.clockControl1.BackupAlarm = new System.DateTime(2003, 3, 13, 11, 12, 0, 0);
        this.clockControl1.HourHand = new ClockControlLibrary.Hand(System.Drawing.Color.HotPink, 3);
        this.clockControl1.Location = new System.Drawing.Point(8, 8);
        this.clockControl1.MessagesToSelf.AddRange(new ClockControlLibrary.MessageToSelf[] {
                                                                                               new ClockControlLibrary.MessageToSelf(new System.DateTime(2003, 2, 22, 21, 55, 0, 0), "Wake up")});
        this.clockControl1.MinuteHand = new ClockControlLibrary.Hand(System.Drawing.Color.Orange, 4);
        this.clockControl1.Name = "clockControl1";
        this.clockControl1.PrimaryAlarm = new System.DateTime(2003, 2, 22, 18, 35, 0, 0);
        this.clockControl1.SecondHand = new ClockControlLibrary.Hand(System.Drawing.Color.LightBlue, 7);
        this.clockControl1.Size = new System.Drawing.Size(236, 176);
        this.clockControl1.TabIndex = 0;
        this.clockControl1.Text = "clockControl1";
        this.clockControl1.AlarmSounded += new ClockControlLibrary.ClockControl.AlarmHandler(this.clockControl1_AlarmSounded);
        // 
        // ClockControlHostForm
        // 
        this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
        this.ClientSize = new System.Drawing.Size(253, 192);
        this.Controls.Add(this.clockControl1);
        this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
        this.MaximizeBox = false;
        this.MinimizeBox = false;
        this.Name = "ClockControlHostForm";
        this.Text = "Clock Control Host Form";
        ((System.ComponentModel.ISupportInitialize)(this.clockControl1)).EndInit();
        this.ResumeLayout(false);

    }
		#endregion

    private void clockControl1_AlarmSounded(object sender, ClockControlLibrary.AlarmEventArgs e) {
      if( e.AlarmType == ClockControlLibrary.AlarmType.Primary ) MessageBox.Show("Wake up now");
      if( e.AlarmType == ClockControlLibrary.AlarmType.Backup ) MessageBox.Show("Wake up now, really I mean it this time");    
    }
  }
}
