using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace ClockControlHost
{
	/// <summary>
	/// Summary description for ExtenderProviderForm.
	/// </summary>
	public class ExtenderProviderForm : System.Windows.Forms.Form
	{
    private System.Windows.Forms.PictureBox pictureBox1;
    private System.Windows.Forms.PictureBox pictureBox2;
    private System.Windows.Forms.PictureBox pictureBox3;
    private ClockControlLibrary.ClockControl clockControl1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ExtenderProviderForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ExtenderProviderForm));
      this.pictureBox1 = new System.Windows.Forms.PictureBox();
      this.pictureBox2 = new System.Windows.Forms.PictureBox();
      this.pictureBox3 = new System.Windows.Forms.PictureBox();
      this.clockControl1 = new ClockControlLibrary.ClockControl();
      ((System.ComponentModel.ISupportInitialize)(this.clockControl1)).BeginInit();
      this.SuspendLayout();
      // 
      // pictureBox1
      // 
      this.pictureBox1.Image = ((System.Drawing.Bitmap)(resources.GetObject("pictureBox1.Image")));
      this.pictureBox1.Location = new System.Drawing.Point(9, 9);
      this.pictureBox1.Name = "pictureBox1";
      this.pictureBox1.Size = new System.Drawing.Size(118, 184);
      this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
      this.pictureBox1.TabIndex = 0;
      this.pictureBox1.TabStop = false;
      this.clockControl1.SetTimeZoneModifier(this.pictureBox1, -11);
      // 
      // pictureBox2
      // 
      this.pictureBox2.Image = ((System.Drawing.Bitmap)(resources.GetObject("pictureBox2.Image")));
      this.pictureBox2.Location = new System.Drawing.Point(130, 9);
      this.pictureBox2.Name = "pictureBox2";
      this.pictureBox2.Size = new System.Drawing.Size(118, 184);
      this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
      this.pictureBox2.TabIndex = 1;
      this.pictureBox2.TabStop = false;
      // 
      // pictureBox3
      // 
      this.pictureBox3.Image = ((System.Drawing.Bitmap)(resources.GetObject("pictureBox3.Image")));
      this.pictureBox3.Location = new System.Drawing.Point(251, 9);
      this.pictureBox3.Name = "pictureBox3";
      this.pictureBox3.Size = new System.Drawing.Size(119, 184);
      this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
      this.pictureBox3.TabIndex = 2;
      this.pictureBox3.TabStop = false;
      this.clockControl1.SetTimeZoneModifier(this.pictureBox3, -19);
      // 
      // clockControl1
      // 
      this.clockControl1.BackupAlarm = new System.DateTime(2003, 1, 11, 19, 7, 58, 105);
      this.clockControl1.Face = ClockControlLibrary.ClockFace.Digital;
      this.clockControl1.Location = new System.Drawing.Point(9, 200);
      this.clockControl1.Name = "clockControl1";
      this.clockControl1.PrimaryAlarm = new System.DateTime(2003, 1, 11, 18, 57, 58, 105);
      this.clockControl1.Size = new System.Drawing.Size(361, 54);
      this.clockControl1.TabIndex = 3;
      this.clockControl1.Text = "clockControl1";
      // 
      // ExtenderProviderForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(380, 265);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.clockControl1,
                                                                  this.pictureBox3,
                                                                  this.pictureBox2,
                                                                  this.pictureBox1});
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "ExtenderProviderForm";
      this.Text = "Extender Provider Form";
      ((System.ComponentModel.ISupportInitialize)(this.clockControl1)).EndInit();
      this.ResumeLayout(false);

    }
		#endregion
	}
}
