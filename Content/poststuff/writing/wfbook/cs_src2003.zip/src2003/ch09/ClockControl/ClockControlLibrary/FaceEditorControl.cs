using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Data;
using System.Windows.Forms;
using System.Windows.Forms.Design;

namespace ClockControlLibrary
{
	/// <summary>
	/// Summary description for FaceEditorControl.
	/// </summary>
	internal class FaceEditorControl : System.Windows.Forms.UserControl  {
    private System.Windows.Forms.PictureBox picDigital;
    private System.Windows.Forms.PictureBox picAnalog;
    private System.Windows.Forms.PictureBox picBoth;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public FaceEditorControl()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitForm call

		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(FaceEditorControl));
      this.picDigital = new System.Windows.Forms.PictureBox();
      this.picAnalog = new System.Windows.Forms.PictureBox();
      this.picBoth = new System.Windows.Forms.PictureBox();
      this.SuspendLayout();
      // 
      // picDigital
      // 
      this.picDigital.BackColor = System.Drawing.SystemColors.Highlight;
      this.picDigital.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.picDigital.Image = ((System.Drawing.Bitmap)(resources.GetObject("picDigital.Image")));
      this.picDigital.Location = new System.Drawing.Point(152, 8);
      this.picDigital.Name = "picDigital";
      this.picDigital.Size = new System.Drawing.Size(65, 65);
      this.picDigital.TabIndex = 8;
      this.picDigital.TabStop = false;
      this.picDigital.Click += new System.EventHandler(this.picDigital_Click);
      // 
      // picAnalog
      // 
      this.picAnalog.BackColor = System.Drawing.SystemColors.Highlight;
      this.picAnalog.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.picAnalog.Image = ((System.Drawing.Bitmap)(resources.GetObject("picAnalog.Image")));
      this.picAnalog.Location = new System.Drawing.Point(80, 8);
      this.picAnalog.Name = "picAnalog";
      this.picAnalog.Size = new System.Drawing.Size(65, 65);
      this.picAnalog.TabIndex = 7;
      this.picAnalog.TabStop = false;
      this.picAnalog.Click += new System.EventHandler(this.picAnalog_Click);
      // 
      // picBoth
      // 
      this.picBoth.BackColor = System.Drawing.SystemColors.Highlight;
      this.picBoth.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.picBoth.Image = ((System.Drawing.Bitmap)(resources.GetObject("picBoth.Image")));
      this.picBoth.Location = new System.Drawing.Point(8, 8);
      this.picBoth.Name = "picBoth";
      this.picBoth.Size = new System.Drawing.Size(65, 65);
      this.picBoth.TabIndex = 6;
      this.picBoth.TabStop = false;
      this.picBoth.Click += new System.EventHandler(this.picBoth_Click);
      // 
      // FaceEditorControl
      // 
      this.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(236)), ((System.Byte)(233)), ((System.Byte)(216)));
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.picDigital,
                                                                  this.picAnalog,
                                                                  this.picBoth});
      this.Name = "FaceEditorControl";
      this.Size = new System.Drawing.Size(223, 80);
      this.ResumeLayout(false);

    }
		#endregion

    private ClockFace                   face = ClockFace.Both;
    private IWindowsFormsEditorService  editorService = null;

    public FaceEditorControl(IWindowsFormsEditorService editorService) {
      InitializeComponent();
      this.editorService = editorService;
    }

    public ClockFace Face {
      get { return face; }
      set { 
        face = value;
        if( face == ClockFace.Both ) {
          this.picBoth.BackColor = Color.Red;
          return;
        }
        if( face == ClockFace.Analog ) {
          this.picAnalog.BackColor = Color.Red;
          return;
        }
        if( face == ClockFace.Digital ) {
          this.picDigital.BackColor = Color.Red;
          return;
        }
      }
    }

    private void picBoth_Click(object sender, System.EventArgs e) {
      face = ClockFace.Both;

      // Close the UI editor upon value selection
      editorService.CloseDropDown();
    }

    private void picAnalog_Click(object sender, System.EventArgs e) {
      face = ClockFace.Analog;

      // Close the UI editor upon value selection
      editorService.CloseDropDown();
    }

    private void picDigital_Click(object sender, System.EventArgs e) {
      face = ClockFace.Digital;

      // Close the UI editor upon value selection
      editorService.CloseDropDown();
    }

    protected override void OnPaint(PaintEventArgs pe) {

      // Get currently selected control
      PictureBox   selected;
      if( face == ClockFace.Both ) selected = this.picBoth;
      else if( face == ClockFace.Analog ) selected = this.picAnalog;
      else selected = this.picDigital;

      // Paint the border
      Graphics   g = pe.Graphics;
      using( Pen pen = new Pen(Color.Gray, 1) ) {
        pen.DashStyle = DashStyle.Dash;
        g.DrawLine( pen, new Point(selected.Left - 2, selected.Top - 2), new Point(selected.Left + selected.Width + 1, selected.Top - 2));
        g.DrawLine( pen, new Point(selected.Left + selected.Width + 1, selected.Top - 2), new Point(selected.Left + selected.Width + 1, selected.Top + selected.Height + 1));
        g.DrawLine( pen, new Point(selected.Left + selected.Width + 1, selected.Top + selected.Height + 1), new Point(selected.Left - 2, selected.Top + selected.Height + 1));
        g.DrawLine( pen, new Point(selected.Left - 2, selected.Top + selected.Height + 1), new Point(selected.Left - 2, selected.Top - 2));
      }
      base.OnPaint(pe);
    }
	}
}
