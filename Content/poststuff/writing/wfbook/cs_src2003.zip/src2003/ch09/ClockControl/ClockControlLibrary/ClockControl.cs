using System;
using System.Collections;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.ComponentModel.Design.Serialization;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Design;
using System.Globalization;
using System.Reflection;
using System.Windows.Forms;
using System.Windows.Forms.Design;

namespace ClockControlLibrary {
  #region ClockControlDesigner

  public class ClockControlDesigner : ControlDesigner { 
    private ClockControl   clockControl = null;
    private bool           showBorder = true;
    DesignerVerb           showBorderVerb = null;

    public override void Initialize(IComponent component) { 
      base.Initialize(component);
      
      // Get clock control shortcut reference
      clockControl = (ClockControl)component;
    }

    protected override void OnPaintAdornments(PaintEventArgs e) {
      // Let the base class have a crack
      base.OnPaintAdornments(e);

      // Don�t show border if hidden or does not have an Analog face
      if( (!showBorder) || (clockControl.Face == ClockFace.Digital) ) return;

      // Draw border
      Graphics   g = e.Graphics;
      using( Pen pen = new Pen(Color.Gray, 1) ) {
        pen.DashStyle = DashStyle.Dash;
        g.DrawRectangle(pen, 0, 0, clockControl.Width - 1, clockControl.Height - 1);
      }
    }

    private string GetVerbText() { 
      return(showBorder ? "Hide Border" : "Show Border");
    }

    public override DesignerVerbCollection Verbs {
      get {
        // Return new list of context menu items
        DesignerVerbCollection   verbs = new DesignerVerbCollection();
        showBorderVerb = new DesignerVerb(GetVerbText(), new EventHandler(ShowBorderClicked));
        verbs.Add(showBorderVerb);
        return verbs;
      }
    }

    private void ShowBorderClicked(object sender, EventArgs e) {
      // Toggle property value
      ShowBorder = !ShowBorder;
    }

    // Provide implementation of ShowBorder to provide 
    // storage for created ShowBorder property
    private bool ShowBorder {
      get { return showBorder; }
      set {
        // Change property value
        PropertyDescriptor property = TypeDescriptor.GetProperties(typeof(ClockControl))["ShowBorder"];
        this.RaiseComponentChanging(property);
        showBorder = value;
        this.RaiseComponentChanged(property, !showBorder, showBorder);

        // Toggle Show/Hide Border verb entry in context menu
        IMenuCommandService   menuService = (IMenuCommandService)this.GetService(typeof(IMenuCommandService));
        if( menuService != null ) {
          // Recreate Show/Hide Border verb
          if( menuService.Verbs.IndexOf(showBorderVerb) >= 0 ) {
            menuService.Verbs.Remove(showBorderVerb);
            showBorderVerb = new DesignerVerb(GetVerbText(), new EventHandler(ShowBorderClicked));
            menuService.Verbs.Add(showBorderVerb);
          }
        }

        // Update clock UI
        clockControl.Invalidate();
      }
    }

    protected override void PreFilterProperties(IDictionary properties) {

      // Let the base have a chance
      base.PreFilterProperties(properties);

      // Create design-time-only property entry and add it to the
      // property browser�s Design category
      properties["ShowBorder"] = TypeDescriptor.CreateProperty(typeof(ClockControlDesigner), 
        "ShowBorder", 
        typeof(bool), 
        CategoryAttribute.Design, 
        DesignOnlyAttribute.Yes);
    }
  }

  #endregion

  #region HandConverter
    
  public class HandConverter : ExpandableObjectConverter {
    // Don't need to override CanConvertTo if converting to string, as that's what base TypeConverter does
    // Do need to override CanConvertFrom since it's base converts from InstanceDescriptor

    public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType) {
      // We can be converted to an InstanceDescriptor
      if( destinationType == typeof(InstanceDescriptor) ) return true;
      return base.CanConvertTo(context, destinationType);
    }
        
    public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType) {
      // We can convert from a string to a Hand type
      if( sourceType == typeof(string) ) { return true; }
      return base.CanConvertFrom(context, sourceType);
    }

    public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo info, object value) {

      // If converting from a string
      if( value is string ) {
        // Build a Hand type   
        try {
          // Get Hand properties
          string     propertyList = (string)value;
          string[]   properties = propertyList.Split(';');
          return new Hand(Color.FromName(properties[0].Trim()), 
                          Convert.ToInt32(properties[1]));
        }
        catch {}
        throw new ArgumentException("The arguments were not valid.");
      }
      return base.ConvertFrom(context, info, value);
    }
        
    public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType) {

      // If source value is a Hand type
      if( value is Hand ) {
        // Convert to string
        if( (destinationType == typeof(string)) ) {
          Hand     hand = (Hand)value;
          string   color = (hand.Color.IsNamedColor ? 
                            hand.Color.Name : 
                            hand.Color.R + ", " + hand.Color.G + ", " + hand.Color.B);
          return string.Format("{0}; {1}", color, hand.Width.ToString());
        }
        // Convert to InstanceDescriptor
        if( (destinationType == typeof(InstanceDescriptor)) ) {
          Hand       hand = (Hand)value;
          object[]   properties = new object[2];
          Type[]     types = new Type[2];

          // Color
          types[0] = typeof(Color);
          properties[0] = hand.Color;

          // Width
          types[1] = typeof(int);
          properties[1] = hand.Width;

          // Build constructor
          ConstructorInfo   ci = typeof(Hand).GetConstructor(types);
          return new InstanceDescriptor(ci, properties);
        }
      }                
      // Base ConvertTo if neither string or InstanceDescriptor required
      return base.ConvertTo(context, culture, value, destinationType);
    }     

    public override bool GetCreateInstanceSupported(ITypeDescriptorContext context) {

      // Always force a new instance
      return true;
    }

    public override object CreateInstance(ITypeDescriptorContext context, IDictionary propertyValues) {

      // Use the dictionary to create a new instance
      return new Hand((Color)propertyValues["Color"], (int)propertyValues["Width"]);
    }
  }
    
  #endregion

  #region Hand

  [TypeConverter(typeof(HandConverter))]
  public class Hand {
    private Color  color = Color.Black;
    private int    width = 1;
    public Hand(Color color, int width) {
      this.color = color;
      this.width = width;
    }

    public Color Color {
      get { return color; }
      set { color = value; }
    }

    public int Width {
      get { return width; }
      set { width = value; }
    }
  }
    
  #endregion

  #region DigitalTimeFormatEditor
    
  public class DigitalTimeFormatEditor : System.Drawing.Design.UITypeEditor {
    public override UITypeEditorEditStyle GetEditStyle(ITypeDescriptorContext context) {
      if( context != null ) {
        return UITypeEditorEditStyle.Modal;
      }
      return base.GetEditStyle(context);
    }
    public override object EditValue(ITypeDescriptorContext context, IServiceProvider provider, object value) {

      if( (context != null) && (provider != null) ) {
        // Access the property browser�s UI display service, IWindowsFormsEditorService
        IWindowsFormsEditorService   editorService = (IWindowsFormsEditorService)provider.GetService(typeof(IWindowsFormsEditorService));

        if( editorService != null ) {
          // Create an instance of the UI editor dialog
          DigitalTimeFormatEditorForm   modalEditor = new DigitalTimeFormatEditorForm();

          // Pass the UI editor dialog the current property value
          modalEditor.DigitalTimeFormat = (string)value;

          // Display the UI editor dialog
          if( editorService.ShowDialog(modalEditor) == DialogResult.OK ) {
            // Return the new property value from the UI editor dialog
            return modalEditor.DigitalTimeFormat;
          }
        }
      }
      return base.EditValue(context, provider, value);
    }
  }

  #endregion

  #region FaceEditor
    
  public class FaceEditor : System.Drawing.Design.UITypeEditor {
    public override UITypeEditorEditStyle GetEditStyle(ITypeDescriptorContext context) {
      if( context != null ) {
        return UITypeEditorEditStyle.DropDown;
      }
      return base.GetEditStyle(context);
    }
    public override object EditValue(ITypeDescriptorContext context, IServiceProvider provider, object value) {

      if( (context != null) && (provider != null) ) {
        // Access the property browser�s UI display service, IWindowsFormsEditorService
        IWindowsFormsEditorService   editorService = (IWindowsFormsEditorService)provider.GetService(typeof(IWindowsFormsEditorService));

        if( editorService != null ) {
          // Create an instance of the UI editor control, passing a reference to the editor service
          FaceEditorControl   dropDownEditor = new FaceEditorControl(editorService);

          // Pass the UI editor control the current property value
          dropDownEditor.Face = (ClockFace)value;

          // Display the UI editor control
          editorService.DropDownControl(dropDownEditor);

          // Return the new property value from the UI editor control
          return dropDownEditor.Face;
        }
      }
      return base.EditValue(context, provider, value);
    }
  }

  #endregion

  #region MessageToSelfConverter

  internal class MessageToSelfConverter : ExpandableObjectConverter {    
    public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType) {
      if( destinationType == typeof(InstanceDescriptor) ) return true;
      return this.CanConvertTo(context, destinationType);
    }
            
    public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType) {

      // If source value is an MessageToSelf type
      if( value is MessageToSelf ) {
        // Convert to string
        if( (destinationType == typeof(string)) ) {
          MessageToSelf     messageToSelf = (MessageToSelf)value;
          return string.Format("{0}, {1}", messageToSelf.Occurence.ToString(), messageToSelf.Message);
        }

        // Convert to InstanceDescriptor
        if( (destinationType == typeof(InstanceDescriptor)) ) {
          MessageToSelf       messageToSelf = (MessageToSelf)value;
          object[]   properties = new object[2];
          Type[]     types = new Type[2];
          // Color
          properties[0] = messageToSelf.Occurence;
          types[0] = typeof(DateTime);
          // Width
          properties[1] = messageToSelf.Message;
          types[1] = typeof(string);
          // Build constructor
          ConstructorInfo   ci = typeof(MessageToSelf).GetConstructor(types);
          return new InstanceDescriptor(ci, properties);
        }
      }

      // Base ConvertTo if neither string or InstanceDescriptor required
      return base.ConvertTo(context, culture, value, destinationType);
    }     
  }
  
  #endregion

  #region MessageToSelf

  [TypeConverter(typeof(MessageToSelfConverter))]
  public class MessageToSelf {
  
    DateTime  occurence = DateTime.Now;
    string    message = "";
    
    public MessageToSelf() {}

    public MessageToSelf(DateTime occurence, string message) {
      this.message = message;
      this.occurence = occurence;
    }

    public DateTime Occurence {
      get { return occurence; }
      set { occurence = value; }
    }

    public string Message {
      get { return message; }
      set { message = value; }
    }
  }

  #endregion

  #region MessageToSelfCollection Thanks to http://www.sellsbrothers.com/tools/#collectiongen
  // #region MessageToSelfCollectionold

  /// <summary>
  ///		A strongly-typed collection of <see cref="MessageToSelf"/> objects.
  /// </summary>
  //[Serializable]
  public class MessageToSelfCollection : ICollection, IList, IEnumerable, ICloneable {
        #region Interfaces
    /// <summary>
    ///		Supports type-safe iteration over a <see cref="MessageToSelfCollection"/>.
    /// </summary>
    public interface IMessageToSelfCollectionEnumerator {
      /// <summary>
      ///		Gets the current element in the collection.
      /// </summary>
      MessageToSelf Current {get;}

      /// <summary>
      ///		Advances the enumerator to the next element in the collection.
      /// </summary>
      /// <exception cref="InvalidOperationException">
      ///		The collection was modified after the enumerator was created.
      /// </exception>
      /// <returns>
      ///		<c>true</c> if the enumerator was successfully advanced to the next element; 
      ///		<c>false</c> if the enumerator has passed the end of the collection.
      /// </returns>
      bool MoveNext();

      /// <summary>
      ///		Sets the enumerator to its initial position, before the first element in the collection.
      /// </summary>
      void Reset();
    }
        #endregion

    private const int DEFAULT_CAPACITY = 16;

		#region Implementation (data)
    private MessageToSelf[] m_array;
    private int m_count = 0;
    [NonSerialized]
    private int m_version = 0;
		#endregion
	
        #region Static Wrappers
    /// <summary>
    ///		Creates a synchronized (thread-safe) wrapper for a 
    ///     <c>MessageToSelfCollection</c> instance.
    /// </summary>
    /// <returns>
    ///     An <c>MessageToSelfCollection</c> wrapper that is synchronized (thread-safe).
    /// </returns>
    public static MessageToSelfCollection Synchronized(MessageToSelfCollection list) {
      if(list==null)
        throw new ArgumentNullException("list");
      return new SyncMessageToSelfCollection(list);
    }
        
    /// <summary>
    ///		Creates a read-only wrapper for a 
    ///     <c>MessageToSelfCollection</c> instance.
    /// </summary>
    /// <returns>
    ///     An <c>MessageToSelfCollection</c> wrapper that is read-only.
    /// </returns>
    public static MessageToSelfCollection ReadOnly(MessageToSelfCollection list) {
      if(list==null)
        throw new ArgumentNullException("list");
      return new ReadOnlyMessageToSelfCollection(list);
    }
        #endregion

	    #region Construction
    /// <summary>
    ///		Initializes a new instance of the <c>MessageToSelfCollection</c> class
    ///		that is empty and has the default initial capacity.
    /// </summary>
    public MessageToSelfCollection() {
      m_array = new MessageToSelf[DEFAULT_CAPACITY];
    }
		
    /// <summary>
    ///		Initializes a new instance of the <c>MessageToSelfCollection</c> class
    ///		that has the specified initial capacity.
    /// </summary>
    /// <param name="capacity">
    ///		The number of elements that the new <c>MessageToSelfCollection</c> is initially capable of storing.
    ///	</param>
    public MessageToSelfCollection(int capacity) {
      m_array = new MessageToSelf[capacity];
    }

    /// <summary>
    ///		Initializes a new instance of the <c>MessageToSelfCollection</c> class
    ///		that contains elements copied from the specified <c>MessageToSelfCollection</c>.
    /// </summary>
    /// <param name="c">The <c>MessageToSelfCollection</c> whose elements are copied to the new collection.</param>
    public MessageToSelfCollection(MessageToSelfCollection c) {
      m_array = new MessageToSelf[c.Count];
      AddRange(c);
    }

    /// <summary>
    ///		Initializes a new instance of the <c>MessageToSelfCollection</c> class
    ///		that contains elements copied from the specified <see cref="MessageToSelf"/> array.
    /// </summary>
    /// <param name="a">The <see cref="MessageToSelf"/> array whose elements are copied to the new list.</param>
    public MessageToSelfCollection(MessageToSelf[] a) {
      m_array = new MessageToSelf[a.Length];
      AddRange(a);
    }
		#endregion
		
		#region Operations (type-safe ICollection)
    /// <summary>
    ///		Gets the number of elements actually contained in the <c>MessageToSelfCollection</c>.
    /// </summary>
    public virtual int Count {
      get { return m_count; }
    }

    /// <summary>
    ///		Copies the entire <c>MessageToSelfCollection</c> to a one-dimensional
    ///		string array.
    /// </summary>
    /// <param name="array">The one-dimensional <see cref="MessageToSelf"/> array to copy to.</param>
    public virtual void CopyTo(MessageToSelf[] array) {
      this.CopyTo(array, 0);
    }

    /// <summary>
    ///		Copies the entire <c>MessageToSelfCollection</c> to a one-dimensional
    ///		<see cref="MessageToSelf"/> array, starting at the specified index of the target array.
    /// </summary>
    /// <param name="array">The one-dimensional <see cref="MessageToSelf"/> array to copy to.</param>
    /// <param name="start">The zero-based index in <paramref name="array"/> at which copying begins.</param>
    public virtual void CopyTo(MessageToSelf[] array, int start) {
      if (m_count > array.GetUpperBound(0) + 1 - start)
        throw new System.ArgumentException("Destination array was not long enough.");
			
      Array.Copy(m_array, 0, array, start, m_count); 
    }

    /// <summary>
    ///		Gets a value indicating whether access to the collection is synchronized (thread-safe).
    /// </summary>
    /// <returns>true if access to the ICollection is synchronized (thread-safe); otherwise, false.</returns>
    public virtual bool IsSynchronized {
      get { return m_array.IsSynchronized; }
    }

    /// <summary>
    ///		Gets an object that can be used to synchronize access to the collection.
    /// </summary>
    public virtual object SyncRoot {
      get { return m_array.SyncRoot; }
    }
		#endregion
		
		#region Operations (type-safe IList)
    /// <summary>
    ///		Gets or sets the <see cref="MessageToSelf"/> at the specified index.
    /// </summary>
    /// <param name="index">The zero-based index of the element to get or set.</param>
    /// <exception cref="ArgumentOutOfRangeException">
    ///		<para><paramref name="index"/> is less than zero</para>
    ///		<para>-or-</para>
    ///		<para><paramref name="index"/> is equal to or greater than <see cref="MessageToSelfCollection.Count"/>.</para>
    /// </exception>
    public virtual MessageToSelf this[int index] {
      get {
        ValidateIndex(index); // throws
        return m_array[index]; 
      }
      set {
        ValidateIndex(index); // throws
        ++m_version; 
        m_array[index] = value; 
      }
    }

    /// <summary>
    ///		Adds a <see cref="MessageToSelf"/> to the end of the <c>MessageToSelfCollection</c>.
    /// </summary>
    /// <param name="item">The <see cref="MessageToSelf"/> to be added to the end of the <c>MessageToSelfCollection</c>.</param>
    /// <returns>The index at which the value has been added.</returns>
    public virtual int Add(MessageToSelf item) {
      if (m_count == m_array.Length)
        EnsureCapacity(m_count + 1);

      m_array[m_count] = item;
      m_version++;

      return m_count++;
    }
		
    /// <summary>
    ///		Removes all elements from the <c>MessageToSelfCollection</c>.
    /// </summary>
    public virtual void Clear() {
      ++m_version;
      m_array = new MessageToSelf[DEFAULT_CAPACITY];
      m_count = 0;
    }
		
    /// <summary>
    ///		Creates a shallow copy of the <see cref="MessageToSelfCollection"/>.
    /// </summary>
    public virtual object Clone() {
      MessageToSelfCollection newColl = new MessageToSelfCollection(m_count);
      Array.Copy(m_array, 0, newColl.m_array, 0, m_count);
      newColl.m_count = m_count;
      newColl.m_version = m_version;

      return newColl;
    }

    /// <summary>
    ///		Determines whether a given <see cref="MessageToSelf"/> is in the <c>MessageToSelfCollection</c>.
    /// </summary>
    /// <param name="item">The <see cref="MessageToSelf"/> to check for.</param>
    /// <returns><c>true</c> if <paramref name="item"/> is found in the <c>MessageToSelfCollection</c>; otherwise, <c>false</c>.</returns>
    public virtual bool Contains(MessageToSelf item) {
      for (int i=0; i != m_count; ++i)
        if (m_array[i].Equals(item))
          return true;
      return false;
    }

    /// <summary>
    ///		Returns the zero-based index of the first occurrence of a <see cref="MessageToSelf"/>
    ///		in the <c>MessageToSelfCollection</c>.
    /// </summary>
    /// <param name="item">The <see cref="MessageToSelf"/> to locate in the <c>MessageToSelfCollection</c>.</param>
    /// <returns>
    ///		The zero-based index of the first occurrence of <paramref name="item"/> 
    ///		in the entire <c>MessageToSelfCollection</c>, if found; otherwise, -1.
    ///	</returns>
    public virtual int IndexOf(MessageToSelf item) {
      for (int i=0; i != m_count; ++i)
        if (m_array[i].Equals(item))
          return i;
      return -1;
    }

    /// <summary>
    ///		Inserts an element into the <c>MessageToSelfCollection</c> at the specified index.
    /// </summary>
    /// <param name="index">The zero-based index at which <paramref name="item"/> should be inserted.</param>
    /// <param name="item">The <see cref="MessageToSelf"/> to insert.</param>
    /// <exception cref="ArgumentOutOfRangeException">
    ///		<para><paramref name="index"/> is less than zero</para>
    ///		<para>-or-</para>
    ///		<para><paramref name="index"/> is equal to or greater than <see cref="MessageToSelfCollection.Count"/>.</para>
    /// </exception>
    public virtual void Insert(int index, MessageToSelf item) {
      ValidateIndex(index, true); // throws
			
      if (m_count == m_array.Length)
        EnsureCapacity(m_count + 1);

      if (index < m_count) {
        Array.Copy(m_array, index, m_array, index + 1, m_count - index);
      }

      m_array[index] = item;
      m_count++;
      m_version++;
    }

    /// <summary>
    ///		Removes the first occurrence of a specific <see cref="MessageToSelf"/> from the <c>MessageToSelfCollection</c>.
    /// </summary>
    /// <param name="item">The <see cref="MessageToSelf"/> to remove from the <c>MessageToSelfCollection</c>.</param>
    /// <exception cref="ArgumentException">
    ///		The specified <see cref="MessageToSelf"/> was not found in the <c>MessageToSelfCollection</c>.
    /// </exception>
    public virtual void Remove(MessageToSelf item) {		   
      int i = IndexOf(item);
      if (i < 0)
        throw new System.ArgumentException("Cannot remove the specified item because it was not found in the specified Collection.");
			
      ++m_version;
      RemoveAt(i);
    }

    /// <summary>
    ///		Removes the element at the specified index of the <c>MessageToSelfCollection</c>.
    /// </summary>
    /// <param name="index">The zero-based index of the element to remove.</param>
    /// <exception cref="ArgumentOutOfRangeException">
    ///		<para><paramref name="index"/> is less than zero</para>
    ///		<para>-or-</para>
    ///		<para><paramref name="index"/> is equal to or greater than <see cref="MessageToSelfCollection.Count"/>.</para>
    /// </exception>
    public virtual void RemoveAt(int index) {
      ValidateIndex(index); // throws
			
      m_count--;

      if (index < m_count) {
        Array.Copy(m_array, index + 1, m_array, index, m_count - index);
      }
			
      // We can't set the deleted entry equal to null, because it might be a value type.
      // Instead, we'll create an empty single-element array of the right type and copy it 
      // over the entry we want to erase.
      MessageToSelf[] temp = new MessageToSelf[1];
      Array.Copy(temp, 0, m_array, m_count, 1);
      m_version++;
    }

    /// <summary>
    ///		Gets a value indicating whether the collection has a fixed size.
    /// </summary>
    /// <value>true if the collection has a fixed size; otherwise, false. The default is false</value>
    public virtual bool IsFixedSize {
      get { return false; }
    }

    /// <summary>
    ///		gets a value indicating whether the IList is read-only.
    /// </summary>
    /// <value>true if the collection is read-only; otherwise, false. The default is false</value>
    public virtual bool IsReadOnly {
      get { return false; }
    }
		#endregion

		#region Operations (type-safe IEnumerable)
		
    /// <summary>
    ///		Returns an enumerator that can iterate through the <c>MessageToSelfCollection</c>.
    /// </summary>
    /// <returns>An <see cref="Enumerator"/> for the entire <c>MessageToSelfCollection</c>.</returns>
    public virtual IMessageToSelfCollectionEnumerator GetEnumerator() {
      return new Enumerator(this);
    }
		#endregion

		#region Public helpers (just to mimic some nice features of ArrayList)
		
    /// <summary>
    ///		Gets or sets the number of elements the <c>MessageToSelfCollection</c> can contain.
    /// </summary>
    public virtual int Capacity {
      get { return m_array.Length; }
			
      set {
        if (value < m_count)
          value = m_count;

        if (value != m_array.Length) {
          if (value > 0) {
            MessageToSelf[] temp = new MessageToSelf[value];
            Array.Copy(m_array, temp, m_count);
            m_array = temp;
          }
          else {
            m_array = new MessageToSelf[DEFAULT_CAPACITY];
          }
        }
      }
    }

    /// <summary>
    ///		Adds the elements of another <c>MessageToSelfCollection</c> to the current <c>MessageToSelfCollection</c>.
    /// </summary>
    /// <param name="x">The <c>MessageToSelfCollection</c> whose elements should be added to the end of the current <c>MessageToSelfCollection</c>.</param>
    /// <returns>The new <see cref="MessageToSelfCollection.Count"/> of the <c>MessageToSelfCollection</c>.</returns>
    public virtual int AddRange(MessageToSelfCollection x) {
      if (m_count + x.Count >= m_array.Length)
        EnsureCapacity(m_count + x.Count);
			
      Array.Copy(x.m_array, 0, m_array, m_count, x.Count);
      m_count += x.Count;
      m_version++;

      return m_count;
    }

    /// <summary>
    ///		Adds the elements of a <see cref="MessageToSelf"/> array to the current <c>MessageToSelfCollection</c>.
    /// </summary>
    /// <param name="x">The <see cref="MessageToSelf"/> array whose elements should be added to the end of the <c>MessageToSelfCollection</c>.</param>
    /// <returns>The new <see cref="MessageToSelfCollection.Count"/> of the <c>MessageToSelfCollection</c>.</returns>
    public virtual int AddRange(MessageToSelf[] x) {
      if (m_count + x.Length >= m_array.Length)
        EnsureCapacity(m_count + x.Length);

      Array.Copy(x, 0, m_array, m_count, x.Length);
      m_count += x.Length;
      m_version++;

      return m_count;
    }
		
    /// <summary>
    ///		Sets the capacity to the actual number of elements.
    /// </summary>
    public virtual void TrimToSize() {
      this.Capacity = m_count;
    }

		#endregion

		#region Implementation (helpers)

    /// <exception cref="ArgumentOutOfRangeException">
    ///		<para><paramref name="index"/> is less than zero</para>
    ///		<para>-or-</para>
    ///		<para><paramref name="index"/> is equal to or greater than <see cref="MessageToSelfCollection.Count"/>.</para>
    /// </exception>
    private void ValidateIndex(int i) {
      ValidateIndex(i, false);
    }

    /// <exception cref="ArgumentOutOfRangeException">
    ///		<para><paramref name="index"/> is less than zero</para>
    ///		<para>-or-</para>
    ///		<para><paramref name="index"/> is equal to or greater than <see cref="MessageToSelfCollection.Count"/>.</para>
    /// </exception>
    private void ValidateIndex(int i, bool allowEqualEnd) {
      int max = (allowEqualEnd)?(m_count):(m_count-1);
      if (i < 0 || i > max)
        throw new System.ArgumentOutOfRangeException("Index was out of range.  Must be non-negative and less than the size of the collection.", (object)i, "Specified argument was out of the range of valid values.");
    }

    private void EnsureCapacity(int min) {
      int newCapacity = ((m_array.Length == 0) ? DEFAULT_CAPACITY : m_array.Length * 2);
      if (newCapacity < min)
        newCapacity = min;

      this.Capacity = newCapacity;
    }

		#endregion
		
		#region Implementation (ICollection)

    void ICollection.CopyTo(Array array, int start) {
      this.CopyTo((MessageToSelf[])array, start);
    }

		#endregion

		#region Implementation (IList)

    object IList.this[int i] {
      get { return (object)this[i]; }
      set { this[i] = (MessageToSelf)value; }
    }

    int IList.Add(object x) {
      return this.Add((MessageToSelf)x);
    }

    bool IList.Contains(object x) {
      return this.Contains((MessageToSelf)x);
    }

    int IList.IndexOf(object x) {
      return this.IndexOf((MessageToSelf)x);
    }

    void IList.Insert(int pos, object x) {
      this.Insert(pos, (MessageToSelf)x);
    }

    void IList.Remove(object x) {
      this.Remove((MessageToSelf)x);
    }

    void IList.RemoveAt(int pos) {
      this.RemoveAt(pos);
    }

		#endregion

		#region Implementation (IEnumerable)

    IEnumerator IEnumerable.GetEnumerator() {
      return (IEnumerator)(this.GetEnumerator());
    }

		#endregion

		#region Nested enumerator class
    /// <summary>
    ///		Supports simple iteration over a <see cref="MessageToSelfCollection"/>.
    /// </summary>
    private class Enumerator : IEnumerator, IMessageToSelfCollectionEnumerator {
			#region Implementation (data)
			
      private MessageToSelfCollection m_collection;
      private int m_index;
      private int m_version;
			
			#endregion
		
			#region Construction
			
      /// <summary>
      ///		Initializes a new instance of the <c>Enumerator</c> class.
      /// </summary>
      /// <param name="tc"></param>
      internal Enumerator(MessageToSelfCollection tc) {
        m_collection = tc;
        m_index = -1;
        m_version = tc.m_version;
      }
			
			#endregion
	
			#region Operations (type-safe IEnumerator)
			
      /// <summary>
      ///		Gets the current element in the collection.
      /// </summary>
      public MessageToSelf Current {
        get { return m_collection[m_index]; }
      }

      /// <summary>
      ///		Advances the enumerator to the next element in the collection.
      /// </summary>
      /// <exception cref="InvalidOperationException">
      ///		The collection was modified after the enumerator was created.
      /// </exception>
      /// <returns>
      ///		<c>true</c> if the enumerator was successfully advanced to the next element; 
      ///		<c>false</c> if the enumerator has passed the end of the collection.
      /// </returns>
      public bool MoveNext() {
        if (m_version != m_collection.m_version)
          throw new System.InvalidOperationException("Collection was modified; enumeration operation may not execute.");

        ++m_index;
        return (m_index < m_collection.Count) ? true : false;
      }

      /// <summary>
      ///		Sets the enumerator to its initial position, before the first element in the collection.
      /// </summary>
      public void Reset() {
        m_index = -1;
      }
			#endregion
	
			#region Implementation (IEnumerator)
			
      object IEnumerator.Current {
        get { return (object)(this.Current); }
      }
			
			#endregion
    }
        #endregion
        
        #region Nested Syncronized Wrapper class
    private class SyncMessageToSelfCollection : MessageToSelfCollection {
            #region Implementation (data)
      private MessageToSelfCollection m_collection;
      private object m_root;
            #endregion

            #region Construction
      internal SyncMessageToSelfCollection(MessageToSelfCollection list) {
        m_root = list.SyncRoot;
        m_collection = list;
      }
            #endregion
            
            #region Type-safe ICollection
      public override void CopyTo(MessageToSelf[] array) {
        lock(this.m_root)
          m_collection.CopyTo(array);
      }

      public override void CopyTo(MessageToSelf[] array, int start) {
        lock(this.m_root)
          m_collection.CopyTo(array,start);
      }
      public override int Count {
        get { 
          lock(this.m_root)
            return m_collection.Count;
        }
      }

      public override bool IsSynchronized {
        get { return true; }
      }

      public override object SyncRoot {
        get { return this.m_root; }
      }
            #endregion
            
            #region Type-safe IList
      public override MessageToSelf this[int i] {
        get {
          lock(this.m_root)
            return m_collection[i];
        }
        set {
          lock(this.m_root)
            m_collection[i] = value; 
        }
      }

      public override int Add(MessageToSelf x) {
        lock(this.m_root)
          return m_collection.Add(x);
      }
            
      public override void Clear() {
        lock(this.m_root)
          m_collection.Clear();
      }

      public override bool Contains(MessageToSelf x) {
        lock(this.m_root)
          return m_collection.Contains(x);
      }

      public override int IndexOf(MessageToSelf x) {
        lock(this.m_root)
          return m_collection.IndexOf(x);
      }

      public override void Insert(int pos, MessageToSelf x) {
        lock(this.m_root)
          m_collection.Insert(pos,x);
      }

      public override void Remove(MessageToSelf x) {           
        lock(this.m_root)
          m_collection.Remove(x);
      }

      public override void RemoveAt(int pos) {
        lock(this.m_root)
          m_collection.RemoveAt(pos);
      }
            
      public override bool IsFixedSize {
        get {return m_collection.IsFixedSize;}
      }

      public override bool IsReadOnly {
        get {return m_collection.IsReadOnly;}
      }
            #endregion

            #region Type-safe IEnumerable
      public override IMessageToSelfCollectionEnumerator GetEnumerator() {
        lock(m_root)
          return m_collection.GetEnumerator();
      }
            #endregion

            #region Public Helpers
      // (just to mimic some nice features of ArrayList)
      public override int Capacity {
        get {
          lock(this.m_root)
            return m_collection.Capacity;
        }
                
        set {
          lock(this.m_root)
            m_collection.Capacity = value;
        }
      }

      public override int AddRange(MessageToSelfCollection x) {
        lock(this.m_root)
          return m_collection.AddRange(x);
      }

      public override int AddRange(MessageToSelf[] x) {
        lock(this.m_root)
          return m_collection.AddRange(x);
      }
            #endregion
    }
        #endregion

        #region Nested Read Only Wrapper class
    private class ReadOnlyMessageToSelfCollection : MessageToSelfCollection {
            #region Implementation (data)
      private MessageToSelfCollection m_collection;
            #endregion

            #region Construction
      internal ReadOnlyMessageToSelfCollection(MessageToSelfCollection list) {
        m_collection = list;
      }
            #endregion
            
            #region Type-safe ICollection
      public override void CopyTo(MessageToSelf[] array) {
        m_collection.CopyTo(array);
      }

      public override void CopyTo(MessageToSelf[] array, int start) {
        m_collection.CopyTo(array,start);
      }
      public override int Count {
        get {return m_collection.Count;}
      }

      public override bool IsSynchronized {
        get { return m_collection.IsSynchronized; }
      }

      public override object SyncRoot {
        get { return this.m_collection.SyncRoot; }
      }
            #endregion
            
            #region Type-safe IList
      public override MessageToSelf this[int i] {
        get { return m_collection[i]; }
        set { throw new NotSupportedException("This is a Read Only Collection and can not be modified"); }
      }

      public override int Add(MessageToSelf x) {
        throw new NotSupportedException("This is a Read Only Collection and can not be modified");
      }
            
      public override void Clear() {
        throw new NotSupportedException("This is a Read Only Collection and can not be modified");
      }

      public override bool Contains(MessageToSelf x) {
        return m_collection.Contains(x);
      }

      public override int IndexOf(MessageToSelf x) {
        return m_collection.IndexOf(x);
      }

      public override void Insert(int pos, MessageToSelf x) {
        throw new NotSupportedException("This is a Read Only Collection and can not be modified");
      }

      public override void Remove(MessageToSelf x) {           
        throw new NotSupportedException("This is a Read Only Collection and can not be modified");
      }

      public override void RemoveAt(int pos) {
        throw new NotSupportedException("This is a Read Only Collection and can not be modified");
      }
            
      public override bool IsFixedSize {
        get {return true;}
      }

      public override bool IsReadOnly {
        get {return true;}
      }
            #endregion

            #region Type-safe IEnumerable
      public override IMessageToSelfCollectionEnumerator GetEnumerator() {
        return m_collection.GetEnumerator();
      }
            #endregion

            #region Public Helpers
      // (just to mimic some nice features of ArrayList)
      public override int Capacity {
        get { return m_collection.Capacity; }
                
        set { throw new NotSupportedException("This is a Read Only Collection and can not be modified"); }
      }

      public override int AddRange(MessageToSelfCollection x) {
        throw new NotSupportedException("This is a Read Only Collection and can not be modified");
      }

      public override int AddRange(MessageToSelf[] x) {
        throw new NotSupportedException("This is a Read Only Collection and can not be modified");
      }
            #endregion
    }
        #endregion
  }

  #endregion

  #region AlarmType Enumeration

  // Which alarm?
  public enum AlarmType {
    Primary,
    Backup
  }

  #endregion

  #region ClockFace Enumeration

  public enum ClockFace {
    Analog = 0,
    Digital = 1,
    Both = 2
  }

  #endregion

  public class AlarmEventArgs : EventArgs {
    AlarmType type;

    public AlarmType AlarmType {
      get { return type; }
    }

    public AlarmEventArgs(AlarmType type) {
      this.type = type;
    }
  }

  [
    ToolboxBitmap(typeof(ClockControlLibrary.ClockControl), "images.ClockControl.ico"),
    DefaultEvent("AlarmSounded"),
    DefaultProperty("Face"),
    ProvideProperty("TimeZoneModifier", typeof(Control)),
    Designer(typeof(ClockControlDesigner))
  ]
  public class ClockControl : System.Windows.Forms.Control, ISupportInitialize, IExtenderProvider {
    private DateTime    primaryAlarm = DateTime.Now;
    private bool        primaryAlarmSounded = false;
    private DateTime    backupAlarm = DateTime.Now.AddMinutes(10);
    private bool        backupAlarmSounded = false;
    private bool        isItTimeForABreak = true;
    private Timer       timer = new Timer();
    private int         timeZoneModifier = 0;
    private Hashtable   timeZoneModifiers = new Hashtable();
    private string      digitalTimeFormat = "dd/MM/yyyy hh:mm:ss tt";
    private ClockFace   face = ClockFace.Both;
    private bool        initializing = false;
    private Hand        hourHand = new Hand(Color.Black, 1);
    private Hand        minuteHand = new Hand(Color.Black, 1);
    private Hand        secondHand = new Hand(Color.Red, 1);

    private MessageToSelfCollection messagesToSelf = new MessageToSelfCollection();

    // Alarm event
    public delegate void AlarmHandler(object sender, AlarmEventArgs e);

    [Category("Notification")]
    public event AlarmHandler AlarmSounded;

    #region ISupportInitialize

    void ISupportInitialize.BeginInit() { initializing = true; }

    void ISupportInitialize.EndInit() {
      if( !this.DesignMode ) {
        // Check alarm values
        if( primaryAlarm >= backupAlarm )
          throw new ArgumentOutOfRangeException("Primary alarm must be before Backup alarm");
        //Initialize timer
        timer.Interval = 1000;
        timer.Tick += new System.EventHandler(this.timer_Tick);
        timer.Enabled = true;
      }
      initializing = false;
    }

    #endregion

    #region IExtenderProvider

    bool IExtenderProvider.CanExtend(object extendee) {
      // Don't extend self
      if( extendee == this ) return false;
      
      // Extend suitable controls
      return( (extendee is PictureBox) ||
              (extendee is Panel) );
    }

    [
      Category("Behavior"),
      Description("Sets the timezone difference from the current time"),
      DefaultValue(0)
    ]
    public int GetTimeZoneModifier(Control extendee) {
      // Return component's timezone offset
      return Convert.ToInt32(timeZoneModifiers[extendee]);
    }

    public void SetTimeZoneModifier(Control extendee, object value) {
      // If property isn't provided
      if( value == null ) {
        // Remove it
        timeZoneModifiers.Remove(extendee);
        if( !this.DesignMode ) {
          extendee.Click -= new EventHandler(extendee_Click);
        }
      }
      else {
        // Add the offset as an integer
        timeZoneModifiers[extendee] = Convert.ToInt32(value);
        if( !this.DesignMode ) {
          extendee.Click += new EventHandler(extendee_Click);
        }
      }
    }

    private void extendee_Click(object sender, System.EventArgs e) {
      // Update the time-zone
      timeZoneModifier = (int)timeZoneModifiers[sender];
    }
    
    #endregion

    public ClockControl() {

      // Reduce flicker
      this.SetStyle(ControlStyles.DoubleBuffer, true);
      this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);

      // Redraw when resized
      this.SetStyle(ControlStyles.ResizeRedraw, true);
    }

    protected override void Dispose(bool disposing) {
      if( disposing ) {
        // Clean up any resources being used
        timer.Dispose();
        base.Dispose(disposing);
      }
    }
    
    #region Properties

    [
      Browsable(false),
      DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)
    ]
    public bool IsItTimeForABreak {
      get { return isItTimeForABreak; }
      set { isItTimeForABreak = value; }
    }

    [
      Category("Behavior"),
      Description("Primary alarm...for the light-sleepers.")
    ]
    public DateTime PrimaryAlarm {
      get { return primaryAlarm; }
      set { 
        if( !initializing ) {
          if( value >= backupAlarm )
            throw new ArgumentOutOfRangeException("Primary alarm must be before Backup alarm");
        }
        primaryAlarm = value; 
      }
    }

    [
      Category("Behavior"),
      Description("Backup alarm...for the late-nighters.")
    ]
    public DateTime BackupAlarm {
      get { return backupAlarm; }
      set { 
        if( !initializing ) {
          if( value < primaryAlarm )
            throw new ArgumentOutOfRangeException("Backup alarm must be after Primary alarm");
        }
        backupAlarm = value;
      }
    }

    [
      Category("Appearance"),
      Description("The digital time format, constructed from .NET format specifiers"),
      DefaultValue("dd/MM/yyyy hh:mm:ss tt"),
      Editor(typeof(DigitalTimeFormatEditor), typeof(System.Drawing.Design.UITypeEditor))
    ]
    public string DigitalTimeFormat {
      get { return digitalTimeFormat; }
      set { 
        digitalTimeFormat = value;
        this.Invalidate();
      }
    }

    [
      Category("Behavior"),
      Description("Stuff to remember for later"),
      DesignerSerializationVisibility(DesignerSerializationVisibility.Content)
    ]
    public MessageToSelfCollection MessagesToSelf {
      get {
        if( messagesToSelf == null ) messagesToSelf = new MessageToSelfCollection();
        return messagesToSelf;
      }
      set { messagesToSelf = value; }
    }

    [
      Category("Appearance"),
      Description("Determines which style of clock face to display"),
      DefaultValue(ClockFace.Both),
      Editor(typeof(FaceEditor), typeof(System.Drawing.Design.UITypeEditor))
    ]
    public ClockFace Face {
      get { return face; }
      set {
        face = value;
        this.Invalidate();
      }
    }

    [
      Category("Appearance"),
      Description("Sets the color and size of the Hour Hand")
    ]
    public Hand HourHand {
      get { return hourHand; }
      set {
        hourHand = value;
        this.Invalidate();
      }
    }
    private bool ShouldSerializeHourHand() {
      // Only serialize non-default values
      return( (hourHand.Color != Color.Black) || (hourHand.Width != 1) );
    }
    private void ResetHourHand() {
      HourHand = new Hand(Color.Black, 1);
    }

    [
      Category("Appearance"),
      Description("Sets the color and size of the Minute Hand")
    ]
    public Hand MinuteHand {
      get { return minuteHand; }
      set {
        minuteHand = value;
        this.Invalidate();
      }
    }
    private bool ShouldSerializeMinuteHand() {
      // Only serialize non-default values
      return( (minuteHand.Color != Color.Black) || (minuteHand.Width != 1) );
    }
    private void ResetMinuteHand() {
      MinuteHand = new Hand(Color.Black, 1);
    }

    [
      Category("Appearance"),
      Description("Sets the color and size of the Second Hand")
    ]
    public Hand SecondHand {
      get { return secondHand; }
      set {
        secondHand = value;
        this.Invalidate();
      } 
    }
    private bool ShouldSerializeSecondHand() {
      // Only serialize non-default values
      return( (secondHand.Color != Color.Red) || (secondHand.Width != 1) );
    }
    private void ResetSecondHand() {
      SecondHand = new Hand(Color.Red, 1);
    }

    #endregion

    #region Event Handlers

    protected override void OnPaint(PaintEventArgs pe) {

      // Get specified date/time if control in design-time, 
      // or current date/time if control is in run-time
      DateTime   now;
      if( this.DesignMode ) {
        // Get pretty date/time for design-time
        now = new DateTime(2002, 12, 31, 15, 00, 20, 0);
      }
      else {
        // Get current date/time and apply the time zone modifier
        now = DateTime.Now.AddHours(timeZoneModifier);
      }

      // Paint the clocks
      Graphics   g = pe.Graphics;
      Size       clientSize = this.ClientRectangle.Size;
      int        xRadius = clientSize.Width/2;
      int        yRadius = clientSize.Height/2;
      double     degrees;
      int        x;
      int        y;

      // Make things pretty
      g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

      // Digital or Analog Face
      using( Pen facePen = new Pen(Color.Black, 2) ) {
        if( face != ClockFace.Digital ) {
          g.DrawEllipse(facePen, facePen.Width, facePen.Width, clientSize.Width - facePen.Width * 2, clientSize.Height - facePen.Width * 2);
          using( SolidBrush faceBrush = new SolidBrush(Color.White) ) {
            g.FillEllipse(faceBrush, facePen.Width, facePen.Width, clientSize.Width - facePen.Width * 2, clientSize.Height - facePen.Width * 2);
          }
        }
        else {
          g.DrawRectangle(facePen, facePen.Width, facePen.Width, clientSize.Width - facePen.Width * 2, clientSize.Height - facePen.Width * 2);
          using( SolidBrush faceBrush = new SolidBrush(Color.White) ) {
            g.FillRectangle(faceBrush, facePen.Width, facePen.Width, clientSize.Width - facePen.Width * 2, clientSize.Height - facePen.Width * 2);
          }
        }
      }

      // Paint analog clock?
      if( face != ClockFace.Digital ) {
          
        // Hour hand
        using( Pen hourHandPen = new Pen(hourHand.Color, hourHand.Width) ) {
          degrees = (90.0-((now.Hour/3.0)+(now.Minute/180.0))*90.0) * (Math.PI/180.0);
          x = (int)Math.Round((xRadius/3.0)*Math.Cos(degrees));
          y = (int)-(Math.Round((yRadius/3.0)*Math.Sin(degrees)));
          g.DrawLine(hourHandPen, xRadius, yRadius, x + xRadius, y + yRadius);
        }
              
        // Minute hand
        using( Pen minuteHandPen = new Pen(minuteHand.Color, minuteHand.Width) ) {
          degrees = (90.0-(now.Minute/15.0)*90.0) * (Math.PI/180.0);
          x = (int)Math.Round((xRadius/2.0)*Math.Cos(degrees));
          y = (int)-(Math.Round((yRadius/2.0)*Math.Sin(degrees)));
          g.DrawLine(minuteHandPen, xRadius, yRadius, x + xRadius, y + yRadius);
        }
              
        // Second hand
        using( Pen secondHandPen = new Pen(secondHand.Color, secondHand.Width) ) {
          degrees = (90.0-(now.Second/15.0)*90.0) * (Math.PI/180.0);
          x = (int)Math.Round((2.0*xRadius/3.0)*Math.Cos(degrees));
          y = (int)-(Math.Round((2.0*yRadius/3.0)*Math.Sin(degrees)));
          g.DrawLine(secondHandPen, xRadius, yRadius, x + xRadius, y + yRadius);
        }
      }

      // Paint digital clock?
      if( face != ClockFace.Analog ) {
        StringFormat    format = new StringFormat();
        format.Alignment = StringAlignment.Center;
        float   clearance = ((face == ClockFace.Digital) ? 1F : 1.5F);
        g.DrawString(now.ToString(digitalTimeFormat), this.Font, Brushes.Black, xRadius, yRadius * clearance, format);
      }

      // Let the base implementation do its thing
      base.OnPaint(pe);
    }

    private void timer_Tick(object sender, System.EventArgs e) {
      
      // Refresh clock face
      this.Invalidate();

      // Sound the first alarm? (comparing to the second)
      if( !primaryAlarmSounded && (DateTime.Now.ToString("hh:mm:ss") == primaryAlarm.ToString("hh:mm:ss")) ) {
        primaryAlarmSounded = true;
        if( this.AlarmSounded != null ) {
          this.AlarmSounded(this, new AlarmEventArgs(AlarmType.Primary));
        }
      }

      // Sound the second alarm? (comparing to the second)
      if( !backupAlarmSounded && (DateTime.Now.ToString("hh:mm:ss") == backupAlarm.ToString("hh:mm:ss")) ) {
        backupAlarmSounded = true;
        if( this.AlarmSounded != null ) {
          this.AlarmSounded(this, new AlarmEventArgs(AlarmType.Backup));
        }
      }

      // Display message to self?
      MessageToSelf   msgToRemove = null;
      foreach( MessageToSelf   msg in messagesToSelf ) {
        if( DateTime.Now.ToString("hh:mm:ss") == msg.Occurence.ToString("hh:mm:ss") ) {
          MessageBox.Show(msg.Message, "Message To Self");
          break;
        }
      }
      if( msgToRemove != null ) messagesToSelf.Remove(msgToRemove);

    }

    #endregion

  }
}
