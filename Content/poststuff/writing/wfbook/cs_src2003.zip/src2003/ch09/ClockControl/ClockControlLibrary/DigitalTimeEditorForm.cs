using System;
using System.Drawing;
using System.Data;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace ClockControlLibrary
{
	public class DigitalTimeFormatEditorForm : System.Windows.Forms.Form
	{
    private System.Windows.Forms.Button btnOK;
    private System.Windows.Forms.Button btnCancel;
    private System.Windows.Forms.Timer timer;
    private System.Windows.Forms.Label lblExample2;
    private System.Windows.Forms.Button btnAddFormatSpecifier;
    private System.Windows.Forms.Label lblExample1;
    private System.Windows.Forms.TextBox txtFormat;
    private System.Windows.Forms.Label lblExample;
    private System.Windows.Forms.Label lblFormat;
    private System.Windows.Forms.ComboBox lstFormatSpecifiers;
    private System.ComponentModel.IContainer components;

		public DigitalTimeFormatEditorForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.components = new System.ComponentModel.Container();
      this.btnOK = new System.Windows.Forms.Button();
      this.btnCancel = new System.Windows.Forms.Button();
      this.timer = new System.Windows.Forms.Timer(this.components);
      this.lblExample2 = new System.Windows.Forms.Label();
      this.btnAddFormatSpecifier = new System.Windows.Forms.Button();
      this.lblExample1 = new System.Windows.Forms.Label();
      this.txtFormat = new System.Windows.Forms.TextBox();
      this.lblExample = new System.Windows.Forms.Label();
      this.lblFormat = new System.Windows.Forms.Label();
      this.lstFormatSpecifiers = new System.Windows.Forms.ComboBox();
      this.SuspendLayout();
      // 
      // btnOK
      // 
      this.btnOK.Anchor = System.Windows.Forms.AnchorStyles.None;
      this.btnOK.Location = new System.Drawing.Point(235, 70);
      this.btnOK.Name = "btnOK";
      this.btnOK.TabIndex = 2;
      this.btnOK.Text = "OK";
      this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
      // 
      // btnCancel
      // 
      this.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.None;
      this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
      this.btnCancel.Location = new System.Drawing.Point(322, 70);
      this.btnCancel.Name = "btnCancel";
      this.btnCancel.TabIndex = 3;
      this.btnCancel.Text = "Cancel";
      // 
      // lblExample2
      // 
      this.lblExample2.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(0)), ((System.Byte)(192)));
      this.lblExample2.Location = new System.Drawing.Point(60, 54);
      this.lblExample2.Name = "lblExample2";
      this.lblExample2.Size = new System.Drawing.Size(296, 14);
      this.lblExample2.TabIndex = 13;
      this.lblExample2.Text = "1/1/02 1:1:1 AM";
      // 
      // btnAddFormatSpecifier
      // 
      this.btnAddFormatSpecifier.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F);
      this.btnAddFormatSpecifier.Location = new System.Drawing.Point(215, 8);
      this.btnAddFormatSpecifier.Name = "btnAddFormatSpecifier";
      this.btnAddFormatSpecifier.Size = new System.Drawing.Size(29, 19);
      this.btnAddFormatSpecifier.TabIndex = 9;
      this.btnAddFormatSpecifier.Text = "<<";
      this.btnAddFormatSpecifier.Click += new System.EventHandler(this.btnAddFormatSpecifier_Click);
      // 
      // lblExample1
      // 
      this.lblExample1.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(0)), ((System.Byte)(192)));
      this.lblExample1.Location = new System.Drawing.Point(60, 38);
      this.lblExample1.Name = "lblExample1";
      this.lblExample1.Size = new System.Drawing.Size(296, 14);
      this.lblExample1.TabIndex = 12;
      this.lblExample1.Text = "12/12/2002 12:12:12 AM";
      // 
      // txtFormat
      // 
      this.txtFormat.Location = new System.Drawing.Point(62, 8);
      this.txtFormat.Name = "txtFormat";
      this.txtFormat.Size = new System.Drawing.Size(145, 20);
      this.txtFormat.TabIndex = 8;
      this.txtFormat.Text = "";
      this.txtFormat.TextChanged += new System.EventHandler(this.txtFormat_TextChanged);
      // 
      // lblExample
      // 
      this.lblExample.Location = new System.Drawing.Point(8, 38);
      this.lblExample.Name = "lblExample";
      this.lblExample.TabIndex = 11;
      this.lblExample.Text = "Examples:";
      // 
      // lblFormat
      // 
      this.lblFormat.Location = new System.Drawing.Point(8, 10);
      this.lblFormat.Name = "lblFormat";
      this.lblFormat.TabIndex = 7;
      this.lblFormat.Text = "Format:";
      // 
      // lstFormatSpecifiers
      // 
      this.lstFormatSpecifiers.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.lstFormatSpecifiers.Location = new System.Drawing.Point(252, 8);
      this.lstFormatSpecifiers.Name = "lstFormatSpecifiers";
      this.lstFormatSpecifiers.Size = new System.Drawing.Size(145, 21);
      this.lstFormatSpecifiers.TabIndex = 10;
      // 
      // DigitalTimeFormatEditorForm
      // 
      this.AcceptButton = this.btnOK;
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(404, 100);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.lblExample2,
                                                                  this.btnAddFormatSpecifier,
                                                                  this.lblExample1,
                                                                  this.txtFormat,
                                                                  this.lblExample,
                                                                  this.lblFormat,
                                                                  this.lstFormatSpecifiers,
                                                                  this.btnCancel,
                                                                  this.btnOK});
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "DigitalTimeFormatEditorForm";
      this.ShowInTaskbar = false;
      this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
      this.Text = "Digital Time Format Editor";
      this.ResumeLayout(false);

    }
		#endregion

    
    private DateTime   exampleDateTime1 = new DateTime(2002, 12, 31, 12, 59, 59);
    private DateTime   exampleDateTime2 = new DateTime(2002, 1, 1, 1, 1, 1);
    private string     digitalTimeFormat = "";

    public string DigitalTimeFormat {
      get { return digitalTimeFormat; }
      set { digitalTimeFormat = value; }
    }
        
    protected override void OnLoad(System.EventArgs e) {
      base.OnLoad(e);
      
      // Set the textbox from the property
      txtFormat.Text = digitalTimeFormat;
      
      // Build the examples based on the format
      lblExample1.Text = exampleDateTime1.ToString(txtFormat.Text);
      lblExample2.Text = exampleDateTime2.ToString(txtFormat.Text);
      
      // Build the list
      // TODO: Nicer?
      DataTable   lst = new DataTable("List");
      lst.Columns.Add(new DataColumn("Value", typeof(string)));
      lst.Columns.Add(new DataColumn("Display", typeof(string)));
      lst.Rows.Add(new Object[] {"/","/  (Date Separator)"});
      lst.Rows.Add(new Object[] {":",":  (Time Separator)"});
      lst.Rows.Add(new Object[] {"d","d  (Day: 1-31)"});
      lst.Rows.Add(new Object[] {"dd","dd  (Day: 01-31)"});
      lst.Rows.Add(new Object[] {"ddd","ddd  (Day Mon-Sun)"});
      lst.Rows.Add(new Object[] {"H","H  (Hour: 0-23)"});
      lst.Rows.Add(new Object[] {"h","h  (Hour: 1-12)"});
      lst.Rows.Add(new Object[] {"HH","HH  (Hour: 00-23)"});
      lst.Rows.Add(new Object[] {"hh","hh  (Hour: 01-12)"});
      lst.Rows.Add(new Object[] {"M","M   (Month: 1-12)"});
      lst.Rows.Add(new Object[] {"m","m  (Minute: 0-59)"});
      lst.Rows.Add(new Object[] {"mm","mm  (Minute: 00-59)"});
      lst.Rows.Add(new Object[] {"MM","MM  (Month: 01-12)"});
      lst.Rows.Add(new Object[] {"MMM","MMM  (Month: Jan-Dec)"});
      lst.Rows.Add(new Object[] {"s","s  (Second: 0-59)"});
      lst.Rows.Add(new Object[] {"ss","ss  (Second: 00-59)"});
      lst.Rows.Add(new Object[] {"tt","tt  (AM/PM)"});
      lst.Rows.Add(new Object[] {"y","y  (Year: 1-99)"});
      lst.Rows.Add(new Object[] {"yy","yy  (Year: 01-99)"});
      lst.Rows.Add(new Object[] {"yyyy","yyyy  (Year: 2001-2099)"});
      lstFormatSpecifiers.DataSource = lst;
      lstFormatSpecifiers.ValueMember = "Value";
      lstFormatSpecifiers.DisplayMember = "Display";                                                                     
    }
        
    private void btnOK_Click(object sender, System.EventArgs e) {
      DialogResult = DialogResult.OK;
      digitalTimeFormat = txtFormat.Text;
      this.Close();
    }
        
    private void btnAddFormatSpecifier_Click(object sender, System.EventArgs e) {
      // Add selected format specifier
      if( lstFormatSpecifiers.Text != "" ) {
        txtFormat.Text += lstFormatSpecifiers.SelectedValue;
        txtFormat.Select(txtFormat.Text.Length, 0);
        txtFormat.Focus();
      }
    }

    private void txtFormat_TextChanged(object sender, System.EventArgs e) {
      lblExample1.Text = exampleDateTime1.ToString(txtFormat.Text);
      lblExample2.Text = exampleDateTime2.ToString(txtFormat.Text);
    }
  }
}
