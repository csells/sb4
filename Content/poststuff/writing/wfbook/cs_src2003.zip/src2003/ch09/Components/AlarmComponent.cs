using System;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;

namespace Components {
  /// <summary>
  /// Summary description for AlarmComponent.
  /// </summary>
  public class AlarmComponent : System.ComponentModel.Component {
    private Timer timer1;
    private System.ComponentModel.IContainer components;

    public AlarmComponent(System.ComponentModel.IContainer container) {
      // Add object to container�s list so that
      // we get notified when the container goes away
      container.Add(this);
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
      timer1.Disposed += new EventHandler(timer1_Disposed);
    }

    void timer1_Disposed(object sender, EventArgs e) {
      System.Diagnostics.Debug.WriteLine("Timer disposed");
    }

    public AlarmComponent() {
      /// <summary>
      /// Required for Windows.Forms Class Composition Designer support
      /// </summary>
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    protected override void Dispose(bool disposing) {
      if( disposing ) {
        // Release managed resources
        // ...

        // Let contained components know to release their resources
        if( components != null ) {
          components.Dispose();
        }
      }

      // Release unmanaged resources
      // ...
    }

	#region Component Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.components = new System.ComponentModel.Container();
      this.timer1 = new System.Windows.Forms.Timer(this.components);
      // 
      // timer1
      // 
      this.timer1.Enabled = true;
      this.timer1.Tick += new System.EventHandler(this.timer1_Tick);

    }
	#endregion

    DateTime alarm = DateTime.MaxValue; // No alarm
    public DateTime Alarm {
      get { return this.alarm; }
      set { this.alarm = value; }
    }

    // Handle the Timer's Tick event
    public event EventHandler AlarmSounded;

    void timer1_Tick(object sender, System.EventArgs e) {
      // Check to see if we're within 1 second of the alarm
      double seconds = (DateTime.Now - this.alarm).TotalSeconds;
      if( (seconds >= 0) && (seconds <= 1) ) {
        this.alarm = DateTime.MaxValue; // Show alarm only once
        if( this.AlarmSounded != null ) {
          AlarmSounded(this, EventArgs.Empty);
        }
      }
    }

  }
}
