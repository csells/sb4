using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Shapes {
  /// <summary>
  /// Summary description for Form1.
  /// </summary>
  public class ShapesForm : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public ShapesForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
      this.SetStyle(ControlStyles.ResizeRedraw, true);
      this.SetStyle(ControlStyles.DoubleBuffer, true);
      this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      // 
      // Form1
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(8, 19);
      this.BackColor = System.Drawing.Color.White;
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Name = "Form1";
      this.Text = "Shapes";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);

    }
		#endregion

    void Form1_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      int x = 0;
      int y = 0;
      int width = this.ClientRectangle.Width/3;
      int height = this.ClientRectangle.Height/3;
      Brush blackBrush = Brushes.Black;
      Brush fillBrush = Brushes.Gray;
      Pen whitePen = System.Drawing.Pens.White;
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Center;

      using( Pen pen = new Pen(Color.Red, 4) ) {
        // Arc
        g.DrawArc(pen, x + 10, y + 10, width - 20, height - 20, 180, 180);
        g.DrawString("Arc", this.Font, blackBrush, new Rectangle(x, y, width, height), format);
        x = (x > this.ClientRectangle.Width - 2*width ? 0 : x + width);
        y = (x == 0 ? y + height : y);

        // Bezier
        g.DrawBezier(pen, new Point(x + 10, y + height - 20), new Point(x + width - 20, y + height - 20), new Point(x + 10, y + 10), new Point(x + width - 20, y + 10));
        g.DrawString("Bezier", this.Font, blackBrush, new Rectangle(x, y, width, height), format);
        x = (x > this.ClientRectangle.Width - 2*width ? 0 : x + width);
        y = (x == 0 ? y + height : y);

        // Closed Curve
        g.FillClosedCurve(fillBrush, new Point[] { new Point(x + 10, y + height - 20), new Point(x + width - 20, y + height - 20), new Point(x + 10, y + 10), new Point(x + width - 20, y + 10), });
        g.DrawClosedCurve(pen, new Point[] { new Point(x + 10, y + height - 20), new Point(x + width - 20, y + height - 20), new Point(x + 10, y + 10), new Point(x + width - 20, y + 10), });
        g.DrawString("Closed Curve", this.Font, blackBrush, new Rectangle(x, y, width, height), format);
        x = (x > this.ClientRectangle.Width - 2*width ? 0 : x + width);
        y = (x == 0 ? y + height : y);

        // Curve
        g.DrawCurve(pen, new Point[] { new Point(x + 10, y + height - 20), new Point(x + width - 20, y + height - 20), new Point(x + 10, y + 10), new Point(x + width - 20, y + 10), });
        g.DrawString("Curve", this.Font, blackBrush, new Rectangle(x, y, width, height), format);
        x = (x > this.ClientRectangle.Width - 2*width ? 0 : x + width);
        y = (x == 0 ? y + height : y);

        // Ellipse
        g.FillEllipse(fillBrush, x + 10, y + 10, width - 20, height - 20);
        g.DrawEllipse(pen, x + 10, y + 10, width - 20, height - 20);
        g.DrawString("Ellipse", this.Font, blackBrush, new Rectangle(x, y, width, height), format);
        x = (x > this.ClientRectangle.Width - 2*width ? 0 : x + width);
        y = (x == 0 ? y + height : y);

        // Lines
        g.DrawLines(pen, new Point[] { new Point(x + 10, y + height - 20), new Point(x + width - 20, y + height - 20), new Point(x + 10, y + 10), new Point(x + width - 20, y + 10), });
        g.DrawString("Lines", this.Font, blackBrush, new Rectangle(x, y, width, height), format);
        x = (x > this.ClientRectangle.Width - 2*width ? 0 : x + width);
        y = (x == 0 ? y + height : y);

        // Pie
        g.FillPie(fillBrush, x + 10, y + 10, width - 20, height - 20, 180, 180);
        g.DrawPie(pen, x + 10, y + 10, width - 20, height - 20, 180, 180);
        g.DrawString("Pie", this.Font, blackBrush, new Rectangle(x, y, width, height), format);
        x = (x > this.ClientRectangle.Width - 2*width ? 0 : x + width);
        y = (x == 0 ? y + height : y);

        // Polygon
        g.FillPolygon(fillBrush, new Point[] { new Point(x + 10, y + height - 20), new Point(x + width - 20, y + height - 20), new Point(x + 10, y + 10), new Point(x + width - 20, y + 10), });
        g.DrawPolygon(pen, new Point[] { new Point(x + 10, y + height - 20), new Point(x + width - 20, y + height - 20), new Point(x + 10, y + 10), new Point(x + width - 20, y + 10), });
        g.DrawString("Polygon", this.Font, blackBrush, new Rectangle(x, y, width, height), format);
        x = (x > this.ClientRectangle.Width - 2*width ? 0 : x + width);
        y = (x == 0 ? y + height : y);

        // Rectangle
        g.FillRectangle(fillBrush, x + 10, y + 10, width - 20, height - 20);
        g.DrawRectangle(pen, x + 10, y + 10, width - 20, height - 20);
        g.DrawString("Rectangle", this.Font, blackBrush, new Rectangle(x, y, width, height), format);
        x = (x > this.ClientRectangle.Width - 2*width ? 0 : x + width);
        y = (x == 0 ? y + height : y);
      }
      
    }
  }
}
