using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Shapes
{
	/// <summary>
	/// Summary description for FillModesForm.
	/// </summary>
	public class FillModesForm : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public FillModesForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      // 
      // FillModesForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(8, 19);
      this.BackColor = System.Drawing.Color.White;
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Name = "FillModesForm";
      this.Text = "Fill Modes";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.FillModesForm_Paint);

    }
		#endregion

    void FillModesForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      int x = 0;
      int y = 0;
      int width = this.ClientRectangle.Width/2;
      int height = this.ClientRectangle.Height;
      Brush blackBrush = Brushes.Black;
      Brush fillBrush = Brushes.Gray;
      Pen whitePen = System.Drawing.Pens.White;
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Center;

      using( Pen pen = new Pen(Color.Red, 4) )
      using( Pen pointPen = new Pen(Color.Black, 3) ) {
        pointPen.StartCap = pointPen.EndCap = LineCap.SquareAnchor;
        FillMode fill = FillMode.Winding;
        Point[] points = null;

        fill = FillMode.Winding;
        points = new Point[] { new Point(x + 25, y + height - 25), new Point(x + width - 25, y + height - 25), new Point(x + 25, height/2), new Point(x + width - 25, y + 25), new Point(x + 25, y + 25), new Point(x + width - 25, height/2), };
        g.DrawRectangle(Pens.Black, x, y, width, height);
        g.FillClosedCurve(fillBrush, points, fill);
        g.DrawClosedCurve(pen, points);
        foreach( Point point in points ) g.DrawLine(pointPen, new Point(point.X, point.Y), new Point(point.X + 1, point.Y));
        for( int i = 0; i != points.Length; ++i ) g.DrawString(i.ToString(), this.Font, blackBrush, points[i]);
        g.DrawString(string.Format("FillMode= {0}", fill), this.Font, blackBrush, new Rectangle(x, y, width, height), format);
        x = (x > this.ClientRectangle.Width - 2*width ? 0 : x + width);
        y = (x == 0 ? y + height : y);

        fill = FillMode.Alternate;
        points = new Point[] { new Point(x + 25, y + height - 25), new Point(x + width - 25, y + height - 25), new Point(x + 25, height/2), new Point(x + width - 25, y + 25), new Point(x + 25, y + 25), new Point(x + width - 25, height/2), };
        g.DrawRectangle(Pens.Black, x, y, width, height);
        g.FillClosedCurve(fillBrush, points, fill);
        g.DrawClosedCurve(pen, points);
        foreach( Point point in points ) g.DrawLine(pointPen, new Point(point.X, point.Y), new Point(point.X + 1, point.Y));
        for( int i = 0; i != points.Length; ++i ) g.DrawString(i.ToString(), this.Font, blackBrush, points[i]);
        g.DrawString(string.Format("FillMode= {0}", fill), this.Font, blackBrush, new Rectangle(x, y, width, height), format);
        x = (x > this.ClientRectangle.Width - 2*width ? 0 : x + width);
        y = (x == 0 ? y + height : y);

      }

    }
	}
}
