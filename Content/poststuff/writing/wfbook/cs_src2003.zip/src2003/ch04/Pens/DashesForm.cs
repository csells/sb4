using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Pens {
  /// <summary>
  /// Summary description for DashesForm.
  /// </summary>
  public class DashesForm : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public DashesForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      // 
      // DashesForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.BackColor = System.Drawing.Color.White;
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Name = "DashesForm";
      this.Text = "Dashes";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.DashesForm_Paint);

    }
		#endregion

    void DashesForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      string[] dashNames = Enum.GetNames(typeof(DashStyle));
      Array.Sort(dashNames);

      int x = 0;
      int y = 0;
      int width = this.ClientRectangle.Width/2;
      int height = this.ClientRectangle.Height/((dashNames.Length)/2);
      Brush blackBrush = Brushes.Black;

      Debug.Assert(dashNames.Length % 2 == 0);
      
      foreach( string dashName in dashNames ) {
        using( Pen pen = new Pen(Color.Black, 12) ) {
          pen.DashStyle = (DashStyle)Enum.Parse(typeof(DashStyle), dashName);
//          pen.DashCap = DashCap.Triangle;
          if( pen.DashStyle == DashStyle.Custom ) {
            // Set increasing dashes with constant spaces
            pen.DashPattern = new float[] { 1f, 1f, 2f, 1f, 3f, 1f, 4f, 1f, };
          }
          g.DrawLine(pen, x + 10, y + height*2/3, x + width - 20, y + height*2/3);
          g.DrawString(dashName, this.Font, blackBrush, x + 10, y);
          x += width;
          if( x > this.ClientRectangle.Width - width ) {
            y += height;
            x = 0;
          }
        }
      }

    }
  }
}
