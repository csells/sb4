using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Pens
{
	/// <summary>
	/// Summary description for JoinsForm.
	/// </summary>
	public class JoinsForm : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public JoinsForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      // 
      // JoinsForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.BackColor = System.Drawing.Color.White;
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Name = "JoinsForm";
      this.Text = "Joins";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.JoinsForm_Paint);

    }
		#endregion

    private void JoinsForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e) {
      Graphics g = e.Graphics;
      string[] joinNames = Enum.GetNames(typeof(LineJoin));
      Array.Sort(joinNames);

      int x = 0;
      int y = 0;
      int width = this.ClientRectangle.Width/2;
      int height = this.ClientRectangle.Height/((joinNames.Length)/2);
      Brush blackBrush = Brushes.Black;
      Pen blackPen = System.Drawing.Pens.Black;
      Pen whitePen = System.Drawing.Pens.White;
      
      foreach( string joinName in joinNames ) {
        using( Pen pen = new Pen(Color.Black, 12) ) {
          pen.LineJoin = (LineJoin)Enum.Parse(typeof(LineJoin), joinName);
          g.DrawRectangle(pen, new Rectangle(x + 20, y + 20, width - 40, height - 40));
          g.DrawRectangle(whitePen, new Rectangle(x + 20, y + 20, width - 40, height - 40));

          StringFormat format = new StringFormat();
          format.Alignment = StringAlignment.Center;
          format.LineAlignment = StringAlignment.Center;
          g.DrawString(joinName, this.Font, blackBrush, new Rectangle(x, y, width, height), format);

          x += width;
          if( x > this.ClientRectangle.Width - width ) {
            y += height;
            x = 0;
          }
        }
      }

    }
	}
}
