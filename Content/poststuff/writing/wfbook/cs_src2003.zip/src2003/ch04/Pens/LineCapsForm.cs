using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Pens {
  /// <summary>
  /// Summary description for LineCapsForm.
  /// </summary>
  public class LineCapsForm : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public LineCapsForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      // 
      // LineCapsForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.BackColor = System.Drawing.Color.White;
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Name = "LineCapsForm";
      this.Text = "Line Caps";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.LineCapsForm_Paint);

    }
		#endregion

    void LineCapsForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      string[] capNames = Enum.GetNames(typeof(LineCap));
      Array.Sort(capNames);

      int x = 0;
      int y = 0;
      int width = this.ClientRectangle.Width/2;
      int height = this.ClientRectangle.Height/((capNames.Length)/2);
      Brush blackBrush = Brushes.Black;
      Pen whitePen = System.Drawing.Pens.White;
      
      foreach( string capName in capNames ) {
        using( Pen pen = new Pen(Color.Black, 12) ) {
          pen.EndCap = (LineCap)Enum.Parse(typeof(LineCap), capName);
          if( pen.EndCap == LineCap.AnchorMask ) continue; // Not a real LineCap
          if( pen.EndCap == LineCap.Custom ) {
            // width and height of 3 and unfilled arrow head
            pen.CustomEndCap = new AdjustableArrowCap(3f, 3f, false);
          }
          g.DrawLine(pen, x, y + height*2/3, x + width*2/3, y + height*2/3);
          g.DrawLine(whitePen, x, y + height*2/3, x + width*2/3, y + height*2/3);
          g.DrawString(capName, this.Font, blackBrush, x, y);
          x += width;
          if( x > this.ClientRectangle.Width - width ) {
            y += height;
            x = 0;
          }
        }
      }

    }

  }
}
