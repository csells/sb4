using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Brushes
{
	/// <summary>
	/// Summary description for HatchBrushes.
	/// </summary>
	public class HatchBrushesForm : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public HatchBrushesForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      // 
      // HatchBrushesForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Name = "HatchBrushesForm";
      this.Text = "Hatch Brushes";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.HatchBrushes_Paint);

    }
		#endregion

    void HatchBrushes_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      string[] hatchNames = Enum.GetNames(typeof(HatchStyle));
      int x = 0;
      int y = 0;
      int width = this.ClientRectangle.Width/4;
      int height = this.ClientRectangle.Height/(hatchNames.Length/4);
      Brush blackBrush = System.Drawing.Brushes.Black;
      Pen blackPen = Pens.Black;

      Debug.Assert(hatchNames.Length % 4 == 0);
      Array.Sort(hatchNames);

      foreach( string hatchName in hatchNames ) {
        HatchStyle style = (HatchStyle)Enum.Parse(typeof(HatchStyle), hatchName);
        using( HatchBrush brush = new HatchBrush(style, Color.Black, Color.White) ) {
          g.FillRectangle(brush, x, y + height/2, width, height/2);
          g.DrawRectangle(blackPen, x, y, width, height);
          g.DrawString(hatchName, this.Font, blackBrush, x, y);
          x += width;
          if( x > this.ClientRectangle.Width - width ) {
            y += height;
            x = 0;
          }
        }
      }

    }
	}
}
