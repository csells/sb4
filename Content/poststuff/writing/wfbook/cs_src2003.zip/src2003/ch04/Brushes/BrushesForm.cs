using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Brushes {
  /// <summary>
  /// Summary description for Form1.
  /// </summary>
  public class BrushesForm : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public BrushesForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
      this.SetStyle(ControlStyles.ResizeRedraw, true);
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      // 
      // BrushesForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(9, 22);
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Name = "BrushesForm";
      this.Text = "Brushes";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.BrushesForm_Paint);

    }
		#endregion

    enum LinearGradientMode {
      BackwardDiagonal,
      ForwardDiagonal,
      Horizontal,
      Vertical,
    }

    void BrushesForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      int x = 0;
      int y = 0;
      int width = this.ClientRectangle.Width;
      int height = this.ClientRectangle.Height/5;
      Brush whiteBrush = System.Drawing.Brushes.White;
      Brush blackBrush = System.Drawing.Brushes.Black;

      using( Brush brush = new SolidBrush(Color.DarkBlue) ) {
        g.FillRectangle(brush, x, y, width, height);
        g.DrawString(brush.ToString(), this.Font, whiteBrush, x, y);
        y += height;
      }

      string file = @"c:\windows\Santa Fe Stucco.bmp";
      using( Brush brush =
               new TextureBrush(new Bitmap(file)) ) {
        g.FillRectangle(brush, x, y, width, height);
        g.DrawString(brush.ToString(), this.Font, whiteBrush, x, y);
        y += height;
      }

      using( Brush brush = 
               new HatchBrush(
               HatchStyle.Divot, Color.DarkBlue, Color.White) ) {
        g.FillRectangle(brush, x, y, width, height);
        g.DrawString(brush.ToString(), this.Font, blackBrush, x, y);
        y += height;
      }

      using( Brush brush =
               new LinearGradientBrush(
               new Rectangle(x, y, width, height),
               Color.DarkBlue,
               Color.White,
               45.0f) ) {
        g.FillRectangle(brush, x, y, width, height);
        g.DrawString(brush.ToString(), this.Font, blackBrush, x, y);
        y += height;
      }

      Point[] points = new Point[] { new Point(x, y),
                                     new Point(x + width, y),
                                     new Point(x + width, y + height),
                                     new Point(x, y + height) };
      using( Brush brush = new PathGradientBrush(points) ) {
        g.FillRectangle(brush, x, y, width, height);
        g.DrawString(brush.ToString(), this.Font, blackBrush, x, y);
        y += height;
      }
    }

  }
}











