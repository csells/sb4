using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Brushes {
  /// <summary>
  /// Summary description for PathGradientBrushesForm.
  /// </summary>
  public class PathGradientBrushesForm : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public PathGradientBrushesForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      // 
      // PathGradientBrushesForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Name = "PathGradientBrushesForm";
      this.Text = "Path Gradient Brushes";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.PathGradientBrushesForm_Paint);

    }
		#endregion

    void PathGradientBrushesForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      int width = this.ClientRectangle.Width/2;
      int height = this.ClientRectangle.Height/2;

      Point[] triPoints = new Point[] { new Point(width/2, 0),
                                        new Point(0, height),
                                        new Point(width, height), };
      using( PathGradientBrush brush = new PathGradientBrush(triPoints) ) {
        brush.SurroundColors = new Color[] { Color.Red, Color.Blue };
        int x = 0;
        int y = 0;
        g.FillRectangle(brush, x, y, width, height);
      }

      Point[] quadPoints = new Point[] { new Point(0, 0), new Point(width, 0), new Point(width, height), new Point(0, height), };
      using( PathGradientBrush brush = new PathGradientBrush(quadPoints) ) {
        // defaults to Clamp, which won't draw anywhere except upper left of client
        brush.WrapMode = WrapMode.Tile;
        int x = width;
        int y = 0;
        g.FillRectangle(brush, x, y, width, height);
      }

      Point[] diamondPoints = new Point[] { new Point(width/2, 0), new Point(width, height/2), new Point(width/2, height), new Point(0, height/2), };
      using( PathGradientBrush brush =
               new PathGradientBrush(diamondPoints) ) {
        brush.WrapMode = WrapMode.Tile;
        brush.CenterPoint = new Point(0, height/2);
        int x = 0;
        int y = height;
        g.FillRectangle(brush, x, y, width, height);
      }

      //      Point[] diamondPoints = new Point[] { new Point(width/2, 0), new Point(width, height/2), new Point(width/2, height), new Point(0, height/2), };
      //      using( GraphicsPath diamondPath = new GraphicsPath() ) {
      //        diamondPath.AddPolygon(diamondPoints);
      //        using( PathGradientBrush brush = new PathGradientBrush(diamondPath) ) {
      //          brush.WrapMode = WrapMode.Tile;
      //          int x = 0;
      //          int y = height;
      //          g.FillRectangle(brush, x, y, width, height);
      //        }
      //      }

      using( GraphicsPath circle = new GraphicsPath() ) {
        circle.AddEllipse(0, 0, width, height);
        using( PathGradientBrush brush = new PathGradientBrush(circle) ) {
          brush.WrapMode = WrapMode.Tile;
          brush.SurroundColors = new Color[] { Color.White }; // default
          brush.CenterColor = Color.Black;
          int x = width;
          int y = height;
          g.FillRectangle(brush, x, y, width, height);
        }
      }

    }
  }
}
