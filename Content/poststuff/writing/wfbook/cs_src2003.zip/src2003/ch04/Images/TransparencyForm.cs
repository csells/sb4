using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Images {
  /// <summary>
  /// Summary description for Form1.
  /// </summary>
  public class TransparencyForm : System.Windows.Forms.Form {
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.Splitter splitter1;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.Panel panel2;
    private System.Windows.Forms.GroupBox groupBox3;
    private System.Windows.Forms.Splitter splitter2;
    private System.Windows.Forms.Panel panel3;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public TransparencyForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      // Constructor code
      this.SetStyle(ControlStyles.ResizeRedraw, true);
      this.SetStyle(ControlStyles.DoubleBuffer, true);
      this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.panel1 = new System.Windows.Forms.Panel();
      this.splitter1 = new System.Windows.Forms.Splitter();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.panel2 = new System.Windows.Forms.Panel();
      this.groupBox3 = new System.Windows.Forms.GroupBox();
      this.splitter2 = new System.Windows.Forms.Splitter();
      this.panel3 = new System.Windows.Forms.Panel();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.groupBox3.SuspendLayout();
      this.SuspendLayout();
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.panel1});
      this.groupBox1.Dock = System.Windows.Forms.DockStyle.Left;
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(112, 102);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Original Colors";
      // 
      // panel1
      // 
      this.panel1.BackColor = System.Drawing.Color.White;
      this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.panel1.Location = new System.Drawing.Point(3, 16);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(106, 83);
      this.panel1.TabIndex = 0;
      this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
      // 
      // splitter1
      // 
      this.splitter1.Location = new System.Drawing.Point(112, 0);
      this.splitter1.Name = "splitter1";
      this.splitter1.Size = new System.Drawing.Size(3, 102);
      this.splitter1.TabIndex = 1;
      this.splitter1.TabStop = false;
      // 
      // groupBox2
      // 
      this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.panel2});
      this.groupBox2.Dock = System.Windows.Forms.DockStyle.Left;
      this.groupBox2.Location = new System.Drawing.Point(115, 0);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size(117, 102);
      this.groupBox2.TabIndex = 2;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "White Background";
      // 
      // panel2
      // 
      this.panel2.BackColor = System.Drawing.Color.White;
      this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
      this.panel2.Location = new System.Drawing.Point(3, 16);
      this.panel2.Name = "panel2";
      this.panel2.Size = new System.Drawing.Size(111, 83);
      this.panel2.TabIndex = 0;
      this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
      // 
      // groupBox3
      // 
      this.groupBox3.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.panel3});
      this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox3.Location = new System.Drawing.Point(232, 0);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new System.Drawing.Size(120, 102);
      this.groupBox3.TabIndex = 3;
      this.groupBox3.TabStop = false;
      this.groupBox3.Text = "Made Transparent";
      // 
      // splitter2
      // 
      this.splitter2.Location = new System.Drawing.Point(232, 0);
      this.splitter2.Name = "splitter2";
      this.splitter2.Size = new System.Drawing.Size(3, 102);
      this.splitter2.TabIndex = 4;
      this.splitter2.TabStop = false;
      // 
      // panel3
      // 
      this.panel3.BackColor = System.Drawing.Color.White;
      this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
      this.panel3.Location = new System.Drawing.Point(3, 16);
      this.panel3.Name = "panel3";
      this.panel3.Size = new System.Drawing.Size(114, 83);
      this.panel3.TabIndex = 0;
      this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
      // 
      // TransparencyForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(352, 102);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.splitter2,
                                                                  this.groupBox3,
                                                                  this.groupBox2,
                                                                  this.splitter1,
                                                                  this.groupBox1});
      this.Name = "TransparencyForm";
      this.Text = "Transparency";
      this.Layout += new System.Windows.Forms.LayoutEventHandler(this.TransparencyForm_Layout);
      this.groupBox1.ResumeLayout(false);
      this.groupBox2.ResumeLayout(false);
      this.groupBox3.ResumeLayout(false);
      this.ResumeLayout(false);

    }
		#endregion

    string backgroundString = "the quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\n";

    void panel1_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      using( Bitmap bmp = new Bitmap(this.GetType(), "INTL_NO.BMP") ) {
        // Draw the text in the background
        g.DrawString(backgroundString, this.Font, Brushes.Black, this.ClientRectangle);

        Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
        rect.Offset((this.panel1.ClientRectangle.Width - rect.Width)/2, (this.panel1.ClientRectangle.Height - rect.Height)/2);
        g.DrawImage(bmp, rect);
      }
    
    }

    void panel2_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      using( Bitmap bmp = new Bitmap(this.GetType(), "INTL_NO.BMP") ) {
        // Draw the text in the background
        g.DrawString(backgroundString, this.Font, Brushes.Black, this.ClientRectangle);

        // Set the image attribute's color mappings
        ColorMap[] colorMap = new ColorMap[1];
        colorMap[0] = new ColorMap();
        colorMap[0].OldColor = bmp.GetPixel(0, bmp.Height - 1);
        colorMap[0].NewColor = Color.White;
        ImageAttributes attr = new ImageAttributes();
        attr.SetRemapTable(colorMap);

        // Draw using the color map
        Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
        rect.Offset((this.panel2.ClientRectangle.Width - rect.Width)/2, (this.panel2.ClientRectangle.Height - rect.Height)/2);
        g.DrawImage(bmp, rect, 0, 0, rect.Width, rect.Height, g.PageUnit, attr);
      }

    }

    private void panel3_Paint(object sender, System.Windows.Forms.PaintEventArgs e) {
      Graphics g = e.Graphics;
      using( Bitmap bmp = new Bitmap(this.GetType(), "INTL_NO.BMP") ) {
        // Draw the text in the background
        g.DrawString(backgroundString, this.Font, Brushes.Black, this.ClientRectangle);

        // Make the bottom left pixel the transparent color
        bmp.MakeTransparent();
        Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
        rect.Offset((this.panel2.ClientRectangle.Width - rect.Width)/2, (this.panel2.ClientRectangle.Height - rect.Height)/2);
        g.DrawImage(bmp, rect);

        //        // Set the image attribute's color mappings
        //        ColorMap[] colorMap = new ColorMap[1];
        //        colorMap[0] = new ColorMap();
        //        colorMap[0].OldColor = bmp.GetPixel(0, bmp.Height - 1);
        //        colorMap[0].NewColor = Color.Transparent;
        //        ImageAttributes attr = new ImageAttributes();
        //        attr.SetRemapTable(colorMap);
        //
        //        // Draw using the color map
        //        Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
        //        rect.Offset((this.panel2.ClientRectangle.Width - rect.Width)/2, (this.panel2.ClientRectangle.Height - rect.Height)/2);
        //        g.DrawImage(bmp, rect, 0, 0, rect.Width, rect.Height, g.PageUnit, attr);
      }

    }

    private void TransparencyForm_Layout(object sender, System.Windows.Forms.LayoutEventArgs e) {
      panel1.Refresh();
      panel2.Refresh();
      panel3.Refresh();
    }

  }
}











