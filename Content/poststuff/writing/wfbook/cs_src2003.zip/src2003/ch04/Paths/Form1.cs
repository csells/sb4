using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Paths {
    /// <summary>
    /// Summary description for Form1.
    /// </summary>
    public class Form1 : System.Windows.Forms.Form {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;

        public Form1() {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
            this.SetStyle(ControlStyles.ResizeRedraw, true);
            this.SetStyle(ControlStyles.DoubleBuffer, true);
            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose( bool disposing ) {
            if( disposing ) {
                if (components != null) {
                    components.Dispose();
                }
            }
            base.Dispose( disposing );
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            // 
            // Form1
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(22, 49);
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(292, 266);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 32F, (System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic), System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
            this.Name = "Form1";
            this.Text = "Path";
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);

        }
        #endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main() {
            Application.Run(new Form1());
        }

        GraphicsPath GetRoundedRectPath(Rectangle rect, int radius) {
            int diameter = 2 * radius;
            Rectangle arcRect = new Rectangle(rect.Location, new Size(diameter, diameter));
            GraphicsPath path = new GraphicsPath();

            // top left
            path.AddArc(arcRect, 180, 90);

            // top right
            arcRect.X = rect.Right - diameter;
            path.AddArc(arcRect, 270, 90);

            //path.StartFigure();

            // bottom right
            arcRect.Y = rect.Bottom - diameter;
            path.AddArc(arcRect, 0, 90);

            // bottom left
            arcRect.X = rect.Left;
            path.AddArc(arcRect, 90, 90);

            path.CloseFigure();

            return path;
        }

        GraphicsPath GetClosedBezierPath(Rectangle rect, Point[] points) {
            GraphicsPath path = new GraphicsPath();
            path.AddBeziers(points);
            path.CloseFigure();
            return path;
        }

        GraphicsPath GetDonutPath(Rectangle rect, int holeRadius) {
            GraphicsPath path = new GraphicsPath();
            //      path.FillMode = FillMode.Winding;
            path.AddEllipse(rect);
            Point centerPoint = new Point(rect.Left + rect.Width/2, rect.Top + rect.Height/2);
            Rectangle holeRect = new Rectangle(centerPoint.X - holeRadius, centerPoint.Y - holeRadius, holeRadius * 2, holeRadius * 2);
            //  path.StartFigure();
            path.AddEllipse(holeRect);

            // Combining text as a figure
            StringFormat format = new StringFormat();
            format.Alignment = StringAlignment.Center;
            format.LineAlignment = StringAlignment.Center;
            path.AddString("ooohhhh, donuts...", this.Font.FontFamily, (int)this.Font.Style, this.Font.Height, rect, format);

            return path;
        }

        // Need to pass in DPI = 100 for GraphicsUnit == Display
        GraphicsPath GetStringPath(
            string s,
            float dpi,
            RectangleF rect,
            Font font,
            StringFormat format) {
            GraphicsPath path = new GraphicsPath();
            // Convert font size into appropriate coordinates
            float emSize = dpi * font.SizeInPoints / 72;
            path.AddString(s, font.FontFamily, (int)font.Style, emSize, rect, format);
            return path;
        }

        private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e) {
            Graphics g = e.Graphics;
            int width = this.ClientRectangle.Width;
            int height = this.ClientRectangle.Height;
            Rectangle rect = new Rectangle(10, 10, width - 20, height - 20);
            StringFormat format = new StringFormat();
            format.Alignment = StringAlignment.Center;
            format.LineAlignment = StringAlignment.Center;
            //using( GraphicsPath path = GetRoundedRectPath(rect, width/10) ) {
            //using( GraphicsPath path = GetClosedBezierPath(rect, new Point[] { new Point(25, height - 25), new Point(width - 25, height - 25), new Point(25, 25), new Point(width - 25, 25), }) ) {
            using( GraphicsPath path = GetDonutPath(rect, width/5) ) {
            //using( GraphicsPath path = GetStringPath("Ain't paths cool?", rect, this.Font, format) ) {
                g.FillPath(Brushes.Yellow, path);
                g.DrawPath(Pens.Black, path);
            }

        }

    }
}
