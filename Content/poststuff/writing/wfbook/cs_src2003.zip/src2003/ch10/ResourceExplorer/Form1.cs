using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO; // FileStream
using System.Reflection; // Assembly
using System.Resources; // Resource readers

namespace ResourceExplorer {
  /// <summary>
  /// Summary description for Form1.
  /// </summary>
  public class Form1 : System.Windows.Forms.Form {
    private System.Windows.Forms.MainMenu mainMenu1;
    private System.Windows.Forms.MenuItem menuItem1;
    private System.Windows.Forms.MenuItem fileOpenMenuItem;
    private System.Windows.Forms.MenuItem menuItem3;
    private System.Windows.Forms.MenuItem fileExitMenuItem;
    private System.Windows.Forms.MenuItem menuItem5;
    private System.Windows.Forms.MenuItem helpAboutMenuItem;
    private System.Windows.Forms.OpenFileDialog openFileDialog1;
    private System.Windows.Forms.TreeView resourcesTreeView;
    private System.Windows.Forms.StatusBar statusBar1;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public Form1() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
      this.mainMenu1 = new System.Windows.Forms.MainMenu();
      this.menuItem1 = new System.Windows.Forms.MenuItem();
      this.fileOpenMenuItem = new System.Windows.Forms.MenuItem();
      this.menuItem3 = new System.Windows.Forms.MenuItem();
      this.fileExitMenuItem = new System.Windows.Forms.MenuItem();
      this.menuItem5 = new System.Windows.Forms.MenuItem();
      this.helpAboutMenuItem = new System.Windows.Forms.MenuItem();
      this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
      this.resourcesTreeView = new System.Windows.Forms.TreeView();
      this.statusBar1 = new System.Windows.Forms.StatusBar();
      this.SuspendLayout();
      // 
      // mainMenu1
      // 
      this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.menuItem1,
                                                                              this.menuItem5});
      // 
      // menuItem1
      // 
      this.menuItem1.Index = 0;
      this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.fileOpenMenuItem,
                                                                              this.menuItem3,
                                                                              this.fileExitMenuItem});
      this.menuItem1.Text = "&File";
      // 
      // fileOpenMenuItem
      // 
      this.fileOpenMenuItem.Index = 0;
      this.fileOpenMenuItem.Shortcut = System.Windows.Forms.Shortcut.CtrlO;
      this.fileOpenMenuItem.Text = "&Open...";
      this.fileOpenMenuItem.Click += new System.EventHandler(this.fileOpenMenuItem_Click);
      // 
      // menuItem3
      // 
      this.menuItem3.Index = 1;
      this.menuItem3.Text = "-";
      // 
      // fileExitMenuItem
      // 
      this.fileExitMenuItem.Index = 2;
      this.fileExitMenuItem.Text = "E&xit";
      this.fileExitMenuItem.Click += new System.EventHandler(this.fileExitMenuItem_Click);
      // 
      // menuItem5
      // 
      this.menuItem5.Index = 1;
      this.menuItem5.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.helpAboutMenuItem});
      this.menuItem5.Text = "&Help";
      // 
      // helpAboutMenuItem
      // 
      this.helpAboutMenuItem.Index = 0;
      this.helpAboutMenuItem.Text = "&About...";
      this.helpAboutMenuItem.Click += new System.EventHandler(this.helpAboutMenuItem_Click);
      // 
      // openFileDialog1
      // 
      this.openFileDialog1.Filter = "Resource Files (*.exe, *.dll, *.resx, *.resources)|*.exe;*.dll;*.resx;*.resources" +
        "|All Files (*.*)|*.*";
      // 
      // resourcesTreeView
      // 
      this.resourcesTreeView.Dock = System.Windows.Forms.DockStyle.Fill;
      this.resourcesTreeView.ImageIndex = -1;
      this.resourcesTreeView.Name = "resourcesTreeView";
      this.resourcesTreeView.SelectedImageIndex = -1;
      this.resourcesTreeView.Size = new System.Drawing.Size(472, 171);
      this.resourcesTreeView.Sorted = true;
      this.resourcesTreeView.TabIndex = 0;
      this.resourcesTreeView.KeyDown += new System.Windows.Forms.KeyEventHandler(this.resourcesTreeView_KeyDown);
      this.resourcesTreeView.DoubleClick += new System.EventHandler(this.resourcesTreeView_DoubleClick);
      this.resourcesTreeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.resourcesTreeView_AfterSelect);
      // 
      // statusBar1
      // 
      this.statusBar1.Location = new System.Drawing.Point(0, 171);
      this.statusBar1.Name = "statusBar1";
      this.statusBar1.Size = new System.Drawing.Size(472, 22);
      this.statusBar1.TabIndex = 1;
      // 
      // Form1
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.BackgroundImage = ((System.Drawing.Bitmap)(resources.GetObject("$this.BackgroundImage")));
      this.ClientSize = new System.Drawing.Size(472, 193);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.resourcesTreeView,
                                                                  this.statusBar1});
      this.Menu = this.mainMenu1;
      this.Name = "Form1";
      this.Text = "ResourceExplorer";
      this.ResumeLayout(false);

    }
		#endregion

    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main() {
      Application.Run(new Form1());
    }

    void LoadResourcesFromFile(string fileName) {
      resourcesTreeView.Nodes.Clear();
      TreeNode root = resourcesTreeView.Nodes.Add(Path.GetFileName(fileName));

      switch( System.IO.Path.GetExtension(fileName).ToLower() ) {
        case ".exe":
        case ".dll":
          LoadResourcesFromAssemblyFile(root, fileName);
          break;

        case ".resx":
          LoadResourcesFromResxFile(root, fileName);
          break;

        case ".resources":
          LoadResourcesFromResourcesFile(root, fileName);
          break;

        default:
          MessageBox.Show("Unknown file format");
          break;
      }

      root.Expand();
    }

    void LoadResourcesFromAssemblyFile(TreeNode parent, string fileName) {
      Assembly assem = Assembly.LoadFrom(fileName);
      foreach( string resourceName in assem.GetManifestResourceNames() ) {
        TreeNode node = parent.Nodes.Add(resourceName);
        if( resourceName.ToLower().EndsWith(".resources") ) {
          using( Stream stream = assem.GetManifestResourceStream(resourceName) ) {
            LoadResourcesFromResourcesStream(node, stream);
          }
        }
      }
    }

    void LoadResourcesFromResxFile(TreeNode parent, string fileName) {
      using( ResXResourceReader reader = new ResXResourceReader(fileName) ) {
        foreach( DictionaryEntry entry in reader ) {
          TreeNode node = parent.Nodes.Add(string.Format("{0} ({1})", entry.Key.ToString(), entry.Value.GetType()));
          node.Tag = entry.Value;
        }
      }
    }

    void LoadResourcesFromResourcesFile(TreeNode parent, string fileName) {
      using( FileStream stream = new FileStream(fileName, FileMode.Open, FileAccess.Read) ) {
        LoadResourcesFromResourcesStream(parent, stream);
      }
    }

    void LoadResourcesFromResourcesStream(TreeNode parent, Stream stream) {
      using( ResourceReader reader = new ResourceReader(stream) ) {
        foreach( DictionaryEntry entry in reader ) {
          TreeNode node = parent.Nodes.Add(string.Format("{0} ({1})", entry.Key.ToString(), (entry.Value != null ? entry.Value.GetType().ToString() : "<none>")));
          node.Tag = entry.Value;
        }
      }
    }

    void ShowSelectedNode() {
      TreeNode node = resourcesTreeView.SelectedNode;
      if( node == null ) return;
      // TODO: Show the contents
      //MessageBox.Show(node.Text);
    }

    private void fileOpenMenuItem_Click(object sender, System.EventArgs e) {
      if( openFileDialog1.ShowDialog() == DialogResult.OK ) {
        LoadResourcesFromFile(openFileDialog1.FileName);
      }
    }

    private void fileExitMenuItem_Click(object sender, System.EventArgs e) {
      this.Close();
    }

    private void helpAboutMenuItem_Click(object sender, System.EventArgs e) {
      MessageBox.Show("From the Chris Sells WinForms book(s)\r\nEnjoy.", "About ResourceExplorer");
    }

    private void resourcesTreeView_DoubleClick(object sender, System.EventArgs e) {
      ShowSelectedNode();
    }

    private void resourcesTreeView_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e) {
      if( (this == Form.ActiveForm) && ((e.KeyCode & Keys.Enter) == Keys.Enter) ) ShowSelectedNode();
    }

    private void resourcesTreeView_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e) {
      statusBar1.Text = "";
      TreeNode node = resourcesTreeView.SelectedNode;
      if( node == null ) return;
      object value = node.Tag;
      if( value == null ) return;
      statusBar1.Text = value.ToString();
    }

  }
}
