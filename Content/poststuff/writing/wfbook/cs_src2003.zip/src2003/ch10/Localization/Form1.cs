using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Globalization;

namespace LocalizedApp {
  /// <summary>
  /// Summary description for Form1.
  /// </summary>
  public class Form1 : System.Windows.Forms.Form {
    private System.Windows.Forms.ListView listView1;
    private System.Windows.Forms.ColumnHeader columnHeader1;
    private System.Windows.Forms.ColumnHeader columnHeader2;
    private System.Windows.Forms.ColumnHeader columnHeader3;
    private System.Windows.Forms.ColumnHeader columnHeader4;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public Form1() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.listView1 = new System.Windows.Forms.ListView();
      this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
      this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
      this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
      this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
      this.SuspendLayout();
      // 
      // listView1
      // 
      this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
                                                                                this.columnHeader1,
                                                                                this.columnHeader4,
                                                                                this.columnHeader2,
                                                                                this.columnHeader3});
      this.listView1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.listView1.Name = "listView1";
      this.listView1.Size = new System.Drawing.Size(352, 266);
      this.listView1.TabIndex = 0;
      this.listView1.View = System.Windows.Forms.View.Details;
      // 
      // columnHeader1
      // 
      this.columnHeader1.Text = "Culture English Name";
      this.columnHeader1.Width = 143;
      // 
      // columnHeader2
      // 
      this.columnHeader2.Text = "Currency";
      // 
      // columnHeader3
      // 
      this.columnHeader3.Text = "Date";
      this.columnHeader3.Width = 84;
      // 
      // columnHeader4
      // 
      this.columnHeader4.Text = "Name";
      // 
      // Form1
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(352, 266);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.listView1});
      this.Name = "Form1";
      this.Text = "Localized Currencies and Dates";
      this.Load += new System.EventHandler(this.Form1_Load);
      this.ResumeLayout(false);

    }
		#endregion

    void Form1_Load(object sender, EventArgs e) {
      double amount = 4.52;
      DateTime date = DateTime.Now;

      foreach( CultureInfo info in
        CultureInfo.GetCultures(CultureTypes.AllCultures) ) {
        ListViewItem item = listView1.Items.Add(info.EnglishName);
        item.SubItems.Add(info.Name);
        if( !info.IsNeutralCulture ) {
          item.SubItems.Add(amount.ToString("C", info.NumberFormat));
          item.SubItems.Add(date.ToString("d", info.DateTimeFormat));
        }
      }
    }

  }
}









