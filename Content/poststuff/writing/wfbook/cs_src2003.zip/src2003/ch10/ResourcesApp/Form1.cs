using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO; // Stream
using System.Reflection; // Assembly
using System.Resources; // Resource readers

namespace ResourcesApp {
  /// <summary>
  /// Summary description for Form1.
  /// </summary>
  public class Form1 : System.Windows.Forms.Form {
    private System.Windows.Forms.PictureBox pictureBox1;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public Form1() {
      InitializeComponent();

      // Get this form's assembly
      Assembly assem = this.GetType().Assembly;

      //      // Load the resource "ResourcesApp.Azul.jpg"
      //      Stream stream =
      //        assem.GetManifestResourceStream(this.GetType(), "Azul.jpg");

      //      // Load the bitmap from the stream
      //      this.BackgroundImage = new Bitmap(stream);

      //this.BackgroundImage = new Bitmap(stream);
      // Load image from "ResourcesApp.Azul.jpg"
      this.BackgroundImage = new Bitmap(this.GetType(), "Azul.jpg");
      //new Bitmap(this.GetType(), "foo.bar.Azul.jpg");
      //new Bitmap(@"C:\WINDOWS\Web\Wallpaper\Azul.jpg");

      //      using( ResXResourceReader reader = new ResXResourceReader(@"..\..\Resource1.resx") ) {
      //        foreach( DictionaryEntry entry in reader ) {
      //          string s = string.Format("{0} ({1})= '{2}'",
      //            entry.Key, entry.Value.GetType(), entry.Value);
      //          MessageBox.Show(s);
      //        }
      //      }
      //
      //            using( ResXResourceReader reader = new ResXResourceReader(@"..\..\Resource1.resx") ) {
      //              foreach( DictionaryEntry entry in reader ) {
      //                if( entry.Key.ToString() == "MyString" ) {
      //                  // Set form caption from string resource
      //                  this.Text = (string)entry.Value;
      //                }
      //              }
      //            }
      //      using( ResourceReader reader = new ResourceReader(@"..\..\Resource1.resources") ) {
      //        foreach( DictionaryEntry entry in reader ) {
      //          string s = string.Format("{0} ({1})= '{2}'",
      //            entry.Key, entry.Value.GetType(), entry.Value);
      //          MessageBox.Show(s);
      //        }
      //      }
      //
      //      using( ResourceReader reader = new ResourceReader(@"..\..\Resource1.resources") ) {
      //        foreach( DictionaryEntry entry in reader ) {
      //          if( entry.Key.ToString() == "MyString" ) {
      //            // Set form caption from string resource
      //            this.Text = entry.Value.ToString();
      //          }
      //        }
      //      }

//      // Load embedded .resources file
//      using( Stream stream =
//               assem.GetManifestResourceStream(
//               this.GetType(), "Resource1.resources") ) {
//        // Find resource in .resources file
//        using( ResourceReader reader = new ResourceReader(stream) ) {
//          foreach( DictionaryEntry entry in reader ) {
//            if( entry.Key.ToString() == "MyString" ) {
//              // Set form caption from string resource
//              this.Text = (string)entry.Value;
//            }
//          }
//        }
//      }

      // Load the .resources file into the ResourceManager
      // Use the type to determine resource name and assembly
      ResourceManager resman = new ResourceManager(this.GetType());

      // Set form caption from string resource
      this.Text = (string)resman.GetObject("MyString"); // The hard way
      this.Text = resman.GetString("MyString"); // The easy way
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      ResourceManager resources = new ResourceManager(typeof(Form1));
      this.pictureBox1 = new System.Windows.Forms.PictureBox();
      this.SuspendLayout();
      // 
      // pictureBox1
      // 
      this.pictureBox1.Image = (System.Drawing.Bitmap)resources.GetObject("pictureBox1.Image");
      this.pictureBox1.Location = new System.Drawing.Point(40, 40);
      this.pictureBox1.Name = "pictureBox1";
      this.pictureBox1.Size = new System.Drawing.Size(216, 192);
      this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.pictureBox1.TabIndex = 0;
      this.pictureBox1.TabStop = false;
      // 
      // Form1
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.BackgroundImage =
        (System.Drawing.Bitmap)resources.GetObject("$this.BackgroundImage");
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.pictureBox1});
      this.Name = "Form1";
      this.Text = "Form1";
      this.ResumeLayout(false);

    }
		#endregion

    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main() {
      Application.Run(new Form1());
    }
  }
}
