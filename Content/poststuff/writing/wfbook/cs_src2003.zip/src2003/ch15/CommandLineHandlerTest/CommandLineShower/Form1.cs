using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using Genghis.Web;

namespace CommandLineShower {
  /// <summary>
  /// Summary description for Form1.
  /// </summary>
  public class Form1 : System.Windows.Forms.Form {
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.ListBox mainArgumentsListBox;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.TextBox configPathTextBox;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.ListBox urlArgumentsListBox;
    private System.Windows.Forms.GroupBox groupBox3;
    private System.Windows.Forms.ListBox masterArgumentsListBox;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.TextBox piTextBox;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.TextBox appLaunchUrlTextBox;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public Form1() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.mainArgumentsListBox = new System.Windows.Forms.ListBox();
      this.label1 = new System.Windows.Forms.Label();
      this.configPathTextBox = new System.Windows.Forms.TextBox();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.urlArgumentsListBox = new System.Windows.Forms.ListBox();
      this.groupBox3 = new System.Windows.Forms.GroupBox();
      this.masterArgumentsListBox = new System.Windows.Forms.ListBox();
      this.label2 = new System.Windows.Forms.Label();
      this.piTextBox = new System.Windows.Forms.TextBox();
      this.label3 = new System.Windows.Forms.Label();
      this.appLaunchUrlTextBox = new System.Windows.Forms.TextBox();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.groupBox3.SuspendLayout();
      this.SuspendLayout();
      // 
      // groupBox1
      // 
      this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.mainArgumentsListBox});
      this.groupBox1.Location = new System.Drawing.Point(8, 16);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(720, 100);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Main Arguments";
      // 
      // mainArgumentsListBox
      // 
      this.mainArgumentsListBox.Dock = System.Windows.Forms.DockStyle.Fill;
      this.mainArgumentsListBox.IntegralHeight = false;
      this.mainArgumentsListBox.Location = new System.Drawing.Point(3, 16);
      this.mainArgumentsListBox.Name = "mainArgumentsListBox";
      this.mainArgumentsListBox.Size = new System.Drawing.Size(714, 81);
      this.mainArgumentsListBox.TabIndex = 0;
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(8, 160);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(112, 23);
      this.label1.TabIndex = 1;
      this.label1.Text = ".config File Path";
      this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // configPathTextBox
      // 
      this.configPathTextBox.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.configPathTextBox.Location = new System.Drawing.Point(128, 160);
      this.configPathTextBox.Name = "configPathTextBox";
      this.configPathTextBox.ReadOnly = true;
      this.configPathTextBox.Size = new System.Drawing.Size(600, 20);
      this.configPathTextBox.TabIndex = 2;
      this.configPathTextBox.Text = "textBox1";
      // 
      // groupBox2
      // 
      this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.urlArgumentsListBox});
      this.groupBox2.Location = new System.Drawing.Point(8, 192);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size(720, 100);
      this.groupBox2.TabIndex = 0;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "URL Arguments";
      // 
      // urlArgumentsListBox
      // 
      this.urlArgumentsListBox.Dock = System.Windows.Forms.DockStyle.Fill;
      this.urlArgumentsListBox.IntegralHeight = false;
      this.urlArgumentsListBox.Location = new System.Drawing.Point(3, 16);
      this.urlArgumentsListBox.Name = "urlArgumentsListBox";
      this.urlArgumentsListBox.Size = new System.Drawing.Size(714, 81);
      this.urlArgumentsListBox.TabIndex = 0;
      // 
      // groupBox3
      // 
      this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.groupBox3.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.masterArgumentsListBox});
      this.groupBox3.Location = new System.Drawing.Point(8, 304);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new System.Drawing.Size(720, 100);
      this.groupBox3.TabIndex = 0;
      this.groupBox3.TabStop = false;
      this.groupBox3.Text = "Master Arguments";
      // 
      // masterArgumentsListBox
      // 
      this.masterArgumentsListBox.Dock = System.Windows.Forms.DockStyle.Fill;
      this.masterArgumentsListBox.IntegralHeight = false;
      this.masterArgumentsListBox.Location = new System.Drawing.Point(3, 16);
      this.masterArgumentsListBox.Name = "masterArgumentsListBox";
      this.masterArgumentsListBox.Size = new System.Drawing.Size(714, 81);
      this.masterArgumentsListBox.TabIndex = 0;
      // 
      // label2
      // 
      this.label2.Location = new System.Drawing.Point(16, 416);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(80, 23);
      this.label2.TabIndex = 3;
      this.label2.Text = "pi from .config";
      this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // piTextBox
      // 
      this.piTextBox.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.piTextBox.Location = new System.Drawing.Point(104, 416);
      this.piTextBox.Name = "piTextBox";
      this.piTextBox.ReadOnly = true;
      this.piTextBox.Size = new System.Drawing.Size(608, 20);
      this.piTextBox.TabIndex = 2;
      this.piTextBox.Text = "";
      // 
      // label3
      // 
      this.label3.Location = new System.Drawing.Point(8, 128);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(112, 23);
      this.label3.TabIndex = 1;
      this.label3.Text = "APP_LAUNCH_URL";
      this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // appLaunchUrlTextBox
      // 
      this.appLaunchUrlTextBox.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.appLaunchUrlTextBox.Location = new System.Drawing.Point(128, 128);
      this.appLaunchUrlTextBox.Name = "appLaunchUrlTextBox";
      this.appLaunchUrlTextBox.ReadOnly = true;
      this.appLaunchUrlTextBox.Size = new System.Drawing.Size(600, 20);
      this.appLaunchUrlTextBox.TabIndex = 2;
      this.appLaunchUrlTextBox.Text = "textBox1";
      // 
      // Form1
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(744, 446);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.label2,
                                                                  this.configPathTextBox,
                                                                  this.label1,
                                                                  this.groupBox1,
                                                                  this.groupBox2,
                                                                  this.groupBox3,
                                                                  this.piTextBox,
                                                                  this.label3,
                                                                  this.appLaunchUrlTextBox});
      this.Name = "Form1";
      this.Text = "Command Line Shower";
      this.Load += new System.EventHandler(this.Form1_Load);
      this.groupBox1.ResumeLayout(false);
      this.groupBox2.ResumeLayout(false);
      this.groupBox3.ResumeLayout(false);
      this.ResumeLayout(false);

    }
		#endregion

    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main(string[] args) {
      Form1 form = new Form1();
      form.MainArguments = args;
      Application.Run(form);
    }

    void Form1_Load(object sender, EventArgs e) {
      this.Text += string.Format(" (for .NET v{0})", Environment.Version);

      mainArgumentsListBox.DataSource = mainArgs;

      try {
        object obj = AppDomain.CurrentDomain.GetData("APP_LAUNCH_URL");
        appLaunchUrlTextBox.Text = (obj != null ? obj.ToString() : "<null>");
      }
      catch( Exception ex ) {
        appLaunchUrlTextBox.Text = ex.Message;
      }

      configPathTextBox.Text = AppDomain.CurrentDomain.SetupInformation.ConfigurationFile;
      urlArgumentsListBox.DataSource = WebCommandLineHelper.CommandLineArgs(null);
      masterArgumentsListBox.DataSource = WebCommandLineHelper.CommandLineArgs(mainArgs);
      try {
        piTextBox.Text = System.Configuration.ConfigurationSettings.AppSettings["pi"].ToString();
      }
      catch( Exception ex ) {
        piTextBox.Text = "Exception: " + ex.Message;
      }
    }

    string[] mainArgs = null;

    public string[] MainArguments {
      set { mainArgs = value; }
    }

  }
}
