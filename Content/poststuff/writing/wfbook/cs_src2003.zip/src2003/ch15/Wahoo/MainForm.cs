using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;
using System.IO.IsolatedStorage;
using System.Text;
using System.Security;
using System.Security.Permissions;
using System.Diagnostics;
using System.Reflection;
using Wahoo.localhost;
using WahooControl;

using System.Web.Services.Protocols;

namespace Wahoo {
  public class MainForm : System.Windows.Forms.Form {
    private System.Windows.Forms.MainMenu mainMenu;
    private System.Windows.Forms.MenuItem menuItem1;
    private System.Windows.Forms.MenuItem menuItem3;
    private System.Windows.Forms.MenuItem cmdHelpAbout;
    private System.Windows.Forms.StatusBar statusBar;
    private System.ComponentModel.IContainer components;
    private System.Windows.Forms.MenuItem menuItem2;
    private System.Windows.Forms.MenuItem cmdGameExit;
    private System.Windows.Forms.MenuItem cmdGameNew;
    private System.Windows.Forms.MenuItem cmdGamePauseResume;
    private System.Windows.Forms.StatusBarPanel panelStatus;
    private System.Windows.Forms.StatusBarPanel panelScore;
    private System.Windows.Forms.MenuItem cmdGetHighScores;
    private System.Windows.Forms.MenuItem cmdViewCachedHighScores;
    private System.Windows.Forms.MenuItem menuItem6;
    private WahooControl.WahooGame game;
    private System.Windows.Forms.MenuItem cmdKeys;
    private System.Windows.Forms.MenuItem menuItem4;
    private int _score = 0;

    public MainForm() {
      // Required for Windows Form Designer support
      components = null;
      InitializeComponent();

      // HACK: Add a textbox so that we can get the arrow keys
      //Controls.Add(new System.Windows.Forms.TextBox());

      // Load the user preferences
      LoadSettings();
    }

        #region Isolated storage stuff
    private void LoadSettings() {
      try {
        using( Stream       stream = OpenSettingsStream() )
        using( StreamReader reader = new StreamReader(stream) ) {
          Location = (Point)ReadSetting(reader, typeof(Point));
          ClientSize = (Size)ReadSetting(reader, typeof(Size));
        }
      }
      catch {
        // If there's nothing to read, put the form in the center of the screen
        StartPosition = FormStartPosition.CenterScreen;
      }
    }

    private void SaveSettings() {
      // Restore so we don't store a zero size or location
      WindowState = FormWindowState.Normal;

      // Save the window location
      using( Stream       stream = CreateSettingsStream() )
      using( StreamWriter writer = new StreamWriter(stream) ) {
        WriteSetting(writer, Location);

        // NOTE: We save and restore the client size because
        // using just the window size seems to cause the form
        // to grow and grow...
        WriteSetting(writer, ClientSize);
      }
    }

    private IsolatedStorageFileStream CreateSettingsStream() {
      IsolatedStorageFile store = IsolatedStorageFile.GetUserStoreForDomain();
      return new IsolatedStorageFileStream("settings.txt", FileMode.Create, store);
    }

    private IsolatedStorageFileStream OpenSettingsStream() {
      IsolatedStorageFile store = IsolatedStorageFile.GetUserStoreForDomain();
      return new IsolatedStorageFileStream("settings.txt", FileMode.Open, store);
    }

    private object ReadSetting(StreamReader reader, Type type) {
      TypeConverter   converter = TypeDescriptor.GetConverter(type);
      return converter.ConvertFromString(reader.ReadLine());
    }

    private void WriteSetting(StreamWriter writer, object obj) {
      TypeConverter   converter = TypeDescriptor.GetConverter(obj.GetType());
      writer.WriteLine(converter.ConvertToString(obj));
    }
        #endregion

    // Clean up any resources being used
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }


        #region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(MainForm));
      this.mainMenu = new System.Windows.Forms.MainMenu();
      this.menuItem1 = new System.Windows.Forms.MenuItem();
      this.cmdGameNew = new System.Windows.Forms.MenuItem();
      this.cmdGamePauseResume = new System.Windows.Forms.MenuItem();
      this.menuItem2 = new System.Windows.Forms.MenuItem();
      this.cmdGetHighScores = new System.Windows.Forms.MenuItem();
      this.cmdViewCachedHighScores = new System.Windows.Forms.MenuItem();
      this.menuItem6 = new System.Windows.Forms.MenuItem();
      this.cmdGameExit = new System.Windows.Forms.MenuItem();
      this.menuItem3 = new System.Windows.Forms.MenuItem();
      this.cmdKeys = new System.Windows.Forms.MenuItem();
      this.menuItem4 = new System.Windows.Forms.MenuItem();
      this.cmdHelpAbout = new System.Windows.Forms.MenuItem();
      this.statusBar = new System.Windows.Forms.StatusBar();
      this.panelStatus = new System.Windows.Forms.StatusBarPanel();
      this.panelScore = new System.Windows.Forms.StatusBarPanel();
      this.game = new WahooControl.WahooGame();
      ((System.ComponentModel.ISupportInitialize)(this.panelStatus)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.panelScore)).BeginInit();
      this.SuspendLayout();
      // 
      // mainMenu
      // 
      this.mainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                             this.menuItem1,
                                                                             this.menuItem3});
      // 
      // menuItem1
      // 
      this.menuItem1.Index = 0;
      this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.cmdGameNew,
                                                                              this.cmdGamePauseResume,
                                                                              this.menuItem2,
                                                                              this.cmdGetHighScores,
                                                                              this.cmdViewCachedHighScores,
                                                                              this.menuItem6,
                                                                              this.cmdGameExit});
      this.menuItem1.Text = "&Game";
      this.menuItem1.Click += new System.EventHandler(this.menuItem1_Click);
      // 
      // cmdGameNew
      // 
      this.cmdGameNew.Index = 0;
      this.cmdGameNew.Shortcut = System.Windows.Forms.Shortcut.F2;
      this.cmdGameNew.Text = "&New Game";
      this.cmdGameNew.Click += new System.EventHandler(this.cmdGameNew_Click);
      // 
      // cmdGamePauseResume
      // 
      this.cmdGamePauseResume.Index = 1;
      this.cmdGamePauseResume.Shortcut = System.Windows.Forms.Shortcut.F3;
      this.cmdGamePauseResume.Text = "&Pause/Resume Game";
      this.cmdGamePauseResume.Click += new System.EventHandler(this.cmdGamePauseResume_Click);
      // 
      // menuItem2
      // 
      this.menuItem2.Index = 2;
      this.menuItem2.Text = "-";
      // 
      // cmdGetHighScores
      // 
      this.cmdGetHighScores.Index = 3;
      this.cmdGetHighScores.Text = "&Get High Scores...";
      this.cmdGetHighScores.Click += new System.EventHandler(this.cmdGetHighScores_Click);
      // 
      // cmdViewCachedHighScores
      // 
      this.cmdViewCachedHighScores.Index = 4;
      this.cmdViewCachedHighScores.Text = "&View Cached High Scores...";
      this.cmdViewCachedHighScores.Click += new System.EventHandler(this.cmdViewCachedHighScores_Click);
      // 
      // menuItem6
      // 
      this.menuItem6.Index = 5;
      this.menuItem6.Text = "-";
      // 
      // cmdGameExit
      // 
      this.cmdGameExit.Index = 6;
      this.cmdGameExit.Text = "E&xit";
      this.cmdGameExit.Click += new System.EventHandler(this.cmdGameExit_Click);
      // 
      // menuItem3
      // 
      this.menuItem3.Index = 1;
      this.menuItem3.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.cmdKeys,
                                                                              this.menuItem4,
                                                                              this.cmdHelpAbout});
      this.menuItem3.Text = "&Help";
      // 
      // cmdKeys
      // 
      this.cmdKeys.Index = 0;
      this.cmdKeys.Text = "&Keys...";
      this.cmdKeys.Click += new System.EventHandler(this.cmdKeys_Click);
      // 
      // menuItem4
      // 
      this.menuItem4.Index = 1;
      this.menuItem4.Text = "-";
      // 
      // cmdHelpAbout
      // 
      this.cmdHelpAbout.Index = 2;
      this.cmdHelpAbout.Text = "&About Wahoo!...";
      this.cmdHelpAbout.Click += new System.EventHandler(this.cmdHelpAbout_Click);
      // 
      // statusBar
      // 
      this.statusBar.Location = new System.Drawing.Point(0, 363);
      this.statusBar.Name = "statusBar";
      this.statusBar.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
                                                                                 this.panelStatus,
                                                                                 this.panelScore});
      this.statusBar.ShowPanels = true;
      this.statusBar.Size = new System.Drawing.Size(304, 22);
      this.statusBar.TabIndex = 1;
      this.statusBar.Text = "Ready";
      // 
      // panelStatus
      // 
      this.panelStatus.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
      this.panelStatus.Text = "Ready (F2 to Play)";
      this.panelStatus.Width = 219;
      // 
      // panelScore
      // 
      this.panelScore.Alignment = System.Windows.Forms.HorizontalAlignment.Right;
      this.panelScore.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Contents;
      this.panelScore.MinWidth = 1;
      this.panelScore.Text = "Score: 000";
      this.panelScore.Width = 69;
      // 
      // game
      // 
      this.game.BackgroundImage = ((System.Drawing.Bitmap)(resources.GetObject("game.BackgroundImage")));
      this.game.Columns = 10;
      this.game.Dock = System.Windows.Forms.DockStyle.Fill;
      this.game.Name = "game";
      this.game.Padding = 2;
      this.game.Rows = 20;
      this.game.Size = new System.Drawing.Size(304, 363);
      this.game.TabIndex = 0;
      this.game.TabStop = false;
      this.game.TickInterval = 500;
      this.game.GameOver += new WahooControl.WahooGame.GameOverCallback(this.game_GameOver);
      this.game.LinesRemoved += new WahooControl.WahooGame.LinesRemovedCallback(this.game_LinesRemoved);
      // 
      // MainForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(304, 385);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.game,
                                                                  this.statusBar});
      this.KeyPreview = true;
      this.Menu = this.mainMenu;
      this.Name = "MainForm";
      this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
      this.Text = "Wahoo!";
      ((System.ComponentModel.ISupportInitialize)(this.panelStatus)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.panelScore)).EndInit();
      this.ResumeLayout(false);

    }
		#endregion

    [STAThread]
    static void Main() {
      Application.Run(new MainForm());
    }


        #region Event handlers
    private void cmdGameNew_Click(object sender, System.EventArgs e) {
      if( game.IsPlaying ) {
        if( MessageBox.Show("Quit current game?", "Wahoo!", MessageBoxButtons.YesNo) == DialogResult.No ) {
          return;
        }
      }

      _score = 0;
      game.New();
      panelStatus.Text = "Playing (F3 to Pause)";
      panelScore.Text = "Score: " + _score;
    }

    private void cmdGamePauseResume_Click(object sender, System.EventArgs e) {
      if( !game.IsPlaying ) return;

      if( game.IsPaused ) {
        game.Resume();
        panelStatus.Text = "Playing (F3 to Pause)";
      }
      else {
        game.Pause();
        panelStatus.Text = "Paused (F3 to Resume)";
      }
    }

    protected override void OnDeactivate(EventArgs args) {
      base.OnDeactivate(args);

      if( !game.IsPlaying || game.IsPaused ) return;

      game.Pause();
      panelStatus.Text = "Paused (F3 to Resume)";
    }

    protected override void OnKeyDown(System.Windows.Forms.KeyEventArgs e) {
      Trace.WriteLine(string.Format("MainForm_KeyDown({0})", e.KeyData));
      e.Handled = game.ProcessKey(e.KeyData);
      base.OnKeyDown(e);
    }

    protected override void OnClosing(CancelEventArgs args) {
      SaveSettings();
    }
        
    private void cmdGameExit_Click(object sender, System.EventArgs e) {
      Close();
    }

    private void cmdKeys_Click(object sender, System.EventArgs e) {
      string  s = "The Wahoo! control keys are:\r\n\r\n" +
        "Left:\tj and Left Arrow\r\n" +
        "Right:\tl and Right Arrow\r\n" +
        "Rotate:\ti and Up Arrow\r\n" +
        "Drop:\tk and Down Arrow";
      MessageBox.Show(s, "Wahoo! Keys");
    }

    private void cmdHelpAbout_Click(object sender, System.EventArgs e) {
      // Get referenced assemblies
      StringBuilder   sb = new StringBuilder();
      Assembly        executingAssembly = Assembly.GetExecutingAssembly();
      foreach( AssemblyName name in executingAssembly.GetReferencedAssemblies() ) {
        sb.Append(string.Format("{0} v{1}\r\n", name.Name, name.Version));
      }

      // Get this assembly
      Version     version = executingAssembly.GetName().Version;
      MessageBox.Show(string.Format("The game of Wahoo! v{0}\r\nCopyright (c) 2001-2002, Chris Sells\r\nEnjoy.\r\n\r\nReferenced Assemblies:\r\n{1}", version, sb.ToString()), "About Wahoo!");
    }

    private void game_GameOver() {
      panelStatus.Text = "Game Over (F2 to Play)";

      // Let the player know and ask them if they'd like to
      // send their high score to the server
      DialogResult    dr = MessageBox.Show("Game Over...\r\n\r\nSend score of " + _score + " to Wahoo! high score server?", "Wahoo!", MessageBoxButtons.YesNo);
      if( dr == DialogResult.Yes ) {
        SendHighScore(_score);
      }
    }

    private void game_LinesRemoved(int linesRemoved) {
      // Normalize the speed
      int speed = (game.Speed < 10 ? 1 : game.Speed);

      // A Wahoo! is double
      if( linesRemoved == 4 ) {
        _score += linesRemoved * speed * 2;
        panelScore.Text = "Score: " + _score + " (Wahoo!)";
      }
      else {
        _score += linesRemoved * speed;
        panelScore.Text = "Score: " + _score;
      }
    }

    private void cmdGetHighScores_Click(object sender, System.EventArgs e) {
      GetHighScores();
    }

    private void cmdViewCachedHighScores_Click(object sender, System.EventArgs e) {
      OpenFileDialog  dlg = new OpenFileDialog();
      dlg.DefaultExt = ".txt";
      dlg.Filter = "Text Files (*.txt)|*.txt|All files (*.*)|*.*";

      if( dlg.ShowDialog() == DialogResult.OK ) {
        using( Stream stream = dlg.OpenFile() )
        using( StreamReader reader = new StreamReader(stream) ) {
          MessageBox.Show(reader.ReadToEnd(), "Wahoo! Cached High Scores");
        }
      }
    }
        #endregion

    // Check permission
    bool HavePermission(IPermission perm) {
      try { perm.Demand(); }
      catch( SecurityException ) { return false; }
      return true;
    }


        #region Web Service Access
        
    void SendHighScore(int score) {
      HighScoreWhoForm    dlg = new HighScoreWhoForm();
      dlg.lblScore.Text = score.ToString();
      dlg.txtName.Text = "Anon";

      if( dlg.ShowDialog() != DialogResult.OK ) return;

      try {
        // Send score
        WahooScoresService service = (WahooScoresService)GetServiceForAppBase(typeof(WahooScoresService));
        service.RegisterScore(dlg.txtName.Text, score);
        MessageBox.Show("Your high score was registered on the Wahoo! server", "Wahoo!");
      }
      catch( Exception e ) {
        MessageBox.Show("Unable to send high score: " + e.Message, "Wahoo!");
        return;
      }
    }

    // Get a client-side web service proxy of any type, replacing
    // the "localhost" site with the appbase site
    static SoapHttpClientProtocol GetServiceForAppBase(Type type) {
      // Create an instance of the service using .NET Reflection
      SoapHttpClientProtocol service = (SoapHttpClientProtocol)
        type.Assembly.CreateInstance(type.FullName);
      if( service == null ) throw new ArgumentException("Can't create service of type: " + type.FullName, "type");

      try {
        // Set URL to server where this came from
        string appbase =
          AppDomain.CurrentDomain.BaseDirectory;
        string site =
          System.Security.Policy.Site.CreateFromUrl(appbase).Name;
        service.Url =
          service.Url.Replace("//localhost/", "//" + site + "/");
      }
        // If we can't create a site from the appbase,
        // then we're not a ZTD app and there's no reason to
        // adjust the service's URL
      catch( ArgumentException ) {}

      return service;
    }

    void GetHighScores() {
      WahooScore[]    scores;

      try {
        // Get scores
        WahooScoresService service = (WahooScoresService)
          GetServiceForAppBase(typeof(WahooScoresService));
        scores = service.GetScores();
      }
      catch( Exception e ) {
        MessageBox.Show("Unable to get high scores\r\n" + e.Message, "Wahoo!");
        return;
      }
                            
      // Show scores
      StringBuilder    sb = new StringBuilder();
      for( int i = 0; i != Math.Min(scores.Length, 10); ++i ) {
        sb.AppendFormat("{0}\t{1}\r\n", scores[i].Score, scores[i].Name);
      }

      DialogResult    dr = MessageBox.Show(sb.ToString() + "\r\nCache these scores locally?", "Wahoo! Top 10 Scores", MessageBoxButtons.YesNo);

      // Cache scores safely
      if( dr == DialogResult.Yes ) {
        // Check for permissions to do this
        // (By default, won't have this permission in the Internet Zone)
        if( !HavePermission(new FileDialogPermission(FileDialogPermissionAccess.Save)) ) {
          string  s = "This application does not have permission to save files on this machine.";
          MessageBox.Show(s, "Wahoo!");
          return;
        }

        SaveFileDialog  dlg = new SaveFileDialog();
        dlg.DefaultExt = ".txt";
        dlg.Filter = "Text Files (*.txt)|*.txt|All files (*.*)|*.*";

        // NOTE: Not allowed unless we have FileIOPermission : )
        //dlg.AddExtension = true;
        //dlg.FileName = "Wahoo! High Scores.txt";

        if( dlg.ShowDialog() == DialogResult.OK ) {
          using( Stream stream = dlg.OpenFile() )
          using( StreamWriter writer = new StreamWriter(stream) ) {
            writer.Write(sb.ToString());
          }
        }
      }
    }

        #endregion

    private void menuItem1_Click(object sender, System.EventArgs e) {
        
    }
  }
}
