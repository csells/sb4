using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace DataSets {
  /// <summary>
  /// Summary description for MultiTableForm.
  /// </summary>
  public class MultiTableForm : System.Windows.Forms.Form {
    private System.Windows.Forms.ListBox customersListBox;
    private System.Windows.Forms.ContextMenu contextMenu1;
    private System.Windows.Forms.MenuItem addRowMenuItem;
    private System.Windows.Forms.MenuItem updateSelectedRowMenuItem;
    private System.Windows.Forms.MenuItem deleteSelectedRowMenuItem;
    private System.Windows.Forms.MenuItem commitChangesMenuItem;
    private System.Windows.Forms.Splitter splitter1;
    private System.Windows.Forms.ListBox ordersListBox;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public MultiTableForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.customersListBox = new System.Windows.Forms.ListBox();
      this.contextMenu1 = new System.Windows.Forms.ContextMenu();
      this.addRowMenuItem = new System.Windows.Forms.MenuItem();
      this.updateSelectedRowMenuItem = new System.Windows.Forms.MenuItem();
      this.deleteSelectedRowMenuItem = new System.Windows.Forms.MenuItem();
      this.commitChangesMenuItem = new System.Windows.Forms.MenuItem();
      this.splitter1 = new System.Windows.Forms.Splitter();
      this.ordersListBox = new System.Windows.Forms.ListBox();
      this.SuspendLayout();
      // 
      // customersListBox
      // 
      this.customersListBox.ContextMenu = this.contextMenu1;
      this.customersListBox.Dock = System.Windows.Forms.DockStyle.Top;
      this.customersListBox.IntegralHeight = false;
      this.customersListBox.Name = "customersListBox";
      this.customersListBox.Size = new System.Drawing.Size(312, 136);
      this.customersListBox.TabIndex = 0;
      this.customersListBox.SelectedIndexChanged += new System.EventHandler(this.customersListBox_SelectedIndexChanged);
      // 
      // contextMenu1
      // 
      this.contextMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                 this.addRowMenuItem,
                                                                                 this.updateSelectedRowMenuItem,
                                                                                 this.deleteSelectedRowMenuItem,
                                                                                 this.commitChangesMenuItem});
      // 
      // addRowMenuItem
      // 
      this.addRowMenuItem.Index = 0;
      this.addRowMenuItem.Text = "&Add Row";
      this.addRowMenuItem.Click += new System.EventHandler(this.addRowMenuItem_Click);
      // 
      // updateSelectedRowMenuItem
      // 
      this.updateSelectedRowMenuItem.Index = 1;
      this.updateSelectedRowMenuItem.Text = "&Update Selected Row";
      this.updateSelectedRowMenuItem.Click += new System.EventHandler(this.updateSelectedRowMenuItem_Click);
      // 
      // deleteSelectedRowMenuItem
      // 
      this.deleteSelectedRowMenuItem.Index = 2;
      this.deleteSelectedRowMenuItem.Text = "&Delete Selected Row";
      this.deleteSelectedRowMenuItem.Click += new System.EventHandler(this.deleteSelectedRowMenuItem_Click);
      // 
      // commitChangesMenuItem
      // 
      this.commitChangesMenuItem.Index = 3;
      this.commitChangesMenuItem.Text = "&Commit Changes";
      this.commitChangesMenuItem.Click += new System.EventHandler(this.commitChangesMenuItem_Click);
      // 
      // splitter1
      // 
      this.splitter1.Dock = System.Windows.Forms.DockStyle.Top;
      this.splitter1.Location = new System.Drawing.Point(0, 136);
      this.splitter1.Name = "splitter1";
      this.splitter1.Size = new System.Drawing.Size(312, 3);
      this.splitter1.TabIndex = 1;
      this.splitter1.TabStop = false;
      // 
      // ordersListBox
      // 
      this.ordersListBox.Dock = System.Windows.Forms.DockStyle.Fill;
      this.ordersListBox.IntegralHeight = false;
      this.ordersListBox.Location = new System.Drawing.Point(0, 139);
      this.ordersListBox.Name = "ordersListBox";
      this.ordersListBox.Size = new System.Drawing.Size(312, 179);
      this.ordersListBox.TabIndex = 2;
      // 
      // MultiTableForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(312, 318);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.ordersListBox,
                                                                  this.splitter1,
                                                                  this.customersListBox});
      this.Name = "MultiTableForm";
      this.Text = "Multi-Table Data Sets";
      this.Load += new System.EventHandler(this.MultiTableForm_Load);
      this.ResumeLayout(false);

    }
		#endregion

    // Configure the connection
    SqlConnection conn = new SqlConnection(@"data source=MUNGO\NETSDK;initial catalog=northwind;integrated security=SSPI");

    // Create the adapters
    SqlDataAdapter customersAdapter = new SqlDataAdapter();
    SqlDataAdapter ordersAdapter = new SqlDataAdapter();

    // A data set for use by the form
    DataSet dataset = new DataSet();

    void PopulateListBoxes() {
      // Clear the listbox
      customersListBox.Items.Clear();

      // Enumerate cached data
      foreach( DataRow row in dataset.Tables["customers"].Rows ) {
        if( (row.RowState & DataRowState.Deleted) != 0 )  {
          string id =
            row["CustomerID", DataRowVersion.Original].ToString();
          customersListBox.Items.Add("***deleted***: " + id);
          continue;
        }

        // Use the expression instead of composing the string
        //string item = row["ContactTitle"] + ", " + row["ContactName"];
        string item = row["ContactTitleName"].ToString();
        //item += string.Format(" ({2})", row.RowState);
        if( row.HasErrors ) item += "(***" + row.RowError + "***)";
        customersListBox.Items.Add(item);
      }

      PopulateChildListBox();
    }

    void PopulateChildListBox() {
      // Clear the listbox
      ordersListBox.Items.Clear();

      // Get the currently selected parent custom row
      int index = customersListBox.SelectedIndex;
      if( index == -1 ) return;

      // Get row from data set
      DataRow parent = dataset.Tables["Customers"].Rows[index];

      // Enumerate child rows
      foreach( DataRow row in parent.GetChildRows("CustomersOrders") ) {
        if( (row.RowState & DataRowState.Deleted) != 0 )  {
          string id =
            row["OrderID", DataRowVersion.Original].ToString();
          ordersListBox.Items.Add("***deleted***: " + id);
          continue;
        }

        string item = row["OrderID"] + ", " + row["OrderDate"] + ", " + row["CustomerContactName"];
        //item += string.Format(" ({2})", row.RowState);
        if( row.HasErrors ) item += "(***" + row.RowError + "***)";
        ordersListBox.Items.Add(item);
      }
    }

    void MultiTableForm_Load(object sender, EventArgs e) {
      // Create the Customer adapter from the connection
      customersAdapter.SelectCommand = conn.CreateCommand();
      customersAdapter.SelectCommand.CommandText =
        "select * from customers";

      // Fill the data set w/ the Customers table
      customersAdapter.Fill(dataset, "Customers");

      // Create the Customer adapter from the connection
      ordersAdapter.SelectCommand = conn.CreateCommand();
      ordersAdapter.SelectCommand.CommandText =
        "select * from orders";

      // Fill the data set w/ the Orders table
      ordersAdapter.Fill(dataset, "Orders");

      // Need one command builder for each adapter
      // in anticipation of eventually committing changes
      new SqlCommandBuilder(customersAdapter);
      new SqlCommandBuilder(ordersAdapter);

      // Get reference of the tables
      DataTable customers = dataset.Tables["Customers"];
      DataTable orders = dataset.Tables["Orders"];

      // Add a constraint
      UniqueConstraint constraint =
        new UniqueConstraint(customers.Columns["CustomerID"]);
      customers.Constraints.Add(constraint);

      // Create the relation
      DataRelation relation =
        new DataRelation(
        "CustomersOrders",
        customers.Columns["CustomerID"],
        orders.Columns["CustomerID"]);

      // Add the relation
      dataset.Relations.Add(relation);

      // Create the expression column
      DataColumn exp = new DataColumn();
      exp.ColumnName = "ContactTitleName";
      exp.DataType = typeof(string);
      exp.Expression = "ContactTitle + ', ' + ContactName";

      // Add it to the customer table
      dataset.Tables["Customers"].Columns.Add(exp);

      // Create the expression column
      DataColumn exp2 = new DataColumn();
      exp2.ColumnName = "CustomerContactName";
      exp2.DataType = typeof(string);
      exp2.Expression = "parent(CustomersOrders).ContactName";

      // Add it to the customer table
      dataset.Tables["Orders"].Columns.Add(exp2);

      // Populate listboxes
      PopulateListBoxes();
    }

    void addRowMenuItem_Click(object sender, EventArgs e) {
      // Ask table for an empty DataRow
      DataRow row = dataset.Tables[0].NewRow();

      // Fill DataRow
      row["CustomerID"] = "SELLSB";
      row["CompanyName"] = "Sells Brothers, Inc.";
      row["ContactName"] = "Chris Sells";
      row["ContactTitle"] = "Chief Cook and Bottle Washer";
      row["Address"] = "555 Not My Street";
      row["City"] = "Beaverton";
      row["Region"] = "OR";
      row["PostalCode"] = "97007";
      row["Country"] = "USA";
      row["Phone"] = "503-555-1234";
      row["Fax"] = "503-555-4321";

      // Add DataRow to the table
      dataset.Tables[0].Rows.Add(row);

      // Update listboxes
      PopulateListBoxes();
    }

    void updateSelectedRowMenuItem_Click(object sender, EventArgs e) {
      // Get selection index from listbox
      int index = customersListBox.SelectedIndex;
      if( index == -1 ) return;

      // Get row from dataset
      DataRow row = dataset.Tables[0].Rows[index];

      // Update the row as appropriate
      row["ContactTitle"] = "CEO";

      DataTable
        tableChanges = dataset.Tables[0].GetChanges(DataRowState.Modified);
      if( tableChanges != null ) {
        foreach( DataRow changedRow in tableChanges.Rows ) {
          MessageBox.Show(changedRow["CustomerID"] + " modified");
        }
      }

      // Update listboxes
      PopulateListBoxes();
    }

    void deleteSelectedRowMenuItem_Click(object sender, EventArgs e) {
      // Get selection index from listbox
      int index = customersListBox.SelectedIndex;
      if( index == -1 ) return;

      // Get row from dataset
      DataRow row = dataset.Tables[0].Rows[index];

      // Mark the row as deleted
      row.Delete();

      DataTable tableChanges = dataset.Tables[0].GetChanges(DataRowState.Deleted);
      if( tableChanges != null ) {
        foreach( DataRow deletedRow in tableChanges.Rows ) {
          MessageBox.Show("***deleted***" + deletedRow["CustomerID", DataRowVersion.Original]);
        }
      }

      // Update listboxes
      PopulateListBoxes();
    }

    void commitChangesMenuItem_Click(object sender, EventArgs e) {
      // Commit customer changes back to the data source
      try {
        customersAdapter.Update(dataset, "Customers");
      }
      catch( SqlException ex ) {
        MessageBox.Show(ex.Message,
          "Error(s) Committing Customer Changes");
      }

      // Commit order changes back to the data source
      try {
        ordersAdapter.Update(dataset, "Orders");
      }
      catch( SqlException ex ) {
        MessageBox.Show(ex.Message,
          "Error(s) Committing Order Changes");
      }

      // Update listboxes
      PopulateListBoxes();
    }

    void customersListBox_SelectedIndexChanged(object sender, EventArgs e) {
      PopulateChildListBox();    
    }

  }
}










