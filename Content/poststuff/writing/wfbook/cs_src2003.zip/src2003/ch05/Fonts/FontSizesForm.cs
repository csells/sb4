using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Fonts {
  /// <summary>
  /// Summary description for FontSizes.
  /// </summary>
  public class FontSizesForm : System.Windows.Forms.Form {
    private System.Windows.Forms.ListBox listBox1;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public FontSizesForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.listBox1 = new System.Windows.Forms.ListBox();
      this.SuspendLayout();
      // 
      // listBox1
      // 
      this.listBox1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.listBox1.IntegralHeight = false;
      this.listBox1.ItemHeight = 21;
      this.listBox1.Name = "listBox1";
      this.listBox1.Size = new System.Drawing.Size(560, 182);
      this.listBox1.TabIndex = 0;
      // 
      // FontSizesForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(12, 22);
      this.ClientSize = new System.Drawing.Size(560, 182);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.listBox1});
      this.Font = new System.Drawing.Font("Courier New", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Name = "FontSizesForm";
      this.Text = "Font Sizes";
      this.Load += new System.EventHandler(this.FontSizes_Load);
      this.ResumeLayout(false);

    }
		#endregion

    float GetPixelsFromPoints(float points, float dpi) {
      return (dpi * points)/72f;
    }

    float GetInchesFromPoints(float points, float dpi) {
      return GetPixelsFromPoints(points, dpi)/dpi;
    }

    float GetPixelsFromDesignUnits(float designUnits, Font font, float dpi) {
      float scale = GetPixelsFromPoints(font.Size, dpi)/font.FontFamily.GetEmHeight(font.Style);
      return designUnits * scale;
    }

    float GetPointsFromPixels(float pixels, float dpi) {
      return (pixels*72f)/dpi;
    }

    private void FontSizes_Load(object sender, System.EventArgs e) {
      using( Graphics g = this.CreateGraphics() ) {

      // A 12-point font will be 16 pixels high on a 96 dpi monitor
      //        float dpi = g.DpiY;
      //        float points = 12.0f;
      //        float pixels = (points * dpi)/72f;
      //        MessageBox.Show(pixels.ToString());

      // A 12-point font will be 16 pixels high on a 96 dpi monitor
      //        float points = 12.0f;
      //        float designUnits = 2048;
      //        float pixels = 


        listBox1.Items.Add(string.Format("Font.Name=                       {0}", this.Font.Name));
        listBox1.Items.Add(string.Format("Font.FontFamly.Name=             {0}", this.Font.FontFamily.Name));
        listBox1.Items.Add(string.Format("Font.Size=                       {0} {1}s (specified Unit)", this.Font.Size, this.Font.Unit.ToString()));
        listBox1.Items.Add(string.Format("Font.Height=                     {0} Pixels", this.Font.Height));
        listBox1.Items.Add(string.Format("Font.GetHeight=                  {0} Pixels", this.Font.GetHeight(g)));
        listBox1.Items.Add(string.Format("Font.SizeInPoints=               {0} Points", this.Font.SizeInPoints.ToString()));
        listBox1.Items.Add(string.Format("GetPixels(Font.SizeInPoints)=    {0} Pixels", GetPixelsFromPoints(this.Font.SizeInPoints, g.DpiY)));
//        listBox1.Items.Add(string.Format("GetInches(Font.SizeInPoints)=    {0} Inches", GetInchesFromPoints(this.Font.SizeInPoints, g.DpiY)));
        listBox1.Items.Add(string.Format("Font.FontFamily.GetEmHeight=     {0} Design Units", this.Font.FontFamily.GetEmHeight(FontStyle.Regular)));
        listBox1.Items.Add(string.Format("GetPixels(GetEmHeight)=          {0} Pixels", GetPixelsFromDesignUnits(this.Font.FontFamily.GetEmHeight(this.Font.Style), this.Font, g.DpiY)));
        listBox1.Items.Add(string.Format("Font.FontFamily.GetLineSpacing=  {0} Design Units", this.Font.FontFamily.GetLineSpacing(FontStyle.Regular)));
        listBox1.Items.Add(string.Format("GetPixels(GetLineSpacing)=       {0} Pixels", GetPixelsFromDesignUnits(this.Font.FontFamily.GetLineSpacing(this.Font.Style), this.Font, g.DpiY)));
        listBox1.Items.Add(string.Format("Font.FontFamily.GetCellAscent=   {0} Design Units", this.Font.FontFamily.GetCellAscent(FontStyle.Regular)));
        listBox1.Items.Add(string.Format("GetPixels(GetCellAscent)=        {0} Pixels", GetPixelsFromDesignUnits(this.Font.FontFamily.GetCellAscent(this.Font.Style), this.Font, g.DpiY)));
        listBox1.Items.Add(string.Format("Font.FontFamily.GetCellDescent=  {0} Design Units", this.Font.FontFamily.GetCellDescent(FontStyle.Regular)));
        listBox1.Items.Add(string.Format("GetPixels(GetCellDescent)=       {0} Pixels", GetPixelsFromDesignUnits(this.Font.FontFamily.GetCellDescent(this.Font.Style), this.Font, g.DpiY)));
        listBox1.Items.Add(string.Format("Padding=                         {0} Design Units", this.Font.FontFamily.GetLineSpacing(FontStyle.Regular) - (this.Font.FontFamily.GetCellAscent(FontStyle.Regular) + this.Font.FontFamily.GetCellDescent(FontStyle.Regular))));
        listBox1.Items.Add(string.Format("GetPixels(Padding)=              {0} Pixels", GetPixelsFromDesignUnits(this.Font.FontFamily.GetLineSpacing(FontStyle.Regular) - (this.Font.FontFamily.GetCellAscent(FontStyle.Regular) + this.Font.FontFamily.GetCellDescent(FontStyle.Regular)), this.Font, g.DpiY)));
      }
    }

  }

}
