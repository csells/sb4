using System;
using System.Drawing.Text;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Fonts {
  /// <summary>
  /// Summary description for TextContrastForm.
  /// </summary>
  public class TextContrastForm : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public TextContrastForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      // 
      // TextContrastForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.BackColor = System.Drawing.Color.White;
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Name = "TextContrastForm";
      this.Text = "Text Contrasts";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.TextContrastForm_Paint);

    }
		#endregion

    void TextContrastForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      string s = @"Howdie, Partner";

      StringFormat format = new StringFormat();
      format.FormatFlags = StringFormatFlags.NoWrap;

      float y = 0;
      for( int i = 0; i <= 12; i += 4 ) {
        g.TextContrast = i;
        string line = "Contrast= " + i.ToString() + ": " + s;
        g.DrawString(line, this.Font, Brushes.Black, 0, y, format);
        y += this.Font.GetHeight(g) + 10;
      }

    }
  }
}
