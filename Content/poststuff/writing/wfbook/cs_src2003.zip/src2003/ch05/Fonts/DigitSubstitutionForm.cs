using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Globalization;

namespace Fonts {
  /// <summary>
  /// Summary description for DigitSubstitutionForm.
  /// </summary>
  public class DigitSubstitutionForm : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public DigitSubstitutionForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      // 
      // DigitSubstitutionForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(9, 22);
      this.BackColor = System.Drawing.Color.White;
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Name = "DigitSubstitutionForm";
      this.Text = "Digit Substitution";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.DigitSubstitutionForm_Paint);

    }
		#endregion

    void DigitSubstitutionForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      string digits = @"0 1 2 3 4 5 6 7 8 9 0";

      StringDigitSubstitute[] methods = { StringDigitSubstitute.None,
                                          StringDigitSubstitute.National,
                                          StringDigitSubstitute.Traditional,
                                          StringDigitSubstitute.User,
      };

      float y = 0;
      CultureInfo culture = new CultureInfo("th-TH"); // Thailand
      StringFormat format = new StringFormat();

      foreach( StringDigitSubstitute method in methods ) {
        format.SetDigitSubstitution(culture.LCID, method);
        g.DrawString(method.ToString() + ": " + digits, this.Font, Brushes.Black, 0, y, format);
        y += this.Font.GetHeight(g);
      }

    }
  }
}
