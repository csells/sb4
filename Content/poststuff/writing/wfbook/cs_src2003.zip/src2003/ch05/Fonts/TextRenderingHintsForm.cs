using System;
using System.Drawing.Text;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Fonts {
  /// <summary>
  /// Summary description for TextRenderingHintsForms.
  /// </summary>
  public class TextRenderingHintsForm : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public TextRenderingHintsForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      // 
      // TextRenderingHintsForms
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(9, 22);
      this.BackColor = System.Drawing.Color.White;
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Name = "TextRenderingHintsForms";
      this.Text = "Text Rendering Hints";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.TextRenderingHintsForms_Paint);

    }
		#endregion

    void TextRenderingHintsForms_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      string s = @"Greetings, Planet Earth";

      TextRenderingHint[] hints = { TextRenderingHint.SystemDefault,
                                    TextRenderingHint.SingleBitPerPixel,
                                    TextRenderingHint.SingleBitPerPixelGridFit,
                                    TextRenderingHint.AntiAlias,
                                    TextRenderingHint.AntiAliasGridFit,
                                    TextRenderingHint.ClearTypeGridFit,
      };

      float y = 0;

      StringFormat format = new StringFormat();
      format.FormatFlags = StringFormatFlags.NoWrap;

      foreach( TextRenderingHint hint in hints ) {
        g.TextRenderingHint = hint;
        string line = hint.ToString() + ": " + s;
        g.DrawString(line, this.Font, Brushes.Black, 0, y, format);
        y += this.Font.GetHeight(g) + 10;
      }

    }
  }
}
