using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.IO.IsolatedStorage;
using System.Text;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Soap;
using System.Runtime.Serialization.Formatters.Binary;

namespace Serialization {
  class Test {
    static void DoSerialize1() {
      string s = "Wahoo!";
      int n = 452;
      using( Stream stream = new MemoryStream() ) {
        // Write to the stream
        byte[] bytes1 = UnicodeEncoding.Unicode.GetBytes(s);
        byte[] bytes2 = BitConverter.GetBytes(n);
        stream.Write(bytes1, 0, bytes1.Length);
        stream.Write(bytes2, 0, bytes2.Length);

        // Reset the stream to the beginning
        stream.Seek(0, SeekOrigin.Begin);

        // Read from the stream
        byte[] bytes3 = new byte[stream.Length - 4];
        byte[] bytes4 = new byte[4];
        stream.Read(bytes3, 0, bytes3.Length);
        stream.Read(bytes4, 0, bytes4.Length);

        // Do something with the data
        MessageBox.Show(UnicodeEncoding.Unicode.GetString(bytes3) + " " + BitConverter.ToInt32(bytes4, 0));
      }
    }

    static void DoSerialize2() {
      string s = "Wahoo!";
      int n = 452;
      using( Stream stream = new MemoryStream() ) {

        // Write to the stream
        StreamWriter writer = new StreamWriter(stream);
        writer.WriteLine(s);
        writer.WriteLine(n);
        writer.Flush(); // Flush the buffer

        // Reset the stream to the beginning
        stream.Seek(0, SeekOrigin.Begin);

        // Read from the stream
        StreamReader reader = new StreamReader(stream);
        string s2 = reader.ReadLine();
        int n2 = int.Parse(reader.ReadLine());

        // Do something with the data
        MessageBox.Show(s2 + " " + n2);
      }
    }

    static void DoSerialize3() {
      string s = "Wahoo!";
      int n = 452;
      using( Stream stream = new MemoryStream() ) {

        // Write to the stream
        BinaryWriter writer = new BinaryWriter(stream);
        writer.Write(s);
        writer.Write(n);
        writer.Flush(); // Flush the buffer

        // Reset the stream to the beginning
        stream.Seek(0, SeekOrigin.Begin);

        // Read from the stream
        BinaryReader reader = new BinaryReader(stream);
        string s2 = reader.ReadString();
        int n2 = reader.ReadInt32();

        // Do something with the data
        MessageBox.Show(s2 + " " + n2);
      }
    }

    //    [SerializableAttribute]
    //    class MyData : IDeserializationCallback {
    //      string s = "Wahoo!";
    //      [NonSerialized] int n = 6;
    //
    //      public string String {
    //        get { return s; }
    //        set { value = s; n = s.Length; }
    //      }
    //
    //      public int Length {
    //        get { return n; }
    //      }
    //
    //  #region Implementation of IDeserializationCallback
    //      public void OnDeserialization(object sender) {
    //        // Cache the string's length
    //        n = s.Length;
    //      }
    //  #endregion
    //    }

    //    [SerializableAttribute]
    //      class MyData : ISerializable {
    //      string s = "Wahoo!";
    //      int n = 6;
    //
    //      public string String {
    //        get { return s; }
    //        set { value = s; n = s.Length; }
    //      }
    //
    //      public int Length {
    //        get { return n; }
    //      }
    //
    //  #region Implementation of ISerializable
    //      public MyData() {}
    //      public MyData(
    //        SerializationInfo info, StreamingContext context) {
    //        // Get value from name/value pairs
    //        s = info.GetString("MyString");
    //
    //        // Cache the string's length
    //        n = s.Length;
    //      }
    //
    //      public void GetObjectData(
    //        SerializationInfo info, StreamingContext context) {
    //        // Add value to name/value pairs
    //        info.AddValue("MyString", s);
    //      }
    //  #endregion
    //
    //    }

    [SerializableAttribute]
      class MyData : ISerializable {
      string s = "Wahoo!";
      int n = 6;
      ArrayList oldStrings = new ArrayList(); // v2.0 addition
      static string currentVersion = "2.0";

      public string String {
        get { return s; }
        set {
          oldStrings.Add(s);
          s = value;
          n = s.Length;
        }
      }

      public int Length {
        get { return n; }
      }

      public ArrayList OldStrings {
        get { return oldStrings; }
      }

      public MyData() {}

#region Implementation of ISerializable
      public MyData(
        SerializationInfo info, StreamingContext context) {
        // Read the data based on the version
        string streamVersion = info.GetString("Version");
        switch( streamVersion ) {
          case "1.0":
            s = info.GetString("MyString");
            n = s.Length;
            break;

          case "2.0":
            s = info.GetString("MyString");
            n = s.Length;
            oldStrings =
              (ArrayList)info.GetValue("OldStrings", typeof(ArrayList));
            break;
        }
      }

      public void GetObjectData(
        SerializationInfo info, StreamingContext context) {
        // Tag the data with a version
        info.AddValue("Version", currentVersion);
        info.AddValue("MyString", s);
        info.AddValue("OldStrings", oldStrings);
      }
#endregion

    }

    static void DoSerialize4() {
      MyData data = new MyData();
      data.String = "Yahoo!";
      data.String = "Yodal!";
      data.String = "Local!";
      data.String = "Stop yelling!";
      using( Stream stream =
               new FileStream(@"c:\temp\mydata.xml", FileMode.Create) ) {
        // Write to the stream
        IFormatter formatter = new SoapFormatter();
        formatter.Serialize(stream, data);

        // Reset the stream to the beginning
        stream.Seek(0, SeekOrigin.Begin);

        // Read from the stream
        MyData data2 = (MyData)formatter.Deserialize(stream);

        // Do something with the data
        MessageBox.Show(data2.String + " " + data2.Length);
        foreach( string oldString in data2.OldStrings ) {
          MessageBox.Show(oldString, "Old String");
        }
      }
    }

    [STAThread]
    static void Main() {
      DoSerialize4();
    }

  }
}
