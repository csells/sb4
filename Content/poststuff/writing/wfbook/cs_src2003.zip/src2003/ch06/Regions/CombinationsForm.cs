using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Regions {
  /// <summary>
  /// Summary description for CombinationsForm.
  /// </summary>
  public class CombinationsForm : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public CombinationsForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      // 
      // CombinationsForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(12, 28);
      this.BackColor = System.Drawing.Color.White;
      this.ClientSize = new System.Drawing.Size(544, 118);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Name = "CombinationsForm";
      this.Text = "Region Combinations";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.CombinationsForm_Paint);

    }
		#endregion

    void CombinationsForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      float width = this.ClientSize.Width/5;
      float height = this.ClientSize.Height;
      RectangleF rect = new RectangleF(0, 0, width, height);
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Center;

      using( GraphicsPath path1 = new GraphicsPath() )
      using( GraphicsPath path2 = new GraphicsPath() ) {
        // Two overlapping ellipses
        RectangleF path1Rect = new RectangleF(0, 0, width*2f/3f, height);
        RectangleF path2Rect = path1Rect;
        path2Rect.Offset(width*1f/3f, 0);
        path1.AddEllipse(path1Rect);
        path2.AddEllipse(path2Rect);

        // Union
        using( Region region = new Region(path1) ) {
          region.Union(path2);
          g.FillRegion(Brushes.Red, region);
        }
        g.DrawString("Union", this.Font, Brushes.Black, rect, format);
        g.DrawRectangle(Pens.Black, rect.X, rect.Y, rect.Width, rect.Height);
        g.TranslateTransform(width, 0);

        // Intersect the easy way
        using( Region region = new Region(path1) ) {
          region.Intersect(path2);
          g.FillRegion(Brushes.Red, region);
        }

        // Intersect the hard way
//        using( Region region = new Region() ) {
//          // Defaults to region.IsInfinit(g) == true
//          if( !region.IsEmpty(g) ) region.MakeEmpty();
//          region.Union(path1); // Add a path
//          region.Intersect(path2); // Intersect with another path
//          g.FillRegion(Brushes.Red, region);
//        }

        g.DrawString("Intersect", this.Font, Brushes.Black, rect, format);
        g.DrawRectangle(Pens.Black, rect.X, rect.Y, rect.Width, rect.Height);
        g.TranslateTransform(width, 0);

        // Exclude
        using( Region region = new Region(path1) ) {
          region.Exclude(path2);
          g.FillRegion(Brushes.Red, region);
        }
        g.DrawString("Exclude", this.Font, Brushes.Black, rect, format);
        g.DrawRectangle(Pens.Black, rect.X, rect.Y, rect.Width, rect.Height);
        g.TranslateTransform(width, 0);

        // Complement
        using( Region region = new Region(path1) ) {
          region.Complement(path2);
          g.FillRegion(Brushes.Red, region);
        }
        g.DrawString("Comple-\nment", this.Font, Brushes.Black, rect, format);
        g.DrawRectangle(Pens.Black, rect.X, rect.Y, rect.Width, rect.Height);
        g.TranslateTransform(width, 0);

        // Xor
        using( Region region = new Region(path1) ) {
          region.Xor(path2);
          g.FillRegion(Brushes.Red, region);
        }
        g.DrawString("Xor", this.Font, Brushes.Black, rect, format);
        g.DrawRectangle(Pens.Black, rect.X, rect.Y, rect.Width, rect.Height);
        g.TranslateTransform(width, 0);

      }



    }

  }
}
















