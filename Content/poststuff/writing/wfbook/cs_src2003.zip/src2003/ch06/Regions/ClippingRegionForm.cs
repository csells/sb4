using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Regions {
  /// <summary>
  /// Summary description for Form1.
  /// </summary>
  public class ClippingRegionForm : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public ClippingRegionForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
      this.SetStyle(ControlStyles.ResizeRedraw, true);
      this.SetStyle(ControlStyles.DoubleBuffer, true);
      this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      // 
      // ClippingRegionForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(12, 28);
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Name = "ClippingRegionForm";
      this.Text = "Clipping Regions";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);

    }
		#endregion

    Random rnd = new Random();

    void Form1_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Center;

      using( GraphicsPath path = new GraphicsPath() ) {
        path.AddEllipse(this.ClientRectangle);
        using( Region region = new Region(path) ) {
          // Frame clipping region
          g.DrawPath(Pens.Red, path);

          // Don't draw outside the ellipse region
          g.Clip = region;

          // Draw a rectangle
          Rectangle rect = this.ClientRectangle;
          rect.Offset(10, 10);
          rect.Width -= 20;
          rect.Height -= 20;
          g.FillRectangle(Brushes.Black, rect);
          g.DrawString("Rectangle clipped to Ellipse", this.Font, Brushes.White, rect, format);
        }
      }

    }

  }
}












