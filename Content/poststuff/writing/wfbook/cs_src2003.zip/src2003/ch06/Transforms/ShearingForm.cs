using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Transforms {
  /// <summary>
  /// Summary description for ShearingForm.
  /// </summary>
  public class ShearingForm : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public ShearingForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      // 
      // ShearingForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(15, 37);
      this.BackColor = System.Drawing.Color.White;
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Name = "ShearingForm";
      this.Text = "Shearing";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.ShearingForm_Paint);

    }
		#endregion

    void Foo(Graphics g) {
      Matrix matrix = new Matrix();
      matrix.Translate(10, 20); // Move orgin to (10, 20)
      matrix.Scale(2, 3); // Scale x/width and y/width by 2 and 3

      matrix.Reset();
      matrix.Scale(2, 3); // Scale x/width and y/width by 2 and 3
      matrix.Translate(10, 20, MatrixOrder.Append); // Move orgin to (20, 60)

      g.Transform = matrix;
      g.DrawString("(0, 0)", this.Font, Brushes.Black, 0, 0);

    }

    private void ShearingForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e) {
      Graphics g = e.Graphics;
      float width = 200; //g.MeasureString("Shear(.0, 0)", this.Font).Width;
      float height = 50; //this.Font.GetHeight(g);
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Center;
      RectangleF rect = new RectangleF(0, 0, width, height);
      Matrix matrix;

      matrix = new Matrix();
      matrix.Translate(0, 0);
      matrix.Shear(0f, 0f);
      g.Transform = matrix;
      g.DrawString("Shear(0, 0)", this.Font, Brushes.Black, rect, format);
      g.DrawRectangle(Pens.Black, rect.X, rect.Y, rect.Width, rect.Height);

      matrix = new Matrix();
      matrix.Shear(.5f, 0f); // Shear in x dimension only
      matrix.Translate(width, 0);
      g.Transform = matrix;
      g.DrawString("Shear(.5, 0)", this.Font, Brushes.Black, rect, format);
      g.DrawRectangle(Pens.Black, rect.X, rect.Y, rect.Width, rect.Height);

      matrix = new Matrix();
      matrix.Translate(2 * width, 0);
      matrix.Shear(1f, 0f);
      g.Transform = matrix;
      g.DrawString("Shear(1, 0)", this.Font, Brushes.Black, rect, format);
      g.DrawRectangle(Pens.Black, rect.X, rect.Y, rect.Width, rect.Height);
    }

  }
}










