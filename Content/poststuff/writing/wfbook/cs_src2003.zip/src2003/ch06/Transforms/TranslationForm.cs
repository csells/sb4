using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Transforms {
  /// <summary>
  /// Summary description for TranslationForm.
  /// </summary>
  public class TranslationForm : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public TranslationForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      // 
      // TranslationForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Name = "TranslationForm";
      this.Text = "Translation";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.TranslationForm_Paint);

    }
		#endregion

    void DrawLabeledRect(Graphics g, string label) {
      // Always draw at (0, 0) and let the client
      // set the position using a transform
      RectangleF rect = new RectangleF(0, 0, 125, 125);
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Center;
      g.FillRectangle(Brushes.White, rect);
      g.DrawRectangle(Pens.Black, rect.X, rect.Y, rect.Width, rect.Height);
      g.DrawString(label, this.Font, Brushes.Black, rect, format);
    }

    void TranslationForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;

      // Origin at (0, 0)
      DrawLabeledRect(g, "Translate(0, 0)");

      // Move origin to (150, 150)
      Matrix matrix = new Matrix();
      matrix.Translate(150, 150);
      g.Transform = matrix;
      DrawLabeledRect(g, "Translate(150, 150)");

    }

  }
}
