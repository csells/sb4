using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Transforms {
  /// <summary>
  /// Summary description for RotateForm.
  /// </summary>
  public class RotateForm : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public RotateForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      // 
      // RotateForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(8, 19);
      this.ClientSize = new System.Drawing.Size(280, 214);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Name = "RotateForm";
      this.Text = "Rotation";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.RotateForm_Paint);

    }
		#endregion

    void RotateForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      int x = 25;
      int y = 25;
      int width = 250; //this.ClientSize.Width;
      int height = 250; //this.ClientSize.Height;
      float textWidth = g.MeasureString("00", this.Font).Width;
      float length = Math.Min(width - x, height - x) - textWidth;
      RectangleF textRect = new RectangleF(x + length, y - this.Font.GetHeight(g)/2, length, textWidth);
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Near;
      format.LineAlignment = StringAlignment.Center;

      for( int i = 0; i <= 90; i += 10 ) {
        Matrix matrix = new Matrix();
        matrix.RotateAt(i, new PointF(x, y));
        g.Transform = matrix;
        g.DrawLine(Pens.Black, x, y, x + length, y);
        g.DrawString(i.ToString(), this.Font, Brushes.Black, textRect, format);
      }

    }

  }
}





