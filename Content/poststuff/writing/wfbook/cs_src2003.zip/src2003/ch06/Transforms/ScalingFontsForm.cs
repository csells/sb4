using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Transforms {
  /// <summary>
  /// Summary description for ScalingFontsForm.
  /// </summary>
  public class ScalingFontsForm : System.Windows.Forms.Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public ScalingFontsForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      // 
      // ScalingFontsForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(8, 19);
      this.ClientSize = new System.Drawing.Size(512, 70);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.Name = "ScalingFontsForm";
      this.Text = "Scaling Fonts";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.ScalingFontsForm_Paint);

    }
		#endregion

    void ScalingFontsForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      int x = 0;
      int y = 0;
      int width = this.ClientRectangle.Width/4;
      int height = this.ClientRectangle.Height;
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Center;

      Matrix matrix = new Matrix();

      g.ResetTransform();
      g.DrawRectangle(Pens.Black, x, y, width, height);
      matrix.Reset();
      matrix.Scale(1, 1);
      g.Transform = matrix;
      g.DrawString("Scale(1, 1)", this.Font, Brushes.Black, new Rectangle(x, y, width, height), format);
      x = (x > this.ClientRectangle.Width - 2*width ? 0 : x + width);
      y = (x == 0 ? y + height : y);

      g.ResetTransform();
      g.DrawRectangle(Pens.Black, x, y, width, height);
      matrix.Reset();
      matrix.Scale(1, 3);
      g.Transform = matrix;
      g.DrawString("Scale(1, 3)", this.Font, Brushes.Black, new RectangleF(x, y/3f, width, height/3f), format);
      x = (x > this.ClientRectangle.Width - 2*width ? 0 : x + width);
      y = (x == 0 ? y + height : y);

      g.ResetTransform();
      g.DrawRectangle(Pens.Black, x, y, width, height);
      matrix.Reset();
      matrix.Scale(3, 1);
      g.Transform = matrix;
      g.DrawString("Scale(3, 1)", this.Font, Brushes.Black, new RectangleF(x/3f, y, width/3f, height), format);
      x = (x > this.ClientRectangle.Width - 2*width ? 0 : x + width);
      y = (x == 0 ? y + height : y);

      g.ResetTransform();
      g.DrawRectangle(Pens.Black, x, y, width, height);
      matrix.Reset();
      //matrix.Translate(width, height);
      matrix.Scale(-1, -1);
      g.Transform = matrix;
      g.DrawString("Scale(-1, -1)", this.Font, Brushes.Black,
        new RectangleF(-x - width, -y - height, width, height), format);
      //g.DrawString("Scale(-1, -1)", this.Font, Brushes.Black, new RectangleF(-x, -y, width, height), format);
      x = (x > this.ClientRectangle.Width - 2*width ? 0 : x + width);
      y = (x == 0 ? y + height : y);

    }

  }
}
