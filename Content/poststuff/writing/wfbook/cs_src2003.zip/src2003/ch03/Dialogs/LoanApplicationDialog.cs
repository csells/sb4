using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;

namespace Dialogs {
  /// <summary>
  /// Summary description for ApplicationDialog.
  /// </summary>
  public class LoanApplicationDialog : System.Windows.Forms.Form {
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.TextBox applicantNameTextBox;
    private System.Windows.Forms.Button okButton;
    private System.Windows.Forms.Button cancelButton;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.TextBox applicantPhoneNoTextBox;
    private System.Windows.Forms.TextBox applicantLoanAmountTextBox;
    private System.Windows.Forms.ToolTip toolTip1;
    private System.Windows.Forms.ErrorProvider infoProvider;
    private System.Windows.Forms.ErrorProvider errorProvider;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.HelpProvider helpProvider1;
    private System.ComponentModel.IContainer components;

    public LoanApplicationDialog() {
      // Required for Windows Form Designer support
      InitializeComponent();

      // Constructor code after InitializeComponent call
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(LoanApplicationDialog));
      this.label1 = new System.Windows.Forms.Label();
      this.applicantNameTextBox = new System.Windows.Forms.TextBox();
      this.okButton = new System.Windows.Forms.Button();
      this.cancelButton = new System.Windows.Forms.Button();
      this.applicantPhoneNoTextBox = new System.Windows.Forms.TextBox();
      this.label2 = new System.Windows.Forms.Label();
      this.applicantLoanAmountTextBox = new System.Windows.Forms.TextBox();
      this.label3 = new System.Windows.Forms.Label();
      this.errorProvider = new System.Windows.Forms.ErrorProvider();
      this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
      this.infoProvider = new System.Windows.Forms.ErrorProvider();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.helpProvider1 = new System.Windows.Forms.HelpProvider();
      this.groupBox1.SuspendLayout();
      this.SuspendLayout();
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(16, 24);
      this.label1.Name = "label1";
      this.label1.TabIndex = 0;
      this.label1.Text = "Applicant Name";
      this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // applicantNameTextBox
      // 
      this.applicantNameTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right)));
      this.applicantNameTextBox.Location = new System.Drawing.Point(128, 24);
      this.applicantNameTextBox.Name = "applicantNameTextBox";
      this.applicantNameTextBox.Size = new System.Drawing.Size(168, 20);
      this.applicantNameTextBox.TabIndex = 1;
      this.applicantNameTextBox.Text = "";
      this.toolTip1.SetToolTip(this.applicantNameTextBox, "Please enter a name");
      this.applicantNameTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.applicantNameTextBox_Validating);
      this.applicantNameTextBox.Validated += new System.EventHandler(this.applicantNameTextBox_Validated);
      // 
      // okButton
      // 
      this.okButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.okButton.DialogResult = System.Windows.Forms.DialogResult.OK;
      this.okButton.Location = new System.Drawing.Point(156, 148);
      this.okButton.Name = "okButton";
      this.okButton.TabIndex = 2;
      this.okButton.Text = "OK";
      this.okButton.Click += new System.EventHandler(this.okButton_Click);
      // 
      // cancelButton
      // 
      this.cancelButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cancelButton.CausesValidation = false;
      this.cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
      this.cancelButton.Location = new System.Drawing.Point(244, 148);
      this.cancelButton.Name = "cancelButton";
      this.cancelButton.TabIndex = 2;
      this.cancelButton.Text = "Cancel";
      this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
      // 
      // applicantPhoneNoTextBox
      // 
      this.applicantPhoneNoTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right)));
      this.applicantPhoneNoTextBox.Location = new System.Drawing.Point(128, 56);
      this.applicantPhoneNoTextBox.Name = "applicantPhoneNoTextBox";
      this.applicantPhoneNoTextBox.Size = new System.Drawing.Size(168, 20);
      this.applicantPhoneNoTextBox.TabIndex = 1;
      this.applicantPhoneNoTextBox.Text = "";
      this.toolTip1.SetToolTip(this.applicantPhoneNoTextBox, "Please enter a phone number: (xxx) xxx-xxxx");
      this.applicantPhoneNoTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.applicantPhoneNoTextBox_Validating);
      // 
      // label2
      // 
      this.label2.Location = new System.Drawing.Point(16, 56);
      this.label2.Name = "label2";
      this.label2.TabIndex = 2;
      this.label2.Text = "Applicant Phone #";
      this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // applicantLoanAmountTextBox
      // 
      this.applicantLoanAmountTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right)));
      this.applicantLoanAmountTextBox.Location = new System.Drawing.Point(128, 88);
      this.applicantLoanAmountTextBox.Name = "applicantLoanAmountTextBox";
      this.applicantLoanAmountTextBox.Size = new System.Drawing.Size(168, 20);
      this.applicantLoanAmountTextBox.TabIndex = 1;
      this.applicantLoanAmountTextBox.Text = "";
      this.toolTip1.SetToolTip(this.applicantLoanAmountTextBox, "Please enter a loan amount");
      this.applicantLoanAmountTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.applicantLoanAmountTextBox_Validating);
      // 
      // label3
      // 
      this.label3.Location = new System.Drawing.Point(16, 88);
      this.label3.Name = "label3";
      this.label3.TabIndex = 0;
      this.label3.Text = "Loan Amount";
      this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // errorProvider
      // 
      this.errorProvider.ContainerControl = this;
      // 
      // infoProvider
      // 
      this.infoProvider.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
      this.infoProvider.ContainerControl = this;
      this.infoProvider.DataMember = "";
      this.infoProvider.Icon = ((System.Drawing.Icon)(resources.GetObject("infoProvider.Icon")));
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.applicantLoanAmountTextBox);
      this.groupBox1.Controls.Add(this.label1);
      this.groupBox1.Controls.Add(this.applicantPhoneNoTextBox);
      this.groupBox1.Controls.Add(this.applicantNameTextBox);
      this.groupBox1.Controls.Add(this.label2);
      this.groupBox1.Controls.Add(this.label3);
      this.groupBox1.Location = new System.Drawing.Point(8, 8);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(320, 128);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Applicant Information";
      // 
      // helpProvider1
      // 
      this.helpProvider1.HelpNamespace = "dialogs.chm";
      // 
      // LoanApplicationDialog
      // 
      this.AcceptButton = this.okButton;
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.CancelButton = this.cancelButton;
      this.ClientSize = new System.Drawing.Size(336, 190);
      this.Controls.Add(this.groupBox1);
      this.Controls.Add(this.okButton);
      this.Controls.Add(this.cancelButton);
      this.HelpButton = true;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "LoanApplicationDialog";
      this.ShowInTaskbar = false;
      this.Text = "Loan Application";
      this.Load += new System.EventHandler(this.LoanApplicationDialog_Load);
      this.HelpRequested += new System.Windows.Forms.HelpEventHandler(this.LoanApplicationDialog_HelpRequested);
      this.groupBox1.ResumeLayout(false);
      this.ResumeLayout(false);

    }
		#endregion

    // Retrieve all controls and all child controls and etc.
    // Make sure to send controls back at lowest depth first
    // so that most child controls are checked for things before
    // container controls, e.g. a TextBox is checked before a
    // GroupBox control
    Control[] GetAllControls() {
      ArrayList list = new ArrayList();
      GetAllControls(Controls, list);
      return (Control[])list.ToArray(typeof(Control));
    }
    void GetAllControls(Control.ControlCollection controls, ArrayList list) {
      foreach(Control control in controls) {
        if(control.HasChildren) GetAllControls(control.Controls, list);
        list.Add(control);
      }
    }

    Rectangle GetFormRelativeBounds(Control control) {
      // Sum the location X,Y values of this control and
      // each and every parent excluding the form itself
      if( control == null ) return control.Bounds;
      Control current = control;
      int x = 0;
      int y = 0;
      while(current != control.FindForm()) {
        x += current.Location.X;
        y += current.Location.Y;
        current = current.Parent;
      }
      // Return form-relative control bounds
      return new Rectangle(x, y, control.Bounds.Width, control.Bounds.Height);
    }
    
    void okButton_Click(object sender, EventArgs e) {
      //  this.DialogResult = DialogResult.OK;
      //  this.Close();

      // Validate each control manually
      foreach( Control control in GetAllControls() ) {
        // Validate this control
        control.Focus();
        if( !this.Validate() ) {
          this.DialogResult = DialogResult.None;
          break;
        }
      }
    }

    void cancelButton_Click(object sender, EventArgs e) {
      //  this.DialogResult = DialogResult.Cancel;
      //  this.Close();
    }

    void LoanApplicationDialog_Load(object sender, EventArgs e) {
      // Use tooltips to populate the "information provider"
      //      foreach( Control control in this.Controls ) {
      //        string toolTip = toolTip1.GetToolTip(control);
      //        if( toolTip.Length == 0 ) continue;
      //        infoProvider.SetError(control, toolTip);
      //      }

      if( this.Modal ) {
        // Show as a fixed-sized modal dialog
        this.FormBorderStyle = FormBorderStyle.FixedDialog;
      }
      else {
        // Show as a sizeable modeless dialog
        this.FormBorderStyle = FormBorderStyle.Sizable;
      }
    }

    void applicantNameTextBox_Validating(object sender, CancelEventArgs e) {
      string toolTip = toolTip1.GetToolTip((Control)sender);
      if( ((TextBox)sender).Text.Length == 0 ) {
        // Show the error when there is no text in the text box
        errorProvider.SetError((Control)sender, toolTip);
        //        infoProvider.SetError((Control)sender, null);
        e.Cancel = true;
      }
      else {
        // Show the info when there is text in the text box
        errorProvider.SetError((Control)sender, null);
        //        infoProvider.SetError((Control)sender, toolTip);
      }
    }

    void applicantNameTextBox_Validated(object sender, EventArgs e) {
      //      MessageBox.Show("Thanks, " + applicantNameTextBox.Text, "Nice Name!");
    }

    void applicantPhoneNoTextBox_Validating(object sender, CancelEventArgs e) {
      Regex re = new Regex(@"^\(\d{3}\) \d{3}-\d{4}$");
      string toolTip = toolTip1.GetToolTip((Control)sender);
      if( !re.IsMatch(((TextBox)sender).Text) ) {
        errorProvider.SetError((Control)sender, toolTip);
        //        infoProvider.SetError((Control)sender, null);
        e.Cancel = true;
      }
      else {
        errorProvider.SetError((Control)sender, null);
        //        infoProvider.SetError((Control)sender, toolTip);
      }
    }

    private void applicantLoanAmountTextBox_Validating(object sender, System.ComponentModel.CancelEventArgs e) {
      string toolTip = toolTip1.GetToolTip((Control)sender);
      if( ((TextBox)sender).Text.Length == 0 ) {
        errorProvider.SetError((Control)sender, toolTip);
        //        infoProvider.SetError((Control)sender, null);
        e.Cancel = true;
      }
      else {
        errorProvider.SetError((Control)sender, null);
        //        infoProvider.SetError((Control)sender, toolTip);
      }
    }

    void LoanApplicationDialog_HelpRequested(object sender, HelpEventArgs e) {
//      // F1
//      if( Control.MouseButtons == MouseButtons.None ) {
//        string subtopic = null;
//        if( this.ActiveControl == this.applicantNameTextBox) {
//          subtopic = "name";
//        }
//        else if( this.ActiveControl == this.applicantPhoneNoTextBox ) {
//          subtopic = "phoneNo";
//        }
//        else if( this.ActiveControl == this.applicantLoanAmountTextBox ) {
//          subtopic = "loanAmount";
//        }
//
//        //Help.ShowHelp(this, Path.GetFullPath("loanApplicationDialog.htm"));
//        Help.ShowHelp(this, "dialogs.chm", "loanApplicationDialog.htm#" + subtopic);
//        e.Handled = true;
//      }
//        // Help button
//      else {
//        // Look for control user clicked on
//        Point pt = this.PointToClient(e.MousePos);
//        foreach( Control control in GetAllControls() ) {
//          if(control == null) return;
//          // Convert control's container-relative bounds to client-relative bounds
//          Rectangle myBounds = GetFormRelativeBounds(control);
//          if(myBounds.Contains(pt) ) {
//            // Show help
//            string help = toolTip1.GetToolTip(control);
//            if( help.Length == 0 ) return;
//            Help.ShowPopup(this, help, e.MousePos);
//            e.Handled = true;
//            break;
//          }
//        }
//      }
    }
    

//    void LoanApplicationDialog_HelpRequested(object sender, HelpEventArgs e) {
//      Control controlNeedingHelp = null;
//      Point pt = this.PointToClient(e.MousePos);
//
//      // If no mouse button being clicked, F1 got us here
//      if( Control.MouseButtons == MouseButtons.None ) {
//        // Show help in upper right corner of active control
//        controlNeedingHelp = this.ActiveControl;
//        pt = ActiveControl.Location;
//      }
//        // Help button got us here
//      else {
//        // Look for control user clicked on
//        foreach( Control control in GetAllControls() ) {
//          if(control == null) return;
//           Convert control's container-relative bounds to client-relative bounds
//          Rectangle myBounds = GetFormRelativeBounds(control);
//          if(myBounds.Contains(pt) ) {
//            controlNeedingHelp = control;
//            break;
//          }
//        }
//      }
//
//      // Show help
//      string help = toolTip1.GetToolTip(controlNeedingHelp);
//      if( help.Length == 0 ) return;
//      Help.ShowPopup(this, help, this.PointToScreen(pt));
//      e.Handled = true;
//    }
    
    public string ApplicantName {
      get {
        return applicantNameTextBox.Text;
      }

      set {
        applicantNameTextBox.Text = value;
      }
    }

  }
}
