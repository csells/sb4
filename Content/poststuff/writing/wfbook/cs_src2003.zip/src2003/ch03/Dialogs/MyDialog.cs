using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Dialogs
{
	/// <summary>
	/// Summary description for MyDialog.
	/// </summary>
	public class MyDialog : System.Windows.Forms.Form
	{
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.Label controlBoxLabel;
    private System.Windows.Forms.Label formBorderStyleLabel;
    private System.Windows.Forms.Label helpButtonLabel;
    private System.Windows.Forms.Label minimizeBoxLabel;
    private System.Windows.Forms.Label maximizeBoxLabel;
    private System.Windows.Forms.Label showInTaskBarLabel;
    private System.Windows.Forms.Label label8;
    private System.Windows.Forms.Label sizeGripStyleLabel;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public MyDialog()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.label1 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.label3 = new System.Windows.Forms.Label();
      this.label4 = new System.Windows.Forms.Label();
      this.label5 = new System.Windows.Forms.Label();
      this.label6 = new System.Windows.Forms.Label();
      this.controlBoxLabel = new System.Windows.Forms.Label();
      this.formBorderStyleLabel = new System.Windows.Forms.Label();
      this.helpButtonLabel = new System.Windows.Forms.Label();
      this.minimizeBoxLabel = new System.Windows.Forms.Label();
      this.maximizeBoxLabel = new System.Windows.Forms.Label();
      this.showInTaskBarLabel = new System.Windows.Forms.Label();
      this.sizeGripStyleLabel = new System.Windows.Forms.Label();
      this.label8 = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(16, 16);
      this.label1.Name = "label1";
      this.label1.TabIndex = 0;
      this.label1.Text = "ControlBox";
      this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // label2
      // 
      this.label2.Location = new System.Drawing.Point(16, 40);
      this.label2.Name = "label2";
      this.label2.TabIndex = 0;
      this.label2.Text = "FormBorderStyle";
      this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // label3
      // 
      this.label3.Location = new System.Drawing.Point(16, 64);
      this.label3.Name = "label3";
      this.label3.TabIndex = 0;
      this.label3.Text = "HelpButton";
      this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // label4
      // 
      this.label4.Location = new System.Drawing.Point(16, 88);
      this.label4.Name = "label4";
      this.label4.TabIndex = 0;
      this.label4.Text = "MinimizeBox";
      this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // label5
      // 
      this.label5.Location = new System.Drawing.Point(16, 112);
      this.label5.Name = "label5";
      this.label5.TabIndex = 0;
      this.label5.Text = "MaximizeBox";
      this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // label6
      // 
      this.label6.Location = new System.Drawing.Point(16, 136);
      this.label6.Name = "label6";
      this.label6.TabIndex = 0;
      this.label6.Text = "ShowInTaskBar";
      this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // controlBoxLabel
      // 
      this.controlBoxLabel.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.controlBoxLabel.Location = new System.Drawing.Point(128, 16);
      this.controlBoxLabel.Name = "controlBoxLabel";
      this.controlBoxLabel.Size = new System.Drawing.Size(104, 23);
      this.controlBoxLabel.TabIndex = 1;
      this.controlBoxLabel.Text = "label7";
      this.controlBoxLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // formBorderStyleLabel
      // 
      this.formBorderStyleLabel.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.formBorderStyleLabel.Location = new System.Drawing.Point(128, 40);
      this.formBorderStyleLabel.Name = "formBorderStyleLabel";
      this.formBorderStyleLabel.Size = new System.Drawing.Size(104, 23);
      this.formBorderStyleLabel.TabIndex = 2;
      this.formBorderStyleLabel.Text = "label8";
      this.formBorderStyleLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // helpButtonLabel
      // 
      this.helpButtonLabel.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.helpButtonLabel.Location = new System.Drawing.Point(128, 64);
      this.helpButtonLabel.Name = "helpButtonLabel";
      this.helpButtonLabel.Size = new System.Drawing.Size(104, 23);
      this.helpButtonLabel.TabIndex = 2;
      this.helpButtonLabel.Text = "label8";
      this.helpButtonLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // minimizeBoxLabel
      // 
      this.minimizeBoxLabel.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.minimizeBoxLabel.Location = new System.Drawing.Point(128, 88);
      this.minimizeBoxLabel.Name = "minimizeBoxLabel";
      this.minimizeBoxLabel.Size = new System.Drawing.Size(104, 23);
      this.minimizeBoxLabel.TabIndex = 2;
      this.minimizeBoxLabel.Text = "label8";
      this.minimizeBoxLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // maximizeBoxLabel
      // 
      this.maximizeBoxLabel.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.maximizeBoxLabel.Location = new System.Drawing.Point(128, 112);
      this.maximizeBoxLabel.Name = "maximizeBoxLabel";
      this.maximizeBoxLabel.Size = new System.Drawing.Size(104, 23);
      this.maximizeBoxLabel.TabIndex = 2;
      this.maximizeBoxLabel.Text = "label8";
      this.maximizeBoxLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // showInTaskBarLabel
      // 
      this.showInTaskBarLabel.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.showInTaskBarLabel.Location = new System.Drawing.Point(128, 136);
      this.showInTaskBarLabel.Name = "showInTaskBarLabel";
      this.showInTaskBarLabel.Size = new System.Drawing.Size(104, 23);
      this.showInTaskBarLabel.TabIndex = 2;
      this.showInTaskBarLabel.Text = "label8";
      this.showInTaskBarLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // sizeGripStyleLabel
      // 
      this.sizeGripStyleLabel.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right);
      this.sizeGripStyleLabel.Location = new System.Drawing.Point(128, 160);
      this.sizeGripStyleLabel.Name = "sizeGripStyleLabel";
      this.sizeGripStyleLabel.Size = new System.Drawing.Size(104, 23);
      this.sizeGripStyleLabel.TabIndex = 2;
      this.sizeGripStyleLabel.Text = "label8";
      this.sizeGripStyleLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // label8
      // 
      this.label8.Location = new System.Drawing.Point(16, 160);
      this.label8.Name = "label8";
      this.label8.TabIndex = 0;
      this.label8.Text = "SizeGripStyle";
      this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // MyDialog
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(248, 190);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.formBorderStyleLabel,
                                                                  this.controlBoxLabel,
                                                                  this.label1,
                                                                  this.label2,
                                                                  this.label3,
                                                                  this.label4,
                                                                  this.label5,
                                                                  this.label6,
                                                                  this.helpButtonLabel,
                                                                  this.minimizeBoxLabel,
                                                                  this.maximizeBoxLabel,
                                                                  this.showInTaskBarLabel,
                                                                  this.sizeGripStyleLabel,
                                                                  this.label8});
      this.Name = "MyDialog";
      this.Text = "MyDialog";
      this.Load += new System.EventHandler(this.MyDialog_Load);
      this.ResumeLayout(false);

    }
		#endregion

    private void MyDialog_Load(object sender, System.EventArgs e) {
      controlBoxLabel.Text = this.ControlBox.ToString();
      formBorderStyleLabel.Text = this.FormBorderStyle.ToString();
      helpButtonLabel.Text = this.HelpButton.ToString();
      maximizeBoxLabel.Text = this.MaximizeBox.ToString();
      minimizeBoxLabel.Text = this.MinimizeBox.ToString();
      showInTaskBarLabel.Text = this.ShowInTaskbar.ToString();
      sizeGripStyleLabel.Text = this.SizeGripStyle.ToString();
    }
	}
}
