using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

public class Form1 : System.Windows.Forms.Form {
  private System.Windows.Forms.Label _timeLabel;
  private TimeWatcherComponent _timeWatcher;
  private System.ComponentModel.IContainer components;

  public Form1() {
    //
    // Required for Windows Form Designer support
    //
    InitializeComponent();

    //
    // TODO: Add any constructor code after InitializeComponent call
    //
  }

  /// <summary>
  /// Clean up any resources being used.
  /// </summary>
  protected override void Dispose( bool disposing ) {
    if( disposing ) {
      if (components != null) {
        components.Dispose();
      }
    }
    base.Dispose( disposing );
  }

		#region Windows Form Designer generated code
  /// <summary>
  /// Required method for Designer support - do not modify
  /// the contents of this method with the code editor.
  /// </summary>
  private void InitializeComponent() {
    this.components = new System.ComponentModel.Container();
    this._timeLabel = new System.Windows.Forms.Label();
    this._timeWatcher = new TimeWatcherComponent(this.components);
    this.SuspendLayout();
    // 
    // _timeLabel
    // 
    this._timeLabel.Dock = System.Windows.Forms.DockStyle.Fill;
    this._timeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
    this._timeLabel.Name = "_timeLabel";
    this._timeLabel.Size = new System.Drawing.Size(304, 70);
    this._timeLabel.TabIndex = 0;
    this._timeLabel.Text = "_timeLabel";
    this._timeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
    // 
    // _timeWatcher
    // 
    this._timeWatcher.Enabled = true;
    this._timeWatcher.TimeChanged += new TimeWatcherComponent.TimeChangedEventHandler(this._timeWatcher_TimeChanged);
    // 
    // Form1
    // 
    this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
    this.ClientSize = new System.Drawing.Size(304, 70);
    this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                this._timeLabel});
    this.Name = "Form1";
    this.Text = "TimeWatcher Test";
    this.ResumeLayout(false);

  }
		#endregion

  /// <summary>
  /// The main entry point for the application.
  /// </summary>
  [STAThread]
  static void Main() {
    Application.Run(new Form1());
  }

  private void _timeWatcher_TimeChanged(object sender, System.EventArgs e) {
    _timeLabel.Text = DateTime.Now.ToString();
  }
}
