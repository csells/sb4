using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using SellsBrothers; // InitialInstanceActivator

namespace SingleInstance {
  /// <summary>
  /// Summary description for Form1.
  /// </summary>
  public class MainForm : Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public MainForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      // 
      // MainForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.IsMdiContainer = true;
      this.Name = "MainForm";
      this.Text = "SingleInstanceApp";

    }
		#endregion

    // Make main form accessible from second instance event handler
    static MainForm mainForm = new MainForm();

    [STAThread]
    static void Main(string[] args) {
      // Check for initial instance
      OtherInstanceCallback callback =
        new OtherInstanceCallback(OnOtherInstance);
      if( InitialInstanceActivator.Activate(mainForm, callback, args) ) {
        return;
      }

      // Open file from command line
      if( args.Length == 1 ) mainForm.OpenFile(args[0]);

      // Show main form
      Application.Run(mainForm);
    }

    // Called from other instances
    static void OnOtherInstance(string[] args) {
      // Open file from command line
      if( args.Length == 1 ) mainForm.OpenFile(args[0]);
    }

    public void OpenFile(string fileName) {
      MdiChild form = new MdiChild();
      form.OpenFile(fileName);
      form.MdiParent = this;
      form.Show();
    }
  }
}
