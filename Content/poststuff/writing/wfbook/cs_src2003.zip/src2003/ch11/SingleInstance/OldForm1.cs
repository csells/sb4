using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Threading;
using System.Runtime.Remoting; // new assembly to reference
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;

namespace SingleInstance {
  /// <summary>
  /// Summary description for Form1.
  /// </summary>
  public class MainForm : Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public MainForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      // 
      // MainForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.IsMdiContainer = true;
      this.Name = "MainForm";
      this.Text = "SingleInstanceApp";

    }
		#endregion

    // Make main form accessible from other instance event handler
    static MainForm mainForm = new MainForm();

    // Signature of method to call when other instance is detected
    delegate void OtherInstanceCallback(string[] args);

    [STAThread]
    static void Main(string[] args) {
      // Check for existing instance
      bool firstInstance = false;
      string safeName = Application.ExecutablePath.Replace(@"\", "_");
      Mutex mutex = new Mutex(true, safeName, out firstInstance);
      if( !firstInstance ) {
        // Open remoting channel exposed from initial instance
        // NOTE: port (1313) and channel name (mainForm) must match below
        string formUrl = "tcp://localhost:1313/mainForm";
        MainForm otherMainForm =
          (MainForm)RemotingServices.Connect(typeof(MainForm), formUrl);

        // Send arguments to initial instance and exit this one
        otherMainForm.OnOtherInstance(args);
        return;
      }

      // Expose remoting channel to accept arguments from other instances
      // NOTE: port (1313) and channel name (mainForm) must match above
      ChannelServices.RegisterChannel(new TcpChannel(1313));
      RemotingServices.Marshal(mainForm, "mainForm");

      // Open file from command line
      if( args.Length == 1 ) mainForm.OpenFile(args[0]);

      // Show main form
      Application.Run(mainForm);
    }

    // Called via remoting channel from other instances
    public void OnOtherInstance(string[] args) {
      // Transition to the UI thread
      if( mainForm.InvokeRequired ) {
        OtherInstanceCallback del =
          new OtherInstanceCallback(OnOtherInstance);
        mainForm.Invoke(del, new object[] { args });
        return;
      }

      // Open file from command line
      if( args.Length == 1 ) this.OpenFile(args[0]);

      // Bring window to the front
      mainForm.Activate();
    }

    public void OpenFile(string fileName) {
      MdiChild form = new MdiChild();
      form.OpenFile(fileName);
      form.MdiParent = this;
      form.Show();
    }
  }
}
