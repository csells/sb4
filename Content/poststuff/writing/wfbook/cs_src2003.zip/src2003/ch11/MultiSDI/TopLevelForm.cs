using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using SellsBrothers;
using Microsoft.Win32; // RegistryKey

namespace MultiSDI {
  /// <summary>
  /// Summary description for TopLevelForm.
  /// </summary>
  class TopLevelForm : Form {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;
    private System.Windows.Forms.MainMenu mainMenu1;
    private System.Windows.Forms.MenuItem menuItem1;
    private System.Windows.Forms.MenuItem fileNewWindowMenuItem;
    private System.Windows.Forms.MenuItem fileCloseWindowMenuItem;
    private System.Windows.Forms.MenuItem windowMenu;
    private System.Windows.Forms.TextBox textBox1;
    static int count = 0;

    public TopLevelForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
      ++count;
      this.Text += ": " + count.ToString();

      // Add new top-level form to the application context
      context.AddTopLevelForm(this);
      
      // Add Window MenuItem to the application context
      context.AddWindowMenu(this.windowMenu);
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.mainMenu1 = new System.Windows.Forms.MainMenu();
      this.menuItem1 = new System.Windows.Forms.MenuItem();
      this.fileNewWindowMenuItem = new System.Windows.Forms.MenuItem();
      this.fileCloseWindowMenuItem = new System.Windows.Forms.MenuItem();
      this.windowMenu = new System.Windows.Forms.MenuItem();
      this.textBox1 = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // mainMenu1
      // 
      this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.menuItem1,
                                                                              this.windowMenu});
      // 
      // menuItem1
      // 
      this.menuItem1.Index = 0;
      this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.fileNewWindowMenuItem,
                                                                              this.fileCloseWindowMenuItem});
      this.menuItem1.Text = "&File";
      // 
      // fileNewWindowMenuItem
      // 
      this.fileNewWindowMenuItem.Index = 0;
      this.fileNewWindowMenuItem.Shortcut = System.Windows.Forms.Shortcut.CtrlN;
      this.fileNewWindowMenuItem.Text = "&New Window";
      this.fileNewWindowMenuItem.Click += new System.EventHandler(this.fileNewWindowMenuItem_Click);
      // 
      // fileCloseWindowMenuItem
      // 
      this.fileCloseWindowMenuItem.Index = 1;
      this.fileCloseWindowMenuItem.Text = "&Close Window";
      this.fileCloseWindowMenuItem.Click += new System.EventHandler(this.fileCloseWindowtMenuItem_Click);
      // 
      // windowMenu
      // 
      this.windowMenu.Index = 1;
      this.windowMenu.Text = "&Window";
      // 
      // textBox1
      // 
      this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.textBox1.Multiline = true;
      this.textBox1.Name = "textBox1";
      this.textBox1.Size = new System.Drawing.Size(292, 266);
      this.textBox1.TabIndex = 0;
      this.textBox1.Text = "";
      // 
      // TopLevelForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.textBox1});
      this.Menu = this.mainMenu1;
      this.Name = "TopLevelForm";
      this.Text = "Top-Level Form";
      this.ResumeLayout(false);

    }
		#endregion

    // Need application context to manage top-level forms
    static MultiSdiApplicationContext context =
      new MultiSdiApplicationContext();

    [STAThread]
    static void Main(string[] args) {
      // Check if someone has hi-jacked the .tlf extension
      bool mapExtension = true;
      using( RegistryKey key =
               Registry.ClassesRoot.OpenSubKey(".tlf") ) {
        if( (key != null) &&
          (key.GetValue(null).ToString().ToLower() != "tlffile" ) ) {
          string ask = "Associate .tlf with this application?";
          DialogResult res =
            MessageBox.Show(ask, "Oops!", MessageBoxButtons.YesNo);
          if( res == DialogResult.No ) mapExtension = false;
        }
      }

      if( mapExtension ) {
        // Map .tlf extension to a ProgID
        using( RegistryKey key =
                 Registry.ClassesRoot.CreateSubKey(".tlf") ) {
          key.SetValue(null, "tlffile");
        }

        // Map ProgID to an Open action for the shell
        string cmdkey = @"tlffile\shell\open\command";
        using( RegistryKey key =
                 Registry.ClassesRoot.CreateSubKey(cmdkey) ) {
          key.SetValue(null, Application.ExecutablePath + " \"%L\"");
        }
      }

      // Add initial form
      TopLevelForm initialForm = new TopLevelForm();
      context.AddTopLevelForm(initialForm);

      // Let initial instance show another top-level form (if necessary)
      OtherInstanceCallback callback = 
        new OtherInstanceCallback(OnOtherInstance);
      if( InitialInstanceActivator.Activate(context, callback, args) ) {
        return;
      }

      // Open file from command line
      if( args.Length == 1 ) initialForm.OpenFile(args[0]);

      // Run application
      Application.Run(context);
    }

    static void NewWindow(string fileName) {
      // Create another top-level form
      TopLevelForm form = new TopLevelForm();
      if( fileName != null ) form.OpenFile(fileName);
      form.Show();
    }

    static void OnOtherInstance(string[] args) {
      NewWindow(args.Length == 1 ? args[0] : null);
    }

    void fileNewWindowMenuItem_Click(object sender, EventArgs e) {
      NewWindow(null);
    }

    void OpenFile(string fileName) {
      using( StreamReader reader = new StreamReader(fileName) ) {
        textBox1.Text = reader.ReadToEnd();
      }

      this.Text += " (" + fileName + ")";
    }

    void fileCloseWindowtMenuItem_Click(object sender, System.EventArgs e) {
      this.Close();
    }
  }
}






