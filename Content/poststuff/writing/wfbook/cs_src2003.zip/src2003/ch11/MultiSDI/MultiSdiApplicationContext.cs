// MultiSdiApplicationContext.cs
// Inspired by Brian Randell
// Copyright (c) 2003, Chris Sells

using System;
using System.Collections;
using System.Windows.Forms;

namespace SellsBrothers {
  public class MultiSdiApplicationContext : ApplicationContext {
    public void AddTopLevelForm(Form form) {
      // Initial main form may add itself twice, but that's OK
      if( topLevelForms.Contains(form) ) return;

      // Add form to collection of forms and
      // watch for it to activate and close
      topLevelForms.Add(form);
      form.Activated += new EventHandler(Form_Activated);
      form.Closed += new EventHandler(Form_Closed);

      // Set initial main form to activate
      if( topLevelForms.Count == 1 ) base.MainForm = form;
    }

    void Form_Activated(object sender, EventArgs e) {
      // Whichever form activated last is the "main" form
      base.MainForm = (Form)sender;
    }

    void Form_Closed(object sender, EventArgs e) {
      // Remove form from the list
      topLevelForms.Remove(sender);

      // Set a new "main" if necessary
      if( ((Form)sender == base.MainForm) &&
        (this.topLevelForms.Count > 0) ) {
        this.MainForm = (Form)topLevelForms[0];
      }
    }

    public void AddWindowMenu(MenuItem menu) {
      // Add at least one dummy menu item to get pop-up event
      if( menu.MenuItems.Count == 0 ) menu.MenuItems.Add("dummy");

      // Subscribe to pop-up event
      menu.Popup += new EventHandler(WindowMenu_Popup);
    }

    // Current Window menu items and the map to the appropriate form
    Hashtable windowMenuMap = new Hashtable();

    void WindowMenu_Popup(object sender, EventArgs e) {
      // Build menu from list of top-level windows
      MenuItem menu = (MenuItem)sender;
      menu.MenuItems.Clear();
      windowMenuMap.Clear();

      foreach( Form form in this.topLevelForms ) {
        MenuItem item = menu.MenuItems.Add(form.Text);
        item.Click += new EventHandler(WindowMenuItem_Click);
    
        // Check currently active window
        if( form == Form.ActiveForm ) item.Checked = true;
    
        // Associate each menu item back to the form
        windowMenuMap.Add(item, form);
      }
    }

    void WindowMenuItem_Click(object sender, EventArgs e) {
      // Activate top-level form based on selection
      ((Form)windowMenuMap[sender]).Activate();
    }

    public Form[] TopLevelForms {
      // Expose list of top-level forms for building Window menu
      get { return (Form[])topLevelForms.ToArray(typeof(Form)); }
    }

    ArrayList topLevelForms = new ArrayList();
  }
}
