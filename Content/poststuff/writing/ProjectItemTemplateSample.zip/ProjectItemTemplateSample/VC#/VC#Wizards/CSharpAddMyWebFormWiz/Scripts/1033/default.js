// portions (c) 2001 Microsoft Corporation
// portions (c) 2002 Chris Sells

var fso = new ActiveXObject("Scripting.FileSystemObject");

function AddDefaultServerScriptToWizard(selProj)
{
	wizard.AddSymbol("DEFAULT_SERVER_SCRIPT", "JavaScript");
}

function AddDefaultClientScriptToWizard(selProj)
{
    var prjScriptLang = selProj.Properties("DefaultClientScript").Value;
    // 0 = JScript
    // 1 = VBScript
    if(prjScriptLang == 0)
    {
        wizard.AddSymbol("DEFAULT_CLIENT_SCRIPT", "JavaScript");
    }
    else
    {
        wizard.AddSymbol("DEFAULT_CLIENT_SCRIPT", "VBScript");
    }
}

function AddDefaultDefaultHTMLPageLayoutToWizard(selProj)
{
    var prjPageLayout = selProj.Properties("DefaultHTMLPageLayout").Value;
    // 0 = FlowLayout
    // 1 = GridLayout
    if(prjPageLayout == 0)
    {
        wizard.AddSymbol("DEFAULT_HTML_LAYOUT", "FlowLayout");
    }
    else
    {
        wizard.AddSymbol("DEFAULT_HTML_LAYOUT", "GridLayout");
    }
}

/******************************************************************************
    Description: Add a file to the project
          oProj: Project object
 strProjectPath: Project path, e.g. "c:\inetpub\wwwroot\WebApplication1\"
strTemplateFile: Template file name (relative to template path), e.g. "WebForm.aspx"
  strTargetFile: Target file name (relative to project path), e.g. "WebForm1.aspx"
******************************************************************************/
function AddFileToProject(oProj, strProjectPath, strTemplateFile, strTargetFile)
{
    // get absolute path to temp file
	var TemporaryFolder = 2;
	var tfolder = fso.GetSpecialFolder(TemporaryFolder);
	var strTempFolder = fso.GetAbsolutePathName(tfolder.Path);
	var strTemp = strTempFolder + "\\" + fso.GetTempName();

    // get absolute path to template file
	var strTemplatePath = wizard.FindSymbol("TEMPLATES_PATH");
	var strTemplate = strTemplatePath + "\\" + strTemplateFile;
	
	// figure out whether to parse the template file or just copy it
	var bCopyOnly = false;
	var strExt = strTemplateFile.substr(strTemplateFile.lastIndexOf("."));
	if(strExt==".bmp" || strExt==".ico" || strExt==".gif" || strExt==".rtf" || strExt==".css")
		bCopyOnly = true;
		
	// render to a temp file
	wizard.RenderTemplate(strTemplate, strTemp, bCopyOnly, true);

    // add file from temp file to target file
	var projfile = oProj.AddFromTemplate(strTemp, strTargetFile);
	
	// delete temp file
	SafeDeleteFile(fso, strTemp);

	return projfile;
}

function OnFinish(selProj, selObj)
{
	try
	{
		SetTargetFullPath(selObj);
		var strProjectPath      = wizard.FindSymbol("TARGET_FULLPATH");
		var strTemplatePath     = wizard.FindSymbol("TEMPLATES_PATH");
		var strProjectName      = wizard.FindSymbol("PROJECT_NAME");
		var strSafeProjectName  = CreateSafeName(strProjectName);

		// add the default project props for the aspx file before we
		// render it
		AddDefaultServerScriptToWizard(selProj);
		AddDefaultClientScriptToWizard(selProj);
		AddDefaultTargetSchemaToWizard(selProj);
		AddDefaultDefaultHTMLPageLayoutToWizard(selProj);

        // set up the symbols for rending
		var strItemName = wizard.FindSymbol("ITEM_NAME");   // e.g. "WebForm1.aspx"
		var strClassName = strItemName.split(".");
		wizard.AddSymbol("SAFE_CLASS_NAME", strClassName[0]);
	    wizard.AddSymbol("SAFE_ITEM_NAME", strClassName[0]);
		wizard.AddSymbol("SAFE_PROJECT_NAME", strSafeProjectName);

		// render the aspx file
		var aspxProjFile = AddFileToProject(selObj, strProjectPath, "WebForm.aspx", strItemName);
	    aspxProjFile.Properties("SubType").Value = "Form";
		
		// adding aspx files causes aspx.cs and aspx.resx files to be created.
		// since we're generating our own aspx.cs file, delete the auto-generated one
        SafeDeleteFile(fso, strProjectPath + "\\" + strItemName + ".cs");

        // add the aspx.cs file
		AddFileToProject(selObj, strProjectPath, "WebForm.aspx.cs", strItemName + ".cs");
		
		// open aspx file *after* replacing aspx.cs file
		// (otherwise VS.NET freaks out)
		aspxProjFile.Open(vsViewKindPrimary).visible = true;

		AddReferencesForWebForm(selProj);
	}
	catch(e)
	{
		if( e.description.length > 0 ) SetErrorInfo(e);
		return e.number;
	}
}
