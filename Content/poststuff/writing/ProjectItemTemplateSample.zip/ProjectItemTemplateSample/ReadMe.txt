To use this VS.NET project item template sample, unzip it to your VS.NET install directory. It contains folders that already exist, but won't overwrite any files, so it's OK to say "Yes" if the shell asks if you'd like to copy the files into the existing directories.

Copyright (c) 2002, Chris Sells
All rights reserved.
No warranties extended.
Use at your own risk!
Comments to csells@sellsbrothers.com.
See http://www.sellsbrothers.com/ for updates.

