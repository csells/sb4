using System;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Collections;
using System.Diagnostics;

class App {
  class ProcessIdentity {
    public Process Process;
    public WindowsIdentity Identity;

    public ProcessIdentity(Process process, WindowsIdentity identity) {
      this.Process = process;
      this.Identity = identity;
    }
  }

  [Flags]
    enum TOKEN_ACCESS : uint {
    TOKEN_ASSIGN_PRIMARY = 0x0001,
    TOKEN_DUPLICATE = 0x0002,
    TOKEN_IMPERSONATE = 0x0004,
    TOKEN_QUERY = 0x0008,
    TOKEN_QUERY_SOURCE = 0x0010,
    TOKEN_ADJUST_PRIVILEGES = 0x0020,
    TOKEN_ADJUST_GROUPS = 0x0040,
    TOKEN_ADJUST_DEFAULT = 0x0080,
    TOKEN_ADJUST_SESSIONID = 0x0100,
    TOKEN_READ = 0x00020000 | TOKEN_QUERY,
    TOKEN_WRITE = 0x00020000 | TOKEN_ADJUST_PRIVILEGES | TOKEN_ADJUST_GROUPS | TOKEN_ADJUST_DEFAULT,
    TOKEN_EXECUTE = 0x00020000,
  };

  [DllImport("Advapi32.dll", SetLastError = true)]
  extern static int OpenProcessToken(IntPtr processHandle, TOKEN_ACCESS desiredAccess, out IntPtr tokenHandle);

  [DllImport("kernel32.dll", SetLastError = true)]
  extern static bool CloseHandle(IntPtr handle);

  static ProcessIdentity[] GetProcessesIdentities() {
    ArrayList list = new ArrayList();

    foreach( Process process in Process.GetProcesses() ) {
      try {
        IntPtr token = IntPtr.Zero;
        if( OpenProcessToken(process.Handle, TOKEN_ACCESS.TOKEN_QUERY, out token) == 0 ) {
          throw new ApplicationException("Can't open process token for: " + process.ProcessName);
        }

        list.Add(new ProcessIdentity(process, new WindowsIdentity(token)));
        CloseHandle(token);
      }
      catch( Exception ex ) {
        list.Add(new ProcessIdentity(process, null));
        System.Diagnostics.Debug.WriteLine(ex.Message);
      }
    }

    return (ProcessIdentity[])list.ToArray(typeof(ProcessIdentity));
  }

  static void Main(string[] args) {
    ProcessIdentity[] normalProcIDs = GetProcessesIdentities();
    foreach( ProcessIdentity procid in normalProcIDs ) {
      if( procid.Identity != null ) {
        Console.WriteLine("{0} running under {1}", procid.Process.ProcessName, procid.Identity.Name);
      }
      else {
        Console.WriteLine("{0} *probably* running under SYSTEM", procid.Process.ProcessName);
      }
    }
  }
}




