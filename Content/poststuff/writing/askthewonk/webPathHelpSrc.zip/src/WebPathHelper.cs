using System;
using System.Web;
using System.Diagnostics;
using System.Security.Policy;

namespace SellsBrothers {
  public class WebPathHelper {
    // "http://www.foo.com/" or "http://localhost/foo/"
    public static string RootUrl {
      get {
        HttpRequest request = HttpContext.Current.Request;

        // "http://www.foo.com/foo.htm" or "http://localhost/foo/foo.htm"
        string requestUrl = request.Url.ToString();

        // "http" or "ftp"
        string protocol = requestUrl.Substring(0, requestUrl.IndexOf(":"));

        // "www.foo.com" or "localhost"
        string site = Site.CreateFromUrl(requestUrl).Name;

        // "/" or "/foo" => "" or "foo"
        string appPath = request.ApplicationPath.Substring(1);

        // "http://www.foo.com/" or "http://localhost/foo/"
        string root = string.Format("{0}://{1}/{2}{3}", protocol, site, appPath, appPath.Length > 0 ? "/" : "");

        //                string appPath = request.ApplicationPath;
        //                int i = requestUrl.IndexOf(appPath);
        //                Debug.Assert(i >= 0);
        //                string root = requestUrl.Substring(0, i + appPath.Length);
        Debug.Assert(root.EndsWith("/"));
        return root;
      }
    }

    public static string RootPath {
      get {
        HttpRequest request = HttpContext.Current.Request;
        string root = request.PhysicalApplicationPath;
        Debug.Assert(root.EndsWith(@"\"));
        return root;
      }
    }

    public static string MapUrlFromRoot(string url) {
      string safeUrl = url.Replace('\\', '/').TrimStart('/');
      return RootUrl + safeUrl;
    }

    public static string MapPathFromRoot(string path) {
      string safePath = path.Replace('/', '\\').TrimStart('\\');
      return RootPath + safePath;
    }
  }
}
