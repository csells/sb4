using System;
using System.Collections;
using System.ComponentModel;
using System.Web;
using System.Web.SessionState;
using System.Text;
using SellsBrothers;

namespace PathFun 
{
	public class Global : System.Web.HttpApplication
	{
        public static string GetPathTable()
        {
            HttpRequest Request = HttpContext.Current.Request;
            StringBuilder sb = new StringBuilder();
            sb.Append("<table>");

            // Row
            sb.Append("<tr><td>Call</td><td>Result</td></tr>");

            // Row
            sb.Append("<tr>");

            sb.Append("<td>");
            sb.Append("Request.ApplicationPath");
            sb.Append("</td>");

            sb.Append("<td>");
            sb.Append(Request.ApplicationPath);
            sb.Append("</td>");

            sb.Append("</tr>");

            // Row
            sb.Append("<tr>");

            sb.Append("<td>");
            sb.Append("Request.CurrentExecutionFilePath");
            sb.Append("</td>");

            sb.Append("<td>");
            sb.Append(Request.CurrentExecutionFilePath);
            sb.Append("</td>");

            sb.Append("</tr>");

            // Row
            sb.Append("<tr>");

            sb.Append("<td>");
            sb.Append("Request.FilePath");
            sb.Append("</td>");

            sb.Append("<td>");
            sb.Append(Request.FilePath);
            sb.Append("</td>");

            sb.Append("</tr>");

            // Row
            sb.Append("<tr>");

            sb.Append("<td>");
            sb.Append("Request.Path");
            sb.Append("</td>");

            sb.Append("<td>");
            sb.Append(Request.Path);
            sb.Append("</td>");

            sb.Append("</tr>");

            // Row
            sb.Append("<tr>");

            sb.Append("<td>");
            sb.Append("Request.PhysicalApplicationPath");
            sb.Append("</td>");

            sb.Append("<td>");
            sb.Append(Request.PhysicalApplicationPath);
            sb.Append("</td>");

            sb.Append("</tr>");

            // Row
            sb.Append("<tr>");

            sb.Append("<td>");
            sb.Append("Request.Url");
            sb.Append("</td>");

            sb.Append("<td>");
            sb.Append(Request.Url);
            sb.Append("</td>");

            sb.Append("</tr>");

            // Row
            sb.Append("<tr>");

            sb.Append("<td>");
            sb.Append("Request.RawUrl");
            sb.Append("</td>");

            sb.Append("<td>");
            sb.Append(Request.RawUrl);
            sb.Append("</td>");

            sb.Append("</tr>");

            // Row
            sb.Append("<tr>");

            sb.Append("<td>");
            sb.Append("Request.Headers['Host']");
            sb.Append("</td>");

            sb.Append("<td>");
            sb.Append(Request.Headers["Host"]);
            sb.Append("</td>");

            sb.Append("</tr>");

            // Row
            sb.Append("<tr>");

            sb.Append("<td>");
            sb.Append("Request.UserHostName");
            sb.Append("</td>");

            sb.Append("<td>");
            sb.Append(Request.UserHostName);
            sb.Append("</td>");

            sb.Append("</tr>");

            // Row
            sb.Append("<tr>");

            sb.Append("<td>");
            sb.Append("Request.UserHostAddress");
            sb.Append("</td>");

            sb.Append("<td>");
            sb.Append(Request.UserHostAddress);
            sb.Append("</td>");

            sb.Append("</tr>");

            // Row
            sb.Append("<tr>");

            sb.Append("<td>");
            sb.Append("Request.MapPath('hi')");
            sb.Append("</td>");

            sb.Append("<td>");
            sb.Append(Request.MapPath("hi"));
            sb.Append("</td>");

            sb.Append("</tr>");

            // Row
            sb.Append("<tr>");

            sb.Append("<td>");
            sb.Append(@"Request.MapPath('\hi')");
            sb.Append("</td>");

            sb.Append("<td>");
            sb.Append(Request.MapPath(@"\hi"));
            sb.Append("</td>");

            sb.Append("</tr>");

            // Row
            sb.Append("<tr>");

            sb.Append("<td>");
            sb.Append("Request.MapPath('/hi')");
            sb.Append("</td>");
            
            sb.Append("<td>");
            sb.Append(Request.MapPath(@"/hi"));
            sb.Append("</td>");
            
            sb.Append("</tr>");

            // Row
            sb.Append("<tr>");

            sb.Append("<td>");
            sb.Append(@"WebPathHelper.RootPath");
            sb.Append("</td>");
            
            sb.Append("<td>");
            sb.Append(WebPathHelper.RootPath);
            sb.Append("</td>");
            
            sb.Append("</tr>");

            // Row
            sb.Append("<tr>");

            sb.Append("<td>");
            sb.Append(@"WebPathHelper.MapPathFromRoot('hi')");
            sb.Append("</td>");
            
            sb.Append("<td>");
            sb.Append(WebPathHelper.MapPathFromRoot(@"hi"));
            sb.Append("</td>");
            
            sb.Append("</tr>");

            // Row
            sb.Append("<tr>");

            sb.Append("<td>");
            sb.Append(@"WebPathHelper.MapPathFromRoot('\hi')");
            sb.Append("</td>");
            
            sb.Append("<td>");
            sb.Append(WebPathHelper.MapPathFromRoot(@"\hi"));
            sb.Append("</td>");
            
            sb.Append("</tr>");

            // Row
            sb.Append("<tr>");

            sb.Append("<td>");
            sb.Append("WebPathHelper.MapPathFromRoot('/hi')");
            sb.Append("</td>");
            
            sb.Append("<td>");
            sb.Append(WebPathHelper.MapPathFromRoot(@"/hi"));
            sb.Append("</td>");
            
            sb.Append("</tr>");

            // Row
            sb.Append("<tr>");

            sb.Append("<td>");
            sb.Append(@"WebPathHelper.RootUrl");
            sb.Append("</td>");
            
            sb.Append("<td>");
            sb.Append(WebPathHelper.RootUrl);
            sb.Append("</td>");
            
            sb.Append("</tr>");

            // Row
            sb.Append("<tr>");

            sb.Append("<td>");
            sb.Append(@"WebPathHelper.MapUrlFromRoot('hi')");
            sb.Append("</td>");
            
            sb.Append("<td>");
            sb.Append(WebPathHelper.MapUrlFromRoot(@"hi"));
            sb.Append("</td>");
            
            sb.Append("</tr>");

            // Row
            sb.Append("<tr>");

            sb.Append("<td>");
            sb.Append(@"WebPathHelper.MapUrlFromRoot('\hi')");
            sb.Append("</td>");
            
            sb.Append("<td>");
            sb.Append(WebPathHelper.MapUrlFromRoot(@"\hi"));
            sb.Append("</td>");
            
            sb.Append("</tr>");

            // Row
            sb.Append("<tr>");

            sb.Append("<td>");
            sb.Append("WebPathHelper.MapUrlFromRoot('/hi')");
            sb.Append("</td>");
            
            sb.Append("<td>");
            sb.Append(WebPathHelper.MapUrlFromRoot(@"/hi"));
            sb.Append("</td>");
            
            sb.Append("</tr>");

            sb.Append("</table>");
            return sb.ToString();
        }

		public Global()
		{
			InitializeComponent();
		}	
		
		protected void Application_Start(Object sender, EventArgs e)
		{

		}
 
		protected void Session_Start(Object sender, EventArgs e)
		{

		}

		protected void Application_BeginRequest(Object sender, EventArgs e)
		{

		}

		protected void Application_EndRequest(Object sender, EventArgs e)
		{

		}

		protected void Application_AuthenticateRequest(Object sender, EventArgs e)
		{

		}

		protected void Application_Error(Object sender, EventArgs e)
		{

		}

		protected void Session_End(Object sender, EventArgs e)
		{

		}

		protected void Application_End(Object sender, EventArgs e)
		{

		}
			
		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
		}
		#endregion
	}
}

