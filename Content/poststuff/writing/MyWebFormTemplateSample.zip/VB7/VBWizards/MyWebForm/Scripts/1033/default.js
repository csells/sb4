// portions (c) 2001 Microsoft Corporation
// bits Michael Weinhardt (michaelweinhardt@yahoo.com.au)

function OnFinish(selProj, selObj)
{

	var oldSuppressUIValue = true;

	try
	{
	
		oldSuppressUIValue = dte.SuppressUI;
		dte.SuppressUI = false;

		//gather template and target file/path details
		var strTemplateName = "MyWebForm.aspx";
		var strItemName = wizard.FindSymbol("ITEM_NAME");
		var strTemplatesPath = wizard.FindSymbol("TEMPLATES_PATH");
		var folder = selObj.parent;
		var strTargetPath = folder.Properties("FullPath");
		var strCodeBehindTargetFile = strTargetPath + "\\" + strItemName + ".vb";
		var strWebFormTemplateFile = strTemplatesPath + "\\" + strTemplateName; 
		var strCodeBehindTemplateFile = strTemplatesPath + "\\" + strTemplateName + ".vb";

		//add class name symbol for the custom .aspx.vb
		var strClassName = strItemName.split(".");
		wizard.AddSymbol("SAFE_CLASS_NAME", strClassName[0]);

		//set default webform properties
		AddDefaultWebFormsPropertiesToWizard(dte, wizard, selProj);

		//generate and add .aspx and .aspx.vb (auto-generated) files to project
		var item = AddFileToVSProject(strItemName, selProj, selObj, strWebFormTemplateFile);

		//delete VB.NET default .aspx.vb and replace with our own version
		var fso = new ActiveXObject("Scripting.FileSystemObject");
		SafeDeleteFile(fso, strCodeBehindTargetFile);
		AddFileToVSProject(strItemName + ".vb", selProj, selObj, strCodeBehindTemplateFile);

		//open .aspx file in the VS.NET IDE
		if( item )
		{
			var editor = item.Open(vsViewKindPrimary);
			editor.Visible = true;
		}

		return 0;

	}
	catch(e)
	{   
		switch(e.number)
		{
			case -2147221492 /* OLE_E_PROMPTSAVECANCELLED */ :
				return -2147221492;
			case -2147024816 /* FILE_ALREADY_EXISTS */ :
			case -2147213313 /* VS_E_WIZARDBACKBUTTONPRESS */ :
				return -2147213313;
			default:
				wizard.ReportError(e.description);
				return -2147213313;
		}
	}
	finally
	{
		dte.SuppressUI = oldSuppressUIValue;
	}
}