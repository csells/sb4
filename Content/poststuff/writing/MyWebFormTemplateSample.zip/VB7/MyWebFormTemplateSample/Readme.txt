Extract this to you Microsoft Visual Studio.Net folder.  It will unzip the sample files to 
various subfolders associated with the MyWebForm Project Template Wizard Sample, but won't overwrite
existing files.

Use at your own risk!
Comments to michaelweinhardt@yahoo.com.au