namespace Microsoft.Samples.Windows.Forms.RegistrySettingsProvider
{
    partial class formTestForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonSaveSettings = new System.Windows.Forms.Button();
            this.buttonResetSettings = new System.Windows.Forms.Button();
            this.buttonPreviousText = new System.Windows.Forms.Button();
            this.buttonUpgradeSettings = new System.Windows.Forms.Button();
            this.comboValueSetting = new System.Windows.Forms.ComboBox();
            this.checkSetting1 = new System.Windows.Forms.CheckBox();
            this.checkSetting2 = new System.Windows.Forms.CheckBox();
            this.textTextSetting = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Random Text";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkSetting1);
            this.groupBox1.Controls.Add(this.checkSetting2);
            this.groupBox1.Location = new System.Drawing.Point(12, 35);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(170, 82);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Random Checkboxes";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(198, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Random Choice:";
            // 
            // buttonSaveSettings
            // 
            this.buttonSaveSettings.Location = new System.Drawing.Point(228, 223);
            this.buttonSaveSettings.Name = "buttonSaveSettings";
            this.buttonSaveSettings.Size = new System.Drawing.Size(152, 23);
            this.buttonSaveSettings.TabIndex = 8;
            this.buttonSaveSettings.Text = "&Save Settings";
            this.buttonSaveSettings.Click += new System.EventHandler(this.buttonSaveSettings_Click);
            // 
            // buttonResetSettings
            // 
            this.buttonResetSettings.Location = new System.Drawing.Point(228, 165);
            this.buttonResetSettings.Name = "buttonResetSettings";
            this.buttonResetSettings.Size = new System.Drawing.Size(152, 23);
            this.buttonResetSettings.TabIndex = 6;
            this.buttonResetSettings.Text = "&Reset Settings";
            this.buttonResetSettings.UseVisualStyleBackColor = true;
            this.buttonResetSettings.Click += new System.EventHandler(this.buttonResetSettings_Click);
            // 
            // buttonPreviousText
            // 
            this.buttonPreviousText.Location = new System.Drawing.Point(228, 136);
            this.buttonPreviousText.Name = "buttonPreviousText";
            this.buttonPreviousText.Size = new System.Drawing.Size(152, 23);
            this.buttonPreviousText.TabIndex = 5;
            this.buttonPreviousText.Text = "&Previous Text";
            this.buttonPreviousText.UseVisualStyleBackColor = true;
            this.buttonPreviousText.Click += new System.EventHandler(this.buttonPreviousText_Click);
            // 
            // buttonUpgradeSettings
            // 
            this.buttonUpgradeSettings.Location = new System.Drawing.Point(228, 194);
            this.buttonUpgradeSettings.Name = "buttonUpgradeSettings";
            this.buttonUpgradeSettings.Size = new System.Drawing.Size(152, 23);
            this.buttonUpgradeSettings.TabIndex = 7;
            this.buttonUpgradeSettings.Text = "&Upgrade Settings";
            this.buttonUpgradeSettings.UseVisualStyleBackColor = true;
            this.buttonUpgradeSettings.Click += new System.EventHandler(this.buttonUpgradeSettings_Click);
            // 
            // comboValueSetting
            // 
            this.comboValueSetting.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::Microsoft.Samples.Windows.Forms.RegistrySettingsProvider.Properties.Settings.Default, "ComboValue", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.comboValueSetting.FormattingEnabled = true;
            this.comboValueSetting.Items.AddRange(new object[] {
            "First Choice",
            "Second Choice",
            "Third Choice"});
            this.comboValueSetting.Location = new System.Drawing.Point(198, 76);
            this.comboValueSetting.Name = "comboValueSetting";
            this.comboValueSetting.Size = new System.Drawing.Size(182, 24);
            this.comboValueSetting.TabIndex = 4;
            this.comboValueSetting.Text = global::Microsoft.Samples.Windows.Forms.RegistrySettingsProvider.Properties.Settings.Default.ComboValue;
            // 
            // checkSetting1
            // 
            this.checkSetting1.AutoSize = true;
            this.checkSetting1.Checked = global::Microsoft.Samples.Windows.Forms.RegistrySettingsProvider.Properties.Settings.Default.CheckSetting1;
            this.checkSetting1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkSetting1.DataBindings.Add(new System.Windows.Forms.Binding("Checked", global::Microsoft.Samples.Windows.Forms.RegistrySettingsProvider.Properties.Settings.Default, "CheckSetting1", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.checkSetting1.Location = new System.Drawing.Point(8, 23);
            this.checkSetting1.Name = "checkSetting1";
            this.checkSetting1.Size = new System.Drawing.Size(161, 21);
            this.checkSetting1.TabIndex = 0;
            this.checkSetting1.Text = "Random CheckBox &1";
            // 
            // checkSetting2
            // 
            this.checkSetting2.AutoSize = true;
            this.checkSetting2.Checked = global::Microsoft.Samples.Windows.Forms.RegistrySettingsProvider.Properties.Settings.Default.CheckSetting2;
            this.checkSetting2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkSetting2.DataBindings.Add(new System.Windows.Forms.Binding("Checked", global::Microsoft.Samples.Windows.Forms.RegistrySettingsProvider.Properties.Settings.Default, "CheckSetting2", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.checkSetting2.Location = new System.Drawing.Point(8, 46);
            this.checkSetting2.Name = "checkSetting2";
            this.checkSetting2.Size = new System.Drawing.Size(161, 21);
            this.checkSetting2.TabIndex = 1;
            this.checkSetting2.Text = "Random CheckBox &2";
            // 
            // textTextSetting
            // 
            this.textTextSetting.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::Microsoft.Samples.Windows.Forms.RegistrySettingsProvider.Properties.Settings.Default, "TextSetting", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.textTextSetting.Location = new System.Drawing.Point(110, 9);
            this.textTextSetting.Name = "textTextSetting";
            this.textTextSetting.Size = new System.Drawing.Size(270, 22);
            this.textTextSetting.TabIndex = 1;
            this.textTextSetting.Text = global::Microsoft.Samples.Windows.Forms.RegistrySettingsProvider.Properties.Settings.Default.TextSetting;
            // 
            // formTestForm
            // 
            this.ClientSize = new System.Drawing.Size(392, 259);
            this.Controls.Add(this.buttonPreviousText);
            this.Controls.Add(this.buttonUpgradeSettings);
            this.Controls.Add(this.buttonResetSettings);
            this.Controls.Add(this.buttonSaveSettings);
            this.Controls.Add(this.comboValueSetting);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textTextSetting);
            this.Controls.Add(this.label1);
            this.ForeColor = global::Microsoft.Samples.Windows.Forms.RegistrySettingsProvider.Properties.Settings.Default.FormForeColor;
            this.MaximizeBox = false;
            this.Name = "formTestForm";
            this.Text = "RegistrySettingsProvider Sample (2)";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textTextSetting;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkSetting1;
        private System.Windows.Forms.CheckBox checkSetting2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboValueSetting;
        private System.Windows.Forms.Button buttonSaveSettings;
        private System.Windows.Forms.Button buttonResetSettings;
        private System.Windows.Forms.Button buttonPreviousText;
        private System.Windows.Forms.Button buttonUpgradeSettings;
    }
}

