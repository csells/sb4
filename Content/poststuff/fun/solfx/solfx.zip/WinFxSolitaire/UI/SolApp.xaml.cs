﻿using System;
using System.Windows;
using System.Data;
using System.Xml;
using System.Configuration;

namespace WinFxSolitaire {
  public partial class SolApp : Application {
    internal Solitaire.Domain.Game Game = Solitaire.Domain.
                                          GameFactory.Instance.
    CreateNewGame(Solitaire.Domain.DrawType.Three,
    Solitaire.Domain.ScoringType.VegasCumulative);

    void AppStartingUp(object sender, StartingUpCancelEventArgs e) {
      MainWindow mainWindow = new MainWindow();
      MainWindow.Show();
    }

  }
}
