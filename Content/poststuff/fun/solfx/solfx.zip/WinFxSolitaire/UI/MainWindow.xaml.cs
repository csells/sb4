﻿#define DEBUG // Hack to Debug.WriteLine will work

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Input;
using Solitaire.Domain;
using CardControls;
using System.Windows.Data;
using System.Diagnostics;
using System.Windows.Media;

namespace WinFxSolitaire {
  public partial class MainWindow : Window {
    public override void EndInit() {
      Game game = ((SolApp)SolApp.Current).Game;

      discardPile.StackOfCards = game.Discard;
      drawPile.StackOfCards = game.Draw;
      suitPile1.StackOfCards = game.SuitStacks[0];
      suitPile2.StackOfCards = game.SuitStacks[1];
      suitPile3.StackOfCards = game.SuitStacks[2];
      suitPile4.StackOfCards = game.SuitStacks[3];
      cardPile1.StackOfCards = game.CardStacks[0];
      cardPile2.StackOfCards = game.CardStacks[1];
      cardPile3.StackOfCards = game.CardStacks[2];
      cardPile4.StackOfCards = game.CardStacks[3];
      cardPile5.StackOfCards = game.CardStacks[4];
      cardPile6.StackOfCards = game.CardStacks[5];
      cardPile7.StackOfCards = game.CardStacks[6];

      this.PreviewMouseLeftButtonDown += MainWindow_PreviewMouseLeftButtonDown;
      this.PreviewMouseMove += MainWindow_PreviewMouseMove;
      this.PreviewMouseLeftButtonUp += MainWindow_PreviewMouseLeftButtonUp;
      this.DataContext = game;
      newGameButton.Click += newGameButton_Click;
    }

    void newGameButton_Click(object sender, RoutedEventArgs e) {
      Game game = ((SolApp)SolApp.Current).Game;

      game.DealNewHand();
// DONE
//      discardPile.StackOfCards = game.Discard;
//      drawPile.StackOfCards = game.Draw;
//      suitPile1.StackOfCards = game.SuitStacks[0];
//      suitPile2.StackOfCards = game.SuitStacks[1];
//      suitPile3.StackOfCards = game.SuitStacks[2];
//      suitPile4.StackOfCards = game.SuitStacks[3];
//      cardPile1.StackOfCards = game.CardStacks[0];
//      cardPile2.StackOfCards = game.CardStacks[1];
//      cardPile3.StackOfCards = game.CardStacks[2];
//      cardPile4.StackOfCards = game.CardStacks[3];
//      cardPile5.StackOfCards = game.CardStacks[4];
//      cardPile6.StackOfCards = game.CardStacks[5];
//      cardPile7.StackOfCards = game.CardStacks[6];
    }

    Nullable<Point> dragPoint = null;
    PileOfCards sourcePile = null;

    void MainWindow_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e) {
      this.sourcePile = FindPile(e.MouseDevice);
      if( this.sourcePile == null ) { return; }
      e.Handled = true;

      Game game = ((SolApp)SolApp.Current).Game;

      if( this.sourcePile.StackOfCards is DrawPile ) {
        game.DrawCards();
        return;
      }

      DragStack dragStack = this.sourcePile.StartDrag(game, e.MouseDevice);
      if( dragStack == null ) { return; }

#if DEBUG
      System.Diagnostics.Debug.WriteLine(string.Format("Dragging {0} cards:", dragStack.Count));
      foreach( Card cardToDrag in dragStack ) {
        System.Diagnostics.Debug.WriteLine(string.Format("\t{0}{1} ({2})", cardToDrag.Rank, cardToDrag.Suit, cardToDrag.Flipped));
      }

      System.Diagnostics.Debug.WriteLine(string.Format("{0} cards left in pile cards:", this.sourcePile.StackOfCards.Count));
      foreach( Card cardLeft in this.sourcePile.StackOfCards ) {
        System.Diagnostics.Debug.WriteLine(string.Format("\t{0}{1} ({2})", cardLeft.Rank, cardLeft.Suit, cardLeft.Flipped));
      }
#endif

      this.sourcePile.Refresh(); // NOTE: Makes sure collection updates are visible

      // DONE: show cards as they're dragged
      // NOTE: Make drag pile the same width as every other pile.
      // The height should fall out of this in the CardControl.MeasureOverride method.
      dragPile.Width = new Length(drawPile.ActualWidth);
      dragPile.StackOfCards = dragStack;

      // TODO: Figure out how to get point relative to cards being dragged,
      // instead of hard-coding in the middle near the top
      // TODO: Figure out why the first drag of a session is at the top-left,
      // but other drags start at the dragPoint offset
      this.dragPoint = new Point(dragPile.ActualWidth / 2.0, dragPile.ActualWidth * CardControl.HeightUnderUpRatio);
      Point pilePosition = new Point(e.GetPosition(mainCanvas).X - this.dragPoint.Value.X, e.GetPosition(mainCanvas).Y - this.dragPoint.Value.Y);

      Canvas.SetLeft(dragPile, new Length(pilePosition.X));
      Canvas.SetTop(dragPile, new Length(pilePosition.Y));
      dragPile.Visibility = Visibility.Visible;

      // Capture the mouse for the pile
      dragPile.CaptureMouse();
    }

    void MainWindow_PreviewMouseMove(object sender, MouseEventArgs e) {
      if( this.dragPoint == null ) { return; }
      Debug.Assert(this.sourcePile != null);
      e.Handled = true;

      // Move the pile the delta between where it just was and where it is now
      Point cursorPosition = e.GetPosition(dragPile);
      Canvas.SetLeft(dragPile, new Length(Canvas.GetLeft(dragPile).Value + cursorPosition.X - this.dragPoint.Value.X));
      Canvas.SetTop(dragPile, new Length(Canvas.GetTop(dragPile).Value + cursorPosition.Y - dragPoint.Value.Y));
    }

    void MainWindow_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e) {
      if( this.dragPoint == null ) { return; }
      Debug.Assert(this.sourcePile != null);
      e.Handled = true;

      // File drop pile
      PileOfCards targetPile = FindPile(e.MouseDevice);
      if( targetPile == null ) { targetPile = this.sourcePile; }

      Game game = ((SolApp)SolApp.Current).Game;
      targetPile.EndDrag(game);

      // Remove drag pile
      dragPile.ReleaseMouseCapture();
      dragPile.Visibility = Visibility.Hidden;
      this.dragPoint = null;
      this.sourcePile = null;
    }

    PileOfCards FindPile(MouseDevice mouse) {
      // NOTE: put top piles at back of list so overlapping of content out of them doesn't result in fake hits
      // taking precedence over bottom piles
      // NOTE: Doesn't seem to still be needed...
      //PileOfCards[] pilesOfCards = new PileOfCards[] { cardPile1, cardPile2, cardPile3, cardPile4, cardPile5, cardPile6, cardPile7, discardPile, drawPile, suitPile1, suitPile2, suitPile3,suitPile4, };
      PileOfCards[] pilesOfCards = new PileOfCards[] { discardPile, drawPile, suitPile1, suitPile2, suitPile3, suitPile4, cardPile1, cardPile2, cardPile3, cardPile4, cardPile5, cardPile6,cardPile7, };

      foreach( PileOfCards pile in pilesOfCards ) {
        // NOTE: Use VisualOperations.HitTest so that it works when an item is dropped
        // not just when picking an item from a list
        //if( pile.InputHitTest(mouse.GetPosition(pile)) != null )
        if( VisualOperations.HitTest(pile, mouse.GetPosition(pile)) != null ) { return pile; }
      }

      return null;
    }

    // NOTE: Should be able to data bind, but nothing seems to be bindable for Window width...
    // TODO: Try to bind to ActualWidth, per John Gossman
    protected override void OnSizeChanged(EventArgs e) {
      double height = this.RenderSize.Width / 7.0 * CardControl.HeightWidthRatio;
      height += 3 * height * CardControl.HeightUnderDownRatio;
      topRow.Height = new GridLength(height);
    }

  }

}
