﻿using System;
using System.Windows;
using System.ComponentModel;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Data;
using System.Windows.Input;
using Solitaire.Domain;
using System.Diagnostics;
using System.Windows.Media;
using System.Globalization;

namespace CardControls {
  /// <summary>
  /// To use custom controls in markup, you currently need to have them
  /// built into a separate assembly (TODO: test this requirement in Avalon CTP).
  /// .xaml pages that want to use the control need to have a mapping
  /// PI (Processing Instruction) before the root element:
  ///
  /// <?Mapping XmlNamespace="CardControls" ClrNamespace="CardControls" Assembly="CardControls" ?>
  /// 
  /// OR, if the usage is in the same assembly, you can do the following:
  /// 
  /// <?Mapping XmlNamespace="CardControls" ClrNamespace="CardControls" ?>
  /// 
  /// NOTE: If the control's in the same assembly, adding the Assembly attribute will cause
  /// the compiler to look for a compiled assembly, which will cause a compiler error, whereas
  /// if the Assembly attribute is left off, it'll do some lazy evaluation against types in
  /// the current assembly (wahoo!).
  ///
  /// Then in the root tag of the .xaml, define a new namespace prefix:
  ///
  /// <DockPanel xmlns:cc="CardControls" ... >
  ///
  /// Then go ahead and use your control in the .xaml somewhere.
  ///
  /// <cc:PileOfCards MyProperty="Hello World" />
  /// </summary>
  public partial class PileOfCards : Canvas {
    public StackOfCards StackOfCards {
      get { return this.DataContext as StackOfCards; }
      set {
        this.DataContext = value;
//        if( value == null ) {
//          return;
//        }
//
//        ListCollectionView view = (ListCollectionView)Binding.GetDefaultView(this.StackOfCards);
//
//        // TODO: why would this happen?
//        if( view == null )
//          return;
//        view.Filter = (new StackFilter(this.StackOfCards)).FilterCallback;
//        view.Refresh();
      }
    }

//    void PileOfCards_Drop(object sender, DragEventArgs e) {
//      if( e.Data == null || e.Effects == DragDropEffects.None ) {
//        e.Effects = DragDropEffects.None;
//        return;
//      }
//
//      e.Effects = DragDropEffects.Move;
//
//      Debug.Assert(e.Data.GetData(typeof(Game)) != null);
//      EndDrag((Game)e.Data.GetData(typeof(Game)));
//      e.Handled = true;
//    }
//
    // Manually pump the Avalon message queue in the background
    // NOTE: There should be some kind of DoEvents or Refresh method in the future
    public void Refresh() {
      System.Diagnostics.Debug.WriteLine("PileOfCards.Refresh()");
      System.Threading.UIDispatcherFrame frame = new System.Threading.UIDispatcherFrame();
      System.Threading.UIContext.CurrentContext.BeginInvoke(delegate(object obj) { frame.ExitRequested = true; return null; }, null, System.Threading.UIContextPriority.Background);
      System.Threading.UIDispatcher.CurrentDispatcher.PushFrame(frame);
    }

    int GetCardIndex(MouseDevice mouse) {
      // DONE
      FrameworkElement elementDirectlyOver = mouse.DirectlyOver as FrameworkElement;
      if( elementDirectlyOver == null )
        return -1;

      Card cardClickedOn = elementDirectlyOver.DataContext as Card;
      if( cardClickedOn == null )
        return -1;

      int index = 0;
      foreach( Card card in this.StackOfCards ) {
        if( cardClickedOn == card )
          return index;

        ++index;
      }

      return -1;
    }

    public DragStack StartDrag(Game game, MouseDevice mouse) {
      int index = GetCardIndex(mouse);

      if( index < 0 )
        return null;

      Card[] cards = game.PickupCards(this.StackOfCards, index);
      return (cards.Length != 0 ? new DragStack(cards) : null);
    }

    public void EndDrag(Game game) {
      game.DropCards(this.StackOfCards);
    }

  }

  public class FlippedToFaceDownIndicatorVisibilityConverter : IValueConverter {
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
      Debug.Assert(value is CardFlipped);
      Debug.Assert(targetType == typeof(Visibility));

#if DEBUG
      return ((CardFlipped)value == CardFlipped.FaceDown ? Visibility.Visible : Visibility.Hidden);
#else
      return Visibility.Hidden;
#endif
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) {
      Debug.Assert(false, "FlippedToFaceDownIndicatorVisibilityConverter.ConvertBack should not be called");
      return value;
    }
  }

  public class FlippedToFaceUpIndicatorVisibilityConverter : IValueConverter {
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
      Debug.Assert(value is CardFlipped);
      Debug.Assert(targetType == typeof(Visibility));

#if DEBUG
      return Visibility.Visible;
#else
      return ((CardFlipped)value == CardFlipped.FaceUp ? Visibility.Visible : Visibility.Hidden);
#endif
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) {
      Debug.Assert(false, "FlippedToFaceUpIndicatorVisibilityConverter.ConvertBack should not be called");
      return value;
    }
  }

  public class FlippedToBackgroundConverter : IValueConverter {
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
      Debug.Assert(value is CardFlipped);
      Debug.Assert(targetType == typeof(Brush));

      return ((CardFlipped)value == CardFlipped.FaceDown ? Brushes.DarkBlue : Brushes.WhiteSmoke);
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) {
      Debug.Assert(false, "FlippedToBackgroundConverter.ConvertBack should not be called");
      return value;
    }
  }

  public class SuitToForegroundConverter : IValueConverter {
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
      Debug.Assert(value is CardSuit);
      Debug.Assert(targetType == typeof(Brush));
      Debug.Assert((int)CardSuit.Heart == 0);

      // Heart, Diamond, Spade and Club in brush colors
      Brush[] foregrounds = { Brushes.Red, Brushes.Red, Brushes.Black, Brushes.Black };
      return foregrounds[(int)value];
    }

    public object ConvertBack(object value, System.Type targetType, object parameter, System.Globalization.CultureInfo culture) {
      Debug.Assert(false, "SuitToForegroundConverter.ConvertBack should not be called");
      return value;
    }

  }

  public class SuitToContentConverter : IValueConverter {
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
      Debug.Assert(value is CardSuit);
      Debug.Assert((int)CardSuit.Heart == 0);

      // Heart, Diamond, Spade and Club in Symbol font
      const string textContents = "©¨ª§";
      return textContents[(int)value].ToString();
    }

    public object ConvertBack(object value, System.Type targetType, object parameter, System.Globalization.CultureInfo culture) {
      Debug.Assert(false, "SuitToContentConverter.ConvertBack should not be called");
      return value;
    }

  }

  public class RankToContentConverter : IValueConverter {
    public object Convert(object value, System.Type targetType, object parameter, System.Globalization.CultureInfo culture) {
      Debug.Assert(value is CardRank);
      Debug.Assert((int)CardRank.Ace == 1);

      const string textContents = "A23456789TJQK";
      if( (int)value == 10 ) { return "10"; }
      return textContents[(int)value - 1].ToString();
    }

    public object ConvertBack(object value, System.Type targetType, object parameter, System.Globalization.CultureInfo culture) {
      Debug.Assert(false, "RankToContentConverter.ConvertBack should not be called");
      return value;
    }

  }

//  class StackFilter {
//    StackOfCards stack;
//
//    public StackFilter(StackOfCards stack) {
//      this.stack = stack;
//    }
//
//    int GetCardsToShow() {
//      switch( this.stack.CardStackType ) {
//      case CardStackType.Card:
//        return 3;
//      case CardStackType.Discard:
//        return 3;
//      case CardStackType.Draw:
//        return 1;
//      case CardStackType.Suit:
//        return 1;
//
//      default:
//        Debug.Assert(false, "Unknown CardStackType: " + this.stack.CardStackType);
//        return int.MaxValue;
//    }
//  }
//
//  public bool FilterCallback(object item) {
//    return true;
//
//    // TODO
//    Card card = (Card)item;
//    int count = Math.Min(this.stack.Count, GetCardsToShow());
//    int bottom = this.stack.Count - count;
//    for( int i = bottom; i != count; ++i ) {
//      if( card == this.stack[i] )
//        return true;
//    }
//
//    return false;
//  }

  }

