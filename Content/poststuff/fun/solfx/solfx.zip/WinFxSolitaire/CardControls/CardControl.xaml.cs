﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Diagnostics;
using Solitaire.Domain;
using System.Windows.Resources;
using Generated;
using System.ComponentModel;
using System.Collections;
using System.Collections.Generic;


namespace CardControls {
  public partial class CardControl : FlowPanel {
    // In sol.exe, the card bitmaps are 71 wide x 96 high:
    public const double HeightWidthRatio = 96.0 / 71.0;

    // 3/96 is sol.exe proportion:
    public const double HeightUnderDownRatio = 3.0 / 96.0;

    // 15/96 is sol.exe proportion:
    public const double HeightUnderUpRatio = 15.0 / 96.0;

    public override void EndInit() {
      base.EndInit();
      this.DataContextChanged += CardControl_DataContextChanged;
    }

//    protected override void OnInitialized(EventArgs args) {
//      base.OnInitialized(args);
//      this.DataContextChanged += CardControl_DataContextChanged;
//    }

    #region Canvas-based resource code
#if FALSE
    //static string folder = "ClassicCards";
    static string folder = "PeterCards";
    static IResourceLoader loader = new ResourceLoader();
    FrameworkElement cardBack = null;
    public FrameworkElement CardBack {
      get {
        if( this.cardBack == null ) {
          // Load resource for card back
          string resourceName = "cardback.xaml";
          FrameworkElement cardXaml = CardControl.loader.LoadResource(resourceName) as FrameworkElement;
          Debug.Assert(cardXaml != null);
          Viewbox viewbox = new Viewbox();
          viewbox.Child = cardXaml;
          this.cardBack = viewbox;
        }

        return this.cardBack;
      }
    }

    FrameworkElement cardFront = null;
    public FrameworkElement CardFront {
      get {
        if( this.cardFront == null ) {
          Card card = this.DataContext as Card;
          if( card != null ) {
            // Load resource for card
            string resourceName = GetCardResourceName(folder, card);
            FrameworkElement cardXaml = CardControl.loader.LoadResource(resourceName) as FrameworkElement;
            Debug.Assert(cardXaml != null);
            Viewbox viewbox = new Viewbox();
            viewbox.Child = cardXaml;
            this.cardFront = viewbox;
          }
        }

        return this.cardFront;
      }
    }

    void CardControl_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e) {
      // Invalidate card face cache
      this.cardFront = null;

      // Pre-load the cache
      FrameworkElement dummy1 = this.CardFront;
      FrameworkElement dummy2 = this.CardBack;

      // Notice when card state changes (specifically, Flipped property)
      Card card = this.DataContext as Card;
      if( card != null ) { card.PropertyChanged += card_PropertyChanged; }

      // Reset the look
      SetCardElement();
    }

    void card_PropertyChanged(object sender, PropertyChangedEventArgs e) {
      // Flip the card
      if( e.PropertyName == "Flipped" ) { SetCardElement(); }
    }

    void SetCardElement() {
      this.Children.Clear();
      Card card = this.DataContext as Card;
      if( card == null ) { return; }
      this.Children.Add(card.Flipped == CardFlipped.FaceUp ? this.CardFront : this.CardBack);
    }

    // GetCardResourceName implementation
    #region GetCardResourceName
    // TODO: replace with message with something more reasonable, e.g. a manifest file of some kind...
    static string GetCardResourceName(string folder, Card card) {
      string rankString = "A23456789TJQK";
      Debug.Assert((int)CardRank.Ace == 1);

      string name = folder + "/";

      switch( folder ) {
      case "ClassicCards":
        // Name format: {folder}/{suit}{rank}.dib.svg.xaml
        // suit one of: cl, dm, ht, sp
        // rank one of: a, 2-9, 10, j, q, k
        switch( card.Suit ) {
        case CardSuit.Club:
          name += "cl";
          break;
        case CardSuit.Diamond:
          name += "dm";
          break;
        case CardSuit.Heart:
          name += "ht";
          break;
        case CardSuit.Spade:
          name += "sp";
          break;
        default: {
            string message = "Unknown suit:" + card.Suit.ToString();
            Debug.Assert(false, message);
            throw new Exception(message);
          }
      }

        if( card.Rank == CardRank.Ten ) { name += "10"; }
        else { name += rankString[(int)card.Rank - 1]; }

        name += ".dib.svg.xaml";
        break;
      case "PeterCards":
        // Name format: {folder}/{suit}{rank}.xaml
        // suit one of: c, d, h, s
        // rank one of: a, 2-9, 10, j, q, k
        name += card.Suit.ToString()[0];
        if( card.Rank == CardRank.Ten ) { name += "10"; }
        else { name += rankString[(int)card.Rank - 1]; }
        name += ".svg.xaml";
        break;

      default: {
          string message = "Unknown card folder:" + folder;
          Debug.Assert(false, message);
          throw new Exception(message);
        }
    }

      return name.ToLower();
    }
    #endregion
#endif
#endregion

    #region Hard-coded DrawingBrush-based code
    Dictionary<string, DrawingBrush> brushMap = new Dictionary<string, DrawingBrush>();

    void CardControl_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e) {
      // Notice when card state changes (specifically, Flipped property)
      Card card = this.DataContext as Card;
      if( card != null ) { card.PropertyChanged += card_PropertyChanged; }

      // Reset the look
      SetCardElement();
    }

    void card_PropertyChanged(object sender, PropertyChangedEventArgs e) {
      // Flip the card
      if( e.PropertyName == "Flipped" ) { SetCardElement(); }
    }

    // TODO: replace with message with something more reasonable,
    // e.g. a manifest file of some kind...
    string GetCardBrushName(Card card) {
      Debug.Assert(card != null);

      // Card back
      if( card.Flipped == CardFlipped.FaceDown ) { return "MsdnCardBack.svg.xaml"; }

      // Card front
      Debug.Assert(card.Flipped == CardFlipped.FaceUp);

      string rankString = "A23456789TJQK";
      Debug.Assert((int)CardRank.Ace == 1);

      // Name format: {suit}{rank}.svg.xaml
      // suit one of: c, d, h, s
      // rank one of: a, 2-9, 10, j, q, k
      string name = "";
      name += card.Suit.ToString()[0];
      if( card.Rank == CardRank.Ten ) { name += "10"; }
      else { name += rankString[(int)card.Rank - 1]; }
      name += ".svg.xaml";
      return name.ToLower();
    }

    Brush GetCardBrush(Card card) {
      if( card == null ) { return null; }
      string brushName = GetCardBrushName(card);
      if( !this.brushMap.ContainsKey(brushName) ) {
        this.brushMap[brushName] = (DrawingBrush)this.Resources[GetCardBrushName(card)];
      }

      return this.brushMap[brushName];
    }

    void SetCardElement() {
      this.Background = GetCardBrush(this.DataContext as Card);
    }
    #endregion

    protected override Size MeasureOverride(Size availableSize) {
      Size size = base.MeasureOverride(availableSize);
      //Debug.WriteLine(string.Format("MeasureOveride(availableSize= {0}) returns Size= {1} (DataContext= {2})", availableSize, size, this.DataContext));

      // Width of a card is always the available space
      size.Width = availableSize.Width;

      // Nominal height is in proportion to the width
      size.Height = size.Width * HeightWidthRatio;

      // Height depends on the type of pile, their position in the pile and/or their state:
      StackOfCards cards = FindStackOfCards();
      Card card = this.DataContext as Card;

      // TODO: Why would this happen?
      if( cards == null || card == null ) {
        return size;
      }

      Debug.Assert(cards != null);
      Debug.Assert(card != null);
    //      Debug.WriteLine(string.Format("StackOfCards= {0}", cards));
    //      Debug.WriteLine(AvalonUtility.GetVisualTreeInfo(this));

      // Draw pile: for now, all of the cards have Height 0 except the top card
      // but it should be offset a tiny bit in X & Y to match sol.exe
      if( cards is DrawPile ) {
        // Give Height to top n cards in DrawPile like sol.exe based on how many cards in pile:
        // > 20 == 3 cards
        // > 10 == 2 cards
        // > 0  == 1 card
        // 0    == 0 cards

        int cardsOnTop = 0;
        if( cards.Count > 20 ) {
          cardsOnTop = 3;
        }
        else if( cards.Count > 10 ) {
          cardsOnTop = 2;
        }
        else if( cards.Count > 0 ) {
          cardsOnTop = 1;
        }

        if( !cards.IsTopCard(card) ) {
          if( cards.InTopCards(card, cardsOnTop) ) {
            size.Height *= HeightUnderDownRatio;
          }
          else {
            size.Height = 0;
          }
        }
      }
      // Discard pile: for now, all of the cards have Height 0 except top card
        // but it should be offset quite a bit in X and a tiny bit in Y to match sol.exe
      else if( cards is DiscardPile ) {
        // Give Height to top n cards based on how many cards are being drawn at once
        int cardsOnTop = Math.Min(cards.Count, 3); // TODO: get cards drawn from the Game instead of hard-coding to 3
        if( !cards.IsTopCard(card) ) {
          if( cards.InTopCards(card, cardsOnTop) ) {
            size.Height *= HeightUnderDownRatio;
          }
          else {
            size.Height = 0;
          }
        }
      }
      // SuitStack: all of the cards have Height 0 except the top card
      else if( cards is SuitStack ) {
        if( !cards.IsTopCard(card) ) {
          size.Height = 0;
        }
      }
      // CardStack: all of the FaceDown cards have a small Height and all of the FaceUp
      // cards have a larger Height
      // DrawStack: just like CardStack except that all cards will be FaceUp
      else if( cards is CardStack || cards is DragStack ) {
        if( !cards.IsTopCard(card) ) {
          if( card.Flipped == CardFlipped.FaceDown ) {
            // Scale based on height
            size.Height *= HeightUnderDownRatio;
          }
          else {
            // Scale based on height
            size.Height *= HeightUnderUpRatio;
          }
        }
      }
      else {
        string message = string.Format("Unknown stack type: {0}", cards.GetType());
        Debug.Assert(false, message);
        throw new Exception(message);
      }

      return size;
    }

    StackOfCards FindStackOfCards() {
      // Navigate the visual tree looking for the PileOfCards controls
      Visual parent = VisualOperations.GetParent(this);
      while( parent != null ) {
        if( parent is PileOfCards ) {
          // Pull out the StackOfCards that this card is in
          return ((PileOfCards)parent).DataContext as StackOfCards;
        }
        parent = VisualOperations.GetParent(parent);
      }

      return null;
    }
  }
}
