﻿#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

#endregion

namespace Solitaire.Domain {
    public class GameTimer {
        public GameTimer() {
            m_gameTimer = new System.Timers.Timer();
            m_gameTimer.Interval = 1000;   // Ticks every 1 second
            m_gameTimer.AutoReset = true;
            Reset();
        }

        public event EventHandler TimeChanged;

        private void RaiseTimeChanged() {
            if (this.TimeChanged != null) {
                TimeChanged(this, EventArgs.Empty);
            }
        }

        public void Start() {
            m_gameTimer.Enabled = true;
        }

        public void Stop() {
            m_gameTimer.Enabled = false;
        }

        public void Reset() {
            Stop();
            m_gameSeconds = 0;
            RaiseTimeChanged();
        }

        public int Time {
            get {
                return m_gameSeconds;
            }
        }

        private void gameTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e) {
            m_gameSeconds++;
            RaiseTimeChanged();
        }

        private System.Timers.Timer m_gameTimer;
        private int m_gameSeconds;
    }
}
