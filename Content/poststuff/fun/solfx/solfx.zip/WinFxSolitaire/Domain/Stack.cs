using System;
using System.ComponentModel;
using System.Collections; // IEnumerable
using System.Collections.Generic;

namespace Solitaire.Domain {
  public enum CardStackType {
    Card,
    Discard,
    Draw,
    Suit,
  };

  // DONE: Avalon CTP doesn't provide views for IEnumerable, so had to implement IList
  //public abstract class StackOfCards : IEnumerable, ICollectionChange {
  public abstract class StackOfCards : IList, ICollectionChange {
    internal StackOfCards(Deck deck, int numCards) {
      for( uint i = 0; i < numCards; i++ ) {
        m_cards.Add(deck.DrawCard());
      }
    }

    #region IEnumerable Members
    public IEnumerator GetEnumerator() {
      return (IEnumerator)m_cards.GetEnumerator();
    }
    #endregion

    #region ICollectionChange
    public event CollectionChangeEventHandler CollectionChanged;

    void RaiseCollectionChanged(CollectionChangeAction action, object obj) {
      if( this.CollectionChanged != null ) {
        System.Diagnostics.Debug.WriteLine(string.Format("StackOfCards.RaiseCollectionChanged({0})", action));
        CollectionChanged(this, new CollectionChangeEventArgs(action, obj));
      }
    }
    #endregion

    #region IList Members
    public int Add(object value) {
      throw new NotImplementedException();
    }

    public void Clear() {
      throw new NotImplementedException();
    }

    public bool Contains(object value) {
      return m_cards.Contains((Card)value);
    }

    public int IndexOf(object value) {
      return m_cards.IndexOf((Card)value);
    }

    public void Insert(int index, object value) {
      throw new NotImplementedException();
    }

    public bool IsFixedSize {
      get {
        return ((IList)m_cards).IsFixedSize;
      }
    }

    public bool IsReadOnly {
      get {
        return ((IList)m_cards).IsReadOnly;
      }
    }

    public void Remove(object value) {
      throw new NotImplementedException();
    }

    public void RemoveAt(int index) {
      throw new NotImplementedException();
    }

    public object this[int index] {
      get {
        return m_cards[index];
      }
      set {
        throw new NotImplementedException();
      }
    }
    #endregion

    #region ICollection Members
    public void CopyTo(Array array, int index) {
      throw new NotImplementedException();
    }

    public int Count {
      get {
        return m_cards.Count;
      }
    }

    public bool IsSynchronized { get { return ((ICollection)m_cards).IsSynchronized; } }

    // TODO: Aha! The data binding is accessing the SyncRoot, which
    // avoids the ICollectionChange implementation
    //public object SyncRoot { get { throw new NotImplementedException(); } }
    // NOTE: This is a completely incorrect implementation, but it'll get me by
    // 'til Avalon data binding works with an IEnumerable again...
    public object SyncRoot { get { return this; } }
    #endregion

    public Card GetCard(int i) {
      return m_cards[i];
    }

    internal Card[] GrabCards(int i) {
      if( !VerifyGrab(i) )
        return new Card[0];

      Card[] cards = new Card[m_cards.Count - i];
      m_cards.CopyTo(i, cards, 0, m_cards.Count - i);
      m_cards.RemoveRange(i, m_cards.Count - i);

      // TODO: optimize for Remove instead of Refresh
      RaiseCollectionChanged(CollectionChangeAction.Refresh, null);
      return cards;
    }

    internal bool DropCards(Card[] cards) {
      if( !VerifyDrop(cards) )
        return false;

      foreach( Card c in cards ) {
        m_cards.Add(c);
        // TODO: optimize for Add instead of Refresh
        //RaiseCollectionChanged(CollectionChangeAction.Add, c);
      }

      RaiseCollectionChanged(CollectionChangeAction.Refresh, null);
      return true;
    }

    internal void ReturnCards(Card[] cards) {
      foreach( Card c in cards ) {
        m_cards.Add(c);
        // TODO: optimize for Add instead of Refresh
        //RaiseCollectionChanged(CollectionChangeAction.Add, c);
      }
      RaiseCollectionChanged(CollectionChangeAction.Refresh, null);
    }

    protected abstract bool VerifyGrab(int i);
    protected abstract bool VerifyDrop(Card[] cards);

    public abstract CardStackType CardStackType { get; }

    protected List<Card> m_cards = new List<Card>();
  }
}
