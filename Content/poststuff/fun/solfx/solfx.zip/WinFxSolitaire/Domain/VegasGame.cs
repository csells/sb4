using System;

namespace Solitaire.Domain
{
	/// <summary>
	/// Summary description for VegasGame.
	/// </summary>
	public class VegasGame : Game
	{
		internal VegasGame(DrawType drawType) : base(drawType) {
			m_scoreTimer = new System.Timers.Timer();
			m_scoreTimer.Interval = 10000;
			m_scoreTimer.Elapsed += new System.Timers.ElapsedEventHandler(this.scoreTimer_Elapsed);

			// Move this to when first card moved
			m_scoreTimer.Enabled = true;
		}

		private void scoreTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e) {
			this.Score -= 2;
		}

		private System.Timers.Timer m_scoreTimer;
	}
}
