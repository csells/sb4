﻿#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

#endregion

namespace Solitaire.Domain {
    public class NoScoringStrategy : ScoringStrategy {
        public NoScoringStrategy() {
        }
    }
}
