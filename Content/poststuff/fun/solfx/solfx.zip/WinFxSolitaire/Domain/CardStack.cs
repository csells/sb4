using System;

namespace Solitaire.Domain {
    /// <summary>
    /// Summary description for CardStack.
    /// </summary>
    public class CardStack : StackOfCards {
        internal CardStack() {
        }

        internal override void ClearAndDealCards(Deck deck, int numCards) {
            base.ClearAndDealCards(deck, numCards);
            if (numCards > 0) {
                m_cards[m_cards.Count - 1].Flipped = CardFlipped.FaceUp;
            }
        }

        protected override bool VerifyGrab(int cardIndex) {
            if (cardIndex < 0 || cardIndex >= m_cards.Count) {
                throw new ArgumentOutOfRangeException("i", cardIndex, "No card in stack at that index");
            }

            // Verify that all grabbed cards are flipped
            for (int i = cardIndex; i < m_cards.Count; i++) {
                if (m_cards[i].Flipped == CardFlipped.FaceDown) {
                    return false;
                }
            }
            return true;
        }

        protected override bool VerifyDrop(Card[] cards) {
            int targetCount = m_cards.Count;
            Card bottomSourceCard = cards[0];

            if (targetCount == 0 && bottomSourceCard.Rank == CardRank.King) return true;

            if (targetCount == 0) return false;

            bool bottomSourceCardIsBlack = (bottomSourceCard.Suit == CardSuit.Club || bottomSourceCard.Suit == CardSuit.Spade);
            Card topTargetCard = m_cards[targetCount - 1];
            bool topTargetCardIsBlack = (topTargetCard.Suit == CardSuit.Club || topTargetCard.Suit == CardSuit.Spade);

            if ((int)topTargetCard.Rank - (int)bottomSourceCard.Rank != 1) return false;

            if (topTargetCardIsBlack && bottomSourceCardIsBlack) return false;

            if (!topTargetCardIsBlack && !bottomSourceCardIsBlack) return false;

            if (bottomSourceCard.Rank == CardRank.Ace) return false;

            return true;
        }
    }
}
