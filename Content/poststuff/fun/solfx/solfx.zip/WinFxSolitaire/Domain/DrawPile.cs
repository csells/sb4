using System;
using System.Diagnostics;

namespace Solitaire.Domain {
    /// <summary>
    /// Summary description for DrawPile.
    /// </summary>
    public class DrawPile : StackOfCards {
        internal DrawPile() {
        }

        protected override bool VerifyGrab(int i) {
            return i < m_cards.Count;
        }

        protected override bool VerifyDrop(Card[] cards) {
            return true;
        }
    }
}
