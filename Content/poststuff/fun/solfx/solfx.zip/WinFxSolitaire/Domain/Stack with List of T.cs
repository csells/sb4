using System;
using System.ComponentModel;
//using System.Collections; // IEnumerable
using System.Collections.Generic;

namespace Solitaire.Domain {
  public enum CardStackType {
    Card,
    Discard,
    Draw,
    Suit,
  };

  // DONE: Needed to get data bound view (requires IList implementation)
  //public abstract class StackOfCards : IEnumerable, ICollectionChange {
  public abstract class StackOfCards : List<Card>, ICollectionChange {
    #region ICollectionChange
    public event CollectionChangeEventHandler CollectionChanged;

    void RaiseCollectionChanged(CollectionChangeAction action, object obj) {
      System.Diagnostics.Debug.WriteLine(string.Format("StackOfCards.RaiseCollectionChanged({0})", action));
      if( this.CollectionChanged != null )
        CollectionChanged(this, new CollectionChangeEventArgs(action, obj));
    }
    #endregion

    internal StackOfCards(Deck deck, int numCards) {
      //m_cards = new List<Card>();
      for( uint i = 0; i < numCards; i++ ) {
        //m_cards.Add(deck.DrawCard());
        base.Add(deck.DrawCard());
      }
    }

//    public Card this[int i] {
//      get {
//        return m_cards[i];
//      }
//    }
//
//    public int Count {
//      get {
//        return m_cards.Count;
//      }
//    }

//    #region IEnumerable Members
//    public IEnumerator GetEnumerator() {
//      return (IEnumerator)m_cards.GetEnumerator();
//    }
//    #endregion

//    #region ICollectionViewFactory Members
//    CollectionView ICollectionViewFactory.CreateView() {
//      System.Reflection.Assembly assem = System.Reflection.Assembly.Load("PresentationFramework, version=6.0.4030.0, Culture=neutral, PublicKeyToken=31BF3856AD364E35");
//      return (CollectionView)assem.CreateInstance("MS.Internal.Data.ArrayListCollectionView", false, System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic, null, new object[] { this }, null, null);
//
////      Type arrayListDataCollectionType = Type.GetType("MS.Internal.Data.ArrayListCollectionView");
////      return (CollectionView)Activator.CreateInstance("PresentationFramework", "MS.Internal.Data.ArrayListCollectionView").Unwrap();
//    }
//    #endregion

    #region IList<Card> overrides to disable non-stack-like behavior
    public void Insert(int index, Card item) {
      throw new NotImplementedException();
    }

    public void RemoveAt(int index) {
      throw new NotImplementedException();
    }
    #endregion

    #region ICollection<Card> overrides to disable non-stack-like behavior
    public void Add(Card item) {
      throw new NotImplementedException();
    }

    public void Clear() {
      throw new NotImplementedException();
    }

    public bool Remove(Card item) {
      throw new NotImplementedException();
    }
    #endregion

    #region IList overrides to disable non-stack-like behavior
    public void Insert(int index, object item) {
      throw new NotImplementedException();
    }
    #endregion

    #region ICollection overrides to disable non-stack-like behavior
    public void Add(object item) {
      throw new NotImplementedException();
    }

    public bool Remove(object item) {
      throw new NotImplementedException();
    }
    #endregion

    internal Card[] GrabCards(int i) {
      if( !VerifyGrab(i) )
        return new Card[0];

      //cards = new Card[m_cards.Count - i];
      Card[] cards = new Card[base.Count - i];
//        m_cards.CopyTo(i, cards, 0, m_cards.Count - i);
//        m_cards.RemoveRange(i, m_cards.Count - i);
      base.CopyTo(i, cards, 0, base.Count - i);
      base.RemoveRange(i, base.Count - i);

      // TODO: optimize for Remove instead of Refresh
      RaiseCollectionChanged(CollectionChangeAction.Refresh, null);
      return cards;
    }

    internal bool DropCards(Card[] cards) {
      if( !VerifyDrop(cards) )
        return false;

      foreach( Card c in cards ) {
        //m_cards.Add(c);
        base.Add(c);
        // TODO: optimize for Add instead of Refresh
        //RaiseCollectionChanged(CollectionChangeAction.Add, c);
      }

      RaiseCollectionChanged(CollectionChangeAction.Refresh, null);
      return true;
    }

    internal void ReturnCards(Card[] cards) {
      foreach( Card c in cards ) {
        //m_cards.Add(c);
        base.Add(c);
        // TODO: optimize for Add instead of Refresh
        //RaiseCollectionChanged(CollectionChangeAction.Add, c);
        RaiseCollectionChanged(CollectionChangeAction.Refresh, null);
      }
    }

    protected abstract bool VerifyGrab(int i);
    protected abstract bool VerifyDrop(Card[] cards);

    public abstract CardStackType CardStackType { get; }

    //protected List<Card> m_cards;
  }
}
