using System;
using System.ComponentModel;

namespace Solitaire.Domain {
    public class Card : IPropertyChange {
        public event PropertyChangedEventHandler PropertyChanged;

        private void RaisePropertyChanged(string propertyName) {
            if (this.PropertyChanged != null) {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public Card(CardSuit cardSuit, CardRank cardRank) {
            m_suit = cardSuit;
            m_rank = cardRank;
            m_flipped = CardFlipped.FaceDown;
        }

        public CardSuit Suit { get { return m_suit; } }

        public CardRank Rank { get { return this.m_rank; } }

        public CardFlipped Flipped {
            get { return m_flipped; }
            set {
                if (value != m_flipped) {
                    m_flipped = value;
                    RaisePropertyChanged("Flipped");
                }
            }
        }

        private CardSuit m_suit;
        private CardRank m_rank;
        private CardFlipped m_flipped;
    }
}
