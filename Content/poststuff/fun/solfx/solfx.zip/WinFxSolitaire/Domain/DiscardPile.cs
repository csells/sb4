using System;

namespace Solitaire.Domain {
    /// <summary>
    /// Summary description for DiscardPile.
    /// </summary>
    public class DiscardPile : StackOfCards {
        internal DiscardPile() {
        }

        protected override bool VerifyGrab(int i) {
            // Either user is grabbing top card or Game is grabbing all cards to put back in draw pile
            // TODO: make sure user can't grab all cards, just Game
            return i == m_cards.Count - 1 || i == 0;
        }

        protected override bool VerifyDrop(Card[] cards) {
            return true;
        }
    }
}
