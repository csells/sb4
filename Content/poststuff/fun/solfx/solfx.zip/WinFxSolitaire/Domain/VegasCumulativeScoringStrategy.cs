﻿using System;

namespace Solitaire.Domain {
    /// <summary>
    /// Summary description for VegasGameScoringStrategy.
    /// </summary>
    public class VegasCumulativeScoringStrategy : ScoringStrategy {
        public VegasCumulativeScoringStrategy() {
        }

        public override void ScoreStartNewHand() {
            this.Score -= 52;
        }

        public override void ScoreCardToSuitStack() {
            this.Score += 5;
        }

        public override void ScoreCardFromSuitStack() {
            this.Score -= 5;
        }
    }
}
