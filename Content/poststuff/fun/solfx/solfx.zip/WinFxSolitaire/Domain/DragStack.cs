using System;

namespace Solitaire.Domain {
  /// <summary>
  /// Summary description for DragStack.
  /// </summary>
  public class DragStack : StackOfCards {
    public DragStack(Card[] cards) {
      base.DropCards(cards, false);
    }

    protected override bool VerifyGrab(int cardIndex) {
      return cardIndex < m_cards.Count;
    }

    protected override bool VerifyDrop(Card[] cards) {
      foreach( Card card in cards ) {
        if( card.Flipped == CardFlipped.FaceDown ) { return false; }
      }
      return true;
    }
  }
}
