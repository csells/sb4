using System;

namespace Solitaire.Domain {
  public class SuitStack : StackOfCards {
    internal SuitStack() {
    }

    protected override bool VerifyGrab(int i) {
      if( i > 1 )
        return false;
      return true;
    }

    protected override bool VerifyDrop(Card[] cards) {
      if( !(cards.Length == 1) ) {
        return false;
      }

      Card card = cards[0];

      if( m_cards.Count == 0 && card.Rank == CardRank.Ace ) {
        return true;
      }
      else if( m_cards.Count > 0 && (int)m_cards[m_cards.Count - 1].Rank == (int)card.Rank - 1 ) {
        return true;
      }
      else {
        return false;
      }
    }
  }
}
