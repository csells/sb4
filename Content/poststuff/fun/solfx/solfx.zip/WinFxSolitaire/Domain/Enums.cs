using System;

namespace Solitaire.Domain
{
	public enum DrawType
	{
		One,
		Three
	}
	public enum ScoringType
	{
		None = 0,
		Standard = 1,
		Vegas = 2,
		VegasCumulative = 3
	}
	
	public enum CardSuit {
		Heart,
		Diamond,
		Spade,
		Club
	}

	public enum CardRank {
		Ace = 1,
		Two,
		Three,
		Four,
		Five,
		Six,
		Seven,
		Eight,
		Nine,
		Ten,
		Jack,
		Queen,
		King
	}

    public enum CardFlipped {
        FaceDown = 0,
        FaceUp
    }
}
