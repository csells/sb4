using System;

namespace Solitaire.Domain {
	/// <summary>
	/// The factory pattern is used to create new games. This will isolate the game UI from
	/// whether the Game class implements scoring or whether we will use subclasses to
	/// implement different scoring algorithms.
	/// </summary>
	public class GameFactory {
		public static readonly GameFactory Instance = new GameFactory();

		private GameFactory() {
		}

		/// <summary>
		/// Create a new game of the specified type
		/// </summary>
		/// <param name="drawType">Whether to draw one or three cards from the draw pile</param>
		/// <param name="scoringType">Scoring algorithm to use</param>
		/// <returns></returns>
		public Game CreateNewGame(DrawType drawType, ScoringType scoringType) {
            return CreateNewGame(drawType, scoringType, true);
        }

        /// <summary>
        /// Create a new game of the specified type
        /// </summary>
        /// <param name="drawType">Whether to draw one or three cards from the draw pile</param>
        /// <param name="scoringType">Scoring algorithm to use</param>
        /// <param name="autoFlipTopCard">Whether to automatically flip top draw/stack card if unflipped</param>
        /// <returns></returns>
        public Game CreateNewGame(DrawType drawType, ScoringType scoringType, bool autoFlipTopCard) {
            GameTimer gameTimer = new GameTimer();
            switch (scoringType) {
                case ScoringType.None:
                    return new Game(drawType, new NoScoringStrategy(), gameTimer, autoFlipTopCard);
                case ScoringType.Standard:
                    return new Game(drawType, new StandardScoringStrategy(gameTimer), gameTimer, autoFlipTopCard);
                case ScoringType.Vegas:
                    return new Game(drawType, new VegasScoringStrategy(), gameTimer, autoFlipTopCard);
                case ScoringType.VegasCumulative:
                    return new Game(drawType, new VegasCumulativeScoringStrategy(), gameTimer, autoFlipTopCard);
                default:
                    throw new NotImplementedException();
            }
        }
    }
}
