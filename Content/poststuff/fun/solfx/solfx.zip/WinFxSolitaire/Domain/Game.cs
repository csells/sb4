using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;

namespace Solitaire.Domain {
  public class Game : IPropertyChange {
    internal Game(DrawType drawType, ScoringStrategy scoringStrategy, GameTimer gameTimer, bool autoFlipTopCard) {
      m_gameTimer = gameTimer;
      m_drawType = drawType;
      m_scoringStrategy = scoringStrategy;
      m_scoringStrategy.ScoreChanged += new EventHandler(OnScoreChanged);
      m_gameTimer.TimeChanged += new EventHandler(OnGameTimeChanged);
      m_autoFlipTopCard = autoFlipTopCard;
      m_deck = new Deck();

      // initialize stacks
      m_suitStacks = new SuitStack[4];
      for( int i = 0; i < 4; i++ ) {
        m_suitStacks[i] = new SuitStack();
      }

      m_cardStacks = new CardStack[7];
      for( int i = 0; i < 7; i++ ) {
        m_cardStacks[i] = new CardStack();
      }

      m_discardPile = new DiscardPile();
      m_drawPile = new DrawPile();

      this.DealNewHand();
    }

    public bool AutoFlipTopCard {
      get {
        return m_autoFlipTopCard;
      }
      set {
        m_autoFlipTopCard = value;
      }
    }


    public void DealNewHand() {
      m_deck.Shuffle();
      // DealCards clears the stack and takes cards from the deck
      // So we need to DealCards even if we aren't taking any from the deck
      foreach( SuitStack suitStack in m_suitStacks ) {
        suitStack.ClearAndDealCards(m_deck, 0);
      }

      for( int i = 0; i < m_cardStacks.Length; i++ ) {
        m_cardStacks[i].ClearAndDealCards(m_deck, i + 1);
      }

      m_discardPile.ClearAndDealCards(m_deck, 0);
      m_drawPile.ClearAndDealCards(m_deck, m_deck.Count);

      m_scoringStrategy.ScoreStartNewHand();
    }

    public bool DrawCards() {
      // Check for empty draw pile
      if( m_drawPile.Count == 0 ) {
        if( m_discardPile.Count == 0 )
          return false; // No more cards to draw

        // Move all cards from discard pile to draw pile, flipping them face down
        Card[] cards = PickupCards(m_discardPile, 0);

        foreach( Card card in cards ) {
          card.Flipped = CardFlipped.FaceDown;
        }

        DropCards(m_drawPile, true);
        return true;
      }

      // Figure out how many cards to draw from draw pile
      int cardsToDraw = 0;

      switch( m_drawType ) {
      case DrawType.One:
        cardsToDraw = 1;
        break;
      case DrawType.Three:
        cardsToDraw = 3;
        break;
      default:
        System.Diagnostics.Debug.Assert(false, string.Format("Unknown Draw Type= {0}", m_drawType));
        return false;
    }
    cardsToDraw = Math.Min(cardsToDraw, m_drawPile.Count);

    // Remove cards from draw pile and put them, face up, in the discard pile
    Card[] otherCards = PickupCards(m_drawPile, m_drawPile.Count - cardsToDraw);

    Debug.Assert(otherCards.Length == cardsToDraw);
    foreach( Card card in otherCards ) {
      card.Flipped = CardFlipped.FaceUp;
    }

    DropCards(m_discardPile, true);
    return true;
  }

  public Card[] PickupCards(StackOfCards stack, int cardNum) {
    m_dragging = stack.GrabCards(cardNum);
    if( m_dragging != null && m_dragging.Length > 0 ) {
      m_sourceDragStack = stack;
    }
    return m_dragging;
  }

  public bool DropCards(StackOfCards stack) {
    return DropCards(stack, false);
  }

  public bool DropCards(StackOfCards stack, bool reversed) {
    bool success;

    if( m_dragging == null || m_dragging.Length == 0 ) {
      success = false;
    }
    else {
      success = stack.DropCards(m_dragging, reversed);
      if( !success ) {
        m_sourceDragStack.ReturnCards(m_dragging);
      }
    }

    // Flipping top card on source stack automatically
    if( success && !(m_sourceDragStack is DrawPile) && this.AutoFlipTopCard ) {
      FlipTopCard(m_sourceDragStack);
    }

    // Scoring
    if( success ) {
      if( m_sourceDragStack is SuitStack ) {
        m_scoringStrategy.ScoreCardFromSuitStack();
      }
      if( stack is SuitStack ) {
        m_scoringStrategy.ScoreCardToSuitStack();
      }
    }

    m_dragging = null;
    m_sourceDragStack = null;
    return success;
  }

  public void FlipTopCard(StackOfCards stack) {
    if( stack.Count < 1 )
      return;

    if( stack[stack.Count - 1].Flipped == CardFlipped.FaceDown )
      stack[stack.Count - 1].Flipped = CardFlipped.FaceUp;
  }

  public StackOfCards[] SuitStacks {
    get {
      return m_suitStacks;
    }
  }

  public StackOfCards[] CardStacks {
    get {
      return m_cardStacks;
    }
  }

  public StackOfCards Draw {
    get {
      return m_drawPile;
    }
  }

  public StackOfCards Discard {
    get {
      return m_discardPile;
    }
  }

  public int Score {
    get {
      return m_scoringStrategy.Score;
    }
  }

  public int GameTime {
    get {
      return m_gameTimer.Time;
    }
  }

  public event PropertyChangedEventHandler PropertyChanged;

  private void OnScoreChanged(object sender, EventArgs e) {
    RaisePropertyChanged("Score");
  }

  private void OnGameTimeChanged(object sender, EventArgs e) {
    RaisePropertyChanged("GameTime");
  }

  private void RaisePropertyChanged(string propertyName) {
    if( this.PropertyChanged != null ) {
      PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
    }
  }

  private DrawType m_drawType;
  private ScoringStrategy m_scoringStrategy;
  private DrawPile m_drawPile;
  private DiscardPile m_discardPile;
  private CardStack[] m_cardStacks;
  private SuitStack[] m_suitStacks;
  private Card[] m_dragging;
  private StackOfCards m_sourceDragStack;
  private bool m_autoFlipTopCard;
  private GameTimer m_gameTimer;
  private Deck m_deck;
}
}