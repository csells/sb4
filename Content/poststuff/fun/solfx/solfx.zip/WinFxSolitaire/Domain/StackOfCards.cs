using System;
using System.ComponentModel;
using System.Collections; // IEnumerable
using System.Collections.Generic;

namespace Solitaire.Domain {
  public abstract class StackOfCards : IEnumerable, ICollectionChange {
    public event CollectionChangeEventHandler CollectionChanged;

    private void RaiseCollectionChanged(CollectionChangeAction action, object obj) {
      if( this.CollectionChanged != null ) {
        CollectionChanged(this, new CollectionChangeEventArgs(action, obj));
      }
    }

    internal StackOfCards() {
      m_cards = new List<Card>();
    }

    internal virtual void ClearAndDealCards(Deck deck, int numCards) {
      m_cards.Clear();
      for( int i = 0; i < numCards; i++ ) {
        m_cards.Add(deck.DrawCard());
      }
      RaiseCollectionChanged(CollectionChangeAction.Refresh, null);
    }

    public Card this[int i] {
      get {
        return m_cards[i];
      }
    }

    public int Count {
      get {
        return m_cards.Count;
      }
    }

    public bool IsTopCard(Card card) {
      return InTopCards(card, 1);
    }

    public bool InTopCards(Card card, int n) {
      for( int i = 1; i <= n; ++i ) {
        if( m_cards[m_cards.Count - i] == card ) {
          return true;
        }
      }
      return false;
    }

    #region IEnumerable Members
    public IEnumerator GetEnumerator() {
      return m_cards.GetEnumerator();
    }
    #endregion

    internal Card[] GrabCards(int i) {
      if( i > m_cards.Count || i < 0 ) {
        throw new ArgumentOutOfRangeException("i", i, "Index out of range");
      }
      if( !VerifyGrab(i) ) {
        return new Card[] {};
      }

      Card[] cards = new Card[m_cards.Count - i];
      m_cards.CopyTo(i, cards, 0, m_cards.Count - i);
      m_cards.RemoveRange(i, m_cards.Count - i);

      // TODO: optimize for Remove instead of Refresh
      RaiseCollectionChanged(CollectionChangeAction.Refresh, null);
      return cards;
    }

    internal bool DropCards(Card[] cards, bool reversed) {
      if( !VerifyDrop(cards) ) {
        return false;
      }

      for( int i = 0; i != cards.Length; ++i ) {
        m_cards.Add(cards[reversed ? cards.Length - i - 1 : i]);
        // TODO: optimize for Add instead of Refresh
        //RaiseCollectionChanged(CollectionChangeAction.Add, c);
        RaiseCollectionChanged(CollectionChangeAction.Refresh, null);
      }
      return true;
    }

    internal void ReturnCards(Card[] cards) {
      foreach( Card c in cards ) {
        m_cards.Add(c);
        // TODO: optimize for Add instead of Refresh
        //RaiseCollectionChanged(CollectionChangeAction.Add, c);
        RaiseCollectionChanged(CollectionChangeAction.Refresh, null);
      }
    }

    protected abstract bool VerifyGrab(int i);
    protected abstract bool VerifyDrop(Card[] cards);

    protected List<Card> m_cards;
  }
}
