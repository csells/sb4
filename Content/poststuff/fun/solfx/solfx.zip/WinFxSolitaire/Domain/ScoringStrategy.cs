﻿#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

#endregion

namespace Solitaire.Domain {
    public abstract class ScoringStrategy {
        public ScoringStrategy() {
        }

        public event EventHandler ScoreChanged;

        private void RaiseScoreChanged() {
            if (this.ScoreChanged != null) {
                ScoreChanged(this, EventArgs.Empty);
            }
        }

        public virtual void ScoreStartNewHand() { }
        public virtual void ScoreCardFromSuitStack() {}
        public virtual void ScoreCardToSuitStack() {}
        public virtual void ScoreDiscardToCardStack() { }

        public int Score {
            get {
                return m_score;
            }
            protected set {
                if (value != m_score) {
                    m_score = value;
                    RaiseScoreChanged();
                }
            }
        }

        private int m_score = 0;
    }
}
