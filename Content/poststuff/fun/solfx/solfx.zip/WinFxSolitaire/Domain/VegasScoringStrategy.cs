using System;

namespace Solitaire.Domain
{
	/// <summary>
	/// Summary description for VegasGameScoringStrategy.
	/// </summary>
	public class VegasScoringStrategy : ScoringStrategy
	{
		public VegasScoringStrategy() {
        }

        public override void ScoreStartNewHand() {
            this.Score = 0;
        }

        public override void ScoreCardToSuitStack() {
            this.Score += 5;
        }

        public override void ScoreCardFromSuitStack() {
            this.Score -= 5;
        }
	}
}
