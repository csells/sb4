﻿using System;

namespace Solitaire.Domain {
    /// <summary>
    /// Summary description for VegasGameScoringStrategy.
    /// </summary>
    public class StandardScoringStrategy : ScoringStrategy {
        public StandardScoringStrategy(GameTimer gameTimer) {
            m_gameTimer = gameTimer;
            m_gameTimer.TimeChanged += new EventHandler(StandardScoringStrategy_GameTimeChanged);
        }

        public override void ScoreStartNewHand() {
            this.Score = 0;
        }

        public override void ScoreCardToSuitStack() {
            this.Score += 10;
        }

        public override void ScoreCardFromSuitStack() {
            this.Score -= 10;
        }

        public override void ScoreDiscardToCardStack() {
            this.Score += 5;
        }

        void StandardScoringStrategy_GameTimeChanged(object sender, EventArgs e) {
            if (m_gameTimer.Time % 10 == 0) {    // Decrement score every 10 seconds
                this.Score -= 2;
            }
        }

        private GameTimer m_gameTimer;
    }
}
