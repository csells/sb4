using System;
using System.Collections.Generic;

namespace Solitaire.Domain {
  public class Deck {
    public Deck() {
      m_cards = new List<Card>(52);
      m_allCards = new List<Card>(52);
      foreach( CardSuit suit in Enum.GetValues(typeof(CardSuit)) ) {
        foreach( CardRank val in Enum.GetValues(typeof(CardRank)) ) {
          m_allCards.Add(new Card(suit, val));
        }
      }
      m_random = new Random();
    }

    public void Shuffle() {
      m_cards.Clear();
      m_cards.AddRange(m_allCards);
      foreach( Card c in m_cards ) {
        c.Flipped = CardFlipped.FaceDown;
      }
    }

    public int Count {
      get {
        return m_cards.Count;
      }
    }

    public Card DrawCard() {
      if( m_cards.Count == 0 ) {
        throw new ApplicationException("Deck empty");
      }
      int num = m_random.Next(m_cards.Count);
      Card nextCard = m_cards[num];
      m_cards.RemoveAt(num);
      return nextCard;
    }

    private List<Card> m_cards;
    private List<Card> m_allCards;
    private Random m_random;
  }
}
