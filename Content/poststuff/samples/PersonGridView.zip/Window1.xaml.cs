using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace PersonGridView
{
    public partial class Window1 : System.Windows.Window
    {
        public Window1()
        {
            InitializeComponent();

            List<PersonHolder> people = new List<PersonHolder>();
            people.Add(new PersonHolder() { ID = 1, Person = new Person() { Name = "Tom", Age = 11 } });
            people.Add(new PersonHolder() { ID = 2, Person = new Person() { Name = "John", Age = 12 } });
            people.Add(new PersonHolder() { ID = 3, Person = new Person() { Name = "Melissa", Age = 38 } });

            DataContext = people;
        }
    }

    class Person
    {
        string name;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        int age;
        public int Age
        {
            get { return age; }
            set { age = value; }
        }
    }

    class PersonHolder
    {
        int id;
        public int ID
        {
            get { return id; }
            set { id = value; }
        }

        Person person;
        public Person Person
        {
            get { return person; }
            set { person = value; }
        }
    }
}
