You have generated a stand-alone ATL application called dlgonly. Enjoy.
