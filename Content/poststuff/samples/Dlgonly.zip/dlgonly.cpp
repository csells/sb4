// forsteve3.cpp : Defines the entry point for the application.

#include "stdafx.h"
#include "resource.h"

class CDlgonlyDlg : public CAxDialogImpl<CDlgonlyDlg>
{
public:
BEGIN_MSG_MAP(CDlgonlyDlg)
    COMMAND_ID_HANDLER(IDOK, OnCommand)
    COMMAND_ID_HANDLER(IDCANCEL, OnCommand)
END_MSG_MAP()

    enum { IDD = IDD_DLGONLY };

    LRESULT OnCommand(WORD, WORD id, HWND, BOOL&)
    {
        EndDialog(id);
        return 0;
    }
};

// Required ATL module
CComModule _Module;

int WINAPI _tWinMain(HINSTANCE hinst, HINSTANCE, LPTSTR lpCmdLine, int nShow)
{
    // Initialize COM
    CoInitialize(0);

    // Initialize the ATL module
    _Module.Init(0, hinst);
    
    // Create and show the dialog
    CDlgonlyDlg dlg;
    dlg.DoModal();

    // Terminate the ATL module
    _Module.Term();
    
    // Uninitialize COM
    CoUninitialize();
    
    return 0;
}
