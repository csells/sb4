// Main.cs
// Copyright (c) Chris Sells, 2001
// All rights reserved. No warranties extended. Use at your own risk.
// All comments to csells@sellsbrothers.com

using System;
using System.Net.Sockets;
using System.Net;
using System.IO;

class App
{
    static DateTime GetServerTime(string server, int port)
    {
        TcpClient       socket = new TcpClient(server, port);
        NetworkStream   stream = socket.GetStream();
        BinaryReader    reader = new BinaryReader(socket.GetStream());

        // Read as host ordered bits according to the spec, i.e. big endian
        uint    big = reader.ReadUInt32();

        // Close the connection
        reader.Close();
        stream.Close();
        socket.Close();

        // Convert from network order to host order, i.e. little endian
        uint    time = (uint)System.Net.IPAddress.NetworkToHostOrder((int)big);
        //Console.WriteLine(time);

        // The time is the number of seconds since 00:00 (midnight) 1 January 1900
        // GMT, such that the time 1 is 12:00:01 am on 1 January 1900 GMT
        DateTime    baseTime = new DateTime(1900, 1, 1, 0, 0, 0);
        //Console.WriteLine(baseTime);

        // We need to chop out the hours, minutes and seconds, because TimeSpan
        // won't take an unsigned number of seconds and all bits matter
        const uint  secondsInHours = 60 * 60;
        const uint  secondsInMinutes = 60;
        int   hours = (int)(time/secondsInHours);
        time %= secondsInHours;

        int   minutes = (int)(time/secondsInMinutes);
        time %= secondsInMinutes;

        int   seconds = (int)time;

        TimeSpan    span = new TimeSpan(hours, minutes, seconds);
        //Console.WriteLine("span= " + span);

        // Offset base time by number of seconds since 1900 and the current time zone
        DateTime    serverTime = baseTime + span + TimeZone.CurrentTimeZone.GetUtcOffset(DateTime.Now);
        //Console.WriteLine(now);

        return serverTime;
    }

    static void Main(string[] args)
    {
        string  server = "time-A.timefreq.bldrdoc.gov";
        int     port = 37;

        Console.WriteLine("{0}:{1} reports current time as {2}", server, port, GetServerTime(server, port));
    }
}
