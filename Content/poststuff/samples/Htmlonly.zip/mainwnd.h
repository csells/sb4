// MainWnd.h: Defines main window for application

#pragma once
#ifndef MAINWND_H
#define MAINWND_H

#include "HtmlDialogImpl.h"

/*
class CAboutDlg : public CHtmlDialogImpl<CAboutDlg>
{
public:
    enum { IDD = IDD_ABOUT };

    HRESULT GetUrl(BSTR* pbstrUrl)
    {
        *pbstrUrl = SysAllocString(OLESTR("res://htmlonly.exe/about.htm"));
        return S_OK;
    }
};
*/

typedef CWinTraitsOR<0, WS_EX_CLIENTEDGE, CFrameWinTraits>
        CMainWindowTraits;

class CMainWindow : public CWindowImpl<CMainWindow, CWindow, CMainWindowTraits>
{
public:
    CMainWindow()
    {
        // Initialize window info
        CWndClassInfo&  wci = GetWndClassInfo();
        if( !wci.m_atom )
        {
            wci.m_wc.hIcon = LoadIcon(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDI_HTMLONLY));
            wci.m_wc.hIconSm = (HICON)::LoadImage(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDI_HTMLONLY), IMAGE_ICON, 16, 16, LR_DEFAULTCOLOR);
            wci.m_bSystemCursor = TRUE;
            wci.m_lpszCursorID = IDC_ARROW;
        }
    }

BEGIN_MSG_MAP(CMainWindow)
    MESSAGE_HANDLER(WM_CREATE, OnCreate)
    MESSAGE_HANDLER(WM_SIZE, OnSize)
    COMMAND_ID_HANDLER(ID_FILE_EXIT, OnExit)
    COMMAND_ID_HANDLER(ID_HELP_ABOUT, OnAbout)
END_MSG_MAP()

    LRESULT OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& lResult)
    {
        LPCTSTR pszControlName = __T("res://htmlonly.exe/top.htm");
        if( m_ax.Create(m_hWnd, CWindow::rcDefault, pszControlName, WS_CHILD | WS_VISIBLE) )
        {
            CComPtr<IAxWinAmbientDispatch> spAmbient;
            if( SUCCEEDED(m_ax.QueryHost(&spAmbient)) )
            {
                // Turn off default of no 3D border
                spAmbient->put_DocHostFlags(0);
            }

            return 0;
        }

        return -1;
    }

    LRESULT OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& lResult)
    {
        RECT rect = { 0, 0, LOWORD(lParam), HIWORD(lParam) };
        return m_ax.MoveWindow(&rect);
    }
    
    LRESULT OnExit(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
    {
        DestroyWindow();
        return 0;
    }

    LRESULT OnAbout(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
    {
        //return ShowHTMLDialog(m_hWnd, OLESTR("res://htmlonly.exe/about.htm"));
        //CAboutDlg().DoModal();
        CSimpleHtmlDialog<IDD_ABOUT>().DoModal();
        return 0;
    }
    
    void OnFinalMessage(HWND)
    {
        PostQuitMessage(0);
    }

private:
    CAxWindow   m_ax;
};

#endif  // MAINWND_H
