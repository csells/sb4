// htmlonly.cpp : Defines the entry point for the application.

#include "stdafx.h"
#include "resource.h"
#include "mainwnd.h"

// Required ATL module
CComModule _Module;

// Empty object map
BEGIN_OBJECT_MAP(ObjectMap)
END_OBJECT_MAP()

int WINAPI WinMain(HINSTANCE hinst, HINSTANCE, LPSTR, int nShow)
{
    // Initialize COM
    CoInitialize(0);

    // Initialize the ATL module
    _Module.Init(0, hinst);

    // Initialize support for control containment
    AtlAxWinInit(); // FIX: Add gdi32.lib to the link line

    // Create and show the main window
    USES_CONVERSION;
    HMENU       hMenu = LoadMenu(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_HTMLONLY));
    CComBSTR    bstrTitle; bstrTitle.LoadString(IDS_APP_TITLE);

    CMainWindow wndMain;
    wndMain.Create(0, CWindow::rcDefault, OLE2CT(bstrTitle), 0, 0, (UINT)hMenu);
    wndMain.ShowWindow(nShow);
    wndMain.UpdateWindow();

    // Pump messages
    HACCEL  haccel = LoadAccelerators(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDC_HTMLONLY));
    MSG     msg;
    while( GetMessage(&msg, 0, 0, 0) )
    {
        if( !TranslateAccelerator(msg.hwnd, haccel, &msg) )
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    // Terminate the ATL module
    _Module.Term();
    
    // Uninitialize COM
    CoUninitialize();
    
    return 0;
}
