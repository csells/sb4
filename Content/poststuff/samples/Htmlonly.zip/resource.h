//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by htmlonly.rc
//
#define ID_HELP_ABOUT                   101
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDR_TOP                         103
#define IDR_LEFT                        104
#define ID_FILE_EXIT                    105
#define IDR_RIGHT                       105
#define IDR_ABOUT                       106
#define IDI_HTMLONLY                    107
#define IDD_ABOUT                       107
#define IDI_SMALL                       108
#define IDC_HTMLONLY                    109
#define IDR_HTMLONLY                    109

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
