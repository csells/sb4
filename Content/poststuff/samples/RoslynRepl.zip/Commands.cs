﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;

namespace RoslynRepl {
  public interface ICommand {
    ICommandHost CommandHost { set; }
    string Name { get; }
    string Description { get; }
    string Usage { get; }
    void Execute(string[] args);
  }

  public interface ICommandHost {
    void Clear();
    bool ContinueExecuting { get; set; }
    void Write(params object[] objects);
    IEnumerable<ICommand> Commands { get; }
    void Execute(string s);
    void ResetSession();
    string PrimaryPrompt { get; set; }
    string SecondaryPrompt { get; set; }
  }

  public class ClearCommand : ICommand {
    ICommandHost host;
    public ICommandHost CommandHost { set { host = value; } }

    public string Name { get { return "cls"; } }
    public string Description { get { return "Clears the contents of the REPL editor window."; } }
    public string Usage { get { return "Usage: #cls"; } }

    public void Execute(params string[] args) {
      if (args.Length != 0) { throw new Exception(Usage); }
      host.Clear();
    }
  }

  public class ExitCommand : ICommand {
    ICommandHost host;
    public ICommandHost CommandHost { set { host = value; } }

    public string Name { get { return "exit"; } }
    public string Description { get { return "Closes the REPL window."; } }
    public string Usage { get { return "Usage: #exit"; } }

    public void Execute(params string[] args) {
      if (args.Length != 0) { throw new Exception(Usage); }
      host.ContinueExecuting = false;
    }
  }

  public class HelpCommand : ICommand {
    ICommandHost host;
    public ICommandHost CommandHost { set { host = value; } }

    public string Name { get { return "help"; } }
    public string Description { get { return "Display help for all commands or specified command."; } }
    public string Usage { get { return "Usage: #help [command-name]"; } }

    public void Execute(params string[] args) {
      if (args.Length > 1) { throw new Exception(Usage); }

      if (args.Length == 0) {
        host.Write("Commands:\r\n");
        foreach (ICommand command in host.Commands) {
          host.Write("  ", command.Name.PadRight(10), command.Description, "\r\n");
        }
      }
      else {
        ICommand command = host.Commands.FirstOrDefault(c => string.Compare((args[0]), c.Name, true) == 0);
        if (command == null) {
          throw new Exception("Unknown command");
        }
        else {
          host.Write(command.Description, "\r\n", command.Usage, "\r\n");
        }
      }
    }
  }

  public class LoadCommand : ICommand {
    ICommandHost host;
    public ICommandHost CommandHost { set { host = value; } }

    public string Name { get { return "load"; } }
    public string Description { get { return "Executes the specified file within the current interactive session."; } }
    public string Usage { get { return "Usage: #load \"path-to-file\""; } }

    public void Execute(params string[] args) {
      if (args.Length != 1) { throw new Exception(Usage); }

      host.Execute(File.ReadAllText(args[0]));
    }
  }

  public class PromptCommand : ICommand {
    ICommandHost host;
    public ICommandHost CommandHost { set { host = value; } }

    public string Name { get { return "prompt"; } }
    public string Description { get { return "Changes the current prompt settings."; } }
    public string Usage { get { return "Usage: #prompt \"primary-prompt\" [\"secondary-prompt\"]"; } }

    public void Execute(params string[] args) {
      if (args.Length < 1 || args.Length > 2) { throw new Exception(Usage); }

      host.PrimaryPrompt = args[0];
      if (args.Length == 2) { host.SecondaryPrompt = args[1]; }
    }
  }

  public class ResetCommand : ICommand {
    ICommandHost host;
    public ICommandHost CommandHost { set { host = value; } }

    public string Name { get { return "reset"; } }
    public string Description { get { return "Reset the environment to the initial state, keeping REPL history."; } }
    public string Usage { get { return "Usage: #reset"; } }

    public void Execute(params string[] args) {
      if (args.Length != 0) { throw new Exception(Usage); }

      host.ResetSession();
    }
  }

}
