﻿using System;

namespace RoslynRepl {
  class Program {
    static void Main(string[] args) {
      new ConsoleReplHost().Run();
    }
  }
};
