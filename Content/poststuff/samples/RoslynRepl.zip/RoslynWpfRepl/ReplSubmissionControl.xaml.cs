﻿// Example header text. Can be configured in the options.
using System;
using System;
using System;
using System.Diagnostics;
using System.Linq;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Roslyn.Scripting.CSharp;

namespace RoslynWpfRepl {
  public class CommandExecutedArgs : EventArgs {
    public CommandExecutedArgs(bool executionComplete) {
      this.ExecutionComplete = executionComplete;
    }

    public bool ExecutionComplete { get; private set; }
  }

  public delegate void CommandExecuting(object sender, EventArgs e);
  public delegate void CommandExecuted(object sender, CommandExecutedArgs e);

  public partial class ReplSubmissionControl : UserControl {
    static readonly Brush errorBrush = new SolidColorBrush(Colors.Red);
    static readonly ObjectFormatter formatter = new ObjectFormatter();

    public event CommandExecuting CommandExecuting;
    public event CommandExecuted CommandExecuted;
    public ReplEngine Engine { get; set; }

    public ReplSubmissionControl() {
      this.InitializeComponent();
    }

    // TODO: probably not the right way to do this, but I want the main window
    // to manage focus and the FocusManager.FocusedElement property on this
    // control + UIElement.Focus doesn't seem to do the job
    new public bool Focus() {
      return this.inputTextBox.Focus();
    }

    void inputTextBox_KeyUp(object sender, KeyEventArgs e) {
      var textBox = (TextBox)sender;
      var cmd = textBox.Text;
      if (string.IsNullOrWhiteSpace(cmd)) {
        return;
      }

      if (e.Key == Key.Enter) {
        if (!this.ExecuteCommand(cmd)) {
          int pos = textBox.SelectionStart;
          textBox.SelectedText = "\r\n";
          textBox.Select(pos + 2, 0);
        }
      }
      else if (textBox.SelectionLength == 0) {
        this.ShowCompletions(cmd, textBox.SelectionStart);
      }
    }

    bool ExecuteCommand(string cmd) {
      if (this.CommandExecuting != null) {
        this.CommandExecuting(this, EventArgs.Empty);
      }

      // Clear the current output
      Write(null);
      SetError(null);
      bool executionCompleted = false;

      try {
        var result = this.Engine.Execute(cmd);
        executionCompleted = (result == null || result.GetType() != typeof(ReplEngine.NeedMoreInput));
        if (executionCompleted) { SetOutput(result); }
      }
      catch (Exception ex) {
        SetError(ex.Message);
        executionCompleted = true;
      }

      if (this.CommandExecuted != null) {
        this.CommandExecuted(this, new CommandExecutedArgs(executionCompleted));
      }

      return executionCompleted;
    }

    public static Control GetTextControl(string text, Brush foreground = null) {
      if (string.IsNullOrEmpty(text)) { return null; }

      var control = new TextBox() {
        Text = text,
        TextWrapping = TextWrapping.Wrap,
        TextAlignment = TextAlignment.Left,
        AutoWordSelection = true,
        IsReadOnly = true,
        BorderThickness = new Thickness(),
      };

      if (foreground != null) { control.Foreground = foreground; }
      return control;
    }

    void SetError(string error) {
      outputContainer.Content = GetTextControl(new TrimmedStringBuilder(error).ToString(), errorBrush);
    }

    void SetOutput(object output) {
      string s = null;
      if (output != null) {
        if (output.GetType() == typeof(string)) {
          s = new TrimmedStringBuilder(output.ToString()).ToString();
        }
        else {
          s = formatter.FormatObject(output);
        }
      }

      outputContainer.Content = GetTextControl(s);
    }

    void ShowCompletions(string cmd, int position) {
      var completions = this.Engine.GetCompletions(cmd, position);
      if (completions == null) {
        return;
      }
      // TODO: put these in a listbox
      Debug.Write(completions.Aggregate(new StringBuilder("Completions:\r\n"), (sb, c) => sb.AppendFormat("\t{0}\r\n", c.Name)));
    }

    TrimmedStringBuilder trimmedOutput = new TrimmedStringBuilder();

    public void Write(string s) {
      if (s == null) { trimmedOutput.Clear(); }
      else { trimmedOutput.Append(s); }

      consoleContainer.Content = GetTextControl(trimmedOutput.ToString());
    }
  }
}