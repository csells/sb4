﻿using System;
using System.Linq;
using System.Text;

namespace RoslynWpfRepl {
  // Output a stream of strings with \r\n pairs potentially spread across strings,
  // trimming the trailing \r and \r\n to avoid the output containing the extra spacing.
  class TrimmedStringBuilder {
    readonly StringBuilder sb;

    public TrimmedStringBuilder(string s = "") {
      sb = new StringBuilder(s);
    }

    public void Clear() {
      sb.Clear();
    }

    public void Append(string s) {
      sb.Append(s);
    }

    public override string ToString() {
      int len = sb.Length;

      if (len >= 1 && sb[len - 1] == '\r') {
        len -= 1;
      }
      else if (len >= 2 && sb[len - 2] == '\r' && sb[len - 1] == '\n') {
        len -= 2;
      }

      return sb.ToString(0, len);
    }

  }
}
