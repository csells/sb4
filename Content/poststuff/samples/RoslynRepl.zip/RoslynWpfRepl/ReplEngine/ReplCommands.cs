﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;

namespace RoslynWpfRepl {
  public interface IReplCommand {
    IReplHost CommandHost { set; }
    string Name { get; }
    string Description { get; }
    string Usage { get; }
    object Execute(string[] args);
  }

  public interface IReplHost {
    void Clear(bool showWelcome = false);
    IEnumerable<IReplCommand> Commands { get; }
    object Execute(string line);
    void ResetSession();
    void Write(string s);
  }

  public class ClearCommand : IReplCommand {
    IReplHost host;
    public IReplHost CommandHost {
      set { host = value; }
    }

    public string Name {
      get { return "cls"; }
    }
    public string Description {
      get { return "Clears the contents of the REPL editor window."; }
    }
    public string Usage {
      get { return "Usage: #cls"; }
    }

    public object Execute(params string[] args) {
      if (args.Length != 0) { throw new Exception(Usage); }
      host.Clear();
      return null;
    }
  }

  public class HelpCommand : IReplCommand {
    IReplHost host;
    public IReplHost CommandHost {
      set { host = value; }
    }

    public string Name {
      get { return "help"; }
    }

    public string Description {
      get { return "Display help for all commands or specified command."; }
    }
    
    public string Usage {
      get { return "Usage: #help [command-name]"; }
    }

    public object Execute(params string[] args) {
      if (args.Length > 1) { throw new Exception(Usage); }

      var result = new StringBuilder();
      if (args.Length == 0) {
        result.Append("Commands:\r\n");
        foreach (IReplCommand command in host.Commands) {
          result.AppendFormat("  {0} {1}\r\n", command.Name.PadRight(9), command.Description);
        }
      }
      else {
        IReplCommand command = host.Commands.FirstOrDefault(c => string.Compare((args[0]), c.Name, true) == 0);
        if (command == null) {
          throw new Exception("Unknown command. " + Usage);
        }
        else {
          result.AppendFormat("{0}\r\n{1}\r\n", command.Description, command.Usage);
        }
      }

      return result.ToString();
    }
  }

  public class LoadCommand : IReplCommand {
    IReplHost host;
    public IReplHost CommandHost {
      set { host = value; }
    }

    public string Name {
      get { return "load"; }
    }

    public string Description {
      get { return "Executes the specified file within the current interactive session."; }
    }

    public string Usage {
      get { return "Usage: #load \"path-to-file\""; }
    }

    public object Execute(params string[] args) {
      if (args.Length != 1) { throw new Exception(Usage); }

      return host.Execute(File.ReadAllText(args[0]));
    }
  }

  public class ResetCommand : IReplCommand {
    IReplHost host;
    public IReplHost CommandHost {
      set { host = value; }
    }

    public string Name {
      get { return "reset"; }
    }
    public string Description {
      get { return "Reset the environment to the initial state, keeping REPL history."; }
    }
    public string Usage {
      get { return "Usage: #reset"; }
    }

    public object Execute(params string[] args) {
      if (args.Length != 0) { throw new Exception(Usage); }

      host.ResetSession();
      return null;
    }
  }
}