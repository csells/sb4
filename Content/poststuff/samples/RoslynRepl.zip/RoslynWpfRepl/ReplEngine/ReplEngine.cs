﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using Roslyn.Compilers;
using Roslyn.Compilers.CSharp;
using Roslyn.Compilers.Common;
using Roslyn.Scripting;
using Roslyn.Scripting.CSharp;
using System.Text;
using System.Diagnostics;

namespace RoslynWpfRepl {
  public class ReplEngine {
    static readonly string[] defaultReferences = new string[] { "mscorlib", "System", "System.Core", "Microsoft.CSharp", "System.Data", "System.Data.DataSetExtensions", "System.Xml", "System.Xml.Linq" };
    static readonly string[] defaultNamespaces = new string[] { "System", "System.Linq", "System.Collections.Generic", "System.Text" };
    static readonly ParseOptions interactiveOptions = new ParseOptions(kind: SourceCodeKind.Interactive, languageVersion: LanguageVersion.CSharp6);
    static readonly AssemblyResolver assemblyResolver = new AssemblyResolver();

    // Split lines with optional quotes, e.g. 'foo "  bar baz" quux' splits into three strings: 'foo', '"  bar baz"' and 'quux'
    static readonly Regex splitRegex = new Regex(@"\S*?[\[""].*?[\]""]|\S+");

    readonly List<MetadataReference> references = new List<MetadataReference>(defaultReferences.Select(r => MetadataReference.Create(r)));
    readonly IReplCommand[] commands;
    readonly ReplHostTextWriter consoleOut;
    readonly CommonScriptEngine engine = new ScriptEngine(defaultReferences, defaultNamespaces);
    Session session;
    ICompilation previousCompilation;

    public ReplEngine(IReplHost host) {
      commands = new IReplCommand[] {
        new ClearCommand() { CommandHost = host },
        new HelpCommand() { CommandHost = host },
        new LoadCommand() { CommandHost = host },
        new ResetCommand() { CommandHost = host },
      };

      // Redirect Console
      // TODO: what to do Console.Read?
      consoleOut = new ReplHostTextWriter(host);
      Console.SetOut(consoleOut);

      ResetSession();
    }

    public IEnumerable<IReplCommand> Commands {
      get { return commands; }
    }

    internal struct NeedMoreInput { public static NeedMoreInput Default = new NeedMoreInput(); };

    public object Execute(string cmd) {
      // Handle #commands
      string trimmed = cmd.Trim();
      if (trimmed[0] == '#') {
        var commandArgs = splitRegex.Matches(trimmed.Substring(1)).OfType<Match>().Select(m => m.Value.Trim('"')).ToArray();
        var command = commands.FirstOrDefault(c => string.Compare(commandArgs[0], c.Name, true) == 0);
        if (command != null) { return command.Execute(commandArgs.Skip(1).ToArray()); }
      }

      // Handle C# (including #define and other directives)
      // Check for complete submission
      var tree = SyntaxTree.ParseCompilationUnit(cmd, options: interactiveOptions);
      if (!Syntax.IsCompleteSubmission(tree)) { return NeedMoreInput.Default; }

      try {
        Submission<object> submission = engine.CompileSubmission<object>(cmd, session);
        previousCompilation = submission.Compilation;
        object result = submission.Execute();
        consoleOut.Flush(); // Push Console.Write output to the screen

        bool hasValue;
        ITypeSymbol resultType = submission.Compilation.GetSubmissionResultType(out hasValue);

        if (hasValue && resultType != null && resultType.SpecialType != SpecialType.System_Void) {
          return result;
        }
      }
      catch (CompilationErrorException ex) {
        throw new Exception(ex.Diagnostics.Select(d => d.ToString()).Aggregate("", (s, r) => s + r + "\r\n"), ex);
      }

      return null;
    }

    public void ResetSession() {
      session = Session.Create();
      previousCompilation = null;

      // HACK: work around a known issue where namespaces aren't visible inside functions
      foreach (string nm in defaultNamespaces) {
        engine.Execute("using " + nm + ";", session);
      }
    }

    public IEnumerable<ISymbol> GetCompletions(string cmd, int position) {
      // TODO: handle #commands

      // Handle C# commands
      var tree = SyntaxTree.ParseCompilationUnit(cmd, options: interactiveOptions);

      // Check for completions
      // TODO: replace this very limited completion finder
      try {
        var speculativeCompilation = Compilation.CreateSubmission("sub", syntaxTree: tree, previousSubmission: previousCompilation, references: references, referenceResolver: assemblyResolver);
        var token = tree.Root.FindToken(position - 1);
        var parentToken = token.Parent;
        var memberAccess = parentToken as MemberAccessExpressionSyntax;
        if (memberAccess != null) {
          var model = speculativeCompilation.GetSemanticModel(tree);
          var info = model.GetSemanticInfo(memberAccess.Expression);
          if (info.Type != null) {
            return model.LookupSymbols(position, container: info.Type).OrderBy(s => s.Name);
          }
        }
      }
      catch { }

      return null;
    }

  };
}