﻿using System;
using System.IO;
using System.Linq;
using System.Text;

namespace RoslynWpfRepl {
    class ReplHostTextWriter : TextWriter {
    readonly IReplHost host;

    public ReplHostTextWriter(IReplHost host) {
      this.host = host;
    }

    public override void Write(char value) {
      host.Write(value.ToString());
    }

    public override Encoding Encoding {
      get { return Encoding.Default; }
    }
  }

}