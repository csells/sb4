﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Documents;

namespace RoslynWpfRepl {
  public partial class MainWindow : Window, IReplHost {
    ReplEngine repl;
    List<ReplSubmissionControl> submissions = new List<ReplSubmissionControl>();
    int executingSubmissionIndex = -1;

    public MainWindow() {
      InitializeComponent();
      repl = new ReplEngine(this);
      Clear(true);
    }

    void AddSubmission() {
      var submission = new ReplSubmissionControl() { Engine = repl };
      submissions.Add(submission);
      submission.CommandExecuting += new CommandExecuting(submission_CommandExecuting);
      submission.CommandExecuted += new CommandExecuted(submission_CommandExecuted);
      submission.Loaded += new RoutedEventHandler(submission_Loaded);
      var block = new BlockUIContainer(submission);
      block.Margin = new Thickness(0, 0, 0, 10);
      flowDocViewer.Document.Blocks.Add(block);
    }

    void submission_Loaded(object sender, RoutedEventArgs e) {
      ((ReplSubmissionControl)sender).Focus();
    }

    void submission_CommandExecuting(object sender, EventArgs e) {
      executingSubmissionIndex = submissions.IndexOf((ReplSubmissionControl)sender);
      Debug.Assert(executingSubmissionIndex >= 0);
    }

    void submission_CommandExecuted(object sender, CommandExecutedArgs e) {
      if (!e.ExecutionComplete) { return; }

      if (executingSubmissionIndex + 1 < submissions.Count) {
        submissions[executingSubmissionIndex + 1].Focus();
      }
      else {
        AddSubmission();
      }

      executingSubmissionIndex = -1;
    }

    public void Clear(bool showWelcome = false) {
      flowDocViewer.Document = new FlowDocument();
      if (showWelcome) {
        //flowDocViewer.Document.Blocks.Add(new Paragraph(new Run("Welcome to RoslynRepl!\r\nType '#help' for more information.")) { TextAlignment = TextAlignment.Left });
        flowDocViewer.Document.Blocks.Add(new BlockUIContainer(ReplSubmissionControl.GetTextControl("Welcome to RoslynRepl!\r\nType '#help' for more information.")));
      }
      AddSubmission();
    }

    public IEnumerable<IReplCommand> Commands {
      get { return repl.Commands; }
    }

    object IReplHost.Execute(string line) {
      return repl.Execute(line);
    }

    public void ResetSession() {
      repl.ResetSession();
    }

    public void Write(string s) {
      Debug.Assert(executingSubmissionIndex >= 0);
      submissions[executingSubmissionIndex].Write(s);
    }

  }
}