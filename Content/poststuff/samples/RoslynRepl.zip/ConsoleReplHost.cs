﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Roslyn.Compilers;
using Roslyn.Compilers.CSharp;
using Roslyn.Compilers.Common;
using Roslyn.Scripting;
using Roslyn.Scripting.CSharp;
using System.Text.RegularExpressions;

namespace RoslynRepl {
  public class ConsoleReplHost : ICommandHost {
    static readonly string[] defaultReferences = new string[] { "System", "System.Core", "Microsoft.CSharp", "System.Data", "System.Data.DataSetExtensions", "System.Xml", "System.Xml.Linq" };
    static readonly string[] defaultNamespaces = new string[] { "System", "System.Linq", "System.Collections.Generic", "System.Text" };
    static readonly ParseOptions interactiveOptions = new ParseOptions(kind: SourceCodeKind.Interactive, languageVersion: LanguageVersion.CSharp6);

    // Split lines with optional quotes, e.g. 'foo "  bar baz" quux' splits into three strings: 'foo', '"  bar baz"' and 'quux'
    static readonly Regex splitRegex = new Regex(@"\S*?[\[""].*?[\]""]|\S+");

    bool continueExecuting = true;
    readonly ICommand[] commands;
    readonly CommonScriptEngine engine = new ScriptEngine(defaultReferences, defaultNamespaces);
    readonly ObjectFormatter formatter = new ObjectFormatter(maxLineLength: Console.BufferWidth, memberIndentation: "  ");
    Session session;

    public ConsoleReplHost() {
      commands = new ICommand[] {
        new ClearCommand() { CommandHost = this },
        new ExitCommand() { CommandHost = this },
        new HelpCommand() { CommandHost = this },
        new LoadCommand() { CommandHost = this },
        new PromptCommand() { CommandHost = this },
        new ResetCommand() { CommandHost = this },
      };

      PrimaryPrompt = "> ";
      SecondaryPrompt = ". ";

      ResetSession();
    }

    public string PrimaryPrompt { get; set; }
    public string SecondaryPrompt { get; set; }

    public void Clear() {
      Console.Clear();
    }

    public bool ContinueExecuting {
      get { return continueExecuting; }
      set { continueExecuting = value; }
    }

    public void Write(params object[] objects) {
      foreach (var o in objects) { Console.Write(o.ToString()); }
    }

    void WriteLine(params object[] objects) {
      Write(objects);
      Write("\r\n");
    }

    public IEnumerable<ICommand> Commands {
      get { return commands; }
    }

    public void Execute(string s) {
      try {
        Submission<object> submission = engine.CompileSubmission<object>(s, session);
        object result = submission.Execute();
        bool hasValue;
        ITypeSymbol resultType = submission.Compilation.GetSubmissionResultType(out hasValue);

        // Print the results
        if (hasValue) {
          if (resultType != null && resultType.SpecialType == SpecialType.System_Void) {
            Console.WriteLine(formatter.VoidDisplayString);
          }
          else {
            Console.WriteLine(formatter.FormatObject(result));
          }
        }
      }
      catch (CompilationErrorException e) {
        Error(e.Diagnostics.Select(d => d.ToString()).ToArray());
      }
      catch (Exception e) {
        Error(e.ToString());
      }
    }

    public void ResetSession() {
      session = Session.Create();

      // HACK: work around a known issue where namespaces aren't visible inside functions
      foreach (string nm in defaultNamespaces) {
        engine.Execute("using " + nm + ";", session);
      }
    }

    public void Run() {
      // Usage
      WriteLine("Welcome to RoslynRepl!");
      WriteLine("Type \"#help\" for more information.");
      WriteLine();

      while (true) {
        Console.Write(PrimaryPrompt);
        var input = new StringBuilder();

        while (true) {
          string line = Console.ReadLine();
          if (string.IsNullOrWhiteSpace(line)) { continue; }

          // Handle #commands
          string trimmed = line.Trim();
          if (trimmed[0] == '#') {
            var commandArgs = splitRegex.Matches(trimmed.Substring(1)).OfType<Match>().Select(m => m.Value.Trim('"')).ToArray();
            var command = commands.FirstOrDefault(c => string.Compare(commandArgs[0], c.Name, true) == 0);
            if (command != null) {
              try { command.Execute(commandArgs.Skip(1).ToArray()); }
              catch (Exception e) { Error(e.Message); }
              if (!continueExecuting) { return; }
              break;
            }
          }

          // Handle C# (include #define and other directives)
          input.AppendLine(line);

          // Check for complete submission
          if (Syntax.IsCompleteSubmission(SyntaxTree.ParseCompilationUnit(input.ToString(), options: interactiveOptions))) { break; } // foo();
          Console.Write(SecondaryPrompt);
        }

        Execute(input.ToString());
      }
    }

    void Error(params string[] errors) {
      var oldColor = Console.ForegroundColor;
      Console.ForegroundColor = ConsoleColor.Red;
      WriteLine(errors);
      Console.ForegroundColor = oldColor;
    }

  };
}
