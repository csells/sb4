// Disp2.h : Declaration of the CDisp2

#ifndef __DISP2_H_
#define __DISP2_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CDisp2
class ATL_NO_VTABLE CDisp2 : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CDisp2, &CLSID_Disp2>,
    // DONE: IDispatchImpl doesn't work here, but IRawDispImpl can help.
	//public IDispatchImpl<IDisp2, &IID_IDisp2, &LIBID_ATLDISPLib>
    // DONE: IDispinterfaceImpl can help w/ 3 of 4
    public IRawDispImpl<DDisp2>
{
public:
	CDisp2()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_DISP2)
DECLARE_NOT_AGGREGATABLE(CDisp2)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CDisp2)
	COM_INTERFACE_ENTRY(DDisp2)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// DDisp2
public:
    STDMETHODIMP Invoke(DISPID dispIdMember, REFIID riid, LCID lcid, WORD wFlags, DISPPARAMS * pDispParams, VARIANT * pVarResult, EXCEPINFO * pExcepInfo, UINT * puArgErr);

    // Actual implementation
	STDMETHOD(SaySomething)(BSTR bstrSomething);
};

#endif //__DISP2_H_
