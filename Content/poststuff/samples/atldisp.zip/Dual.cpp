// Dual.cpp : Implementation of CDual
#include "stdafx.h"
#include "Atldisp.h"
#include "Dual.h"

/////////////////////////////////////////////////////////////////////////////
// CDual


STDMETHODIMP CDual::SaySomething(BSTR bstrSomething)
{
	MessageBoxW(0, bstrSomething, L"CDual::SaySomething", MB_SETFOREGROUND);
	return S_OK;
}
