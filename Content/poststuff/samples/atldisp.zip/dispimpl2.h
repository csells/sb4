// dispimpl2.h: IDispatchImpl2
/////////////////////////////////////////////////////////////////////////////
// Copyright (c) 1998 Chris Sells
// All rights reserved.
//
// 10/25/98:
// -Initial release.
//
// NO WARRANTIES ARE EXTENDED. USE AT YOUR OWN RISK.
//
// Contact the author with suggestions or comments at csells@sellsbrothers.com.
/////////////////////////////////////////////////////////////////////////////
// This header defines three C++ classes for use in implementing
// dispatch-based interfaces:
//  -IDualDispImpl for implementing dual interfaces.
//  -IDelegatingDispImpl for implementing delegating dispinterfaces.
//  -IRawDispImpl for implementing raw dispinterfaces.
/////////////////////////////////////////////////////////////////////////////
// IDualDispImpl: For use with dispatch-based interfaces declared like so:
//
// [dual]
// interface IFoo : IDispatch
// {
//    ...
// }
//
// IDualDispImpl implements all four IDispatch methods.
// IDualDispImpl gets the IDispatch vtbl entries by deriving from
// the IDispatch that servers as the base class for the dual interface.
//
// Usage:
//  class CFoo : ..., public IDualDispImpl<IFoo>
//
// The current IDispatchImpl is only good for duals.
// NOTE: A typedef would've done here, but I like getting the piid using __uuidof.
/////////////////////////////////////////////////////////////////////////////
// IDelegatingDispImpl: For use with dispatch-based interfaces declared like so:
//
// [oleautomation]
// interface IFoo : IUnknown
// {
//    ...
// }
//
// dispinterface DFoo
// {
//    interface IFoo; // Logically delegate to another interface
// }
//
// IDelegatingDispImpl implements all four IDispatch methods.
// IDelegatingDispImpl gets the IDispatch vtbl entries by deriving from
// the IDispatch in addition to the non-IDispatch based interface.
//
// Usage:
//  class CFoo : ..., public IDelegatingDispImpl<DFoo, IFoo>
/////////////////////////////////////////////////////////////////////////////
// IRawDispImpl: For use with dispatch-based interfaces declared like so:
//
// dispinterface DFoo
// {
// properties:
//   ...
// methods:
//   ...
// }
//
// IRawDispImpl implements three of the IDispatch methods.
// Invoke is left to the implementor.
// IRawDispImpl gets the IDispatch vtbl entries by deriving from
// the IDispatch in addition to the non-IDispatch based interface.
//
// Usage:
//  class CFoo : ..., public IRawDispImpl<DFoo>
//  {
//  ...
//      STDMETHODIMP Invoke(...);   // Implemented by hand.
//  };
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
// IDualDispImpl

template <class T, const IID* piid = &__uuidof(T), const GUID* plibid = &CComModule::m_libid, WORD wMajor = 1,
          WORD wMinor = 0, class tihclass = CComTypeInfoHolder>
class ATL_NO_VTABLE IDualDispImpl : public IDispatchImpl<T, piid, plibid, wMajor, wMinor, tihclass> {};

/////////////////////////////////////////////////////////////////////////////
// IDelegatingDispImpl

template <class D, class T, const IID* piid = &__uuidof(T), const GUID* plibid = &CComModule::m_libid, WORD wMajor = 1,
          WORD wMinor = 0, class tihclass = CComTypeInfoHolder>
class ATL_NO_VTABLE IDelegatingDispImpl : public T, public D
{
public:
	typedef tihclass _tihclass;
// IDispatch
	STDMETHOD(GetTypeInfoCount)(UINT* pctinfo)
	{
		*pctinfo = 1;
		return S_OK;
	}
	STDMETHOD(GetTypeInfo)(UINT itinfo, LCID lcid, ITypeInfo** pptinfo)
	{
		return _tih.GetTypeInfo(itinfo, lcid, pptinfo);
	}
	STDMETHOD(GetIDsOfNames)(REFIID riid, LPOLESTR* rgszNames, UINT cNames,
		LCID lcid, DISPID* rgdispid)
	{
		return _tih.GetIDsOfNames(riid, rgszNames, cNames, lcid, rgdispid);
	}
	STDMETHOD(Invoke)(DISPID dispidMember, REFIID riid,
		LCID lcid, WORD wFlags, DISPPARAMS* pdispparams, VARIANT* pvarResult,
		EXCEPINFO* pexcepinfo, UINT* puArgErr)
	{
        // DONE: Cast to T*, not IDispatch*
		//return _tih.Invoke((IDispatch*)this, dispidMember, riid, lcid,
        //                 dispidMember, riid, lcid, wFlags, pdispparams,
        //                 pvarResult, pexcepinfo, puArgErr);

        // DONE: reinterpret_cast because CComTypeInfoHolder makes the mistaken
        //       assumption that the typeinfo can only Invoke using an IDispatch*.
        //       Since the implementation only passes the itf onto
        //       ITypeInfo::Invoke (which takes a void*), this is a safe cast
        //       until the ATL team fixes CComTypeInfoHolder.
		return _tih.Invoke(reinterpret_cast<IDispatch*>(static_cast<T*>(this)),
                           dispidMember, riid, lcid, wFlags, pdispparams,
                           pvarResult, pexcepinfo, puArgErr);
	}
protected:
	static _tihclass _tih;
	static HRESULT GetTI(LCID lcid, ITypeInfo** ppInfo)
	{
		return _tih.GetTI(lcid, ppInfo);
	}
};

template <class D, class T, const IID* piid, const GUID* plibid, WORD wMajor, WORD wMinor, class tihclass>
IDelegatingDispImpl<D, T, piid, plibid, wMajor, wMinor, tihclass>::_tihclass
    IDelegatingDispImpl<D, T, piid, plibid, wMajor, wMinor, tihclass>::_tih =
        {piid, plibid, wMajor, wMinor, NULL, 0, NULL, 0};

/////////////////////////////////////////////////////////////////////////////
// IRawDispImpl

template <class T, const IID* piid = &__uuidof(T), const GUID* plibid = &CComModule::m_libid, WORD wMajor = 1,
          WORD wMinor = 0, class tihclass = CComTypeInfoHolder>
class ATL_NO_VTABLE IRawDispImpl : public T
{
public:
	typedef tihclass _tihclass;
// IDispatch
	STDMETHOD(GetTypeInfoCount)(UINT* pctinfo)
	{
		*pctinfo = 1;
		return S_OK;
	}
	STDMETHOD(GetTypeInfo)(UINT itinfo, LCID lcid, ITypeInfo** pptinfo)
	{
		return _tih.GetTypeInfo(itinfo, lcid, pptinfo);
	}
	STDMETHOD(GetIDsOfNames)(REFIID riid, LPOLESTR* rgszNames, UINT cNames,
		LCID lcid, DISPID* rgdispid)
	{
		return _tih.GetIDsOfNames(riid, rgszNames, cNames, lcid, rgdispid);
	}

    // You have to implement Invoke by hand.
    // However, the ATL team could bring to bear the same techniques used by
    // IDispEventImpl to make this easier.
	STDMETHOD(Invoke)(DISPID dispidMember, REFIID riid, LCID lcid, WORD wFlags, DISPPARAMS* pdispparams, VARIANT* pvarResult, EXCEPINFO* pexcepinfo, UINT* puArgErr) = 0;

protected:
	static _tihclass _tih;
	static HRESULT GetTI(LCID lcid, ITypeInfo** ppInfo)
	{
		return _tih.GetTI(lcid, ppInfo);
	}
};

template <class T, const IID* piid, const GUID* plibid, WORD wMajor, WORD wMinor, class tihclass>
IRawDispImpl<T, piid, plibid, wMajor, wMinor, tihclass>::_tihclass
    IRawDispImpl<T, piid, plibid, wMajor, wMinor, tihclass>::_tih =
        {piid, plibid, wMajor, wMinor, NULL, 0, NULL, 0};
