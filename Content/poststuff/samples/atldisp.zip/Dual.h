// Dual.h : Declaration of the CDual

#ifndef __DUAL_H_
#define __DUAL_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CDual
class ATL_NO_VTABLE CDual : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CDual, &CLSID_Dual>,
    // DONE: Either IDispatchImpl or IDualDispImpl works
	//public IDispatchImpl<IDual>
	public IDualDispImpl<IDual>
{
public:
	CDual()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_DUAL)
DECLARE_NOT_AGGREGATABLE(CDual)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CDual)
	COM_INTERFACE_ENTRY(IDual)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IDual
public:
	STDMETHOD(SaySomething)(BSTR bstrSomething);
};

#endif //__DUAL_H_
