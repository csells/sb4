/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Mon Oct 26 13:44:00 1998
 */
/* Compiler settings for c:\temp\atldisp\atldisp.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __atldisp_h__
#define __atldisp_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IDual_FWD_DEFINED__
#define __IDual_FWD_DEFINED__
typedef interface IDual IDual;
#endif 	/* __IDual_FWD_DEFINED__ */


#ifndef __IDisp1_FWD_DEFINED__
#define __IDisp1_FWD_DEFINED__
typedef interface IDisp1 IDisp1;
#endif 	/* __IDisp1_FWD_DEFINED__ */


#ifndef __DDisp1_FWD_DEFINED__
#define __DDisp1_FWD_DEFINED__
typedef interface DDisp1 DDisp1;
#endif 	/* __DDisp1_FWD_DEFINED__ */


#ifndef __DDisp2_FWD_DEFINED__
#define __DDisp2_FWD_DEFINED__
typedef interface DDisp2 DDisp2;
#endif 	/* __DDisp2_FWD_DEFINED__ */


#ifndef __Dual_FWD_DEFINED__
#define __Dual_FWD_DEFINED__

#ifdef __cplusplus
typedef class Dual Dual;
#else
typedef struct Dual Dual;
#endif /* __cplusplus */

#endif 	/* __Dual_FWD_DEFINED__ */


#ifndef __Disp1_FWD_DEFINED__
#define __Disp1_FWD_DEFINED__

#ifdef __cplusplus
typedef class Disp1 Disp1;
#else
typedef struct Disp1 Disp1;
#endif /* __cplusplus */

#endif 	/* __Disp1_FWD_DEFINED__ */


#ifndef __Disp2_FWD_DEFINED__
#define __Disp2_FWD_DEFINED__

#ifdef __cplusplus
typedef class Disp2 Disp2;
#else
typedef struct Disp2 Disp2;
#endif /* __cplusplus */

#endif 	/* __Disp2_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 


#ifndef __ATLDISPLib_LIBRARY_DEFINED__
#define __ATLDISPLib_LIBRARY_DEFINED__

/* library ATLDISPLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_ATLDISPLib;

#ifndef __IDual_INTERFACE_DEFINED__
#define __IDual_INTERFACE_DEFINED__

/* interface IDual */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IDual;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("A960247D-6AAD-11D2-90D9-00104B2168FE")
    IDual : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SaySomething( 
            BSTR bstrSomething) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDualVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IDual __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IDual __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IDual __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IDual __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IDual __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IDual __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IDual __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SaySomething )( 
            IDual __RPC_FAR * This,
            BSTR bstrSomething);
        
        END_INTERFACE
    } IDualVtbl;

    interface IDual
    {
        CONST_VTBL struct IDualVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDual_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDual_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDual_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDual_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IDual_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IDual_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IDual_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IDual_SaySomething(This,bstrSomething)	\
    (This)->lpVtbl -> SaySomething(This,bstrSomething)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IDual_SaySomething_Proxy( 
    IDual __RPC_FAR * This,
    BSTR bstrSomething);


void __RPC_STUB IDual_SaySomething_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IDual_INTERFACE_DEFINED__ */


#ifndef __IDisp1_INTERFACE_DEFINED__
#define __IDisp1_INTERFACE_DEFINED__

/* interface IDisp1 */
/* [unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_IDisp1;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("A960247F-6AAD-11D2-90D9-00104B2168FE")
    IDisp1 : public IUnknown
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SaySomething( 
            BSTR bstrSomething) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDisp1Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IDisp1 __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IDisp1 __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IDisp1 __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SaySomething )( 
            IDisp1 __RPC_FAR * This,
            BSTR bstrSomething);
        
        END_INTERFACE
    } IDisp1Vtbl;

    interface IDisp1
    {
        CONST_VTBL struct IDisp1Vtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDisp1_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDisp1_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDisp1_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDisp1_SaySomething(This,bstrSomething)	\
    (This)->lpVtbl -> SaySomething(This,bstrSomething)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IDisp1_SaySomething_Proxy( 
    IDisp1 __RPC_FAR * This,
    BSTR bstrSomething);


void __RPC_STUB IDisp1_SaySomething_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IDisp1_INTERFACE_DEFINED__ */


#ifndef __DDisp1_DISPINTERFACE_DEFINED__
#define __DDisp1_DISPINTERFACE_DEFINED__

/* dispinterface DDisp1 */
/* [uuid] */ 


EXTERN_C const IID DIID_DDisp1;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("D33CD8B0-6D09-11d2-90DC-00104B2168FE")
    DDisp1 : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct DDisp1Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            DDisp1 __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            DDisp1 __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            DDisp1 __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            DDisp1 __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            DDisp1 __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            DDisp1 __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            DDisp1 __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } DDisp1Vtbl;

    interface DDisp1
    {
        CONST_VTBL struct DDisp1Vtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define DDisp1_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define DDisp1_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define DDisp1_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define DDisp1_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define DDisp1_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define DDisp1_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define DDisp1_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* __DDisp1_DISPINTERFACE_DEFINED__ */


#ifndef __DDisp2_DISPINTERFACE_DEFINED__
#define __DDisp2_DISPINTERFACE_DEFINED__

/* dispinterface DDisp2 */
/* [uuid] */ 


EXTERN_C const IID DIID_DDisp2;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("A9602483-6AAD-11D2-90D9-00104B2168FE")
    DDisp2 : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct DDisp2Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            DDisp2 __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            DDisp2 __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            DDisp2 __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            DDisp2 __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            DDisp2 __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            DDisp2 __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            DDisp2 __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } DDisp2Vtbl;

    interface DDisp2
    {
        CONST_VTBL struct DDisp2Vtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define DDisp2_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define DDisp2_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define DDisp2_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define DDisp2_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define DDisp2_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define DDisp2_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define DDisp2_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* __DDisp2_DISPINTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_Dual;

#ifdef __cplusplus

class DECLSPEC_UUID("A960247E-6AAD-11D2-90D9-00104B2168FE")
Dual;
#endif

EXTERN_C const CLSID CLSID_Disp1;

#ifdef __cplusplus

class DECLSPEC_UUID("A9602480-6AAD-11D2-90D9-00104B2168FE")
Disp1;
#endif

EXTERN_C const CLSID CLSID_Disp2;

#ifdef __cplusplus

class DECLSPEC_UUID("A9602484-6AAD-11D2-90D9-00104B2168FE")
Disp2;
#endif
#endif /* __ATLDISPLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
