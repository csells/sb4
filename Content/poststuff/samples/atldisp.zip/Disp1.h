// Disp1.h : Declaration of the CDisp1

#ifndef __DISP1_H_
#define __DISP1_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CDisp1
class ATL_NO_VTABLE CDisp1 : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CDisp1, &CLSID_Disp1>,
    // DONE: IDispatchImpl doesn't work here, but IDelegatingDispImpl will
	//public IDispatchImpl<IDisp1, &IID_IDisp1, &LIBID_ATLDISPLib>
    public IDelegatingDispImpl<DDisp1, IDisp1>
{
public:
	CDisp1()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_DISP1)
DECLARE_NOT_AGGREGATABLE(CDisp1)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CDisp1)
	COM_INTERFACE_ENTRY(IDisp1)
	COM_INTERFACE_ENTRY(DDisp1)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IDisp1
public:
	STDMETHOD(SaySomething)(BSTR bstrSomething);
};

#endif //__DISP1_H_
