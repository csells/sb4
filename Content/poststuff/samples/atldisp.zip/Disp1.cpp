// Disp1.cpp : Implementation of CDisp1
#include "stdafx.h"
#include "Atldisp.h"
#include "Disp1.h"

/////////////////////////////////////////////////////////////////////////////
// CDisp1


STDMETHODIMP CDisp1::SaySomething(BSTR bstrSomething)
{
	MessageBoxW(0, bstrSomething, L"CDisp1::SaySomething", MB_SETFOREGROUND);
	return S_OK;
}
