// Disp2.cpp : Implementation of CDisp2
#include "stdafx.h"
#include "Atldisp.h"
#include "Disp2.h"

/////////////////////////////////////////////////////////////////////////////
// CDisp2

// DDisp2
STDMETHODIMP CDisp2::Invoke(
    DISPID      dispIdMember,
    REFIID      riid,
    LCID        lcid,
    WORD        wFlags,
    DISPPARAMS* pDispParams,
    VARIANT*    pVarResult,
    EXCEPINFO*  pExcepInfo,
    UINT*       puArgErr)
{
    HRESULT hr = DISP_E_MEMBERNOTFOUND;

    switch( dispIdMember )
    {
    // SaySomething method
    case 1:
    {
        if( (wFlags == DISPATCH_METHOD) &&
            (pDispParams) &&
            (pDispParams->cArgs == 1) &&
            (pDispParams->rgvarg[0].vt == VT_BSTR) )
        {
            hr = SaySomething(pDispParams->rgvarg[0].bstrVal);
        }
        else
        {
            // Cop out, I know...
            hr = E_FAIL;
        }
    }
    break;
    }

    return hr;
}

STDMETHODIMP CDisp2::SaySomething(BSTR bstrSomething)
{
	MessageBoxW(0, bstrSomething, L"CDisp2::SaySomething", MB_SETFOREGROUND);
	return S_OK;
}
