// CoClockBox.cpp : Implementation of CClockBoxApp and DLL registration.
/////////////////////////////////////////////////////////////////////////////
// Copyright (c) 1996-1997, Chris Sells
// All rights reserved.
//
// NO WARRANTIES ARE EXTENDED. USE AT YOUR OWN RISK.
//
// To contact the author with suggestions or comments, use
// csells@sellsbrothers.com

#include "stdafx.h"
#include "ClockBox.h"
#include <ActivScp.h>
#include "CoClockBox.h"
#include <assert.h>

ITypeInfo* LoadTypeInfo(REFGUID guid);

/////////////////////////////////////////////////////////////////////////////
//

CoClockBox::CoClockBox()
    :
    m_hinst(0),
    m_hwndMain(0),
    m_pas(0),
    m_pClock(new CComObject<CoClock>)
{
    if( m_pClock ) m_pClock->AddRef();
}

CoClockBox::~CoClockBox()
{
    UnloadScript();
    if( m_pClock ) m_pClock->Release();
}

void CoClockBox::LoadScript(LPCSTR szFileName)
{
    USES_CONVERSION;
    assert(!m_pas);

    LPSTR   pszCode = 0;
    HANDLE  hFile = CreateFile(szFileName, GENERIC_READ, 0, 0, OPEN_EXISTING, 0, 0);
    if( hFile != INVALID_HANDLE_VALUE )
    {
        DWORD   nBytes = GetFileSize(hFile, 0);
        if( pszCode = new char[nBytes + 1] )
        {
            DWORD   nBytesRead;
            if( ReadFile(hFile, pszCode, nBytes, &nBytesRead, 0) &&
                nBytesRead == nBytes )
            {
                pszCode[nBytes] = 0;
            }
            else
            {
                pszCode[0] = 0;
            }
        }
        ::CloseHandle(hFile);
    }

    CLSID               clsid;
    IActiveScriptParse* pasp = 0;
    if( !pszCode ||
        FAILED(::CLSIDFromProgID(OLESTR("VBScript"), &clsid)) ||
        FAILED(::CoCreateInstance(clsid, 0, CLSCTX_ALL,
                                  IID_IActiveScript, (void**)&m_pas)) ||
        FAILED(m_pas->SetScriptSite((IActiveScriptSite*)this)) ||
        FAILED(m_pas->QueryInterface(IID_IActiveScriptParse, (void**)&pasp)) ||
        FAILED(pasp->InitNew()) ||
        FAILED(pasp->ParseScriptText(T2COLE(pszCode), 0, 0, 0, 0, 0, SCRIPTTEXT_ISVISIBLE, 0, 0)) ||
        FAILED(m_pas->AddNamedItem(L"ClockBox", SCRIPTITEM_ISSOURCE | SCRIPTITEM_ISVISIBLE)) ||
        FAILED(m_pas->SetScriptState(SCRIPTSTATE_CONNECTED)) )
    {
        UnloadScript();
        ::MessageBox(0, "Failed to load file.", 0, 0);
    }

    delete [] pszCode;
    if( pasp ) pasp->Release();
}

// IActiveScriptSite
STDMETHODIMP CoClockBox::GetDocVersionString(BSTR* pbstr)
{
    *pbstr = 0;
    return E_NOTIMPL;
}

STDMETHODIMP CoClockBox::GetLCID(LCID* plcid)
{
    *plcid = 0x409;
    return S_OK;
}

STDMETHODIMP CoClockBox::GetItemInfo(LPCOLESTR pstrName, DWORD dwReturnMask, IUnknown **ppunkItem, ITypeInfo **ppTypeInfo)
{
    if( !::_wcsicmp(pstrName, L"ClockBox") )
    {
        if( dwReturnMask & SCRIPTINFO_IUNKNOWN )
        {
            (*ppunkItem = (DIClockBox*)this)->AddRef();
            return S_OK;
        }
        if( dwReturnMask & SCRIPTINFO_ITYPEINFO	)
        {
            *ppTypeInfo = LoadTypeInfo(CLSID_CoClockBox);
            return (*ppTypeInfo ? S_OK : E_FAIL);
        }
        return E_FAIL;
    }
    else
    {
        return TYPE_E_ELEMENTNOTFOUND;
    }
}

STDMETHODIMP CoClockBox::OnEnterScript()
{
    return S_OK;
}

STDMETHODIMP CoClockBox::OnLeaveScript()
{
    return S_OK;
}

STDMETHODIMP CoClockBox::OnScriptError(IActiveScriptError* pase)
{
    USES_CONVERSION;

    EXCEPINFO   ei;
    pase->GetExceptionInfo(&ei);

    BSTR    bstrError;
    if( FAILED(pase->GetSourceLineText(&bstrError)) )
    {
        bstrError = ::SysAllocString(OLESTR("<unavailable>"));
    }

    DWORD   dwSourceContext;
    ULONG   nLineNo;
    LONG    nCharPos;
    pase->GetSourcePosition(&dwSourceContext, &nLineNo, &nCharPos);

    char    sz[1048];
    ::wsprintf(sz, "Line: %u\nCharacter: %d\nSource: '%s'\n\n%s",
               nLineNo, nCharPos, LPCSTR(OLE2CT(bstrError)),
               LPCSTR(OLE2CT(ei.bstrDescription)));
    
    HRESULT hr = S_OK;
    switch( ::MessageBox(m_hwndMain, sz, "Script Error", MB_ABORTRETRYIGNORE) )
    {
    case IDABORT: hr = E_FAIL; break;
    case IDRETRY: hr = S_FALSE; break;
    case IDIGNORE: hr = S_OK; break;
    }

    ::SysFreeString(bstrError);
    return hr;
}

STDMETHODIMP CoClockBox::OnScriptTerminate(const VARIANT* pvarResult, const EXCEPINFO* pei)
{
    return S_OK;
}

STDMETHODIMP CoClockBox::OnStateChange(SCRIPTSTATE ss)
{
    return S_OK;
}

// IActiveScriptSiteWindow
STDMETHODIMP CoClockBox::GetWindow(HWND* phwnd)
{
    *phwnd = m_hwndMain; return S_OK;
}

STDMETHODIMP CoClockBox::EnableModeless(BOOL bEnable)
{
    EnableWindow(m_hwndMain, bEnable); return S_OK;
}

// DIClockBox
STDMETHODIMP CoClockBox::GetClock(DIClock** ppClock)
{
    if( m_pClock )
    {
        (*ppClock = (DIClock*)m_pClock)->AddRef();
        return S_OK;
    }
    else
    {
        *ppClock = 0;
        return E_OUTOFMEMORY;
    }
}

// Gunk
void CoClockBox::UnloadScript()
{
    if( m_pas )
    {
        m_pas->Release();
        m_pas = 0;
    }
}

void CoClockBox::OnTimer()
{
    assert(m_pClock);

    // Let the clock know the current time
    time_t  t = time(0);
    m_pClock->put_Seconds(t);

    // Notify all interested parties
    Fire_OnTick((DIClock*)m_pClock, t);

    ::InvalidateRect(m_hwndMain, 0, TRUE);
}

void CoClockBox::OnPaint(HDC hdc)
{
    if( m_pClock )
    {
        RECT    rect;
        ::GetClientRect(m_hwndMain, &rect);
        m_pClock->DrawTime(hdc, rect);
    }
}

BOOL CoClockBox::Create(HINSTANCE hinst, int nCmdShow)
{
    LPCSTR      szWndClass = "ClockBoxMainWndClass";
    WNDCLASSEX  wc;
    ZeroMemory(&wc, sizeof(wc));
    
    wc.cbSize = sizeof(wc);
    wc.style = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;
    wc.lpfnWndProc = MainWndProc;
    wc.hInstance = m_hinst = hinst;
    wc.hbrBackground = HBRUSH(COLOR_WINDOW + 1);
    wc.lpszClassName = szWndClass;
    wc.hIcon = LoadIcon(0, MAKEINTRESOURCE(IDI_APPLICATION));
    wc.hCursor = LoadCursor(0, MAKEINTRESOURCE(IDC_ARROW));
    
    if( ::RegisterClassEx(&wc) )
    {
        m_hwndMain = ::CreateWindow(szWndClass, "ClockBox",
                                    WS_OVERLAPPEDWINDOW,
                                    CW_USEDEFAULT, CW_USEDEFAULT,
                                    CW_USEDEFAULT, CW_USEDEFAULT,
                                    0, 0, m_hinst, 0);
        if( m_hwndMain )
        {
            ::ShowWindow(m_hwndMain, nCmdShow);
            ::UpdateWindow(m_hwndMain);

            // Start the clock(s) ticking
            if( m_pClock )
            {
                ::SetTimer(m_hwndMain, 1, 1000, 0);
            }

            return TRUE;
        }
    }
            
    return FALSE;
}

static
ITypeInfo* LoadTypeInfo(REFGUID guid)
{
    USES_CONVERSION;
    char    szFileName[MAX_PATH];
    ::GetModuleFileName(0, szFileName, sizeof(szFileName));

    ITypeLib*   ptl;
    ITypeInfo*  pti = 0;
    if( SUCCEEDED(::LoadTypeLib(T2COLE(szFileName), &ptl)) )
    {
        ptl->GetTypeInfoOfGuid(guid, &pti);
        ptl->Release();
    }
    return pti;
}

