// ClockBox.cpp : Implementation of WinMain

// You will need the NT SUR Beta 2 SDK or VC 4.2 in order to build this 
// project.  This is because you will need MIDL 3.00.15 or higher and new
// headers and libs.  If you have VC 4.2 installed, then everything should
// already be configured correctly.

// Note: Proxy/Stub Information
//		To build a separate proxy/stub DLL, 
//		run nmake -f ClockBoxps.mak in the project directory.

#include "stdafx.h"
#include "resource.h"
#include <initguid.h>
#include <ActivScp.h>
#include "ClockBox.h"
#include "CoClockBox.h"

#define IID_DEFINED
#include "ClockBox_i.c"


LONG CExeModule::Unlock()
{
	LONG l = CComModule::Unlock();
	if (l == 0)
		PostThreadMessage(dwThreadID, WM_QUIT, 0, 0);
	return l;
}

CExeModule _Module;

BEGIN_OBJECT_MAP(ObjectMap)
	OBJECT_ENTRY(CLSID_CoClockBox, CoClockBox)
END_OBJECT_MAP()


/////////////////////////////////////////////////////////////////////////////
//

// CoClockBox singleton
CComObject<CoClockBox>* g_cb = 0;

extern "C" int WINAPI _tWinMain(HINSTANCE hInstance, 
	HINSTANCE /*hPrevInstance*/, LPTSTR lpCmdLine, int nShowCmd)
{
	HRESULT hRes = CoInitialize(NULL);
//  If you are running on NT 4.0 or higher you can use the following call
//	instead to make the EXE free threaded.
//  This means that calls come in on a random RPC thread
//	HRESULT hRes = CoInitializeEx(NULL, COINIT_MULTITHREADED);
	_ASSERTE(SUCCEEDED(hRes));
	_Module.Init(ObjectMap, hInstance);
	_Module.dwThreadID = GetCurrentThreadId();
	TCHAR szTokens[] = _T("-/");

	LPTSTR lpszToken = _tcstok(lpCmdLine, szTokens);
	while (lpszToken != NULL)
	{
		if (_tcsicmp(lpszToken, _T("UnregServer"))==0)
			return _Module.UnregisterServer();
		else if (_tcsicmp(lpszToken, _T("RegServer"))==0)
			return _Module.RegisterServer(TRUE);
		lpszToken = _tcstok(NULL, szTokens);
	}

    // No objects are COM-Createable
	//hRes = _Module.RegisterClassObjects(CLSCTX_LOCAL_SERVER, REGCLS_MULTIPLEUSE);
	//_ASSERTE(SUCCEEDED(hRes));

    g_cb = new CComObject<CoClockBox>;
    if( g_cb )
    {
        g_cb->AddRef();

        if( g_cb->Create(hInstance, nShowCmd) )
        {
            if( lpCmdLine && *lpCmdLine )
            {
                g_cb->LoadScript(lpCmdLine);
            }
            
            MSG msg;
            while( ::GetMessage(&msg, 0, 0, 0) )
            {
                ::TranslateMessage(&msg);
                ::DispatchMessage(&msg);
            }
        }

        g_cb->Release();
    }
    
    //_Module.RevokeClassObjects();

	CoUninitialize();
	return 0;
}

LRESULT CALLBACK MainWndProc(HWND hwnd, UINT nMsg, WPARAM wparam, LPARAM lparam)
{
    switch( nMsg )
    {
    case WM_CLOSE:
        ::PostQuitMessage(0);
    break;

    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC         hdc = ::BeginPaint(hwnd, &ps);

        if( g_cb ) g_cb->OnPaint(hdc);

        ::EndPaint(hwnd, &ps);
    }
    break;

    case WM_TIMER:
        if( g_cb ) g_cb->OnTimer();
    break;

    default:
        return ::DefWindowProc(hwnd, nMsg, wparam, lparam);
    break;
    }

    return 0;
}
