/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 3.01.75 */
/* at Mon Nov 17 12:40:31 1997
 */
/* Compiler settings for ClockBox.idl:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )
#include "rpc.h"
#include "rpcndr.h"
#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __ClockBox_h__
#define __ClockBox_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __DIClock_FWD_DEFINED__
#define __DIClock_FWD_DEFINED__
typedef interface DIClock DIClock;
#endif 	/* __DIClock_FWD_DEFINED__ */


#ifndef __DIClockBox_FWD_DEFINED__
#define __DIClockBox_FWD_DEFINED__
typedef interface DIClockBox DIClockBox;
#endif 	/* __DIClockBox_FWD_DEFINED__ */


#ifndef __DClockBoxEvents_FWD_DEFINED__
#define __DClockBoxEvents_FWD_DEFINED__
typedef interface DClockBoxEvents DClockBoxEvents;
#endif 	/* __DClockBoxEvents_FWD_DEFINED__ */


#ifndef __CoClock_FWD_DEFINED__
#define __CoClock_FWD_DEFINED__

#ifdef __cplusplus
typedef class CoClock CoClock;
#else
typedef struct CoClock CoClock;
#endif /* __cplusplus */

#endif 	/* __CoClock_FWD_DEFINED__ */


#ifndef __CoClockBox_FWD_DEFINED__
#define __CoClockBox_FWD_DEFINED__

#ifdef __cplusplus
typedef class CoClockBox CoClockBox;
#else
typedef struct CoClockBox CoClockBox;
#endif /* __cplusplus */

#endif 	/* __CoClockBox_FWD_DEFINED__ */


/* header files for imported files */
#include "unknwn.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __DIClock_INTERFACE_DEFINED__
#define __DIClock_INTERFACE_DEFINED__

/****************************************
 * Generated header for interface: DIClock
 * at Mon Nov 17 12:40:31 1997
 * using MIDL 3.01.75
 ****************************************/
/* [unique][helpstring][dual][uuid][object] */ 



EXTERN_C const IID IID_DIClock;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    interface DECLSPEC_UUID("F7B5348C-1664-11D0-93CF-468127000000")
    DIClock : public IDispatch
    {
    public:
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Caption( 
            /* [string][in] */ BSTR bstrCaption) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Caption( 
            /* [retval][string][out] */ BSTR __RPC_FAR *pbstrCaption) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Local( 
            /* [in] */ VARIANT_BOOL bLocal) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Local( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pbLocal) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Seconds( 
            /* [in] */ long nSeconds) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Seconds( 
            /* [retval][out] */ long __RPC_FAR *pnSeconds) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_FontSize( 
            /* [in] */ int nPointSize) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_FontSize( 
            /* [retval][out] */ int __RPC_FAR *pnPointSize) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct DIClockVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            DIClock __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            DIClock __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            DIClock __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            DIClock __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            DIClock __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            DIClock __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            DIClock __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Caption )( 
            DIClock __RPC_FAR * This,
            /* [string][in] */ BSTR bstrCaption);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Caption )( 
            DIClock __RPC_FAR * This,
            /* [retval][string][out] */ BSTR __RPC_FAR *pbstrCaption);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Local )( 
            DIClock __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL bLocal);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Local )( 
            DIClock __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pbLocal);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Seconds )( 
            DIClock __RPC_FAR * This,
            /* [in] */ long nSeconds);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Seconds )( 
            DIClock __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pnSeconds);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FontSize )( 
            DIClock __RPC_FAR * This,
            /* [in] */ int nPointSize);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FontSize )( 
            DIClock __RPC_FAR * This,
            /* [retval][out] */ int __RPC_FAR *pnPointSize);
        
        END_INTERFACE
    } DIClockVtbl;

    interface DIClock
    {
        CONST_VTBL struct DIClockVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define DIClock_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define DIClock_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define DIClock_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define DIClock_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define DIClock_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define DIClock_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define DIClock_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define DIClock_put_Caption(This,bstrCaption)	\
    (This)->lpVtbl -> put_Caption(This,bstrCaption)

#define DIClock_get_Caption(This,pbstrCaption)	\
    (This)->lpVtbl -> get_Caption(This,pbstrCaption)

#define DIClock_put_Local(This,bLocal)	\
    (This)->lpVtbl -> put_Local(This,bLocal)

#define DIClock_get_Local(This,pbLocal)	\
    (This)->lpVtbl -> get_Local(This,pbLocal)

#define DIClock_put_Seconds(This,nSeconds)	\
    (This)->lpVtbl -> put_Seconds(This,nSeconds)

#define DIClock_get_Seconds(This,pnSeconds)	\
    (This)->lpVtbl -> get_Seconds(This,pnSeconds)

#define DIClock_put_FontSize(This,nPointSize)	\
    (This)->lpVtbl -> put_FontSize(This,nPointSize)

#define DIClock_get_FontSize(This,pnPointSize)	\
    (This)->lpVtbl -> get_FontSize(This,pnPointSize)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [propput] */ HRESULT STDMETHODCALLTYPE DIClock_put_Caption_Proxy( 
    DIClock __RPC_FAR * This,
    /* [string][in] */ BSTR bstrCaption);


void __RPC_STUB DIClock_put_Caption_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE DIClock_get_Caption_Proxy( 
    DIClock __RPC_FAR * This,
    /* [retval][string][out] */ BSTR __RPC_FAR *pbstrCaption);


void __RPC_STUB DIClock_get_Caption_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE DIClock_put_Local_Proxy( 
    DIClock __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL bLocal);


void __RPC_STUB DIClock_put_Local_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE DIClock_get_Local_Proxy( 
    DIClock __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pbLocal);


void __RPC_STUB DIClock_get_Local_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE DIClock_put_Seconds_Proxy( 
    DIClock __RPC_FAR * This,
    /* [in] */ long nSeconds);


void __RPC_STUB DIClock_put_Seconds_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE DIClock_get_Seconds_Proxy( 
    DIClock __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pnSeconds);


void __RPC_STUB DIClock_get_Seconds_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE DIClock_put_FontSize_Proxy( 
    DIClock __RPC_FAR * This,
    /* [in] */ int nPointSize);


void __RPC_STUB DIClock_put_FontSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE DIClock_get_FontSize_Proxy( 
    DIClock __RPC_FAR * This,
    /* [retval][out] */ int __RPC_FAR *pnPointSize);


void __RPC_STUB DIClock_get_FontSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __DIClock_INTERFACE_DEFINED__ */


#ifndef __DIClockBox_INTERFACE_DEFINED__
#define __DIClockBox_INTERFACE_DEFINED__

/****************************************
 * Generated header for interface: DIClockBox
 * at Mon Nov 17 12:40:31 1997
 * using MIDL 3.01.75
 ****************************************/
/* [unique][helpstring][dual][uuid][object] */ 



EXTERN_C const IID IID_DIClockBox;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    interface DECLSPEC_UUID("F7B53483-1664-11D0-93CF-468127000000")
    DIClockBox : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE GetClock( 
            /* [retval][out] */ DIClock __RPC_FAR *__RPC_FAR *ppClock) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct DIClockBoxVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            DIClockBox __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            DIClockBox __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            DIClockBox __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            DIClockBox __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            DIClockBox __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            DIClockBox __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            DIClockBox __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetClock )( 
            DIClockBox __RPC_FAR * This,
            /* [retval][out] */ DIClock __RPC_FAR *__RPC_FAR *ppClock);
        
        END_INTERFACE
    } DIClockBoxVtbl;

    interface DIClockBox
    {
        CONST_VTBL struct DIClockBoxVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define DIClockBox_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define DIClockBox_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define DIClockBox_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define DIClockBox_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define DIClockBox_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define DIClockBox_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define DIClockBox_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define DIClockBox_GetClock(This,ppClock)	\
    (This)->lpVtbl -> GetClock(This,ppClock)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE DIClockBox_GetClock_Proxy( 
    DIClockBox __RPC_FAR * This,
    /* [retval][out] */ DIClock __RPC_FAR *__RPC_FAR *ppClock);


void __RPC_STUB DIClockBox_GetClock_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __DIClockBox_INTERFACE_DEFINED__ */



#ifndef __CLOCKBOXLib_LIBRARY_DEFINED__
#define __CLOCKBOXLib_LIBRARY_DEFINED__

/****************************************
 * Generated header for library: CLOCKBOXLib
 * at Mon Nov 17 12:40:31 1997
 * using MIDL 3.01.75
 ****************************************/
/* [helpstring][version][uuid] */ 



EXTERN_C const IID LIBID_CLOCKBOXLib;

#ifndef __DClockBoxEvents_DISPINTERFACE_DEFINED__
#define __DClockBoxEvents_DISPINTERFACE_DEFINED__

/****************************************
 * Generated header for dispinterface: DClockBoxEvents
 * at Mon Nov 17 12:40:31 1997
 * using MIDL 3.01.75
 ****************************************/
/* [uuid] */ 



EXTERN_C const IID DIID_DClockBoxEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    interface DECLSPEC_UUID("372A3A40-1595-11d0-93CE-E87291000000")
    DClockBoxEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct DClockBoxEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            DClockBoxEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            DClockBoxEvents __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            DClockBoxEvents __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            DClockBoxEvents __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            DClockBoxEvents __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            DClockBoxEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            DClockBoxEvents __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } DClockBoxEventsVtbl;

    interface DClockBoxEvents
    {
        CONST_VTBL struct DClockBoxEventsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define DClockBoxEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define DClockBoxEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define DClockBoxEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define DClockBoxEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define DClockBoxEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define DClockBoxEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define DClockBoxEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* __DClockBoxEvents_DISPINTERFACE_DEFINED__ */


#ifdef __cplusplus
EXTERN_C const CLSID CLSID_CoClock;

class DECLSPEC_UUID("F7B53490-1664-11D0-93CF-468127000000")
CoClock;
#endif

#ifdef __cplusplus
EXTERN_C const CLSID CLSID_CoClockBox;

class DECLSPEC_UUID("F7B53487-1664-11D0-93CF-468127000000")
CoClockBox;
#endif
#endif /* __CLOCKBOXLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
