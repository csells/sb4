// pch.h: Precompiled header

#include <windows.h>
#include <assert.h>
#include <Strng816.h>