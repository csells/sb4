// CoClockBox.h : Declaration of the CoClockBox
/////////////////////////////////////////////////////////////////////////////
// Copyright (c) 1996-1997, Chris Sells
// All rights reserved.
//
// NO WARRANTIES ARE EXTENDED. USE AT YOUR OWN RISK.
//
// To contact the author with suggestions or comments, use
// csells@sellsbrothers.com

#ifndef __CLOCKBOX_H_
#define __CLOCKBOX_H_

#include "resource.h"       // main symbols
#include "CoClock.h"
#include "CPClockBox.h"

/////////////////////////////////////////////////////////////////////////////
// ClockBox

class ATL_NO_VTABLE CoClockBox : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CoClockBox,&CLSID_CoClockBox>,
	public IConnectionPointContainerImpl<CoClockBox>,
    public CProxyDClockBoxEvents<CoClockBox>,
	public IDispatchImpl<DIClockBox, &IID_DIClockBox, &LIBID_CLOCKBOXLib>,
	public ISupportErrorInfoImpl<&IID_DIClockBox>,
    public IActiveScriptSite,
    public IActiveScriptSiteWindow
{
public:
BEGIN_COM_MAP(CoClockBox)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(DIClockBox)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(IActiveScriptSite)
	COM_INTERFACE_ENTRY(IActiveScriptSiteWindow)
	COM_INTERFACE_ENTRY_IMPL(IConnectionPointContainer)
END_COM_MAP()
DECLARE_NOT_AGGREGATABLE(CoClockBox) 
// Remove the comment from the line above if you don't want your object to 
// support aggregation.  The default is to support it

// Connection Point
BEGIN_CONNECTION_POINT_MAP(CoClockBox)
    CONNECTION_POINT_ENTRY(DIID_DClockBoxEvents)
END_CONNECTION_POINT_MAP()

DECLARE_REGISTRY_RESOURCEID(IDR_ClockBox)

public:
    CoClockBox();
    virtual ~CoClockBox();

    BOOL Create(HINSTANCE hinst, int nCmdShow);
    void LoadScript(LPCSTR szFileName);

    // IActiveScriptSite
    STDMETHODIMP GetDocVersionString(BSTR* pbstr);
    STDMETHODIMP GetLCID(LCID* plcid);
    STDMETHODIMP GetItemInfo(LPCOLESTR pstrName, DWORD dwReturnMask, IUnknown **ppunkItem, ITypeInfo **ppTypeInfo);
    STDMETHODIMP OnEnterScript();
    STDMETHODIMP OnLeaveScript();
    STDMETHODIMP OnScriptError(IActiveScriptError* pase);
    STDMETHODIMP OnScriptTerminate(const VARIANT* pvarResult, const EXCEPINFO* pei);
    STDMETHODIMP OnStateChange(SCRIPTSTATE ss);

    // IActiveScriptSiteWindow
    STDMETHODIMP GetWindow(HWND* phwnd);
    STDMETHODIMP EnableModeless(BOOL bEnable);

    // DIClockBox
    STDMETHODIMP GetClock(DIClock** ppClock);
    
    // Implementation
private:
    void UnloadScript();
    void OnTimer();
    void OnPaint(HDC hdc);
    
private:
    IActiveScript*      m_pas;
    HINSTANCE           m_hinst;
    HWND                m_hwndMain;
    CComObject<CoClock>*    m_pClock;

    friend LRESULT CALLBACK
        MainWndProc(HWND hwnd, UINT nMsg, WPARAM wparam, LPARAM lparam);
};

#endif //__CLOCKBOX_H_
