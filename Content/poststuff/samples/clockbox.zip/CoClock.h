// CoClock.h : Declaration of the CoClock
/////////////////////////////////////////////////////////////////////////////
// Copyright (c) 1996-1997, Chris Sells
// All rights reserved.
//
// NO WARRANTIES ARE EXTENDED. USE AT YOUR OWN RISK.
//
// To contact the author with suggestions or comments, use
// csells@sellsbrothers.com

#include "resource.h"       // main symbols
#include <time.h>

/////////////////////////////////////////////////////////////////////////////
// Clock

class CoClock : 
	public CComDualImpl<DIClock, &IID_DIClock, &LIBID_CLOCKBOXLib>, 
	public ISupportErrorInfoImpl<&IID_DIClock>,
	public CComObjectRoot,
	public CComCoClass<CoClock,&CLSID_CoClock>
{
public:
BEGIN_COM_MAP(CoClock)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(DIClock)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()
DECLARE_NOT_AGGREGATABLE(CoClock) 
// Remove the comment from the line above if you don't want your object to 
// support aggregation.  The default is to support it

public:
    CoClock();
    virtual ~CoClock();

// DIClock
    STDMETHODIMP put_Caption(BSTR bstrCaption);
    STDMETHODIMP get_Caption(BSTR* pbstrCaption);
    STDMETHODIMP put_Local(VARIANT_BOOL bLocal);
    STDMETHODIMP get_Local(VARIANT_BOOL* pbLocal);
    STDMETHODIMP get_Seconds(long* pnSeconds);
    STDMETHODIMP put_Seconds(long nSeconds);
    STDMETHODIMP get_FontSize(int* pnPointSize);
    STDMETHODIMP put_FontSize(int nPointSize);

// Implementation
private:
    void DrawTime(HDC hdc, RECT rect);

// Properties
private:
    char    m_szCaption[128];
    time_t  m_time;
    BOOL    m_bLocal;
    int     m_nPointSize;

    friend class CoClockBox;
};
