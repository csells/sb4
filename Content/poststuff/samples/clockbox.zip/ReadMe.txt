ClockBox
Copyright (c) 1996-1997, Chris Sells
All rights reserved.
NO WARRANTIES ARE EXTENDED. USE AT YOUR OWN RISK.
Contact the author at csells@sellsbrothers.com with suggestions or comments.

This is a sample application to show how to be an Active Scripting Host.
It is meant as a bare-bones implementation to show the minimum implementation
of IActiveScriptSite and IActiveScriptSiteWindow (see CoClockBox.cpp).

The ClockBox application will take any script file on the command
line as the script to run. Running ClockBox.exe /regserver will
cause the shell to associate .cbs (ClockBox Script) files with
the ClockBox application. See the Scripts directory for some sample
ClockBox scripts.
