/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 3.01.75 */
/* at Mon Nov 17 12:40:31 1997
 */
/* Compiler settings for ClockBox.idl:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_DIClock = {0xF7B5348C,0x1664,0x11D0,{0x93,0xCF,0x46,0x81,0x27,0x00,0x00,0x00}};


const IID IID_DIClockBox = {0xF7B53483,0x1664,0x11D0,{0x93,0xCF,0x46,0x81,0x27,0x00,0x00,0x00}};


const IID LIBID_CLOCKBOXLib = {0xF7B53481,0x1664,0x11D0,{0x93,0xCF,0x46,0x81,0x27,0x00,0x00,0x00}};


const IID DIID_DClockBoxEvents = {0x372A3A40,0x1595,0x11d0,{0x93,0xCE,0xE8,0x72,0x91,0x00,0x00,0x00}};


const CLSID CLSID_CoClock = {0xF7B53490,0x1664,0x11D0,{0x93,0xCF,0x46,0x81,0x27,0x00,0x00,0x00}};


const CLSID CLSID_CoClockBox = {0xF7B53487,0x1664,0x11D0,{0x93,0xCF,0x46,0x81,0x27,0x00,0x00,0x00}};


#ifdef __cplusplus
}
#endif

