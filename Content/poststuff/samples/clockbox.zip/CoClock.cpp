// CoClock.cpp : Implementation of CClockApp and DLL registration.
/////////////////////////////////////////////////////////////////////////////
// Copyright (c) 1996-1997, Chris Sells
// All rights reserved.
//
// NO WARRANTIES ARE EXTENDED. USE AT YOUR OWN RISK.
//
// To contact the author with suggestions or comments, use
// csells@sellsbrothers.com

#include "stdafx.h"
#include "ClockBox.h"
#include "CoClock.h"
#include <assert.h>

#define DIM(a) (sizeof(a)/sizeof(*a))

/////////////////////////////////////////////////////////////////////////////

CoClock::CoClock()
    :
    m_time(0),
    m_bLocal(FALSE),
    m_nPointSize(24)
{
    ::strcpy(m_szCaption, "Univeral Coordinated Time");
}

CoClock::~CoClock()
{
}

// DIClock
STDMETHODIMP CoClock::put_Caption(BSTR bstrCaption)
{
    USES_CONVERSION;
    ::strncpy(m_szCaption, OLE2CT(bstrCaption), DIM(m_szCaption));
    return S_OK;
}

STDMETHODIMP CoClock::get_Caption(BSTR* pbstrCaption)
{
    USES_CONVERSION;
    *pbstrCaption = ::SysAllocString(T2COLE(m_szCaption));
    return (pbstrCaption ? S_OK : E_OUTOFMEMORY);
}

STDMETHODIMP CoClock::put_Local(VARIANT_BOOL bLocal)
{
    m_bLocal = (bLocal == VARIANT_TRUE ? TRUE : FALSE);
    return S_OK;
}

STDMETHODIMP CoClock::get_Local(VARIANT_BOOL* pbLocal)
{
    *pbLocal = (m_bLocal ? VARIANT_TRUE : VARIANT_FALSE);
    return S_OK;
}

STDMETHODIMP CoClock::get_Seconds(long* pnSeconds)
{
    *pnSeconds = m_time;
    return S_OK;
}

STDMETHODIMP CoClock::put_Seconds(long nSeconds)
{
    m_time = nSeconds;
    return S_OK;
}

STDMETHODIMP CoClock::get_FontSize(int* pnPointSize)
{
    *pnPointSize = m_nPointSize;
    return S_OK;
}

STDMETHODIMP CoClock::put_FontSize(int nPointSize)
{
    m_nPointSize = nPointSize;
    return S_OK;
}

// Implementation
void CoClock::DrawTime(HDC hdc, RECT rect)
{
    USES_CONVERSION;

    if( m_time )
    {
        tm* ptm = (m_bLocal ? ::localtime(&m_time) : ::gmtime(&m_time));
        
        char    szTime[128];
        ::strftime(szTime, DIM(szTime), "%I:%M:%S %p\r\n%A, %B %d, %Y\r\n", ptm);
        ::strcat(szTime, m_szCaption);

        LOGFONT lf;
        ::ZeroMemory(&lf, sizeof(lf));
        lf.lfHeight = -::MulDiv(m_nPointSize, ::GetDeviceCaps(hdc, LOGPIXELSY), 72);
        HFONT   hfont = ::CreateFontIndirect(&lf);
        assert(hfont);

        HFONT   hfontOld = ::SelectObject(hdc, hfont);
        RECT    rectCalc = {0, 0, rect.right, 0};
        ::DrawText(hdc, szTime, -1, &rectCalc, DT_CALCRECT);

        int nTextHeight = rectCalc.bottom - rectCalc.top;
        rect.top += (rect.bottom - rect.top - nTextHeight)/2;
        ::DrawText(hdc, szTime, -1, &rect, DT_CENTER);

        ::SelectObject(hdc, hfontOld);
    }
}
