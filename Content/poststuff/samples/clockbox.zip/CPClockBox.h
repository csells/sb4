
//////////////////////////////////////////////////////////////////////////////
// CProxyDClockBoxEvents
template <class T>
class CProxyDClockBoxEvents : public IConnectionPointImpl<T, &DIID_DClockBoxEvents, CComDynamicUnkArray>
{
public:
//methods:
//DClockBoxEvents : IDispatch
public:
	void Fire_OnTick(
		DIClock * pClock,
		long nSeconds)
	{
		VARIANTARG* pvars = new VARIANTARG[2];
		for (int i = 0; i < 2; i++)
			VariantInit(&pvars[i]);
		T* pT = (T*)this;
		pT->Lock();
		IUnknown** pp = m_vec.begin();
		while (pp < m_vec.end())
		{
			if (*pp != NULL)
			{
				pvars[1].vt = VT_DISPATCH;
				pvars[1].pdispVal = pClock;
				pvars[0].vt = VT_I4;
				pvars[0].lVal= nSeconds;
				DISPPARAMS disp = { pvars, NULL, 2, 0 };
				IDispatch* pDispatch = reinterpret_cast<IDispatch*>(*pp);
				pDispatch->Invoke(0x1, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, NULL, NULL, NULL);
			}
			pp++;
		}
		pT->Unlock();
		delete[] pvars;
	}

};

