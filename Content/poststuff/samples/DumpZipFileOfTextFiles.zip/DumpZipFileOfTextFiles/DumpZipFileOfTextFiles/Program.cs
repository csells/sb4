using System;
using System.Collections.Generic;
using System.Text;
using java.util; // all from vjslib assembly
using java.util.zip;
using java.io;

namespace DumpZipFileOfTextFiles {
  class Program {
    static void Main(string[] args) {
      if( args.Length != 1 ) {
        Console.WriteLine("Usage: dumpzipfileoftextfiles <file>");
        return;
      }

      // we're assuming a zip file full of ASCII text files here
      string filename = args[0];
      ZipFile zip = new ZipFile(filename);

      try {
        // enumerate entries in the zip file
        // NOTE: can't enum via foreach -- Java objects don't support it
        Enumeration entries = zip.entries();
        while( entries.hasMoreElements() ) {
          ZipEntry entry = (ZipEntry)entries.nextElement();

          // read text bytes into an ASCII string
          byte[] bytes = ReadZipBytes(zip, entry);
          string s = ASCIIEncoding.ASCII.GetString(bytes);

          // do something w/ the text
          string entryname = entry.getName();
          Console.WriteLine("{0}:\r\n{1}\r\n", entryname, s);
        }
      }
      finally {
        if( zip != null ) { zip.close(); }
      }
    }

    static byte[] ReadZipBytes(ZipFile zip, ZipEntry entry) {
      // read contents of text stream into bytes
      InputStream instream = zip.getInputStream(entry);
      int size = (int)entry.getSize();
      sbyte[] sbytes = new sbyte[size];
      int offset = 0;
      while( true ) {
        int read = instream.read(sbytes, offset, size - offset);
        if( read == -1 ) { break; }
        offset += read;
      }
      instream.close();

      // this is the magic method for converting signed bytes
      // in unsigned bytes for use with the rest of .NET, e.g.
      // ASCIIEncoding.ASCII.GetString(bytes[]) or new MemoryStream(bytes[])
      return (byte[])(object)sbytes;
    }

  }
}
