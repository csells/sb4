DlgCtrl
Copyright (c) 1998, Chris Sells
All rights reserved.
NO WARRANTIES ARE EXTENDED. USE AT YOUR OWN RISK.
Contact the author at csells@sellsbrothers.com with suggestions or comments.

This is a sample application to show how to build an ActiveX Control
in ATL based on a dialog box template. This technique is an illustration
of the technique described in Microsoft Knowledge Base Article Q175503.
