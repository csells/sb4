// ComDlgCtrl.h

#ifndef COMDLGCTRL_H
#define COMDLGCTRL_H

template <typename Deriving>
class ATL_NO_VTABLE CComDlgControl :
    public CComControlBase,
    public CDialogImpl<Deriving>
{
public:
    CComDlgControl() : CComControlBase(m_hWnd)
    {
        Deriving* p = static_cast<Deriving*>(this);
        p->m_bWindowOnly = TRUE;
    }

    HRESULT FireOnRequestEdit(DISPID dispID)
    {
        Deriving* p = static_cast<Deriving*>(this);
        return Deriving::__ATL_PROP_NOTIFY_EVENT_CLASS::FireOnRequestEdit(p->GetUnknown(), dispID);
    }

    HRESULT FireOnChanged(DISPID dispID)
    {
        Deriving* p = static_cast<Deriving*>(this);
        return Deriving::__ATL_PROP_NOTIFY_EVENT_CLASS::FireOnChanged(p->GetUnknown(), dispID);
    }

    virtual HRESULT ControlQueryInterface(const IID& iid, void** ppv)
    {
        Deriving* p = static_cast<Deriving*>(this);
        return p->_InternalQueryInterface(iid, ppv);
    }

    virtual HWND CreateControlWindow(HWND hWndParent, RECT& rcPos)
    {
        // CDialogImpl::Create differs from CWindowImpl         
        Deriving* p = static_cast<Deriving*>(this);
        return p->Create(hWndParent);
    }
};

#endif  // COMDLGCTRL_H
