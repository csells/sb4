// CalcSquare.cpp : Implementation of CCalcSquare
#include "stdafx.h"
#include "DlgCtrl.h"
#include "CalcSquare.h"

/////////////////////////////////////////////////////////////////////////////
// CCalcSquare

CCalcSquare::CCalcSquare()
{
}

// ICalcSquare
STDMETHODIMP CCalcSquare::get_Op1(long * pVal)
{
    if( m_editOp1.m_hWnd )
    {
        *pVal = GetDlgItemInt(IDC_OP1);
	    return S_OK;
    }

    return E_UNEXPECTED;
}

STDMETHODIMP CCalcSquare::put_Op1(long newVal)
{
    if( m_editOp1.m_hWnd )
    {
        SetDlgItemInt(IDC_OP1, newVal);
        FireOnChanged(1);
	    return S_OK;
    }

    return E_UNEXPECTED;
}

STDMETHODIMP CCalcSquare::get_Op2(long * pVal)
{
    if( m_editOp2.m_hWnd )
    {
        *pVal = GetDlgItemInt(IDC_OP2);
	    return S_OK;
    }

    return E_UNEXPECTED;
}

STDMETHODIMP CCalcSquare::put_Op2(long newVal)
{
    if( m_editOp2.m_hWnd )
    {
        SetDlgItemInt(IDC_OP2, newVal);
        FireOnChanged(2);
	    return S_OK;
    }

    return E_UNEXPECTED;
}

STDMETHODIMP CCalcSquare::get_Sum(long * pVal)
{
    if( m_editSum.m_hWnd )
    {
        *pVal = GetDlgItemInt(IDC_SUM);
	    return S_OK;
    }

    return E_UNEXPECTED;
}

STDMETHODIMP CCalcSquare::put_Sum(long newVal)
{
    if( m_editSum.m_hWnd )
    {
        SetDlgItemInt(IDC_SUM, newVal);
        FireOnChanged(3);
	    return S_OK;
    }

    return E_UNEXPECTED;
}

STDMETHODIMP CCalcSquare::Add()
{
    HRESULT hr;
    long    nOp1;
    long    nOp2;

    if( SUCCEEDED(hr = this->get_Op1(&nOp1)) &&
        SUCCEEDED(hr = this->get_Op2(&nOp2)) )
    {
        hr = this->put_Sum(nOp1 + nOp2);
    }

    return hr;
}

// Overrides
STDMETHODIMP CCalcSquare::GetViewStatus(DWORD* pdwStatus)
{
	ATLTRACE(_T("IViewObjectExImpl::GetViewStatus\n"));
	*pdwStatus = VIEWSTATUS_SOLIDBKGND | VIEWSTATUS_OPAQUE;
	return S_OK;
}

STDMETHODIMP CCalcSquare::TranslateAccelerator(MSG *pMsg)
{
	ATLTRACE(_T("IOleInPlaceActiveObjectImpl::TranslateAccelerator\n"));
    if( (pMsg->message < WM_KEYFIRST || pMsg->message > WM_KEYLAST) &&
        (pMsg->message < WM_MOUSEFIRST || pMsg->message > WM_MOUSELAST) )
    {
        return S_FALSE;
    }

    return (IsDialogMessage(m_hWnd, pMsg) ? S_OK : S_FALSE);
}

// Message Handlers

// DONE
LRESULT CCalcSquare::OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
    this->InPlaceActivate(OLEIVERB_UIACTIVATE);

    // TODO: Perform any dialog initialization
    m_editOp1.Attach(GetDlgItem(IDC_OP1));
    m_editOp2.Attach(GetDlgItem(IDC_OP2));
    m_btnAdd.Attach(GetDlgItem(IDC_ADD));
    m_editSum.Attach(GetDlgItem(IDC_SUM));

    return 0;
}

LRESULT CCalcSquare::OnAdd(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
    this->Add();
    return 0;
}

