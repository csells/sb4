//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DlgCtrl.rc
//
#define IDS_PROJNAME                    100
#define IDR_CALCSQUARE                  101
#define IDC_OP1                         201
#define IDD_CALCSQUARE                  201
#define IDC_OP2                         202
#define IDC_ADD                         203
#define IDC_SUM                         204

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
