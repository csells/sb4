// CalcSquare.h : Declaration of the CCalcSquare

#ifndef __CALCSQUARE_H_
#define __CALCSQUARE_H_

#include "resource.h"   // main symbols
#include "ComDlgCtrl.h" // DONE

/////////////////////////////////////////////////////////////////////////////
// CCalcSquare
class ATL_NO_VTABLE CCalcSquare :
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CCalcSquare,&CLSID_CalcSquare>,
    // DONE
	//public CComControl<CCalcSquare>,
	public CComDlgControl<CCalcSquare>,
	public IDispatchImpl<ICalcSquare, &IID_ICalcSquare, &LIBID_DLGCTRLLib>,
	public IPersistStreamInitImpl<CCalcSquare>,
	public IOleControlImpl<CCalcSquare>,
	public IOleObjectImpl<CCalcSquare>,
	public IOleInPlaceActiveObjectImpl<CCalcSquare>,
	public IViewObjectExImpl<CCalcSquare>,
	public IOleInPlaceObjectWindowlessImpl<CCalcSquare>
{
public:
	CCalcSquare();

DECLARE_REGISTRY_RESOURCEID(IDR_CALCSQUARE)

    enum { IDD = IDD_CALCSQUARE };  // DONE

BEGIN_COM_MAP(CCalcSquare) 
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ICalcSquare)
	COM_INTERFACE_ENTRY_IMPL_IID(IID_IViewObject, IViewObjectEx)
	COM_INTERFACE_ENTRY_IMPL_IID(IID_IViewObject2, IViewObjectEx)
	COM_INTERFACE_ENTRY_IMPL(IViewObjectEx)
	COM_INTERFACE_ENTRY_IMPL_IID(IID_IOleWindow, IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY_IMPL_IID(IID_IOleInPlaceObject, IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY_IMPL(IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY_IMPL(IOleInPlaceActiveObject)
	COM_INTERFACE_ENTRY_IMPL(IOleControl)
	COM_INTERFACE_ENTRY_IMPL(IOleObject)
	COM_INTERFACE_ENTRY_IMPL(IPersistStreamInit)
END_COM_MAP()

BEGIN_PROPERTY_MAP(CCalcSquare)
	// Example entries
	// PROP_ENTRY("Property Description", dispid, clsid)
	// PROP_PAGE(CLSID_StockColorPage)
END_PROPERTY_MAP()


BEGIN_MSG_MAP(CCalcSquare)
    MESSAGE_HANDLER(WM_SETFOCUS, OnSetFocus)
    MESSAGE_HANDLER(WM_KILLFOCUS, OnKillFocus)
	MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)    // DONE
	COMMAND_HANDLER(IDC_ADD, BN_CLICKED, OnAdd)     // DONE
END_MSG_MAP()

    // IViewObjectEx
	STDMETHODIMP GetViewStatus(DWORD* pdwStatus);

    // IOleInPlaceActiveObject
    STDMETHODIMP CCalcSquare::TranslateAccelerator(MSG *pMsg);

    // DONE
    LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
    LRESULT OnAdd(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);

// ICalcSquare
public:
	STDMETHODIMP Add();
	STDMETHODIMP get_Sum(/*[out, retval]*/ long *pVal);
	STDMETHODIMP put_Sum(/*[in]*/ long newVal);
	STDMETHODIMP get_Op2(/*[out, retval]*/ long *pVal);
	STDMETHODIMP put_Op2(/*[in]*/ long newVal);
	STDMETHODIMP get_Op1(/*[out, retval]*/ long *pVal);
	STDMETHODIMP put_Op1(/*[in]*/ long newVal);

private:
    // DONE
    CWindow m_editOp1;
    CWindow m_editOp2;
    CWindow m_btnAdd;
    CWindow m_editSum;
};

#endif //__CALCSQUARE_H_
