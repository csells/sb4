using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace EventSinkAndMethodInvoke2
{
	public partial class Workflow2 : SequentialWorkflow
	{
		// DONE: bound to by the event sink
		Order _approvedOrder;
		string _approvalComment;

		private void code1_ExecuteCode(object sender, EventArgs e)
		{
			Console.WriteLine("Order: customer= {0}, description= {1}, approved w/ comment= {2}", _approvedOrder.Customer, _approvedOrder.Description, _approvalComment);
		}
	}
}
