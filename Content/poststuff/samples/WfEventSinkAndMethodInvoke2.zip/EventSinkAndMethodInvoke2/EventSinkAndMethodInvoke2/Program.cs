#region Using directives

using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Workflow.Runtime;
using System.Workflow.Runtime.Hosting;
using System.Workflow.Runtime.Messaging;
using System.Workflow.ComponentModel;

#endregion

namespace EventSinkAndMethodInvoke2
{
	class Program
	{
		static AutoResetEvent waitHandle = new AutoResetEvent(false);

		static void Main(string[] args)
		{
			WorkflowRuntime workflowRuntime = new WorkflowRuntime();

			// DONE: Add IOrderService implementation
			OrderServiceImpl orderService = new OrderServiceImpl();
			workflowRuntime.AddService(orderService);

			workflowRuntime.StartRuntime();
			workflowRuntime.WorkflowCompleted += delegate(object sender, WorkflowCompletedEventArgs e)
			{
				waitHandle.Set();
			};

			Type type = typeof(EventSinkAndMethodInvoke2.Workflow2);
			WorkflowInstance wf = workflowRuntime.StartWorkflow(type);

			// DONE: Simulate human decision time and approve the order
			System.Threading.Thread.Sleep(1000);
			orderService.ApproveOrder(wf, "this is a *fine* order!");

			// DONE: Handle termination
			workflowRuntime.WorkflowTerminated += delegate(object sender, WorkflowTerminatedEventArgs e)
			{
				Console.WriteLine("WorkflowTerminated: {0}", e.Reason);
				waitHandle.Set();
			};

			waitHandle.WaitOne();
			workflowRuntime.StopRuntime();
		}
	}

	// DONE: Args and everything the args send have to be serializable
	[Serializable]
	public class OrderEventArgs : WorkflowMessageEventArgs
	{
		Order _order;
		public Order Order
		{
			get { return _order; }
		}

		string _comment;
		public string Comment
		{
			get { return _comment; }
		}

		public OrderEventArgs(Guid workflowInstanceId, Order order, string comment)
			: base(workflowInstanceId)
		{
			_order = order;
			_comment = comment;
		}
	}

	[Serializable]
	public class Order
	{
		Guid _orderId = Guid.NewGuid();
		public Guid OrderId
		{
			get { return _orderId; }
		}

		private string _customer;

		public string Customer
		{
			get { return _customer; }
			set { _customer = value; }
		}

		private string _desc;

		public string Description
		{
			get { return _desc; }
			set { _desc = value; }
		}

		public Order(string customer, string desc)
		{
			_customer = customer;
			_desc = desc;
		}
	}

	[DataExchangeService]
	public interface IOrderService
	{
		void CreateOrder(string customer, string orderDescription);
		event EventHandler<OrderEventArgs> OrderApproved;
	}

	class OrderServiceImpl : IOrderService
	{
		#region IOrderService Members

		Dictionary<Guid, Order> _workflowOrderMap = new Dictionary<Guid, Order>();

		public void CreateOrder(string customer, string orderDescription)
		{
			_workflowOrderMap.Add(BatchEnvironment.CurrentInstanceId, new Order(customer, orderDescription));
		}

		public void ApproveOrder(WorkflowInstance wf, string comment)
		{
			if (OrderApproved != null)
			{
				Guid wfId = wf.InstanceId;
				OrderApproved(null, new OrderEventArgs(wfId, _workflowOrderMap[wfId], comment));
			}
		}

		public event EventHandler<OrderEventArgs> OrderApproved;

		#endregion
	}

}
