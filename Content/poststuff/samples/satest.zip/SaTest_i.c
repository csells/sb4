/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 3.01.75 */
/* at Wed Apr 29 13:05:39 1998
 */
/* Compiler settings for SaTest.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IArrayHolder = {0xCCE24679,0x0842,0x11D1,{0xA8,0x4F,0xC9,0xA7,0xC7,0xDE,0xD0,0x6D}};


const IID LIBID_SATESTLib = {0xCCE2466C,0x0842,0x11D1,{0xA8,0x4F,0xC9,0xA7,0xC7,0xDE,0xD0,0x6D}};


const CLSID CLSID_ArrayHolder = {0xCCE2467A,0x0842,0x11D1,{0xA8,0x4F,0xC9,0xA7,0xC7,0xDE,0xD0,0x6D}};


#ifdef __cplusplus
}
#endif

