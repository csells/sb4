// ArrayHolder.cpp : Implementation of CArrayHolder
#include "stdafx.h"
#include "SaTest.h"
#include "ArrayHolder.h"

/////////////////////////////////////////////////////////////////////////////
// CArrayHolder

CArrayHolder::CArrayHolder()
    :
    m_nLen(0),
    m_rgn(0)
{
}

CArrayHolder::~CArrayHolder()
{
    delete[] m_rgn;
}

STDMETHODIMP CArrayHolder::GetArray(SAFEARRAY** ppsa)
{
    // The client (VB) may or may not be passing in a pre-dimensioned array,
    // but it does require the SAFEARRAY to be [in, out] so we can make sure
    // we've got the number of dimensions right (the type is specified in the IDL).
    if( !ppsa ) return E_POINTER;
    if( *ppsa && SafeArrayGetDim(*ppsa) != 1 ) return E_UNEXPECTED;

    HRESULT hr;

    // If VB has built an array for us, reset the number of elements
    if( *ppsa )
    {
        SAFEARRAYBOUND  sab = { m_nLen, 0 };
        hr = SafeArrayRedim(*ppsa, &sab);
    }
    // If VB hasn't built an array for us, build one
    else
    {
        *ppsa = SafeArrayCreateVector(VT_I4, 0, m_nLen);
        if( !*ppsa ) hr = E_OUTOFMEMORY;
    }

    if( SUCCEEDED(hr) )
    {
        // Copy our C array into the VB-allocated SAFEARRAY
        long* rgn = 0;
        hr = SafeArrayAccessData(*ppsa, (void**)&rgn);
        if( SUCCEEDED(hr) )
        {
            memcpy(rgn, m_rgn, m_nLen * sizeof(long));
            SafeArrayUnaccessData(*ppsa);
        }
    }

    return hr;
}

STDMETHODIMP CArrayHolder::PutArray(SAFEARRAY** ppsa)
{
    if( !ppsa || !*ppsa ) return E_INVALIDARG;
    if( SafeArrayGetDim(*ppsa) != 1 ) return E_UNEXPECTED;

    HRESULT hr;
    long    nUBound;
    long    nLBound;
    long*   rgn = 0;
    long*   rgn2 = 0;

    // Copy the data from the SAFEARRAY into our C array
    if( SUCCEEDED(hr = SafeArrayGetUBound(*ppsa, 1, &nUBound)) &&
        SUCCEEDED(hr = SafeArrayGetLBound(*ppsa, 1, &nLBound)) &&
        SUCCEEDED(hr = SafeArrayAccessData(*ppsa, (void**)&rgn)) &&
        SUCCEEDED(hr = ((rgn2 = new long[nUBound - nLBound + 1]) ? S_OK : E_OUTOFMEMORY)) )
    {
        delete[] m_rgn;
        m_rgn = rgn2;
        m_nLen = nUBound - nLBound + 1;
        memcpy(m_rgn, rgn, m_nLen * sizeof(long));
    }

    if( rgn ) SafeArrayUnaccessData(*ppsa);
	return S_OK;
}

STDMETHODIMP CArrayHolder::get_ArrayAsVariant(VARIANT* pvar)
{
    pvar->vt = VT_ARRAY|VT_I4;
    return GetArray(&pvar->parray);
}

STDMETHODIMP CArrayHolder::put_ArrayAsVariant(VARIANT var)
{
    if( var.vt != (VT_ARRAY|VT_I4) ) return E_INVALIDARG;
    //return PutArray(&var.parray);
    return S_OK;
}

