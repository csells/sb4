/* this ALWAYS GENERATED file contains the proxy stub code */


/* File created by MIDL compiler version 3.01.75 */
/* at Wed Apr 29 13:05:39 1998
 */
/* Compiler settings for SaTest.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )

#define USE_STUBLESS_PROXY

#include "rpcproxy.h"
#include "SaTest.h"

#define TYPE_FORMAT_STRING_SIZE   1027                              
#define PROC_FORMAT_STRING_SIZE   97                                

typedef struct _MIDL_TYPE_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ TYPE_FORMAT_STRING_SIZE ];
    } MIDL_TYPE_FORMAT_STRING;

typedef struct _MIDL_PROC_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ PROC_FORMAT_STRING_SIZE ];
    } MIDL_PROC_FORMAT_STRING;


extern const MIDL_TYPE_FORMAT_STRING __MIDL_TypeFormatString;
extern const MIDL_PROC_FORMAT_STRING __MIDL_ProcFormatString;


/* Object interface: IUnknown, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}} */


/* Object interface: IDispatch, ver. 0.0,
   GUID={0x00020400,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}} */


/* Object interface: IArrayHolder, ver. 0.0,
   GUID={0xCCE24679,0x0842,0x11D1,{0xA8,0x4F,0xC9,0xA7,0xC7,0xDE,0xD0,0x6D}} */


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO IArrayHolder_ServerInfo;

#pragma code_seg(".orpc")
extern const USER_MARSHAL_ROUTINE_QUADRUPLE UserMarshalRoutines[2];

static const MIDL_STUB_DESC Object_StubDesc = 
    {
    0,
    NdrOleAllocate,
    NdrOleFree,
    0,
    0,
    0,
    0,
    0,
    __MIDL_TypeFormatString.Format,
    0, /* -error bounds_check flag */
    0x20000, /* Ndr library version */
    0,
    0x301004b, /* MIDL Version 3.1.75 */
    0,
    UserMarshalRoutines,
    0,  /* Reserved1 */
    0,  /* Reserved2 */
    0,  /* Reserved3 */
    0,  /* Reserved4 */
    0   /* Reserved5 */
    };

static const unsigned short IArrayHolder_FormatStringOffsetTable[] = 
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    0,
    24,
    48,
    72
    };

static const MIDL_SERVER_INFO IArrayHolder_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &IArrayHolder_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0
    };

static const MIDL_STUBLESS_PROXY_INFO IArrayHolder_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &IArrayHolder_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };

CINTERFACE_PROXY_VTABLE(11) _IArrayHolderProxyVtbl = 
{
    &IArrayHolder_ProxyInfo,
    &IID_IArrayHolder,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *)-1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *)-1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *)-1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *)-1 /* IArrayHolder::GetArray */ ,
    (void *)-1 /* IArrayHolder::PutArray */ ,
    (void *)-1 /* IArrayHolder::get_ArrayAsVariant */ ,
    (void *)-1 /* IArrayHolder::put_ArrayAsVariant */
};


static const PRPC_STUB_FUNCTION IArrayHolder_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _IArrayHolderStubVtbl =
{
    &IID_IArrayHolder,
    &IArrayHolder_ServerInfo,
    11,
    &IArrayHolder_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};

#pragma data_seg(".rdata")

static const USER_MARSHAL_ROUTINE_QUADRUPLE UserMarshalRoutines[2] = 
        {
            
            {
            LPSAFEARRAY_UserSize
            ,LPSAFEARRAY_UserMarshal
            ,LPSAFEARRAY_UserUnmarshal
            ,LPSAFEARRAY_UserFree
            },
            {
            VARIANT_UserSize
            ,VARIANT_UserMarshal
            ,VARIANT_UserUnmarshal
            ,VARIANT_UserFree
            }

        };


#if !defined(__RPC_WIN32__)
#error  Invalid build platform for this stub.
#endif

#if !(TARGET_IS_NT40_OR_LATER)
#error You need a Windows NT 4.0 or later to run this stub because it uses these features:
#error   -Oif or -Oicf, [wire_marshal] or [user_marshal] attribute.
#error However, your C/C++ compilation flags indicate you intend to run this app on earlier systems.
#error This app will die there with the RPC_X_WRONG_STUB_VERSION error.
#endif


static const MIDL_PROC_FORMAT_STRING __MIDL_ProcFormatString =
    {
        0,
        {

	/* Procedure GetArray */

			0x33,		/* FC_AUTO_HANDLE */
			0x64,		/* 100 */
/*  2 */	NdrFcShort( 0x7 ),	/* 7 */
#ifndef _ALPHA_
/*  4 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/*  6 */	NdrFcShort( 0x0 ),	/* 0 */
/*  8 */	NdrFcShort( 0x8 ),	/* 8 */
/* 10 */	0x7,		/* 7 */
			0x2,		/* 2 */

	/* Parameter ppsa */

/* 12 */	NdrFcShort( 0x11b ),	/* 283 */
#ifndef _ALPHA_
/* 14 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 16 */	NdrFcShort( 0xffffffff ),	/* Type Offset=-1 */

	/* Return value */

/* 18 */	NdrFcShort( 0x70 ),	/* 112 */
#ifndef _ALPHA_
/* 20 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 22 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure PutArray */

/* 24 */	0x33,		/* FC_AUTO_HANDLE */
			0x64,		/* 100 */
/* 26 */	NdrFcShort( 0x8 ),	/* 8 */
#ifndef _ALPHA_
/* 28 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 30 */	NdrFcShort( 0x0 ),	/* 0 */
/* 32 */	NdrFcShort( 0x8 ),	/* 8 */
/* 34 */	0x6,		/* 6 */
			0x2,		/* 2 */

	/* Parameter ppsa */

/* 36 */	NdrFcShort( 0x10b ),	/* 267 */
#ifndef _ALPHA_
/* 38 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 40 */	NdrFcShort( 0xffffffff ),	/* Type Offset=-1 */

	/* Return value */

/* 42 */	NdrFcShort( 0x70 ),	/* 112 */
#ifndef _ALPHA_
/* 44 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 46 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_ArrayAsVariant */

/* 48 */	0x33,		/* FC_AUTO_HANDLE */
			0x64,		/* 100 */
/* 50 */	NdrFcShort( 0x9 ),	/* 9 */
#ifndef _ALPHA_
/* 52 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 54 */	NdrFcShort( 0x0 ),	/* 0 */
/* 56 */	NdrFcShort( 0x8 ),	/* 8 */
/* 58 */	0x5,		/* 5 */
			0x2,		/* 2 */

	/* Parameter pvar */

/* 60 */	NdrFcShort( 0x4113 ),	/* 16659 */
#ifndef _ALPHA_
/* 62 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 64 */	NdrFcShort( 0x3ea ),	/* Type Offset=1002 */

	/* Return value */

/* 66 */	NdrFcShort( 0x70 ),	/* 112 */
#ifndef _ALPHA_
/* 68 */	NdrFcShort( 0x8 ),	/* x86, MIPS, PPC Stack size/offset = 8 */
#else
			NdrFcShort( 0x10 ),	/* Alpha Stack size/offset = 16 */
#endif
/* 70 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_ArrayAsVariant */

/* 72 */	0x33,		/* FC_AUTO_HANDLE */
			0x64,		/* 100 */
/* 74 */	NdrFcShort( 0xa ),	/* 10 */
#ifndef _ALPHA_
#if !defined(_MIPS_) && !defined(_PPC_)
/* 76 */	NdrFcShort( 0x18 ),	/* x86 Stack size/offset = 24 */
#else
			NdrFcShort( 0x1c ),	/* MIPS & PPC Stack size/offset = 28 */
#endif
#else
			NdrFcShort( 0x20 ),	/* Alpha Stack size/offset = 32 */
#endif
/* 78 */	NdrFcShort( 0x0 ),	/* 0 */
/* 80 */	NdrFcShort( 0x8 ),	/* 8 */
/* 82 */	0x6,		/* 6 */
			0x2,		/* 2 */

	/* Parameter var */

/* 84 */	NdrFcShort( 0x8b ),	/* 139 */
#ifndef _ALPHA_
#if !defined(_MIPS_) && !defined(_PPC_)
/* 86 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* MIPS & PPC Stack size/offset = 8 */
#endif
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 88 */	NdrFcShort( 0x3f8 ),	/* Type Offset=1016 */

	/* Return value */

/* 90 */	NdrFcShort( 0x70 ),	/* 112 */
#ifndef _ALPHA_
#if !defined(_MIPS_) && !defined(_PPC_)
/* 92 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
#else
			NdrFcShort( 0x18 ),	/* MIPS & PPC Stack size/offset = 24 */
#endif
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 94 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

			0x0
        }
    };

static const MIDL_TYPE_FORMAT_STRING __MIDL_TypeFormatString =
    {
        0,
        {
			0x11, 0x0,	/* FC_RP */
/*  2 */	NdrFcShort( 0xfffffffd ),	/* Offset= -3 (-1) */
/*  4 */	
			0x13, 0x10,	/* FC_OP */
/*  6 */	NdrFcShort( 0x2 ),	/* Offset= 2 (8) */
/*  8 */	
			0x13, 0x0,	/* FC_OP */
/* 10 */	NdrFcShort( 0x3a6 ),	/* Offset= 934 (944) */
/* 12 */	
			0x2a,		/* FC_ENCAPSULATED_UNION */
			0x48,		/* 72 */
/* 14 */	NdrFcShort( 0x18 ),	/* 24 */
/* 16 */	NdrFcShort( 0xa ),	/* 10 */
/* 18 */	NdrFcLong( 0x8 ),	/* 8 */
/* 22 */	NdrFcShort( 0x6c ),	/* Offset= 108 (130) */
/* 24 */	NdrFcLong( 0xd ),	/* 13 */
/* 28 */	NdrFcShort( 0x9e ),	/* Offset= 158 (186) */
/* 30 */	NdrFcLong( 0x9 ),	/* 9 */
/* 34 */	NdrFcShort( 0xcc ),	/* Offset= 204 (238) */
/* 36 */	NdrFcLong( 0xc ),	/* 12 */
/* 40 */	NdrFcShort( 0x292 ),	/* Offset= 658 (698) */
/* 42 */	NdrFcLong( 0x24 ),	/* 36 */
/* 46 */	NdrFcShort( 0x2be ),	/* Offset= 702 (748) */
/* 48 */	NdrFcLong( 0x800d ),	/* 32781 */
/* 52 */	NdrFcShort( 0x2da ),	/* Offset= 730 (782) */
/* 54 */	NdrFcLong( 0x10 ),	/* 16 */
/* 58 */	NdrFcShort( 0x2f2 ),	/* Offset= 754 (812) */
/* 60 */	NdrFcLong( 0x2 ),	/* 2 */
/* 64 */	NdrFcShort( 0x30a ),	/* Offset= 778 (842) */
/* 66 */	NdrFcLong( 0x3 ),	/* 3 */
/* 70 */	NdrFcShort( 0x322 ),	/* Offset= 802 (872) */
/* 72 */	NdrFcLong( 0x14 ),	/* 20 */
/* 76 */	NdrFcShort( 0x33a ),	/* Offset= 826 (902) */
/* 78 */	NdrFcShort( 0xffffffff ),	/* Offset= -1 (77) */
/* 80 */	
			0x1b,		/* FC_CARRAY */
			0x1,		/* 1 */
/* 82 */	NdrFcShort( 0x2 ),	/* 2 */
/* 84 */	0x9,		/* 9 */
			0x0,		/*  */
/* 86 */	NdrFcShort( 0xfffffffc ),	/* -4 */
/* 88 */	0x6,		/* FC_SHORT */
			0x5b,		/* FC_END */
/* 90 */	
			0x17,		/* FC_CSTRUCT */
			0x3,		/* 3 */
/* 92 */	NdrFcShort( 0x8 ),	/* 8 */
/* 94 */	NdrFcShort( 0xfffffff2 ),	/* Offset= -14 (80) */
/* 96 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 98 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 100 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 102 */	NdrFcShort( 0x4 ),	/* 4 */
/* 104 */	0x18,		/* 24 */
			0x0,		/*  */
/* 106 */	NdrFcShort( 0x0 ),	/* 0 */
/* 108 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 110 */	
			0x48,		/* FC_VARIABLE_REPEAT */
			0x49,		/* FC_FIXED_OFFSET */
/* 112 */	NdrFcShort( 0x4 ),	/* 4 */
/* 114 */	NdrFcShort( 0x0 ),	/* 0 */
/* 116 */	NdrFcShort( 0x1 ),	/* 1 */
/* 118 */	NdrFcShort( 0x0 ),	/* 0 */
/* 120 */	NdrFcShort( 0x0 ),	/* 0 */
/* 122 */	0x13, 0x0,	/* FC_OP */
/* 124 */	NdrFcShort( 0xffffffde ),	/* Offset= -34 (90) */
/* 126 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 128 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 130 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 132 */	NdrFcShort( 0x8 ),	/* 8 */
/* 134 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 136 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 138 */	NdrFcShort( 0x4 ),	/* 4 */
/* 140 */	NdrFcShort( 0x4 ),	/* 4 */
/* 142 */	0x11, 0x0,	/* FC_RP */
/* 144 */	NdrFcShort( 0xffffffd4 ),	/* Offset= -44 (100) */
/* 146 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 148 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 150 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 152 */	NdrFcLong( 0x0 ),	/* 0 */
/* 156 */	NdrFcShort( 0x0 ),	/* 0 */
/* 158 */	NdrFcShort( 0x0 ),	/* 0 */
/* 160 */	0xc0,		/* 192 */
			0x0,		/* 0 */
/* 162 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 164 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 166 */	0x0,		/* 0 */
			0x46,		/* 70 */
/* 168 */	
			0x21,		/* FC_BOGUS_ARRAY */
			0x3,		/* 3 */
/* 170 */	NdrFcShort( 0x0 ),	/* 0 */
/* 172 */	0x18,		/* 24 */
			0x0,		/*  */
/* 174 */	NdrFcShort( 0x0 ),	/* 0 */
/* 176 */	NdrFcLong( 0xffffffff ),	/* -1 */
/* 180 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 182 */	NdrFcShort( 0xffffffe0 ),	/* Offset= -32 (150) */
/* 184 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 186 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 188 */	NdrFcShort( 0x8 ),	/* 8 */
/* 190 */	NdrFcShort( 0x0 ),	/* 0 */
/* 192 */	NdrFcShort( 0x6 ),	/* Offset= 6 (198) */
/* 194 */	0x8,		/* FC_LONG */
			0x36,		/* FC_POINTER */
/* 196 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 198 */	
			0x11, 0x0,	/* FC_RP */
/* 200 */	NdrFcShort( 0xffffffe0 ),	/* Offset= -32 (168) */
/* 202 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 204 */	NdrFcLong( 0x20400 ),	/* 132096 */
/* 208 */	NdrFcShort( 0x0 ),	/* 0 */
/* 210 */	NdrFcShort( 0x0 ),	/* 0 */
/* 212 */	0xc0,		/* 192 */
			0x0,		/* 0 */
/* 214 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 216 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 218 */	0x0,		/* 0 */
			0x46,		/* 70 */
/* 220 */	
			0x21,		/* FC_BOGUS_ARRAY */
			0x3,		/* 3 */
/* 222 */	NdrFcShort( 0x0 ),	/* 0 */
/* 224 */	0x18,		/* 24 */
			0x0,		/*  */
/* 226 */	NdrFcShort( 0x0 ),	/* 0 */
/* 228 */	NdrFcLong( 0xffffffff ),	/* -1 */
/* 232 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 234 */	NdrFcShort( 0xffffffe0 ),	/* Offset= -32 (202) */
/* 236 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 238 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 240 */	NdrFcShort( 0x8 ),	/* 8 */
/* 242 */	NdrFcShort( 0x0 ),	/* 0 */
/* 244 */	NdrFcShort( 0x6 ),	/* Offset= 6 (250) */
/* 246 */	0x8,		/* FC_LONG */
			0x36,		/* FC_POINTER */
/* 248 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 250 */	
			0x11, 0x0,	/* FC_RP */
/* 252 */	NdrFcShort( 0xffffffe0 ),	/* Offset= -32 (220) */
/* 254 */	
			0x2b,		/* FC_NON_ENCAPSULATED_UNION */
			0x8,		/* FC_LONG */
/* 256 */	0x6,		/* 6 */
			0x0,		/*  */
/* 258 */	NdrFcShort( 0xfffffff8 ),	/* -8 */
/* 260 */	NdrFcShort( 0x2 ),	/* Offset= 2 (262) */
/* 262 */	NdrFcShort( 0x10 ),	/* 16 */
/* 264 */	NdrFcShort( 0x2b ),	/* 43 */
/* 266 */	NdrFcLong( 0x3 ),	/* 3 */
/* 270 */	NdrFcShort( 0xffff8008 ),	/* Offset= -32760 (-32490) */
/* 272 */	NdrFcLong( 0x11 ),	/* 17 */
/* 276 */	NdrFcShort( 0xffff8002 ),	/* Offset= -32766 (-32490) */
/* 278 */	NdrFcLong( 0x2 ),	/* 2 */
/* 282 */	NdrFcShort( 0xffff8006 ),	/* Offset= -32762 (-32480) */
/* 284 */	NdrFcLong( 0x4 ),	/* 4 */
/* 288 */	NdrFcShort( 0xffff800a ),	/* Offset= -32758 (-32470) */
/* 290 */	NdrFcLong( 0x5 ),	/* 5 */
/* 294 */	NdrFcShort( 0xffff800c ),	/* Offset= -32756 (-32462) */
/* 296 */	NdrFcLong( 0xb ),	/* 11 */
/* 300 */	NdrFcShort( 0xffff8006 ),	/* Offset= -32762 (-32462) */
/* 302 */	NdrFcLong( 0xa ),	/* 10 */
/* 306 */	NdrFcShort( 0xffff8008 ),	/* Offset= -32760 (-32454) */
/* 308 */	NdrFcLong( 0x6 ),	/* 6 */
/* 312 */	NdrFcShort( 0xd6 ),	/* Offset= 214 (526) */
/* 314 */	NdrFcLong( 0x7 ),	/* 7 */
/* 318 */	NdrFcShort( 0xffff800c ),	/* Offset= -32756 (-32438) */
/* 320 */	NdrFcLong( 0x8 ),	/* 8 */
/* 324 */	NdrFcShort( 0xd0 ),	/* Offset= 208 (532) */
/* 326 */	NdrFcLong( 0xd ),	/* 13 */
/* 330 */	NdrFcShort( 0xffffff4c ),	/* Offset= -180 (150) */
/* 332 */	NdrFcLong( 0x9 ),	/* 9 */
/* 336 */	NdrFcShort( 0xffffff7a ),	/* Offset= -134 (202) */
/* 338 */	NdrFcLong( 0x2000 ),	/* 8192 */
/* 342 */	NdrFcShort( 0xc2 ),	/* Offset= 194 (536) */
/* 344 */	NdrFcLong( 0x24 ),	/* 36 */
/* 348 */	NdrFcShort( 0xc0 ),	/* Offset= 192 (540) */
/* 350 */	NdrFcLong( 0x4024 ),	/* 16420 */
/* 354 */	NdrFcShort( 0xba ),	/* Offset= 186 (540) */
/* 356 */	NdrFcLong( 0x4011 ),	/* 16401 */
/* 360 */	NdrFcShort( 0xe8 ),	/* Offset= 232 (592) */
/* 362 */	NdrFcLong( 0x4002 ),	/* 16386 */
/* 366 */	NdrFcShort( 0xe6 ),	/* Offset= 230 (596) */
/* 368 */	NdrFcLong( 0x4003 ),	/* 16387 */
/* 372 */	NdrFcShort( 0xe4 ),	/* Offset= 228 (600) */
/* 374 */	NdrFcLong( 0x4004 ),	/* 16388 */
/* 378 */	NdrFcShort( 0xe2 ),	/* Offset= 226 (604) */
/* 380 */	NdrFcLong( 0x4005 ),	/* 16389 */
/* 384 */	NdrFcShort( 0xe0 ),	/* Offset= 224 (608) */
/* 386 */	NdrFcLong( 0x400b ),	/* 16395 */
/* 390 */	NdrFcShort( 0xce ),	/* Offset= 206 (596) */
/* 392 */	NdrFcLong( 0x400a ),	/* 16394 */
/* 396 */	NdrFcShort( 0xcc ),	/* Offset= 204 (600) */
/* 398 */	NdrFcLong( 0x4006 ),	/* 16390 */
/* 402 */	NdrFcShort( 0xd2 ),	/* Offset= 210 (612) */
/* 404 */	NdrFcLong( 0x4007 ),	/* 16391 */
/* 408 */	NdrFcShort( 0xc8 ),	/* Offset= 200 (608) */
/* 410 */	NdrFcLong( 0x4008 ),	/* 16392 */
/* 414 */	NdrFcShort( 0xca ),	/* Offset= 202 (616) */
/* 416 */	NdrFcLong( 0x400d ),	/* 16397 */
/* 420 */	NdrFcShort( 0xc8 ),	/* Offset= 200 (620) */
/* 422 */	NdrFcLong( 0x4009 ),	/* 16393 */
/* 426 */	NdrFcShort( 0xc6 ),	/* Offset= 198 (624) */
/* 428 */	NdrFcLong( 0x6000 ),	/* 24576 */
/* 432 */	NdrFcShort( 0xc4 ),	/* Offset= 196 (628) */
/* 434 */	NdrFcLong( 0x400c ),	/* 16396 */
/* 438 */	NdrFcShort( 0xbe ),	/* Offset= 190 (628) */
/* 440 */	NdrFcLong( 0x10 ),	/* 16 */
/* 444 */	NdrFcShort( 0xffff8002 ),	/* Offset= -32766 (-32322) */
/* 446 */	NdrFcLong( 0x12 ),	/* 18 */
/* 450 */	NdrFcShort( 0xffff8006 ),	/* Offset= -32762 (-32312) */
/* 452 */	NdrFcLong( 0x13 ),	/* 19 */
/* 456 */	NdrFcShort( 0xffff8008 ),	/* Offset= -32760 (-32304) */
/* 458 */	NdrFcLong( 0x16 ),	/* 22 */
/* 462 */	NdrFcShort( 0xffff8008 ),	/* Offset= -32760 (-32298) */
/* 464 */	NdrFcLong( 0x17 ),	/* 23 */
/* 468 */	NdrFcShort( 0xffff8008 ),	/* Offset= -32760 (-32292) */
/* 470 */	NdrFcLong( 0xe ),	/* 14 */
/* 474 */	NdrFcShort( 0x9e ),	/* Offset= 158 (632) */
/* 476 */	NdrFcLong( 0x400e ),	/* 16398 */
/* 480 */	NdrFcShort( 0xa4 ),	/* Offset= 164 (644) */
/* 482 */	NdrFcLong( 0x4010 ),	/* 16400 */
/* 486 */	NdrFcShort( 0x6a ),	/* Offset= 106 (592) */
/* 488 */	NdrFcLong( 0x4012 ),	/* 16402 */
/* 492 */	NdrFcShort( 0x68 ),	/* Offset= 104 (596) */
/* 494 */	NdrFcLong( 0x4013 ),	/* 16403 */
/* 498 */	NdrFcShort( 0x66 ),	/* Offset= 102 (600) */
/* 500 */	NdrFcLong( 0x4016 ),	/* 16406 */
/* 504 */	NdrFcShort( 0x60 ),	/* Offset= 96 (600) */
/* 506 */	NdrFcLong( 0x4017 ),	/* 16407 */
/* 510 */	NdrFcShort( 0x5a ),	/* Offset= 90 (600) */
/* 512 */	NdrFcLong( 0x0 ),	/* 0 */
/* 516 */	NdrFcShort( 0x0 ),	/* Offset= 0 (516) */
/* 518 */	NdrFcLong( 0x1 ),	/* 1 */
/* 522 */	NdrFcShort( 0x0 ),	/* Offset= 0 (522) */
/* 524 */	NdrFcShort( 0xffffffff ),	/* Offset= -1 (523) */
/* 526 */	
			0x15,		/* FC_STRUCT */
			0x7,		/* 7 */
/* 528 */	NdrFcShort( 0x8 ),	/* 8 */
/* 530 */	0xb,		/* FC_HYPER */
			0x5b,		/* FC_END */
/* 532 */	
			0x13, 0x0,	/* FC_OP */
/* 534 */	NdrFcShort( 0xfffffe44 ),	/* Offset= -444 (90) */
/* 536 */	
			0x13, 0x0,	/* FC_OP */
/* 538 */	NdrFcShort( 0x196 ),	/* Offset= 406 (944) */
/* 540 */	
			0x13, 0x0,	/* FC_OP */
/* 542 */	NdrFcShort( 0x1e ),	/* Offset= 30 (572) */
/* 544 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 546 */	NdrFcLong( 0x2f ),	/* 47 */
/* 550 */	NdrFcShort( 0x0 ),	/* 0 */
/* 552 */	NdrFcShort( 0x0 ),	/* 0 */
/* 554 */	0xc0,		/* 192 */
			0x0,		/* 0 */
/* 556 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 558 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 560 */	0x0,		/* 0 */
			0x46,		/* 70 */
/* 562 */	
			0x1b,		/* FC_CARRAY */
			0x0,		/* 0 */
/* 564 */	NdrFcShort( 0x1 ),	/* 1 */
/* 566 */	0x18,		/* 24 */
			0x0,		/*  */
/* 568 */	NdrFcShort( 0x4 ),	/* 4 */
/* 570 */	0x1,		/* FC_BYTE */
			0x5b,		/* FC_END */
/* 572 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 574 */	NdrFcShort( 0x10 ),	/* 16 */
/* 576 */	NdrFcShort( 0x0 ),	/* 0 */
/* 578 */	NdrFcShort( 0xa ),	/* Offset= 10 (588) */
/* 580 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 582 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 584 */	NdrFcShort( 0xffffffd8 ),	/* Offset= -40 (544) */
/* 586 */	0x36,		/* FC_POINTER */
			0x5b,		/* FC_END */
/* 588 */	
			0x13, 0x0,	/* FC_OP */
/* 590 */	NdrFcShort( 0xffffffe4 ),	/* Offset= -28 (562) */
/* 592 */	
			0x13, 0x8,	/* FC_OP [simple_pointer] */
/* 594 */	0x2,		/* FC_CHAR */
			0x5c,		/* FC_PAD */
/* 596 */	
			0x13, 0x8,	/* FC_OP [simple_pointer] */
/* 598 */	0x6,		/* FC_SHORT */
			0x5c,		/* FC_PAD */
/* 600 */	
			0x13, 0x8,	/* FC_OP [simple_pointer] */
/* 602 */	0x8,		/* FC_LONG */
			0x5c,		/* FC_PAD */
/* 604 */	
			0x13, 0x8,	/* FC_OP [simple_pointer] */
/* 606 */	0xa,		/* FC_FLOAT */
			0x5c,		/* FC_PAD */
/* 608 */	
			0x13, 0x8,	/* FC_OP [simple_pointer] */
/* 610 */	0xc,		/* FC_DOUBLE */
			0x5c,		/* FC_PAD */
/* 612 */	
			0x13, 0x0,	/* FC_OP */
/* 614 */	NdrFcShort( 0xffffffa8 ),	/* Offset= -88 (526) */
/* 616 */	
			0x13, 0x10,	/* FC_OP */
/* 618 */	NdrFcShort( 0xffffffaa ),	/* Offset= -86 (532) */
/* 620 */	
			0x13, 0x10,	/* FC_OP */
/* 622 */	NdrFcShort( 0xfffffe28 ),	/* Offset= -472 (150) */
/* 624 */	
			0x13, 0x10,	/* FC_OP */
/* 626 */	NdrFcShort( 0xfffffe58 ),	/* Offset= -424 (202) */
/* 628 */	
			0x13, 0x10,	/* FC_OP */
/* 630 */	NdrFcShort( 0xffffffa2 ),	/* Offset= -94 (536) */
/* 632 */	
			0x15,		/* FC_STRUCT */
			0x7,		/* 7 */
/* 634 */	NdrFcShort( 0x10 ),	/* 16 */
/* 636 */	0x6,		/* FC_SHORT */
			0x2,		/* FC_CHAR */
/* 638 */	0x2,		/* FC_CHAR */
			0x38,		/* FC_ALIGNM4 */
/* 640 */	0x8,		/* FC_LONG */
			0x39,		/* FC_ALIGNM8 */
/* 642 */	0xb,		/* FC_HYPER */
			0x5b,		/* FC_END */
/* 644 */	
			0x13, 0x0,	/* FC_OP */
/* 646 */	NdrFcShort( 0xfffffff2 ),	/* Offset= -14 (632) */
/* 648 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x7,		/* 7 */
/* 650 */	NdrFcShort( 0x20 ),	/* 32 */
/* 652 */	NdrFcShort( 0x0 ),	/* 0 */
/* 654 */	NdrFcShort( 0x0 ),	/* Offset= 0 (654) */
/* 656 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 658 */	0x6,		/* FC_SHORT */
			0x6,		/* FC_SHORT */
/* 660 */	0x6,		/* FC_SHORT */
			0x6,		/* FC_SHORT */
/* 662 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 664 */	NdrFcShort( 0xfffffe66 ),	/* Offset= -410 (254) */
/* 666 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 668 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 670 */	NdrFcShort( 0x4 ),	/* 4 */
/* 672 */	0x18,		/* 24 */
			0x0,		/*  */
/* 674 */	NdrFcShort( 0x0 ),	/* 0 */
/* 676 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 678 */	
			0x48,		/* FC_VARIABLE_REPEAT */
			0x49,		/* FC_FIXED_OFFSET */
/* 680 */	NdrFcShort( 0x4 ),	/* 4 */
/* 682 */	NdrFcShort( 0x0 ),	/* 0 */
/* 684 */	NdrFcShort( 0x1 ),	/* 1 */
/* 686 */	NdrFcShort( 0x0 ),	/* 0 */
/* 688 */	NdrFcShort( 0x0 ),	/* 0 */
/* 690 */	0x13, 0x0,	/* FC_OP */
/* 692 */	NdrFcShort( 0xffffffd4 ),	/* Offset= -44 (648) */
/* 694 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 696 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 698 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 700 */	NdrFcShort( 0x8 ),	/* 8 */
/* 702 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 704 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 706 */	NdrFcShort( 0x4 ),	/* 4 */
/* 708 */	NdrFcShort( 0x4 ),	/* 4 */
/* 710 */	0x11, 0x0,	/* FC_RP */
/* 712 */	NdrFcShort( 0xffffffd4 ),	/* Offset= -44 (668) */
/* 714 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 716 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 718 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 720 */	NdrFcShort( 0x4 ),	/* 4 */
/* 722 */	0x18,		/* 24 */
			0x0,		/*  */
/* 724 */	NdrFcShort( 0x0 ),	/* 0 */
/* 726 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 728 */	
			0x48,		/* FC_VARIABLE_REPEAT */
			0x49,		/* FC_FIXED_OFFSET */
/* 730 */	NdrFcShort( 0x4 ),	/* 4 */
/* 732 */	NdrFcShort( 0x0 ),	/* 0 */
/* 734 */	NdrFcShort( 0x1 ),	/* 1 */
/* 736 */	NdrFcShort( 0x0 ),	/* 0 */
/* 738 */	NdrFcShort( 0x0 ),	/* 0 */
/* 740 */	0x13, 0x0,	/* FC_OP */
/* 742 */	NdrFcShort( 0xffffff56 ),	/* Offset= -170 (572) */
/* 744 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 746 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 748 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 750 */	NdrFcShort( 0x8 ),	/* 8 */
/* 752 */	NdrFcShort( 0x0 ),	/* 0 */
/* 754 */	NdrFcShort( 0x6 ),	/* Offset= 6 (760) */
/* 756 */	0x8,		/* FC_LONG */
			0x36,		/* FC_POINTER */
/* 758 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 760 */	
			0x11, 0x0,	/* FC_RP */
/* 762 */	NdrFcShort( 0xffffffd4 ),	/* Offset= -44 (718) */
/* 764 */	
			0x1d,		/* FC_SMFARRAY */
			0x0,		/* 0 */
/* 766 */	NdrFcShort( 0x8 ),	/* 8 */
/* 768 */	0x2,		/* FC_CHAR */
			0x5b,		/* FC_END */
/* 770 */	
			0x15,		/* FC_STRUCT */
			0x3,		/* 3 */
/* 772 */	NdrFcShort( 0x10 ),	/* 16 */
/* 774 */	0x8,		/* FC_LONG */
			0x6,		/* FC_SHORT */
/* 776 */	0x6,		/* FC_SHORT */
			0x4c,		/* FC_EMBEDDED_COMPLEX */
/* 778 */	0x0,		/* 0 */
			NdrFcShort( 0xfffffff1 ),	/* Offset= -15 (764) */
			0x5b,		/* FC_END */
/* 782 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 784 */	NdrFcShort( 0x18 ),	/* 24 */
/* 786 */	NdrFcShort( 0x0 ),	/* 0 */
/* 788 */	NdrFcShort( 0xa ),	/* Offset= 10 (798) */
/* 790 */	0x8,		/* FC_LONG */
			0x36,		/* FC_POINTER */
/* 792 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 794 */	NdrFcShort( 0xffffffe8 ),	/* Offset= -24 (770) */
/* 796 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 798 */	
			0x11, 0x0,	/* FC_RP */
/* 800 */	NdrFcShort( 0xfffffd88 ),	/* Offset= -632 (168) */
/* 802 */	
			0x1b,		/* FC_CARRAY */
			0x0,		/* 0 */
/* 804 */	NdrFcShort( 0x1 ),	/* 1 */
/* 806 */	0x19,		/* 25 */
			0x0,		/*  */
/* 808 */	NdrFcShort( 0x0 ),	/* 0 */
/* 810 */	0x1,		/* FC_BYTE */
			0x5b,		/* FC_END */
/* 812 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 814 */	NdrFcShort( 0x8 ),	/* 8 */
/* 816 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 818 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 820 */	NdrFcShort( 0x4 ),	/* 4 */
/* 822 */	NdrFcShort( 0x4 ),	/* 4 */
/* 824 */	0x13, 0x0,	/* FC_OP */
/* 826 */	NdrFcShort( 0xffffffe8 ),	/* Offset= -24 (802) */
/* 828 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 830 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 832 */	
			0x1b,		/* FC_CARRAY */
			0x1,		/* 1 */
/* 834 */	NdrFcShort( 0x2 ),	/* 2 */
/* 836 */	0x19,		/* 25 */
			0x0,		/*  */
/* 838 */	NdrFcShort( 0x0 ),	/* 0 */
/* 840 */	0x6,		/* FC_SHORT */
			0x5b,		/* FC_END */
/* 842 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 844 */	NdrFcShort( 0x8 ),	/* 8 */
/* 846 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 848 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 850 */	NdrFcShort( 0x4 ),	/* 4 */
/* 852 */	NdrFcShort( 0x4 ),	/* 4 */
/* 854 */	0x13, 0x0,	/* FC_OP */
/* 856 */	NdrFcShort( 0xffffffe8 ),	/* Offset= -24 (832) */
/* 858 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 860 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 862 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 864 */	NdrFcShort( 0x4 ),	/* 4 */
/* 866 */	0x19,		/* 25 */
			0x0,		/*  */
/* 868 */	NdrFcShort( 0x0 ),	/* 0 */
/* 870 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 872 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 874 */	NdrFcShort( 0x8 ),	/* 8 */
/* 876 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 878 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 880 */	NdrFcShort( 0x4 ),	/* 4 */
/* 882 */	NdrFcShort( 0x4 ),	/* 4 */
/* 884 */	0x13, 0x0,	/* FC_OP */
/* 886 */	NdrFcShort( 0xffffffe8 ),	/* Offset= -24 (862) */
/* 888 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 890 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 892 */	
			0x1b,		/* FC_CARRAY */
			0x7,		/* 7 */
/* 894 */	NdrFcShort( 0x8 ),	/* 8 */
/* 896 */	0x19,		/* 25 */
			0x0,		/*  */
/* 898 */	NdrFcShort( 0x0 ),	/* 0 */
/* 900 */	0xb,		/* FC_HYPER */
			0x5b,		/* FC_END */
/* 902 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 904 */	NdrFcShort( 0x8 ),	/* 8 */
/* 906 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 908 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 910 */	NdrFcShort( 0x4 ),	/* 4 */
/* 912 */	NdrFcShort( 0x4 ),	/* 4 */
/* 914 */	0x13, 0x0,	/* FC_OP */
/* 916 */	NdrFcShort( 0xffffffe8 ),	/* Offset= -24 (892) */
/* 918 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 920 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 922 */	
			0x15,		/* FC_STRUCT */
			0x3,		/* 3 */
/* 924 */	NdrFcShort( 0x8 ),	/* 8 */
/* 926 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 928 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 930 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 932 */	NdrFcShort( 0x8 ),	/* 8 */
/* 934 */	0x6,		/* 6 */
			0x0,		/*  */
/* 936 */	NdrFcShort( 0xffffffd8 ),	/* -40 */
/* 938 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 940 */	NdrFcShort( 0xffffffee ),	/* Offset= -18 (922) */
/* 942 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 944 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 946 */	NdrFcShort( 0x28 ),	/* 40 */
/* 948 */	NdrFcShort( 0xffffffee ),	/* Offset= -18 (930) */
/* 950 */	NdrFcShort( 0x0 ),	/* Offset= 0 (950) */
/* 952 */	0x6,		/* FC_SHORT */
			0x6,		/* FC_SHORT */
/* 954 */	0x38,		/* FC_ALIGNM4 */
			0x8,		/* FC_LONG */
/* 956 */	0x8,		/* FC_LONG */
			0x4c,		/* FC_EMBEDDED_COMPLEX */
/* 958 */	0x0,		/* 0 */
			NdrFcShort( 0xfffffc4d ),	/* Offset= -947 (12) */
			0x5b,		/* FC_END */
/* 962 */	0xb4,		/* FC_USER_MARSHAL */
			0x83,		/* 131 */
/* 964 */	NdrFcShort( 0x0 ),	/* 0 */
/* 966 */	NdrFcShort( 0x4 ),	/* 4 */
/* 968 */	NdrFcShort( 0x0 ),	/* 0 */
/* 970 */	NdrFcShort( 0xfffffc3a ),	/* Offset= -966 (4) */
/* 972 */	
			0x11, 0x0,	/* FC_RP */
/* 974 */	NdrFcShort( 0xfffffc31 ),	/* Offset= -975 (-1) */
/* 976 */	
			0x12, 0x10,	/* FC_UP */
/* 978 */	NdrFcShort( 0x2 ),	/* Offset= 2 (980) */
/* 980 */	
			0x12, 0x0,	/* FC_UP */
/* 982 */	NdrFcShort( 0xffffffda ),	/* Offset= -38 (944) */
/* 984 */	0xb4,		/* FC_USER_MARSHAL */
			0x83,		/* 131 */
/* 986 */	NdrFcShort( 0x0 ),	/* 0 */
/* 988 */	NdrFcShort( 0x4 ),	/* 4 */
/* 990 */	NdrFcShort( 0x0 ),	/* 0 */
/* 992 */	NdrFcShort( 0xfffffff0 ),	/* Offset= -16 (976) */
/* 994 */	
			0x11, 0x4,	/* FC_RP [alloced_on_stack] */
/* 996 */	NdrFcShort( 0x6 ),	/* Offset= 6 (1002) */
/* 998 */	
			0x13, 0x0,	/* FC_OP */
/* 1000 */	NdrFcShort( 0xfffffea0 ),	/* Offset= -352 (648) */
/* 1002 */	0xb4,		/* FC_USER_MARSHAL */
			0x83,		/* 131 */
/* 1004 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1006 */	NdrFcShort( 0x10 ),	/* 16 */
/* 1008 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1010 */	NdrFcShort( 0xfffffff4 ),	/* Offset= -12 (998) */
/* 1012 */	
			0x12, 0x0,	/* FC_UP */
/* 1014 */	NdrFcShort( 0xfffffe92 ),	/* Offset= -366 (648) */
/* 1016 */	0xb4,		/* FC_USER_MARSHAL */
			0x83,		/* 131 */
/* 1018 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1020 */	NdrFcShort( 0x10 ),	/* 16 */
/* 1022 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1024 */	NdrFcShort( 0xfffffff4 ),	/* Offset= -12 (1012) */

			0x0
        }
    };

const CInterfaceProxyVtbl * _SaTest_ProxyVtblList[] = 
{
    ( CInterfaceProxyVtbl *) &_IArrayHolderProxyVtbl,
    0
};

const CInterfaceStubVtbl * _SaTest_StubVtblList[] = 
{
    ( CInterfaceStubVtbl *) &_IArrayHolderStubVtbl,
    0
};

PCInterfaceName const _SaTest_InterfaceNamesList[] = 
{
    "IArrayHolder",
    0
};

const IID *  _SaTest_BaseIIDList[] = 
{
    &IID_IDispatch,
    0
};


#define _SaTest_CHECK_IID(n)	IID_GENERIC_CHECK_IID( _SaTest, pIID, n)

int __stdcall _SaTest_IID_Lookup( const IID * pIID, int * pIndex )
{
    
    if(!_SaTest_CHECK_IID(0))
        {
        *pIndex = 0;
        return 1;
        }

    return 0;
}

const ExtendedProxyFileInfo SaTest_ProxyFileInfo = 
{
    (PCInterfaceProxyVtblList *) & _SaTest_ProxyVtblList,
    (PCInterfaceStubVtblList *) & _SaTest_StubVtblList,
    (const PCInterfaceName * ) & _SaTest_InterfaceNamesList,
    (const IID ** ) & _SaTest_BaseIIDList,
    & _SaTest_IID_Lookup, 
    1,
    2
};
