/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 3.01.75 */
/* at Wed Apr 29 13:05:39 1998
 */
/* Compiler settings for SaTest.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )
#include "rpc.h"
#include "rpcndr.h"
#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __SaTest_h__
#define __SaTest_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IArrayHolder_FWD_DEFINED__
#define __IArrayHolder_FWD_DEFINED__
typedef interface IArrayHolder IArrayHolder;
#endif 	/* __IArrayHolder_FWD_DEFINED__ */


#ifndef __ArrayHolder_FWD_DEFINED__
#define __ArrayHolder_FWD_DEFINED__

#ifdef __cplusplus
typedef class ArrayHolder ArrayHolder;
#else
typedef struct ArrayHolder ArrayHolder;
#endif /* __cplusplus */

#endif 	/* __ArrayHolder_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IArrayHolder_INTERFACE_DEFINED__
#define __IArrayHolder_INTERFACE_DEFINED__

/****************************************
 * Generated header for interface: IArrayHolder
 * at Wed Apr 29 13:05:39 1998
 * using MIDL 3.01.75
 ****************************************/
/* [unique][helpstring][dual][uuid][object] */ 



EXTERN_C const IID IID_IArrayHolder;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    interface DECLSPEC_UUID("CCE24679-0842-11D1-A84F-C9A7C7DED06D")
    IArrayHolder : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE GetArray( 
            /* [out][in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *ppsa) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE PutArray( 
            /* [in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *ppsa) = 0;
        
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_ArrayAsVariant( 
            /* [retval][out] */ VARIANT __RPC_FAR *pvar) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_ArrayAsVariant( 
            /* [in] */ VARIANT var) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IArrayHolderVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IArrayHolder __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IArrayHolder __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IArrayHolder __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IArrayHolder __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IArrayHolder __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IArrayHolder __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IArrayHolder __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetArray )( 
            IArrayHolder __RPC_FAR * This,
            /* [out][in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *ppsa);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *PutArray )( 
            IArrayHolder __RPC_FAR * This,
            /* [in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *ppsa);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ArrayAsVariant )( 
            IArrayHolder __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pvar);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ArrayAsVariant )( 
            IArrayHolder __RPC_FAR * This,
            /* [in] */ VARIANT var);
        
        END_INTERFACE
    } IArrayHolderVtbl;

    interface IArrayHolder
    {
        CONST_VTBL struct IArrayHolderVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IArrayHolder_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IArrayHolder_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IArrayHolder_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IArrayHolder_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IArrayHolder_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IArrayHolder_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IArrayHolder_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IArrayHolder_GetArray(This,ppsa)	\
    (This)->lpVtbl -> GetArray(This,ppsa)

#define IArrayHolder_PutArray(This,ppsa)	\
    (This)->lpVtbl -> PutArray(This,ppsa)

#define IArrayHolder_get_ArrayAsVariant(This,pvar)	\
    (This)->lpVtbl -> get_ArrayAsVariant(This,pvar)

#define IArrayHolder_put_ArrayAsVariant(This,var)	\
    (This)->lpVtbl -> put_ArrayAsVariant(This,var)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IArrayHolder_GetArray_Proxy( 
    IArrayHolder __RPC_FAR * This,
    /* [out][in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *ppsa);


void __RPC_STUB IArrayHolder_GetArray_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IArrayHolder_PutArray_Proxy( 
    IArrayHolder __RPC_FAR * This,
    /* [in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *ppsa);


void __RPC_STUB IArrayHolder_PutArray_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget] */ HRESULT STDMETHODCALLTYPE IArrayHolder_get_ArrayAsVariant_Proxy( 
    IArrayHolder __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pvar);


void __RPC_STUB IArrayHolder_get_ArrayAsVariant_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE IArrayHolder_put_ArrayAsVariant_Proxy( 
    IArrayHolder __RPC_FAR * This,
    /* [in] */ VARIANT var);


void __RPC_STUB IArrayHolder_put_ArrayAsVariant_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IArrayHolder_INTERFACE_DEFINED__ */



#ifndef __SATESTLib_LIBRARY_DEFINED__
#define __SATESTLib_LIBRARY_DEFINED__

/****************************************
 * Generated header for library: SATESTLib
 * at Wed Apr 29 13:05:39 1998
 * using MIDL 3.01.75
 ****************************************/
/* [helpstring][version][uuid] */ 



EXTERN_C const IID LIBID_SATESTLib;

#ifdef __cplusplus
EXTERN_C const CLSID CLSID_ArrayHolder;

class DECLSPEC_UUID("CCE2467A-0842-11D1-A84F-C9A7C7DED06D")
ArrayHolder;
#endif
#endif /* __SATESTLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  LPSAFEARRAY_UserSize(     unsigned long __RPC_FAR *, unsigned long            , LPSAFEARRAY __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  LPSAFEARRAY_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, LPSAFEARRAY __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  LPSAFEARRAY_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, LPSAFEARRAY __RPC_FAR * ); 
void                      __RPC_USER  LPSAFEARRAY_UserFree(     unsigned long __RPC_FAR *, LPSAFEARRAY __RPC_FAR * ); 

unsigned long             __RPC_USER  VARIANT_UserSize(     unsigned long __RPC_FAR *, unsigned long            , VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
void                      __RPC_USER  VARIANT_UserFree(     unsigned long __RPC_FAR *, VARIANT __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
