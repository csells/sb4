// ArrayHolder.h : Declaration of the CArrayHolder

#ifndef __ARRAYHOLDER_H_
#define __ARRAYHOLDER_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CArrayHolder
class ATL_NO_VTABLE CArrayHolder : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CArrayHolder, &CLSID_ArrayHolder>,
	public IDispatchImpl<IArrayHolder, &IID_IArrayHolder, &LIBID_SATESTLib>
{
public:
	CArrayHolder();
	virtual ~CArrayHolder();

DECLARE_REGISTRY_RESOURCEID(IDR_ARRAYHOLDER)

BEGIN_COM_MAP(CArrayHolder)
	COM_INTERFACE_ENTRY(IArrayHolder)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IArrayHolder
public:
	STDMETHODIMP GetArray(SAFEARRAY** ppsa);
	STDMETHODIMP PutArray(SAFEARRAY** ppsa);
	STDMETHODIMP get_ArrayAsVariant(VARIANT* pvar);
	STDMETHODIMP put_ArrayAsVariant(VARIANT var);

private:
    long*   m_rgn;
    size_t  m_nLen;    
};

#endif //__ARRAYHOLDER_H_
