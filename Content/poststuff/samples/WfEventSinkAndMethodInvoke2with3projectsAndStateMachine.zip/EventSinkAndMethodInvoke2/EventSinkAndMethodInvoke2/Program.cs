#region Using directives

using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Workflow.Runtime;
using System.Workflow.Runtime.Hosting;
using System.Workflow.Runtime.Messaging;
using System.Workflow.ComponentModel;

#endregion

namespace EventSinkAndMethodInvoke2
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Main AppDomain= {0}", AppDomain.CurrentDomain.Id);

			//Console.WriteLine("\nTesting sequential workflow:");
			//TestWorkflow(typeof(EventSinkAndMethodInvoke2.Workflow2));

			Console.WriteLine("\nTesting state machine workflow:");
			TestWorkflow(typeof(EventSinkAndMethodInvoke2.StateMachine1));
		}

		static void TestWorkflow(Type type)
		{
			AutoResetEvent waitHandle = new AutoResetEvent(false);
			WorkflowRuntime workflowRuntime = new WorkflowRuntime();

			// DONE: Add IOrderService implementation
			OrderServiceImpl orderService = new OrderServiceImpl();
			workflowRuntime.AddService(orderService);

			workflowRuntime.StartRuntime();
			workflowRuntime.WorkflowCompleted += delegate(object sender, WorkflowCompletedEventArgs e)
			{
				waitHandle.Set();
			};

			WorkflowInstance wf = workflowRuntime.StartWorkflow(type);

			// DONE: Simulate human decision time and approve the order
			System.Threading.Thread.Sleep(1000);
			orderService.ApproveOrder(wf, "this is a *fine* order!");

			// DONE: Handle termination
			workflowRuntime.WorkflowTerminated += delegate(object sender, WorkflowTerminatedEventArgs e)
			{
				Console.WriteLine("WorkflowTerminated: {0}", e.Reason);
				waitHandle.Set();
			};

			waitHandle.WaitOne();
			workflowRuntime.StopRuntime();
		}

	}

	class OrderServiceImpl : IOrderService
	{
		#region IOrderService Members

		Dictionary<Guid, Order> _workflowOrderMap = new Dictionary<Guid, Order>();

		public void CreateOrder(string customer, string orderDescription)
		{
			_workflowOrderMap.Add(BatchEnvironment.CurrentInstanceId, new Order(customer, orderDescription));
		}

		public void ApproveOrder(WorkflowInstance wf, string comment)
		{
			if (OrderApproved != null)
			{
				Guid wfId = wf.InstanceId;
				OrderApproved(null, new OrderEventArgs(wfId, _workflowOrderMap[wfId], comment));
			}
		}

		public event EventHandler<OrderEventArgs> OrderApproved;

		#endregion
	}

}
