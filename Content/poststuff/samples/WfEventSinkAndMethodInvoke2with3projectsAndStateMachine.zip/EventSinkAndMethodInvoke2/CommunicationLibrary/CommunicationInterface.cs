using System;
using System.Workflow.Runtime.Messaging;
using System.Workflow.ComponentModel;
using System.Collections.Generic;
using System.Workflow.Runtime;

namespace EventSinkAndMethodInvoke2
{
	// DONE: Args and everything the args send have to be serializable
	[Serializable]
	public class OrderEventArgs : WorkflowMessageEventArgs
	{
		Order _order;
		public Order Order
		{
			get { return _order; }
		}

		string _comment;
		public string Comment
		{
			get { return _comment; }
		}

		public OrderEventArgs(Guid workflowInstanceId, Order order, string comment)
			: base(workflowInstanceId)
		{
			_order = order;
			_comment = comment;
		}
	}

	[Serializable]
	public class Order
	{
		Guid _orderId = Guid.NewGuid();
		public Guid OrderId
		{
			get { return _orderId; }
		}

		private string _customer;

		public string Customer
		{
			get { return _customer; }
			set { _customer = value; }
		}

		private string _desc;

		public string Description
		{
			get { return _desc; }
			set { _desc = value; }
		}

		public Order(string customer, string desc)
		{
			_customer = customer;
			_desc = desc;
		}
	}

	[DataExchangeService]
	public interface IOrderService
	{
		void CreateOrder(string customer, string orderDescription);
		event EventHandler<OrderEventArgs> OrderApproved;
	}

}
