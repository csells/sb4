// MainWnd.h: Defines main window for application

#pragma once
#ifndef MAINWND_H
#define MAINWND_H

typedef CWinTraitsOR<0, WS_EX_CLIENTEDGE, CFrameWinTraits>
        CMainWindowTraits;

class CMainWindow : public CWindowImpl<CMainWindow, CWindow, CMainWindowTraits>
{
public:
    CMainWindow()
    {
        // Initialize window info
        CWndClassInfo&  wci = GetWndClassInfo();
        if( !wci.m_atom )
        {
            wci.m_wc.hIcon = LoadIcon(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDI_AFFIRM));
            wci.m_wc.hIconSm = (HICON)::LoadImage(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDI_AFFIRM), IMAGE_ICON, 16, 16, LR_DEFAULTCOLOR);
            wci.m_wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
            wci.m_bSystemCursor = TRUE;
            wci.m_lpszCursorID = IDC_ARROW;
        }
    }

BEGIN_MSG_MAP(CMainWindow)
    MESSAGE_HANDLER(WM_CREATE, OnCreate)
    MESSAGE_HANDLER(WM_SIZE, OnSize)
    COMMAND_ID_HANDLER(ID_FILE_EXIT, OnExit)
    COMMAND_ID_HANDLER(ID_HELP_ABOUT, OnAbout)
END_MSG_MAP()

// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);


    LRESULT OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& lResult)
    {
        LPCTSTR pszControlName = __T("res://Affirm.exe/main.htm");
        if( !m_ax.Create(m_hWnd, CWindow::rcDefault, pszControlName, WS_CHILD | WS_VISIBLE) )
        {
            return -1;
        }

        SetForegroundWindow(m_ax);
        m_ax.SetFocus();

        return 0;
    }

    LRESULT OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& lResult)
    {
        RECT rect = { 0, 0, LOWORD(lParam), HIWORD(lParam) };
        m_ax.MoveWindow(&rect);

        return 0;
    }
    
    LRESULT OnExit(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
    {
        DestroyWindow();
        return 0;
    }
    
    LRESULT OnAbout(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
    {
        CSimpleDialog<IDD_ABOUTBOX> dlg;
        dlg.DoModal();
        return 0;
    }
    
    void OnFinalMessage(HWND)
    {
        PostQuitMessage(0);
    }

    // Required to forward messages to the control
    BOOL PreTranslateMessage(MSG* pMsg)
    {
        // Accelerators are only keyboard or mouse messages
        if ((pMsg->message < WM_KEYFIRST || pMsg->message > WM_KEYLAST) &&
            (pMsg->message < WM_MOUSEFIRST || pMsg->message > WM_MOUSELAST))
            return FALSE;

		// Find a direct child of this window from the window that has focus.
        // This will be AxHost window for the hosted control.
		HWND hWndCtl = ::GetFocus();
		if( IsChild(hWndCtl) && ::GetParent(hWndCtl) != m_hWnd )
		{
			do hWndCtl = ::GetParent(hWndCtl);
			while( ::GetParent(hWndCtl) != m_hWnd );
		}

        // Give the control (via the AxHost) a chance to translate this message
		if (::SendMessage(hWndCtl, WM_FORWARDMSG, 0, (LPARAM)pMsg) ) return TRUE;

        // Check for dialog-type navigation accelerators
        return IsDialogMessage(pMsg);
    }

private:
    CAxWindow   m_ax;
};

#endif  // MAINWND_H
