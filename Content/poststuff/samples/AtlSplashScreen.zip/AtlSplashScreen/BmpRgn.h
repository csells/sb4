// BmpRgn.h: interface for the CBmpRgn class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BMPRGN_H__0C47C521_99E8_11D3_83D7_444553547777__INCLUDED_)
#define AFX_BMPRGN_H__0C47C521_99E8_11D3_83D7_444553547777__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <vector>
#include <list>
#include <AttilaWrappers.h>
#include <AttilaGdi.h>

class CBmpRgn  
{

public:
	CBmpRgn();
	virtual ~CBmpRgn();
	HRGN CreateRgn(HBITMAP hBitmap, COLORREF clrBkgnd, int PolyFillMode = ALTERNATE);

private:

	typedef std::vector<bool> bVector1d;
	typedef std::vector<bVector1d> bVector2d;
    typedef std::vector<CPoint> vPoints;

	int CountOfNeighbors(bVector2d& Img, int x, int y);
	int CountOfVertNeighbors(bVector2d& Img, int x, int y);
	int CountOfHorzNeighbors(bVector2d& Img, int x, int y);

private:
	HBITMAP m_hBitmap;
	BITMAP m_Bitmap;
	COLORREF m_clrBkgnd;
	CGdiMemDC m_MemDc;

	bVector2d *m_pMonoBits;
	bVector2d *m_pEdgeBits;
	vPoints m_EdgePoints;
};

#endif // !defined(AFX_BMPRGN_H__0C47C521_99E8_11D3_83D7_444553547777__INCLUDED_)
