// BmpRgn.cpp: implementation of the CBmpRgn class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "BmpRgn.h"
#include <AttilaGdi.h>
//#include <algorithm>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CBmpRgn::CBmpRgn()
{
	//
	// Initialize our vectors
	//
	m_pMonoBits = NULL;
	m_pEdgeBits = NULL;
	
	//
	// Done
	//
	return;
}

CBmpRgn::~CBmpRgn()
{
}



//
// DumpImage
//	- Debug display of a 2d vector of bools (monochrome bitmap)
//

#define DumpImage(img)	{																\
		char s[1024] = "";																\
		ATLTRACE("bmHeight: %d, bmWidth: %d\n", m_Bitmap.bmHeight, m_Bitmap.bmWidth);	\
		s[0] = NULL;																	\
		for (y = 0; y < m_Bitmap.bmHeight; y++) {										\
			s[strlen(s) + 1] = NULL;													\
			s[strlen(s)] = 48 + (y % 10);												\
		}																				\
		ATLTRACE("   %s\n", s);															\
		for (y = 0; y < m_Bitmap.bmHeight; y++) {										\
			s[0] = NULL;																\
			for (x = 0; x < m_Bitmap.bmWidth; x++) {									\
				if (img[x][y])															\
					strcat(s, "T");														\
				else																	\
					strcat(s, " ");														\
			}																			\
			ATLTRACE("%2.2d>%s\n", y, s);												\
		}																				\
		ATLTRACE("\n");																	\
	}																					\



//
// CreateRgn
//	- Build a region from a bitmap and a background color.
//
HRGN CBmpRgn::CreateRgn(HBITMAP hBitmap, COLORREF clrBkgnd, int PolyFillMode)
{
	HDC ScreenDc;
	int x, y;

	//
	// Set our private members
	//
	m_hBitmap = hBitmap;
	m_clrBkgnd = clrBkgnd;


	//
	// Get the details about the bitmap
	//
	GetObject(m_hBitmap, sizeof(m_Bitmap), &m_Bitmap);

	//
	// Create our working images
	//
	if (m_pMonoBits)
		delete m_pMonoBits;
	m_pMonoBits = new bVector2d(m_Bitmap.bmWidth, bVector1d(m_Bitmap.bmHeight, false));

	if (m_pEdgeBits)
		delete m_pEdgeBits;
	m_pEdgeBits = new bVector2d(m_Bitmap.bmWidth, bVector1d(m_Bitmap.bmHeight, false));

	//
	// Use references to the monochrome images
	//
	bVector2d& MonoImage = *m_pMonoBits;
	bVector2d& EdgesOnly = *m_pEdgeBits;

	//
	// Select the bitmap into a memory device context
	//	- Allows us to use GetPixel() function. Though using the
	//	  GDI to get pixel values is likely slower than hand coding
	//	  the access it certainly makes this code much cleaner.
	//
	ScreenDc = GetDC(NULL);
	m_MemDc.CreateCompatibleDC(GetDC(NULL), m_hBitmap);
	m_MemDc.SelectObject(m_hBitmap);
	ReleaseDC(NULL, ScreenDc);

	//
	// Convert the image to a 2d array of bool's.
	//	- More or less monochrome. Though it's no longer
	//	  a real bitmap.
	//
	for (x = 0; x < m_Bitmap.bmWidth; x++) {
		for (y = 0; y < m_Bitmap.bmHeight; y++) {
			MonoImage[x][y] = (GetPixel(m_MemDc, x, y) != m_clrBkgnd);
		}
	}

#ifdef _DEBUG
	DumpImage(MonoImage)
#endif

	//
	// Remove fully surrounded pixels
	//	- This will leave the polygon(s) outlined with a thick edge.
	//
	for (x = 0; x < m_Bitmap.bmWidth; x++) {
		for (y = 0; y < m_Bitmap.bmHeight; y++) {
			if (MonoImage[x][y]) {
				if (CountOfNeighbors(MonoImage, x, y) != 8)
					EdgesOnly[x][y] = true;
			}
		}
	}

#ifdef _DEBUG
	DumpImage(EdgesOnly)
#endif

	//
	// Thin the edges by removing redundant pixels
	//	- This will yield an image where every "on" pixel is
	//	  connected to at most 4 other pixels, though typically
	//	  only two (4 connected pixel only occur at the intersection
	//	  point of two lines, crossing each other at 90 degrees).
	//
	for (x = 0; x < m_Bitmap.bmWidth; x++) {
		for (y = 0; y < m_Bitmap.bmHeight; y++) {
			//
			// Only check pixels that are on
			//
			if (EdgesOnly[x][y]) {
				//
				// If this pixel has both a vertical and horizontal neighbor then it may be redundant
				//
				if (CountOfVertNeighbors(EdgesOnly, x, y) >= 1 && CountOfHorzNeighbors(EdgesOnly, x, y) >= 1) {
					//
					// If all but one of it's original nieghbors where on then
					// this pixel is a redundant "inside" pixel - remove it.
					//
					if (CountOfNeighbors(MonoImage, x, y) == 7)
						EdgesOnly[x][y] = false;
				}

			}
		}
	}

#ifdef _DEBUG
	DumpImage(EdgesOnly)
#endif


	//
	// Build the list of all points that form edges
	//	- This is an pixel that is left "on", or true, in the
	//	  EdgesOnly image.
	//
	for (x = 0; x < m_Bitmap.bmWidth; x++) {
		for (y = 0; y < m_Bitmap.bmHeight; y++) {
			if (EdgesOnly[x][y]) {
				m_EdgePoints.push_back(CPoint(x, y));
			}
		}
	}

#ifdef _DEBUG
	{
		vPoints::iterator i;
		for (i = m_EdgePoints.begin(); i != m_EdgePoints.end(); ++i)
			ATLTRACE("m_EdgePoint(%d, %d)\n", i->x, i->y);
	}
#endif

	//
	// Setup to create the region
	//
	POINT *PolyPts;
	POINT *p;

	PolyPts = new POINT[m_EdgePoints.size()];
	p = PolyPts;
	for (vPoints::iterator i = m_EdgePoints.begin(); i != m_EdgePoints.end(); ++i) {
		*p++ = (*i);
	}

	//
	// Create the region
	//
	HRGN hRgn = CreatePolygonRgn(PolyPts, m_EdgePoints.size(), PolyFillMode);

#if _DEBUG
	if (hRgn == NULL) {
		long e = GetLastError();		// ought not to happen?
	}
#endif

	//
	// cleanup the points
	//
	delete PolyPts;
	PolyPts = NULL;
	p = NULL;

	//
	// Done
	//
	return hRgn;
}


//
// CountOfMonoNeighbors
//	- Count the number of pixels next to the specified one.
//
int CBmpRgn::CountOfNeighbors(bVector2d& Img, int x, int y)
{
	int Count = 0;

	//
	// To avoid index out of bounds exceptions there's lots of
	// checks of the x and y values.
	//
	if (x >= 1 && y >= 1)
		if (Img[x - 1][y - 1]) Count++;

	if (x >= 1)
		if (Img[x - 1][y]) Count++;

	if (x >= 1)
		if (Img[x - 1][y + 1]) Count++;
	
	if (y >= 1)
		if (Img[x][y - 1]) Count++;

	if (y < Img[x].size())	
		if (Img[x][y + 1]) Count++;

	if (x < Img.size() && y >= 1)
		if (Img[x + 1][y - 1]) Count++;
	
	if (x < Img.size())
		if (Img[x + 1][y]) Count++;

	if (x < Img.size() && y < Img[x].size())
		if (Img[x + 1][y + 1]) Count++;

	return Count;
}

//
// CountOfVertNeighbors
//	- Count the number of neighbors to the north or south.
//
int CBmpRgn::CountOfVertNeighbors(bVector2d& Img, int x, int y)
{
	int Count = 0;

	if (y >= 1)
		if (Img[x][y - 1]) Count++;

	if (Img[x][y + 1]) Count++;

	return Count;
}

//
// CountOfHorxNeighbors
//	- Count the number of neighbors to the east or west
//
int CBmpRgn::CountOfHorzNeighbors(bVector2d& Img, int x, int y)
{
	int Count = 0;

	if (x >= 1)
		if (Img[x - 1][y]) Count++;

	if (Img[x + 1][y]) Count++;

	return Count;
}


