﻿///<reference path='../declare/winrt.d.ts' static='true' />
///<reference path='../declare/winjs.d.ts' static='true' />

declare var msSetImmediate: (expression: any) => void;
