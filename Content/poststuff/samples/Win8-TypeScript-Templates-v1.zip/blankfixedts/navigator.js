﻿var Application;
(function (Application) {
    "use strict";
    var appView = Windows.UI.ViewManagement.ApplicationView;
    var nav = WinJS.Navigation;
    Application.navigator;
    var PageControlNavigator = (function () {
        function PageControlNavigator(element, options) {
            var _this = this;
            this.home = "";
            this._element = null;
            this._lastNavigationPromise = WinJS.Promise.as();
            this._element = element || document.createElement("div");
            this._element.appendChild(this._createPageElement());
            this.home = options.home;
            this._lastViewstate = appView.value;
            nav.onnavigated = function (args) {
                return _this._navigated(args);
            };
            window.onresize = function (args) {
                return _this._resized(args);
            };
            document.body.onkeyup = function (args) {
                return _this._keyupHandler(args);
            };
            document.body.onkeypress = function (args) {
                return _this._keypressHandler(args);
            };
            document.body.onmspointerup = function (args) {
                return _this._mspointerupHandler(args);
            };
            Application.navigator = this;
        }
        Object.defineProperty(PageControlNavigator.prototype, "pageControl", {
            get: function () {
                return this.pageElement ? this.pageElement.winControl : null;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(PageControlNavigator.prototype, "pageElement", {
            get: function () {
                return this._element.firstElementChild;
            },
            enumerable: true,
            configurable: true
        });
        PageControlNavigator.prototype._createPageElement = function () {
            var element = document.createElement("div");
            element.style.width = "100%";
            element.style.height = "100%";
            return element;
        };
        PageControlNavigator.prototype._getAnimationElements = function () {
            if(this.pageControl && this.pageControl.getAnimationElements) {
                return this.pageControl.getAnimationElements();
            }
            return this.pageElement;
        };
        PageControlNavigator.prototype._keypressHandler = function (args) {
            if(args.key === "Backspace") {
                nav.back();
            }
        };
        PageControlNavigator.prototype._keyupHandler = function (args) {
            if((args.key === "Left" && args.altKey) || (args.key === "BrowserBack")) {
                nav.back();
            } else {
                if((args.key === "Right" && args.altKey) || (args.key === "BrowserForward")) {
                    nav.forward();
                }
            }
        };
        PageControlNavigator.prototype._mspointerupHandler = function (args) {
            if(args.button === 3) {
                nav.back();
            } else {
                if(args.button === 4) {
                    nav.forward();
                }
            }
        };
        PageControlNavigator.prototype._navigated = function (args) {
            var newElement = this._createPageElement();
            var parentedComplete;
            var parented = new WinJS.Promise(function (c) {
                parentedComplete = c;
            });
            this._lastNavigationPromise.cancel();
            this._lastNavigationPromise = WinJS.Promise.timeout().then(function () {
                return WinJS.UI.Pages.render(args.detail.location, newElement, args.detail.state, parented);
            }).then(function parentElement(control) {
                var oldElement = this.pageElement;
                if(oldElement.winControl && oldElement.winControl.unload) {
                    oldElement.winControl.unload();
                }
                this._element.appendChild(newElement);
                this._element.removeChild(oldElement);
                oldElement.innerText = "";
                this._updateBackButton();
                parentedComplete();
                WinJS.UI.Animation.enterPage(this._getAnimationElements()).done();
            }.bind(this));
            args.detail.setPromise(this._lastNavigationPromise);
        };
        PageControlNavigator.prototype._resized = function (args) {
            if(this.pageControl && this.pageControl.updateLayout) {
                this.pageControl.updateLayout.call(this.pageControl, this.pageElement, appView.value, this._lastViewstate);
            }
            this._lastViewstate = appView.value;
        };
        PageControlNavigator.prototype._updateBackButton = function () {
            var backButton = this.pageElement.querySelector("header[role=banner] .win-backbutton");
            if(backButton) {
                backButton.onclick = function () {
                    return nav.back();
                };
                if(nav.canGoBack) {
                    backButton.removeAttribute("disabled");
                } else {
                    backButton.setAttribute("disabled", "disabled");
                }
            }
        };
        return PageControlNavigator;
    })();
    Application.PageControlNavigator = PageControlNavigator;    
    WinJS.Utilities.markSupportedForProcessing(PageControlNavigator);
})(Application || (Application = {}));

