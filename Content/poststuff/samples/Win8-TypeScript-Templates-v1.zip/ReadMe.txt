This code is provide as is without warranty or indemnification by Sells Brothers, Inc. On your head be it.

Refer to http://sellsbrothers.com for information on this code.