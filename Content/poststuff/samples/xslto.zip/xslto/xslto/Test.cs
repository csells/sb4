//-----------------------------------------------------------------------------
// Definition: Prototype implementation for mapping xml chunks to methods
//             using xpath statements.
//
// Input: xml file - XMLFile1.xml 
//        <?xml version="1.0" encoding="utf-8" ?> 
//        <person>
//          <name>Tim</name>
//          <age>34</age>
//        </person>
//
// Output: console window
//         person
//         name
//         Tim
//         age
//         34
//-----------------------------------------------------------------------------
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Reflection;
using System.Xml;
using System.Xml.Serialization;
using System.Xml.XPath;

namespace XSLTObjects
{
  /// <summary>
  /// Custom attribute for matching xpath statements to methods.
  /// </summary>
  [AttributeUsage(AttributeTargets.Method)]
  public class MatchAttribute : Attribute
  {
    private string xpath;

    public string XPath
    {
      get { return xpath; }
    }

    public MatchAttribute(string xpath)
    {
      this.xpath = xpath;
    }
  }

  /// <summary>
  /// XPath, methodInfo pair.  Used to keep a mapping between the xpath
  /// statement in the MatchAttribute and information about the methods 
  /// to which it applies.
  /// </summary>
  internal class XPathMethodInfoPair
  {
    private string xpath;
    private MethodInfo method;
    
    public string XPath
    {
      get { return xpath; }
    }

    public MethodInfo Method
    {
      get { return method; }
    }

    internal XPathMethodInfoPair(string xpath, MethodInfo method)
    {
      this.xpath = xpath;
      this.method = method;
    }
  }

  /// <summary>
  /// Not intended to be used directly.  Intended to be the base class
  /// of one written to map specific, expected elements to methods.
  /// 
  /// This class is meant to do the basic mechanics of matching xpath 
  /// to methods, invoking methods and doing the general walking of the 
  /// document.
  /// </summary>
  public class Transform
  {
    private Stack<XPathNavigator> navStack;
    private List<XPathMethodInfoPair> mapping;

    /// <summary>
    /// Creates a list of XPathMethodInfoPair objects that represent the 
    /// xpath to method mappings.  Called multiple times, but the mapping
    /// is done once.
    /// </summary>
    private void LoadMapping()
    {
      if (mapping == null)
      {
        mapping = new List<XPathMethodInfoPair>();

        Type t = GetType();

        // get all method info's for this type
        MethodInfo[] infos = t.GetMethods();
        foreach (MethodInfo info in infos)
        {
          // look for custom Match attribute
          object[] attrs = info.GetCustomAttributes(typeof(MatchAttribute), true);

          if (attrs.Length > 1)
          {
            throw new ApplicationException(string.Format("Can only have 1 MatchAttribute on method {0}", info.Name));
          }
          else if (attrs.Length == 1)
          {
            MatchAttribute attr = attrs[0] as MatchAttribute;
            if (attr == null)
            {
              throw new ApplicationException("Expected object of type MatchAttribute");
            }

            mapping.Add(new XPathMethodInfoPair(attr.XPath, info));
          }
        }
      }
    }

    /// <summary>
    /// Determines whether the current position in the XPathNavigator
    /// matches with one of the xpath, method pairs.  If it does, it
    /// returns the corresponding method information.
    /// </summary>
    private MethodInfo MatchMethod(XPathNavigator node)
    {
      foreach (XPathMethodInfoPair pair in mapping)
      {
        if (node.Matches(pair.XPath))
        {
          return pair.Method;
        }
      }
      return null;
    }

    /// <summary>
    /// Begins walking the document.
    /// </summary>
    public void Execute(XPathNavigator nav)
    {
      if (navStack == null)
        navStack = new Stack<XPathNavigator>();
      navStack.Push(nav);
      ApplyTemplates("/");
      navStack.Clear();
    }

    /// <summary>
    /// Recursive method that uses input xpath statement to select
    /// and walk a set of nodes.  If the node matches one of the
    /// xpath, method pairs, it detemines the expected parameters and
    /// invokes the method.
    /// 
    /// It uses a stack to maintain the position of the navigator 
    /// despite recursive calls.
    /// </summary>
    protected void ApplyTemplates(string selection)
    {
      LoadMapping();

      XPathNavigator nav = navStack.Peek();
      XPathNodeIterator iter = nav.Select(selection);
      while (iter.MoveNext())
      {
        MethodInfo method = MatchMethod(iter.Current);
        if (method != null)
        {
          object[] args = new object[1];
          navStack.Push(iter.Current);

          ParameterInfo[] paramInfos = method.GetParameters();
          if (paramInfos.Length > 1)
          {
            throw new ApplicationException("Expected match method to have one parameter");
          }
          Type t = paramInfos[0].ParameterType;
          if (t == typeof(XPathNavigator))
          {
            args[0] = navStack.Peek();
          }
          else
          { // not used
            XmlSerializer xs = new XmlSerializer(t);
            XmlReader xr = navStack.Peek().ReadSubtree();
            if (xr == null)
              throw new ApplicationException("ReadSubtree not implemented yet");
            args[0] = xs.Deserialize(xr);
          }

          method.Invoke(this, args);
          navStack.Pop();
        }
      }
    }

    /// <summary>
    /// General document walking.
    /// </summary>
    [Match("/")]
    public virtual void Document(XPathNavigator nav)
    {
      ApplyTemplates("node()");
    }

    /// <summary>
    /// General document walking.
    /// </summary>
    [Match("*")]
    public virtual void Element(XPathNavigator nav)
    {
      ApplyTemplates("*");
    }
  }

  /// <summary>
  /// Implementation of the Transform class that maps specific, expected
  /// elements to methods.  The methods of this class expect the xml 
  /// elements in the sample input file (XMLFile1.xml).
  /// </summary>
  public class MyTransform : Transform
  {
    [Match("/person")]
    public void Person(XPathNavigator nav)
    {
      Console.WriteLine(nav.Name);
      ApplyTemplates("*");
    }

    [Match("name")]
    public void Name(XPathNavigator nav)
    {
      Console.WriteLine(nav.Name);
      ApplyTemplates("text()");
    }

    [Match("age")]
    public void Age(XPathNavigator nav)
    {
      Console.WriteLine(nav.Name);
      ApplyTemplates("text()");
    }

    [Match("text()")]
    public void Text(XPathNavigator nav)
    {
      Console.WriteLine(nav.Value);
    }
  }

  /// <summary>
  /// Prototype implementation of mapping xml chunks to methods using
  /// xpath statements.
  /// </summary>
  class Test
  {
    private void InstanceMain(string[] args)
    {
      MyTransform trans = new MyTransform();
      XPathDocument doc = new XPathDocument(@"..\..\XMLFile1.xml");
      trans.Execute(doc.CreateNavigator());
    }

    static void Main(string[] args)
    {
      new Test().InstanceMain(args);
    }
  }
}
