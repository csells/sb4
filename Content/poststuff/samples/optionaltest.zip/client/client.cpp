// client.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

int main(int argc, char* argv[])
{
    CoInitialize(0);

    try
    {
        IKingOfTheWorldPtr sp(__uuidof(KingOfTheWorld));

        // No automation use of defaultvalue from C++
        sp->AnnounceStatus(L"I'm the king of the world!");
    }
    catch(...) { printf("oops\n"); }

    CoUninitialize();
	return 0;
}
