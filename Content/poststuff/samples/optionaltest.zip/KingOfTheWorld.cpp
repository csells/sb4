// KingOfTheWorld.cpp : Implementation of CKingOfTheWorld
#include "stdafx.h"
#include "Optionaltest.h"
#include "KingOfTheWorld.h"

/////////////////////////////////////////////////////////////////////////////
// CKingOfTheWorld


STDMETHODIMP CKingOfTheWorld::AnnounceStatus(BSTR bstrStatus)
{
	MessageBoxW(0, bstrStatus, L"Status", MB_SETFOREGROUND);

	return S_OK;
}
