// KingOfTheWorld.h : Declaration of the CKingOfTheWorld

#ifndef __KINGOFTHEWORLD_H_
#define __KINGOFTHEWORLD_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CKingOfTheWorld
class ATL_NO_VTABLE CKingOfTheWorld : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CKingOfTheWorld, &CLSID_KingOfTheWorld>,
	public IDispatchImpl<IKingOfTheWorld, &IID_IKingOfTheWorld, &LIBID_OPTIONALTESTLib>
{
public:
	CKingOfTheWorld()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_KINGOFTHEWORLD)
DECLARE_NOT_AGGREGATABLE(CKingOfTheWorld)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CKingOfTheWorld)
	COM_INTERFACE_ENTRY(IKingOfTheWorld)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IKingOfTheWorld
public:
	STDMETHOD(AnnounceStatus)(/*[in, optional, defaultvalue("I'm the king of the world")]*/ BSTR bstrStatus);
};

#endif //__KINGOFTHEWORLD_H_
