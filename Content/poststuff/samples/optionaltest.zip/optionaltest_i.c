/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Mon Oct 12 09:22:43 1998
 */
/* Compiler settings for C:\TEMP\optionaltest\optionaltest.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IKingOfTheWorld = {0xE2910422,0x6190,0x11D2,{0x90,0xD5,0x00,0x10,0x4B,0x21,0x68,0xFE}};


const IID LIBID_OPTIONALTESTLib = {0xE2910416,0x6190,0x11D2,{0x90,0xD5,0x00,0x10,0x4B,0x21,0x68,0xFE}};


const CLSID CLSID_KingOfTheWorld = {0xE2910423,0x6190,0x11D2,{0x90,0xD5,0x00,0x10,0x4B,0x21,0x68,0xFE}};


#ifdef __cplusplus
}
#endif

