var script = WScript;
var book = new ActiveXObject("BookTickerSvr.AmazonTicker");

var rgISBNs = new Array;
rgISBNs[0] = "0201379686";
rgISBNs[1] = "0201634503";
rgISBNs[2] = "0201695898";
rgISBNs[3] = "0135200245";
rgISBNs[4] = "1-57231-995-X";

var sRanks = "";
for( var i = 0; i != rgISBNs.length; ++i )
{
    book.isbn = rgISBNs[i];
    book.updateBookInfo();
    sRanks += "'" + book.title + "' sales rank: " + book.salesRank + ", reviews:" + book.reviewCount + "\n";
}

script.Echo(sRanks);
