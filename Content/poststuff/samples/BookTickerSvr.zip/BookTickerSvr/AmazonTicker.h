// AmazonTicker.h : Declaration of the CAmazonTicker

#ifndef __AMAZONTICKER_H_
#define __AMAZONTICKER_H_

#include "resource.h"       // main symbols
#include "BookTickerSvrCP.h"

// Handle redirection
template <class T>
class CBindStatusCallback2 : public CBindStatusCallback<T>
{
public:
    typedef CBindStatusCallback<T> baseClass;

    ~CBindStatusCallback2()
    {
        // TODO: This is never called...
        ATLTRACE("~CBindStatusCallback2()\n");
    }

    // Create us instead of base class
	static HRESULT Download(T* pT, ATL_PDATAAVAILABLE pFunc, BSTR bstrURL, IUnknown* pUnkContainer = NULL, BOOL bRelative = FALSE)
	{
		CComObject<CBindStatusCallback2<T> > *pbsc;
		HRESULT hRes = CComObject<CBindStatusCallback2<T> >::CreateInstance(&pbsc);
		if (FAILED(hRes))
			return hRes;
		return pbsc->StartAsyncDownload(pT, pFunc, bstrURL, pUnkContainer, bRelative);
	}

    // Cache the container for potential redirection use
    HRESULT StartAsyncDownload(T* pT, ATL_PDATAAVAILABLE pFunc, BSTR bstrURL, IUnknown* pUnkContainer = NULL, BOOL bRelative = FALSE)
	{
        m_spunkContainer = pUnkContainer;
        return baseClass::StartAsyncDownload(pT, pFunc, bstrURL, pUnkContainer, bRelative);
	}

    // Look for redirection URL
    STDMETHODIMP OnProgress(ULONG ulProgress, ULONG ulProgressMax, ULONG ulStatusCode, LPCWSTR szStatusText)
    {
        if( ulStatusCode == BINDSTATUS_REDIRECTING )
        {
            m_bstrRedirectUrl = szStatusText;
        }

        return baseClass::OnProgress(ulProgress, ulProgressMax, ulStatusCode, szStatusText);
    }

    // After we get the redirect URL, we'll get this
	STDMETHODIMP OnStopBinding(HRESULT hresult, LPCWSTR szError)
	{
		m_spBinding.Release();
		m_spBindCtx.Release();
		m_spMoniker.Release();

        if( m_bstrRedirectUrl.Length() )
        {
            // Detach URL in case we check the redirect before StartAsyncDownload returns
            BSTR    bstrRedirectUrl = m_bstrRedirectUrl.Detach();

            // Start download from redirect URL
            HRESULT hr = baseClass::StartAsyncDownload(m_pT, m_pFunc, bstrRedirectUrl, m_spunkContainer, FALSE);

            SysFreeString(bstrRedirectUrl);
            return hr;
        }

        (m_pT->*m_pFunc)(this, NULL, 0);
        m_spunkContainer.Release();

        // TODO: I don't believe this object ever goes away...
        this->AddRef(); this->Release(); // Trigger 'delete this' if we're the last ref

        return S_OK;
	}

private:
    CComBSTR            m_bstrRedirectUrl;
    CComPtr<IUnknown>   m_spunkContainer;
};

/////////////////////////////////////////////////////////////////////////////
// CAmazonTicker

class ATL_NO_VTABLE CAmazonTicker : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CAmazonTicker, &CLSID_AmazonTicker>,
	public ISupportErrorInfo,
	public IDispatchImpl<IBookTicker, &IID_IBookTicker>,
	public CProxy_IBookTickerEvents< CAmazonTicker >,
	public IConnectionPointContainerImpl<CAmazonTicker>,
    public IProvideClassInfo2Impl<&CLSID_AmazonTicker, &DIID__IBookTickerEvents>,
    public IPersistPropertyBagImpl<CAmazonTicker>,
    public IObjectWithSiteImpl<CAmazonTicker>,
    public IPropertyNotifySinkCP<CAmazonTicker>,
    public CFirePropNotifyEvent
{
public:
	CAmazonTicker();

    void OnData(CBindStatusCallback<CAmazonTicker>* pbsc, BYTE* pBytes, DWORD dwSize);

DECLARE_REGISTRY_RESOURCEID(IDR_AMAZONTICKER)
DECLARE_NOT_AGGREGATABLE(CAmazonTicker)
//DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CAmazonTicker)
	COM_INTERFACE_ENTRY(IBookTicker)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY_IMPL(IConnectionPointContainer)
	COM_INTERFACE_ENTRY(IProvideClassInfo)
	COM_INTERFACE_ENTRY(IProvideClassInfo2)
	COM_INTERFACE_ENTRY(IPersist)
	COM_INTERFACE_ENTRY(IPersistPropertyBag)
    COM_INTERFACE_ENTRY(IObjectWithSite)
END_COM_MAP()

BEGIN_CONNECTION_POINT_MAP(CAmazonTicker)
	CONNECTION_POINT_ENTRY(DIID__IBookTickerEvents)
	CONNECTION_POINT_ENTRY(IID_IPropertyNotifySink)
END_CONNECTION_POINT_MAP()

BEGIN_PROP_MAP(CAmazonTicker)
    PROP_ENTRY("ISBN", 1, CLSID_NULL)
END_PROP_MAP()

BEGIN_CATEGORY_MAP(CPenguin)
  IMPLEMENTED_CATEGORY(CATID_SafeForScripting)
  IMPLEMENTED_CATEGORY(CATID_SafeForInitializing)
END_CATEGORY_MAP()

// ISupportsErrorInfo
public:
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IBookTicker
public:
	STDMETHOD(get_Asynch)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_Asynch)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(get_NormalizedISBN)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_AverageReview)(/*[out, retval]*/ double *pVal);
	STDMETHOD(get_BookUrl)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_ReadyState)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_ReviewCount)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_BookTitle)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_SalesRank)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_ISBN)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_ISBN)(/*[in]*/ BSTR newVal);

private:
    HRESULT StartUpdateBookInfo(BSTR bstrIsbn);
    HRESULT UpdateBookInfo(BSTR bstrIsbn);
    HRESULT ParsePage(const char* pszPage);

public:
    BOOL    m_bRequiresSave;

	HRESULT FireOnChanged(DISPID dispID)
	{
        return CFirePropNotifyEvent::FireOnChanged(GetUnknown(), dispID);
	}

private:
    CComBSTR    m_bstrIsbn;
    long        m_nSalesRank;
    CComBSTR    m_bstrTitle;
    long        m_nReviewCount;
    long        m_nReadyState;
    double      m_dbAverageReview;
    bool        m_bAsynch;
    std::string m_sPage;
};

#endif //__AMAZONTICKER_H_
