// AmazonTicker.cpp : Implementation of CAmazonTicker

#include "stdafx.h"
#include "BookTickerSvr.h"
#include "AmazonTicker.h"

/////////////////////////////////////////////////////////////////////////////
// CAmazonTicker helpers

static
HRESULT GetStringFromStream(
    IStream*    pStream,
    char**      ppsz)
{
    if( !ppsz ) return E_POINTER;
    *ppsz = 0;

    STATSTG stat = { 0 };
    HR(pStream->Stat(&stat, STATFLAG_NONAME));
    *ppsz = new char[stat.cbSize.LowPart + 1];
    if( !*ppsz ) return E_OUTOFMEMORY;

    ULONG   cbRead;
    HR(pStream->Read(*ppsz, stat.cbSize.LowPart, &cbRead));
    (*ppsz)[cbRead] = 0;

    return S_OK;
}

static
HRESULT GetStringFromUrl(
    LPCOLESTR   pszUrl,
    char**      ppsz)
{
    if( !ppsz ) return E_POINTER;
    *ppsz = 0;

    CComPtr<IBindCtx>   spBindCtx;
    HR(CreateBindCtx(0, &spBindCtx));

    ULONG               cchEaten;
    CComPtr<IMoniker>   spMoniker;
    HR(MkParseDisplayNameEx(spBindCtx, pszUrl, &cchEaten, &spMoniker));
    
    CComPtr<IStream>    spStream;
    HR(spMoniker->BindToStorage(spBindCtx, 0, __uuidof(spStream), (void**)&spStream));

    HR(GetStringFromStream(spStream, ppsz));

    return S_OK;
}

static
long NumberFromCommaNumber(const char* pszNumber)
{
    long    n = 0;
    long    cch = (pszNumber ? strlen(pszNumber) : 0);
    for( const char* pchDigit = &pszNumber[0]; pchDigit != &pszNumber[cch]; ++pchDigit )
    {
        if( isdigit(*pchDigit) )
        {
            n = (n * 10) + (*pchDigit - '0');
        }
    }

    return n;
}

static
HRESULT GetNormalizedIsbn(BSTR bstrIsbn, BSTR* pbstrNormalizedIsbn)
{
    if( !pbstrNormalizedIsbn ) return E_POINTER;
    *pbstrNormalizedIsbn = 0;

    CComBSTR    bstrNormalizedIsbn;
    size_t      cch = SysStringLen(bstrIsbn);
    for( size_t i = 0; i != cch; ++i )
    {
        if( (bstrIsbn[i] >= OLESTR('0') && bstrIsbn[i] <= OLESTR('9')) ||
            (bstrIsbn[i] >= OLESTR('A') && bstrIsbn[i] <= OLESTR('Z')) ||
            (bstrIsbn[i] >= OLESTR('a') && bstrIsbn[i] <= OLESTR('z')) )
        {
            OLECHAR sz[2];
            sz[0] = bstrIsbn[i];
            sz[1] = 0;
            bstrNormalizedIsbn += sz;
        }
    }

    *pbstrNormalizedIsbn = bstrNormalizedIsbn.Detach();
    return S_OK;
}

static
HRESULT GetUrlFromIsbn(BSTR bstrIsbn, BSTR* pbstrUrl)
{
    if( !pbstrUrl ) return E_POINTER;
    *pbstrUrl = 0;

    CComBSTR    bstrUrl = OLESTR("http://www.amazon.com/exec/obidos/ASIN/");
    //CComBSTR    bstrUrl = OLESTR("http://localhost/amazon/");

    CComBSTR    bstrNormalizedIsbn;
    HR(GetNormalizedIsbn(bstrIsbn, &bstrNormalizedIsbn));

    bstrUrl += bstrNormalizedIsbn;
    *pbstrUrl = bstrUrl.Detach();

    return S_OK;
}

/////////////////////////////////////////////////////////////////////////////
// CAmazonTicker

CAmazonTicker::CAmazonTicker()
:   m_bRequiresSave(TRUE),
    m_nSalesRank(0),
    m_nReviewCount(0),
    m_bAsynch(true),
    m_nReadyState(READYSTATE_COMPLETE)
{
}

void CAmazonTicker::OnData(
    CBindStatusCallback<CAmazonTicker>* pbsc,
    BYTE*                               pBytes,
    DWORD                               dwSize)
{
    // Still downloading
    if( dwSize )
    {
        m_sPage.append((const char*)pBytes, dwSize);
    }
    // Done downloading, parse the cached data
    else
    {
        ParsePage(m_sPage.c_str());
        m_sPage.erase();

        m_nReadyState = READYSTATE_COMPLETE;
        FireOnChanged(DISPID_READYSTATE);
        Fire_OnReadyStateChange();
    }
}

HRESULT CAmazonTicker::ParsePage(const char* pszPage)
{
    Regexp reTitle = "<TITLE>Amazon.com: A Glance: ([^\\(:]*)[^\n]*</TITLE>";
    if( reTitle.Match(pszPage) )
    {
        m_bstrTitle = reTitle[1];
    }
    else
    {
        return Error("Can't find Title for the ISBN");
    }

    Regexp reRank = "Sales Rank:[^,0-9]*([,0-9]+)";
    if( reRank.Match(pszPage) )
    {
        m_nSalesRank = NumberFromCommaNumber(reRank[1]);
    }
    else
    {
        return Error("Can't find Sales Rank for the ISBN");
    }

    Regexp reReviewCount = "Number of Reviews: ([0-9]+)";
    if( reReviewCount.Match(pszPage) )
    {
        m_nReviewCount = NumberFromCommaNumber(reReviewCount[1]);
    }

    if( m_nReviewCount )
    {
        Regexp  reAverageReview = "Avg\\. Customer Review:[^A]*ALT=\"([\\.0-9]+) out of 5 stars\">";
        if( reAverageReview.Match(pszPage) )
        {
            m_dbAverageReview = atof(reAverageReview[1].c_str());
        }
    }

    return S_OK;
}

/////////////////////////////////////////////////////////////////////////////
// ISupportErrorInfo

STDMETHODIMP CAmazonTicker::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IBookTicker
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// IBookTicker


STDMETHODIMP CAmazonTicker::get_ISBN(BSTR *pVal)
{
    return m_bstrIsbn.CopyTo(pVal);
}

STDMETHODIMP CAmazonTicker::put_ISBN(BSTR newVal)
{
    if( m_bAsynch ) { HR(StartUpdateBookInfo(newVal)); }
    else            { HR(UpdateBookInfo(newVal)); }

    return S_OK;
}

STDMETHODIMP CAmazonTicker::get_SalesRank(long *pVal)
{
    if( !pVal ) return E_POINTER;
    *pVal = m_nSalesRank;
	return S_OK;
}

STDMETHODIMP CAmazonTicker::get_BookTitle(BSTR *pVal)
{
    return m_bstrTitle.CopyTo(pVal);
}

STDMETHODIMP CAmazonTicker::get_ReviewCount(long *pVal)
{
    if( !pVal ) return E_POINTER;
    *pVal = m_nReviewCount;
    return S_OK;
}

STDMETHODIMP CAmazonTicker::get_BookUrl(BSTR *pVal)
{
    if( !m_bstrIsbn.Length() ) return E_UNEXPECTED;
    return GetUrlFromIsbn(m_bstrIsbn, pVal);
}

STDMETHODIMP CAmazonTicker::get_AverageReview(/*[out, retval]*/ double *pVal)
{
    if( !pVal ) return E_POINTER;

    *pVal = m_dbAverageReview;
    return S_OK;
}

STDMETHODIMP CAmazonTicker::get_NormalizedISBN(BSTR *pVal)
{
    if( !m_bstrIsbn ) return E_UNEXPECTED;

    HR(GetNormalizedIsbn(m_bstrIsbn, pVal));
    return S_OK;
}

STDMETHODIMP CAmazonTicker::get_Asynch(VARIANT_BOOL *pVal)
{
    if( !pVal ) return E_POINTER;
    *pVal = (m_bAsynch ? VARIANT_TRUE : VARIANT_FALSE);
    return S_OK;
}

STDMETHODIMP CAmazonTicker::put_Asynch(VARIANT_BOOL newVal)
{
    m_bAsynch = (newVal == VARIANT_TRUE);
    return S_OK;
}

STDMETHODIMP CAmazonTicker::get_ReadyState(long *pVal)
{
    if( !pVal ) return E_POINTER;
    *pVal = m_nReadyState;
    return S_OK;
}

HRESULT CAmazonTicker::StartUpdateBookInfo(BSTR bstrIsbn)
{
    if( !bstrIsbn || !*bstrIsbn ) return Error(OLESTR("Need an ISDN"));
    if( m_nReadyState != READYSTATE_COMPLETE ) return Error("Already updating book info");

	m_bstrIsbn = bstrIsbn;
    m_nSalesRank = 0;
    m_bstrTitle.Empty();
    m_nReviewCount = 0;
    m_dbAverageReview = 0.0;

    CComBSTR    bstrUrl;
    HR(GetUrlFromIsbn(bstrIsbn, &bstrUrl));

    m_nReadyState = READYSTATE_LOADED;
    FireOnChanged(DISPID_READYSTATE);
    Fire_OnReadyStateChange();

    // Start the download, making sure to pass the site to let the browser participate
    HR(CBindStatusCallback2<CAmazonTicker>::Download(this, OnData, bstrUrl, m_spUnkSite));
    return S_OK;
}

HRESULT CAmazonTicker::UpdateBookInfo(BSTR bstrIsbn)
{
    if( !bstrIsbn || !*bstrIsbn ) return Error(OLESTR("Need an ISDN"));
    if( m_nReadyState != READYSTATE_COMPLETE ) return Error("Already updating book info");

	m_bstrIsbn = bstrIsbn;
    m_nSalesRank = 0;
    m_bstrTitle.Empty();
    m_nReviewCount = 0;
    m_dbAverageReview = 0.0;

    CComBSTR    bstrUrl;
    HR(GetUrlFromIsbn(m_bstrIsbn, &bstrUrl));

    char*       pszPage = 0;
    HR(GetStringFromUrl(bstrUrl, &pszPage));
    HR(ParsePage(pszPage));

    delete[] pszPage;

    return S_OK;
}
