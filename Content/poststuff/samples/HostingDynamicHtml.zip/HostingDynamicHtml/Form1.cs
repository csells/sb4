using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;
using mshtml;

namespace HostingDynamicHtml
{
    [InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
    public interface ITest
    {
        void DisplayDialog(string s);
    }

	public class Form1 : System.Windows.Forms.Form, ITest
	{
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button cmdReplace;
        private System.Windows.Forms.Button cmdAppend;
        private AxSHDocVw.AxWebBrowser axWebBrowser;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

        IeHelper.DocHostUIHandler   handler = new IeHelper.DocHostUIHandler();

		public Form1()
		{
			// Required for Windows Form Designer support
			InitializeComponent();

			// Add any constructor code after InitializeComponent call
            handler.ExternalDispatch = this;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
            this.axWebBrowser = new AxSHDocVw.AxWebBrowser();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cmdReplace = new System.Windows.Forms.Button();
            this.cmdAppend = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.axWebBrowser)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // axWebBrowser
            // 
            this.axWebBrowser.Dock = System.Windows.Forms.DockStyle.Fill;
            this.axWebBrowser.Enabled = true;
            this.axWebBrowser.Location = new System.Drawing.Point(0, 56);
            this.axWebBrowser.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axWebBrowser.OcxState")));
            this.axWebBrowser.Size = new System.Drawing.Size(448, 294);
            this.axWebBrowser.TabIndex = 0;
            this.axWebBrowser.NavigateComplete2 += new AxSHDocVw.DWebBrowserEvents2_NavigateComplete2EventHandler(this.axWebBrowser_NavigateComplete2);
            this.axWebBrowser.DocumentComplete += new AxSHDocVw.DWebBrowserEvents2_DocumentCompleteEventHandler(this.axWebBrowser_DocumentComplete);
            // 
            // panel1
            // 
            this.panel1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                                 this.cmdReplace,
                                                                                 this.cmdAppend});
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(448, 56);
            this.panel1.TabIndex = 1;
            // 
            // cmdReplace
            // 
            this.cmdReplace.Enabled = false;
            this.cmdReplace.Location = new System.Drawing.Point(40, 16);
            this.cmdReplace.Name = "cmdReplace";
            this.cmdReplace.TabIndex = 0;
            this.cmdReplace.Text = "Replace";
            this.cmdReplace.Click += new System.EventHandler(this.cmdReplace_Click);
            // 
            // cmdAppend
            // 
            this.cmdAppend.Enabled = false;
            this.cmdAppend.Location = new System.Drawing.Point(136, 16);
            this.cmdAppend.Name = "cmdAppend";
            this.cmdAppend.TabIndex = 0;
            this.cmdAppend.Text = "Append";
            this.cmdAppend.Click += new System.EventHandler(this.cmdAppend_Click);
            // 
            // Form1
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(448, 350);
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                          this.axWebBrowser,
                                                                          this.panel1});
            this.Name = "Form1";
            this.Text = "Dynamic HTML Hosting";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.axWebBrowser)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

        private void Form1_Load(object sender, System.EventArgs e)
        {
            // Surf to an empty page
            object  dummy = new object();
            axWebBrowser.Navigate("about:blank", ref dummy, ref dummy, ref dummy, ref dummy);
        }

        private void axWebBrowser_DocumentComplete(object sender, AxSHDocVw.DWebBrowserEvents2_DocumentCompleteEvent e)
        {
            handler.SetHandler(axWebBrowser);
        }

        private void axWebBrowser_NavigateComplete2(object sender, AxSHDocVw.DWebBrowserEvents2_NavigateComplete2Event e)
        {
            cmdReplace.Enabled = true;
            cmdAppend.Enabled = true;
        }

        private void cmdReplace_Click(object sender, System.EventArgs e)
        {
            // Replace BODY's entire inner HTML
            IHTMLDocument2  document = (IHTMLDocument2)axWebBrowser.Document;
            IHTMLElement    body = (IHTMLElement)document.body;
            body.innerHTML = "<b onclick='window.external.DisplayDialog(\"clicked on Replacement\");'>Replacement</b> of entire BODY content";
        }

        private void cmdAppend_Click(object sender, System.EventArgs e)
        {
            // Append new text at the end of the document
            IHTMLDocument2  document = (IHTMLDocument2)axWebBrowser.Document;
            document.write("<p><b onclick='window.external.DisplayDialog(\"clicked on Appending\");'>Appending</b> a paragraph</p>");
        }

        #region Implementation of ITest
        public void DisplayDialog(string s)
        {
            MessageBox.Show(s, "ITest.DisplayDialog");
        }
        #endregion
	}
}
