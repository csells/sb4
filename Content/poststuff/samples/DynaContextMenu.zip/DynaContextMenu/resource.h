//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BmpView.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_CONTEXTMENU                 201
#define IDD_PROP_PAGE1                  202
#define IDD_PROP_PAGE2                  203
#define IDB_BITMAP1                     203
#define IDD_PROP_PAGE3                  204
#define IDC_TYPE                        1001
#define IDC_WIDTH                       1002
#define IDC_HEIGHT                      1003
#define IDC_HORRES                      1004
#define IDC_VERTRES                     1005
#define IDC_BITDEPTH                    1006
#define IDC_COMPRESSION                 1008
#define IDC_FILELOCATION                1009
#define IDC_FILESIZE                    1010
#define IDC_FILEDATE                    1011
#define IDC_FILEATTRIB                  1012
#define ID_RECENT_BTN                   32777
#define ID_VIEW_PROPERTIES              32778

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        204
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
