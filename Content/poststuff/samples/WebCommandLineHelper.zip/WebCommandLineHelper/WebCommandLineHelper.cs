// WebCommandLineHelper.cs: Contributed by Chris Sells
// Inspired by Rob Macdonald [rob@SALTERTON.COM]

#region Copyright � 2002 The Genghis Group
/*
 * This software is provided 'as-is', without any express or implied warranty.
 * In no event will the authors be held liable for any damages arising from the
 * use of this software.
 *
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, subject to the following restrictions:
 *
 * 1. The origin of this software must not be misrepresented; you must not claim
 * that you wrote the original software. If you use this software in a product,
 * an acknowledgment in the product documentation is required, as shown here:
 *
 * Portions copyright � 2002 The Genghis Group (http://www.genghisgroup.com/).
 *
 * 2. No substantial portion of the source code of this library may be redistributed
 * without the express written permission of the copyright holders, where
 * "substantial" is defined as enough code to be recognizably from this library.
*/
#endregion
#region Features
// This class is meant to be used to hide the difference between command line args
// when the app is launched locally via the shell or when it's launched remotely
// via an URL.
#endregion
#region Limitations
// -Requires EnvironmentPermission.
// -Should catch exceptions when permissions not present?
#endregion
#region Usage
/*
class App
{
    // Can be launched as EXE, e.g. foo.exe one two three
    // Can be launched as URL, e.g. http://localhost/foo/foo.exe?one&two&three
    // Cab be launched via URL with name-value pairs, too, but that requires parsing,
    // just like it would from the command line.
    static void Main(string[] args)
    {
        args = WebCommandLineHelper.CommandLineArgs(args);
        
        string argstring = "";
        foreach( string arg in args ) argstring += arg + "\r\n";
        MessageBox.Show(argstring, "Args from " + (WebCommandLineHelper.LaunchedFromUrl ? "URL" : "EXE"));
    }
}
*/
#endregion
#region History
// 10/1/02:
//  -Updated by Chris Sells [csells@sellsbrothers.com] to fix the current
//   AppDomain's APP_CONFIG_FILE to exclude URL arguments, otherwise the
//   custom .config appsettings can't be obtained, because the APP_CONFIG_FILE
//   variable is pre-loaded to include the entire URL, include the args.
//   This fix was inspired by Dave Thorson [davethorson@attbi.com]. Thanks, Dave!
#endregion

using System;
using System.Web;
using System.Security;

namespace Genghis.Web 
{
    public class WebCommandLineHelper 
    {
        static public bool Empty(string s) { return s == null || s.Length == 0; }

        static public bool LaunchedFromUrl 
        {
            get 
            {
                try 
                {
                    // Check if we have a site
                    string  url = (string)AppDomain.CurrentDomain.GetData("APPBASE");
                    System.Security.Policy.Site.CreateFromUrl(url);
                    return true;
                }
                catch( ArgumentException ) 
                {
                    return false;
                }
            }
        }

        // NOTE: This depends on where ieexec.exe usage
        static public string GetLaunchUrlWithArgs()
        {
            string[] cl = Environment.GetCommandLineArgs();
            if( cl.Length > 1 ) return cl[1];
            return null;
        }

        static public string GetLaunchUrlNoArgs()
        {
            string url = GetLaunchUrlWithArgs();
            if( Empty(url) ) return null;
            int delimiter = url.IndexOf('?');
            if( delimiter < 0 ) return url;
            return url.Substring(0, delimiter);
        }

        static public string GetLaunchUrlOnlyArgs()
        {
            string url = GetLaunchUrlWithArgs();
            if( Empty(url) ) return null;
            int delimiter = url.IndexOf('?');
            if( delimiter < 0 ) return null;
            return url.Substring(delimiter + 1);
        }

        static public void EnableUrlCommandLineArgs()
        {
            // NOTE: If an URL used to launch an EXE has arguments, those
            // arguments will make their way into the AppDomain's AppPath,
            // screwing all kinds of things up, e.g. finding the EXE's .config
            // file. Make sure to call this function *before* executing code
            // that relies on the AppPath, e.g. pulling items from the .config
            // file or pulling in referenced assemblies.
            AppDomain.CurrentDomain.SetData("APP_CONFIG_FILE", GetLaunchUrlNoArgs() + ".config");
        }

        static public string[] CommandLineArgs(string[] argsFromMain)
        {
            return CommandLineArgs(argsFromMain, true);
        }

        static public string[] CommandLineArgs(string[] argsFromMain, bool enableUrlCommandLineArgs)
        {
            if( !LaunchedFromUrl ) return argsFromMain;

            // NOTE: Fix issues w/ passing command line args via an URL
            if( enableUrlCommandLineArgs ) EnableUrlCommandLineArgs();

            System.Collections.ArrayList argList = new System.Collections.ArrayList();
            string url = GetLaunchUrlWithArgs();
            string qs = GetLaunchUrlOnlyArgs();
            HttpRequest request = new HttpRequest("", url, qs);

            foreach( string key in request.QueryString.Keys ) 
            {
                foreach( string value in request.QueryString.GetValues(key) ) 
                {
                    if( !Empty(key) ) argList.Add(key + "=" + value);
                    else argList.Add(value);
                }
            }

            return (string[])argList.ToArray(typeof(string));
        }

    }
}

