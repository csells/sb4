using System;
using System.Windows.Forms;
using Genghis.Web;

class App
{
    // Can be launched as EXE, e.g. foo.exe one two three
    // Can be launched as URL, e.g. http://localhost/foo/foo.exe?one&two&three
    static void Main(string[] args)
    {
        args = WebCommandLineHelper.CommandLineArgs(args);
        string argstring = "";
        foreach( string arg in args ) argstring += arg + "\r\n";
        MessageBox.Show(argstring, "Args for " + (WebCommandLineHelper.LaunchedFromUrl ? Environment.GetCommandLineArgs()[1] : "EXE"));

        // Test that the AppPath is OK by pulling in custom .config appsettings
        // NOTE: This depends on WebCommandLineHelper.EnableUrlCommandLineArgs()
        // being called already (WebCommandLineHelper.CommandLineArgs does it
        // for you unless you pass false as the 2nd arg).
        string pi = System.Configuration.ConfigurationSettings.AppSettings["pi"];
        MessageBox.Show("pi from .config= " + pi);
    }
}
