using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace EventSinkAndMethodInvoke2
{
	public partial class StateMachine1 : StateMachineWorkflow
	{
		private void code2_ExecuteCode(object sender, EventArgs e)
		{
			if (orderApproved1.Comment == null)
			{
				Code codeActivity = (Code)sender;
				IOrderService_Events.OrderApproved orderApproved2 = (IOrderService_Events.OrderApproved)(codeActivity.Parent.Activities["orderApproved1"]);
				Console.WriteLine("order approved: customer= {0}, product description= {1}, comment= {2}", orderApproved2.Order.Customer, orderApproved2.Order.Description, orderApproved2.Comment);
			}
		}
	}

}
