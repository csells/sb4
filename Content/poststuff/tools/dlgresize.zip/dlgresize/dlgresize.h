// dlgresize.h
