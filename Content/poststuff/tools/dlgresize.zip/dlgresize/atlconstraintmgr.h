// atlconstraintmgr.h
/////////////////////////////////////////////////////////////////////////////
// Usage:
// 1. Derive your dlg or window from CWndConstraintMgr
// 2. Add a constraint map
// 3. Chain the dlgs msg-map with CWndConstraintMgr
//
// class CFooDlg : public CDialogImpl<CFooDlg>,
//                 public CWndConstraintMgr<CFooDlg>
// {
// ...
// BEGIN_MSG_MAP(CFooDlg)
//	  CHAIN_MSG_MAP(CWndConstraintMgr<CFooDlg>)
// END_MSG_MAP()
//
// BEGIN_CONSTRAINT_MAP(CFooDlg)
//    CONSTRAINT_ENTRY(IDC_CTRL1, Fixed, Shift)			
//	  CONSTRAINT_ENTRY(IDC_CTRL2, Expand, Expand)			
//	  CONSTRAINT_ENTRY_RECT(IDC_CTRL3, 50, 0, 50, 0)
// END_CONSTRAINT_MAP()
// ...
// };
// 
// every constraint is between 0 and 100 and describes the percentage
// that the left/top/right/bottom position of the control is moved,
// relative to how much the dialog is resized.
//
// Standard constraints:
//	 Fixed	position doesn't change	
//	 Shift  position is shifted by the amount the dlg is resized
//   Expand width or height is expanded by the amount the dlg is resized
// 
// CONSTRAINT_ENTRY(IDC_CTRL1, Fixed, Shift) == CONSTRAINT_ENTRY_RECT(IDC_CTRL1, 0, 100, 0, 100)
// CONSTRAINT_ENTRY(IDC_CTRL2, Expand, Expand) == CONSTRAINT_ENTRY_RECT(IDC_CTRL2, 0, 0, 100, 100)			
/////////////////////////////////////////////////////////////////////////////
// History:
// 2/7/00
//  -Updated by Horst Veith [hveith@intercom.at]
//  -Added template argument to active the drawing of the grow handle
//  -Constraints are between 0 and 100 (which is more logical)
//  -Chris fixed a couple of typos in the CPropsheetConstraintMgr class.
//  -Chris also renovated some of the message handling to make debugging easier.
//  -Chris added an empty AddConstraints() function to allow a missing constraint map.
//
// 1/27/00:
//  -Updated by Chris Sells [csells@sellsbrothers.com].
//  -Added CONSTRAINT_MAP and template base classes.
//  -Moved order of args from Left, Right, Top, Bottom to Left, Top, Right, Bottom
//   to match all of Windows.
//  -Renamed CWndConstraintMgr to CWndConstraintMgrMgr.
//  -Added separated CWndConstraintMgrMgr and CPropsheetConstraintMgr
//  -Added MSG_MAP in templates to support chaining in deriving class and a single
//   macro to use for both windows and propsheets, i.e. CHAIN_MSG_MAP.
//  -Added hit testing for the grow handle per Katy Mulvey [ktm@ormec.com] in
//   http://www.windev.org/archives/mar98/msg00417.html.
//
// 1/27/00
//  -Released by Horst Veith [hveith@intercom.at]
/////////////////////////////////////////////////////////////////////////////
// Known issues:
//  -If there are no constraints and their is a grow handle, it will leave a trail.
//  -Property sheets don't resize.
//  -Property sheets need to be expanded to allow a place for the gripper.

#ifndef _INC_ATLCONSTRAINTMSG
#define _INC_ATLCONSTRAINTMSG

#pragma once

#ifndef _WINDOWS_
#include <windows.h>
#endif

#ifndef _INC_COMMCTRL
#include <commctrl.h>
#endif

#ifndef __cplusplus
	#error ATL requires C++ compilation (use a .cpp suffix)
#endif

//lint -e534 -e1924

namespace WTL
{

#define BEGIN_CONSTRAINT_MAP(_class) \
public: \
    void AddConstraints() \
    {

#define CONSTRAINT_ENTRY(_nID, _cHor, _cVer) \
        AddConstraint(_nID, _cHor, _cVer);

#define CONSTRAINT_ENTRY_EX(_nID, _cHor, _cVer, _bInvalidateChilds) \
        AddConstraint(_nID, _cHor, _cVer, _bInvalidateChilds);

#define CONSTRAINT_ENTRY_RECT(_nID, _nLeft, _nTop, _nRight, _nBottom) \
        AddConstraint(_nID, _nLeft, _nTop, _nRight, _nBottom);

#define CONSTRAIN_ENTRY_RECT_EX(_nID, _nLeft, _nTop, _nRight, _nBottom, _bInvalidateChilds) \
        AddConstraint(_nID, _nLeft, _nTop, _nRight, _nBottom, _bInvalidateChilds);

#define END_CONSTRAINT_MAP() \
    }

class CWndConstraintMgrBase
{
public:
    CWndConstraintMgrBase() :
        m_hWndContainer(NULL),
        m_bDefer(false),
        m_bDrawGripper(true),
        m_pControls(NULL),
        m_nControls(0)
    { 
        ConstraintsUnInit();
    }

    BEGIN_MSG_MAP(CWndConstraintMgrBase)
        MESSAGE_HANDLER(WM_PAINT, OnPaint)
        MESSAGE_HANDLER(WM_GETMINMAXINFO, OnGetMinMaxInfo)
        MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
        MESSAGE_HANDLER(WM_NCHITTEST, OnNcHitTest)
    END_MSG_MAP()    

    LRESULT OnPaint(UINT, WPARAM, LPARAM, BOOL& bHandled)
    {
        bHandled = FALSE;
        DrawGrowHandle();
        return 0;
    }

    LRESULT OnGetMinMaxInfo(UINT, WPARAM, LPARAM lParam, BOOL& bHandled)
    {
        bHandled = FALSE;

	    if( m_szMin.cx )
	    {
		    ((LPMINMAXINFO)lParam)->ptMinTrackSize.x = m_szMin.cx;
		    ((LPMINMAXINFO)lParam)->ptMinTrackSize.y = m_szMin.cy;

            bHandled = TRUE;
	    }

        return 0;
    }

    LRESULT OnDestroy(UINT, WPARAM, LPARAM lParam, BOOL& bHandled)
    {
        bHandled = FALSE;
        ConstraintsUnInit();
        return 0;
    }

    LRESULT OnNcHitTest(UINT, WPARAM, LPARAM lParam, BOOL& bHandled)
    {
        WORD    xPosScreen = LOWORD(lParam);
        WORD    yPosScreen = HIWORD(lParam);
        
        bHandled = FALSE;
        if (!m_bDrawGripper) return 0;
        
        RECT    rectClient; ::GetClientRect(m_hWndContainer, &rectClient);
        RECT    rect = {rectClient.right-16, rectClient.bottom-16,  rectClient.right, rectClient.bottom};
        
        POINT   pt = { xPosScreen, yPosScreen };
        ScreenToClient(m_hWndContainer, &pt);
        
        if( PtInRect(&rect, pt) )
        {
            bHandled = TRUE;
            return HTBOTTOMRIGHT;
        }
        
        return 0;
    }

    void ConstraintsInit(HWND hWnd, bool bDrawGripper = true, bool bDefer = true, int nWidth = 0, int nHeight = 0)
    {
        m_hWndContainer = hWnd;
        if (::IsWindow(m_hWndContainer))
        {
            if (nWidth && nHeight)
            {
                m_szBase.cx = m_szMin.cx = nWidth;
                m_szBase.cy = m_szMin.cy = nHeight;
            }
            else
            {
                RECT	rc;
                ::GetClientRect(m_hWndContainer, &rc);	
                m_szBase.cx = rc.right - rc.left;
                m_szBase.cy = rc.bottom - rc.top;
                ::GetWindowRect(m_hWndContainer, &rc);	
                m_szMin.cx = rc.right - rc.left;
                m_szMin.cy = rc.bottom - rc.top;
            }
            m_bDefer = bDefer;
            m_bDrawGripper = bDrawGripper;
        }
    }

    void ConstraintsInitPropSheet(HWND hWnd, bool bDrawGripper = true, bool bDefer = true, int nWidth = 0, int nHeight = 0)
    {
/* TODO: Need a good place for this

        // Make room for gripper
        if( m_bDrawGripper )
        {
            RECT    rect; GetClientRect(hWnd, &rect);
            rect.right += 16;
            rect.bottom += 16;
            MoveWindow(hWnd, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, TRUE);
        }
*/
        ConstraintsInit(hWnd, bDrawGripper, bDefer, nWidth, nHeight);
        
        AddConstraint(IDOK, Shift, Shift);
        AddConstraint(IDCANCEL, Shift, Shift);
        AddConstraint(IDSHEET, Expand, Expand);	
        AddConstraint(IDAPPLY, Shift);
        AddConstraint(IDPROPHELP, Shift);

        // Make sheet resizeable
        DWORD   style = GetWindowLong(hWnd, GWL_STYLE);
        if ((style & DS_MODALFRAME) == DS_MODALFRAME)
        {
            style &= ~DS_MODALFRAME;
            style |= WS_THICKFRAME;
            style |= WS_MAXIMIZEBOX;
            SetWindowLong(hWnd, GWL_STYLE, style);
        }
        
        DWORD   exstyle = GetWindowLong(hWnd, GWL_EXSTYLE);
        if ((exstyle & WS_EX_DLGMODALFRAME) == WS_EX_DLGMODALFRAME)
        {
            exstyle &= ~WS_EX_DLGMODALFRAME;
            SetWindowLong(hWnd, GWL_EXSTYLE, exstyle);
        }
        else
        {
            exstyle |= WS_EX_CLIENTEDGE;
            SetWindowLong(hWnd, GWL_EXSTYLE, exstyle);
        }
    }
      
    void ConstraintsUnInit()
    {
        m_szBase.cx = m_szBase.cy = m_szMin.cx = m_szMin.cy = 0;; 
        XObject* p = m_pControls;
        while (p)
        {
            XObject* p2 = p->m_pNext;
            delete p;
            p = p2;
        }
        m_pControls = NULL;
        m_nControls = 0;
    }
    
    typedef enum
    {
        Fixed = 0,
        Shift,
        Expand
    } DefaultConstraint;
    
    // No need for an empty CONSTRAINT_MAP or any CONSTRAINT_MAP at all.
    // This is handy for property sheets that just want the pages to resize.
    void AddConstraints() {}

    void AddConstraint(UINT nID, DefaultConstraint cHor = Expand, DefaultConstraint cVer = Shift, bool bInvalidateChilds = false)
    {
        AddConstraint(nID, (cHor == Shift ? 100 : 0), (cVer == Shift ? 100 : 0), 
                           (cHor == Fixed ? 0 : 100), (cVer == Fixed ? 0 : 100), bInvalidateChilds);
    }
    
    void AddConstraint(HWND hWnd, DefaultConstraint cHor = Expand, DefaultConstraint cVer = Shift, bool bInvalidateChilds = false)
    {
        AddConstraint(hWnd, (cHor == Shift ? 100 : 0), (cVer == Shift ? 100 : 0), 
                            (cHor == Fixed ? 0 : 100), (cVer == Fixed ? 0 : 100), bInvalidateChilds);
    }
    
    void AddConstraint(UINT nID, UINT nLeft, UINT nTop, UINT nRight, UINT nBottom, bool bInvalidateChilds = false)
    {
        RECT	rc = { min(max(0, nLeft), 100), min(max(0, nTop), 100),
            min(max(0, nRight), 100),min(max(0, nBottom), 100)};
        
        XObject* p = new XObject(nID, NULL, rc, bInvalidateChilds, m_pControls);
        m_pControls = p;
    }
    
    void AddConstraint(HWND hWnd, UINT nLeft, UINT nTop, UINT nRight, UINT nBottom, bool bInvalidateChilds = false)
    {
        RECT	rc = { min(max(0, nLeft), 100), min(max(0, nTop), 100),
            min(max(0, nRight), 100),min(max(0, nBottom), 100)};
        
        XObject* p = new XObject(0, hWnd, rc, bInvalidateChilds, m_pControls);
        m_pControls = p;
    }
    
    void Resize(int nClientWidth, int nClientHeight)
    {
        if (!::IsWindow(m_hWndContainer)) return;
        
        HDWP  hDefer = m_bDefer ? ::BeginDeferWindowPos(m_nControls) : NULL;
        
        if( m_pControls )
        {
            int nDeltaClientWidth = max(nClientWidth - m_szBase.cx, 0);
            int nDeltaClientHeight = max(nClientHeight - m_szBase.cy, 0);
            
            XObject* p = m_pControls;
            while (p)
            {
                p->Resize(m_hWndContainer, nDeltaClientWidth, nDeltaClientHeight, hDefer);
                p = p->m_pNext;
            }
        }
        
        if (m_bDrawGripper)
        {	
            // NOTE: This causes the flicker, but w/o this call,
            //       the grow handle leaves trails.
            RECT    rect = {m_szBase.cx-16, m_szBase.cy-16,  nClientWidth, nClientHeight};
            ::InvalidateRect(m_hWndContainer, &rect, FALSE);
        }
        
        if (hDefer) ::EndDeferWindowPos(hDefer);
    }
    
    void ResizeActivePage()
    {
        if (!IsWindow(m_hWndContainer)) return;
        
        HWND hTab = (HWND)SendMessage(m_hWndContainer, PSM_GETTABCONTROL, 0, 0L);
        if (!hTab) return;
        
        RECT rectTabControl;
        GetWindowRect(hTab, &rectTabControl);
        ::ScreenToClient(m_hWndContainer, (LPPOINT)&rectTabControl);
        ::ScreenToClient(m_hWndContainer, ((LPPOINT)&rectTabControl)+1);
        
        RECT rectTab;
        if (SendMessage(hTab, TCM_GETITEMRECT, SendMessage(hTab, TCM_GETCURSEL, 0, 0L), (LPARAM)&rectTab))
        {
            HWND hPage = (HWND)SendMessage(m_hWndContainer, PSM_GETCURRENTPAGEHWND, 0, 0L);
            if (!hPage) return;
            
            rectTabControl.top += rectTab.bottom;
            
            SetWindowPos(hPage, NULL, rectTabControl.left+4, rectTabControl.top+2,
                         rectTabControl.right-rectTabControl.left-8,
                         rectTabControl.bottom-rectTabControl.top-5,
                         SWP_NOZORDER|SWP_NOACTIVATE);
        }
    }
    
    void ResizeParentToFit()
    {
        if (!m_hWndContainer) return;
        RECT	rcWindow, rcClient;
        
        GetWindowRect(GetParent(m_hWndContainer), &rcWindow);
        GetClientRect(GetParent(m_hWndContainer), &rcClient);
        rcWindow.right -= rcWindow.left + rcClient.right; 
        rcWindow.bottom -= rcWindow.top + rcClient.bottom;
        SetWindowPos(GetParent(m_hWndContainer), NULL, 0, 0,
                     rcWindow.right + m_szBase.cx, rcWindow.bottom + m_szBase.cy, SWP_NOMOVE|SWP_NOZORDER|SWP_NOACTIVATE); 
    }
    
protected:
    enum { IDSHEET = 0x3020, IDAPPLY, IDPROPHELP, IDWIZBACK, IDWIZNEXT, IDWIZFINISH, IDWIZLINE };
        
    void DrawGrowHandle()
    {
        if (!m_bDrawGripper) return;
        
        RECT    rectClient; ::GetClientRect(m_hWndContainer, &rectClient);
        RECT    rect = {rectClient.right-16, rectClient.bottom-16,  rectClient.right, rectClient.bottom};
        
        HDC hdc = ::GetDC(m_hWndContainer);
        ::DrawFrameControl(hdc, &rect, DFC_SCROLL, DFCS_SCROLLSIZEGRIP);
        ::ReleaseDC(m_hWndContainer, hdc);
    }
    
    class XObject
    {
        friend class CWndConstraintMgrBase;
    protected:
        XObject(UINT nID, HWND hWnd, RECT& rcConst, bool bInvalidateChilds, XObject* pNext) :
            m_nID(nID),	
            m_hWnd(hWnd),
            m_bInvalidateChilds(bInvalidateChilds),
            m_pNext(pNext)
        {
            m_rcConst.left = rcConst.left * 100;
            m_rcConst.top = rcConst.top * 100;
            m_rcConst.right = rcConst.right * 100;
            m_rcConst.bottom = rcConst.bottom * 100;
        }			
             
        void Resize(HWND hParent, int nWidth, int nHeight, HDWP& hDefer)
        {
            if (!m_hWnd || !m_nID)
            {
                m_hWnd = GetDlgItem(hParent, m_nID); 
                if (!::IsWindow(m_hWnd)) return;
                GetWindowRect(m_hWnd, &m_rcBase);
                ::ScreenToClient(hParent, (LPPOINT)&m_rcBase);
                ::ScreenToClient(hParent, ((LPPOINT)&m_rcBase)+1);
                m_nID = 1;
            }
            else if (!::IsWindow(m_hWnd)) return;
            
            RECT rc = { m_rcBase.left + (int)(m_rcConst.left*nWidth/10000),
                m_rcBase.top + (int)(m_rcConst.top*nHeight/10000), 
                m_rcBase.right + (int)(m_rcConst.right*nWidth/10000),
                m_rcBase.bottom + (int)(m_rcConst.bottom*nHeight/10000)};       
            
            if (hDefer)
                hDefer = ::DeferWindowPos(hDefer, m_hWnd, NULL, rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top,
                                          SWP_NOACTIVATE|SWP_NOZORDER); 
            else
                ::SetWindowPos(m_hWnd, NULL, rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top, SWP_NOACTIVATE|SWP_NOZORDER);
            
            if (m_bInvalidateChilds)
            {
                for (HWND hWndChild = GetTopWindow(m_hWnd); hWndChild; hWndChild = GetNextWindow(hWndChild, GW_HWNDNEXT))
                    if (hWndChild) ::InvalidateRect(hWndChild, NULL, true);
            }
        }
        
        HWND        m_hWnd;
        UINT        m_nID;
        RECT        m_rcBase;   // Original-Position und Gr��e des Objekts
        RECT        m_rcConst;			
        XObject*    m_pNext;
        bool        m_bInvalidateChilds;
    };

    HWND        m_hWndContainer;
    SIZE        m_szBase;							
    SIZE        m_szMin;
    bool        m_bDefer;
    bool        m_bDrawGripper;
    XObject*    m_pControls;		
    UINT        m_nControls;
};

template <typename Deriving, bool bDrawGripper = true, bool bDefer = true, int nWidth = 0, int nHeight = 0>
class CWndConstraintMgr : public CWndConstraintMgrBase
{
public:
    BEGIN_MSG_MAP(CWndConstraintMgr)
        CHAIN_MSG_MAP(CWndConstraintMgrBase)
        MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
        MESSAGE_HANDLER(WM_SIZE, OnSize)
    END_MSG_MAP()

    LRESULT OnInitDialog(UINT, WPARAM, LPARAM, BOOL& bHandled)
    {
        bHandled = FALSE;
        ConstraintsInit(static_cast<Deriving*>(this)->m_hWnd, bDrawGripper, bDefer, nWidth, nHeight);
        static_cast<Deriving*>(this)->AddConstraints();
        return 0;
    }
    
    LRESULT OnSize(UINT, WPARAM, LPARAM lParam, BOOL& bHandled)
    {
        Resize((WORD)(lParam), ((WORD)(((DWORD)(lParam) >> 16) & 0xFFFF)));
        return 0;
    }
};

template <typename Deriving,  bool bDrawGripper = true, bool bDefer = true, int nWidth = 0, int nHeight = 0>
class CPropertySheetConstraintMgr : public CWndConstraintMgrBase
{
public:
    CPropertySheetConstraintMgr() : m_bFirstSize(true)
    {
    }

    BEGIN_MSG_MAP(CPropertySheetConstraintMgr)
        CHAIN_MSG_MAP(CWndConstraintMgrBase)
        NOTIFY_HANDLER(IDSHEET, TCN_SELCHANGE, OnSelChange)
        MESSAGE_HANDLER(WM_SIZE, OnSize)
    END_MSG_MAP()
    
    LRESULT OnSelChange(int idCtrl, LPNMHDR pnmh, BOOL& bHandled)
    {
        ResizeActivePage();
        return 0;
    }

    LRESULT OnSize(UINT, WPARAM, LPARAM lParam, BOOL& bHandled)
    {
        WORD    nWidth = LOWORD(lParam);  // width of client area 
        WORD    nHeight = HIWORD(lParam); // height of client area 
        ATLTRACE("OnSize -- nWidth= %d,  nHeight= %d\n", nWidth, nHeight);
 
        // Can't trust WTL's property sheet to give us WM_CREATE or WM_INITDIALOG
        if( m_bFirstSize )
        {
            Deriving*   pThis = static_cast<Deriving*>(this);

            ConstraintsInitPropSheet(pThis->m_hWnd, bDrawGripper, bDefer, nWidth, nHeight);
            pThis->AddConstraints();

            m_bFirstSize = false;
        }

        if(m_szMin.cx)
        {
            Resize((WORD)(lParam), ((WORD)(((DWORD)(lParam) >> 16) & 0xFFFF)));
            ResizeActivePage();
        }

        return 0;
    }

private:
    bool    m_bFirstSize:1;
};

}; //namespace WTL

#ifndef _WTL_NOUSE_NAMESPACE
using namespace WTL;
#endif

#endif // _INC_ATLCONSTRAINTMSG
