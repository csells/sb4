//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by dlgresize.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_PAGE1                       102
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDD_PAGE2                       130
#define IDC_ASSIGN_LIST                 245
#define IDC_AVAIL_LIST                  257
#define IDC_ADD                         258
#define IDC_REMOVE                      259
#define IDC_GROUP                       260
#define IDC_UP                          261
#define IDC_DOWN                        262
#define IDC_GROUPTEXT                   263
#define IDC_AVAIL_TEXT                  264
#define IDC_ASSIGN_TEXT                 265
#define IDC_ADDALL                      266
#define IDC_BEAM1                       279
#define IDC_BEAM2                       280
#define IDC_TESTPROPSHEET               1000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
