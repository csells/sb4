// maindlg.h : interface of the CMainDlg class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINDLG_H__4176E68E_A056_41AE_9629_8DBD36B83676__INCLUDED_)
#define AFX_MAINDLG_H__4176E68E_A056_41AE_9629_8DBD36B83676__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "atlconstraintmgr.h"
#include <afxres.h>
#include "resource.h"

class CMainDlg :
        public CDialogImpl<CMainDlg>,
		public CWndConstraintMgr<CMainDlg>  // DONE
{
public:
	enum { IDD = IDD_MAINDLG };

	BEGIN_MSG_MAP(CMainDlg)
        CHAIN_MSG_MAP(CWndConstraintMgr<CMainDlg>)  // DONE

		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
		COMMAND_ID_HANDLER(ID_APP_ABOUT, OnAppAbout)
		COMMAND_ID_HANDLER(IDOK, OnOK)
		COMMAND_ID_HANDLER(IDCANCEL, OnCancel)
        COMMAND_ID_HANDLER(IDC_TESTPROPSHEET, OnTestPropertySheet)
	END_MSG_MAP()

    // DONE
    BEGIN_CONSTRAINT_MAP(CMainDlg)
    	CONSTRAINT_ENTRY(IDC_GROUPTEXT, Fixed, Fixed)
    	CONSTRAINT_ENTRY(IDC_GROUP, Expand, Fixed)
    	CONSTRAINT_ENTRY(IDC_BEAM1, Expand, Fixed)

		CONSTRAINT_ENTRY_RECT(IDC_AVAIL_LIST, 0, 0, 50, 100)

		CONSTRAINT_ENTRY_RECT(IDC_ADD, 50, 0, 50, 0)
		CONSTRAINT_ENTRY_RECT(IDC_REMOVE, 50, 0, 50, 0)
		CONSTRAINT_ENTRY_RECT(IDC_ADDALL, 50, 0, 50, 0)
		CONSTRAINT_ENTRY_RECT(IDC_ASSIGN_LIST, 50, 0, 100, 100)
		CONSTRAINT_ENTRY_RECT(IDC_ASSIGN_TEXT, 50, 0, 50, 0)
		CONSTRAINT_ENTRY_RECT(IDC_UP, 100, 100, 100, 100)
		CONSTRAINT_ENTRY_RECT(IDC_DOWN, 100, 100, 100, 100)

    	CONSTRAINT_ENTRY(IDC_BEAM2, Expand, Shift)

    	CONSTRAINT_ENTRY(IDOK,  Shift, Shift)
    	CONSTRAINT_ENTRY(IDCANCEL,  Shift, Shift)
    	CONSTRAINT_ENTRY(ID_APP_ABOUT,  Shift, Shift)
    END_CONSTRAINT_MAP()

	LRESULT OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		// center the dialog on the screen
		CenterWindow();

		// set icons
		HICON hIcon = (HICON)::LoadImage(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_MAINFRAME), 
			IMAGE_ICON, ::GetSystemMetrics(SM_CXICON), ::GetSystemMetrics(SM_CYICON), LR_DEFAULTCOLOR);
		SetIcon(hIcon, TRUE);
		HICON hIconSmall = (HICON)::LoadImage(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_MAINFRAME), 
			IMAGE_ICON, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON), LR_DEFAULTCOLOR);
		SetIcon(hIconSmall, FALSE);

#ifdef TESTPROPSHEET
        ::ShowWindow(GetDlgItem(IDC_TESTPROPSHEET), SW_SHOW);
#endif

		return TRUE;
	}

	LRESULT OnTestPropertySheet(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
        CMyPropertySheet    sheet;
        sheet.DoModal();
		return 0;
	}

	LRESULT OnAppAbout(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		CAboutDlg dlg;
		dlg.DoModal();
		return 0;
	}

	LRESULT OnOK(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		// TODO: Add validation code 
		CloseDialog(wID);
		return 0;
	}

	LRESULT OnCancel(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		CloseDialog(wID);
		return 0;
	}

	void CloseDialog(int nVal)
	{
		DestroyWindow();
		::PostQuitMessage(nVal);
	}
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINDLG_H__4176E68E_A056_41AE_9629_8DBD36B83676__INCLUDED_)
