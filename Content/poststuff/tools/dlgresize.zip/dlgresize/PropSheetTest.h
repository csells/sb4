// PropSheetTest.h

#pragma once
#ifndef INC_PROPSHEETTEST
#define INC_PROPSHEETTEST

#define TESTPROPSHEET
#ifdef TESTPROPSHEET

#include "atlapp.h"    // NOTE: Requires WTL
#include "atldlgs.h"

// Avoid some compiler warnings that arise from only half-way using WTL.
#undef ID_VIEW_TOOLBAR
#undef ID_VIEW_STATUS_BAR

#include "atlconstraintmgr.h"

class CPageOne : public CPropertyPageImpl<CPageOne>
{
public:
	enum { IDD = IDD_PAGE1 };

	BEGIN_MSG_MAP(CPageOne)
		CHAIN_MSG_MAP(CPropertyPageImpl<CPageOne>)
	END_MSG_MAP()
};

class CPageTwo : public CPropertyPageImpl<CPageTwo>
{
public:
	enum { IDD = IDD_PAGE2 };

	BEGIN_MSG_MAP(CPageTwo)
		CHAIN_MSG_MAP(CPropertyPageImpl<CPageTwo>)
	END_MSG_MAP()
};

class CMyPropertySheet :
    public CPropertySheetImpl<CMyPropertySheet>,
    public CPropertySheetConstraintMgr<CMyPropertySheet> // DONE
{
public:
	CPageOne m_page1;
	CPageTwo m_page2;

	CMyPropertySheet()
	{
		AddPage(m_page1);
		AddPage(m_page2);
	}

	BEGIN_MSG_MAP(CMyPropertySheet)
        CHAIN_MSG_MAP(CPropertySheetConstraintMgr<CMyPropertySheet>) // DONE

		CHAIN_MSG_MAP(CPropertySheetImpl<CMyPropertySheet>)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	END_MSG_MAP()

	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		ModifyStyle(0, WS_THICKFRAME);
		return 1;
	}
};

#endif  // TESTPROPSHEET
#endif  // INC_PROPSHEETTEST
