// dlgresize.cpp : main source file for dlgresize.exe
//

#include "stdafx.h"
#include "resource.h"

#include "PropSheetTest.h"
#include "aboutdlg.h"
#include "maindlg.h"

CComModule _Module;

int Run(LPTSTR /*lpstrCmdLine*/ = NULL, int nCmdShow = SW_SHOWDEFAULT)
{
	CMainDlg dlgMain;

	if(dlgMain.Create(NULL) == NULL)
	{
		ATLTRACE(_T("Main dialog creation failed!\n"));
		return 0;
	}

	dlgMain.ShowWindow(nCmdShow);

    MSG msg;
    while( GetMessage(&msg, 0, 0, 0) )
    {
        if( !dlgMain.IsDialogMessage(&msg) )
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

	return msg.wParam;
}

int WINAPI _tWinMain(HINSTANCE hInstance, HINSTANCE /*hPrevInstance*/, LPTSTR lpstrCmdLine, int nCmdShow)
{
#if (_WIN32_IE >= 0x0300)
	INITCOMMONCONTROLSEX iccx;
	iccx.dwSize = sizeof(iccx);
	iccx.dwICC = ICC_COOL_CLASSES | ICC_BAR_CLASSES;
	BOOL bRet = ::InitCommonControlsEx(&iccx);
	bRet;
	ATLASSERT(bRet);
#else
	::InitCommonControls();
#endif

	_Module.Init(NULL, hInstance);

	int nRet = Run(lpstrCmdLine, nCmdShow);

	_Module.Term();
	return nRet;
}
