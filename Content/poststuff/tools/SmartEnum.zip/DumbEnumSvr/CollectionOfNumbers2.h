// CollectionOfNumbers2.h : Declaration of the CCollectionOfNumbers2

#ifndef __COLLECTIONOFNUMBERS2_H_
#define __COLLECTIONOFNUMBERS2_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CCollectionOfNumbers2
class ATL_NO_VTABLE CCollectionOfNumbers2 : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CCollectionOfNumbers2, &CLSID_CollectionOfNumbers2>,
	public IDispatchImpl<ICollectionOfNumbers2, &IID_ICollectionOfNumbers2, &LIBID_DUMBENUMSVRLib>
{
public:
	CCollectionOfNumbers2() : m_cNumbers(100)
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_COLLECTIONOFNUMBERS2)
DECLARE_NOT_AGGREGATABLE(CCollectionOfNumbers2)

BEGIN_COM_MAP(CCollectionOfNumbers2)
	COM_INTERFACE_ENTRY(ICollectionOfNumbers2)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// ICollectionOfNumbers2
public:
	STDMETHOD(get__NewEnum)(/*[out, retval]*/ IUnknown* *pVal);
	STDMETHOD(get_CountOfNumbers)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_CountOfNumbers)(/*[in]*/ long newVal);

private:
	long m_cNumbers;
};

#endif //__COLLECTIONOFNUMBERS2_H_
