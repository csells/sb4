// CollectionOfNumbers.cpp : Implementation of CCollectionOfNumbers
#include "stdafx.h"
#include "DumbEnumSvr.h"
#include "CollectionOfNumbers.h"

/////////////////////////////////////////////////////////////////////////////
// CCollectionOfNumbers

STDMETHODIMP CCollectionOfNumbers::get_CountOfNumbers(long *pVal)
{
    *pVal = m_cNumbers;
	return S_OK;
}

STDMETHODIMP CCollectionOfNumbers::put_CountOfNumbers(long newVal)
{
    m_cNumbers = newVal;
	return S_OK;
}

STDMETHODIMP CCollectionOfNumbers::get__NewEnum(IUnknown **pVal)
{
    *pVal = 0;

    VARIANT*    rgv = new VARIANT[m_cNumbers];
    if( !rgv ) return E_OUTOFMEMORY;

    long    n = 0;
    for( VARIANT* pv = &rgv[0]; pv != &rgv[m_cNumbers]; ++pv )
    {
        pv->vt = VT_I4;
        pv->lVal = n++;
    }

    typedef CComEnum< IEnumVARIANT, &IID_IEnumVARIANT, VARIANT, _Copy<VARIANT> > CComEnumVariant;
    CComObject<CComEnumVariant>*    pev = 0;
    HRESULT hr = pev->CreateInstance(&pev);
    if( SUCCEEDED(hr) )
    {
        pev->AddRef();
        hr = pev->Init(&rgv[0], &rgv[m_cNumbers], 0, AtlFlagTakeOwnership);
        if( SUCCEEDED(hr) ) pev->QueryInterface(pVal);
        pev->Release();
    }

    return hr;
}
