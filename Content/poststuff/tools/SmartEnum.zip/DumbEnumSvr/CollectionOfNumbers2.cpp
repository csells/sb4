// CollectionOfNumbers2.cpp : Implementation of CCollectionOfNumbers2
// Copyright (c) 1998, Chris Sells. 
// All rights reserved. No warrenties extended. Use at your own risk. 
// Comments to csells@sellsbrothers.com. 

#include "stdafx.h"
#include "DumbEnumSvr.h"
#include "CollectionOfNumbers2.h"

#include "..\SmartEnumSvr.h"
#include "..\SmartEnumSvr_i.c"
#include "..\UseSmartEnum.h"

typedef CComEnum< IEnumVARIANT, &IID_IEnumVARIANT, VARIANT, _Copy<VARIANT> > CComEnumVariant;

class CSmartProxiedEnumVARIANT :
    public CComEnumVariant,
    public IMarshalForSmartEnumImpl<CSmartProxiedEnumVARIANT, 1024>
{
public:
BEGIN_COM_MAP(CSmartProxiedEnumVARIANT)
    COM_INTERFACE_ENTRY(IMarshal)
    COM_INTERFACE_ENTRY_CHAIN(CComEnumVariant)
END_COM_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CCollectionOfNumbers2

STDMETHODIMP CCollectionOfNumbers2::get_CountOfNumbers(long *pVal)
{
    *pVal = m_cNumbers;
	return S_OK;
}

STDMETHODIMP CCollectionOfNumbers2::put_CountOfNumbers(long newVal)
{
    m_cNumbers = newVal;
	return S_OK;
}

STDMETHODIMP CCollectionOfNumbers2::get__NewEnum(IUnknown **pVal)
{
    *pVal = 0;

    VARIANT*    rgv = new VARIANT[m_cNumbers];
    if( !rgv ) return E_OUTOFMEMORY;

    long    n = 0;
    for( VARIANT* pv = &rgv[0]; pv != &rgv[m_cNumbers]; ++pv )
    {
        pv->vt = VT_I4;
        pv->lVal = n++;
    }

    CComObject<CSmartProxiedEnumVARIANT>*   pev = 0;
    HRESULT hr = pev->CreateInstance(&pev);
    if( SUCCEEDED(hr) )
    {
        pev->AddRef();
        hr = pev->Init(&rgv[0], &rgv[m_cNumbers], 0, AtlFlagTakeOwnership);
        if( SUCCEEDED(hr) ) pev->QueryInterface(pVal);
        pev->Release();
    }

    return hr;
}
