// CollectionOfNumbers.h : Declaration of the CCollectionOfNumbers

#ifndef __COLLECTIONOFNUMBERS_H_
#define __COLLECTIONOFNUMBERS_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CCollectionOfNumbers
class ATL_NO_VTABLE CCollectionOfNumbers : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CCollectionOfNumbers, &CLSID_CollectionOfNumbers>,
	public IDispatchImpl<ICollectionOfNumbers, &IID_ICollectionOfNumbers, &LIBID_DUMBENUMSVRLib>
{
public:
    CCollectionOfNumbers() : m_cNumbers(100)
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_COLLECTIONOFNUMBERS)
DECLARE_NOT_AGGREGATABLE(CCollectionOfNumbers)

BEGIN_COM_MAP(CCollectionOfNumbers)
	COM_INTERFACE_ENTRY(ICollectionOfNumbers)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// ICollectionOfNumbers
public:
	STDMETHOD(get__NewEnum)(/*[out, retval]*/ IUnknown* *pVal);
	STDMETHOD(get_CountOfNumbers)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_CountOfNumbers)(/*[in]*/ long newVal);

private:
	long m_cNumbers;
};

#endif //__COLLECTIONOFNUMBERS_H_
