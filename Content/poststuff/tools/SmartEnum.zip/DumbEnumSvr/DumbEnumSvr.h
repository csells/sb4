/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Fri Nov 27 11:05:38 1998
 */
/* Compiler settings for D:\Project\mine\SmartEnumSvr\DumbEnumSvr\DumbEnumSvr.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __DumbEnumSvr_h__
#define __DumbEnumSvr_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __ICollectionOfNumbers_FWD_DEFINED__
#define __ICollectionOfNumbers_FWD_DEFINED__
typedef interface ICollectionOfNumbers ICollectionOfNumbers;
#endif 	/* __ICollectionOfNumbers_FWD_DEFINED__ */


#ifndef __ICollectionOfNumbers2_FWD_DEFINED__
#define __ICollectionOfNumbers2_FWD_DEFINED__
typedef interface ICollectionOfNumbers2 ICollectionOfNumbers2;
#endif 	/* __ICollectionOfNumbers2_FWD_DEFINED__ */


#ifndef __CollectionOfNumbers_FWD_DEFINED__
#define __CollectionOfNumbers_FWD_DEFINED__

#ifdef __cplusplus
typedef class CollectionOfNumbers CollectionOfNumbers;
#else
typedef struct CollectionOfNumbers CollectionOfNumbers;
#endif /* __cplusplus */

#endif 	/* __CollectionOfNumbers_FWD_DEFINED__ */


#ifndef __CollectionOfNumbers2_FWD_DEFINED__
#define __CollectionOfNumbers2_FWD_DEFINED__

#ifdef __cplusplus
typedef class CollectionOfNumbers2 CollectionOfNumbers2;
#else
typedef struct CollectionOfNumbers2 CollectionOfNumbers2;
#endif /* __cplusplus */

#endif 	/* __CollectionOfNumbers2_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __ICollectionOfNumbers_INTERFACE_DEFINED__
#define __ICollectionOfNumbers_INTERFACE_DEFINED__

/* interface ICollectionOfNumbers */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ICollectionOfNumbers;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("B6175094-83D4-11D2-987D-00600823CFFB")
    ICollectionOfNumbers : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_CountOfNumbers( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_CountOfNumbers( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get__NewEnum( 
            /* [retval][out] */ IUnknown __RPC_FAR *__RPC_FAR *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ICollectionOfNumbersVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ICollectionOfNumbers __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ICollectionOfNumbers __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ICollectionOfNumbers __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ICollectionOfNumbers __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ICollectionOfNumbers __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ICollectionOfNumbers __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ICollectionOfNumbers __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_CountOfNumbers )( 
            ICollectionOfNumbers __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_CountOfNumbers )( 
            ICollectionOfNumbers __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get__NewEnum )( 
            ICollectionOfNumbers __RPC_FAR * This,
            /* [retval][out] */ IUnknown __RPC_FAR *__RPC_FAR *pVal);
        
        END_INTERFACE
    } ICollectionOfNumbersVtbl;

    interface ICollectionOfNumbers
    {
        CONST_VTBL struct ICollectionOfNumbersVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ICollectionOfNumbers_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICollectionOfNumbers_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICollectionOfNumbers_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ICollectionOfNumbers_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ICollectionOfNumbers_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ICollectionOfNumbers_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ICollectionOfNumbers_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ICollectionOfNumbers_get_CountOfNumbers(This,pVal)	\
    (This)->lpVtbl -> get_CountOfNumbers(This,pVal)

#define ICollectionOfNumbers_put_CountOfNumbers(This,newVal)	\
    (This)->lpVtbl -> put_CountOfNumbers(This,newVal)

#define ICollectionOfNumbers_get__NewEnum(This,pVal)	\
    (This)->lpVtbl -> get__NewEnum(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ICollectionOfNumbers_get_CountOfNumbers_Proxy( 
    ICollectionOfNumbers __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ICollectionOfNumbers_get_CountOfNumbers_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ICollectionOfNumbers_put_CountOfNumbers_Proxy( 
    ICollectionOfNumbers __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ICollectionOfNumbers_put_CountOfNumbers_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ICollectionOfNumbers_get__NewEnum_Proxy( 
    ICollectionOfNumbers __RPC_FAR * This,
    /* [retval][out] */ IUnknown __RPC_FAR *__RPC_FAR *pVal);


void __RPC_STUB ICollectionOfNumbers_get__NewEnum_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ICollectionOfNumbers_INTERFACE_DEFINED__ */


#ifndef __ICollectionOfNumbers2_INTERFACE_DEFINED__
#define __ICollectionOfNumbers2_INTERFACE_DEFINED__

/* interface ICollectionOfNumbers2 */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ICollectionOfNumbers2;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("B6175097-83D4-11D2-987D-00600823CFFB")
    ICollectionOfNumbers2 : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_CountOfNumbers( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_CountOfNumbers( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get__NewEnum( 
            /* [retval][out] */ IUnknown __RPC_FAR *__RPC_FAR *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ICollectionOfNumbers2Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ICollectionOfNumbers2 __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ICollectionOfNumbers2 __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ICollectionOfNumbers2 __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ICollectionOfNumbers2 __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ICollectionOfNumbers2 __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ICollectionOfNumbers2 __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ICollectionOfNumbers2 __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_CountOfNumbers )( 
            ICollectionOfNumbers2 __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_CountOfNumbers )( 
            ICollectionOfNumbers2 __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get__NewEnum )( 
            ICollectionOfNumbers2 __RPC_FAR * This,
            /* [retval][out] */ IUnknown __RPC_FAR *__RPC_FAR *pVal);
        
        END_INTERFACE
    } ICollectionOfNumbers2Vtbl;

    interface ICollectionOfNumbers2
    {
        CONST_VTBL struct ICollectionOfNumbers2Vtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ICollectionOfNumbers2_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICollectionOfNumbers2_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICollectionOfNumbers2_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ICollectionOfNumbers2_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ICollectionOfNumbers2_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ICollectionOfNumbers2_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ICollectionOfNumbers2_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ICollectionOfNumbers2_get_CountOfNumbers(This,pVal)	\
    (This)->lpVtbl -> get_CountOfNumbers(This,pVal)

#define ICollectionOfNumbers2_put_CountOfNumbers(This,newVal)	\
    (This)->lpVtbl -> put_CountOfNumbers(This,newVal)

#define ICollectionOfNumbers2_get__NewEnum(This,pVal)	\
    (This)->lpVtbl -> get__NewEnum(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ICollectionOfNumbers2_get_CountOfNumbers_Proxy( 
    ICollectionOfNumbers2 __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ICollectionOfNumbers2_get_CountOfNumbers_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ICollectionOfNumbers2_put_CountOfNumbers_Proxy( 
    ICollectionOfNumbers2 __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ICollectionOfNumbers2_put_CountOfNumbers_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ICollectionOfNumbers2_get__NewEnum_Proxy( 
    ICollectionOfNumbers2 __RPC_FAR * This,
    /* [retval][out] */ IUnknown __RPC_FAR *__RPC_FAR *pVal);


void __RPC_STUB ICollectionOfNumbers2_get__NewEnum_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ICollectionOfNumbers2_INTERFACE_DEFINED__ */



#ifndef __DUMBENUMSVRLib_LIBRARY_DEFINED__
#define __DUMBENUMSVRLib_LIBRARY_DEFINED__

/* library DUMBENUMSVRLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_DUMBENUMSVRLib;

EXTERN_C const CLSID CLSID_CollectionOfNumbers;

#ifdef __cplusplus

class DECLSPEC_UUID("B6175095-83D4-11D2-987D-00600823CFFB")
CollectionOfNumbers;
#endif

EXTERN_C const CLSID CLSID_CollectionOfNumbers2;

#ifdef __cplusplus

class DECLSPEC_UUID("B6175098-83D4-11D2-987D-00600823CFFB")
CollectionOfNumbers2;
#endif
#endif /* __DUMBENUMSVRLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
