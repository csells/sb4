// CollectionBuffer.h : Declaration of the CCollectionBuffer
// Copyright (c) 1998, Chris Sells. 
// All rights reserved. No warrenties extended. Use at your own risk. 
// Comments to csells@sellsbrothers.com. 

#ifndef __COLLECTIONBUFFER_H_
#define __COLLECTIONBUFFER_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CCollectionBuffer
class ATL_NO_VTABLE CCollectionBuffer : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CCollectionBuffer, &CLSID_CollectionBuffer>,
	public IDispatchImpl<ICollectionBuffer, &IID_ICollectionBuffer>
{
public:
    CCollectionBuffer() : m_celt(128)
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_COLLECTIONBUFFER)
DECLARE_NOT_AGGREGATABLE(CCollectionBuffer)

BEGIN_COM_MAP(CCollectionBuffer)
	COM_INTERFACE_ENTRY(ICollectionBuffer)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// ICollectionBuffer
public:
	STDMETHODIMP get_BufferSize(/*[out, retval]*/ long *pVal);
	STDMETHODIMP put_BufferSize(/*[in]*/ long newVal);
	STDMETHODIMP get_Collection(/*[out, retval]*/ IDispatch** pVal);
	STDMETHODIMP put_Collection(/*[in]*/ IDispatch* newVal);
    STDMETHODIMP get__NewEnum(/*[out, retval]*/ IUnknown** ppunkEnum);

private:
    long                m_celt;
    CComDispatchDriver  m_spdispColl;
};

#endif //__COLLECTIONBUFFER_H_
