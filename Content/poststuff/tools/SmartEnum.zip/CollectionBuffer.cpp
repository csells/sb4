// CollectionBuffer.cpp : Implementation of CCollectionBuffer
// Copyright (c) 1998, Chris Sells. 
// All rights reserved. No warrenties extended. Use at your own risk. 
// Comments to csells@sellsbrothers.com. 

#include "stdafx.h"
#include "SmartEnumSvr.h"
#include "CollectionBuffer.h"
#include "SmartEnumVARIANT.h"

/////////////////////////////////////////////////////////////////////////////
// CCollectionBuffer

STDMETHODIMP CCollectionBuffer::put_Collection(IDispatch* pdispColl)
{
    ObjectLock  lock(this);
    m_spdispColl = pdispColl;
    return S_OK;
}

STDMETHODIMP CCollectionBuffer::get_Collection(IDispatch** ppdispColl)
{
    ObjectLock  lock(this);
    if( !ppdispColl ) return E_POINTER;
    if( *ppdispColl = m_spdispColl ) (*ppdispColl)->AddRef();
    return S_OK;
}

STDMETHODIMP CCollectionBuffer::get_BufferSize(long *pVal)
{
    ObjectLock  lock(this);
    if( !pVal ) return E_POINTER;
    *pVal = m_celt;
    return S_OK;
}

STDMETHODIMP CCollectionBuffer::put_BufferSize(long newVal)
{
    ObjectLock  lock(this);
    if( newVal < 1 ) return E_INVALIDARG;
    m_celt = newVal;
	return S_OK;
}

STDMETHODIMP CCollectionBuffer::get__NewEnum(IUnknown** ppunkEnum)
{
    ObjectLock  lock(this);
    if( !m_spdispColl ) return E_UNEXPECTED;
    if( !ppunkEnum ) return E_POINTER;
    *ppunkEnum = 0;

    // Grab a new enum
    CComVariant var;
    HR(m_spdispColl.GetProperty(DISPID_NEWENUM, &var));
    if( var.vt != VT_UNKNOWN && var.vt != VT_DISPATCH ) return E_UNEXPECTED;

    CComQIPtr<IEnumVARIANT> spev = var.punkVal;
    if( !spev ) return E_NOINTERFACE;

    // Create the smart enum
    CComObject<CSmartEnumVARIANT>*  pSmartEnum = 0;
    HR(pSmartEnum->CreateInstance(&pSmartEnum));
    CComPtr<IEnumVARIANT>   punkStable = pSmartEnum;  // Pointer stablization
    HR(pSmartEnum->Construct(spev, m_celt));

    // Return the enumerator to the client
    return punkStable->QueryInterface(ppunkEnum);
}
