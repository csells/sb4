// SmartEnumVARIANT.cpp : Implementation of CSmartEnumVARIANT
// Copyright (c) 1998, Chris Sells. 
// All rights reserved. No warrenties extended. Use at your own risk. 
// Comments to csells@sellsbrothers.com. 

#include "stdafx.h"
#include "SmartEnumSvr.h"
#include "SmartEnumVARIANT.h"

/////////////////////////////////////////////////////////////////////////////
// CSmartEnumVARIANT

CSmartEnumVARIANT::CSmartEnumVARIANT() : m_pvi(0)
{
}

CSmartEnumVARIANT::~CSmartEnumVARIANT()
{
    delete m_pvi;
}

HRESULT CSmartEnumVARIANT::Construct(IEnumVARIANT* pev, ULONG celt)
{
    if( !pev ) return E_INVALIDARG;
    ObjectLock  lock(this);

    m_spevDelegate = pev;
    m_celt = celt;
    m_pvi = new variant_iterator(m_spevDelegate, celt);
    if( !m_pvi ) return E_OUTOFMEMORY;

    return S_OK;
}

// IEnumVARIANT (smartly)

STDMETHODIMP CSmartEnumVARIANT::Next(ULONG celt, VARIANT* rgelt, ULONG* pceltFetched)
{
    ObjectLock  lock(this);
    if( !m_pvi ) return E_UNEXPECTED;

    ULONG               celtFetched = 0;
    variant_iterator&   it = *m_pvi;
    variant_iterator    end;
    while( it != end && celtFetched < celt )
    {
        HR(VariantCopy(rgelt, &*it));
        ++celtFetched;
        ++it;
    }

    if( pceltFetched ) *pceltFetched = celtFetched;
    return (celtFetched == celt ? S_OK : S_FALSE);
}

STDMETHODIMP CSmartEnumVARIANT::Skip(ULONG celt)
{
    ObjectLock  lock(this);
    if( !m_pvi ) return E_UNEXPECTED;
    return (m_pvi->skip(celt) ? S_OK : S_FALSE);
}

STDMETHODIMP CSmartEnumVARIANT::Reset()
{
    ObjectLock  lock(this);
    if( !m_pvi ) return E_UNEXPECTED;
    return (m_pvi->reset() ? S_OK : E_FAIL);
}

STDMETHODIMP CSmartEnumVARIANT::Clone(IEnumVARIANT** ppEnum)
{
    ObjectLock  lock(this);

    // Create the smart enum
    CComObject<CSmartEnumVARIANT>*  pSmartEnum = 0;
    HR(pSmartEnum->CreateInstance(&pSmartEnum));
    CComPtr<IEnumVARIANT>   pevStable = pSmartEnum; // Pointer stablization
    HR(pSmartEnum->Construct(m_spevDelegate, m_celt));

    // Return the enumerator to the client
    return pevStable->QueryInterface(ppEnum);
}

// IMarshal (as a smart proxy)

STDMETHODIMP CSmartEnumVARIANT::GetUnmarshalClass(REFIID riid, void *pv, DWORD dwDestContext, void *pvDestContext, DWORD mshlflags, CLSID *pCid)
{
    *pCid = GetObjectCLSID();
    return S_OK;
}

STDMETHODIMP CSmartEnumVARIANT::GetMarshalSizeMax(REFIID riid, void *pv, DWORD dwDestContext, void *pvDestContext, DWORD mshlflags, DWORD *pSize)
{
    ObjectLock  lock(this);

    // Marshal size is size of marshaled IEnumVARIANT of delegate + sizeof(m_celt)
    HR(CoGetMarshalSizeMax(pSize, riid, m_spevDelegate, dwDestContext, pvDestContext, mshlflags));
    *pSize += sizeof(long);

    return S_OK;
}

STDMETHODIMP CSmartEnumVARIANT::MarshalInterface(IStream *pStm, REFIID riid, void *pv, DWORD dwDestContext, void *pvDestCtx, DWORD mshlflags)
{
    ObjectLock  lock(this);

    // Marshal IEnumVARIANT of delegate and m_celt
    HR(CoMarshalInterface(pStm, riid, m_spevDelegate, dwDestContext, pvDestCtx, mshlflags));
    ULONG   cb;
    HR(pStm->Write(&m_celt, sizeof(m_celt), &cb));

    return S_OK;
}

STDMETHODIMP CSmartEnumVARIANT::UnmarshalInterface(IStream *pStm, REFIID riid, void **ppv)
{
    ObjectLock  lock(this);

    // Clear old state
    delete m_pvi;
    m_pvi = 0;
    m_spevDelegate.Release();

    // Read new state
    CComPtr<IEnumVARIANT>   spev;
    HR(CoUnmarshalInterface(pStm, IID_IEnumVARIANT, (void**)&spev));
    ULONG   cb;
    ULONG   celt;
    HR(pStm->Read(&celt, sizeof(m_celt), &cb));

    // Construct myself from new state
    HR(Construct(spev, celt));

    // Return interface pointer to client
    return QueryInterface(riid, ppv);
}

STDMETHODIMP CSmartEnumVARIANT::ReleaseMarshalData(IStream *pStm)
{
    // Free up the delegate's IEnumVARIANT
    CoReleaseMarshalData(pStm);
    return S_OK;
}

STDMETHODIMP CSmartEnumVARIANT::DisconnectObject(DWORD dwReserved)
{
    return S_OK;
}
