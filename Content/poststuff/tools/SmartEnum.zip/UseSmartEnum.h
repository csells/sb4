// UseSmartEnum.h
// Copyright (c) 1998, Chris Sells. 
// All rights reserved. No warrenties extended. Use at your own risk. 
// Comments to csells@sellsbrothers.com. 

#pragma once
#ifndef __USESMARTENUM_H__
#define __USESMARTENUM_H__

template <typename Deriving, ULONG celtBuffer = 1024>
class IMarshalForSmartEnumImpl : public IMarshal
{
// IMarshal
public:
    STDMETHODIMP GetUnmarshalClass(REFIID riid, void *pv, DWORD dwDestContext, void *pvDestContext, DWORD mshlflags, CLSID *pCid)
    {
        // Smart proxy will make buffer calls to me
        *pCid = CLSID_SmartEnumVARIANT;
        return S_OK;
    }
    
    STDMETHODIMP GetMarshalSizeMax(REFIID riid, void *pv, DWORD dwDestContext, void *pvDestContext, DWORD mshlflags, DWORD *pSize)
    {
        // Packet size is size of standard marshal packet for me + sizeof(celt)
        CComPtr<IMarshal>   spmStandard;
        HR(CoGetStandardMarshal(riid, This()->GetUnknown(), dwDestContext, pvDestContext, mshlflags, &spmStandard));
        HR(spmStandard->GetMarshalSizeMax(riid, pv, dwDestContext, pvDestContext, mshlflags, pSize));
        *pSize += sizeof(celtBuffer);

        return S_OK;
    }
    
    STDMETHODIMP MarshalInterface(IStream *pStm, REFIID riid, void *pv, DWORD dwDestContext, void *pvDestCtx, DWORD mshlflags)
    {
        CComPtr<IMarshal>   spmStandard;
        HR(CoGetStandardMarshal(riid, This()->GetUnknown(), dwDestContext, pvDestCtx, mshlflags, &spmStandard));

        // Marshal stub interface pointer into packet
        HR(CoMarshalInterface(pStm, riid, spmStandard, dwDestContext, pvDestCtx, mshlflags));

        // Write buffering size
        ULONG   cb;
        ULONG   celt = celtBuffer;
        HR(pStm->Write(&celt, sizeof(celt), &cb));

        return S_OK;
    }
    
    STDMETHODIMP UnmarshalInterface(IStream *pStm, REFIID riid, void **ppv)
    {
        // Smart proxy does the rest
        return E_NOTIMPL;
    }
    
    STDMETHODIMP ReleaseMarshalData(IStream *pStm)
    {
        // Free up the stub
        CoReleaseMarshalData(pStm);
        return S_OK;
    }
    
    STDMETHODIMP DisconnectObject(DWORD dwReserved)
    {
        return S_OK;
    }

private:
    Deriving* This() { return static_cast<Deriving*>(this); }
};

#endif  // __USESMARTENUM_H__
