// SmartEnumVARIANT.h : Declaration of the CSmartEnumVARIANT
// Copyright (c) 1998, Chris Sells. 
// All rights reserved. No warrenties extended. Use at your own risk. 
// Comments to csells@sellsbrothers.com. 

#ifndef __SMARTENUMVARIANT_H_
#define __SMARTENUMVARIANT_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CSmartEnumVARIANT
class ATL_NO_VTABLE CSmartEnumVARIANT : 
    public CComObjectRootEx<CComMultiThreadModel>,
    public CComCoClass<CSmartEnumVARIANT, &CLSID_SmartEnumVARIANT>,
    public IEnumVARIANT,
    public IMarshal
{
public:
    CSmartEnumVARIANT();
    virtual ~CSmartEnumVARIANT();

    HRESULT Construct(IEnumVARIANT* pev, ULONG celt);
    
DECLARE_REGISTRY_RESOURCEID(IDR_SMARTENUMVARIANT)
DECLARE_NOT_AGGREGATABLE(CSmartEnumVARIANT)

BEGIN_COM_MAP(CSmartEnumVARIANT)
    COM_INTERFACE_ENTRY(IEnumVARIANT)
    COM_INTERFACE_ENTRY(IMarshal)
END_COM_MAP()

// IEnumVARIANT
public:
    STDMETHODIMP Next(ULONG celt, VARIANT* rgelt, ULONG* pceltFetched);
	STDMETHODIMP Skip(ULONG celt);
	STDMETHODIMP Reset();
	STDMETHODIMP Clone(IEnumVARIANT** ppEnum);

// IMarshal
public:
    STDMETHODIMP GetUnmarshalClass(REFIID riid, void *pv, DWORD dwDestContext, void *pvDestContext, DWORD mshlflags, CLSID *pCid);
    STDMETHODIMP GetMarshalSizeMax(REFIID riid, void *pv, DWORD dwDestContext, void *pvDestContext, DWORD mshlflags, DWORD *pSize);
    STDMETHODIMP MarshalInterface(IStream *pStm, REFIID riid, void *pv, DWORD dwDestContext, void *pvDestCtx, DWORD mshlflags);
    STDMETHODIMP UnmarshalInterface(IStream *pStm, REFIID riid, void **ppv);
    STDMETHODIMP ReleaseMarshalData(IStream *pStm);
    STDMETHODIMP DisconnectObject(DWORD dwReserved);

private:
    ULONG                   m_celt;
    CComPtr<IEnumVARIANT>   m_spevDelegate;
    variant_iterator*       m_pvi;
};

#endif //__SMARTENUMVARIANT_H_
