/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Fri Nov 27 11:06:20 1998
 */
/* Compiler settings for D:\Project\mine\SmartEnumSvr\SmartEnumSvr.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __SmartEnumSvr_h__
#define __SmartEnumSvr_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __ICollectionBuffer_FWD_DEFINED__
#define __ICollectionBuffer_FWD_DEFINED__
typedef interface ICollectionBuffer ICollectionBuffer;
#endif 	/* __ICollectionBuffer_FWD_DEFINED__ */


#ifndef __SmartEnumVARIANT_FWD_DEFINED__
#define __SmartEnumVARIANT_FWD_DEFINED__

#ifdef __cplusplus
typedef class SmartEnumVARIANT SmartEnumVARIANT;
#else
typedef struct SmartEnumVARIANT SmartEnumVARIANT;
#endif /* __cplusplus */

#endif 	/* __SmartEnumVARIANT_FWD_DEFINED__ */


#ifndef __CollectionBuffer_FWD_DEFINED__
#define __CollectionBuffer_FWD_DEFINED__

#ifdef __cplusplus
typedef class CollectionBuffer CollectionBuffer;
#else
typedef struct CollectionBuffer CollectionBuffer;
#endif /* __cplusplus */

#endif 	/* __CollectionBuffer_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __ICollectionBuffer_INTERFACE_DEFINED__
#define __ICollectionBuffer_INTERFACE_DEFINED__

/* interface ICollectionBuffer */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ICollectionBuffer;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("B6175081-83D4-11D2-987D-00600823CFFB")
    ICollectionBuffer : public IDispatch
    {
    public:
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_Collection( 
            /* [retval][out] */ IDispatch __RPC_FAR *__RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE put_Collection( 
            /* [in] */ IDispatch __RPC_FAR *newVal) = 0;
        
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_BufferSize( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE put_BufferSize( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [id][propget] */ HRESULT STDMETHODCALLTYPE get__NewEnum( 
            /* [retval][out] */ IUnknown __RPC_FAR *__RPC_FAR *ppunkEnum) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ICollectionBufferVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ICollectionBuffer __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ICollectionBuffer __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ICollectionBuffer __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ICollectionBuffer __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ICollectionBuffer __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ICollectionBuffer __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ICollectionBuffer __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Collection )( 
            ICollectionBuffer __RPC_FAR * This,
            /* [retval][out] */ IDispatch __RPC_FAR *__RPC_FAR *pVal);
        
        /* [helpstring][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Collection )( 
            ICollectionBuffer __RPC_FAR * This,
            /* [in] */ IDispatch __RPC_FAR *newVal);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_BufferSize )( 
            ICollectionBuffer __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_BufferSize )( 
            ICollectionBuffer __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get__NewEnum )( 
            ICollectionBuffer __RPC_FAR * This,
            /* [retval][out] */ IUnknown __RPC_FAR *__RPC_FAR *ppunkEnum);
        
        END_INTERFACE
    } ICollectionBufferVtbl;

    interface ICollectionBuffer
    {
        CONST_VTBL struct ICollectionBufferVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ICollectionBuffer_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICollectionBuffer_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICollectionBuffer_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ICollectionBuffer_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ICollectionBuffer_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ICollectionBuffer_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ICollectionBuffer_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ICollectionBuffer_get_Collection(This,pVal)	\
    (This)->lpVtbl -> get_Collection(This,pVal)

#define ICollectionBuffer_put_Collection(This,newVal)	\
    (This)->lpVtbl -> put_Collection(This,newVal)

#define ICollectionBuffer_get_BufferSize(This,pVal)	\
    (This)->lpVtbl -> get_BufferSize(This,pVal)

#define ICollectionBuffer_put_BufferSize(This,newVal)	\
    (This)->lpVtbl -> put_BufferSize(This,newVal)

#define ICollectionBuffer_get__NewEnum(This,ppunkEnum)	\
    (This)->lpVtbl -> get__NewEnum(This,ppunkEnum)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE ICollectionBuffer_get_Collection_Proxy( 
    ICollectionBuffer __RPC_FAR * This,
    /* [retval][out] */ IDispatch __RPC_FAR *__RPC_FAR *pVal);


void __RPC_STUB ICollectionBuffer_get_Collection_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE ICollectionBuffer_put_Collection_Proxy( 
    ICollectionBuffer __RPC_FAR * This,
    /* [in] */ IDispatch __RPC_FAR *newVal);


void __RPC_STUB ICollectionBuffer_put_Collection_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE ICollectionBuffer_get_BufferSize_Proxy( 
    ICollectionBuffer __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ICollectionBuffer_get_BufferSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE ICollectionBuffer_put_BufferSize_Proxy( 
    ICollectionBuffer __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ICollectionBuffer_put_BufferSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id][propget] */ HRESULT STDMETHODCALLTYPE ICollectionBuffer_get__NewEnum_Proxy( 
    ICollectionBuffer __RPC_FAR * This,
    /* [retval][out] */ IUnknown __RPC_FAR *__RPC_FAR *ppunkEnum);


void __RPC_STUB ICollectionBuffer_get__NewEnum_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ICollectionBuffer_INTERFACE_DEFINED__ */



#ifndef __SMARTENUMSVRLib_LIBRARY_DEFINED__
#define __SMARTENUMSVRLib_LIBRARY_DEFINED__

/* library SMARTENUMSVRLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_SMARTENUMSVRLib;

EXTERN_C const CLSID CLSID_SmartEnumVARIANT;

#ifdef __cplusplus

class DECLSPEC_UUID("B617507E-83D4-11D2-987D-00600823CFFB")
SmartEnumVARIANT;
#endif

EXTERN_C const CLSID CLSID_CollectionBuffer;

#ifdef __cplusplus

class DECLSPEC_UUID("B6175082-83D4-11D2-987D-00600823CFFB")
CollectionBuffer;
#endif
#endif /* __SMARTENUMSVRLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
