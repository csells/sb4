// ComCurrency.cpp : Implementation of CComCurrency

#include "stdafx.h"
#include "ComCurrency.h"
#include "resource.h"

/////////////////////////////////////////////////////////////////////////////
// CComCurrency class helpers

// Return the highest order bit composing dwTarget in wBit
#define HI_BIT(dwTarget, wBit) \
	do \
	{ \
		if (dwTarget != 0) \
			for (wBit = 32; (dwTarget & (0x00000001 << wBit-1)) == 0; wBit--);\
		else \
			wBit = 0; \
	} while (0)

// Left shift an (assumed unsigned) currency by wBits
#define LSHIFT_UCUR(cur, wBits) \
	do \
	{ \
		for (WORD wTempBits = wBits; wTempBits > 0; wTempBits--) \
		{ \
			cur.m_cur.Hi = ((DWORD)cur.m_cur.Hi << 1); \
			cur.m_cur.Hi |= (cur.m_cur.Lo & 0x80000000) >> 31; \
			cur.m_cur.Lo = cur.m_cur.Lo << 1; \
		} \
	} while (0)

// Right shift an (assumed unsigned) currency by wBits
#define RSHIFT_UCUR(cur, wBits) \
	do \
	{ \
		for (WORD wTempBits = wBits; wTempBits > 0; wTempBits--) \
		{ \
			cur.m_cur.Lo = cur.m_cur.Lo >> 1; \
			cur.m_cur.Lo |= (cur.m_cur.Hi & 0x00000001) << 31; \
			cur.m_cur.Hi = ((DWORD)cur.m_cur.Hi >> 1); \
		} \
	} while (0)

/////////////////////////////////////////////////////////////////////////////
// CComCurrency class (internally currency is 8-byte int scaled by 10,000)

CComCurrency::CComCurrency(long nUnits, long nFractionalUnits)
{
	SetCurrency(nUnits, nFractionalUnits);
	SetStatus(valid);
}

const CComCurrency& CComCurrency::operator=(CURRENCY cySrc)
{
	m_cur = cySrc;
	SetStatus(valid);
	return *this;
}

const CComCurrency& CComCurrency::operator=(const CComCurrency& curSrc)
{
	m_cur = curSrc.m_cur;
	m_status = curSrc.m_status;
	return *this;
}


BOOL CComCurrency::operator<(const CComCurrency& cur) const
{
	_ASSERTE(GetStatus() == valid);
	_ASSERTE(cur.GetStatus() == valid);

	return((m_cur.Hi == cur.m_cur.Hi) ?
		(m_cur.Lo < cur.m_cur.Lo) : (m_cur.Hi < cur.m_cur.Hi));
}

BOOL CComCurrency::operator>(const CComCurrency& cur) const
{
	_ASSERTE(GetStatus() == valid);
	_ASSERTE(cur.GetStatus() == valid);

	return((m_cur.Hi == cur.m_cur.Hi) ?
		(m_cur.Lo > cur.m_cur.Lo) : (m_cur.Hi > cur.m_cur.Hi));
}

BOOL CComCurrency::operator<=(const CComCurrency& cur) const
{
	_ASSERTE(GetStatus() == valid);
	_ASSERTE(cur.GetStatus() == valid);

	return((m_cur.Hi == cur.m_cur.Hi) ?
		(m_cur.Lo <= cur.m_cur.Lo) : (m_cur.Hi < cur.m_cur.Hi));
}

BOOL CComCurrency::operator>=(const CComCurrency& cur) const
{
	_ASSERTE(GetStatus() == valid);
	_ASSERTE(cur.GetStatus() == valid);

	return((m_cur.Hi == cur.m_cur.Hi) ?
		(m_cur.Lo >= cur.m_cur.Lo) : (m_cur.Hi > cur.m_cur.Hi));
}

CComCurrency CComCurrency::operator+(const CComCurrency& cur) const
{
	CComCurrency curResult;

	// If either operand Null, result Null
	if (GetStatus() == null || cur.GetStatus() == null)
	{
		curResult.SetStatus(null);
		return curResult;
	}

	// If either operand Invalid, result Invalid
	if (GetStatus() == invalid || cur.GetStatus() == invalid)
	{
		curResult.SetStatus(invalid);
		return curResult;
	}

	// Add separate CURRENCY components
	curResult.m_cur.Hi = m_cur.Hi + cur.m_cur.Hi;
	curResult.m_cur.Lo = m_cur.Lo + cur.m_cur.Lo;

	// Increment Hi if Lo overflows
	if (m_cur.Lo > curResult.m_cur.Lo)
		curResult.m_cur.Hi++;

	// Overflow if operands same sign and result sign different
	if (!((m_cur.Hi ^ cur.m_cur.Hi) & 0x80000000) &&
		((m_cur.Hi ^ curResult.m_cur.Hi) & 0x80000000))
	{
		curResult.SetStatus(invalid);
	}

	return curResult;
}

CComCurrency CComCurrency::operator-(const CComCurrency& cur) const
{
	CComCurrency curResult;

	// If either operand Null, result Null
	if (GetStatus() == null || cur.GetStatus() == null)
	{
		curResult.SetStatus(null);
		return curResult;
	}

	// If either operand Invalid, result Invalid
	if (GetStatus() == invalid || cur.GetStatus() == invalid)
	{
		curResult.SetStatus(invalid);
		return curResult;
	}

	// Subtract separate CURRENCY components
	curResult.m_cur.Hi = m_cur.Hi - cur.m_cur.Hi;
	curResult.m_cur.Lo = m_cur.Lo - cur.m_cur.Lo;

	// Decrement Hi if Lo overflows
	if (m_cur.Lo < curResult.m_cur.Lo)
		curResult.m_cur.Hi--;

	// Overflow if operands not same sign and result not same sign
	if (((m_cur.Hi ^ cur.m_cur.Hi) & 0x80000000) &&
		((m_cur.Hi ^ curResult.m_cur.Hi) & 0x80000000))
	{
		curResult.SetStatus(invalid);
	}

	return curResult;
}

CComCurrency CComCurrency::operator-() const
{
	// If operand not Valid, just return
	if (!GetStatus() == valid)
		return *this;

	CComCurrency curResult;

	// Negating MIN_CURRENCY,will set invalid
	if (m_cur.Hi == 0x80000000 && m_cur.Lo == 0x00000000)
	{
		curResult.SetStatus(invalid);
	}

	curResult.m_cur.Hi = ~m_cur.Hi;
	curResult.m_cur.Lo = -(long)m_cur.Lo;

	// If cy was -1 make sure Hi correctly set
	if (curResult.m_cur.Lo == 0)
		curResult.m_cur.Hi++;

	return curResult;
}

CComCurrency CComCurrency::operator*(long nOperand) const
{
	// If operand not Valid, just return
	if (!GetStatus() == valid)
		return *this;

	CComCurrency curResult(m_cur);
	DWORD nTempOp;

	// Return now if one operand is 0 (optimization)
	if ((m_cur.Hi == 0x00000000 && m_cur.Lo == 0x00000000) || nOperand == 0)
	{
		curResult.m_cur.Hi = 0;
		curResult.m_cur.Lo = 0;
		return curResult;
	}

	// Handle only valid case of multiplying MIN_CURRENCY
	if (m_cur.Hi == 0x80000000 && m_cur.Lo == 0x00000000 && nOperand == 1)
		return curResult;

	// Compute absolute values.
	if (m_cur.Hi < 0)
		curResult = -curResult;

	nTempOp = labs(nOperand);

	// Check for overflow
	if (curResult.m_cur.Hi != 0)
	{
		WORD wHiBitCur, wHiBitOp;
		HI_BIT(curResult.m_cur.Hi, wHiBitCur);
		HI_BIT(nTempOp, wHiBitOp);

		// 63-bit limit on result. (n bits)*(m bits) = (n+m-1) bits.
		if (wHiBitCur + wHiBitOp - 1 > 63)
		{
			// Overflow!
			curResult.SetStatus(invalid);

			// Set to maximum negative value
			curResult.m_cur.Hi = 0x80000000;
			curResult.m_cur.Lo = 0x00000000;

			return curResult;
		}
	}

	// Break up into WORDs
	WORD wCy4, wCy3, wCy2, wCy1, wL2, wL1;

	wCy4 = HIWORD(curResult.m_cur.Hi);
	wCy3 = LOWORD(curResult.m_cur.Hi);
	wCy2 = HIWORD(curResult.m_cur.Lo);
	wCy1 = LOWORD(curResult.m_cur.Lo);

	wL2 = HIWORD(nTempOp);
	wL1 = LOWORD(nTempOp);

	// Multiply each set of WORDs
	DWORD dwRes11, dwRes12, dwRes21, dwRes22;
	DWORD dwRes31, dwRes32, dwRes41;  // Don't need dwRes42

	dwRes11 = wCy1 * wL1;
	dwRes12 = wCy1 * wL2;
	dwRes21 = wCy2 * wL1;
	dwRes22 = wCy2 * wL2;

	dwRes31 = wCy3 * wL1;
	dwRes32 = wCy3 * wL2;
	dwRes41 = wCy4 * wL1;

	// Add up low order pieces
	dwRes11 += dwRes12<<16;
	curResult.m_cur.Lo = dwRes11 + (dwRes21<<16);

	// Check if carry required
	if (dwRes11 < dwRes12<<16 || (DWORD)curResult.m_cur.Lo < dwRes11)
		curResult.m_cur.Hi = 1;
	else
		curResult.m_cur.Hi = 0;

	// Add up the high order pieces
	curResult.m_cur.Hi += dwRes31 + (dwRes32<<16) + (dwRes41<<16) +
		dwRes22 + (dwRes12>>16) + (dwRes21>>16);

	// Compute result sign
	if ((m_cur.Hi ^ nOperand) & 0x80000000)
		curResult = -curResult;

	return curResult;
}

CComCurrency CComCurrency::operator/(long nOperand) const
{
	// If operand not Valid, just return
	if (!GetStatus() == valid)
		return *this;

	CComCurrency curTemp(m_cur);
	DWORD nTempOp;

	// Check for divide by 0
	if (nOperand == 0)
	{
		curTemp.SetStatus(invalid);

		// Set to maximum negative value
		curTemp.m_cur.Hi = 0x80000000;
		curTemp.m_cur.Lo = 0x00000000;

		return curTemp;
	}

	// Compute absolute values
	if (curTemp.m_cur.Hi < 0)
		curTemp = -curTemp;

	nTempOp = labs(nOperand);

	// Optimization - division is simple if Hi == 0
	if (curTemp.m_cur.Hi == 0x0000)
	{
		curTemp.m_cur.Lo = m_cur.Lo / nTempOp;

		// Compute result sign
		if ((m_cur.Hi ^ nOperand) & 0x80000000)
			curTemp = -curTemp;

		return curTemp;
	}

	// Now curTemp represents remainder
	CComCurrency curResult; // Initializes to zero
	CComCurrency curTempResult;
	CComCurrency curOperand;

	curOperand.m_cur.Lo = nTempOp;

	WORD wHiBitRem;
	WORD wScaleOp;

	// Quit if remainder can be truncated
	while (curTemp >= curOperand)
	{
		// Scale up and divide Hi portion
		HI_BIT(curTemp.m_cur.Hi, wHiBitRem);

		if (wHiBitRem != 0)
			wHiBitRem += 32;
		else
			HI_BIT(curTemp.m_cur.Lo, wHiBitRem);

		WORD wShift = (WORD)(64 - wHiBitRem);
		LSHIFT_UCUR(curTemp, wShift);

		// If Operand bigger than Hi it must be scaled
		wScaleOp = (WORD)((nTempOp > (DWORD)curTemp.m_cur.Hi) ? 1 : 0);

		// Perform synthetic division
		curTempResult.m_cur.Hi =
			(DWORD)curTemp.m_cur.Hi / (nTempOp >> wScaleOp);

		// Scale back to get correct result and remainder
		RSHIFT_UCUR(curTemp, wShift);
		wShift = (WORD)(wShift - wScaleOp);
		RSHIFT_UCUR(curTempResult, wShift);

		// Now calculate result and remainder
		curResult += curTempResult;
		curTemp -= curTempResult * nTempOp;
	}

	// Compute result sign
	if ((m_cur.Hi ^ nOperand) & 0x80000000)
		curResult = -curResult;

	return curResult;
}

void CComCurrency::SetCurrency(long nUnits, long nFractionalUnits)
{
	CComCurrency curUnits;              // Initializes to 0
	CComCurrency curFractionalUnits;    // Initializes to 0

	// Set temp currency value to Units (need to multiply by 10,000)
	curUnits.m_cur.Lo = (DWORD)labs(nUnits);
	curUnits = curUnits * 10000;
	if (nUnits < 0)
		curUnits = -curUnits;

	curFractionalUnits.m_cur.Lo = (DWORD)labs(nFractionalUnits);
	if (nFractionalUnits < 0)
		curFractionalUnits = -curFractionalUnits;

	// Now add together Units and FractionalUnits
	*this = curUnits + curFractionalUnits;

	SetStatus(valid);
}

BOOL CComCurrency::ParseCurrency(const BSTR& strCurrency, DWORD dwFlags,  LCID lcid)
{
	USES_CONVERSION;

	SCODE sc;
	if ( FAILED(sc = VarCyFromStr (strCurrency, lcid, dwFlags, &m_cur))) {
        switch (sc) {
        case DISP_E_TYPEMISMATCH:
			// Can't convert string to CURRENCY, set 0 & invalid
			m_cur.Hi = 0x00000000;
			m_cur.Lo = 0x00000000;
			SetStatus(invalid);
			return FALSE;

        case DISP_E_OVERFLOW:
			// Can't convert string to CURRENCY, set max neg & invalid
			m_cur.Hi = 0x80000000;
			m_cur.Lo = 0x00000000;
			SetStatus(invalid);
			return FALSE;

        default:
            ATLTRACE(_T("\nCComCurrency VarCyFromStr call failed.\n\t")) ;
            _ASSERTE (FALSE) ;
//			if (sc == E_OUTOFMEMORY)
//				AfxThrowMemoryException();
//			else
//				AfxThrowOleException(sc);
            return FALSE ;
		}
	}

	SetStatus(valid);
	return TRUE;
}

CComBSTR CComCurrency::Format(DWORD dwFlags, LCID lcid) const
{
	CComBSTR strCur;

	// If null, return empty string
	if (GetStatus() == null)
		return strCur;

	// If invalid, return Currency resource string
	if (GetStatus() == invalid) {
        LoadStringHelper (IDS_INVALID_CURRENCY) ;
		return strCur;
	}

	VarBstrFromCy (m_cur, lcid, dwFlags, &strCur) ;
	return strCur ;
}

