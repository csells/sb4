#if !defined (_COM_CURRENCY_H_)
#define _COM_CURRENCY_H_

/////////////////////////////////////////////////////////////////////////////
// CComCurrency

class CComCurrency
{
// Constructors
public:
	CComCurrency();

	CComCurrency(CURRENCY cySrc);
	CComCurrency(const CComCurrency& curSrc);
	CComCurrency(const VARIANT& varSrc);
	CComCurrency(long nUnits, long nFractionalUnits);

// Attributes
public:
	enum CurrencyStatus
	{
		valid = 0,
		invalid = 1,    // Invalid currency (overflow, div 0, etc.)
		null = 2,       // Literally has no value
	};

	CURRENCY m_cur;
	CurrencyStatus m_status;

	void SetStatus(CurrencyStatus status);
	CurrencyStatus GetStatus() const;

// Operations
public:
	const CComCurrency& operator=(CURRENCY cySrc);
	const CComCurrency& operator=(const CComCurrency& curSrc);
	const CComCurrency& operator=(const VARIANT& varSrc);

	BOOL operator==(const CComCurrency& cur) const;
	BOOL operator!=(const CComCurrency& cur) const;
	BOOL operator<(const CComCurrency& cur) const;
	BOOL operator>(const CComCurrency& cur) const;
	BOOL operator<=(const CComCurrency& cur) const;
	BOOL operator>=(const CComCurrency& cur) const;

	// Currency math
	CComCurrency operator+(const CComCurrency& cur) const;
	CComCurrency operator-(const CComCurrency& cur) const;
	const CComCurrency& operator+=(const CComCurrency& cur);
	const CComCurrency& operator-=(const CComCurrency& cur);
	CComCurrency operator-() const;

	CComCurrency operator*(long nOperand) const;
	CComCurrency operator/(long nOperand) const;
	const CComCurrency& operator*=(long nOperand);
	const CComCurrency& operator/=(long nOperand);

	operator CURRENCY() const;

	// Currency definition
	void SetCurrency(long nUnits, long nFractionalUnits);
	BOOL ParseCurrency(const BSTR& bstrCurrency, DWORD dwFlags = 0, LCID = LANG_USER_DEFAULT);

	// formatting
	CComBSTR Format(DWORD dwFlags = 0, LCID lcid = LANG_USER_DEFAULT) const;

    // Implementation
	LPOLESTR LoadStringHelper(UINT idRes) const
	{
		USES_CONVERSION;

		LPOLESTR sz = (LPOLESTR)CoTaskMemAlloc(_MAX_PATH*sizeof(OLECHAR));
		TCHAR szTemp[_MAX_PATH];
		
		if (!LoadString(_Module.GetResourceInstance(), idRes, szTemp, _MAX_PATH))
		{
			ATLTRACE(_T("Error : Failed to load title string from res\n"));
			return NULL;
		}
		
		ocscpy(sz, T2OLE(szTemp));

		return sz;
	}
};

inline CComCurrency::CComCurrency()
	{ m_cur.Hi = 0; m_cur.Lo = 0; SetStatus(valid); }
inline CComCurrency::CComCurrency(CURRENCY cySrc)
	{ m_cur = cySrc; SetStatus(valid); }
inline CComCurrency::CComCurrency(const CComCurrency& curSrc)
	{ m_cur = curSrc.m_cur; m_status = curSrc.m_status; }
inline CComCurrency::CComCurrency(const VARIANT& varSrc)
	{ *this = varSrc; }
inline CComCurrency::CurrencyStatus CComCurrency::GetStatus() const
	{ return m_status; }
inline void CComCurrency::SetStatus(CurrencyStatus status)
	{ m_status = status; }
inline const CComCurrency& CComCurrency::operator+=(const CComCurrency& cur)
	{ *this = *this + cur; return *this; }
inline const CComCurrency& CComCurrency::operator-=(const CComCurrency& cur)
	{ *this = *this - cur; return *this; }
inline const CComCurrency& CComCurrency::operator*=(long nOperand)
	{ *this = *this * nOperand; return *this; }
inline const CComCurrency& CComCurrency::operator/=(long nOperand)
	{ *this = *this / nOperand; return *this; }
inline BOOL CComCurrency::operator==(const CComCurrency& cur) const
	{ return(m_status == cur.m_status && m_cur.Hi == cur.m_cur.Hi &&
		m_cur.Lo == cur.m_cur.Lo); }
inline BOOL CComCurrency::operator!=(const CComCurrency& cur) const
	{ return(m_status != cur.m_status || m_cur.Hi != cur.m_cur.Hi ||
		m_cur.Lo != cur.m_cur.Lo); }
inline CComCurrency::operator CURRENCY() const
	{ return m_cur; }

#endif
