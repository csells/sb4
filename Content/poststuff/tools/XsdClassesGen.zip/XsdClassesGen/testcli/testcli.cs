using System;
using System.IO;
using XsdClassesGenerator;
using System.Xml;
using System.Xml.Serialization;
using SellsBrothers.VSDesigner.CodeGenerator;

namespace testcli {
  class TestClient {
    [STAThread]
    static void Main(string[] args) {
      // Test VS.NET classes
      VsCSharpXsdClassesGenerator.RegisterClass(typeof(VsCSharpXsdClassesGenerator));

      string  inputFile = @"..\..\unityLogistics.xsd";
      string  input = (new StreamReader(inputFile)).ReadToEnd();

      BaseCodeGeneratorWithSite[] gens = {
//          new VsCSharpXsdClassesGenerator(),
//          new VsVBXsdClassesGenerator(),
      };

      foreach( BaseCodeGeneratorWithSite gen in gens ) {
        byte[]  code = gen.GenerateCode(inputFile, input);
        Console.WriteLine(System.Text.Encoding.ASCII.GetString(code));
      }

      // Test generated code
      using( FileStream fs = new FileStream(@"..\..\unityLogistics.xml", FileMode.Open, FileAccess.Read) ) {
        XmlSerializer   serializer = new XmlSerializer(typeof(unity));
        unity           u = (unity)serializer.Deserialize(fs);

        Console.WriteLine("currentModule=   {0}", u.currentModule);
        Console.WriteLine("nextLecture=     {0}", u.nextLecture);
        Console.WriteLine("currentActivity= {0}", u.currentActivity);
        Console.WriteLine("notes:");
        foreach( string note in u.notes ) {
          Console.WriteLine("\tnote: {0}", note);
        }
      }
    }
  }
}
