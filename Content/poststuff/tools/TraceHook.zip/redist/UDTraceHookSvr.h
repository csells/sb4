/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Tue Jan 26 10:16:23 1999
 */
/* Compiler settings for D:\Project\Mine\tracehook\src\UDTraceHookSvr.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __UDTraceHookSvr_h__
#define __UDTraceHookSvr_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __ITraceHook_FWD_DEFINED__
#define __ITraceHook_FWD_DEFINED__
typedef interface ITraceHook ITraceHook;
#endif 	/* __ITraceHook_FWD_DEFINED__ */


#ifndef __ITraceMethodHook_FWD_DEFINED__
#define __ITraceMethodHook_FWD_DEFINED__
typedef interface ITraceMethodHook ITraceMethodHook;
#endif 	/* __ITraceMethodHook_FWD_DEFINED__ */


#ifndef __ITraceHookFactory_FWD_DEFINED__
#define __ITraceHookFactory_FWD_DEFINED__
typedef interface ITraceHookFactory ITraceHookFactory;
#endif 	/* __ITraceHookFactory_FWD_DEFINED__ */


#ifndef __ITraceDispMethodHook_FWD_DEFINED__
#define __ITraceDispMethodHook_FWD_DEFINED__
typedef interface ITraceDispMethodHook ITraceDispMethodHook;
#endif 	/* __ITraceDispMethodHook_FWD_DEFINED__ */


#ifndef __TraceHook_FWD_DEFINED__
#define __TraceHook_FWD_DEFINED__

#ifdef __cplusplus
typedef class TraceHook TraceHook;
#else
typedef struct TraceHook TraceHook;
#endif /* __cplusplus */

#endif 	/* __TraceHook_FWD_DEFINED__ */


#ifndef __TraceMethodHook_FWD_DEFINED__
#define __TraceMethodHook_FWD_DEFINED__

#ifdef __cplusplus
typedef class TraceMethodHook TraceMethodHook;
#else
typedef struct TraceMethodHook TraceMethodHook;
#endif /* __cplusplus */

#endif 	/* __TraceMethodHook_FWD_DEFINED__ */


#ifndef __TraceDispMethodHook_FWD_DEFINED__
#define __TraceDispMethodHook_FWD_DEFINED__

#ifdef __cplusplus
typedef class TraceDispMethodHook TraceDispMethodHook;
#else
typedef struct TraceDispMethodHook TraceDispMethodHook;
#endif /* __cplusplus */

#endif 	/* __TraceDispMethodHook_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __ITraceHook_INTERFACE_DEFINED__
#define __ITraceHook_INTERFACE_DEFINED__

/* interface ITraceHook */
/* [unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_ITraceHook;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("43B6EC4F-A742-11D2-90EB-00104B2168FE")
    ITraceHook : public IUnknown
    {
    public:
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE SetObjectName( 
            /* [in] */ LPCOLESTR pszObjectName) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ITraceHookVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ITraceHook __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ITraceHook __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ITraceHook __RPC_FAR * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetObjectName )( 
            ITraceHook __RPC_FAR * This,
            /* [in] */ LPCOLESTR pszObjectName);
        
        END_INTERFACE
    } ITraceHookVtbl;

    interface ITraceHook
    {
        CONST_VTBL struct ITraceHookVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ITraceHook_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITraceHook_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITraceHook_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ITraceHook_SetObjectName(This,pszObjectName)	\
    (This)->lpVtbl -> SetObjectName(This,pszObjectName)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring] */ HRESULT STDMETHODCALLTYPE ITraceHook_SetObjectName_Proxy( 
    ITraceHook __RPC_FAR * This,
    /* [in] */ LPCOLESTR pszObjectName);


void __RPC_STUB ITraceHook_SetObjectName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ITraceHook_INTERFACE_DEFINED__ */


#ifndef __ITraceMethodHook_INTERFACE_DEFINED__
#define __ITraceMethodHook_INTERFACE_DEFINED__

/* interface ITraceMethodHook */
/* [unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_ITraceMethodHook;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("43B6EC56-A742-11D2-90EB-00104B2168FE")
    ITraceMethodHook : public IUnknown
    {
    public:
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE SetObjectNameAndIID( 
            /* [in] */ IUnknown __RPC_FAR *punkObj,
            /* [in] */ LPCOLESTR pszObjectName,
            /* [in] */ REFIID riid) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ITraceMethodHookVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ITraceMethodHook __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ITraceMethodHook __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ITraceMethodHook __RPC_FAR * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetObjectNameAndIID )( 
            ITraceMethodHook __RPC_FAR * This,
            /* [in] */ IUnknown __RPC_FAR *punkObj,
            /* [in] */ LPCOLESTR pszObjectName,
            /* [in] */ REFIID riid);
        
        END_INTERFACE
    } ITraceMethodHookVtbl;

    interface ITraceMethodHook
    {
        CONST_VTBL struct ITraceMethodHookVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ITraceMethodHook_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITraceMethodHook_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITraceMethodHook_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ITraceMethodHook_SetObjectNameAndIID(This,punkObj,pszObjectName,riid)	\
    (This)->lpVtbl -> SetObjectNameAndIID(This,punkObj,pszObjectName,riid)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring] */ HRESULT STDMETHODCALLTYPE ITraceMethodHook_SetObjectNameAndIID_Proxy( 
    ITraceMethodHook __RPC_FAR * This,
    /* [in] */ IUnknown __RPC_FAR *punkObj,
    /* [in] */ LPCOLESTR pszObjectName,
    /* [in] */ REFIID riid);


void __RPC_STUB ITraceMethodHook_SetObjectNameAndIID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ITraceMethodHook_INTERFACE_DEFINED__ */


#ifndef __ITraceHookFactory_INTERFACE_DEFINED__
#define __ITraceHookFactory_INTERFACE_DEFINED__

/* interface ITraceHookFactory */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ITraceHookFactory;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("AD8E31B4-A8D9-11d2-9D23-000001136428")
    ITraceHookFactory : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ComTrace( 
            /* [in] */ BSTR bstrObjectName,
            /* [out][in] */ VARIANT __RPC_FAR *pVarObject) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ITraceHookFactoryVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ITraceHookFactory __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ITraceHookFactory __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ITraceHookFactory __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ITraceHookFactory __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ITraceHookFactory __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ITraceHookFactory __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ITraceHookFactory __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ComTrace )( 
            ITraceHookFactory __RPC_FAR * This,
            /* [in] */ BSTR bstrObjectName,
            /* [out][in] */ VARIANT __RPC_FAR *pVarObject);
        
        END_INTERFACE
    } ITraceHookFactoryVtbl;

    interface ITraceHookFactory
    {
        CONST_VTBL struct ITraceHookFactoryVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ITraceHookFactory_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITraceHookFactory_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITraceHookFactory_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ITraceHookFactory_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ITraceHookFactory_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ITraceHookFactory_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ITraceHookFactory_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ITraceHookFactory_ComTrace(This,bstrObjectName,pVarObject)	\
    (This)->lpVtbl -> ComTrace(This,bstrObjectName,pVarObject)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITraceHookFactory_ComTrace_Proxy( 
    ITraceHookFactory __RPC_FAR * This,
    /* [in] */ BSTR bstrObjectName,
    /* [out][in] */ VARIANT __RPC_FAR *pVarObject);


void __RPC_STUB ITraceHookFactory_ComTrace_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ITraceHookFactory_INTERFACE_DEFINED__ */


#ifndef __ITraceDispMethodHook_INTERFACE_DEFINED__
#define __ITraceDispMethodHook_INTERFACE_DEFINED__

/* interface ITraceDispMethodHook */
/* [unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_ITraceDispMethodHook;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("D4123047-A8D7-11D2-9D23-000001136428")
    ITraceDispMethodHook : public IUnknown
    {
    public:
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE SetObjectName( 
            /* [in] */ LPCOLESTR szObjectName) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ITraceDispMethodHookVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ITraceDispMethodHook __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ITraceDispMethodHook __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ITraceDispMethodHook __RPC_FAR * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetObjectName )( 
            ITraceDispMethodHook __RPC_FAR * This,
            /* [in] */ LPCOLESTR szObjectName);
        
        END_INTERFACE
    } ITraceDispMethodHookVtbl;

    interface ITraceDispMethodHook
    {
        CONST_VTBL struct ITraceDispMethodHookVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ITraceDispMethodHook_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITraceDispMethodHook_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITraceDispMethodHook_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ITraceDispMethodHook_SetObjectName(This,szObjectName)	\
    (This)->lpVtbl -> SetObjectName(This,szObjectName)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring] */ HRESULT STDMETHODCALLTYPE ITraceDispMethodHook_SetObjectName_Proxy( 
    ITraceDispMethodHook __RPC_FAR * This,
    /* [in] */ LPCOLESTR szObjectName);


void __RPC_STUB ITraceDispMethodHook_SetObjectName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ITraceDispMethodHook_INTERFACE_DEFINED__ */



#ifndef __UDTRACEHOOKSVRLib_LIBRARY_DEFINED__
#define __UDTRACEHOOKSVRLib_LIBRARY_DEFINED__

/* library UDTRACEHOOKSVRLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_UDTRACEHOOKSVRLib;

EXTERN_C const CLSID CLSID_TraceHook;

#ifdef __cplusplus

class DECLSPEC_UUID("AD8E31B5-A8D9-11d2-9D23-000001136428")
TraceHook;
#endif

EXTERN_C const CLSID CLSID_TraceMethodHook;

#ifdef __cplusplus

class DECLSPEC_UUID("43B6EC57-A742-11D2-90EB-00104B2168FE")
TraceMethodHook;
#endif

EXTERN_C const CLSID CLSID_TraceDispMethodHook;

#ifdef __cplusplus

class DECLSPEC_UUID("D4123048-A8D7-11D2-9D23-000001136428")
TraceDispMethodHook;
#endif
#endif /* __UDTRACEHOOKSVRLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

unsigned long             __RPC_USER  VARIANT_UserSize(     unsigned long __RPC_FAR *, unsigned long            , VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
void                      __RPC_USER  VARIANT_UserFree(     unsigned long __RPC_FAR *, VARIANT __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
