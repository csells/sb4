	
// TraceMethodHook.h : Declaration of the CTraceMethodHook

#ifndef __TRACEMETHODHOOK_H_
#define __TRACEMETHODHOOK_H_

#include "resource.h"       // main symbols

typedef std::vector<std::string> STRINGS ;

/////////////////////////////////////////////////////////////////////////////
// CTraceMethodHook
class ATL_NO_VTABLE CTraceMethodHook : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CTraceMethodHook, &CLSID_TraceMethodHook>,
    public IDelegatorHookMethods2,
	public ITraceMethodHook
{
public:
	CTraceMethodHook();

DECLARE_REGISTRY_RESOURCEID(IDR_TRACEMETHODHOOK)
DECLARE_NOT_AGGREGATABLE(CTraceMethodHook)
DECLARE_GET_CONTROLLING_UNKNOWN()

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CTraceMethodHook)
    COM_INTERFACE_ENTRY(IDelegatorHookMethods2)
	COM_INTERFACE_ENTRY(ITraceMethodHook)
	COM_INTERFACE_ENTRY_AGGREGATE(IID_IMarshal, m_pUnkMarshaler.p)
END_COM_MAP()

	HRESULT FinalConstruct()
	{
		return CoCreateFreeThreadedMarshaler(GetControllingUnknown(), &m_pUnkMarshaler.p);
	}

	void FinalRelease()
	{
		m_pUnkMarshaler.Release();
	}

private:
	CComPtr<IUnknown>   m_pUnkMarshaler;
    CComBSTR            m_bstrObjectName;
    CComBSTR            m_bstrInterfaceName;
    CGitCookie          m_gitTypeInfo;

	STRINGS 			m_methodNames ;

// IDelegatorHookMethods
public:
    STDMETHODIMP DelegatorPreprocess(DWORD nVtblIndex, void* pArgs, void** ppCookie);
    STDMETHODIMP DelegatorPostprocess(DWORD nVtblIndex, HRESULT hrFromInner, void* pCookie);

// ITraceMethodHook
public:
	STDMETHOD(SetObjectNameAndIID)(/*[in]*/ IUnknown* punkObj, /*[in]*/ LPCOLESTR pszObjectName, /*[in]*/ REFIID riid);
};

#endif //__TRACEMETHODHOOK_H_
