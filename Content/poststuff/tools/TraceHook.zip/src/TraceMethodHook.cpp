// TraceMethodHook.cpp : Implementation of CTraceMethodHook
#include "stdafx.h"
#include "UDTraceHookSvr.h"
#include "TraceMethodHook.h"

HRESULT InterfaceNameFromIID(REFIID riid, BSTR* pbstrName);
HRESULT InterfaceTypeInfoFromObjectAndIID(IUnknown* punk, REFIID riid, ITypeInfo** ppti);
HRESULT LoadTypeLibFromRegistry(REFIID iid, ITypeLib** pptl);
HRESULT MethodNameFromInterface(ITypeInfo* ptiItf, DWORD nVtblIndex, VOID * pStack, STRINGS& methodNames, BSTR* pbstrMethodName);
HRESULT ParseTypeInfoStack(FUNCDESC* pfd, void* pStack, CComBSTR& bstrStackDump);
HRESULT LoadMethodNames(BSTR itfName, STRINGS& names);
LPCOLESTR SafeOLESTR(LPCOLESTR psz);

/////////////////////////////////////////////////////////////////////////////
// CTraceMethodHook

CTraceMethodHook::CTraceMethodHook()
{
}

/////////////////////////////////////////////////////////////////////////////
// ITraceMethodHook

STDMETHODIMP CTraceMethodHook::SetObjectNameAndIID(
    IUnknown*   punkObj,
    LPCOLESTR   pszObjectName,
    REFIID      riid)
{
    ObjectLock  lock(this);
	m_bstrObjectName = pszObjectName;
    HR(InterfaceNameFromIID(riid, &m_bstrInterfaceName));

    CComPtr<ITypeInfo>  sptiItf;
    if( SUCCEEDED(InterfaceTypeInfoFromObjectAndIID(punkObj, riid, &sptiItf)) )
        m_gitTypeInfo = sptiItf;
	else
		LoadMethodNames(m_bstrInterfaceName, m_methodNames) ;

	return S_OK;
}

/////////////////////////////////////////////////////////////////////////////
// IDelegatorHookMethods

STDMETHODIMP CTraceMethodHook::DelegatorPreprocess(
    DWORD   nVtblIndex,
    void*   pArgs,
    void**  ppCookie)
{
    if( ppCookie ) *ppCookie = 0;
    ObjectLock  lock(this);

    // Trace the method call
    CComBSTR    bstrMethodName;
    CComPtr<ITypeInfo>  ptiItf;
    m_gitTypeInfo.GetInterface(&ptiItf); // It's OK if there isn't one
    MethodNameFromInterface(ptiItf, nVtblIndex, pArgs, m_methodNames, &bstrMethodName);

	std::wstringstream s ;
    s << GetCurrentThreadId() << L": " << SafeOLESTR(m_bstrObjectName) << L", "  ;
	s << SafeOLESTR(m_bstrInterfaceName) << L"::" << SafeOLESTR(bstrMethodName) << std::endl ;
    OutputDebugString(s.str().c_str());

    return S_OK;
}

STDMETHODIMP CTraceMethodHook::DelegatorPostprocess(
    DWORD   nVtblIndex,
    HRESULT hrFromInner,
    void*   pCookie)
{
    // This shouldn't be called, but if it is, return the inner's HR
    return hrFromInner;
}

/////////////////////////////////////////////////////////////////////////////
// Helpers

static
HRESULT InterfaceNameFromIID(REFIID riid, BSTR* pbstrName)
{
    *pbstrName = 0;
    USES_CONVERSION;

    // Attempt to find it in the interfaces section
    CRegKey key;
    HR(key.Open(HKEY_CLASSES_ROOT, _T("Interface"), KEY_READ));

    OLECHAR szGUID[40];
    StringFromGUID2(riid, szGUID, lengthof(szGUID));
    HR(key.Open(key, OLE2T(szGUID), KEY_READ));

    TCHAR   szName[128] = __T("");
    DWORD   dwType;
    DWORD   dw = sizeof(szName);
    RegQueryValueEx(key.m_hKey, (LPTSTR)NULL, NULL, &dwType, (LPBYTE)szName, &dw);

    // If there's a name, use that
    if( *szName )
    {
        *pbstrName = T2BSTR(szName);
    }
    // Otherwise, use the string form of the GUID
    else
    {
        *pbstrName = OLE2BSTR(szGUID);
    }

    return (*pbstrName ? S_OK : E_OUTOFMEMORY);
}

static
HRESULT LoadTypeLibFromRegistry(REFIID iid, ITypeLib** pptl)
{
    *pptl = 0;

	// If all else fails, try to find local typelib via HKCR/Interface/TypeLib registry entry
	TCHAR szTypelibKey[128];
	{
		wchar_t wszIID[60];
		StringFromGUID2( iid, wszIID, sizeof wszIID / sizeof *wszIID );

		#ifdef UNICODE
		TCHAR* pszIID = wszIID;
		#else
		TCHAR szIID[60];
		wcstombs( szIID, wszIID, sizeof szIID );
		TCHAR* pszIID = szIID;
		#endif
		
		wsprintf( szTypelibKey, __TEXT( "Interface\\%s\\TypeLib" ), pszIID );
	}
	HKEY hkeyTypelib = 0;
	DWORD dwErr = RegOpenKeyEx( HKEY_CLASSES_ROOT, szTypelibKey, 0, KEY_QUERY_VALUE, &hkeyTypelib );
	if ( ERROR_SUCCESS == dwErr )
	{
		TCHAR szLibid[128];
		DWORD cchLibid = sizeof szLibid / sizeof *szLibid;
		TCHAR szVer[128];
		DWORD cchVer = sizeof szVer / sizeof *szVer;
		dwErr = RegQueryValueEx( hkeyTypelib, __TEXT( "" ), 0, 0, reinterpret_cast<BYTE*>( szLibid ), &cchLibid );
		if ( ERROR_SUCCESS == dwErr )
			dwErr = RegQueryValueEx( hkeyTypelib, __TEXT( "Version" ), 0, 0, reinterpret_cast<BYTE*>( szVer ), &cchVer );
		RegCloseKey( hkeyTypelib );
		hkeyTypelib = 0;

		if ( ERROR_SUCCESS == dwErr )
		{
			GUID libid;
			#ifdef UNICODE
			wchar_t* pszLibid = szLibid;
			#else
			wchar_t wszLibid[60];
			mbstowcs( wszLibid, szLibid, sizeof wszLibid / sizeof *wszLibid );
			wchar_t* pszLibid = wszLibid;
			#endif

			HRESULT hr = CLSIDFromString( pszLibid, &libid );

			unsigned short nMajorVer = 0;
			unsigned short nMinorVer = 0;
			if ( SUCCEEDED( hr ) )
			{
				// parse version of library
				TCHAR* psz = szVer;
				bool bFoundMajorVer = false;
				while ( *psz )
				{
					if ( __TEXT( '.' ) == *psz )
					{
						*psz++ = __TEXT( '\0' );
						nMajorVer = _ttoi( szVer );
						bFoundMajorVer = true;
						break;
					}
					++psz;
				}
				if ( bFoundMajorVer && *psz )
					nMinorVer = _ttoi( psz );
				if ( !bFoundMajorVer )
					hr = E_FAIL;
			}
			if ( SUCCEEDED( hr ) )
			{
				// try the following common lcids, one after the other.
				hr = E_FAIL;
				ITypeLib* ptlb = 0;
				LCID lcid[] = { 0, 9, 409 };
				int cLangs = sizeof lcid / sizeof *lcid;
				for ( int i = 0; i < cLangs && FAILED( hr ); ++i )
					hr = LoadRegTypeLib( libid, nMajorVer, nMinorVer, lcid[i], &ptlb );

				if ( SUCCEEDED( hr ) )
				{
					*pptl = ptlb;
					ptlb = 0;
				}
			}
		}
	}

	return *pptl ? S_OK : E_FAIL;
}


static
HRESULT InterfaceTypeInfoFromObjectAndIID(
    IUnknown*   punk,
    REFIID      riid,
    ITypeInfo** ppti)
{
    HRESULT             hr = E_FAIL;

	// SZF : 1/22/2000 : Finally realized why people are reporting that some interfaces are not
	//					 showing the method names, these first two attempts to get the ITypeInfo for
	//					 the interface will fail if the typelibrary for the interface is different
	//					 to the typelibrary of the coclass
	//					 so, we check that the ITypeLib returned can actually provide the ITypeInfo
	//					 before moving on.

	
    // Try IProvideClassInfo
    if( FAILED(hr) )
    {
        CComQIPtr<IProvideClassInfo> sppci = punk;
        if( sppci )
        {
            CComPtr<ITypeInfo>  sptiClass;
            hr = sppci->GetClassInfo(&sptiClass);
            if( SUCCEEDED(hr) )
            {
			    CComPtr<ITypeLib>   sptl;
                UINT zero = 0;
                hr = sptiClass->GetContainingTypeLib(&sptl, &zero);
				if ( SUCCEEDED(hr) )
					hr = sptl->GetTypeInfoOfGuid(riid, ppti) ;
            }
        }
    }

    // Try IDispatch
    if( FAILED(hr) )
    {
        CComQIPtr<IDispatch> spdisp = punk;
        if( spdisp )
        {
            // Get the typeinfo of the dispatch interface
            CComPtr<ITypeInfo> sptiDispatch;
            hr = spdisp->GetTypeInfo(0, 0, &sptiDispatch);
            if( SUCCEEDED(hr) )
            {
                // Get the containing typelib
			    CComPtr<ITypeLib>   sptl;
                UINT zero = 0;
                hr = sptiDispatch->GetContainingTypeLib(&sptl, &zero);
				if ( SUCCEEDED(hr) )
					hr = sptl->GetTypeInfoOfGuid(riid, ppti) ;
            }
        }
    }

    // Try the registry
    if( FAILED(hr) )
    {
	    CComPtr<ITypeLib>   sptl;
        hr = LoadTypeLibFromRegistry(riid, &sptl);
	    if( SUCCEEDED(hr) )
		    hr = sptl->GetTypeInfoOfGuid(riid, ppti);
    }
    return hr;
}

static
HRESULT MethodNameFromInterface(
    ITypeInfo*  ptiItf,
    DWORD       nVtblIndex,
	void *      pStack,
	STRINGS&	methodNames,
    BSTR*       pbstrMethodName)
{
    *pbstrMethodName = 0;

    // If we have the typeinfo, lookup the function name
    if( ptiItf )
    {
        UINT nMethodIndex = 0;
        TYPEATTR*   pta = 0;
        HRESULT     hr = ptiItf->GetTypeAttr(&pta);
        if( SUCCEEDED(hr) )
        {
            switch( pta->typekind )
            {
            case TKIND_INTERFACE:	// custom interfaces
                // method indeces start just beyond IUnknown
                nMethodIndex = nVtblIndex - 3;
                break;
            case TKIND_DISPATCH:	// duals, dispinterfaces
                // method indeces start at top of vtbl
                nMethodIndex = nVtblIndex;
                break;
            default:
                // should never get here
                _ASSERTE(FALSE && "TypeInfo uses unsupported TYPEKIND");
                hr = E_UNEXPECTED;
                break;
            }
        }

        if( SUCCEEDED(hr) )
        {
            // based on the index of the method, look up the logical id
            FUNCDESC* pfd = 0;
            hr = ptiItf->GetFuncDesc(nMethodIndex, &pfd);
            if( SUCCEEDED(hr) )
            {
				CComBSTR bstrMethodName ;
				CComBSTR bstrProperty ;
				if ( INVOKE_PROPERTYGET == pfd->invkind )
					bstrProperty = L"get_" ;
				if ( INVOKE_PROPERTYPUT == pfd->invkind || INVOKE_PROPERTYPUTREF == pfd->invkind )
					bstrProperty = L"put_" ;
                hr = ptiItf->GetDocumentation(pfd->memid, &bstrMethodName, 0, 0, 0);
				hr = ParseTypeInfoStack(pfd, pStack, bstrMethodName) ;		
                ptiItf->ReleaseFuncDesc(pfd);
				if ( ! bstrProperty )
					*pbstrMethodName = bstrMethodName.Detach() ;
				else
				{					
					bstrProperty += bstrMethodName ;
					*pbstrMethodName = bstrProperty.Detach() ;
				}	
            }
        }

        ptiItf->ReleaseTypeAttr(pta);
    }

    // If all else fails, just dump the index of the method
    if( !*pbstrMethodName )
    {
		// but check the methodnames collecton first
		if ( methodNames.size() > nVtblIndex )
			*pbstrMethodName = A2BSTR(methodNames[nVtblIndex].c_str()) ;
		else
		{
		    TCHAR   szMethodName[40];
		    wsprintf(szMethodName, __T("[method%d]()"), nVtblIndex);
			*pbstrMethodName = T2BSTR(szMethodName);
		}
    }

    return *pbstrMethodName ? S_OK : E_OUTOFMEMORY;
}

static
LPCOLESTR SafeOLESTR(LPCOLESTR psz)
{
    return (psz ? psz : OLESTR(""));
}


//
// Simon Fell (simon@zaks.demon.co.uk)
//

#define SET_STK_SIZE(b) if ( -1 == cSizeOnStack ) cSizeOnStack = b ;

static
HRESULT ParseTypeInfoStack(
	FUNCDESC* pfd,
	void*     pStack,
	CComBSTR& bstrStackDump)
{
	short cParams = pfd->cParams ;
	short cSizeOnStack = -1 ;
	ELEMDESC * pedParam = pfd->lprgelemdescParam ;
	std::wstringstream  wsStackDump ;
	VARTYPE vt ;
	void * pParam ;
	wsStackDump << L"(";
	while ( cParams-- )
	{
		if ( cSizeOnStack > -1 )
			wsStackDump << L", " ;
		cSizeOnStack = -1 ;

		vt = pedParam->tdesc.vt ;
		// de-ref pointer type 
		if ( VT_PTR == vt )
		{
			pParam = *(void **)pStack ;
			vt = pedParam->tdesc.lptdesc->vt ;
			cSizeOnStack = 4 ;
		}
		else
			pParam = pStack ;
		
		// is this an [out] param ?
		if ( IDLFLAG_FOUT & pedParam->idldesc.wIDLFlags )
		{
			if ( IDLFLAG_FRETVAL & pedParam->idldesc.wIDLFlags )
				wsStackDump << L"[out,retval]" ;
			else
				wsStackDump << L"[out]" ;
			cSizeOnStack = 4 ;
		}
		else
		{
			// paramater is some sort of [in]
			if ( pedParam->idldesc.wIDLFlags & IDLFLAG_FIN )
			{
				// dump string of this param, and set the number of bytes used on the stack for this param.
				switch ( vt )
				{

				case ( VT_UI8 )	:		// documented as valid types for a TYPEDESC
				case ( VT_I8 ) :		// but doesn't appear to be [ole automation] type
				case ( VT_DECIMAL ) : 
				case ( VT_ERROR )	: 
				case ( VT_USERDEFINED ) : 
				case ( VT_LPSTR ) :		
				case ( VT_LPWSTR ) : 
				case ( VT_VOID ) : 
					wsStackDump << L"[Unexpected Type=" << vt << L"]" ;
					break ;

				case ( VT_SAFEARRAY ) : 
					wsStackDump << L"[Safe Array]" ;
					SET_STK_SIZE(4) ;
					break ;

				case ( VT_UI1 ) : 
					wsStackDump << *(BYTE *)pParam ;
					SET_STK_SIZE(4) ; 
					break ;

				case ( VT_UI2 )	: 
				{
					// WORD * is a unsigned short *
					// and so is treated as a WCHAR *
					// which is not what we want
					DWORD x = *(WORD *)pParam ;
					wsStackDump << x ;
					SET_STK_SIZE(4) ; 
					break ;
				}

				case ( VT_UI4 )	: 
					wsStackDump << *(DWORD *)pParam ;
					SET_STK_SIZE(4) ; 
					break ;

				case ( VT_I1 ): 
					wsStackDump << *(char *)pParam ;
					SET_STK_SIZE(4) ; 
					break ;

				case ( VT_I2 ) : 
					wsStackDump << *(short *)pParam ;
					SET_STK_SIZE(4) ;
					break ;

				case ( VT_I4 ) : 
					wsStackDump << *(long *)pParam ;
					SET_STK_SIZE(4) ;
					break ;

				case ( VT_R4 ) : 
					wsStackDump << *(float *)pParam ;
					SET_STK_SIZE(4) ; 
					break ;

				case ( VT_R8 ) : 
					wsStackDump << *(double *)pParam ;
					SET_STK_SIZE(8) ; 
					break ;

				case ( VT_BOOL ) : 
					wsStackDump << ( VARIANT_TRUE == *(VARIANT_BOOL *)pParam ? L"TRUE" : L"FALSE" ) ;
					SET_STK_SIZE(4) ; 
					break ;

				case ( VT_CY )	: 
				{
					CComBSTR bstrCY ;
					if(SUCCEEDED(VarBstrFromCy ( *(CURRENCY *)pParam, GetThreadLocale(), 0 , &bstrCY )))
						wsStackDump << (LPWSTR)bstrCY ;
					else
						wsStackDump << L"[Unknown Currency Value]" ;
					SET_STK_SIZE(8) ; 
					break ;
				}

				case ( VT_DATE )	: 
				{
					CComBSTR bstrDate ;
					if(SUCCEEDED(VarBstrFromDate ( *(DATE *)pParam, GetThreadLocale(), 0, &bstrDate )))
						wsStackDump << L"'" << (LPWSTR)bstrDate << L"'" ;
					else
						wsStackDump << L"[Unknown Date Value]" ;
					SET_STK_SIZE(8) ;
					break ;
				}

				case ( VT_BSTR )	:
					// s.fell 19 May 1999
					if ( *(BSTR *)pParam )
						wsStackDump << L"\"" << *(BSTR *)pParam << L"\"" ;
					else
						wsStackDump << L"[NULL]" ;
					SET_STK_SIZE(4) ;
					break ;

				case (VT_DISPATCH) : 
					wsStackDump << L"[IDispatch] 0x" << *(void **)pParam ;
					SET_STK_SIZE(4) ; 
					break ;

				case ( VT_UNKNOWN ) : 
					wsStackDump << L"[IUnknown] 0x" << *(void **)pParam ;
					SET_STK_SIZE(4) ; 
					break ;

				case ( VT_VARIANT ) : 
				{
					CComVariant v(*(VARIANT *)pParam) ;
					if(SUCCEEDED(v.ChangeType(VT_BSTR)))
						wsStackDump << L"\"" << v.bstrVal << L"\"";
					else
						wsStackDump << "[Unknown VARIANT Value]" ;
					SET_STK_SIZE(4) ;
					break ;
				}

				case ( VT_INT )	: 
					wsStackDump << *(int *)pParam ;
					SET_STK_SIZE(4) ;
					break ;

				case ( VT_UINT ) : 
					wsStackDump << *(UINT *)pParam ;
					SET_STK_SIZE(4) ;
					break ;

				case ( VT_HRESULT) : 
					wsStackDump << *(HRESULT *)pParam ;
					SET_STK_SIZE(4) ;
					break ;

				default : 
					break ;
				}
			}
		}
		if ( -1 == cSizeOnStack )	// a parameter we don't know the size of
			break ;					// not safe to carry on
		pStack = (BYTE *)pStack + cSizeOnStack ;
		pedParam++ ;
	}
	wsStackDump << L")" ;
	bstrStackDump.Append(wsStackDump.str().c_str()) ;
	return S_OK ;
}

HRESULT LoadMethodNames(BSTR itfName, STRINGS& names)
{
	USES_CONVERSION ;
	CComPtr<IStorage> pStorage ;
	TCHAR sysDir[MAX_PATH] ;
	GetSystemDirectory(sysDir, MAX_PATH ) ;
	lstrcat ( sysDir, _T("\\itfs.bin")) ;
	HRESULT hr = StgOpenStorage(	T2W(sysDir), 
									NULL, 
									STGM_DIRECT | STGM_READ | STGM_SHARE_DENY_WRITE, 
									NULL, 
									0, 
									&pStorage);

	if (FAILED(hr)) return hr;
	CComPtr<IStream> pStm ;
	hr = pStorage->OpenStream(itfName, 0, STGM_DIRECT | STGM_READ | STGM_SHARE_EXCLUSIVE, 0, &pStm);
	if (FAILED(hr)) return hr ;
	DWORD cbItems, cbLen ;
	pStm->Read(&cbItems, sizeof(DWORD), 0) ;
	char buff[500] ;
	names.clear() ;
	while ( cbItems-- )
	{
		pStm->Read(&cbLen, sizeof(DWORD), 0 );
		pStm->Read(&buff, cbLen, 0 ) ;
		buff[cbLen] = 0 ;
		strcat ( buff, "()") ;
		names.push_back(buff) ;
	}
	return S_OK ;
}