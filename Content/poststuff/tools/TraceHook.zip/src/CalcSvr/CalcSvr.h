/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Fri Sep 17 11:37:35 1999
 */
/* Compiler settings for C:\TEMP\simon\tracehook2\src\CalcSvr\CalcSvr.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __CalcSvr_h__
#define __CalcSvr_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __ICalc_FWD_DEFINED__
#define __ICalc_FWD_DEFINED__
typedef interface ICalc ICalc;
#endif 	/* __ICalc_FWD_DEFINED__ */


#ifndef __Calc_FWD_DEFINED__
#define __Calc_FWD_DEFINED__

#ifdef __cplusplus
typedef class Calc Calc;
#else
typedef struct Calc Calc;
#endif /* __cplusplus */

#endif 	/* __Calc_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

/* interface __MIDL_itf_CalcSvr_0000 */
/* [local] */ 

typedef struct  Point
    {
    long x;
    long y;
    }	Point;



extern RPC_IF_HANDLE __MIDL_itf_CalcSvr_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_CalcSvr_0000_v0_0_s_ifspec;

#ifndef __ICalc_INTERFACE_DEFINED__
#define __ICalc_INTERFACE_DEFINED__

/* interface ICalc */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ICalc;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("43B6EC68-A742-11D2-90EB-00104B2168FE")
    ICalc : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Add( 
            /* [in] */ long n) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Sum( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Sum( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE TypesTest0( 
            /* [in] */ long l1,
            /* [in] */ short s2,
            /* [in] */ BSTR bstr,
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE TypesTest1( 
            /* [in] */ BYTE b1,
            /* [in] */ double d1,
            /* [in] */ float f1,
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE TypesTest2( 
            /* [in] */ VARIANT_BOOL vb1,
            /* [in] */ DATE s2,
            /* [in] */ VARIANT v,
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE TypesTest3( 
            /* [in] */ BSTR __RPC_FAR *pbstr,
            /* [in] */ double __RPC_FAR *pd,
            /* [in] */ long __RPC_FAR *plong,
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE TypesTest4( 
            /* [in] */ IDispatch __RPC_FAR *pDisp,
            /* [in] */ IUnknown __RPC_FAR *pUnk,
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE TypesTest5( 
            /* [out] */ BSTR __RPC_FAR *pBstr1,
            /* [in] */ unsigned char __RPC_FAR *pChar,
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE TypesTest6( 
            /* [in] */ INT theint,
            /* [in] */ UINT theuint,
            /* [in] */ HRESULT hr,
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE TypesTest7( 
            /* [in] */ WORD w,
            /* [out][in] */ DWORD __RPC_FAR *pdw,
            /* [out] */ long __RPC_FAR *pl,
            /* [in] */ long p) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE TypesTest8( 
            /* [in] */ CURRENCY c,
            /* [in] */ SAFEARRAY __RPC_FAR * sa,
            /* [in] */ long l) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ICalcVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ICalc __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ICalc __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ICalc __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ICalc __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ICalc __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ICalc __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ICalc __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Add )( 
            ICalc __RPC_FAR * This,
            /* [in] */ long n);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Sum )( 
            ICalc __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Sum )( 
            ICalc __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *TypesTest0 )( 
            ICalc __RPC_FAR * This,
            /* [in] */ long l1,
            /* [in] */ short s2,
            /* [in] */ BSTR bstr,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *TypesTest1 )( 
            ICalc __RPC_FAR * This,
            /* [in] */ BYTE b1,
            /* [in] */ double d1,
            /* [in] */ float f1,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *TypesTest2 )( 
            ICalc __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL vb1,
            /* [in] */ DATE s2,
            /* [in] */ VARIANT v,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *TypesTest3 )( 
            ICalc __RPC_FAR * This,
            /* [in] */ BSTR __RPC_FAR *pbstr,
            /* [in] */ double __RPC_FAR *pd,
            /* [in] */ long __RPC_FAR *plong,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *TypesTest4 )( 
            ICalc __RPC_FAR * This,
            /* [in] */ IDispatch __RPC_FAR *pDisp,
            /* [in] */ IUnknown __RPC_FAR *pUnk,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *TypesTest5 )( 
            ICalc __RPC_FAR * This,
            /* [out] */ BSTR __RPC_FAR *pBstr1,
            /* [in] */ unsigned char __RPC_FAR *pChar,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *TypesTest6 )( 
            ICalc __RPC_FAR * This,
            /* [in] */ INT theint,
            /* [in] */ UINT theuint,
            /* [in] */ HRESULT hr,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *TypesTest7 )( 
            ICalc __RPC_FAR * This,
            /* [in] */ WORD w,
            /* [out][in] */ DWORD __RPC_FAR *pdw,
            /* [out] */ long __RPC_FAR *pl,
            /* [in] */ long p);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *TypesTest8 )( 
            ICalc __RPC_FAR * This,
            /* [in] */ CURRENCY c,
            /* [in] */ SAFEARRAY __RPC_FAR * sa,
            /* [in] */ long l);
        
        END_INTERFACE
    } ICalcVtbl;

    interface ICalc
    {
        CONST_VTBL struct ICalcVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ICalc_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICalc_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICalc_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ICalc_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ICalc_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ICalc_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ICalc_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ICalc_Add(This,n)	\
    (This)->lpVtbl -> Add(This,n)

#define ICalc_get_Sum(This,pVal)	\
    (This)->lpVtbl -> get_Sum(This,pVal)

#define ICalc_put_Sum(This,newVal)	\
    (This)->lpVtbl -> put_Sum(This,newVal)

#define ICalc_TypesTest0(This,l1,s2,bstr,pVal)	\
    (This)->lpVtbl -> TypesTest0(This,l1,s2,bstr,pVal)

#define ICalc_TypesTest1(This,b1,d1,f1,pVal)	\
    (This)->lpVtbl -> TypesTest1(This,b1,d1,f1,pVal)

#define ICalc_TypesTest2(This,vb1,s2,v,pVal)	\
    (This)->lpVtbl -> TypesTest2(This,vb1,s2,v,pVal)

#define ICalc_TypesTest3(This,pbstr,pd,plong,pVal)	\
    (This)->lpVtbl -> TypesTest3(This,pbstr,pd,plong,pVal)

#define ICalc_TypesTest4(This,pDisp,pUnk,pVal)	\
    (This)->lpVtbl -> TypesTest4(This,pDisp,pUnk,pVal)

#define ICalc_TypesTest5(This,pBstr1,pChar,pVal)	\
    (This)->lpVtbl -> TypesTest5(This,pBstr1,pChar,pVal)

#define ICalc_TypesTest6(This,theint,theuint,hr,pVal)	\
    (This)->lpVtbl -> TypesTest6(This,theint,theuint,hr,pVal)

#define ICalc_TypesTest7(This,w,pdw,pl,p)	\
    (This)->lpVtbl -> TypesTest7(This,w,pdw,pl,p)

#define ICalc_TypesTest8(This,c,sa,l)	\
    (This)->lpVtbl -> TypesTest8(This,c,sa,l)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICalc_Add_Proxy( 
    ICalc __RPC_FAR * This,
    /* [in] */ long n);


void __RPC_STUB ICalc_Add_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ICalc_get_Sum_Proxy( 
    ICalc __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ICalc_get_Sum_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ICalc_put_Sum_Proxy( 
    ICalc __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ICalc_put_Sum_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICalc_TypesTest0_Proxy( 
    ICalc __RPC_FAR * This,
    /* [in] */ long l1,
    /* [in] */ short s2,
    /* [in] */ BSTR bstr,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB ICalc_TypesTest0_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICalc_TypesTest1_Proxy( 
    ICalc __RPC_FAR * This,
    /* [in] */ BYTE b1,
    /* [in] */ double d1,
    /* [in] */ float f1,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB ICalc_TypesTest1_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICalc_TypesTest2_Proxy( 
    ICalc __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL vb1,
    /* [in] */ DATE s2,
    /* [in] */ VARIANT v,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB ICalc_TypesTest2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICalc_TypesTest3_Proxy( 
    ICalc __RPC_FAR * This,
    /* [in] */ BSTR __RPC_FAR *pbstr,
    /* [in] */ double __RPC_FAR *pd,
    /* [in] */ long __RPC_FAR *plong,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB ICalc_TypesTest3_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICalc_TypesTest4_Proxy( 
    ICalc __RPC_FAR * This,
    /* [in] */ IDispatch __RPC_FAR *pDisp,
    /* [in] */ IUnknown __RPC_FAR *pUnk,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB ICalc_TypesTest4_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICalc_TypesTest5_Proxy( 
    ICalc __RPC_FAR * This,
    /* [out] */ BSTR __RPC_FAR *pBstr1,
    /* [in] */ unsigned char __RPC_FAR *pChar,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB ICalc_TypesTest5_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICalc_TypesTest6_Proxy( 
    ICalc __RPC_FAR * This,
    /* [in] */ INT theint,
    /* [in] */ UINT theuint,
    /* [in] */ HRESULT hr,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB ICalc_TypesTest6_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICalc_TypesTest7_Proxy( 
    ICalc __RPC_FAR * This,
    /* [in] */ WORD w,
    /* [out][in] */ DWORD __RPC_FAR *pdw,
    /* [out] */ long __RPC_FAR *pl,
    /* [in] */ long p);


void __RPC_STUB ICalc_TypesTest7_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICalc_TypesTest8_Proxy( 
    ICalc __RPC_FAR * This,
    /* [in] */ CURRENCY c,
    /* [in] */ SAFEARRAY __RPC_FAR * sa,
    /* [in] */ long l);


void __RPC_STUB ICalc_TypesTest8_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ICalc_INTERFACE_DEFINED__ */



#ifndef __CALCSVRLib_LIBRARY_DEFINED__
#define __CALCSVRLib_LIBRARY_DEFINED__

/* library CALCSVRLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_CALCSVRLib;

EXTERN_C const CLSID CLSID_Calc;

#ifdef __cplusplus

class DECLSPEC_UUID("43B6EC69-A742-11D2-90EB-00104B2168FE")
Calc;
#endif
#endif /* __CALCSVRLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

unsigned long             __RPC_USER  LPSAFEARRAY_UserSize(     unsigned long __RPC_FAR *, unsigned long            , LPSAFEARRAY __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  LPSAFEARRAY_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, LPSAFEARRAY __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  LPSAFEARRAY_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, LPSAFEARRAY __RPC_FAR * ); 
void                      __RPC_USER  LPSAFEARRAY_UserFree(     unsigned long __RPC_FAR *, LPSAFEARRAY __RPC_FAR * ); 

unsigned long             __RPC_USER  VARIANT_UserSize(     unsigned long __RPC_FAR *, unsigned long            , VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
void                      __RPC_USER  VARIANT_UserFree(     unsigned long __RPC_FAR *, VARIANT __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
