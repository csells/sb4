// Calc.h : Declaration of the CCalc

#ifndef __CALC_H_
#define __CALC_H_

#include "resource.h"       // main symbols

#include <tracehookcli.h>

/////////////////////////////////////////////////////////////////////////////
// CCalc
class ATL_NO_VTABLE CCalc : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CCalc, &CLSID_Calc>,
	public IDispatchImpl<ICalc, &IID_ICalc, &LIBID_CALCSVRLib>
{
public:
	CCalc()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_CALC)
DECLARE_NOT_AGGREGATABLE(CCalc)
DECLARE_PROTECT_FINAL_CONSTRUCT()

//DECLARE_CLASSFACTORY_DEBUGTRACER(CCalc, "calc")

BEGIN_COM_MAP(CCalc)
	COM_INTERFACE_ENTRY(ICalc)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// ICalc
public:
	STDMETHOD(TypesTest0)(long l1, short s2, BSTR bstr, BSTR * pVal);
	STDMETHOD(TypesTest1)(BYTE b1, double d1, float f1, BSTR * pVal);
	STDMETHOD(TypesTest2)(VARIANT_BOOL vb1, DATE s2, VARIANT v, BSTR * pVal);
	STDMETHOD(TypesTest3)(BSTR * pbstr, double * pd, long * plong, BSTR * pVal);
	STDMETHOD(TypesTest4)(IDispatch * pDisp, IUnknown * pUnk /*, CY ct*/, BSTR * pVal);
	STDMETHOD(TypesTest5)(/*[in,out] BSTR ** ppBstr,*/ BSTR * pBstr1, BYTE * pChar, BSTR * pVal);
	STDMETHOD(TypesTest6)(INT theint, UINT uint, HRESULT hr, BSTR * pVal ) ;
	STDMETHOD(TypesTest7)(WORD w, DWORD * pdw, long * pl, long p) ;
	STDMETHOD(TypesTest8)( CURRENCY c, SAFEARRAY * psa, long l ) ;
	STDMETHOD(TypesTest9)(Point* pt) ;

	STDMETHOD(get_Sum)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_Sum)(/*[in]*/ long newVal);
	STDMETHOD(Add)(/*[in]*/ long n);
private:
	long m_nSum;
};

#endif //__CALC_H_
