// Calc.cpp : Implementation of CCalc
#include "stdafx.h"
#include "CalcSvr.h"
#include "Calc.h"

/////////////////////////////////////////////////////////////////////////////
// CCalc


STDMETHODIMP CCalc::Add(long n)
{
	return put_Sum(m_nSum + n);
}

STDMETHODIMP CCalc::get_Sum(long *pVal)
{
    return (*pVal = m_nSum), S_OK;
}

STDMETHODIMP CCalc::put_Sum(long newVal)
{
    return (m_nSum = newVal), S_OK;
}

STDMETHODIMP CCalc::TypesTest0(long l1, short s2, BSTR bstr, BSTR *pVal)
{
	if ( NULL == pVal ) return E_POINTER ;
	*pVal = SysAllocString(L"TypesTest0() Wooo Hoo") ;
	return S_OK;
}

STDMETHODIMP CCalc::TypesTest1(BYTE b1, double d1, float f1, BSTR * pVal)
{
	if ( NULL == pVal ) return E_POINTER ;
	*pVal = SysAllocString(L"TypesTest1() Wooo Hoo") ;
	return S_OK ;
}

STDMETHODIMP CCalc::TypesTest2(VARIANT_BOOL vb1, DATE s2, VARIANT v, BSTR * pVal)
{
	if ( NULL == pVal ) return E_POINTER ;
	*pVal = SysAllocString(L"TypesTest2() Wooo Hoo") ;
	return S_OK ;
}

STDMETHODIMP CCalc::TypesTest3(BSTR * pbstr, double * pd, long * plong, BSTR * pVal)
{
	if ( NULL == pVal ) return E_POINTER ;
	*pVal = SysAllocString(L"TypesTest3() Wooo Hoo") ;
	return S_OK ;
}

STDMETHODIMP CCalc::TypesTest4(IDispatch * pDisp, IUnknown * pUnk /*, CY ct*/, BSTR * pVal)
{
	if ( NULL == pVal ) return E_POINTER ;
	*pVal = SysAllocString(L"TypesTest4() Wooo Hoo") ;
	return S_OK ;
}

STDMETHODIMP CCalc::TypesTest5(/*[in,out] BSTR ** ppBstr,*/ BSTR * pBstr1, BYTE * pChar, BSTR * pVal)
{
	if ( NULL == pVal ) return E_POINTER ;
	*pVal = SysAllocString(L"TypesTest5() Wooo Hoo") ;
	return S_OK ;
}

STDMETHODIMP CCalc::TypesTest6(INT theint, UINT uint, HRESULT hr, BSTR * pVal ) 
{
	if ( NULL == pVal ) return E_POINTER ;
	*pVal = SysAllocString(L"TypesTest6() Wooo Hoo") ;
	return S_OK ;
}

STDMETHODIMP CCalc::TypesTest7(WORD w, DWORD * pdw, long * pl, long p) 
{
	return S_OK ;
}

STDMETHODIMP CCalc::TypesTest8( CURRENCY c, SAFEARRAY * psa, long l ) 
{
	return S_OK ;
}


STDMETHODIMP CCalc::TypesTest9(Point* pt)
{
    return S_OK;
}

