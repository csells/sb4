// AddToDefs.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

using namespace std;
typedef vector<string> STRINGS ;

int main(int argc, char* argv[])
{
	USES_CONVERSION;

	CoInitialize(NULL) ;

	if (argc != 2 )
	{
		cout << argv[0] << "\n" << "Must specify an output filename\n" ;
		return -1;
	}

	HRESULT hr ;
	CComPtr<IStorage> pStorage ;
	WCHAR * szOutput = A2W(argv[1]) ;
	hr = StgOpenStorage( szOutput, NULL,STGM_READWRITE | STGM_SHARE_EXCLUSIVE, NULL, 0, &pStorage ) ;
	if (FAILED(hr))
		hr = StgCreateDocfile(szOutput, STGM_CREATE | STGM_READWRITE | STGM_SHARE_EXCLUSIVE, 0, &pStorage) ;

	if(FAILED(hr))
	{
		cout  << "Unable to create output file (hr=" << hr << ")\n" ;
		return -1;
	}

	char buff[256] ;
	CComPtr<IStream> pStm ;
	bool bNewItf = true ;
	DWORD cbItems =0 ;
	DWORD cbLen   =0 ;
	STRINGS methodnames ;
	try
	{
		while( cin.getline(buff,250) )
		{
			ATLTRACE("%s\n", buff) ;
			if ( bNewItf )
			{
				if ( pStm )
				{
					cbItems = methodnames.size() ;
					pStm->Write(&cbItems, sizeof(DWORD), 0 ) ;
					STRINGS::const_iterator it ;
					for ( it = methodnames.begin() ; it != methodnames.end() ; it++ )
					{
						cbLen = it->size() ;
						pStm->Write(&cbLen, sizeof(DWORD), 0 ) ;
						pStm->Write(it->c_str(), cbLen, 0 ) ;
					}
					pStm.Release() ;
					methodnames.clear() ;
				}
				if ( lstrlen(buff) != 0 )
					hr = pStorage->CreateStream(A2W(buff), STGM_CREATE | STGM_WRITE | STGM_SHARE_EXCLUSIVE, 0, 0, &pStm) ;
				bNewItf = false ;
			}
			else
			{
				if ( lstrlen(buff) == 0 )
					bNewItf = true ;
				else
					methodnames.push_back(buff) ;
			}
		}
	}
	catch(...)
	{
	}
	pStm.Release();
	pStorage.Release() ;
	CoUninitialize();
	return 0 ;
}

