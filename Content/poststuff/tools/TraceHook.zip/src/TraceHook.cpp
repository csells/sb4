// TraceHook.cpp : Implementation of CTraceHook
#include "stdafx.h"
#include "UDTraceHookSvr.h"
#include "TraceHook.h"
#include "TraceMethodHook.h"
#include "TraceDispMethodHook.h"

/////////////////////////////////////////////////////////////////////////////
// CTraceHook

CTraceHook::CTraceHook() : m_bstrObjectName(OLESTR("<object>")), m_bDirty(false)
{
}

// IDelegatorHookQI
STDMETHODIMP CTraceHook::Init(
    IUnknown*   pUnkInner)
{
    // Nothing to init
    return S_OK;
}

STDMETHODIMP CTraceHook::OnFirstDelegatorQIFor(
    REFIID      iid,
    IUnknown*   pItfInner,
    DWORD*      pgrfDelegatorHookOptions,
    REFIID      iidMethodHook,
    void**      ppMethodHook)
{
    ObjectLock  lock(this);

	*pgrfDelegatorHookOptions = 0 ;
	*ppMethodHook = 0 ;

	if (InlineIsEqualGUID(iid, IID_IDispatch))
	{
		// Create a method hook object and init it with object name
		CComPtr<ITraceDispMethodHook> spMethodHook ;
		HR(CTraceDispMethodHook::CreateInstance(&spMethodHook));
		HR(spMethodHook->SetObjectName(m_bstrObjectName)) ;

		// Let UD know we'd like to pre & post process and give it the method hook
		HR(spMethodHook->QueryInterface(iidMethodHook, ppMethodHook));
		*pgrfDelegatorHookOptions = DHO_PREPROCESS_METHODS | DHO_POSTPROCESS_METHODS ;
	}
	else
	{
		// Create a method hook object and init it w/ object name and IID
		CComPtr<ITraceMethodHook>   spMethodHook;
		HR(CTraceMethodHook::CreateInstance(&spMethodHook));
		HR(spMethodHook->SetObjectNameAndIID(pItfInner, m_bstrObjectName, iid));

		// Let UD know we'd like to preprocess and give it the method hook
		HR(spMethodHook->QueryInterface(iidMethodHook, ppMethodHook));
		*pgrfDelegatorHookOptions = DHO_PREPROCESS_METHODS;
	}
    return S_OK;
}

// ITraceHook
STDMETHODIMP CTraceHook::SetObjectName(LPCOLESTR pszObjectName)
{
    ObjectLock  lock(this);
	m_bstrObjectName = pszObjectName;
	m_bDirty = true ;
	return S_OK;
}

// ITraceHookFactory
STDMETHODIMP CTraceHook::ComTrace(BSTR bstrObjectName, VARIANT * pVarObject)
{
	if ( NULL == pVarObject ) return E_POINTER ;

	// make sure this is an object
	CComVariant vObject ;
	HR(vObject.ChangeType ( VT_UNKNOWN, pVarObject )) ;

    ObjectLock  lock(this);

	// create the delegator
	CComPtr<IDelegatorFactory> pDel ;
	HR(CoGetClassObject ( __uuidof(CoDelegator21), CLSCTX_INPROC, 0, __uuidof(IDelegatorFactory), (void **)&pDel ));

    CComPtr<ITraceHook> spHook ;
	spHook.CoCreateInstance ( CLSID_TraceHook ) ;
	HR(spHook->SetObjectName(bstrObjectName && *bstrObjectName ? bstrObjectName : OLESTR("<object>")));

    // Delegate!
	IUnknown * pNewUnk = NULL ;
    HR(pDel->CreateDelegator(0, vObject.punkVal, 0, spHook, 0, IID_IUnknown, (void**)&pNewUnk));

	// update the incoming pointer without breaking anything
	if ( VT_BYREF == (pVarObject->vt & VT_BYREF) )
	{
		if ( VT_UNKNOWN == (pVarObject->vt & VT_UNKNOWN) )
		{
			(*pVarObject->ppunkVal)->Release() ;
			(*pVarObject->ppunkVal) = pNewUnk ;
		}
		else if ( VT_DISPATCH == (pVarObject->vt & VT_DISPATCH) )
		{
			(*pVarObject->ppdispVal)->Release() ;
			pNewUnk->QueryInterface(IID_IDispatch, (void **)pVarObject->ppdispVal) ;
			pNewUnk->Release() ;
		}
	}
	else
	{
		if ( VT_DISPATCH == (pVarObject->vt & VT_DISPATCH))
		{
			VariantClear ( pVarObject ) ;
			pVarObject->vt = VT_DISPATCH ;
			pNewUnk->QueryInterface(IID_IDispatch, (void **)&pVarObject->pdispVal) ;
			pNewUnk->Release() ;
		}
		else
		{
			pVarObject->punkVal->Release() ;
			pVarObject->punkVal = pNewUnk ;
		}
	}
	return S_OK;
}

// IPersist

STDMETHODIMP CTraceHook::GetClassID(CLSID * pclsid)
{
	if ( NULL == pclsid ) return E_POINTER ;
	*pclsid = GetObjectCLSID() ;
	return S_OK ;
}

// IPersistPropertyBag

STDMETHODIMP CTraceHook::InitNew()
{
    ObjectLock  lock(this);
	m_bstrObjectName = OLESTR("<object>");
	return S_OK ;
}

STDMETHODIMP CTraceHook::Load(IPropertyBag * pBag, IErrorLog * pLog )
{
	CComVariant vName ;
	HR(pBag->Read ( OLESTR("name"), &vName, pLog )) ;
	vName.ChangeType (VT_BSTR) ;
    ObjectLock  lock(this);
	m_bstrObjectName = vName.bstrVal ;
	return S_OK ;
}

STDMETHODIMP CTraceHook::Save(IPropertyBag * pBag, BOOL bClearDirty, BOOL bSaveAll) 
{
    ObjectLock  lock(this);
	CComVariant vName ( m_bstrObjectName ) ;
	if ( bClearDirty ) 
		m_bDirty = false ;
	return pBag->Write ( OLESTR("name"), &vName ) ;
}

// IPersistStream

STDMETHODIMP CTraceHook::IsDirty() 
{
	ObjectLock lock(this) ;
	return m_bDirty ? S_OK : S_FALSE ;
}

STDMETHODIMP CTraceHook::Load(IStream * pStm) 
{
    ObjectLock  lock(this);
	return m_bstrObjectName.ReadFromStream(pStm) ;	
}

STDMETHODIMP CTraceHook::Save(IStream * pStm, BOOL bClearDirty) 
{
    ObjectLock  lock(this);
	if ( bClearDirty ) 
		m_bDirty = false ;
	return  m_bstrObjectName.WriteToStream(pStm) ;
}

STDMETHODIMP CTraceHook::GetSizeMax(ULARGE_INTEGER * pcbSize)
{
	if ( NULL == pcbSize ) return E_POINTER ;
	ObjectLock lock(this) ;
	pcbSize->LowPart = SysStringByteLen(m_bstrObjectName) + sizeof(OLECHAR) + sizeof(ULONG) ;
	return S_OK ;
}
