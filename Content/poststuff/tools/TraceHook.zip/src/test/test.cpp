// test.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "..\calcsvr\calcsvr.h"
#include "..\calcsvr\calcsvr_i.c"

int main()
{
    CoInitialize(0);

    // Get a COM object to wrap
    CComPtr<IMalloc>    spMalloc;
    CoGetMalloc(1, &spMalloc);

    // Wrap it
    TRACEHOOK(OLESTR("MyMalloc"), &spMalloc.p);

    // Use it
    spMalloc->Free(spMalloc->Alloc(128));
    spMalloc.Release();

    // Get another COM object to wrap
    CComPtr<ICalc>  spCalc;
    spCalc.CoCreateInstance(CLSID_Calc);

	// CCalc could alternatively use DECLARE_CLASSFACTORY_DEBUGTRACER
    TRACEHOOK(OLESTR("MyCalc"), &spCalc.p);

    // Use it
    spCalc->put_Sum(0);
    spCalc->Add(2);
    spCalc->Add(2);
    long nSum;
    spCalc->get_Sum(&nSum);

	// test stack dumps

	// setup some test types
	CComBSTR out0, out1, out2, out3, out4, out5a, out5b ;
	CComBSTR out6 ;
	SYSTEMTIME st ;
	DATE d ;
	GetSystemTime( &st ) ;
	SystemTimeToVariantTime ( &st, &d ) ;
	CComVariant v(L"Variant containing a string") ;
	CComPtr<IUnknown> spUnk(spCalc) ;
	CComQIPtr<IDispatch> spDisp(spCalc) ;
	BYTE c = -1 ;
	CURRENCY cy ;
	cy.int64 = 25000 ;
	SAFEARRAY * psa; 
	SAFEARRAYBOUND aDim[1]; 
	aDim[0].lLbound = 1; 
	aDim[0].cElements = 8;
	psa = SafeArrayCreate(VT_I2, 1, aDim);
	DWORD dword = 98765 ;
	long lng = 0 ;

	// call some methods
	spCalc->TypesTest0(50000,123,L"Wooooooo Hooooooo", &out0) ;
	spCalc->TypesTest1(0x7f, 22.222233333, 1.112f, &out1);
	spCalc->TypesTest2(VARIANT_TRUE, d, v, &out2);
	spCalc->TypesTest3(&out0, &d, &nSum, &out3);
	spCalc->TypesTest4(spDisp, spUnk, &out4);
	spCalc->TypesTest5(&out5a, &c, &out5b) ;
	spCalc->TypesTest6(0x3fff, 0x8f00, E_FAIL,&out6) ;
	spCalc->TypesTest7(50000,&dword, &lng, 1) ;
	spCalc->TypesTest8(cy, psa, 12345) ;
    //Point   pt = { 1, 2 };
    //spCalc->TypesTest9(&pt);

    spCalc.Release();
	spDisp.Release() ;
	spUnk.Release() ;
	SafeArrayDestroy(psa);

    CoUninitialize();
	return S_OK;
}

