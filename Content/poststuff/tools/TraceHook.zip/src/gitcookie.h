// gitcookie.h
/////////////////////////////////////////////////////////////////////////////
// Copyright (c) 1990 Chris Sells
// All rights reserved.
// 1/10/90 - Initial release.
//
// NO WARRANTIES ARE EXTENDED. USE AT YOUR OWN RISK.
//
// To contact the author with suggestions or comments, use csells@sellsbrothers.com.
/////////////////////////////////////////////////////////////////////////////
// The file provides one class for use with the COM Global Interface Table.
//
// CGitCookie: Wraps the GIT cookie for an interface. It supports automatic
//             placement into the GIT, retrieval from the GIT and removal from the GIT.
//             When used with a smart point, e.g. CComPtr, provides everything
//             you need to use the GIT.
/////////////////////////////////////////////////////////////////////////////
// Usage
/*
// Assume CCollegeStudent is an apartment-neutral object.
// Assume also that CCollegeStudent has the following member variable:
//  CGitCookie m_gitParents;

HRESULT CCollegeStudent::FinalConstruct()
{
    CComPtr<IParents>   spParents;
    if( SUCCEEDED(spParents.CoCreateInstance(CLSID_Parents)) )
    {
        // Cache the interface in the GIT
        m_gitParents = spParents;
        return S_OK;
    }

    return E_FAIL;
}

HRESULT CCollegeStudent::PayTheRent(IRentMan* pRentMan)
{
    // Retrieve the pointer from the GIT
    CComPtr<IParents>   spParents;
    if( SUCCEEDED(m_gitParents.GetInterface(&spParents)) )
    {
        return spParents->PayTheRent(pRentMain);
    }

    return E_FAIL;
}

HRESULT CCollegeStudent::~CCollegeStudent()
{
    // m_gitParents is automatically revoked from the GIT
    // m_gitParents.Revoke() // GIT cookie could be revoked manually
}
*/

#ifndef __GITCOOKIE_H__
#define __GITCOOKIE_H__

#ifndef HR
#define HR(_e) { HRESULT _hr = _e; if( FAILED(_hr) ) return _hr; }
#endif  // HR

#ifndef HR2
#define HR2(_e) { HRESULT _hr = _e; if( FAILED(_hr) ) return; }
#endif  // HR2

class CGitCookie
{
public:
    CGitCookie(IUnknown* punk = 0) : m_dwCookie(0)
    {
        *this = punk;
    }

    ~CGitCookie()
    {
        *this = 0;
    }

    // Return void to make convenient use of HR2
    void operator=(IUnknown* punk)
    {
        CComPtr<IGlobalInterfaceTable>  spgit;
        HR2(GetGIT(&spgit));

        // Clear out the one we've got
        if( m_dwCookie )
        {
            spgit->RevokeInterfaceFromGlobal(m_dwCookie);
            m_dwCookie = 0;
        }

        // Put in another one
        if( punk )
        {
            HR2(spgit->RegisterInterfaceInGlobal(punk, IID_IUnknown, &m_dwCookie));
        }
    }

    template <typename Itf>
    HRESULT GetInterface(Itf** ppitf)
    {
        return GetInterface(__uuidof(Itf), (void**)ppitf);
    }

    HRESULT GetInterface(REFIID riid, void** ppv)
    {
        *ppv = 0;
        if( !m_dwCookie ) return E_UNEXPECTED;

        CComPtr<IGlobalInterfaceTable>  spgit;
        HR(GetGIT(&spgit));

        // Two steps to work around NT4, SP3 bug
        CComPtr<IUnknown>   spunk;
        HR(spgit->GetInterfaceFromGlobal(m_dwCookie, IID_IUnknown, (void**)&spunk));
        HR(spunk->QueryInterface(riid, ppv));

        return S_OK;
    }

    void Revoke()
    {
        *this = 0;
    }

    operator DWORD()
    {
        return m_dwCookie;
    }

    bool operator!()
    {
        return m_dwCookie ? true : false;
    }

private:
    HRESULT GetGIT(IGlobalInterfaceTable** ppgit)
    {
        if( !s_pgit )
        {
            CoCreateInstance(CLSID_StdGlobalInterfaceTable, 0, 
                             CLSCTX_INPROC_SERVER,
                             IID_IGlobalInterfaceTable,
                             (void**)&s_pgit);
        }

        if( *ppgit = s_pgit ) (*ppgit)->AddRef();
        return (*ppgit ? S_OK : E_FAIL);
    }

private:
    DWORD   m_dwCookie;
    static IGlobalInterfaceTable*   s_pgit;
};

// Cache this while the process is running
__declspec(selectany) IGlobalInterfaceTable* CGitCookie::s_pgit = 0;

#endif  // __GITCOOKIE_H__
