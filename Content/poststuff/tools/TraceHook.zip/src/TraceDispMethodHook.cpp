// TraceDispMethodHook.cpp : Implementation of CTraceDispMethodHook

//
// ToDo:
//
// 1) Add support for IDispatchEx ( ASP uses this if supported, (Java-COM implements this))
//

#include "stdafx.h"
#include "UDTraceHookSvr.h"
#include "TraceDispMethodHook.h"

/////////////////////////////////////////////////////////////////////////////
// CTraceDispMethodHook
/////////////////////////////////////////////////////////////////////////////

struct GetIDsOfNamesData
{
	void *		pArgs;
	UINT		nCount;
	LPOLESTR *  szNames;
};

struct InvokeData
{
	VARIANT *	pRetVal ;
	char *		szTrace ;
};

// ITraceDispMethodHook
STDMETHODIMP CTraceDispMethodHook::SetObjectName(LPCOLESTR szObjectName)
{
    ObjectLock  lock(this);
	m_bstrObjectName = szObjectName ;
	return S_OK;
}

// IDelegatorHookMethods2
STDMETHODIMP CTraceDispMethodHook::DelegatorPreprocess(DWORD nVtblIndex, void* pArgs, void** ppHookDefinedData )
{
    ObjectLock  lock(this);

	switch ( nVtblIndex ) 
	{
		case 5:
		{
			// IDispatch::GetIdsOfNames
			GetIDsOfNamesData * p = new GetIDsOfNamesData ;
			p->nCount = *(unsigned int*)((DWORD *)pArgs + 2) ;
			p->szNames = *(LPOLESTR **)((DWORD *)pArgs + 1) ;
			p->pArgs = pArgs;
			*ppHookDefinedData = p ;
			//ATLTRACE(_T("%S, IDispatch::GetIDsOfNames(Count=%d)\n"), m_bstrObjectName, p->nCount) ;
			break;
		}

		case 6 :
		{
			// IDispatch::Invoke()
			DISPID did = *(DISPID *)pArgs ;
			DISPID_MAP::const_iterator it = m_Ids.find(did) ;
			char sz[256];
			if ( it != m_Ids.end() ) 
				wsprintfA(sz, "%S, IDispatch::(Invoke) %S", m_bstrObjectName, it->second.c_str() );
			else
				wsprintfA(sz, "%S, IDispatch::Invoke(%d)", m_bstrObjectName, did);
			
			DISPPARAMS * pDParams = *(DISPPARAMS **)((DWORD *)pArgs + 4) ;
			//ATLTRACE(L"--- No. Of params = %d\n", pDParams->cArgs ) ;
			VARIANTARG * pVArgs = pDParams->rgvarg ;
			CComVariant v ;
			CComBSTR bstrArgs ;
			for ( UINT i = 0 ; i < pDParams->cArgs ; i++ )
			{
				if ( bstrArgs )
					bstrArgs += L", " ;
                bool bWasString = (v.vt == VT_BSTR);
                if( bWasString ) bstrArgs += OLESTR("\"");
				if (SUCCEEDED(v.ChangeType( VT_BSTR, pVArgs++ )))
					bstrArgs +=  v.bstrVal ;
				else
					bstrArgs += L"[Eh ?]" ;
                if( bWasString ) bstrArgs += OLESTR("\"");
			}
			InvokeData * pID = new InvokeData ;
			pID->pRetVal = *(VARIANT **)((DWORD *)pArgs + 5) ;
			pID->szTrace = new char[strlen(sz) + bstrArgs.Length() + 4];
			wsprintfA(pID->szTrace, "%s(%S)", sz, bstrArgs ? bstrArgs : L"" ) ;
			*ppHookDefinedData = pID ;
			break;
		}

		default:
		{
			char sz[256] ;
			wsprintfA(sz, "%S, IDispatch::[method%d]()\n", m_bstrObjectName, nVtblIndex ) ;
			OutputDebugStringA ( sz ) ;
		}
	}
	return S_OK ;
}
   
STDMETHODIMP CTraceDispMethodHook::DelegatorPostprocess(DWORD nVtblIndex, HRESULT hrFromInner, void* pHookDefinedData )
{
	USES_CONVERSION ;

    ObjectLock  lock(this);

	switch ( nVtblIndex ) 
	{
		case 5:
		{
			// IDispatch::GetIdsOfNames
			GetIDsOfNamesData * p = (GetIDsOfNamesData *)pHookDefinedData ;
			DISPID *d = *(DISPID **)((DWORD *)p->pArgs + 4) ;
			for ( DWORD i = 0 ; i < p->nCount ; i++ )
			{
				m_Ids.insert ( DISPID_MAP::value_type ( *d, *p->szNames ) ) ;
				p->szNames++;
			}
			delete p ;
			break;
		}

		case 6:
		{
			InvokeData * pID = (InvokeData *)pHookDefinedData ;
			if ( pID->pRetVal )
			{
				CComVariant v ;
				HRESULT hr = v.ChangeType( VT_BSTR, pID->pRetVal ) ;
				OutputDebugStringA ( pID->szTrace ) ;
				OutputDebugString ( _T(" returned ") ) ;
				if (SUCCEEDED(hr))
				{
					TCHAR * szRetVal = OLE2T(v.bstrVal);
					OutputDebugString ( szRetVal ) ;
				}
				else
					OutputDebugString (_T("[Eh ?]")) ;
				OutputDebugString (_T("\n")) ;
			}
			else
			{
				OutputDebugStringA ( pID->szTrace ) ;
				OutputDebugString ( _T("\n")) ;
			}
			delete [] pID->szTrace  ;
			delete pID ;
			break;
		}
	}
	return hrFromInner ;
}