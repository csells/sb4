// TraceDispMethodHook.h : Declaration of the CTraceDispMethodHook

#ifndef __TRACEDISPMETHODHOOK_H_
#define __TRACEDISPMETHODHOOK_H_

#include "resource.h"       // main symbols
typedef std::map < DISPID, std::wstring > DISPID_MAP ;

/////////////////////////////////////////////////////////////////////////////
// CTraceDispMethodHook
class ATL_NO_VTABLE CTraceDispMethodHook : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CTraceDispMethodHook, &CLSID_TraceDispMethodHook>,
	public ITraceDispMethodHook,
	public IDelegatorHookMethods2
{
public:
	CTraceDispMethodHook()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_TRACEDISPMETHODHOOK)
DECLARE_NOT_AGGREGATABLE(CTraceDispMethodHook)
DECLARE_GET_CONTROLLING_UNKNOWN()

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CTraceDispMethodHook)
	COM_INTERFACE_ENTRY(ITraceDispMethodHook)
    COM_INTERFACE_ENTRY(IDelegatorHookMethods2)
	COM_INTERFACE_ENTRY_AGGREGATE(IID_IMarshal, m_pUnkMarshaler.p)
END_COM_MAP()

	HRESULT FinalConstruct()
	{
		return CoCreateFreeThreadedMarshaler(GetControllingUnknown(), &m_pUnkMarshaler.p);
	}

	void FinalRelease()
	{
		m_pUnkMarshaler.Release();
	}

// ITraceDispMethodHook
public:
	STDMETHOD(SetObjectName)(/*[in]*/ LPCOLESTR szObjectName);

// IDelegatorHookMethods2
public:
    STDMETHODIMP DelegatorPreprocess(DWORD nVtblIndex, void* pArgs, void** ppCookie);
    STDMETHODIMP DelegatorPostprocess(DWORD nVtblIndex, HRESULT hrFromInner, void* pCookie);

private:
	CComPtr<IUnknown>   m_pUnkMarshaler;
	CComBSTR			m_bstrObjectName ;
	DISPID_MAP			m_Ids ;
};

#endif //__TRACEDISPMETHODHOOK_H_
