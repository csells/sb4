	
// TraceHook.h : Declaration of the CTraceHook

#ifndef __TRACEHOOK_H_
#define __TRACEHOOK_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CTraceHook
class ATL_NO_VTABLE CTraceHook : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CTraceHook, &CLSID_TraceHook>,
    public IDelegatorHookQI,
	public ITraceHook,
	public IDispatchImpl<ITraceHookFactory, &IID_ITraceHookFactory, &LIBID_UDTRACEHOOKSVRLib>,
	public IPersistPropertyBag,
	public IPersistStream
{
public:
	CTraceHook();

DECLARE_REGISTRY_RESOURCEID(IDR_TRACEHOOK)
DECLARE_NOT_AGGREGATABLE(CTraceHook)
DECLARE_GET_CONTROLLING_UNKNOWN()

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CTraceHook)
	COM_INTERFACE_ENTRY(ITraceHook)
    COM_INTERFACE_ENTRY(IDelegatorHookQI)
	COM_INTERFACE_ENTRY(ITraceHookFactory)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IPersistPropertyBag)
	COM_INTERFACE_ENTRY2(IPersist, IPersistStream)
	COM_INTERFACE_ENTRY(IPersistStream)
	COM_INTERFACE_ENTRY_AGGREGATE(IID_IMarshal, m_pUnkMarshaler.p)
END_COM_MAP()

	HRESULT FinalConstruct()
	{
		return CoCreateFreeThreadedMarshaler(GetControllingUnknown(), &m_pUnkMarshaler.p);
	}

	void FinalRelease()
	{
		m_pUnkMarshaler.Release();
	}

private:
	CComPtr<IUnknown>   m_pUnkMarshaler;
    CComBSTR            m_bstrObjectName;
	bool				m_bDirty ;
// IDelegatorHookQI
public:
    STDMETHODIMP Init(IUnknown* pUnkInner);
    STDMETHODIMP OnFirstDelegatorQIFor(REFIID iid, IUnknown* pItfInner, DWORD* pgrfDelegatorHookOptions, REFIID iidMethodHook, void** ppMethodHook);

// ITraceHook
public:
	STDMETHOD(SetObjectName)(/*[in]*/ LPCOLESTR pszObjectName);

// ITraceHookFactory
	STDMETHOD(ComTrace)(/*[in]*/ BSTR bstrObjectName, /*[in,out]*/ VARIANT * pVarObject);

// IPerist
	STDMETHOD(GetClassID)(CLSID * pclsid);

// IPersistPropertyBag
	STDMETHOD(InitNew)() ;
	STDMETHOD(Load)(IPropertyBag * pBag, IErrorLog * pLog ) ;
	STDMETHOD(Save)(IPropertyBag * pBag, BOOL bClearDirty, BOOL bSaveAll) ;

// IPersistStream
	STDMETHOD(IsDirty)() ;
	STDMETHOD(Load)(IStream * pStm) ;
	STDMETHOD(Save)(IStream * pStm, BOOL bClearDirty) ;
	STDMETHOD(GetSizeMax)(ULARGE_INTEGER * pcbSize);
};

#endif //__TRACEHOOK_H_
