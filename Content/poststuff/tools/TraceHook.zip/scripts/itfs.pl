# itfs.pl
#
# (c) March 1999 Simon Fell
#
# Interface definition parser for
# the UDTraceHook non-typelib definied interfaces
#

while ($line = <STDIN>) 
{
	if ($line =~ /typedef struct (\w+)Vtbl/)
	{
	    print $1 . "\n" ;
	    do
	    {
	        $line=<STDIN> ;
	        if ( $line =~ /\(.*stdcall\s*\*\s*(.*?)\)/ )
	        {
                print $1 ."\n" ;
                # print $line;
	        }
	    } until ( $line =~ /}/ ) ;
	    print "\n" ;
    }
}
