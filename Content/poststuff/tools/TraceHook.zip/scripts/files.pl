$dir = @ARGV[0]. "\\*.h" ;
print $dir . "\n";
while (glob($dir))
{
	open (HDR, $_ ) ;
	$l = 0 ;
	LINE: while ( $line = <HDR> )
	{
	    if ( $line =~ /File created by MIDL compiler version/ )
	    {
        	print $_ . "\n" ;
        	@args = ( "import.bat", $_ ) ;
        	system (@args) == 0 or die "couldn't launch @args: $?" ;
        	last LINE ;
        }
        $l = $l + 1 ;
        last LINE if $l > 10 ;
    }
}
