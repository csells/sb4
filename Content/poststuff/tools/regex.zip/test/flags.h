// flags.h

struct CharToFlag
{
    char    ch;
    ULONG   flag;
};

inline
ULONG FlagFromChar(
    char                ch,
    const CharToFlag*   rgFlags,
    size_t              cFlags)
{
    for( size_t i = 0; i < cFlags; ++i )
    {
        if( rgFlags[i].ch == ch ) return rgFlags[i].flag;
    }

    return 0;
}

inline
ULONG FlagsFromChars(
    const char*         pszFlags,
    const CharToFlag*   rgFlags,
    size_t              cFlags)
{
    ULONG   grb = 0;
    for( size_t i = 0; i < strlen(pszFlags); ++i )
    {
        grb |= FlagFromChar(pszFlags[i], rgFlags, cFlags);
    }

    return grb;
}

// Flags expected after regcompile in regex_t.re_info
inline
ULONG InfoFlags(const char* pszFlags)
{
    static CharToFlag   rgFlags[] =
    {
        'R', REG_UBACKREF,      // back _r_eference seen
        'H', REG_ULOOKAHEAD,    // looka_h_ead constraint seen
        'Q', REG_UBOUNDS,       // {} _q_uantifier seen
        'B', REG_UBRACES,       // ERE/ARE literal-_b_race heuristic used
        'A', REG_UBSALNUM,      // backslash-_a_lphanumeric seen
        'U', REG_UPBOTCH,       // saw original-POSIX botch:  unmatched right paren in ERE (_u_gh)
        'E', REG_UBBS,          // backslash (_e_scape) seen within []
        'P', REG_UNONPOSIX,     // non-_P_OSIX construct seen
        'S', REG_UUNSPEC,       // POSIX-un_s_pecified syntax seen
        'M', REG_UUNPORT,       // unportable (_m_achine-specific) construct seen
        'L', REG_ULOCALE,       // _l_ocale-specific construct seen
        'N', REG_UEMPTYMATCH,   // RE can match empty (_n_ull) string
        'I', REG_UIMPOSSIBLE,   // _i_mpossible to match
    };

    return FlagsFromChars(pszFlags, rgFlags, lengthof(rgFlags));
}

// Flags to pass to regcomp
inline
ULONG CompFlags(const char* pszFlags)
{
    static CharToFlag   rgFlags[] =
    {
        '-', 0,             // no-op (placeholder)
        '+', REG_FAKE,      // provide fake xy equivalence class???
        'b', REG_BASIC,     // BREs (convenience)
        'e', REG_EXTENDED,  // EREs
        'a', REG_ADVF,      // advanced features in EREs
        'q', REG_QUOTE,     // no special characters, none
        'i', REG_ICASE,     // ignore case
        'o', REG_NOSUB,     // don't care about subexpressions
        'x', REG_EXPANDED,  // expanded format, white space & comments
        'p', REG_NLSTOP,    // \n doesn't match . or [^ ]
        'w', REG_NLANCH,    // ^ matches after \n, $ before 
        'n', REG_NEWLINE,   // newlines are line terminators
        '?', REG_EXPECT,    // report details on partial/limited matches
        's', REG_BOSONLY,   // temporary kludge for BOS-only matches
    };

    return FlagsFromChars(pszFlags, rgFlags, lengthof(rgFlags));
}

// Flags to pass to regexec
inline
ULONG ExecFlags(const char* pszFlags)
{
    static CharToFlag   rgFlags[] =
    {
        '-', 0,             // no-op (placeholder)
        '%', REG_SMALL,     // force small state-set cache in matcher (to test cache replace)
        '^', REG_NOTBOL,    // beginning of string (BOS) is not beginning of line (BOL)
        '$', REG_NOTEOL,    // end of string (EOS) is not end of line (EOL)
    };

    return FlagsFromChars(pszFlags, rgFlags, lengthof(rgFlags));
}
