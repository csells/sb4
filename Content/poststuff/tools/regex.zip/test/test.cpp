// test.cpp : Defines the entry point for the console application.

#include "stdafx.h"
#include "flags.h"

/////////////////////////////////////////////////////////////////////////////
// Test Results: Current we fail the following tests:
/*
Failed during test #14.2 'back references':
        'mismatched number of sub-strings'
Failed during test #14.17 'back references':
        'mismatched number of sub-strings'
Failed during test #20.2 'directors and embedded options':
        'invalid argument to regex function'
Failed during test #20.4 'directors and embedded options':
        'invalid argument to regex function'
Failed during test #21.23 'capturing':
        'mismatched number of sub-strings'
Failed during test #21.34 'capturing':
        'mismatched number of sub-strings'
Failed during test #25.3 'mixed quantifiers':
        'mismatched number of sub-strings'
*/
// I don't know whether that's a failure in the implementation of the tests,
// the implementation of Henry's regex code or in my port...

int         g_nTestMajor = 0;
const char* g_pszTestDesc = 0;

// Set major test case number
void doing(int major, const char* pszTestDesc)
{
    g_nTestMajor = major;
    g_pszTestDesc = pszTestDesc;
}

// Dump the error
void error(int minor, const CRegex& re)
{
    cout << "Failed during test #" << g_nTestMajor << "." << minor << " '" << g_pszTestDesc << "':" << endl;
    cout << "\t'" << re.ErrorString() << "'" << endl;
}

// Check sub-strings
void CheckSubStrings(int minor, const CRegex& re, const char* pszzSubStrings)
{
    size_t      cSubStrings = 0;
    const char* pszSub = pszzSubStrings;
    
    // Special case matching the empty string
    if( !*pszSub && !*pszzSubStrings ) ++cSubStrings;

    while( *pszSub )
    {
        if( strcmp(pszSub, re[cSubStrings].c_str()) )
        {
            cout << "Failed during test #" << g_nTestMajor << "." << minor << " '" << g_pszTestDesc << "':" << endl;
            cout << "\t'mismatched sub-string #" << cSubStrings << "'" << endl;
        }

        ++cSubStrings;
        pszSub += strlen(pszSub) + 1;
    }

    if( cSubStrings != (re.SubStrings() + 1) )
    {
        cout << "Failed during test #" << g_nTestMajor << "." << minor << " '" << g_pszTestDesc << "':" << endl;
        cout << "\t'mismatched number of sub-strings'" << endl;
    }
}

void errorExec(
    int         minor,
    const char* pszRE,
    ULONG       grbComp,
    int         err)
{
    CRegex  re;
    if( re.Compile(pszRE, grbComp) || (re.Error() != err) ) { error(minor, re); return; }
}

// Compile error expected
void e(
    int         minor,
    const char* pszFlags,
    const char* pszRE,
    int         err)
{
    // Check 1st character for '&' to test both ARE and BRE
    bool    bBoth = pszFlags[0] == '&';
    if( bBoth ) ++pszFlags;

    ULONG   grbComp = CompFlags(pszFlags);
    ULONG   grbExec = ExecFlags(pszFlags);
    ULONG   grbInfo = InfoFlags(pszFlags);

    // TODO: For bBoth, put ARE or BRE onto test number

    if( bBoth )
    {
        // Check BRE
        errorExec(minor, pszRE, grbComp | REG_BASIC, err);

        // Check ARE
        errorExec(minor, pszRE, grbComp | REG_ADVANCED, err);
    }
    else
    {
        // Assume REG_ADVANCED if REG_BASIC or REG_EXTENDED not asked for
        if( !strchr(pszFlags, 'b') && !strchr(pszFlags, 'e') ) grbComp |= REG_ADVANCED;
        errorExec(minor, pszRE, grbComp, err);
    }
}

void failExec(
    int         minor,
    const char* pszRE,
    ULONG       grbComp,
    ULONG       grbExec,
    const char* pszToMatch)
{
    CRegex  re;
    if( !re.Compile(pszRE, grbComp) ) { error(minor, re); return; }
    if( re.Match(pszToMatch, grbExec) ) { error(minor, re); return; }
}

// Match failure expected
void f(
    int         minor,
    const char* pszFlags,
    const char* pszRE,
    const char* pszToMatch)
{
    // Check 1st character for '&' to test both ARE and BRE
    bool    bBoth = pszFlags[0] == '&';
    if( bBoth ) ++pszFlags;

    ULONG   grbComp = CompFlags(pszFlags);
    ULONG   grbExec = ExecFlags(pszFlags);
    ULONG   grbInfo = InfoFlags(pszFlags);

    // TODO: For bBoth, put ARE or BRE onto test number

    if( bBoth )
    {
        // Check BRE
        failExec(minor, pszRE, grbComp | REG_BASIC, grbExec, pszToMatch);

        // Check ARE
        failExec(minor, pszRE, grbComp | REG_ADVANCED, grbExec, pszToMatch);
    }
    else
    {
        // Assume REG_ADVANCED if REG_BASIC or REG_EXTENDED not asked for
        if( !strchr(pszFlags, 'b') && !strchr(pszFlags, 'e') ) grbComp |= REG_ADVANCED;
        failExec(minor, pszRE, grbComp, grbExec, pszToMatch);
    }
}

void matchExec(
    int         minor,
    const char* pszRE,
    ULONG       grbComp,
    ULONG       grbExec,
    ULONG       grbInfo,
    const char* pszToMatch,
    const char* pszzSubStrings)
{
    CRegex  re;
    if( !re.Compile(pszRE, grbComp) ) { error(minor, re); return; }
    if( !re.Match(pszToMatch, grbExec) ) { error(minor, re); return; }

    // Check sub-strings
    if( !(grbComp & REG_NOSUB) ) CheckSubStrings(minor, re, pszzSubStrings);

    // TODO: Check grbInfo
}

// Match expected
void m(
    int         minor,
    const char* pszFlags,
    const char* pszRE,
    const char* pszToMatch,
    const char* pszzSubStrings)
{
    // Check 1st character for '&' to test both ARE and BRE
    bool    bBoth = pszFlags[0] == '&';
    if( bBoth ) ++pszFlags;

    ULONG   grbComp = CompFlags(pszFlags);;
    //ULONG   grbComp = CompFlags(pszFlags) | REG_DUMP | REG_PROGRESS;
    ULONG   grbExec = ExecFlags(pszFlags);
    //ULONG   grbExec = ExecFlags(pszFlags) | REG_FTRACE | REG_MTRACE;
    ULONG   grbInfo = InfoFlags(pszFlags);

    // TODO: For bBoth, put ARE or BRE onto test number

    if( bBoth )
    {
        // Check BRE
        matchExec(minor, pszRE, grbComp | REG_BASIC, grbExec, grbInfo, pszToMatch, pszzSubStrings);

        // Check ARE
        matchExec(minor, pszRE, grbComp | REG_ADVANCED, grbExec, grbInfo, pszToMatch, pszzSubStrings);
    }
    else
    {
        // Assume REG_ADVANCED if REG_BASIC or REG_EXTENDED not asked for
        if( !strchr(pszFlags, 'b') && !strchr(pszFlags, 'e') ) grbComp |= REG_ADVANCED;
        matchExec(minor, pszRE, grbComp, grbExec, grbInfo, pszToMatch, pszzSubStrings);
    }
}

// Match expected with indices
void i(
    int         minor,
    const char* pszFlags,
    const char* pszRE,
    const char* pszToMatch,
    const char* pszzSubStrings)
{
    // Check 1st character for '&' to test both ARE and BRE
}

// Forward declaration
void test();

int main(int argc, char* argv[])
{
    test();
    return 0;
}

// Generated with 'tclsh82.exe regtest.tcl > regtest.c'
#include "..\test\regtest.c"
