// SafeFormatter.cs: A formatter for use in an assembly with restricted permissions.
/////////////////////////////////////////////////////////////////////////////
// This formatter only uses ISafelySerializable and
// IDeserializationCallback to provide the formatter implementation, because
// assemblies with restricted permissions can't be counted on to have access
// to Reflection or ISerializable.GetObjectData. Enjoy.
/////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2002, Chris Sells. All rights reserved. No warranties
// extended. Use at your own risk. Feel free to use this code royalty-free in
// your own work, but do not redistribute the source code.
// Bugs and suggestions to mailto:csells@sellsbrothers.com.
// The official home of this software is http://www.sellsbrothers.com/.
/////////////////////////////////////////////////////////////////////////////
// History:
// 1/22/02: Initial alpha release. See TODOs for why.
/////////////////////////////////////////////////////////////////////////////
// Server Usage:
/*
 * using SellsBrothers;
 * 
 * class MyClass : ISerializeable, ISafelySerializeable {
 *   public MySafeToSerializeClass(SerializationInfo info, StreamingContext context) {
 *     // Use info to get the data for your instance from the formatter
 *   }
 * 
 *   void GetObjectData(SerializationInfo info, StreamingContext context) {
 *     // Use info to add the data for your instance to the formatter
 *   }
 * }
 */
// Client Usage:
//
/*
 * using SellsBrothers;
 * 
 * static void SaveObjectSafely(MyClass obj) {
 *   Stream stream = new IsolatedStorageFileStream("safe.txt", FileMode.Create,
 *                          IsolatedStorageFile.GetUserStoreForDomain());
 *   IFormatter formatter = new SafeFormatter();
 *   formatter.Serialize(stream, obj);
 * 
 * static MyClass LoadObjectSafely() {
 *   Stream stream = new IsolatedStorageFileStream("safe.txt", FileMode.Open,
 *                          IsolatedStorageFile.GetUserStoreForDomain());
 *   IFormatter formatter = new SafeFormatter();
 *   return (MyClass)formatter.Deserialize(stream);
 * }
 */
/////////////////////////////////////////////////////////////////////////////

using System;
using System.IO;
using System.Reflection;
using System.Collections;
using System.Diagnostics;
using System.Globalization;
using System.ComponentModel;
using System.Runtime.Serialization;

namespace SellsBrothers
{
    // ISerializable w/o the pesky CAS limitiations
    public interface ISafelySerializable
    {
        void GetObjectData(SerializationInfo info, StreamingContext context);
    }

    // TODO: Handle object graphs (we're just dumping objects by value as we go)
    // TODO: An XML-based stream format would be better, if for no other reason
    // than multi-line strings would actually work.
    public class SafeFormatter : IFormatter
    {
        StreamWriter        _writer;
        StreamReader        _reader;
        Assembly            _callingAssembly;
        FormatterConverter  _converter = new FormatterConverter();

        protected struct NameValue
        {
            public NameValue(string name, object value) { Name = name; Value = value; }
            public string  Name;
            public object  Value;
        }

        #region Implementation of IFormatter
        public void Serialize(Stream stream, object graph)
        {
            try
            {
                _writer = new StreamWriter(stream);
                WriteEntry(new NameValue("root", graph));
            }
            finally
            {
                if( _writer != null )
                {
                    ((IDisposable)_writer).Dispose();
                    _writer = null;
                }
            }
        }

        protected void WriteEntry(NameValue pair)
        {
            if( pair.Value == null ) WriteNull(pair);
            else if( pair.Value is Array ) WriteArray(pair);
            else if( pair.Value is ISafelySerializable ) WriteObject(pair);
            // NOTE: This has to come after the array check, as arrays implement IList
            else if( pair.Value is IList ) WriteList(pair);
            else WriteValue(pair);
        }

        // e.g.
        // null
        // foo
        protected void WriteNull(NameValue pair)
        {
            _writer.WriteLine("null");
            _writer.WriteLine(pair.Name);
        }

        // e.g.
        // array
        // 3
        // foo
        // System.Int32 (type of elements)
        // ... 3 sub-items ...
        protected void WriteArray(NameValue pair)
        {
            _writer.WriteLine("array");
            Array   array = (Array)pair.Value;

            // TODO: Handle mult-dim arrays and non-zero-based arrays
            Debug.Assert(array.Rank == 1);
            Debug.Assert(array.GetLowerBound(0) == 0, "Only handling 0-based arrays");

            _writer.WriteLine(array.Length);
            _writer.WriteLine(pair.Name);
            _writer.WriteLine(array.GetValue(0).GetType());

            for( int i = 0; i != array.Length; ++i )
            {
                WriteEntry(new NameValue(i.ToString(), array.GetValue(i)));
            }
        }

        // e.g.
        // object
        // 3
        // foo
        // MyNamespace.MyClass
        // ... 3 sub-items ...
        protected void WriteObject(NameValue pair)
        {
            ISafelySerializable serial = (ISafelySerializable)pair.Value;
            SerializationInfo   info = new SerializationInfo(pair.Value.GetType(), _converter);
            serial.GetObjectData(info, Context);
            
            _writer.WriteLine("object");
            _writer.WriteLine(info.MemberCount);
            _writer.WriteLine(pair.Name);
            _writer.WriteLine(pair.Value.GetType());
            
            foreach( SerializationEntry entry in info )
            {
                WriteEntry(new NameValue(entry.Name, entry.Value));
            }
        }

        // e.g.
        // list
        // 3
        // foo
        // System.Int32[]
        // ... 3 sub-items ...
        protected void WriteList(NameValue pair)
        {
            _writer.WriteLine("list");
            IList list = (IList)pair.Value;
            _writer.WriteLine(list.Count);
            _writer.WriteLine(pair.Name);
            _writer.WriteLine(pair.Value.GetType());

            int i = 0;  // TODO: What about other kinds of lists?
            foreach( object item in list )
            {
                WriteEntry(new NameValue((i++).ToString(), item));
            }
        }

        // e.g.
        // value
        // foo
        // System.Int32
        // 42
        protected void WriteValue(NameValue pair)
        {
            _writer.WriteLine("value");
            _writer.WriteLine(pair.Name);
            _writer.WriteLine(pair.Value.GetType());
            _writer.WriteLine(_converter.ToString(pair.Value));
        }

        public object Deserialize(Stream stream)
        {
            try
            {
                _reader = new StreamReader(stream);
                _callingAssembly = Assembly.GetCallingAssembly();
                return ReadEntry().Value;
            }
            finally
            {
                if( _reader != null )
                {
                    ((IDisposable)_reader).Dispose();
                    _reader = null;
                }
            }
        }

        protected NameValue ReadEntry()
        {
            string  entryType = _reader.ReadLine();
            switch( entryType )
            {
                case "null": return ReadNull();
                case "array": return ReadArray();
                case "object": return ReadObject();
                case "list": return ReadList();
                case "value": return ReadValue();
                default: throw new ApplicationException(string.Format("Can't deserialize {0}", entryType));
            }
        }

        // e.g.
        // null (already read above)
        // foo
        protected NameValue ReadNull()
        {
            return new NameValue(_reader.ReadLine(), null);
        }


        // e.g.
        // array (already read above)
        // 3
        // foo
        // System.Int32 (type of elements)
        // ... 3 sub-items ...
        protected NameValue ReadArray()
        {
            // Read metadata
            int     subitems = int.Parse(_reader.ReadLine());
            string  name = _reader.ReadLine();
            string  type = _reader.ReadLine();

            // Read each item into the array
            Array   array = CreateArray(type, subitems);
            for( int subitem = 0; subitem != subitems; ++subitem )
            {
                NameValue   pair = ReadEntry();
                array.SetValue(pair.Value, subitem);
            }

            return new NameValue(name, array);
        }

        // e.g.
        // object (already read above)
        // 3
        // foo
        // MyNamespace.MyClass
        // ... 3 sub-items ...
        protected NameValue ReadObject()
        {
            // Read metadata
            int     subitems = int.Parse(_reader.ReadLine());
            string  name = _reader.ReadLine();
            string  type = _reader.ReadLine();

            // Read each sub-item into a bag
            SerializationInfo   info = new SerializationInfo(Type.GetType(type), _converter);
            for( int subitem = 0; subitem != subitems; ++subitem )
            {
                NameValue   pair = ReadEntry();
                info.AddValue(pair.Name, pair.Value);
            }

            // Deserialize the object from the bag
            object  value = CreateInstance(type, info);

            // If the object would like to be notified that it has been deserialized, notify it
            IDeserializationCallback    callback = value as IDeserializationCallback;
            if( callback != null ) callback.OnDeserialization(this);

            return new NameValue(name, value);
        }

        // e.g.
        // list (already read above)
        // 3
        // foo
        // System.Int32[]
        // ... 3 sub-items ...
        protected NameValue ReadList()
        {
            // Read metadata
            int     subitems = int.Parse(_reader.ReadLine());
            string  name = _reader.ReadLine();
            string  type = _reader.ReadLine();

            // Read each item into the list
            IList list = (IList)CreateInstance(type);
            for( int subitem = 0; subitem != subitems; ++subitem )
            {
                NameValue   pair = ReadEntry();
                list.Add(pair.Value);
            }

            return new NameValue(name, list);
        }

        // e.g.
        // value (already read above)
        // foo
        // System.Int32
        // 42
        protected NameValue ReadValue()
        {
            // Read metadata
            string  name = _reader.ReadLine();
            Type    type = Type.GetType(_reader.ReadLine());
            object  value = _converter.Convert(_reader.ReadLine(), type);
            return new NameValue(name, value);
        }

        // Create an instance of an array
        protected Array CreateArray(string type, int length)
        {
            return Array.CreateInstance(Type.GetType(type), length);
        }


        // Create an instance of the object using its default ctor
        protected object CreateInstance(string type)
        {
            return _callingAssembly.CreateInstance(type);
        }


        // Create an instance of the object using its serializtion ctor
        protected object CreateInstance(string type, SerializationInfo info)
        {
            StreamingContext    context = Context;  // Persistance
            Binder              binder = null;  // Use the default binder
            CultureInfo         culture = null; // Use the default culture for the thread
            object[]            attributes = null;  // No activate attributes
            return _callingAssembly.CreateInstance(type, false, BindingFlags.CreateInstance, binder, new object[] { info, context }, culture, attributes);
        }


        // TODO: SerializationBinder?
        public SerializationBinder Binder
        {
            get
            {
                return null;
            }

            set
            {
            }
        }


        // Just doing persistence today
        public StreamingContext Context
        {
            get
            {
                return new StreamingContext(StreamingContextStates.Persistence);
            }

            set
            {
            }
        }


        // Only the object itself can serialize
        public ISurrogateSelector SurrogateSelector
        {
            get
            {
                return null;
            }

            set
            {
            }
        }
        #endregion
    }
}
