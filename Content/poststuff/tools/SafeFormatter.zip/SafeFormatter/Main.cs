using System;
using System.IO;
using System.Reflection;
using System.IO.IsolatedStorage;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;

using SellsBrothers;

namespace SafeFormatterTest
{
    #region Nested Serialization Test Classes
    // From ms-help://MS.VSCC/MS.MSDNVS/cpref/html/frlrfsystemruntimeserializationserializationinfoclasstopic.htm
    [Serializable()] 
    public class MyClass1: ISerializable, ISafelySerializable
    {
        public MyClass2 someObject;
        public int size;
        public String shape;

        //Default constructor
        public MyClass1() 
        {
            someObject = new MyClass2();
        }

        //Deserialization constructor.
        public MyClass1 (SerializationInfo info, StreamingContext context) 
        {
            size = (int)info.GetValue("size", typeof(int));
            shape = (String)info.GetValue("shape", typeof(string));

            //Allows MyClass2 to deserialize itself
            //someObject = new MyClass2(info, context);
            someObject = (MyClass2)info.GetValue("someObject", typeof(MyClass2));
        }

        //Serialization function.
        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("size", size);
            info.AddValue("shape", shape);

            //Allows MyClass2 to serialize itself
            //someObject.GetObjectData(info, context);
            info.AddValue("someObject", someObject);
        }

        public override string ToString()
        {
            return string.Format("someObject= '{0}', size= '{1}', shape= '{2}'", someObject, size, shape);
        }
    }

    [Serializable()] 
    public class MyClass2 : ISerializable, ISafelySerializable
    {
        public double value = 3.14159265;

        public MyClass2() 
        {
        }

        public MyClass2(SerializationInfo info, StreamingContext context) 
        {
            value = (double)info.GetValue("MyClass2_value", typeof(double));
        }


        public void GetObjectData(SerializationInfo info, StreamingContext context) 
        {
            info.AddValue("MyClass2_value", value);
        }

        public override string ToString()
        {
            return string.Format("value= {0}", value.ToString());
        }
    }

    #endregion

    #region DeserializationCallback Test Classes

    [Serializable]
    class DigitSeries : ISerializable, IDeserializationCallback, ISafelySerializable
    {
        public DigitSeries(SerializationInfo si, StreamingContext sc)
        {
            start = si.GetInt32("start");
            end = si.GetInt32("end");
        }

        public DigitSeries(int first, int last)
        {
            start = first;
            end = last;
            GenerateSeries();
        }

        public override string ToString()
        {
            string  series = "";
            foreach( int n in digits ) series += n.ToString() + ", ";
            return series;
        }

        private void GenerateSeries() 
        {
            int count = end - start + 1;
            digits = new int[count];
            for( int n = 0; n < count; n++ ) digits[n] = start + n;
        }

        #region Implementation of IDeserializationCallback
        public void OnDeserialization(object sender)
        {
            GenerateSeries();
        }
    
        #endregion

        #region Implementation of ISerializable and ISafelySerializable
        public void GetObjectData(SerializationInfo si, StreamingContext context)
        {
            si.AddValue("start", start);
            si.AddValue("end", end);
            si.AddValue("digits", digits);
        }
        #endregion

        private int   start;  // Starting value
        private int   end;    // Ending value
        private int[] digits; // The actual digits
    }

    #endregion

	class App
	{
        #region Nested Serialization Test
        static void TestNested()
        {
            // Creates a new MyClass1 object.
            MyClass1 f = new MyClass1();
   
            // Opens a file and serializes the object into it in binary format.
            //Stream stream = File.Open(@"c:\temp\MyClass1MyClass2.txt", FileMode.Create);
            Stream stream = new IsolatedStorageFileStream("MyClass1MyClass2.txt", FileMode.Create, IsolatedStorageFile.GetUserStoreForDomain());
            //IFormatter formatter = new BinaryFormatter();
            //IFormatter formatter = new SoapFormatter();
            IFormatter formatter = new SafeFormatter();

            formatter.Serialize(stream, f);
            stream.Close();
   
            //Empties f.
            f = null;
   
            //Opens file "MyClass1MyClass2.bin" and deserializes the MyClass1 object from it.
            //stream = File.Open(@"c:\temp\MyClass1MyClass2.txt", FileMode.Open);
            stream = new IsolatedStorageFileStream("MyClass1MyClass2.txt", FileMode.Open, IsolatedStorageFile.GetUserStoreForDomain());
            //formatter = new BinaryFormatter();
            //formatter = new SoapFormatter();
            formatter = new SafeFormatter();
            f = (MyClass1)formatter.Deserialize(stream);
            stream.Close();

            Console.WriteLine("\nDeserialized nested object:");
            Console.WriteLine(f);
        }
        #endregion

        #region DeserializationCallback Test
        static void SaveSeries(Stream stream, DigitSeries series)
        {
            SafeFormatter   formatter = new SafeFormatter();
            //BinaryFormatter formatter = new BinaryFormatter();
            //SoapFormatter   formatter = new SoapFormatter();
            formatter.Serialize(stream, series);
        }

        static DigitSeries ReadSeries(Stream stream)
        {
            SafeFormatter   formatter = new SafeFormatter();
            //BinaryFormatter formatter = new BinaryFormatter();
            //SoapFormatter   formatter = new SoapFormatter();
            return (DigitSeries)formatter.Deserialize(stream);
        }

        static void TestDeserializationCallback()
        {
            // Exercise the formatter
            DigitSeries series1 = new DigitSeries(13, 40);

            Console.WriteLine("\nseries 1:");
            Console.WriteLine(series1);

            // Save to the formatter
            using( Stream stream = new IsolatedStorageFileStream("series1.txt", FileMode.Create, IsolatedStorageFile.GetUserStoreForDomain()) )
            {
                SaveSeries(stream, series1);
            }

            // Read from the formatter
            using( Stream stream = new IsolatedStorageFileStream("series1.txt", FileMode.Open, IsolatedStorageFile.GetUserStoreForDomain()) )
            {
                DigitSeries series2 = (DigitSeries)ReadSeries(stream);
                Console.WriteLine("\nseries 2:");
                Console.WriteLine(series2);
            }
        }
        #endregion

        static void Main(string[] args)
		{
            // Check the zone
            string  url = System.Reflection.Assembly.GetExecutingAssembly().CodeBase;
            string  zone = System.Security.Policy.Zone.CreateFromUrl(url).SecurityZone.ToString();
            Console.WriteLine("Zone= " + zone);

            // Test
            TestDeserializationCallback();

            // Wait
            Console.Write("\nPress Enter to quit");
            Console.ReadLine();
        }
	}
}
