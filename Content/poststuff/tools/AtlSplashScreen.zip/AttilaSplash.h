// AttilaSplash.h: Modified for use with Attila
////////////////////////////////////////////////////////////////
// PixieLib(TM) Copyright 1997-1999 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.

// TODO: This needs to be completely overhauled. 2 classes, one of which
//       is a window, and a threadproc is all we need here. The wierdness
//       about passing around back-pointers... yikes!

#pragma once
#ifndef INC_SPLASH
#define INC_SPLASH

#include "AttilaCommon.h"
#include "AttilaGdi.h"
#include "AttilaWrappers.h"
//#include "BmpRgn.h"
#include "qcBitmap.h"

namespace Attila
{

//////////////////////////////////////////////////////////////////
// Splash screen. To use it, write:
//
// CSplashThread* pSplash = new CSplashThread(
//		IDB_MYBITMAP,			// resource ID of bitmap
//		duration,				// min time to display, in msec
//		flags,					// see below
//		&pSplash);				// address of back pointer
//
// If you want to kill the screen, you can call
//
//		CSplashThread::Kill(pSplash);
//
// but this is usually unecessary. You don't have to call delete either;
// CSplashThread will delete itself. When it does, it sets your pointer to NULL so
// you won't try to call Kill on a bad pointer.
//
// NOTE: pSplash MUST be a static/global variable, not a local variable that
// can go out of scope, since CSplashThread will set it to NULL when the splash dies.

class CSplashWindow;

class CSplashThread
{
public:
    CSplashThread(UINT nIDRes,      // resource ID of bitmap
        UINT duration = 5000,       // how long to show (minimum)
        WORD flags = 0,             // see below
        CSplashThread** ppBackPtr = 0):   // pointer to NULL when destroyed
        m_ppBackPtr(ppBackPtr),
        m_nIDRes(nIDRes),
        m_duration(duration),
        m_flags(flags),
        m_pSplashWnd(0)
    {
        DWORD   dw;
        CloseHandle(CreateThread(0, 0, SplashThreadProc, this, 0, &dw));
    }

    enum    // flags
    {
        KillOnClick = 0x0001,		// any key/mouse dismisses splash
    };
    
    // override to create a different kind of splash window
    virtual HWND CreateSplashWindow(UINT nIDRes, UINT duration, WORD flags);

    static void Kill(CSplashThread* pSplash);
    
protected:
    CSplashThread** m_ppBackPtr;// caller's back pointer to me
    UINT            m_nIDRes;   // bitmap resource ID
    UINT            m_duration; // how long to display
    WORD            m_flags;    // CSplashWindow creation flags
    CSplashWindow*  m_pSplashWnd;
    
    static DWORD WINAPI SplashThreadProc(void* pvSplash)
    {
	    // Create the splash window
        CSplashThread*  pSplash = (CSplashThread*)pvSplash;
        if( !pSplash ) return 0;

        HWND    hwndSplash = pSplash->CreateSplashWindow(pSplash->m_nIDRes, pSplash->m_duration, pSplash->m_flags);
        if( !hwndSplash ) return 0;

        // Run this thread's message loop, waiting for WM_QUIT from the splash window
        MSG msg;
        while( GetMessage(&msg, 0, 0, 0) )
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }

        return 0;
    }
};

//////////////////
// Splash window. This class is private to CSplashThread--Don't use it unless
// you are doing some hairy stuff to override the splash window, like
// create animated effects, etc.

class CSplashWindow : public CWindowImpl<CSplashWindow>
{
public:
	// these are public so you can change easily
	static DWORD g_dwStyleDefaultEx;
	static DWORD g_dwStyleDefault;

    typedef CWindowImpl<CSplashWindow> _baseClass;

    BEGIN_MSG_MAP(CSplashWindow)
        MESSAGE_HANDLER(WM_CREATE, OnCreate)
        MESSAGE_HANDLER(WM_PAINT, OnPaint)
        MESSAGE_HANDLER(WM_TIMER, OnTimer)
        MESSAGE_HANDLER(WM_KEYDOWN, OnKeyOrMouse)
        MESSAGE_HANDLER(WM_SYSKEYDOWN, OnKeyOrMouse)
        MESSAGE_HANDLER(WM_LBUTTONDOWN, OnKeyOrMouse)
        MESSAGE_HANDLER(WM_RBUTTONDOWN, OnKeyOrMouse)
        MESSAGE_HANDLER(WM_MBUTTONDOWN, OnKeyOrMouse)
    END_MSG_MAP()

protected:
	friend class CSplashThread;

    CSplashWindow(CSplashThread* pSplash) : m_pSplash(pSplash) {}
    ~CSplashWindow() {}

	// override to do weird stuff
	virtual BOOL Create(UINT nIDRes, UINT duration, WORD flags, HWND hwndMain = 0)
    {
        //if( !m_bitmap.LoadBitmap(nIDRes) ) return FALSE;
        if( !m_bitmap.LoadDIBitmap(nIDRes) ) return FALSE;


        //BITMAP  bm; m_bitmap.GetBitmap(&bm);
        CRect   rect(0, 0, m_bitmap.Width(), m_bitmap.Height());

        m_duration = duration;
        m_flags = flags;

        HWND    hwnd = _baseClass::Create(0, rect, 0, g_dwStyleDefault, g_dwStyleDefaultEx);
        return (hwnd != 0);
    }

    void OnFinalMessage(HWND)
    {
        /*
        if( m_hwndMain )
        {
            ::SetForegroundWindow(m_hwndMain);
        }
        */

        delete this;

        PostQuitMessage(0); // Shut down this thread
    }

	LRESULT OnKeyOrMouse(UINT, LPARAM, WPARAM, BOOL&)
    {
        if( m_flags & CSplashThread::KillOnClick )
        {
			CSplashThread::Kill(m_pSplash);
        }

        return 0;
    }

	LRESULT OnCreate(UINT, LPARAM, WPARAM, BOOL&)
    {
        CenterWindow();
        UpdateWindow();
        SetForegroundWindow(m_hWnd);
        if( m_duration != -1 ) SetTimer(1, m_duration);

        // TODO: Fix this!
        //CBmpRgn     rgn;
        //SetWindowRgn(rgn.CreateRgn(m_bitmap, RGB(66, 255, 239)), TRUE);
        //qcBitmap    bm;
        //bm.FromBitmap(m_bitmap);
        SetWindowRgn(m_bitmap.GenerateWindowRegion(RGB(66, 255, 239)));

        return 0;
    }

	LRESULT OnPaint(UINT, LPARAM, WPARAM, BOOL&)
    {
        CGdiPaintDC dc(m_hWnd);

        //CGdiMemDC   dcImage;
        //if( !dcImage.CreateCompatibleDC(dc) ) return 0;

        //BITMAP bm;
        //m_bitmap.GetBitmap(&bm);
        
        // Paint the image
        //dcImage.SelectObject(m_bitmap);
        //dc.BitBlt(0, 0, m_bitmap.Width(), m_bitmap.Height(), dcImage, 0, 0, SRCCOPY);
        m_bitmap.PaintDIB(dc);

        return 0;
    }
        
	LRESULT OnTimer(UINT, LPARAM, WPARAM, BOOL&)
    {
        /*
        if( (m_flags & CSplashThread::NoWaitForMainWnd) || m_hwndMain )
        {
        */
            // Have main window: OK to die
            CSplashThread::Kill(m_pSplash);
        /*  
        }
        else
        {
            // No main window: keep splashing
            SetTimer(1, 100);
        }
        */

        return 0;
    }

private:
	CSplashThread*  m_pSplash;  // ptr to splash object
	UINT		    m_duration; // duration (msec)
	WORD		    m_flags;    // see below
    //CGdiBitmap      m_bitmap;
    qcBitmap        m_bitmap;
//    HWND            m_hwndMain;
};

// TODO: Restore WS_EX_TOPMOST
DWORD __declspec(selectany) CSplashWindow::g_dwStyleDefaultEx = WS_EX_TOOLWINDOW|WS_EX_TOPMOST;
DWORD __declspec(selectany) CSplashWindow::g_dwStyleDefault   = WS_POPUP | WS_VISIBLE;

inline
HWND CSplashThread::CreateSplashWindow(UINT nIDRes, UINT duration, WORD flags)
{
    m_pSplashWnd = new CSplashWindow(this);
    if( !m_pSplashWnd ) return 0;

    m_pSplashWnd->Create(nIDRes, duration, flags);
    return m_pSplashWnd->m_hWnd;
}

inline
void CSplashThread::Kill(CSplashThread* pSplash)
{
    static CComAutoCriticalSection  cs;
    cs.Lock();

    if( pSplash )
    {
        // splash not already dead: set pointers to NULL
        // in both the app and window.
        CSplashWindow* pSplashWnd = pSplash->m_pSplashWnd;
        ATLASSERT(pSplashWnd);

        pSplashWnd->m_pSplash = 0;

        if( pSplash->m_ppBackPtr )
        {
            *pSplash->m_ppBackPtr = 0;
            pSplash->m_ppBackPtr = 0;
        }

        pSplashWnd->PostMessage(WM_CLOSE);
        
    } // else already dead

    cs.Unlock();
}

class CSplashScreen
{
public:
    CSplashScreen() : m_pThread(0)
    {
    }

    bool Create(UINT nResID, UINT duration = 5000, WORD flags = CSplashThread::KillOnClick)
    {
        Destroy();
        m_pThread = new CSplashThread(nResID, duration, flags, &m_pThread);
        return (m_pThread != 0);
    }

    void Destroy()
    {
        CSplashThread::Kill(m_pThread);
        ATLASSERT(!m_pThread);
    }

    ~CSplashScreen()
    {
        Destroy();
    }

private:
    CSplashThread*  m_pThread;
};

}   // namespace Attila

#ifndef _ATTILA_NOUSE_NAMESPACE
using namespace Attila;
#endif

#endif  // INC_SPLASH
