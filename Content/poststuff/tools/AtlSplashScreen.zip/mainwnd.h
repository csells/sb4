// MainWnd.h: Defines main window for application

#pragma once
#ifndef MAINWND_H
#define MAINWND_H

typedef CWinTraitsOR<0, WS_EX_CLIENTEDGE, CFrameWinTraits>
        CMainWindowTraits;

class CMainWindow : public CWindowImpl<CMainWindow, CWindow, CMainWindowTraits>
{
public:
    CMainWindow()
    {
        // Initialize window info
        CWndClassInfo&  wci = GetWndClassInfo();
        if( !wci.m_atom )
        {
            wci.m_wc.hIcon = LoadIcon(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDI_ATLSPLASHSCREEN));
            wci.m_wc.hIconSm = (HICON)::LoadImage(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDI_ATLSPLASHSCREEN), IMAGE_ICON, 16, 16, LR_DEFAULTCOLOR);
            wci.m_wc.hbrBackground = CreateHatchBrush(HS_DIAGCROSS, RGB(0, 0, 255));  //CreateSolidBrush(RGB(0, 0, 255));
            wci.m_bSystemCursor = TRUE;
            wci.m_lpszCursorID = IDC_ARROW;
        }
    }

BEGIN_MSG_MAP(CMainWindow)
    MESSAGE_HANDLER(WM_PAINT, OnPaint)
    MESSAGE_HANDLER(WM_CREATE, OnCreate)
    COMMAND_ID_HANDLER(ID_FILE_EXIT, OnFileExit)
    COMMAND_ID_HANDLER(ID_HELP_ABOUT, OnHelpAbout)
END_MSG_MAP()

// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

    LRESULT OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& lResult)
    {
        m_splash.Create(IDB_SPLASH);
        return 0;
    }

    LRESULT OnPaint(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& lResult)
    {
        CGdiPaintDC dc(this->m_hWnd);
        dc.SetBkMode(TRANSPARENT);
        dc.SetTextColor(RGB(0, 0, 255));

        CRect       rect;
        GetClientRect(&rect);
        dc.DrawText("Hello, ATL", -1, &rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
        
        return 0;
    }
    
    LRESULT OnFileExit(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
    {
        DestroyWindow();
        return 0;
    }
    
    LRESULT OnHelpAbout(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
    {
        CSimpleDialog<IDD_ABOUTBOX> dlg;
        dlg.DoModal();
        return 0;
    }
    
    void OnFinalMessage(HWND)
    {
        PostQuitMessage(0);
    }

    CSplashScreen   m_splash;
};

#endif  // MAINWND_H
