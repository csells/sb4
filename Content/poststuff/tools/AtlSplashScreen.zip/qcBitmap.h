#pragma once

class qcBitmap
    {
	//  Interface

    public:
        qcBitmap();
        ~qcBitmap();

    	bool     IsValid();
        bool     LoadDIBitmap( UINT nResourceId, HMODULE hMod = NULL );
        bool     LoadDIBitmap( LPCTSTR lpszResourceName, HMODULE hMod = NULL );
        bool     LoadDIBFile( LPCTSTR lpszFilename );
        bool     SaveDIBFile( LPCTSTR lpszFilename );
        bool     FromBitmap( HBITMAP hBmp );
        bool     ToBitmap( HBITMAP pBmp );
        void     DeleteObject();
        bool     PaintDIB( HDC hdc, LPRECT lpDCRect = 0, LPRECT lpDIBRect = 0 );
		bool     TransparentPaint
		             ( HDC hdc, COLORREF clrTransparent,
					   LPRECT lpDCRect = 0, LPRECT lpDIBRect = 0 );
		HRGN     GenerateWindowRegion
			         ( COLORREF clrTransparent, int x = 0, int y = 0,
		               int cx = -1, int cy = -1 );
        DWORD    Width();
        DWORD    Height();
        int      ColorDepth();
        int      Colors();
        HPALETTE GetPalette();
        bool     CopyPalette( HPALETTE* pPalette );

	//  Implementation

    protected:
        bool     m_bIsFileDIB;
        HPALETTE m_hPalette;
		int      m_cPaletteEntries;
        HGLOBAL  m_hDIB;
        HRSRC    m_hResource;

        BITMAPINFO*     GetDIBHeader();
        BITMAPCOREINFO* GetCoreHeader();
        bool            IsWin3DIB();
        void*           FindDIBBits();
        void            LoadHelper();
    };  
