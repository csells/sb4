//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by AtlSplashScreen.rc
//
#define ID_HELP_ABOUT                   101
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define ID_FILE_EXIT                    105
#define IDI_ATLSPLASHSCREEN        107
#define IDI_SMALL                       108
#define IDC_ATLSPLASHSCREEN        109
#define IDR_ATLSPLASHSCREEN        109

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
