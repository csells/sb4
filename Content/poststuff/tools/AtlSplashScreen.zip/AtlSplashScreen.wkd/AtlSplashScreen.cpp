// AtlSplashScreen.cpp : Defines the entry point for the application.

#include "stdafx.h"
#include "resource.h"
#include "mainwnd.h"

// Required ATL module
CComModule _Module;

// Empty object map
BEGIN_OBJECT_MAP(ObjectMap)
END_OBJECT_MAP()

int WINAPI _tWinMain(HINSTANCE hinst, HINSTANCE, LPTSTR lpCmdLine, int nShow)
{
    // Initialize COM
    CoInitialize(0);

    // Initialize the ATL module
    _Module.Init(0, hinst);

	// Initialize support for common controls
	InitCommonControls(); // Normal common controls

#if (_RICHEDIT_VER < 0x0200 )
    LoadLibrary(__T("riched32.dll"));   // RTF control, v1
#else
    LoadLibrary(__T("riched20.dll"));   // RTF control, v2
#endif
    
    // Create and show the main window
    HMENU   hMenu = LoadMenu(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_ATLSPLASHSCREEN));
    TCHAR   szTitle[64] = __T("");
    LoadString(_Module.GetResourceInstance(), IDS_APP_TITLE, szTitle, sizeof(szTitle)/sizeof(*szTitle));

    CMainWindow wndMain;
    wndMain.Create(0, CWindow::rcDefault, szTitle, 0, 0, (UINT)hMenu);
    wndMain.ShowWindow(nShow);
    wndMain.UpdateWindow();

    // Pump messages
    HACCEL  haccel = LoadAccelerators(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDC_ATLSPLASHSCREEN));
    MSG     msg;
    while( GetMessage(&msg, 0, 0, 0) )
    {
        if( !TranslateAccelerator(msg.hwnd, haccel, &msg) )
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    // Terminate the ATL module
    _Module.Term();
    
    // Uninitialize COM
    CoUninitialize();
    
    return 0;
}
