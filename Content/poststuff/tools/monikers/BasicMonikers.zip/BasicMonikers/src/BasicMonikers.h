/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 3.01.75 */
/* at Mon Jun 29 16:46:11 1998
 */
/* Compiler settings for BasicMonikers.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )
#include "rpc.h"
#include "rpcndr.h"

#ifndef __BasicMonikers_h__
#define __BasicMonikers_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __Newmk_FWD_DEFINED__
#define __Newmk_FWD_DEFINED__

#ifdef __cplusplus
typedef class Newmk Newmk;
#else
typedef struct Newmk Newmk;
#endif /* __cplusplus */

#endif 	/* __Newmk_FWD_DEFINED__ */


#ifndef __Hostmk_FWD_DEFINED__
#define __Hostmk_FWD_DEFINED__

#ifdef __cplusplus
typedef class Hostmk Hostmk;
#else
typedef struct Hostmk Hostmk;
#endif /* __cplusplus */

#endif 	/* __Hostmk_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 


#ifndef __BASICMONIKERSLib_LIBRARY_DEFINED__
#define __BASICMONIKERSLib_LIBRARY_DEFINED__

/****************************************
 * Generated header for library: BASICMONIKERSLib
 * at Mon Jun 29 16:46:11 1998
 * using MIDL 3.01.75
 ****************************************/
/* [helpstring][version][uuid] */ 



EXTERN_C const IID LIBID_BASICMONIKERSLib;

#ifdef __cplusplus
EXTERN_C const CLSID CLSID_Newmk;

class DECLSPEC_UUID("05F56161-0622-11D2-90BA-00104B2168FE")
Newmk;
#endif

#ifdef __cplusplus
EXTERN_C const CLSID CLSID_Hostmk;

class DECLSPEC_UUID("FEF9C6A6-0B05-11D2-9825-00600823CFFB")
Hostmk;
#endif
#endif /* __BASICMONIKERSLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
