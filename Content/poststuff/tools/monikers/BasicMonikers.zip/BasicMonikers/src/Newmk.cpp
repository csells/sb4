// Newmk.cpp : Implementation of CNewmk

#include "stdafx.h"
#include "BasicMonikers.h"
#include "Newmk.h"

const size_t GUID_LEN = 36;

/////////////////////////////////////////////////////////////////////////////
// CNewmk

CNewmk::CNewmk() : m_clsid(CLSID_NULL)
{
}

/////////////////////////////////////////////////////////////////////////////
// IMoniker

STDMETHODIMP CNewmk::BindToObject(
    IBindCtx*   pbc,
    IMoniker*   pmkToLeft,
    REFIID      riidResult,
    void**      ppvResult)
{
    BAD_POINTER_RETURN_OR_ZERO(ppvResult);
    BAD_POINTER_RETURN(pbc);
    
    HRESULT hr = E_FAIL;
    
    if( pmkToLeft )
    {
        CComQIPtr<IClassFactory>    spcf;
        hr = pmkToLeft->BindToObject(pbc, 0, IID_IClassFactory, (void**)&spcf);
        if( SUCCEEDED(hr) )
        {
            hr = spcf->CreateInstance(0, riidResult, ppvResult);
        }
        else
        {
            CComQIPtr<IClassActivator>  spca;
            hr = pmkToLeft->BindToObject(pbc, 0, IID_IClassActivator, (void**)&spca);
            if( SUCCEEDED(hr) )
            {
                CComQIPtr<IClassFactory>    spcf;
                hr = spca->GetClassObject(m_clsid, CLSCTX_ALL, 0, IID_IClassFactory, (void**)&spcf);
                if( SUCCEEDED(hr) )
                {
                    hr = spcf->CreateInstance(0, riidResult, ppvResult);
                }
            }
        }
    }
    else
    {
        hr = CoCreateInstance(m_clsid, 0, CLSCTX_ALL, riidResult, ppvResult);
    }
    
    return hr;
}

STDMETHODIMP CNewmk::GetDisplayName(
    IBindCtx*   pbc,
    IMoniker*   pmkToLeft,
    LPOLESTR*   ppszDisplayName)
{
    BAD_POINTER_RETURN_OR_ZERO(ppszDisplayName);
    BAD_POINTER_RETURN(pbc);
    
    HRESULT hr = E_OUTOFMEMORY;
    
    // Name = "dm.newmk.1:05F56161-0622-11D2-90BA-00104B2168FE:"
    const size_t	PREFIX_LEN = ocslen(ProgID());
    *ppszDisplayName = (LPOLESTR)CoTaskMemAlloc((PREFIX_LEN + 1 + GUID_LEN + 2) * sizeof(OLECHAR));
    if( *ppszDisplayName )
    {
        ocscpy(*ppszDisplayName, ProgID());
        StringFromGUID2(m_clsid, *ppszDisplayName + PREFIX_LEN, GUID_LEN + 2 + 1);
        (*ppszDisplayName)[PREFIX_LEN - 1] = ':';
        (*ppszDisplayName)[PREFIX_LEN + 1 + GUID_LEN] = ':';
        *ppszDisplayName[PREFIX_LEN + 1 + GUID_LEN + 1] = 0;
        
        hr = S_OK;
    }
    
    return hr;
}

STDMETHODIMP CNewmk::ParseDisplayName(
    IBindCtx*   pbc,
    IMoniker*   pmkToLeft,
    LPOLESTR    pszDisplayName,
    ULONG*      pchEaten,
    IMoniker**  ppmkOut)
{
    BAD_POINTER_RETURN_OR_ZERO(ppmkOut);
    BAD_POINTER_RETURN_OR_ZERO(pchEaten);
    BAD_POINTER_RETURN(pbc);
    BAD_POINTER_RETURN(pszDisplayName);
    BAD_POINTER_RETURN(pchEaten);
    
    if( pmkToLeft ) return E_UNEXPECTED;
    
    const wchar_t*  pszDisplayParam = 0;
    if( CComMonikerBase::MatchesProgID(pszDisplayName, &pszDisplayParam) )
    {
        // Pull out param up to first ":" or end of string
        size_t	nParamLen = 0;
        while( pszDisplayParam[nParamLen] != OLESTR(':') && pszDisplayParam[nParamLen] != 0)
        {
            ++nParamLen;
        }
        
        LPOLESTR    pszParam = new OLECHAR[nParamLen + 1];
        if( !pszParam ) return E_OUTOFMEMORY;
        
        memcpy(pszParam, pszDisplayParam, nParamLen * sizeof(OLECHAR));
        pszParam[nParamLen] = 0;

        HRESULT hr = MK_E_SYNTAX;

        // Check for CLSID
        if( nParamLen == GUID_LEN )
        {
            wchar_t	wszGuid[1 + GUID_LEN + 1 + 1];
            ocscpy(wszGuid + 1, pszParam);
            wszGuid[0] = OLESTR('{');
            wszGuid[GUID_LEN + 1] = OLESTR('}');
            wszGuid[GUID_LEN + 2] = 0;
            hr = CLSIDFromString(wszGuid, &m_clsid);
        }

        // Check for ProgID
        if( FAILED(hr) )
        {
            // NOTE: This doesn't resolve on the machine of the guy to the left.
            //       It only resolves on the machine the newmk is running.
            hr = CLSIDFromProgID(pszParam, &m_clsid);
        }

        delete[] pszParam;

        // Calculate cchEaten and hand out ourselves
        if( SUCCEEDED(hr) )
        {
            *pchEaten = (pszDisplayParam - pszDisplayName) + nParamLen;
            if( pszDisplayName[*pchEaten] == OLESTR(':') )
            {
                (*pchEaten)++;
            }
            
            (*ppmkOut = this)->AddRef();
            return S_OK;
        }
    }
    
    return MK_E_SYNTAX;
}

