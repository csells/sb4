#include <windows.h>
#include <atlbase.h>
#include <stdio.h>

struct ComInit { ComInit() { CoInitialize(0); } ~ComInit() { CoUninitialize(); } };
ComInit g_com;

#define TEST_HOST   L"frodo"
#define TEST_PROGID L"Excel.Application"
#define TEST_CLSID  L"00024500-0000-0000-C000-000000000046"

HRESULT TestGetObject(LPCOLESTR psz)
{
    CComPtr<IUnknown>	spunk;
    HRESULT             hr = CoGetObject(psz, 0, IID_IUnknown, (void**)&spunk);
    if( SUCCEEDED(hr) )
    {
        wprintf(L"Got %s\n", psz);
    }
    else
    {
        wprintf(L"Failed to get %s (0x%x)\n", psz, hr);
    }
    
    return hr;
}

int main()
{
    // newmk w/ progid and progid
    TestGetObject(L"dm.newmk.1:" TEST_PROGID);
    
    // newmk w/ progid and clsid
    TestGetObject(L"dm.newmk.1:" TEST_CLSID);
    
    // newmk w/ viprogid and clsid
    TestGetObject(L"dm.newmk:" TEST_CLSID);
    
    // newmk w/ progid, clsid and colon
    TestGetObject(L"dm.newmk.1:" TEST_CLSID L":");
    
    // newmk w/ viprogid, clsid and colon
    TestGetObject(L"dm.newmk:" TEST_CLSID L":");
    
    // hostmk w/ progid, colon, bang and newmk
    TestGetObject(L"dm.hostmk.1:" TEST_HOST L":!dm.newmk.1:" TEST_CLSID L":");
    
    // hostmk w/ viprogid, colon, bang and newmk
    TestGetObject(L"dm.hostmk:" TEST_HOST L":!dm.newmk.1:" TEST_CLSID L":");
    
    // hostmk w/ progid, colon and newmk
    TestGetObject(L"dm.hostmk.1:" TEST_HOST L":dm.newmk.1:" TEST_CLSID L":");
    
    // hostmk w/ viprogid, colon and newmk
    TestGetObject(L"dm.hostmk:" TEST_HOST L":dm.newmk.1:" TEST_CLSID L":");
    
    return S_OK;
}
