/* this ALWAYS GENERATED file contains the proxy stub code */


/* File created by MIDL compiler version 3.01.75 */
/* at Mon Jun 29 15:49:07 1998
 */
/* Compiler settings for BasicMonikers.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )

#define USE_STUBLESS_PROXY

#include "rpcproxy.h"
#include "BasicMonikers.h"

#define TYPE_FORMAT_STRING_SIZE   1                                 
#define PROC_FORMAT_STRING_SIZE   1                                 

typedef struct _MIDL_TYPE_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ TYPE_FORMAT_STRING_SIZE ];
    } MIDL_TYPE_FORMAT_STRING;

typedef struct _MIDL_PROC_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ PROC_FORMAT_STRING_SIZE ];
    } MIDL_PROC_FORMAT_STRING;


extern const MIDL_TYPE_FORMAT_STRING __MIDL_TypeFormatString;
extern const MIDL_PROC_FORMAT_STRING __MIDL_ProcFormatString;


/* Object interface: IUnknown, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}} */


/* Object interface: IHostmk, ver. 0.0,
   GUID={0xFEF9C6A5,0x0B05,0x11D2,{0x98,0x25,0x00,0x60,0x08,0x23,0xCF,0xFB}} */


extern const MIDL_STUB_DESC Object_StubDesc;


#pragma code_seg(".orpc")

static const MIDL_STUB_DESC Object_StubDesc = 
    {
    0,
    NdrOleAllocate,
    NdrOleFree,
    0,
    0,
    0,
    0,
    0,
    __MIDL_TypeFormatString.Format,
    0, /* -error bounds_check flag */
    0x20000, /* Ndr library version */
    0,
    0x301004b, /* MIDL Version 3.1.75 */
    0,
    0,
    0,  /* Reserved1 */
    0,  /* Reserved2 */
    0,  /* Reserved3 */
    0,  /* Reserved4 */
    0   /* Reserved5 */
    };

CINTERFACE_PROXY_VTABLE(3) _IHostmkProxyVtbl = 
{
    0,
    &IID_IHostmk,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy
};

const CInterfaceStubVtbl _IHostmkStubVtbl =
{
    &IID_IHostmk,
    0,
    3,
    0, /* pure interpreted */
    CStdStubBuffer_METHODS
};

#pragma data_seg(".rdata")

#if !defined(__RPC_WIN32__)
#error  Invalid build platform for this stub.
#endif

#if !(TARGET_IS_NT40_OR_LATER)
#error You need a Windows NT 4.0 or later to run this stub because it uses these features:
#error   -Oif or -Oicf.
#error However, your C/C++ compilation flags indicate you intend to run this app on earlier systems.
#error This app will die there with the RPC_X_WRONG_STUB_VERSION error.
#endif


static const MIDL_PROC_FORMAT_STRING __MIDL_ProcFormatString =
    {
        0,
        {

			0x0
        }
    };

static const MIDL_TYPE_FORMAT_STRING __MIDL_TypeFormatString =
    {
        0,
        {

			0x0
        }
    };

const CInterfaceProxyVtbl * _BasicMonikers_ProxyVtblList[] = 
{
    ( CInterfaceProxyVtbl *) &_IHostmkProxyVtbl,
    0
};

const CInterfaceStubVtbl * _BasicMonikers_StubVtblList[] = 
{
    ( CInterfaceStubVtbl *) &_IHostmkStubVtbl,
    0
};

PCInterfaceName const _BasicMonikers_InterfaceNamesList[] = 
{
    "IHostmk",
    0
};


#define _BasicMonikers_CHECK_IID(n)	IID_GENERIC_CHECK_IID( _BasicMonikers, pIID, n)

int __stdcall _BasicMonikers_IID_Lookup( const IID * pIID, int * pIndex )
{
    
    if(!_BasicMonikers_CHECK_IID(0))
        {
        *pIndex = 0;
        return 1;
        }

    return 0;
}

const ExtendedProxyFileInfo BasicMonikers_ProxyFileInfo = 
{
    (PCInterfaceProxyVtblList *) & _BasicMonikers_ProxyVtblList,
    (PCInterfaceStubVtblList *) & _BasicMonikers_StubVtblList,
    (const PCInterfaceName * ) & _BasicMonikers_InterfaceNamesList,
    0, // no delegation
    & _BasicMonikers_IID_Lookup, 
    1,
    2
};
