// Newmk.h : Declaration of the CNewmk

#ifndef __NEWMK_H_
#define __NEWMK_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CNewmk
class ATL_NO_VTABLE CNewmk : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CNewmk, &CLSID_Newmk>,
	public CComMoniker<CNewmk>
{
public:
    CNewmk();

	DECLARE_REGISTRY(CLSID_Newmk, _T("dm.newmk.1"), _T("dm.newmk"), IDS_NEWMK, THREADFLAGS_BOTH)

DECLARE_NOT_AGGREGATABLE(CNewmk)

BEGIN_COM_MAP(CNewmk)
	COM_INTERFACE_ENTRY(IPersist)
	COM_INTERFACE_ENTRY(IPersistStream)
	COM_INTERFACE_ENTRY(IMoniker)
	COM_INTERFACE_ENTRY(IParseDisplayName)
	COM_INTERFACE_ENTRY(IROTData)
	COM_INTERFACE_ENTRY(IMarshal)
END_COM_MAP()

public:
	// IMoniker
    STDMETHODIMP BindToObject(IBindCtx *pbc, IMoniker *pmkToLeft,
                              REFIID riidResult, void **ppvResult);

	STDMETHODIMP GetDisplayName(IBindCtx *pbc, IMoniker *pmkToLeft,
                                LPOLESTR *ppszDisplayName);

	STDMETHODIMP ParseDisplayName(IBindCtx *pbc, IMoniker *pmkToLeft,
                                  LPOLESTR pszDisplayName, ULONG *pchEaten,
                                  IMoniker **ppmkOut);

protected:
    // Display Name Helpers
    //virtual const wchar_t* ProgID() { return OLESTR("dm.newmk.1"); }
    //virtual const wchar_t* VersionIndependentProgID() { return OLESTR("dm.newmk"); }

private:
	CLSID	    m_clsid;
};

#endif //__NEWMK_H_
