// Hostmk.h : Declaration of the CHostmk

#ifndef __HOSTMK_H_
#define __HOSTMK_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CHostmk
class ATL_NO_VTABLE CHostmk : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CHostmk, &CLSID_Hostmk>,
	public CComMoniker<CHostmk>,
	public IClassActivator
{
public:
	CHostmk();
	~CHostmk();

	DECLARE_REGISTRY(CLSID_Hostmk, _T("dm.hostmk.1"), _T("dm.hostmk"), IDS_HOSTMK, THREADFLAGS_BOTH)

DECLARE_NOT_AGGREGATABLE(CHostmk)

BEGIN_COM_MAP(CHostmk)
	COM_INTERFACE_ENTRY(IPersist)
	COM_INTERFACE_ENTRY(IPersistStream)
	COM_INTERFACE_ENTRY(IMoniker)
	COM_INTERFACE_ENTRY(IParseDisplayName)
	COM_INTERFACE_ENTRY(IROTData)
	COM_INTERFACE_ENTRY(IMarshal)
	COM_INTERFACE_ENTRY(IClassActivator)
END_COM_MAP()

public:
	// IMoniker
    STDMETHODIMP BindToObject(IBindCtx *pbc, IMoniker *pmkToLeft,
                              REFIID riidResult, void **ppvResult);

	STDMETHODIMP GetDisplayName(IBindCtx *pbc, IMoniker *pmkToLeft,
                                LPOLESTR *ppszDisplayName);

	STDMETHODIMP ParseDisplayName(IBindCtx *pbc, IMoniker *pmkToLeft,
                                  LPOLESTR pszDisplayName, ULONG *pchEaten,
                                  IMoniker **ppmkOut);

	// IClassActivator
	STDMETHODIMP GetClassObject(REFCLSID pClassID, DWORD dwClsContext,
								LCID locale, REFIID riid, void ** ppv);

protected:
    // Display Name Helpers
    //virtual const wchar_t* ProgID() { return OLESTR("dm.hostmk.1"); }
    //virtual const wchar_t* VersionIndependentProgID() { return OLESTR("dm.hostmk"); }

private:
	LPOLESTR	m_pszHost;
};

#endif //__HOSTMK_H_
