// Hostmk.cpp : Implementation of CHostmk

#include "stdafx.h"
#include "BasicMonikers.h"
#include "Hostmk.h"

/////////////////////////////////////////////////////////////////////////////
// CHostmk

CHostmk::CHostmk() : m_pszHost(0)
{
}

CHostmk::~CHostmk()
{
    delete[] m_pszHost;
}

/////////////////////////////////////////////////////////////////////////////
// IMoniker

STDMETHODIMP CHostmk::BindToObject(
    IBindCtx*   pbc,
    IMoniker*   pmkToLeft,
    REFIID      riidResult,
    void**      ppvResult)
{
    BAD_POINTER_RETURN_OR_ZERO(ppvResult);
    BAD_POINTER_RETURN(pbc);
    
    if( pmkToLeft ) return E_UNEXPECTED;
    return GetUnknown()->QueryInterface(riidResult, ppvResult);
}

STDMETHODIMP CHostmk::GetDisplayName(
    IBindCtx*   pbc,
    IMoniker*   pmkToLeft,
    LPOLESTR*   ppszDisplayName)
{
    BAD_POINTER_RETURN(pbc);
    if( !m_pszHost ) return E_UNEXPECTED;
    
    HRESULT hr = E_OUTOFMEMORY;
    
    // Name = "dm.hostmk.1:hostname:"
    const size_t	PREFIX_LEN = ocslen(ProgID());
    const size_t	cchHost = ocslen(m_pszHost);
    *ppszDisplayName = (LPOLESTR)CoTaskMemAlloc((PREFIX_LEN + 1 + cchHost + 1) * sizeof(OLECHAR));
    if( *ppszDisplayName )
    {
        ocscpy(*ppszDisplayName, ProgID());
        (*ppszDisplayName)[PREFIX_LEN - 1] = ':';
        ocscpy((*ppszDisplayName) + PREFIX_LEN + 1, m_pszHost);
        (*ppszDisplayName)[PREFIX_LEN + 1 + cchHost] = ':';
        *ppszDisplayName[PREFIX_LEN + 1 + cchHost + 1] = 0;
        
        hr = S_OK;
    }
    
    return hr;
}

STDMETHODIMP CHostmk::ParseDisplayName(
    IBindCtx*   pbc,
    IMoniker*   pmkToLeft,
    LPOLESTR    pszDisplayName,
    ULONG*      pchEaten,
    IMoniker**  ppmkOut)
{
    BAD_POINTER_RETURN_OR_ZERO(ppmkOut);
    BAD_POINTER_RETURN_OR_ZERO(pchEaten);
    BAD_POINTER_RETURN(pbc);
    BAD_POINTER_RETURN(pszDisplayName);
    BAD_POINTER_RETURN(pchEaten);
    
    if( pmkToLeft ) return MK_E_SYNTAX;
    
    // Parse my display name
    if( !m_pszHost )
    {
        const wchar_t*  pszDisplayParam = 0;
        if( CComMonikerBase::MatchesProgID(pszDisplayName, &pszDisplayParam) )
        {
            size_t	nParamLen = 0;
            while( pszDisplayParam[nParamLen] != OLESTR(':') && pszDisplayParam[nParamLen] != 0)
            {
                ++nParamLen;
            }
            
            m_pszHost = new OLECHAR[nParamLen + 1];
            if( !m_pszHost ) return E_OUTOFMEMORY;
            
            memcpy(m_pszHost, pszDisplayParam, nParamLen * sizeof(OLECHAR));
            m_pszHost[nParamLen] = 0;
            *pchEaten = pszDisplayParam - pszDisplayName + nParamLen;
            if( pszDisplayName[*pchEaten] == ':' )
            {
                (*pchEaten)++;
            }
            (*ppmkOut = this)->AddRef();
            
            return S_OK;
        }

        return MK_E_SYNTAX;
    }
    // Parse the display name of the guy to the right,
    // because if chEaten as returned from the 1st call to ParseDisplayName
    // is returned as less than the whole string, MkParseDisplayName will
    // call us back to parse the rest and then compose the two.
    else
    {
        // Remember to strip off the optional "!" and count it in the eaten characters
        bool    bBang = (*pszDisplayName == OLESTR('!'));
        HRESULT hr = MkParseDisplayName(pbc,
                                        (bBang ? pszDisplayName + 1 : pszDisplayName),
                                        pchEaten,
                                        ppmkOut);

        if( SUCCEEDED(hr) && bBang ) (*pchEaten)++;
        return hr;
    }
}

STDMETHODIMP CHostmk::GetClassObject(
    REFCLSID    pClassID,
    DWORD       dwClsContext,
    LCID        locale,
    REFIID      riid,
    void**      ppv)
{
    COSERVERINFO csi = { 0, m_pszHost };
    return CoGetClassObject(pClassID, dwClsContext, &csi, riid, ppv);
}
