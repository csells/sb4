/////////////////////////////////////////////////////////////////////////////
// mkbase.cpp: CComMonikerBase definition
/////////////////////////////////////////////////////////////////////////////
// Copyright (c) 1997-2001, Tim Ewald, Chris Sells and Don Box.
// All rights reserved.
//
// History:
// 2/9/01:
//  Moved implementation to header file for convenience.
//
// 1/8/99:
//  Szegedi Attila [mailto:astid@EDGE.STUD.U-SZEGED.HU] noticed a bug
//  in the way we implemented Reduce, i.e. not setting *ppmkToLeft to NULL.
//
// 12/22/98:
//  Fixed a bug in Hash that caused the loop not to terminate.
//  Replaced use of memicmp w/ wcsnicmp in MatchesProgID.
//  (Thanks Florman, Bruce [BruceF@inter-intelli.com] for both of these.)
//
// 6/15/98
//  Fixed a bug in GetSizeMax that calculated size of display name improperly.

// NOTE: This file is no longer required.
