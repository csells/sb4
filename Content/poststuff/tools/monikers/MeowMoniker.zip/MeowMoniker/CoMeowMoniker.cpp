// CoMeowMoniker.cpp : Implementation of CoMeowMoniker

#include "stdafx.h"

#include "MeowMoniker.h"
#include "CoMeowMoniker.h"
#include "Base64.h"

/////////////////////////////////////////////////////////////////////////////
// CoMeowMoniker

// Marshal interface into m_pszItf
HRESULT CoMeowMoniker::MarshalInterface(
    IUnknown*   punk,
    REFIID      riid,
    DWORD       dwDestContext,
    DWORD       mshlflags)
{
    if( m_pszItf ) return E_UNEXPECTED;

    // Marshal the interface into a stream
    SIP(IStream) pstm;
    HR(CreateStreamOnHGlobal(0, TRUE, &pstm));
    HR(CoMarshalInterface(pstm, riid, punk, dwDestContext, 0, mshlflags));

    // Treat the marshalled interface as an array of bytes
    HGLOBAL hg;
    HR(GetHGlobalFromStream(pstm, &hg));

    BYTE*   rgbRaw = (BYTE*)GlobalLock(hg);
    if( !rgbRaw ) return MAKE_HRESULT(SEVERITY_ERROR, FACILITY_WINDOWS, GetLastError());

    // Allocate enough memory for encoded string
    ULONG   nRawSize = GlobalSize(hg);
    size_t  nEncodedLen = (nRawSize + 2)/3 * 4; // Round up
    m_pszItf = new char[nEncodedLen + 1];
    if( !m_pszItf ) return E_OUTOFMEMORY;

    // Base64 encode raw data into a string
    HR(BufferEncode64(const_cast<char*>(m_pszItf), nEncodedLen, rgbRaw, nRawSize));

    // NULL-terminate for convenience
    const_cast<char*>(m_pszItf)[nEncodedLen] = 0;

    return S_OK;
}

// Unmarshal interface from m_pszItf
HRESULT CoMeowMoniker::UnmarshalInterface(
    REFIID  riid,
    void**  ppv)
{
    HRESULT hr = S_OK;
    if( !m_pszItf ) return E_UNEXPECTED;

    // Allocate memory for decoded itf
    size_t  nEncodedLen = strlen(m_pszItf);
    assert(nEncodedLen && (nEncodedLen%4 == 0));

    size_t  nRawSize = nEncodedLen/4 * 3;
    HGLOBAL hg = GlobalAlloc(GPTR, nRawSize);
    if( !hg ) return E_OUTOFMEMORY;

    // Build a stream on the memory
    SIP(IStream) pstm;
    HR(CreateStreamOnHGlobal(hg, TRUE, &pstm));

    // Base64 decode from string into raw memory
    BYTE*   rgbRaw = (BYTE*)GlobalLock(hg);
    if( !rgbRaw ) return MAKE_HRESULT(SEVERITY_ERROR, FACILITY_WINDOWS, GetLastError());

    HR(BufferDecode64(rgbRaw, &nRawSize, m_pszItf, nEncodedLen));

    // Unmarshal the interface pointer from the stream
    HR(CoUnmarshalInterface(pstm, riid, ppv));

    return S_OK;
}

STDMETHODIMP CoMeowMoniker::BindToObject(
    IBindCtx*   pbc,
    IMoniker*   pmkToLeft,
    REFIID      riidResult,
    void**      ppvResult)
{
    BAD_POINTER_RETURN_OR_ZERO(ppvResult);
    BAD_POINTER_RETURN(pbc);

    if( pmkToLeft ) return E_UNEXPECTED;
    return UnmarshalInterface(riidResult, ppvResult); 
}

STDMETHODIMP CoMeowMoniker::GetDisplayName(
    IBindCtx*   pbc,
    IMoniker*   pmkToLeft,
    LPOLESTR*   ppwszDisplayName)
{
    BAD_POINTER_RETURN_OR_ZERO(ppwszDisplayName);
    BAD_POINTER_RETURN(pbc);

    if( pmkToLeft ) return E_UNEXPECTED;
    if( !m_pszItf ) return E_UNEXPECTED;

    // Name Format: "dm.meow.1:<marshalled interface as base64 encoding>"
    size_t  cb = (wcslen(ProgID()) + 1 + strlen(m_pszItf) + 1) * sizeof(wchar_t);
    *ppwszDisplayName = (wchar_t*)CoTaskMemAlloc(cb);
    if( !*ppwszDisplayName ) return E_OUTOFMEMORY;
    
    wcscpy(*ppwszDisplayName, ProgID());
    wcscat(*ppwszDisplayName, L":");
    mbstowcs(*ppwszDisplayName + wcslen(*ppwszDisplayName), m_pszItf, strlen(m_pszItf) + 1);

    return S_OK;
}

STDMETHODIMP CoMeowMoniker::ParseDisplayName(
    IBindCtx*   pbc,
    IMoniker*   pmkToLeft,
    LPOLESTR    pwszDisplayName,
    ULONG*      pchEaten,
    IMoniker**  ppmkOut)
{
    BAD_POINTER_RETURN_OR_ZERO(ppmkOut);
    BAD_POINTER_RETURN_OR_ZERO(pchEaten);
    BAD_POINTER_RETURN(pbc);
    BAD_POINTER_RETURN(pwszDisplayName);
    BAD_POINTER_RETURN(pchEaten);

    if( pmkToLeft ) return E_UNEXPECTED;
    if( m_pszItf ) return E_UNEXPECTED;

    const wchar_t*  pwszDisplayParam;
    if( CComMonikerBase::MatchesProgID(pwszDisplayName, &pwszDisplayParam) )
    {
        int cchItf = wcslen(pwszDisplayParam);
        m_pszItf = new char[cchItf + 1];
        if( !m_pszItf ) return E_OUTOFMEMORY;

        wcstombs(const_cast<char*>(m_pszItf), pwszDisplayParam, cchItf + 1);
        *pchEaten = wcslen(pwszDisplayName);
        (*ppmkOut = this)->AddRef();
        return S_OK;
    }

    return MK_E_SYNTAX;
}

STDAPI CreateMeowMoniker(
    IUnknown*   punk,
    REFIID      riid,
    DWORD       dwDestContext,
    DWORD       mshlflags,
    IMoniker**  ppmk)
{
    BAD_POINTER_RETURN_OR_ZERO(ppmk);

    HRESULT         hr = E_OUTOFMEMORY;
    CoMeowMoniker*  pMeow = new CComObject<CoMeowMoniker>;
    if( pMeow )
    {
        // Just to do AddRef() and Release() so moniker object
        // is properly destroyed if it isn't handed out
        CComPtr<IUnknown>   punkMeow = pMeow->GetUnknown();
        hr = pMeow->MarshalInterface(punk, riid, dwDestContext, mshlflags);
        if( SUCCEEDED(hr) )
        {
            (*ppmk = pMeow)->AddRef();
        }
    }

    return hr;
}
