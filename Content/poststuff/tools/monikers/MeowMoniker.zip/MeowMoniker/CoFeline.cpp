// CoFeline.cpp : Implementation of CoFeline

#include "stdafx.h"
#include "MeowMoniker.h"
#include "CoFeline.h"

/////////////////////////////////////////////////////////////////////////////
// CoFeline

STDMETHODIMP CoFeline::GetDisplayName(
    IDispatch*  pdisp,
    BSTR*       pbstrName)
{
    BAD_POINTER_RETURN_OR_ZERO(pbstrName);
    BAD_POINTER_RETURN(pdisp);

    SIP(IMoniker)   pmk;
    HR(CreateMeowMoniker(pdisp,
                         IID_IDispatch,
                         MSHCTX_DIFFERENTMACHINE,
                         MSHLFLAGS_NORMAL,
                         &pmk));

    SIP(IBindCtx)    pbc;
    HR(CreateBindCtx(0, &pbc));

    wchar_t*    pwszDisplayName;
    HR(pmk->GetDisplayName(pbc, 0, &pwszDisplayName));

    *pbstrName = SysAllocString(pwszDisplayName);
    CoTaskMemFree(pwszDisplayName);
    if( !pbstrName ) return E_OUTOFMEMORY;

    return S_OK;
}

STDMETHODIMP CoFeline::ParseDisplayName(
    BSTR        bstrName,
    IDispatch** ppdisp)
{
    BAD_POINTER_RETURN_OR_ZERO(ppdisp);
    BAD_POINTER_RETURN(bstrName);

    SIP(IBindCtx)   pbc;
    HR(CreateBindCtx(0, &pbc));

    SIP(IMoniker)   pmk;
    ULONG           cchEaten;
    HR(MkParseDisplayName(pbc,
                          bstrName,
                          &cchEaten,
                          &pmk));

    HR(pmk->BindToObject(pbc,
                         0,
                         IID_IDispatch,
                         (void**)ppdisp));

    return S_OK;
}
