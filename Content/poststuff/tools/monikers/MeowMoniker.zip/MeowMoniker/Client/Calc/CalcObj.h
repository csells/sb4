// CalcObj.h : Declaration of the CCalcObj

#ifndef __CALCOBJ_H_
#define __CALCOBJ_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CCalcObj
class ATL_NO_VTABLE CCalcObj : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CCalcObj, &CLSID_CalcObj>,
	public ICalcObj
{
public:
	CCalcObj()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_CALCOBJ)
DECLARE_NOT_AGGREGATABLE(CCalcObj)

BEGIN_COM_MAP(CCalcObj)
	COM_INTERFACE_ENTRY(ICalcObj)
END_COM_MAP()

// ICalcObj
public:
	STDMETHOD(Add)(long n);
	STDMETHOD(get_Sum)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_Sum)(/*[in]*/ long newVal);
private:
	long m_nSum;
};

#endif //__CALCOBJ_H_
