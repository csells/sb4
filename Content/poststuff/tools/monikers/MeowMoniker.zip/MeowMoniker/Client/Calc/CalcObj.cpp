// CalcObj.cpp : Implementation of CCalcObj
#include "stdafx.h"
#include "Calc.h"
#include "CalcObj.h"

/////////////////////////////////////////////////////////////////////////////
// CCalcObj


STDMETHODIMP CCalcObj::get_Sum(long * pVal)
{
	*pVal = m_nSum;

	return S_OK;
}

STDMETHODIMP CCalcObj::put_Sum(long newVal)
{
	m_nSum = newVal;

	return S_OK;
}

STDMETHODIMP CCalcObj::Add(long n)
{
	m_nSum += n;

	return S_OK;
}
