// NestedDispatch.cpp : Implementation of CNestedDispatch
#include "stdafx.h"
#include "multidisp.h"
#include "NestedDispatch.h"

/////////////////////////////////////////////////////////////////////////////
// CNestedDispatch

