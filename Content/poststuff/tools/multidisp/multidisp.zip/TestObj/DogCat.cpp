// DogCat.cpp : Implementation of CDogCat
#include "stdafx.h"
#include "TestObj.h"
#include "DogCat.h"

/////////////////////////////////////////////////////////////////////////////
// CDogCat


STDMETHODIMP CDogCat::Bark()
{
	MessageBox(0, "Woof", "", MB_SETFOREGROUND);

	return S_OK;
}

STDMETHODIMP CDogCat::Purr()
{
	MessageBox(0, "Meow", "", MB_SETFOREGROUND);

	return S_OK;
}
