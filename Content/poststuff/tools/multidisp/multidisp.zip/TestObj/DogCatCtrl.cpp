// DogCatCtrl.cpp : Implementation of CDogCatCtrl
#include "stdafx.h"
#include "TestObj.h"
#include "DogCatCtrl.h"

/////////////////////////////////////////////////////////////////////////////
// CDogCatCtrl


HRESULT CDogCatCtrl::OnDraw(ATL_DRAWINFO& di)
{
	RECT& rc = *(RECT*)di.prcBounds;
	Rectangle(di.hdcDraw, rc.left, rc.top, rc.right, rc.bottom);
    DrawTextW(di.hdcDraw, m_bstr.Length() ? m_bstr : L"", -1, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	return S_OK;
}

STDMETHODIMP CDogCatCtrl::get_BarkPurrString(BSTR * pVal)
{
	*pVal = m_bstr.Copy();

	return S_OK;
}

STDMETHODIMP CDogCatCtrl::put_BarkPurrString(BSTR newVal)
{
	m_bstr = newVal;
    FireViewChange();

	return S_OK;
}

STDMETHODIMP CDogCatCtrl::Bark()
{
	MessageBoxW(0, m_bstr, L"Bark", MB_SETFOREGROUND);

	return S_OK;
}

STDMETHODIMP CDogCatCtrl::Purr()
{
	MessageBoxW(0, m_bstr, L"Purr", MB_SETFOREGROUND);

	return S_OK;
}
