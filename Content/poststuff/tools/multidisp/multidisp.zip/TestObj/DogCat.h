// DogCat.h : Declaration of the CDogCat

#ifndef __DOGCAT_H_
#define __DOGCAT_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CDogCat
class ATL_NO_VTABLE CDogCat : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CDogCat, &CLSID_DogCat>,
    public IProvideClassInfoImpl<&CLSID_DogCat, &LIBID_TESTOBJLib>,
	public ICat,
	public IDog
{
public:
	CDogCat()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_DOGCAT)
DECLARE_GET_CONTROLLING_UNKNOWN()

BEGIN_COM_MAP(CDogCat)
	COM_INTERFACE_ENTRY(IDog)
	COM_INTERFACE_ENTRY(ICat)
	COM_INTERFACE_ENTRY(IProvideClassInfo)
    //COM_INTERFACE_ENTRY_BREAK(IDispatch)
	COM_INTERFACE_ENTRY_AUTOAGGREGATE(IID_IDispatch, m_spDispatch.p, CLSID_NestedDispatch)
END_COM_MAP()

// IDogCat
public:
	STDMETHOD(Bark)();
	STDMETHOD(Purr)();

public:
    CComPtr<IUnknown> m_spDispatch;
};

#endif //__DOGCAT_H_
