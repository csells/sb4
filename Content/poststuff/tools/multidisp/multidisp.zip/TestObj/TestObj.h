/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 3.01.75 */
/* at Thu Jun 18 18:00:20 1998
 */
/* Compiler settings for TestObj.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )
#include "rpc.h"
#include "rpcndr.h"
#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __TestObj_h__
#define __TestObj_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IDog_FWD_DEFINED__
#define __IDog_FWD_DEFINED__
typedef interface IDog IDog;
#endif 	/* __IDog_FWD_DEFINED__ */


#ifndef __ICat_FWD_DEFINED__
#define __ICat_FWD_DEFINED__
typedef interface ICat ICat;
#endif 	/* __ICat_FWD_DEFINED__ */


#ifndef __IDogCatCtrl_FWD_DEFINED__
#define __IDogCatCtrl_FWD_DEFINED__
typedef interface IDogCatCtrl IDogCatCtrl;
#endif 	/* __IDogCatCtrl_FWD_DEFINED__ */


#ifndef __DogCat_FWD_DEFINED__
#define __DogCat_FWD_DEFINED__

#ifdef __cplusplus
typedef class DogCat DogCat;
#else
typedef struct DogCat DogCat;
#endif /* __cplusplus */

#endif 	/* __DogCat_FWD_DEFINED__ */


#ifndef __DogCatCtrl_FWD_DEFINED__
#define __DogCatCtrl_FWD_DEFINED__

#ifdef __cplusplus
typedef class DogCatCtrl DogCatCtrl;
#else
typedef struct DogCatCtrl DogCatCtrl;
#endif /* __cplusplus */

#endif 	/* __DogCatCtrl_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IDog_INTERFACE_DEFINED__
#define __IDog_INTERFACE_DEFINED__

/****************************************
 * Generated header for interface: IDog
 * at Thu Jun 18 18:00:20 1998
 * using MIDL 3.01.75
 ****************************************/
/* [object][unique][helpstring][oleautomation][uuid] */ 



EXTERN_C const IID IID_IDog;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    interface DECLSPEC_UUID("71B24C0E-FE53-11D1-9280-006008026FEA")
    IDog : public IUnknown
    {
    public:
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Bark( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDogVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IDog __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IDog __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IDog __RPC_FAR * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Bark )( 
            IDog __RPC_FAR * This);
        
        END_INTERFACE
    } IDogVtbl;

    interface IDog
    {
        CONST_VTBL struct IDogVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDog_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDog_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDog_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDog_Bark(This)	\
    (This)->lpVtbl -> Bark(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring] */ HRESULT STDMETHODCALLTYPE IDog_Bark_Proxy( 
    IDog __RPC_FAR * This);


void __RPC_STUB IDog_Bark_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IDog_INTERFACE_DEFINED__ */


#ifndef __ICat_INTERFACE_DEFINED__
#define __ICat_INTERFACE_DEFINED__

/****************************************
 * Generated header for interface: ICat
 * at Thu Jun 18 18:00:20 1998
 * using MIDL 3.01.75
 ****************************************/
/* [object][unique][helpstring][oleautomation][uuid] */ 



EXTERN_C const IID IID_ICat;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    interface DECLSPEC_UUID("71B24C1A-FE53-11D1-9280-006008026FEA")
    ICat : public IUnknown
    {
    public:
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Purr( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ICatVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ICat __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ICat __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ICat __RPC_FAR * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Purr )( 
            ICat __RPC_FAR * This);
        
        END_INTERFACE
    } ICatVtbl;

    interface ICat
    {
        CONST_VTBL struct ICatVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ICat_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICat_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICat_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ICat_Purr(This)	\
    (This)->lpVtbl -> Purr(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring] */ HRESULT STDMETHODCALLTYPE ICat_Purr_Proxy( 
    ICat __RPC_FAR * This);


void __RPC_STUB ICat_Purr_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ICat_INTERFACE_DEFINED__ */


#ifndef __IDogCatCtrl_INTERFACE_DEFINED__
#define __IDogCatCtrl_INTERFACE_DEFINED__

/****************************************
 * Generated header for interface: IDogCatCtrl
 * at Thu Jun 18 18:00:20 1998
 * using MIDL 3.01.75
 ****************************************/
/* [object][unique][helpstring][dual][uuid] */ 



EXTERN_C const IID IID_IDogCatCtrl;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    interface DECLSPEC_UUID("05F56163-0622-11D2-90BA-00104B2168FE")
    IDogCatCtrl : public IDispatch
    {
    public:
        virtual /* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE get_BarkPurrString( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE put_BarkPurrString( 
            /* [in] */ BSTR newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDogCatCtrlVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IDogCatCtrl __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IDogCatCtrl __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IDogCatCtrl __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IDogCatCtrl __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IDogCatCtrl __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IDogCatCtrl __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IDogCatCtrl __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_BarkPurrString )( 
            IDogCatCtrl __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_BarkPurrString )( 
            IDogCatCtrl __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        END_INTERFACE
    } IDogCatCtrlVtbl;

    interface IDogCatCtrl
    {
        CONST_VTBL struct IDogCatCtrlVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDogCatCtrl_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDogCatCtrl_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDogCatCtrl_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDogCatCtrl_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IDogCatCtrl_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IDogCatCtrl_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IDogCatCtrl_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IDogCatCtrl_get_BarkPurrString(This,pVal)	\
    (This)->lpVtbl -> get_BarkPurrString(This,pVal)

#define IDogCatCtrl_put_BarkPurrString(This,newVal)	\
    (This)->lpVtbl -> put_BarkPurrString(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][propget] */ HRESULT STDMETHODCALLTYPE IDogCatCtrl_get_BarkPurrString_Proxy( 
    IDogCatCtrl __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IDogCatCtrl_get_BarkPurrString_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][propput] */ HRESULT STDMETHODCALLTYPE IDogCatCtrl_put_BarkPurrString_Proxy( 
    IDogCatCtrl __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IDogCatCtrl_put_BarkPurrString_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IDogCatCtrl_INTERFACE_DEFINED__ */



#ifndef __TESTOBJLib_LIBRARY_DEFINED__
#define __TESTOBJLib_LIBRARY_DEFINED__

/****************************************
 * Generated header for library: TESTOBJLib
 * at Thu Jun 18 18:00:20 1998
 * using MIDL 3.01.75
 ****************************************/
/* [helpstring][version][uuid] */ 



EXTERN_C const IID LIBID_TESTOBJLib;

#ifdef __cplusplus
EXTERN_C const CLSID CLSID_DogCat;

class DECLSPEC_UUID("71B24C0F-FE53-11D1-9280-006008026FEA")
DogCat;
#endif

#ifdef __cplusplus
EXTERN_C const CLSID CLSID_DogCatCtrl;

class DECLSPEC_UUID("05F56164-0622-11D2-90BA-00104B2168FE")
DogCatCtrl;
#endif
#endif /* __TESTOBJLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
