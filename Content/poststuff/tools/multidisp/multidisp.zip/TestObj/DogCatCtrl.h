// DogCatCtrl.h : Declaration of the CDogCatCtrl

#ifndef __DOGCATCTRL_H_
#define __DOGCATCTRL_H_

#include "resource.h"       // main symbols


/////////////////////////////////////////////////////////////////////////////
// CDogCatCtrl
class ATL_NO_VTABLE CDogCatCtrl :
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CDogCatCtrl,&CLSID_DogCatCtrl>,
	public CComControl<CDogCatCtrl>,
	//public IDogCatCtrl,
	public IDispatchImpl<IDogCatCtrl, &IID_IDogCatCtrl, &LIBID_TESTOBJLib>,
	public IPersistStreamInitImpl<CDogCatCtrl>,
	public IOleControlImpl<CDogCatCtrl>,
	public IOleObjectImpl<CDogCatCtrl>,
	public IOleInPlaceActiveObjectImpl<CDogCatCtrl>,
	public IViewObjectExImpl<CDogCatCtrl>,
	public IOleInPlaceObjectWindowlessImpl<CDogCatCtrl>,
    public IProvideClassInfoImpl<&CLSID_DogCatCtrl, &LIBID_TESTOBJLib>,
	public ICat,
	public IDog
{
public:
	CDogCatCtrl()
	{
 
	}

DECLARE_REGISTRY_RESOURCEID(IDR_DOGCATCTRL)
DECLARE_GET_CONTROLLING_UNKNOWN()

BEGIN_COM_MAP(CDogCatCtrl) 
	COM_INTERFACE_ENTRY(IDogCatCtrl)
	COM_INTERFACE_ENTRY_IMPL_IID(IID_IViewObject, IViewObjectEx)
	COM_INTERFACE_ENTRY_IMPL_IID(IID_IViewObject2, IViewObjectEx)
	COM_INTERFACE_ENTRY_IMPL(IViewObjectEx)
	COM_INTERFACE_ENTRY_IMPL_IID(IID_IOleWindow, IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY_IMPL_IID(IID_IOleInPlaceObject, IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY_IMPL(IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY_IMPL(IOleInPlaceActiveObject)
	COM_INTERFACE_ENTRY_IMPL(IOleControl)
	COM_INTERFACE_ENTRY_IMPL(IOleObject)
	COM_INTERFACE_ENTRY_IMPL(IPersistStreamInit)
	COM_INTERFACE_ENTRY(IDog)
	COM_INTERFACE_ENTRY(ICat)
	COM_INTERFACE_ENTRY(IProvideClassInfo)
	COM_INTERFACE_ENTRY_AUTOAGGREGATE(IID_IDispatch, m_spDispatch.p, CLSID_NestedDispatch)
END_COM_MAP()

BEGIN_PROPERTY_MAP(CDogCatCtrl)
	// Example entries
	// PROP_ENTRY("Property Description", dispid, clsid)
	// PROP_PAGE(CLSID_StockColorPage)
END_PROPERTY_MAP()


BEGIN_MSG_MAP(CDogCatCtrl)
	MESSAGE_HANDLER(WM_PAINT, OnPaint)
	MESSAGE_HANDLER(WM_SETFOCUS, OnSetFocus)
	MESSAGE_HANDLER(WM_KILLFOCUS, OnKillFocus)
END_MSG_MAP()


// IViewObjectEx
	STDMETHOD(GetViewStatus)(DWORD* pdwStatus)
	{
		ATLTRACE(_T("IViewObjectExImpl::GetViewStatus\n"));
		*pdwStatus = VIEWSTATUS_SOLIDBKGND | VIEWSTATUS_OPAQUE;
		return S_OK;
	}

// IDogCatCtrl
public:
	HRESULT OnDraw(ATL_DRAWINFO& di);

	STDMETHOD(get_BarkPurrString)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_BarkPurrString)(/*[in]*/ BSTR newVal);
	STDMETHOD(Bark)();
	STDMETHOD(Purr)();

private:
	CComBSTR            m_bstr;

public:
    CComPtr<IUnknown>   m_spDispatch;
};

#endif //__DOGCATCTRL_H_
