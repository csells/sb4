#pragma once
#ifndef __MULTIDISP_H__
#define __MULTIDISP_H__

// {AA13E680-06D6-11d2-90BA-00104B2168FE}
extern const GUID CLSID_NestedDispatch;

template <const CLSID* pcoclsid, const GUID* plibid,
          WORD wMajor = 1, WORD wMinor = 0, class tihclass = CComTypeInfoHolder>
class ATL_NO_VTABLE IProvideClassInfoImpl : public IProvideClassInfo
{
public:
    STDMETHODIMP GetClassInfo(ITypeInfo** ppti)
    {
        *ppti = 0;
        ITypeLib*   ptlb = 0;
        HRESULT hr = LoadRegTypeLib(*plibid, wMajor, wMinor, 0, &ptlb);
        if( SUCCEEDED(hr) )
        {
            hr = ptlb->GetTypeInfoOfGuid(*pcoclsid, ppti);
            ptlb->Release();
        }
        return hr;
    }
};

#endif  // __MULTIDISP_H__
