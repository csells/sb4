// NestedDispatch.h : Declaration of the CNestedDispatch
//
/////////////////////////////////////////////////////////////////////////////
// [Serge Sandler ssandler@insureware.com] - 12 September 2002 
// Incompatibility with Windows 9x platform is fixed by replacing lstrcmpiW() 
// with _wcsicmp()
// Use "Win32 Release MinDependency" configuration for release, as Unicode configuration
// will not load in Windows 9x (unless Microsoft layer for Unicode is installed).
// Note, statically linked C run-time library adds around 25K to the executable,
// so if size is a concern, undefine _ATL_MIN_CRT and reimplement _wcsicmp() yourself 
// or link to CRT dynamically.
//
// Also, fixed analysis of wFlags in Invoke()
//
/////////////////////////////////////////////////////////////////////////////
// Copyright (c) 1998, Chris Sells and Don Box.
// All rights reserved.
//
// NO WARRANTIES ARE EXTENDED. USE AT YOUR OWN RISK.
//
// To contact the author with suggestions or comments, use
// csells@sellsbrothers.com

#pragma once
#ifndef __NESTEDDISPATCH_H_
#define __NESTEDDISPATCH_H_

#include "resource.h"

#define SIP(itf) CComQIPtr<itf, &IID_##itf>
#define HR(e) { HRESULT _hr = e; if(FAILED(_hr)) return _hr; }

// This DISPID should be safe for a while...
enum { DISPID_INTERFACE = -2047 };

template <typename Lockable>
class LockHolder
{
public:
    LockHolder(Lockable& l) : m_l(l) { m_l.Lock(); }
    LockHolder(Lockable* pl) : m_l(*pl) { m_l.Lock(); }
    ~LockHolder() { m_l.Unlock(); }

private:
    Lockable&   m_l;
};

/////////////////////////////////////////////////////////////////////////////
// CFlyweightDispatch

class ATL_NO_VTABLE CFlyweightDispatch : 
	public CComObjectRootEx<CComMultiThreadModel>,
    public IDispatch
{
public:
BEGIN_COM_MAP(CFlyweightDispatch)
	COM_INTERFACE_ENTRY(IDispatch)
    // Can't be agile until we stop caching interfaces
	//COM_INTERFACE_ENTRY_AGGREGATE(IID_IMarshal, m_pUnkMarshaler.p)
END_COM_MAP()

DECLARE_GET_CONTROLLING_UNKNOWN()
DECLARE_NOT_AGGREGATABLE(CFlyweightDispatch)

    HRESULT Init(IUnknown* pitfControllingOuter, ITypeInfo* pti, REFIID iid, VARIANT* pvarResult)
    {
        LockHolder<CFlyweightDispatch>  lock(this);

        if( m_spitfControllingOuter ) return E_UNEXPECTED;

        HR(pitfControllingOuter->QueryInterface(iid, (void**)&m_spitfControllingOuter));
        m_spti = pti;
        (pvarResult->pdispVal = this)->AddRef();
        pvarResult->vt = VT_DISPATCH;

        return S_OK;
    }

	STDMETHODIMP FinalConstruct()
	{
        ATLTRACE(_T("CFlyweightDispatch::FinalConstruct()\n"));

        // Don't need a lock as object will only be FC'd once
		return CoCreateFreeThreadedMarshaler(GetControllingUnknown(), &m_pUnkMarshaler.p);
	}

	void FinalRelease()
	{
        ATLTRACE(_T("CFlyweightDispatch::FinalRelease()\n"));

        // No need for a lock as object is only FR'd after everyone has abandoned it
		m_pUnkMarshaler.Release();
	}

public:
    // IDispatch
    STDMETHODIMP GetTypeInfoCount(
                UINT * pctinfo)
    {
        return (*pctinfo = 1), S_OK;
    }

    STDMETHODIMP GetTypeInfo(
                UINT iTInfo,
                LCID lcid,
                ITypeInfo ** ppTInfo)
    {
        if( iTInfo != 0 ) return (*ppTInfo = 0), DISP_E_BADINDEX;

        LockHolder<CFlyweightDispatch>  lock(this);
        return (*ppTInfo = m_spti)->AddRef(), S_OK;
    }

    STDMETHODIMP GetIDsOfNames(
                REFIID riid,
                LPOLESTR * rgszNames,
                UINT cNames,
                LCID lcid,
                DISPID * rgDispId)
    {
        if( riid != GUID_NULL ) return E_INVALIDARG;
        if( cNames == 1 && _wcsicmp(OLESTR("Interface"), rgszNames[0]) == 0 )
        {
            return (rgDispId[0] = DISPID_INTERFACE), S_OK;
        }

        LockHolder<CFlyweightDispatch>  lock(this);
        return m_spti->GetIDsOfNames(rgszNames, cNames, rgDispId);
    }

    STDMETHODIMP Invoke(
                DISPID dispIdMember,
                REFIID riid,
                LCID lcid,
                WORD wFlags,
                DISPPARAMS * pDispParams,
                VARIANT * pVarResult,
                EXCEPINFO * pExcepInfo,
                UINT * puArgErr)
    {
        if( riid != GUID_NULL ) return E_INVALIDARG;

        LockHolder<CFlyweightDispatch>  lock(this);
        if( dispIdMember == DISPID_INTERFACE )
        {
            // Reuse logic of NestedDispatch to Invoke(DISPID_INTERFACE)
            SIP(IDispatch)  spdispOuter = m_spitfControllingOuter;
            if( spdispOuter ) return spdispOuter->Invoke(dispIdMember, riid, lcid, wFlags, pDispParams, pVarResult, pExcepInfo, puArgErr);

            return E_NOINTERFACE;
        }

        return m_spti->Invoke(m_spitfControllingOuter.p, dispIdMember, wFlags, pDispParams, pVarResult, pExcepInfo, puArgErr);
    }

private:
    CComPtr<IUnknown>   m_spitfControllingOuter;
    SIP(ITypeInfo)      m_spti;
	CComPtr<IUnknown>   m_pUnkMarshaler;
};

/////////////////////////////////////////////////////////////////////////////
// CNestedDispatch

class ATL_NO_VTABLE CNestedDispatch : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CNestedDispatch, &CLSID_NestedDispatch>,
    public IDispatch
{
public:
	STDMETHODIMP FinalConstruct()
	{
        ATLTRACE(_T("CNestedDispatch::FinalConstruct()\n"));

        // No need for a lock as object is only FC'd once
        HR(GetTypeInfoOfClass(&m_sptiClass));
        HR(GetTypeInfoOfDefaultInterface(&m_sptiInterface, &m_iid));
		return CoCreateFreeThreadedMarshaler(GetControllingUnknown(), &m_pUnkMarshaler.p);
	}

	void FinalRelease()
	{
        ATLTRACE(_T("CNestedDispatch::FinalRelease()\n"));

        // No need for a lock as object is only FR'd after everyone has abandoned it
		m_pUnkMarshaler.Release();
	}

//DECLARE_REGISTRY_RESOURCEID(IDR_NESTEDDISPATCH)
DECLARE_REGISTRY(CLSID_NestedDispatch, _T("MultiDisp.NestedDispatch.1"), _T("MultiDisp.NestedDispatch"), IDS_NESTEDDISPATCH, THREADFLAGS_BOTH)
DECLARE_GET_CONTROLLING_UNKNOWN()
DECLARE_ONLY_AGGREGATABLE(CNestedDispatch)

BEGIN_COM_MAP(CNestedDispatch)
	COM_INTERFACE_ENTRY(IDispatch)
    // Can't be agile until we stop caching interfaces
	//COM_INTERFACE_ENTRY_AGGREGATE(IID_IMarshal, m_pUnkMarshaler.p)
END_COM_MAP()

public:
    // IDispatch
    STDMETHODIMP GetTypeInfoCount(
                UINT * pctinfo)
    {
        return (*pctinfo = 1), S_OK;
    }

    STDMETHODIMP GetTypeInfo(
                UINT iTInfo,
                LCID lcid,
                ITypeInfo ** ppTInfo)
    {
        if( iTInfo != 0 ) return (*ppTInfo = 0), DISP_E_BADINDEX;

        LockHolder<CNestedDispatch> lock(this);
        return this->GetTypeInfoOfDefaultInterface(ppTInfo);
    }

    STDMETHODIMP GetIDsOfNames(
                REFIID riid,
                LPOLESTR * rgszNames,
                UINT cNames,
                LCID lcid,
                DISPID * rgDispId)
    {
        if( riid != GUID_NULL ) return E_INVALIDARG;

        // Add an extra read-only property "interface"
        if( cNames == 1 && _wcsicmp(OLESTR("interface"), rgszNames[0]) == 0 )
        {
            return (rgDispId[0] = DISPID_INTERFACE), S_OK;
        }

        // Look up any other property or method
        LockHolder<CNestedDispatch> lock(this);
        return m_sptiInterface->GetIDsOfNames(rgszNames, cNames, rgDispId);
    }

    STDMETHODIMP Invoke(
                DISPID dispIdMember,
                REFIID riid,
                LCID lcid,
                WORD wFlags,
                DISPPARAMS * pDispParams,
                VARIANT * pVarResult,
                EXCEPINFO * pExcepInfo,
                UINT * puArgErr)
    {
        if( riid != GUID_NULL ) return E_INVALIDARG;

        HRESULT                     hr = E_FAIL;
        LockHolder<CNestedDispatch> lock(this);

        // Handle the extra read-only property "interface"
        if( dispIdMember == DISPID_INTERFACE )
        {
			if( (wFlags & DISPATCH_PROPERTYGET) == 0 )	return E_UNEXPECTED;
            if( pDispParams->cArgs != 1 ) return E_UNEXPECTED;

            CComVariant varItfName = pDispParams->rgvarg[0];
            if( varItfName.vt != VT_BSTR && FAILED(hr = varItfName.ChangeType(VT_BSTR)) ) return hr;

            // Translate foo.interface("object") and foo.interface("default")
            // into the top-level interface, i.e. this one.
            if( (_wcsicmp(OLESTR("object"), varItfName.bstrVal) == 0) ||
                (_wcsicmp(OLESTR("default"), varItfName.bstrVal) == 0) )
            {
                pVarResult->vt = VT_DISPATCH;
                (pVarResult->pdispVal = this)->AddRef();
                hr = S_OK;
            }
            // Create a new flyweight for each foo.interface("IXxx").
            // We could cache the instances for efficiency, but that would
            // create a refcount cycle as each flyweight needs a backpointer.
            else
            {
                SIP(ITypeInfo)  spti;
                IID             iid;
                HR(GetTypeInfoOfNamedInterface(varItfName.bstrVal, &spti, &iid));

                CComObject<CFlyweightDispatch>* pobj = 0;
                HR(pobj->CreateInstance(&pobj));
                pobj->AddRef();
                hr = pobj->Init(GetControllingUnknown(), spti, iid, pVarResult);
                pobj->Release();
            }
        }
        // Handle the other properties and methods
        else
        {
            // QI(m_iid) on every Invoke to avoid a refcount
            // cycle (as we are being aggregated).
            CComPtr<IUnknown>   spItf;
            HR(GetControllingUnknown()->QueryInterface(m_iid, (void**)&spItf));
            hr = m_sptiInterface->Invoke(spItf.p, dispIdMember, wFlags, pDispParams, pVarResult, pExcepInfo, puArgErr);
        }

        return hr;
    }

private:
    HRESULT GetTypeInfoOfClass(ITypeInfo** ppti)
    {
        SIP(IProvideClassInfo) sppci = GetControllingUnknown();
        if( sppci ) return sppci->GetClassInfo(ppti);
        return (*ppti = 0), E_NOINTERFACE;
    }

    HRESULT GetTypeInfoOfDefaultInterface(ITypeInfo** ppti, IID* piid = 0)
    {
        *ppti = 0;

        for( int i = 0; true; ++i )
        {
            int flags;
            HR(m_sptiClass->GetImplTypeFlags(i, &flags));
            if( flags & IMPLTYPEFLAG_FDEFAULT )
            {
                HREFTYPE    hreftype;
                HR(m_sptiClass->GetRefTypeOfImplType(i, &hreftype));
                HR(m_sptiClass->GetRefTypeInfo(hreftype, ppti));
                if( piid )
                {
                    TYPEATTR*   pta = 0;
                    HRESULT     hr = (*ppti)->GetTypeAttr(&pta);
                    if( FAILED(hr) )
                    {
                        (*ppti)->Release();
                        *ppti = 0;
                        return hr;
                    }

                    *piid = pta->guid;
                    (*ppti)->ReleaseTypeAttr(pta);
                }

                return S_OK;
            }
        }

        return E_FAIL;
    }

    HRESULT GetTypeInfoOfNamedInterface(LPCOLESTR pwszName, ITypeInfo** ppti, IID *piid = 0)
    {
        *ppti = 0;
        if( !pwszName || !*pwszName ) return E_INVALIDARG;

        for( int i = 0; true; ++i )
        {
            HREFTYPE    hreftype;
            HR(m_sptiClass->GetRefTypeOfImplType(i, &hreftype));

            SIP(ITypeInfo)  sptiTemp;
            HR(m_sptiClass->GetRefTypeInfo(hreftype, &sptiTemp));

            CComBSTR    bstrName;
            HR(sptiTemp->GetDocumentation(MEMBERID_NIL, &bstrName, 0, 0, 0));

            if( _wcsicmp(bstrName, pwszName) == 0 )
            {
                if( piid )
                {
                    TYPEATTR*   pta;
                    HR(sptiTemp->GetTypeAttr(&pta));
                    *piid = pta->guid;
                    sptiTemp->ReleaseTypeAttr(pta);
                }

                (*ppti = sptiTemp)->AddRef();
                return S_OK;
            }
        }

        return E_FAIL;
    }

private:
    IID                 m_iid;
    SIP(ITypeInfo)      m_sptiClass;
    SIP(ITypeInfo)      m_sptiInterface;
	CComPtr<IUnknown>   m_pUnkMarshaler;
};

#endif //__NESTEDDISPATCH_H_
