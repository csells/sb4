// Project: D:\wk\1.0\textbox\textbox.dsp.  DO NOT MODIFY THIS FILE BY HAND.
//
#define BUILDNUM_ENABLED (1)
#define MODIFY_VERSIONINFO (1)
#define FILE_VERSION0 (1)
#define FILE_VERSION1 (2)
#define FILE_VERSION2 (0)
#define BUILD_NUMBER (4)
