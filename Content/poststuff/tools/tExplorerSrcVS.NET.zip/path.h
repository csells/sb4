// path.h: Path class declaration

#pragma once
#ifndef __PATH_H__
#define __PATH_H__

#include <tchar.h>
#include <direct.h>
#include "tstring.h"

class Path
{
public:
    Path();
    Path(LPCTSTR pszPath);
    Path(LPCTSTR pszDrive, LPCTSTR pszDir, LPCTSTR pszFileNameName, LPCTSTR pszExt);

    tstring FullPath(bool bTrailingSlash = true);   // Drive + Dir + FileName + Ext
    tstring Folder(bool bTrailingSlash = true);     // Drive + Dir
    tstring File();                                 // FileName + Ext

    tstring Drive();
    tstring Dir(bool bTrailingSlash = true);
    tstring FileName();
    tstring Ext();

    void SetFullPath(LPCTSTR pszPath);
    void SetRelativePath(LPCTSTR pszRelPath, LPCTSTR pszDirRelativeTo = 0);
    void SetDrive(LPCTSTR pszDrive);
    void SetDir(LPCTSTR pszDir);
    void SetFileName(LPCTSTR pszFileNameName);
    void SetExt(LPCTSTR pszExt);

private:
    TCHAR   m_szPath[_MAX_PATH+1];

    static tstring TrimTrailingSlash(tstring s);
};

inline Path::Path()
{
    m_szPath[0] = 0;;
}

inline Path::Path(LPCTSTR pszPath)
{
    SetFullPath(pszPath);
}

inline Path::Path(LPCTSTR pszDrive, LPCTSTR pszDir, LPCTSTR pszFileName, LPCTSTR pszExt)
{
    _tmakepath(m_szPath, pszDrive, pszDir, pszFileName, pszExt);
}

inline tstring Path::FullPath(bool bTrailingSlash)
{
    return (bTrailingSlash ? m_szPath : TrimTrailingSlash(m_szPath));
}

inline tstring Path::Folder(bool bTrailingSlash)
{
    TCHAR   szDrive[_MAX_DRIVE+1];
    TCHAR   szDir[_MAX_DIR+1];
    _tsplitpath(m_szPath, szDrive, szDir, 0, 0);

    TCHAR   szFolder[_MAX_DRIVE+_MAX_DIR+3];
    _tmakepath(szFolder, szDrive, szDir, 0, 0);

    return (bTrailingSlash ? szFolder : TrimTrailingSlash(szFolder));
}

inline tstring Path::File()
{
    TCHAR   szFileName[_MAX_FNAME+1];
    TCHAR   szExt[_MAX_EXT+1];
    _tsplitpath(m_szPath, 0, 0, szFileName, szExt);

    TCHAR   szFile[_MAX_FNAME+_MAX_EXT+3];
    _tmakepath(szFile, 0, 0, szFileName, szExt);
    return szFile;
}

inline tstring Path::Drive()
{
    TCHAR   szDrive[_MAX_DRIVE+1];
    _tsplitpath(m_szPath, szDrive, 0, 0, 0);
    return szDrive;
}

inline tstring Path::Dir(bool bTrailingSlash)
{
    TCHAR   szDir[_MAX_DIR+1];
    _tsplitpath(m_szPath, 0, szDir, 0, 0);

    return (bTrailingSlash ? szDir : TrimTrailingSlash(szDir));
}

inline tstring Path::FileName()
{
    TCHAR   szFileName[_MAX_FNAME+1];
    _tsplitpath(m_szPath, 0, 0, szFileName, 0);
    return szFileName;
}

inline tstring Path::Ext()
{
    TCHAR   szExt[_MAX_EXT+1];
    _tsplitpath(m_szPath, 0, 0, 0, szExt);
    return szExt;
}

inline void Path::SetFullPath(LPCTSTR pszPath)
{
    _tcscpy(m_szPath, pszPath);
}

inline void Path::SetRelativePath(LPCTSTR pszRelPath, LPCTSTR pszDirRelativeTo)
{
    // Check for "x:..." and "\..." first
    if( (pszRelPath[1] == __T(':')) || (pszRelPath[0] == __T('\\')) )
    {
        SetFullPath(pszRelPath);
        return;
    }

    // Get base directory, either the cwd or the directory passed in
    TCHAR   szCurrentDir[_MAX_DRIVE+1+_MAX_DIR+1];
    LPCTSTR pszBaseDir = (pszDirRelativeTo ? pszDirRelativeTo : _tgetcwd(szCurrentDir, sizeof(szCurrentDir)/sizeof(*szCurrentDir)));

    // Build relative path
    TCHAR   szRelPath[MAX_PATH+1];
    _tcscpy(szRelPath, pszBaseDir);
    _tcscat(szRelPath, pszRelPath);

    TCHAR   szFullPath[MAX_PATH+1];
    _fullpath(szFullPath, szRelPath, MAX_PATH);

    SetFullPath(szFullPath);
}

inline void Path::SetDrive(LPCTSTR pszDrive)
{
    TCHAR   szDrive[_MAX_DRIVE+1];
    TCHAR   szDir[_MAX_DIR+1];
    TCHAR   szFileName[_MAX_FNAME+1];
    TCHAR   szExt[_MAX_EXT+1];
    _tsplitpath(m_szPath, szDrive, szDir, szFileName, szExt);
    _tmakepath(m_szPath, pszDrive, szDir, szFileName, szExt);
}

inline void Path::SetDir(LPCTSTR pszDir)
{
    TCHAR   szDrive[_MAX_DRIVE+1];
    TCHAR   szDir[_MAX_DIR+1];
    TCHAR   szFileName[_MAX_FNAME+1];
    TCHAR   szExt[_MAX_EXT+1];
    _tsplitpath(m_szPath, szDrive, szDir, szFileName, szExt);
    _tmakepath(m_szPath, szDrive, pszDir, szFileName, szExt);
}

inline void Path::SetFileName(LPCTSTR pszFileName)
{
    TCHAR   szDrive[_MAX_DRIVE+1];
    TCHAR   szDir[_MAX_DIR+1];
    TCHAR   szFileName[_MAX_FNAME+1];
    TCHAR   szExt[_MAX_EXT+1];
    _tsplitpath(m_szPath, szDrive, szDir, szFileName, szExt);
    _tmakepath(m_szPath, szDrive, szDir, pszFileName, szExt);
}

inline void Path::SetExt(LPCTSTR pszExt)
{
    TCHAR   szDrive[_MAX_DRIVE+1];
    TCHAR   szDir[_MAX_DIR+1];
    TCHAR   szFileName[_MAX_FNAME+1];
    TCHAR   szExt[_MAX_EXT+1];
    _tsplitpath(m_szPath, szDrive, szDir, szFileName, szExt);
    _tmakepath(m_szPath, szDrive, szDir, szFileName, pszExt);
}

inline tstring Path::TrimTrailingSlash(tstring s)
{
    if( !s.empty() && right(s, 1)[0] == '\\' )
    {
        s[s.length()-1] = 0;
    }

    return s;
}

#ifdef TEST
void main()
{
    Path    path("c:\\autoexec.bat");
    cout << "FullPath= " << path.FullPath() << endl
         << "Drive= " << path.Drive() << endl
         << "Dir= " << path.Dir(false) << endl
         << "FileName= " << path.FileName() << endl
         << "Ext= " << path.Ext() << endl
         << "Folder= " << path.Folder(false) << endl
         << "File= " << path.File() << endl
         << endl;

    path.SetDir("\\bar\\quux\\baz");
    cout << "FullPath= " << path.FullPath() << endl
         << "Drive= " << path.Drive() << endl
         << "Dir= " << path.Dir(false) << endl
         << "FileName= " << path.FileName() << endl
         << "Ext= " << path.Ext() << endl
         << "Folder= " << path.Folder(false) << endl
         << "File= " << path.File() << endl
         << endl;

    return 0;
}
#endif  // TEST

#endif  // __PATH_H__
