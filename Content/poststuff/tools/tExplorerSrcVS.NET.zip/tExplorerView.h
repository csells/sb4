// tExplorerView.h : interface of the CTExplorerView class
//
/////////////////////////////////////////////////////////////////////////////

#include "FlagMap.h"

class CTExplorerView : public CTreeView, public CtAppSink
{
protected: // create from serialization only
	CTExplorerView();
	DECLARE_DYNCREATE(CTExplorerView)

// Attributes
public:
	CTExplorerDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTExplorerView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTExplorerView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// App-level telephony events
protected:
    virtual void    OnLineCreate(DWORD nDeviceID);
    virtual void    OnPhoneCreate(DWORD nDeviceID);

// Generated message map functions
protected:
	//{{AFX_MSG(CTExplorerView)
	afx_msg void OnFileRefresh();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	BOOL m_bTapiInRegistry;
	void    AddDialParams(LPLINEDIALPARAMS pldp, HTREEITEM hRoot);
	void    AddLineDevCaps(const CtLineDevCaps& ldc, HTREEITEM hRoot);
    void    AddTerminals(const CtLineDevCaps& ldc, HTREEITEM hRoot);
	void    AddAddresses(DWORD nLineID, DWORD nAddrs, HTREEITEM hRoot);
	void    AddLines(HTREEITEM hRoot);
    void    AddAddressCaps(const CtAddressCaps& ac, HTREEITEM hRoot);
    void    AddCompletionMessages(const CtAddressCaps& ac, HTREEITEM hRoot);
    void    AddLineDevice(const CtLine& line, const char* pszDeviceClass, HTREEITEM hRoot);
    void    AddLineDeviceClasses(DWORD nLineID, const CtLineDevCaps& ldc, HTREEITEM hRoot);

    void    AddProviders(const CtProviderList& lpl, HTREEITEM hRoot);
    void    AddPriorities(HTREEITEM hRoot);
    void    AddLocations(const CtTranslateCaps& tc, HTREEITEM hRoot);
    void    AddCards(const CtTranslateCaps& tc, HTREEITEM hRoot);
    void    AddCountries(const CtCountryList& lcl, HTREEITEM hRoot);

    void    AddPhones(HTREEITEM hRoot);
    void    AddPhoneCaps(const CtPhoneCaps& pc, HTREEITEM hRoot);

    void    AddFlag(DWORD dwFlag, FlagMap aFlags[], LPCSTR szTag, HTREEITEM hRoot);
    void    AddFlags(DWORD dwFlags, FlagMap aFlags[], LPCSTR szTag, HTREEITEM hRoot);
    void    AddScalar(DWORD dwFlag, FlagMap aFlags[], LPCSTR szTag, HTREEITEM hRoot);

    void    GetTapiInfo();
    void    RefreshTapiInfo();

    HTREEITEM   InsertItem(LPCSTR szItem, HTREEITEM hParent = TVI_ROOT);
    HTREEITEM   InsertString(LPCSTR sz, LPCSTR szTag, HTREEITEM hRoot, LPCSTR szParen = 0);
    HTREEITEM   InsertNumber(DWORD n, LPCSTR szTag, HTREEITEM hRoot, LPCSTR szParen = 0);
    HTREEITEM   InsertHexNumber(DWORD n, LPCSTR szTag, HTREEITEM hRoot, LPCSTR szParen = 0);

    DWORD   GetTapiNumber(LPCSTR szSection, LPCSTR szKey, DWORD nDefault = 0);
    LPCSTR  GetTapiString(LPCSTR szSection, LPCSTR szKey, LPCSTR szDefault = "");
};

#ifndef _DEBUG  // debug version in tExplorerView.cpp
inline CTExplorerDoc* CTExplorerView::GetDocument()
   { return (CTExplorerDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////
