// tExplorerDoc.cpp : implementation of the CTExplorerDoc class
//

#include "stdafx.h"
#include "tExplorer.h"

#include "tExplorerDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTExplorerDoc

IMPLEMENT_DYNCREATE(CTExplorerDoc, CDocument)

BEGIN_MESSAGE_MAP(CTExplorerDoc, CDocument)
	//{{AFX_MSG_MAP(CTExplorerDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTExplorerDoc construction/destruction

CTExplorerDoc::CTExplorerDoc()
{
}

CTExplorerDoc::~CTExplorerDoc()
{
}

BOOL CTExplorerDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CTExplorerDoc serialization

void CTExplorerDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
	}
	else
	{
	}
}

/////////////////////////////////////////////////////////////////////////////
// CTExplorerDoc diagnostics

#ifdef _DEBUG
void CTExplorerDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CTExplorerDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTExplorerDoc commands
