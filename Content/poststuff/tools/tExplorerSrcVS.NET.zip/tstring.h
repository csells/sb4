// tstring.h: UNICODE or ANSI std string class

#pragma once
#ifndef __TSTRING_H__
#define __TSTRING_H__

#include <string>

#ifdef UNICODE
//typedef std::wstring tstring;

class tstring : public std::wstring
{
public:
    tstring(const wchar_t* sz = 0) : wstring(sz) {}

    // I like this conversion operator, sue me.
    operator const wchar_t*()
    {
        return this->c_str();
    }
};

#else
//typedef std::string tstring;

class tstring : public std::string
{
public:
    tstring(const char* sz = 0) : string(sz) {}

    // I like this conversion operator, sue me.
    operator const char*()
    {
        return this->c_str();
    }
};

#endif  // UNICODE

// String operations the standard committee forgot

template <typename T>
std::basic_string<T> left(const std::basic_string<T>& s, size_t cch)
{
    return std::basic_string<T>(s.begin(), s.begin()+cch);
}

template <typename T>
std::basic_string<T> right(const std::basic_string<T>& s, size_t cch)
{
    return std::basic_string<T>(s.end() - cch, s.end());
}

template <typename T>
std::basic_string<T> mid(const std::basic_string<T>& s, size_t offset, size_t cch = (size_t)-1)
{
    return std::basic_string<T>(s.begin() + offset, s.begin() + offset + cch);
}

#endif  // __TSTRING_H__
