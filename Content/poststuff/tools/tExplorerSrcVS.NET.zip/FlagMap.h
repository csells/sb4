// FlagMap.h

#ifndef FLAGMAP_H
#define FLAGMAP_H

struct FlagMap
{
    DWORD   dwFlag;
    LPCSTR  szFlag;
};

#endif  // FLAGMAP_H