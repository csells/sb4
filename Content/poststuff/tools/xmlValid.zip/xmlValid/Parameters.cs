using System;
using System.IO;

	/// <summary>
	/// Summary description for Parameters.
	/// </summary>
public class Parameters {
  public readonly			bool		StandardInput	= false;
  public readonly			string		InputFile		= null;
  public readonly			string		SchemaFile		= null;

  public Parameters(bool bStdIn, string strSchemaFile) : this (bStdIn, null, strSchemaFile) {			
  }

  public Parameters(string strInputFile, string strSchemaFile): this(false, strInputFile, strSchemaFile) {
  }

  public Parameters(string strInputFile): this (false, strInputFile, null) {
  }

  public Parameters(bool bStdIn) : this (true, null, null) {
  }

  private Parameters(bool bStdIn, string strInputFile, string strSchemaFile) {
    this.StandardInput	= bStdIn;
    this.SchemaFile		= strSchemaFile;
    this.InputFile		= strInputFile;
  }

  public static Parameters ParseArguments(string[] strArgs) {
    string		strInputFile	= null;
    string		strSchemaFile	= null;
    bool		bStdIn			= false;
    Parameters	p				= null;

    foreach (string s in strArgs) {
      string strCommand = s.TrimStart().Substring(0,2);

      switch (strCommand.ToUpper()) {
          // provide a Schema to validate against
        case "/S":
        case "/s":
          strSchemaFile = s.Substring(3).TrimEnd();
          if (!File.Exists(strSchemaFile)) {
            throw new ParametersParsingException(String.Format("Cannot find the schema file {0}", strSchemaFile));
          }
          break;

          // use the standard input for the source document
        case "/C":
        case "/c":
          bStdIn = true;
          break;

        default:
          strInputFile = s.Trim();
          if (!File.Exists(strInputFile)) {
            throw new ParametersParsingException(String.Format("Cannot find the xml file {0}", strInputFile));
          }
          break;
      }
    }

    if (bStdIn && strInputFile != null) {
      throw new ParametersParsingException("Cannot parse the input file and the standard input at the same time");
    }
    if (bStdIn) {
      p = new Parameters(bStdIn, strSchemaFile);
    }
    else {
      p = new Parameters(strInputFile, strSchemaFile);
    }
			
    return p;
  }
}

public class ParametersParsingException : Exception {
  public ParametersParsingException(string Message, Exception InnerException): base(Message, InnerException) {
  }

  public ParametersParsingException(string Message): base(Message) {
  }

  public ParametersParsingException() : base() {
  }
}
