// xmlValidator.cs
#region Copyright
// Copyright (c) 2001-2004, Sells Brothers, Inc.
// All rights reserved. No warranties extended. Use at your own risk.
// You may use this code in your own projects without royalty.
// You may not redistribute this code in source form.
// The official home of this utility is http://www.sellsbrothers.com
#endregion
#region Usage
// Usage: xmlValid.exe [xmlFile] [/s:xsdFile] [/c]
// This utility will check an xml file for well-formedness and, optionally,
// will validate it against a supplied XML schema file (xsd). I built it to
// check that my site's HTML files were well-formed (and therefore XHTML),
// but it's got all kinds of other uses, including checking .NET .config
// files.
#endregion
#region History
// 1/3/2004 - Tony Malandain added support for pulling the XML to validatate from stdin
// 8/8/2001 - Initial release
#endregion

using System;
using System.Xml;
using System.Xml.Schema;

// NOTE: This class needs refactoring
class XmlValidator {
  static int Main(string[] args) {
    if( args.Length < 1 || args[0] == "/?" ) {
      Usage();
      return 0;
    }

    Parameters p = null;
    try {
      p = Parameters.ParseArguments(args);
      if( p == null ) {
        throw new Exception("Unexpected Execption while parsing the command line");
      }

      XmlTextReader tr = GetXmlTextReader(p);
      string inputName = (p.InputFile != null ? p.InputFile : "standard input");

      // Check well-formedness
      if( p.SchemaFile == null ) {
        try {
          // Need to read the data to validate
          while( tr.Read() ) ;
        }
        catch( Exception ex ) {
          DumpException(ex, "Well-formedness exception");
          return -1;
        }

        Console.WriteLine("{0} is XML well-formed", inputName);
      }
        // Check schema validness
      else {
        try {
          XmlValidator validator = new XmlValidator();
          XmlValidatingReader vr = new XmlValidatingReader(tr);
          vr.ValidationType = ValidationType.Schema;
          vr.ValidationEventHandler += new ValidationEventHandler(validator.ValidationCallBack);
          vr.Schemas.Add(null, p.SchemaFile);

          // Need to read the data to validate
          while( vr.Read() ) ;

          if( !validator.Valid ) return -1;

          Console.WriteLine("{0} is XML well-formed and schema valid", inputName);
        }
        catch( Exception ex ) {
          DumpException(ex, "Schema well-formedness exception");
          return -1;
        }
      }
    }
    catch( Exception ex ) {
      DumpException(ex);
      return -1;
    }

    return 0;
  }

  internal static XmlTextReader GetXmlTextReader(Parameters p) {
    if( p == null ) return null;
    if( p.StandardInput ) {
      return new XmlTextReader(Console.In);
    }
    else {
      return new XmlTextReader(p.InputFile);
    }
  }

  private bool _valid = true;

  public bool Valid {
    get { return _valid; }
  }

  static void Usage() {
    Usage(null);
  }

  static bool Empty(string s) { return s == null || s.Length == 0; }

  static void Usage(string err) {
    if( !Empty(err) ) Console.Error.WriteLine("Error: " + err);
    Console.WriteLine("Usage: xmlValid.exe [xmlFile] [/s:xsdFile] [/c]");
    Console.WriteLine("xmlFile: The xml File to validate");
    Console.WriteLine("/?:      Show usage");
    Console.WriteLine("/s:      A Schema file to valid the Xml against");
    Console.WriteLine("/c:      Receive the xml document to process from the standard input");
    Console.WriteLine("         The xmlFile argument is not required in that case");
  }

  void ValidationCallBack(object sender, ValidationEventArgs args) {
    Console.Write("Validation " + args.Severity + ": " + args.Message + "\n");
    _valid = false;
  }

  static void DumpException(Exception ex) {
    DumpException(ex, null);
  }

  static void DumpException(Exception ex, string err) {
    if( Empty(err) ) err = "Error";
    Console.Error.WriteLine("{0} from '{1}': {2}", err, ex.Source, ex.Message);
  }

}
