/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Mon Sep 25 15:39:34 2000
 */
/* Compiler settings for D:\wk\MetaCode\test\DispExTest\MyExpando\MyExpando.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IMyExpandoObject = {0xD6150C48,0x4FFC,0x4322,{0xAA,0x0B,0x30,0x7E,0xA3,0x9B,0x73,0xC5}};


const IID LIBID_MYEXPANDOLib = {0x42AEFFC9,0xC3EF,0x4213,{0x8D,0x5B,0x31,0xCD,0x67,0xA5,0xD7,0x33}};


const CLSID CLSID_MyExpandoObject = {0x8842CC84,0x9F90,0x4CED,{0xB0,0xE4,0x65,0xFF,0xD1,0x4E,0x31,0x39}};


#ifdef __cplusplus
}
#endif

