// MyExpandoObject.cpp : Implementation of CMyExpandoObject

#include "stdafx.h"
#include "MyExpando.h"
#include "MyExpandoObject.h"

/////////////////////////////////////////////////////////////////////////////
// CMyExpandoObject

CMyExpandoObject::CMyExpandoObject()
{
    // Turn Expando case sensitive in case we have variables like root and Root
    // and we've got a case-sensitive language like Java.
    m_fdexDefault = fdexNameCaseSensitive;
}

/////////////////////////////////////////////////////////////////////////////
// IMyExpandoObject

STDMETHODIMP CMyExpandoObject::put_AutoExpando(VARIANT_BOOL newVal)
{
    m_bAutoExpando = (newVal == VARIANT_TRUE);
    return S_OK;
}

STDMETHODIMP CMyExpandoObject::get_AutoExpando(VARIANT_BOOL* pVal)
{
    if( !pVal ) return E_POINTER;
    *pVal = (m_bAutoExpando ? VARIANT_TRUE : VARIANT_FALSE);
    return S_OK;
}
