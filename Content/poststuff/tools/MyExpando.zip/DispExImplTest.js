// DispExImplTest.js

var exp = new ActiveXObject("MyExpando.MyExpandoObject");
exp.foo = "foo";
exp.bar = "bar";

var s = "";

for( var i in exp )
{
    s += "exp['" + i + "']= " + exp[i] + "\r\n";
}

WScript.Echo(s);

exp.AutoExpando = false;
try
{
    exp.quux = "quux";
    WScript.Echo("Turning off AutoExpando failed");
}
catch(e)
{
    WScript.Echo("Turning off AutoExpando succeeded");
}

