// MyExpandoObject.h : Declaration of the CMyExpandoObject

#ifndef __MYEXPANDOOBJECT_H_
#define __MYEXPANDOOBJECT_H_

#include "resource.h"       // main symbols
#include "dispeximpl.h"

/////////////////////////////////////////////////////////////////////////////
// CMyExpandoObject
class ATL_NO_VTABLE CMyExpandoObject : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CMyExpandoObject, &CLSID_MyExpandoObject>,
    public IDispatchExImpl<IMyExpandoObject>
{
public:
	CMyExpandoObject();

DECLARE_REGISTRY_RESOURCEID(IDR_MYEXPANDOOBJECT)
DECLARE_NOT_AGGREGATABLE(CMyExpandoObject)
DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CMyExpandoObject)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IDispatchEx)
	COM_INTERFACE_ENTRY(IMyExpandoObject)
END_COM_MAP()

// IMyExpandoObject
public:
    STDMETHODIMP put_AutoExpando(VARIANT_BOOL newVal);
    STDMETHODIMP get_AutoExpando(VARIANT_BOOL* pVal);
};

#endif //__MYEXPANDOOBJECT_H_
