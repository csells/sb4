// AttilaMsgPump.h
/////////////////////////////////////////////////////////////////////////////
// This is part of the Attila library.
// Copyright (c) 1999, Attila contributors (see ReadMe.htm).
// All rights reserved. No warranties extended.
/////////////////////////////////////////////////////////////////////////////

#ifndef INC_ATTILAMSGPUMP
#define INC_ATTILAMSGPUMP

#include <AttilaTranslate.h>

namespace Attila
{

// ----------------------------------------------------------------------------
// FUNCTION:  AttilaPumpMessagesWithCmdUI
//		void AttilaPumpMessagesWithCmdUI(MSG* pMsgLast);
//
// REMARKS:
//		This method provides a "main" message loop that performs IDLE-time
//		command UI processing
//
// PARAMETERS:
//		pMainWnd	- the main window the the app
//		pLastMsg	- if you want to know the contents of the final message
//					  sent to the app, provide a pointer to a MSG structure
//					  here.

// RETURN VALUE: none
// -----------------------------------------------------------------------------

inline void AttilaPumpMessagesWithCmdUI(CWindow* pMainWnd, MSG* pLastMsg=NULL)
{
	// JMO: Use the UI message pump which performs idle-time updates

	ATLASSERT(NULL != pMainWnd);
    MSG msg;
	bool bIdle				= true;
	LONG lIdleCount			= 0;
    POINT ptCursorLast = { 2147483647L, 2147483647L };
	UINT nMsgLast			= 0;
	bool bContinue			= true;

	// Go until we can't go no mo'

	while ( bContinue )
	{
		// Is it idle time?

		while ( bIdle && !::PeekMessage(&msg, NULL, NULL, NULL, PM_NOREMOVE) )
		{
			// Call OnIdle while in bIdle state

			if ( lIdleCount <= 0 )
			{
				// Send WM_IDLECMDUI to the main window and all of its descendants

				if ( pMainWnd->IsWindow() && pMainWnd->IsWindowVisible() )
				{
					pMainWnd->SendMessage(WM_IDLECMDUI, 0, 0);
					pMainWnd->SendMessageToDescendants(WM_IDLECMDUI, (WPARAM)TRUE, 0, TRUE);
				}

				// TODO -- MFC also sends an idle message to all frame windows in the
				// app.  Unfortunately, we don't track this the way that MFC does.
				// Not sure what to do about it.
			}
			if ( lIdleCount >= 0 )
			{
				bIdle = false; // assume "no idle" state
			}
		}

		// Pump messages while available

		do
		{
			// Pump message, but quit on WM_QUIT

			bContinue	= FALSE != GetMessage(&msg, 0, 0, 0);

			// Run through the translators first!

			if ( !CMsgTranslator::RunThroughTranslators(msg) )
			{
				::TranslateMessage(&msg);
				::DispatchMessage(&msg);
			}				

			if ( !bContinue )
				break;

			// Reset "no idle" state after pumping "normal" message

			// Avoid sending too many idle messages by checking for messages
			// which do not usually affect the state of the user interface
			// and happen very frequenly.

			bool bIsIdle				= false;
			if ( WM_IDLECMDUI == msg.message )
			{
				bIsIdle					= false;
			}
			else if ( WM_MOUSEMOVE == msg.message || WM_NCMOUSEMOVE == msg.message )
			{
				// Same position as last mouse move?

				if ( ptCursorLast.x == msg.pt.x &&
					 ptCursorLast.y == msg.pt.y &&
					 msg.message == nMsgLast )
				{
					bIsIdle				= false;
				}
				else
				{
					ptCursorLast.x		= msg.pt.y;		 // remember for next time
					ptCursorLast.y		= msg.pt.y;
					nMsgLast			= msg.message;
					bIsIdle				= true;
				}
			}
			else
			{
				// WM_PAINT and WM_SYSTIMER (caret blink)

				bIsIdle = WM_PAINT != msg.message && 0x0118 != msg.message;
			}
			if ( bIsIdle )
			{
				bIdle = true;
				lIdleCount = 0;
			}

		} while ( ::PeekMessage(&msg, NULL, NULL, NULL, PM_NOREMOVE) );
	}
	if ( NULL != pLastMsg )
		*pLastMsg	= msg;
}



// -----------------------------------------------------------------------------
// CLASS: CMsgPumpUI -- a message pumper for user-interface threads.
// REMARKS:
//		For COMMAND_UI processing, we really need something like MFC's
//		CWinThread::OnIdle.  I thought of how CWinThread performs idle time
//		processing and considered numerous ways of replacing it.  However it
//		is very simple and it works so for now I have simply lifted it.  This
//		is a shameless near copy of stuff in CWinThread
//
//		We might want to have a base class ('CMsgPump') for all threads, but
//		I was trying to keep this lightweight for now.
// -----------------------------------------------------------------------------

class CMsgPumpUI
{
public:
								CMsgPumpUI(HWND hWnd);
	virtual						~CMsgPumpUI();

	virtual		void			Run(MSG* pMsgLast=NULL);
	virtual		bool			OnIdle(long lCount);
	virtual		bool			IsIdleMessage(const MSG* pMsg);
	virtual		bool			Pump(MSG* pMsgLast=NULL);
				MSG				m_msgCur;


protected:
				HWND			m_hwndMain;
				POINT			m_ptCursorLast;
				UINT			m_nMsgLast;
};

inline CMsgPumpUI::~CMsgPumpUI()
{
}
inline CMsgPumpUI::CMsgPumpUI(HWND hWnd) : m_hwndMain(hWnd)
{
}
// -----------------------------------------------------------------------------
// FUNCTION: CMsgPumpUI::Pump
// REMARKS:
//		This function sends the given message through the message processing
//		pipeline.  In other words, first we try the message translators.  If
//		they allow us to continue, then we Translate and Dispatch normally.
//
// PARAMETERS:
//		pMsgLast	- points to a MSG structure.  If this is non-NULL, the
//					  contents of the last message will be copied to this
//					  structure.
//
// RETURN VALUE:
//		true if the message pump should continue, false otherwise
// -----------------------------------------------------------------------------
inline bool CMsgPumpUI::Pump(MSG* pMsgLast/*=NULL*/)
{
	// Main message loop.

	bool bContinue = FALSE != GetMessage(&m_msgCur, 0, 0, 0);

	// Run through the translators first!

	if ( !CMsgTranslator::RunThroughTranslators(m_msgCur) )
	{
		::TranslateMessage(&m_msgCur);
		::DispatchMessage(&m_msgCur);
	}				

	// If they want to know what's in the last message, tell them.

	if ( !bContinue && NULL != pMsgLast )
		::CopyMemory(pMsgLast, &m_msgCur, sizeof(MSG));

	return bContinue;
}


// -----------------------------------------------------------------------------
// FUNCTION: CMsgPumpUI::OnIdle
// REMARKS:
//		When the count goes below zero, we kick off idle UI updates and the idle
//		time cycle ends.
//
// PARAMETERS:
//		lCount - the idle count.
//
// RETURN VALUE:
//		true if idle processing should continue, false otherwise
// -----------------------------------------------------------------------------
inline bool CMsgPumpUI::OnIdle(long lCount)
{
	if ( lCount <= 0 )
	{
		CWindow wnd(m_hwndMain);

		// Send WM_IDLECMDUI to the main window and all of its descendants

		if ( wnd.IsWindow() && wnd.IsWindowVisible() )
		{
			wnd.SendMessage(WM_IDLECMDUI, 0, 0);
			wnd.SendMessageToDescendants(WM_IDLECMDUI, (WPARAM)TRUE, 0, TRUE);
		}

		// TODO -- MFC also sends an idle message to all frame windows in the
		// app.  Unfortunately, we don't track this the way that MFC does.
		// Not sure what to do about it.
	}
	return lCount < 0;  // nothing more to do if lCount >= 0
}



// -----------------------------------------------------------------------------
// FUNCTION: CMsgPumpUI::Run
// REMARKS:
//		
// PARAMETERS:
// RETURN VALUE:
// -----------------------------------------------------------------------------
inline void CMsgPumpUI::Run(MSG* pMsgLast/*=NULL*/)
{
	bool bIdle			= true;
	LONG lIdleCount		= 0;
	MSG msg;

	// Go until we can't go no mo'

	while ( true )
	{
		// Is it idle time?

		while ( bIdle && !::PeekMessage(&msg, NULL, NULL, NULL, PM_NOREMOVE) )
		{
			// Call OnIdle while in bIdle state

			if ( !OnIdle(lIdleCount++) )
			{
				bIdle = false; // assume "no idle" state
			}
		}

		// Pump messages while available

		do
		{
			// Pump message, but quit on WM_QUIT

			if ( !Pump(pMsgLast) )
				return;

			// Reset "no idle" state after pumping "normal" message

			if ( IsIdleMessage(&m_msgCur) )
			{
				bIdle = true;
				lIdleCount = 0;
			}

		} while ( ::PeekMessage(&msg, NULL, NULL, NULL, PM_NOREMOVE) );
	}

	ATLASSERT(false);  // not reachable
}


// -----------------------------------------------------------------------------
// FUNCTION: CMsgPumpUI::IsIdleMessage
// REMARKS:
//		Have I mentioned yet that we're stealing from MFC?  Well here's the
//		worst theft of all.  This is how MFC avoids a lot of unnecessary idle
//		processing.
//
// PARAMETERS:
//		pMsg	- the MSG structure of the message currently being processed.
//
// RETURN VALUE:
//		true if the message is an idle message.
// -----------------------------------------------------------------------------
inline bool CMsgPumpUI::IsIdleMessage(const MSG* pMsg)
{
	// Return FALSE if the message just dispatched should _not_
	// cause OnIdle to be run.  Messages which do not usually
	// affect the state of the user interface and happen very
	// often are checked for.

	// Avoid redundant WM_MOUSEMOVE and WM_NCMOUSEMOVE
	bool bIsIdle				= false;
	if ( WM_IDLECMDUI == pMsg->message )
	{
		bIsIdle					= false;
	}
	else if ( WM_MOUSEMOVE == pMsg->message || WM_NCMOUSEMOVE == pMsg->message )
	{
		// Same position as last mouse move?

		if ( m_ptCursorLast.x == pMsg->pt.x &&
			 m_ptCursorLast.y == pMsg->pt.y &&
			 pMsg->message == m_nMsgLast )
		{
			bIsIdle				= false;
		}
		else
		{
			m_ptCursorLast.x	= pMsg->pt.y;		 // remember for next time
			m_ptCursorLast.y	= pMsg->pt.y;
			m_nMsgLast			= pMsg->message;
			bIsIdle				= true;
		}
	}
	else
	{
		// WM_PAINT and WM_SYSTIMER (caret blink)

		bIsIdle = WM_PAINT != pMsg->message && 0x0118 != pMsg->message;
	}
	return bIsIdle;
}


}; // (namespace Attila)

#ifndef _ATTILA_NOUSE_NAMESPACE
using namespace Attila;
#endif


#endif
