// AttilaDlgData.h
/////////////////////////////////////////////////////////////////////////////
// This is part of the Attila library.
// Copyright (c) 1999, Attila contributors (see license.txt).
// All rights reserved. No warranties extended.
/////////////////////////////////////////////////////////////////////////////
// SIGNIFICANT LIMITATIONS:
//   Floating point support is disabled when _ATL_MIN_CRT is defined
//   STL support requires you to #define _ATTILA_USES_STL
//   The common control headers are included if necessary
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
//
//  Here's quick and dirty docs for what's done. If it ain't doc'd here, it
//  ain't done yet. MFC users should notice a lot of overlap from the
//  way MFC DDX/DDV worked, although this being the land of ATL, everything
//  is self-implementing: no wizards, no DDV after DDX dependency, no
//  exceptions, and more flexibility.
//
//  BEGIN_DDX_MAP(classname)
//    Starts the DDX map. Implements UpdateData() and opens up the
//    implementation of OnDataExchange() for the rest of the macros.
//    classname = the name the class that's being defined.
//
//  DDX_CONTROL(id,var)
//    Attaches the variable "var" to the control# "id". The variable should
//    be derived from CWindow rather than CWindowImpl, since it is attached
//    but never detached. Using a variable that's derived from CWindowImpl
//    will, at best, cause assertions.
//
//  DDX_INTEGER(id,var,signed)
//    Exchanges data with control# "id", to the variable "var". "signed"
//    should be "true" for signed variables, "false" for unsigned. Works
//    with any variable that is the size of int (eg, in Win32, it works
//    for int, unsigned int, long, unsigned long). DDX_INTEGER can read
//    decimal integers and hexadecimal (if prefixed with "0x").
//
//  DDX_INTEGER_FORMAT(id,var,signed,format)
//    Identical to DDX_INTEGER, except that "format" is used when placing
//    the data into the control. "format" is a printf-style format string.
//
//  DDX_INTEGER_RANGE(id,var,signed,min,max)
//    Identical to DDX_INTEGER, except that the read value must be between
//    min and max.
//
//  DDX_INTEGER_FORMAT_RANGE(id,var,signed,format,min,max)
//    Identical to DDX_INTEGER_FORMAT, except that the read value must be
//    between min and max.
//
//  DDX_FLOAT(id,var)
//    Exchanges data with control# "id", to the variable "var". Works
//    only for variables of type "double".
//
//  DDX_FLOAT_FORMAT(id,var,format)
//    Identical to DDX_FLOAT, except that "format" is used when placing
//    the data into the control. "format" is a printf-style format string.
//
//  DDX_FLOAT_RANGE(id,var,min,max)
//    Identical to DDX_FLOAT, except that the read value must be between
//    min and max.
//
//  DDX_FLOAT_FORMAT_RANGE(id,var,format,min,max)
//    Identical to DDX_FLOAT_FORMAT, except that the read value must be
//    between min and max.
//
//  DDX_STRING_LENGTH(id,var,len)
//    Exchanges data with control# "id", to the variable "var", which
//    is a character array. The length of the string is limited to
//    "len" characters; thus, "var" must be at least (len+1) characters
//    long, to hold the string and the terminating NULL character.
//
//  DDX_STL_STRING(id,var)
//    Exchanges data with control# "id", to the variable "var", which
//    is an STL string or wstring (it must match your current use of
//    the _UNICODE define).
//
//  DDX_STL_STRING_LENGTH(id,var,len)
//    Identical to DDX_STL_STRING, except that the length of the string
//    is limited to "len" characters.
//
//  DDX_CHECK(id,var)
//    Exchanges data with control# "id", to the variable "var". The
//    value is 0 for unchecked, 1 for checked, and 2 for indeterminate.
//
//  DDX_RADIO(id,var)
//    Exchanges data with the radio button group that starts with control#
//    "id", and ends when the next control with the "group" style is found.
//    The value is 0 for the first radio button, 1 for the second, etc. If
//    no radio button in the group is checked, then the value is -1.
//
//  DDX_SCROLL(id,var)
//    Exchanges data with the control# "id", to the variable "var". The
//    value is the position of the scrollbar. This can only be used for
//    a scrollbar control; it cannot be used for the attached vertical
//    and horizontal scrollbars on the dialog.
//
//  DDX_SCROLL_RANGE(id,var,min,max)
//    Identical to DDX_SCROLL, except that the range of the scroll is
//    set to [min,max] during initialization; thus, the value is limited
//    to [min,max] as well.
//
//  DDX_SLIDER(id,var)
//    Exchanges data with the control# "id", to the variable "var". The
//    value is the position of the slider.
//
//  DDX_SLIDER_RANGE(id,var,min,max)
//    Identical to DDX_SLIDER, except that the range of the slide is set
//    to [min,max] during initialization; thus, the value is limited to
//    [min,max] as well.
//
//  CHAIN_DDX_MAP(baseclass)
//    Chains to the DDX map in a base class.
//
//  CHAIN_DDX_MAP_MEMBER(member)
//    Chains to the DDX map attached to a member variable (which,
//    of course, must be derived somehow from CWindow, and must also
//    contain DDX map macros). Can be useful for multiply nested child
//    windows, such as a property sheet scenario.
//
//  CHAIN_DDX_MAP_FUNCTION(func)
//    Chains to an arbitrary function. This function must take
//    CAttilaDataExchange* as its only parameter, and return a bool,
//    set to true for success, false failure. If this function returns
//    false the DDX/DDV process halts with a failure. This function is
//    responsible for displaying its own error message dialog.
//
//  END_DDX_MAP()
//    Closes the implementation of OnDataExchange()
//
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
//
//  DDX/DDV that's done:
//
//    0. Control attachment
//    1. Integer (supports int or long only)
//    2. Float (supports double only)
//    3. Text (supports char arrays w/ length, STL w/ no length, STL w/ length)
//    4. Sliders and scroll bars
//    5. Buttons (checkboxes and radio buttons)
//    6. Chains (base class, member variable, and function)
//
//  DDX/DDV implementation left to do (all macros are started):
//
//    0. Listboxes
//    1. Comboboxes
//    2. Currency (in an edit control)
//    3. Date (in an edit control)
//    4. Date (in a date/time control)
//
//  Other things that may be missing or need investigation:
//
//    0. Any type of ActiveX control support (necessary?)
//    1. How easy would it be to strip out the default handling (dialog
//       box), and somehow pass back the error in question?
//    2. It would be nice on the _RANGE family of functions to ensure
//       that the initial value is inside the range.
//
/////////////////////////////////////////////////////////////////////////////

#pragma once

#ifndef INC_ATTILADLGDATA
#define INC_ATTILADLGDATA

//  Header dependencies

#ifdef _ATTILA_USES_STL		//  Bring in <string> if using ATL
#include <string>
#endif

#ifndef TBM_SETRANGEMIN		//  We need the common control header file
#include <CommCtrl.h>
#endif

//  The error text (called by FormatMessage) for range and length errors

#ifndef _ATTILA_DDV_INVALID_DATA
#define _ATTILA_DDV_INVALID_DATA _T("Please enter a valid value for this field.")
#endif

#ifndef _ATTILA_DDV_RANGE_ERROR
#define _ATTILA_DDV_RANGE_ERROR _T("Please enter a value between %1 and %2.")
#endif

#ifndef _ATTILA_DDV_LENGTH_ERROR
#define _ATTILA_DDV_LENGTH_ERROR _T("Please enter no more than %1 characters.")
#endif

//  _countof gives the number of elements in an array

#ifndef _countof
#define _countof(a) (sizeof(a)/sizeof(a[0]))
#endif

//  The printf function that should be used

#ifndef _ATL_MIN_CRT
	#define _Attila_DDX_Printf _stprintf
#else
	#define _Attila_DDX_Printf wsprintf
#endif

/////////////////////////////////////////////////////////////////////////////
//
//  Data exchange class
//
//    The data exchange class is simpler than MFCs, because we're mandating
//    that our DDV pass the control ID rather than relying on order. This
//    is done because Attila code isn't wizard generated (and having macros
//    that are order dependent is pretty lame anyway).
//
/////////////////////////////////////////////////////////////////////////////

class CAttilaDataExchange
{
public:
	bool      m_bSaveAndValidate;
	CWindow * m_pDlgWnd;

public:
	HWND
	PrepareCtrl( int id )
	{
		ATLASSERT( id != 0 );
		ATLASSERT( id != -1 );

		HWND hwndCtrl = m_pDlgWnd->GetDlgItem( id );

		if( hwndCtrl == NULL )
		{
			ATLTRACE( "Error: no data exchange control with ID 0x%04X.\n", id );
			ATLASSERT( false );
		}

		return hwndCtrl;
	}

public:
	CAttilaDataExchange( CWindow * pDlgWnd, bool bSaveAndValidate )
	{
		ATLASSERT( pDlgWnd != NULL );
		m_pDlgWnd = pDlgWnd;
		m_bSaveAndValidate = bSaveAndValidate;
	}
};

/////////////////////////////////////////////////////////////////////////////
//
//  Helpers in a class
//
/////////////////////////////////////////////////////////////////////////////

class _Attila_DDX
{
public:
	//  ScanInteger is a simple, CRT-free integer scan on a string

	static bool
	ScanInteger( LPCTSTR pszText, void * pData, bool bSigned = true )
	{
		ATLASSERT( pszText != NULL );
		ATLASSERT( pData != NULL );

		//  Skip whitespace

		while( *pszText == ' ' || *pszText == '\t' )
			pszText++;

		//  Negative?

		bool bNegative = false;

		if( *pszText == '-' )
		{
			if( !bSigned )
				return false;

			bNegative = true;
			pszText++;
		}

		//  Our storage

		DWORD dwValue = 0;
		LPCTSTR pszBegin = pszText;

		//  Check if this is hexadecimal...

		if( *pszText == '0' && ( *(pszText+1) == 'x' || *(pszText+1) == 'X' ))
		{
			pszText += 2;
			pszBegin += 2;

			//  No such thing as negative hex

			if( bNegative )
				return false;

			//  Keep reading digits

			while( 1 )
			{
				char c = *pszText;

				if( c >= 'a' && c <= 'f' )
					c = c - 'a' + 'A';

				if( !(( c >= '0' && c <= '9' ) || ( c >= 'A' && c <= 'F' )))
					break;

				int digit = c - '0';

				if( digit > 9 )
					digit = c - 'A' + 10;

				DWORD dwOldValue = dwValue;
				dwValue = dwValue * 16 + digit;

				if( dwOldValue > dwValue )    // Overrun
					return false;

				pszText++;
			}
		}

		//  ...else, treat it as standard decimal

		else
		{
			//  Keep reading digits

			while( *pszText >= '0' && *pszText <= '9' )
			{
				DWORD dwOldValue = dwValue;
				dwValue = dwValue * 10 + ( *pszText - '0' );

				if( dwOldValue > dwValue )    // Overrun
					return false;

				pszText++;
			}
		}

		//  Make sure we read _something_, and that there's nothing left

		if( pszText == pszBegin || *pszText != 0 )
			return false;

		//  If we're unsigned, assign and get out
		
		if( !bSigned )
		{
			*( reinterpret_cast<DWORD *>( pData ) ) = dwValue;
			return true;
		}
		
		//  Make sure the sign bit isn't set
		
		if( dwValue & 0x80000000 )
			return false;
		
		//  Perform twos-complement negation
		
		if( bNegative )
			dwValue = ( dwValue ^ 0xFFFFFFFF ) + 1;

		//  All done...

		*( reinterpret_cast<DWORD *>( pData ) ) = dwValue;
		return true;
	}

	//  ScanFloat is a simple float scan on a string

	static bool
	ScanFloat( LPCTSTR pszText, double * pData )
	{
	#ifdef _ATL_MIN_CRT
		ATLTRACE( "_Attila_DDX::ScanFloat() was called without CRT support.\n" );
		ATLASSERT( false );
		return false;
	#else
		ATLASSERT( pszText !=NULL );
		ATLASSERT( pData !=NULL );
		
		//  Skip whitespace
		
		while( *pszText == ' ' || *pszText == '\t' )
			pszText++;
		
		//  Use the CRT to scan the float
		
		LPTSTR pszEndPtr = NULL;
		*pData = _tcstod( pszText, &pszEndPtr );
		
		return ( pszEndPtr != pszText );
	#endif
	}

	//  FailDDV is called when DDV fails, to display the "dreaded dialog"

	static void
	FailDDV( HWND hwndCtrl, LPCTSTR pszMessage, bool bEdit... )
	{
		//  Initialization

		LPTSTR pszMsgBuf = NULL;

		//  Display the message

		va_list list;
		va_start( list, bEdit );

		FormatMessage( FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_STRING,
				pszMessage, 0, 0, (LPTSTR) &pszMsgBuf, 0, &list );

		va_end( list );

		MessageBox( GetParent( hwndCtrl ), pszMsgBuf, NULL, MB_ICONEXCLAMATION );
		LocalFree( pszMsgBuf );

		//  Set the focus

		::SetFocus( hwndCtrl );
		if( bEdit ) ::SendMessage( hwndCtrl, EM_SETSEL, 0, -1 );
	}
};

/////////////////////////////////////////////////////////////////////////////
//
//  Dynamic Data Exchange (DDX) and Dynamic Data Validation (DDV) macros
//
/////////////////////////////////////////////////////////////////////////////

//  Start the map with a definition of "UpdateData()" and "DoDataExchange()"

#define BEGIN_DDX_MAP( wndclass ) \
	public: \
	bool UpdateData( bool bSaveAndValidate = true ) \
	{ \
		ATLASSERT( this != NULL ); \
		ATLASSERT( m_hWnd != NULL ); \
		try \
		{ \
			CAttilaDataExchange ex( this, bSaveAndValidate ); \
			return DoDataExchange( &ex ); \
		} \
		catch(...) \
		{ \
			ATLTRACE( "UpdateData caught an exception; returning false.\n" ); \
			return false; \
		} \
	} \
	virtual bool DoDataExchange( CAttilaDataExchange * pDX ) \
	{

//  Control variable assignment

#define DDX_CONTROL( id, var ) \
		if( var.m_hWnd == NULL ) \
		{ \
			ATLASSERT( !pDX -> m_bSaveAndValidate ); \
			var.Attach( pDX -> PrepareCtrl( id )); \
		}

//  Integral DDX/DDV

#define DDX_INTEGER_FORMAT( id, var, bSigned, szFormat ) \
		ATLASSERT( sizeof( var ) == sizeof( int )); \
		if( pDX -> m_bSaveAndValidate ) \
		{ \
			HWND hwndCtrl = pDX -> PrepareCtrl( id ); \
			TCHAR szTemp[ 32 ]; \
			::GetWindowText( hwndCtrl, szTemp, _countof( szTemp )); \
			if( !_Attila_DDX::ScanInteger( szTemp, &var, bSigned )) \
			{ \
				_Attila_DDX::FailDDV( hwndCtrl, _ATTILA_DDV_INVALID_DATA, true ); \
				return false; \
			} \
		} \
		else \
		{ \
			TCHAR szTemp[ 32 ]; \
			_Attila_DDX_Printf( szTemp, szFormat, var ); \
			SetDlgItemText( id, szTemp ); \
		}

#define DDX_INTEGER_FORMAT_RANGE( id, var, bSigned, szFormat, minval, maxval ) \
		ATLASSERT( minval <= maxval ); \
		DDX_INTEGER_FORMAT( id, var, bSigned, szFormat ) \
		if( pDX -> m_bSaveAndValidate && ( var < minval || var > maxval )) \
		{ \
			TCHAR szMin[ 32 ], szMax[ 32 ]; \
			_Attila_DDX_Printf( szMin, szFormat, minval ); \
			_Attila_DDX_Printf( szMax, szFormat, maxval ); \
			_Attila_DDX::FailDDV( pDX -> PrepareCtrl( id ), _ATTILA_DDV_RANGE_ERROR, true, szMin, szMax ); \
			return false; \
		}

#define DDX_INTEGER( id, var, bSigned ) \
		DDX_INTEGER_FORMAT( id, var, bSigned, bSigned ? "%d" : "%u" )

#define DDX_INTEGER_RANGE( id, var, bSigned, minval, maxval ) \
		DDX_INTEGER_FORMAT_RANGE( id, var, bSigned, bSigned ? "%d" : "%u", minval, maxval )

//  Floating point DDX/DDV

#ifndef _ATL_MIN_CRT

	#define DDX_FLOAT_FORMAT( id, var, szFormat ) \
		ATLASSERT( sizeof( var ) == sizeof( double )); \
		if( pDX -> m_bSaveAndValidate ) \
		{ \
			HWND hwndCtrl = pDX -> PrepareCtrl( id ); \
			TCHAR szTemp[ 32 ]; \
			::GetWindowText( hwndCtrl, szTemp, _countof( szTemp )); \
			if( !_Attila_DDX::ScanFloat( szTemp, &var )) \
			{ \
				_Attila_DDX::FailDDV( hwndCtrl, _ATTILA_DDV_INVALID_DATA, true ); \
				return false; \
			} \
		} \
		else \
		{ \
			TCHAR szTemp[ 32 ]; \
			_Attila_DDX_Printf( szTemp, szFormat, var ); \
			SetDlgItemText( id, szTemp ); \
		}

	#define DDX_FLOAT_FORMAT_RANGE( id, var, szFormat, minval, maxval ) \
		ATLASSERT( minval <= maxval ); \
		DDX_FLOAT_FORMAT( id, var, szFormat ) \
		if( pDX -> m_bSaveAndValidate && ( var < minval || var > maxval )) \
		{ \
			TCHAR szMin[ 32 ], szMax[ 32 ]; \
			_Attila_DDX_Printf( szMin, szFormat, minval ); \
			_Attila_DDX_Printf( szMax, szFormat, maxval ); \
			_Attila_DDX::FailDDV( pDX -> PrepareCtrl( id ), _ATTILA_DDV_RANGE_ERROR, true, szMin, szMax ); \
			return false; \
		}

	#define DDX_FLOAT( id, var ) \
		DDX_FLOAT_FORMAT( id, var, "%f" )

	#define DDX_FLOAT_RANGE( id, var, minval, maxval ) \
		DDX_FLOAT_FORMAT_RANGE( id, var, "%f", minval, maxval )

#else

	#define DDX_FLOAT_FORMAT( id, var, szFormat )                       ATLASSERT( false );
	#define DDX_FLOAT_FORMAT_RANGE( id, var, szForamt, minval, maxval ) ATLASSERT( false );
	#define DDX_FLOAT( id, var )                                        ATLASSERT( false );
	#define DDX_FLOAT_RANGE( id, var, minval, maxval )                  ATLASSERT( false );

#endif	// _ATL_MIN_CRT

//  String DDX/DDV

#define DDX_STRING_LENGTH( id, var, len ) \
		if( pDX -> m_bSaveAndValidate ) \
		{ \
			HWND hwndCtrl = pDX -> PrepareCtrl( id ); \
			int nLength = ::GetWindowTextLength( hwndCtrl ); \
			if( nLength > len ) \
			{ \
				TCHAR szTemp[ 32 ]; \
				_Attila_DDX_Printf( szTemp, "%d", len ); \
				_Attila_DDX::FailDDV( hwndCtrl, _ATTILA_DDV_LENGTH_ERROR, true, szTemp ); \
				return false; \
			} \
			int nRetrieved = ::GetWindowText( hwndCtrl, var, len + 1 ); \
		} \
		else \
			SetDlgItemText( id, var );

#ifdef _ATTILA_USES_STL

	#define DDX_STL_STRING( id, var ) \
		if( pDX -> m_bSaveAndValidate ) \
		{ \
			HWND hwndCtrl = pDX -> PrepareCtrl( id ); \
			int nLength = ::GetWindowTextLength( hwndCtrl ) + 1; \
			char * pString = new char[ nLength ]; \
			::GetWindowText( hwndCtrl, pString, nLength ); \
			var = pString; \
			delete[] pString; \
		} \
		else \
			SetDlgItemText( id, var.c_str());

	#define DDX_STL_STRING_LENGTH( id, var, len ) \
		ATLASSERT( len > 0 ); \
		if( pDX -> m_bSaveAndValidate ) \
		{ \
			HWND hwndCtrl = pDX -> PrepareCtrl( id ); \
			if( ::GetWindowTextLength( hwndCtrl ) > len ) \
			{ \
				TCHAR szTemp[ 32 ]; \
				_Attila_DDX_Printf( szTemp, "%d", len ); \
				_Attila_DDX::FailDDV( hwndCtrl, _ATTILA_DDV_LENGTH_ERROR, true, szTemp ); \
				return false; \
			} \
		} \
		DDX_STL_STRING( id, var )

#else

	#define DDX_STL_STRING( id, var )             ATLASSERT( false );
	#define DDX_STL_STRING_LENGTH( id, var, len ) ATLASSERT( false );

#endif	// _ATTILA_USES_STL

//  Date DDX/DDV

#define DDX_DATE( id, var )

#define DDX_DATE_RANGE( id, var, minval, maxval )

//  Currency DDX/DDV

#define DDX_CURRENCY( id, var )

#define DDX_CURRENCY_RANGE( id, var, minval, maxval )

//  Button DDX/DDV

#define DDX_CHECK( id, var ) \
		if( pDX -> m_bSaveAndValidate ) \
		{ \
			var = IsDlgButtonChecked( id ); \
			ATLASSERT( var >= 0 && var <= 2 ); \
		} \
		else \
		{ \
			if( var < 0 || var > 2 ) \
			{ \
				ATLTRACE( "Warning: dialog data checkbox var (%d) for ID 0x%04X is out of range.\n", var, id ); \
				var = 0; \
			} \
			CheckDlgButton( id, var ); \
		}

#define DDX_RADIO( id, var ) \
		{ \
			HWND hwndCtrl = pDX -> PrepareCtrl( id ); \
			ATLASSERT( ::GetWindowLong( hwndCtrl, GWL_STYLE ) & WS_GROUP ); \
			ATLASSERT( ::SendMessage( hwndCtrl, WM_GETDLGCODE, 0, 0 ) & DLGC_RADIOBUTTON ); \
			if( pDX -> m_bSaveAndValidate ) var = -1; \
			int nCurrent = 0; \
			do \
			{ \
				if( ::SendMessage( hwndCtrl, WM_GETDLGCODE, 0, 0 ) & DLGC_RADIOBUTTON ) \
				{ \
					if( pDX -> m_bSaveAndValidate ) \
					{ \
						if( ::SendMessage( hwndCtrl, BM_GETCHECK, 0, 0 ) != 0 ) \
						{ \
							ATLASSERT( var == -1 ); \
							var = nCurrent; \
						} \
					} \
					else \
						::SendMessage( hwndCtrl, BM_SETCHECK, ( nCurrent == var ), 0 ); \
				} \
				else \
					ATLTRACE( "Warning: skipping non-radio button in group (starting with ID 0x%04X).\n", id ); \
				hwndCtrl = ::GetWindow( hwndCtrl, GW_HWNDNEXT ); \
				nCurrent++; \
			} \
			while( hwndCtrl != NULL && !( ::GetWindowLong( hwndCtrl, GWL_STYLE ) & WS_GROUP )); \
		}

//  Listbox DDX/DDV

#define DDX_LBINDEX( id, var )

#define DDX_LBSTRING_LENGTH( id, var, len )

#define DDX_LBSTRING_EXACT_LENGTH( id, var, len )

#ifdef _ATTILA_USES_STL

	#define DDX_STL_LBSTRING( id, var )

	#define DDX_STL_LBSTRING_LENGTH( id, var, len )

	#define DDX_STL_LBSTRING_EXACT( id, var )

	#define DDX_STL_LBSTRING_EXACT_LENGTH( id, var, len )

#else

	#define DDX_STL_LBSTRING( id, var )                   ATLASSERT( false );
	#define DDX_STL_LBSTRING_LENGTH( id, var, len )       ATLASSERT( false );
	#define DDX_STL_LBSTRING_EXACT( id, var )             ATLASSERT( false );
	#define DDX_STL_LBSTRING_EXACT_LENGTH( id, var, len ) ATLASSERT( false );

#endif

//  Listbox DDX/DDV

#define DDX_CBINDEX( id, var )

#define DDX_CBSTRING_LENGTH( id, var, len )

#define DDX_CBSTRING_EXACT_LENGTH( id, var, len )

#ifdef _ATTILA_USES_STL

	#define DDX_STL_CBSTRING( id, var )

	#define DDX_STL_CBSTRING_LENGTH( id, var, len )

	#define DDX_STL_CBSTRING_EXACT( id, var )

	#define DDX_STL_CBSTRING_EXACT_LENGTH( id, var, len )

#else

	#define DDX_STL_CBSTRING( id, var )                   ATLASSERT( false );
	#define DDX_STL_CBSTRING_LENGTH( id, var, len )       ATLASSERT( false );
	#define DDX_STL_CBSTRING_EXACT( id, var )             ATLASSERT( false );
	#define DDX_STL_CBSTRING_EXACT_LENGTH( id, var, len ) ATLASSERT( false );

#endif

//  Scrollbar and slider DDX/DDV

#define DDX_SCROLL( id, var ) \
		{ \
			HWND hwndCtrl = pDX -> PrepareCtrl( id ); \
			if( pDX -> m_bSaveAndValidate ) \
				var = ::GetScrollPos( hwndCtrl, SB_CTL ); \
			else \
				::SetScrollPos( hwndCtrl, SB_CTL, var, TRUE ); \
		}

#define DDX_SCROLL_RANGE( id, var, minval, maxval ) \
		if( !pDX -> m_bSaveAndValidate ) \
		ATLASSERT( minval <= maxval ); \
		{ \
			HWND hwndCtrl = pDX -> PrepareCtrl( id ); \
			::SetScrollRange( hwndCtrl, SB_CTL, minval, maxval, TRUE ); \
		} \
		DDX_SCROLL( id, var )

#define DDX_SLIDER( id, var ) \
		{ \
			HWND hwndCtrl = pDX -> PrepareCtrl( id ); \
			if( pDX -> m_bSaveAndValidate ) \
				var = (int) ::SendMessage( hwndCtrl, TBM_GETPOS, 0, 0 ); \
			else \
				::SendMessage( hwndCtrl, TBM_SETPOS, TRUE, var ); \
		}

#define DDX_SLIDER_RANGE( id, var, minval, maxval ) \
		ATLASSERT( minval <= maxval ); \
		if( !pDX -> m_bSaveAndValidate ) \
		{ \
			if( minval > var || maxval < var ) \
			{ \
				ATLTRACE( "Warning: initial dialog data is out of range in control %d.\n", id ); \
				var = minval; \
			} \
			HWND hwndCtrl = pDX -> PrepareCtrl( id ); \
			::SendMessage( hwndCtrl, TBM_SETRANGEMIN, FALSE, (LPARAM) minval ); \
			::SendMessage( hwndCtrl, TBM_SETRANGEMAX, TRUE,  (LPARAM) maxval ); \
		} \
		DDX_SLIDER( id, var )

//  Date/time control DDX/DDV

#define DDX_DATETIMECTRL( id, var )

#define DDX_DATETIMECTRL_RANGE( id, var, minval, maxval )

//  Chains to other DDX/DDV maps

#define CHAIN_DDX_MAP(otherclass) \
		if( !otherclass::DoDataExchange( pDX )) \
			return false;

#define CHAIN_DDX_MAP_MEMBER(otherobject) \
		if( !otherobject.DoDataExchange( pDX )) \
			return false;

//  Chain to an arbitrary function, which must take CAttilaDataExchange* as
//  its only parameter, and return a "bool": true for success, false for
//  DDX/DDV failure that should stop the DDX/DDV process

#define CHAIN_DDX_MAP_FUNCTION(func) \
		if( !func( pDX )) \
			return false;

//  Clean up

#define END_DDX_MAP() \
		return true; \
	}

#endif	// INC_ATTILADLGDATA
