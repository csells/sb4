// smalldde.h: Just enough DDE wrappers to support sending a shell-like
//             DDE command message
/////////////////////////////////////////////////////////////////////////////
// This is part of the Attila library.
// Copyright (c) 1999, Attila contributors (see ReadMe.htm).
// All rights reserved. No warranties extended.
/////////////////////////////////////////////////////////////////////////////
// History:
//  -11/2/99:
//   Tommy Hui [thui@mediaone.net] fixed a Unicode bug.
/////////////////////////////////////////////////////////////////////////////
// Usage:
/*
HRESULT ExecuteDdeCommand(
    LPCTSTR pszApp,
    LPCTSTR pszTopic,
    LPCTSTR pszCommand)
{
    if( !pszApp || !*pszApp ) return E_INVALIDARG;
    if( !pszTopic || !*pszTopic ) return E_INVALIDARG;
    if( !pszCommand || !*pszCommand ) return E_INVALIDARG;

    CDde    dde;
    DDER(dde.Initialize());

    CDdeConversation    conv;
    DDER(conv.Connect(dde, pszApp, pszTopic));

    CDdeData    data;
    DDER(data.ClientTransaction(dde, conv, pszCommand));

	return DMLERR_NO_ERROR;
}
*/

#pragma once
#ifndef INC_SMALLDDE
#define INC_SMALLDDE

namespace Attila
{

#ifdef TRACEWE
#define TRACEDDE(_err) TRACEWE(_err)
#else
#ifdef _DEBUG
#define TRACEDDE(_err) ATLTRACE(__T("DDE Error: 0x%x\n"), _err), _err
#else
#define TRACEDDE(_err) _err
#endif
#endif

#define DDER(_ex) { long _res = _ex; if( _res != DMLERR_NO_ERROR ) return TRACEDDE(_res), _res; }

class CDde
{
public:
    CDde() : m_id(0) {}

    ~CDde()
    {
        Unitialize();
    }

    long Initialize(PFNCALLBACK pfnCallback = 0, DWORD afCmd = APPCMD_CLIENTONLY)
    {
        Unitialize();

        DDER(DdeInitialize(&m_id, pfnCallback, afCmd, 0));
        return DMLERR_NO_ERROR;
    }

    void Unitialize()
    {
        if( m_id )
        {
            DdeUninitialize(m_id);
            m_id = 0;
        }
    }

    long GetLastError()
    {
        return DdeGetLastError(m_id);
    }

    operator DWORD()
    {
        return m_id;
    }

private:
    DWORD   m_id;
};

class CDdeString
{
public:
    CDdeString() : m_id(0), m_hsz(0) {}

    ~CDdeString()
    {
        Free();
    }

    long Create(DWORD id, LPCTSTR psz, DWORD nCodePage = CP_WINNEUTRAL)
    {
        Free();

        m_id = id;
        m_hsz = DdeCreateStringHandle(m_id, psz, nCodePage);
        if( !m_hsz ) return TRACEDDE(DdeGetLastError(m_id));

        return DMLERR_NO_ERROR;
    }

    void Free()
    {
        if( m_hsz )
        {
            DdeFreeStringHandle(m_id, m_hsz);
            m_id = 0;
            m_hsz = 0;
        }
    }

    operator HSZ()
    {
        return m_hsz;
    }

private:
    DWORD   m_id;
    HSZ     m_hsz;
};

class CDdeConversation
{
public:
    CDdeConversation() : m_hconv(0) {}

    ~CDdeConversation()
    {
        Disconnect();
    }

    long Connect(DWORD id, LPCTSTR pszApp, LPCTSTR pszTopic, CONVCONTEXT* pcc = 0)
    {
        CDdeString hszApp;
        DDER(hszApp.Create(id, pszApp));

        CDdeString hszTopic;
        DDER(hszTopic.Create(id, pszTopic));

        return Connect(id, hszApp, hszTopic, pcc);
    }

    long Connect(DWORD id, HSZ hszApp, HSZ hszTopic, CONVCONTEXT* pcc = 0)
    {
        Disconnect();

	    m_hconv = DdeConnect(id, hszApp, hszTopic, pcc);
        if( !m_hconv ) return TRACEDDE(DdeGetLastError(id));

        return DMLERR_NO_ERROR;
    }

    void Disconnect()
    {
        if( m_hconv )
        {
            DdeDisconnect(m_hconv);
            m_hconv = 0;
        }
    }

    operator HCONV()
    {
        return m_hconv;
    }

private:
    HCONV   m_hconv;
};

class CDdeData
{
public:
    CDdeData() : m_hdata(0) {}
    ~CDdeData()
    {
        Free();
    }

    long ClientTransaction(DWORD id, HCONV hconv, LPCSTR psz)
    {
        Free();

	    m_hdata = DdeClientTransaction((BYTE*)psz, lstrlenA(psz)+1, hconv, 0, CF_TEXT, XTYP_EXECUTE, TIMEOUT_ASYNC, 0);
        if( !m_hdata ) return TRACEDDE(DdeGetLastError(id));

        return DMLERR_NO_ERROR;
    }

    long NameService(DWORD id, HSZ hsz, DWORD afCmd)
    {
        Free();
        
        m_hdata = DdeNameService(id, hsz, 0, afCmd);
        if( !m_hdata ) return TRACEDDE(DdeGetLastError(id));
        
        return DMLERR_NO_ERROR;
    }

    void Free()
    {
        if( m_hdata )
        {
            DdeFreeDataHandle(m_hdata);
            m_hdata = 0;
        }
    }

    operator HDDEDATA()
    {
        return m_hdata;
    }

private:
    HDDEDATA    m_hdata;
};

}   // namespace Attila

#ifndef _ATTILA_NOUSE_NAMESPACE
using namespace Attila;
#endif

#endif  // INC_SMALLDDE
