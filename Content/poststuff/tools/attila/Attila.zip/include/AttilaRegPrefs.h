// AttilaRegPrefs.h
/////////////////////////////////////////////////////////////////////////////
// This is part of the Attila library.
// Copyright (c) 1999, Attila contributors (see ReadMe.htm).
// All rights reserved. No warranties extended.
/////////////////////////////////////////////////////////////////////////////

#pragma once
#ifndef INC_ATTILAREGPREFS
#define INC_ATTILAREGPREFS

namespace Attila
{

class CRegPrefs
{
// Construction
public:
	CRegPrefs();
	CRegPrefs(HKEY hkeyRoot, LPCTSTR pszKeyPath);

	HRESULT Open(HKEY hkeyRoot, LPCTSTR pszKeyPath);
	void Close();

// Operations
public:
	bool IsOpen() const;

	HRESULT Read(LPCTSTR pszName, LPTSTR pszValue, int nValueLength, int * pnValueLength = NULL) const;
	HRESULT Read(LPCTSTR pszName, LONG * pnValue) const;

	HRESULT Write(LPCTSTR pszName, LPCTSTR pszValue) const;
	HRESULT Write(LPCTSTR pszName, LONG nValue) const;

// Implementation
public:
	~CRegPrefs();
private:
	CRegPrefs(const CRegPrefs & prefs);
	CRegPrefs & operator =(const CRegPrefs & prefs);
	
// Implementation Data
private:
	HKEY m_hkey;
	bool m_bAutoDelete;
};


inline CRegPrefs::CRegPrefs()
{
	// init members
	m_hkey = NULL;
	m_bAutoDelete = false;
}


inline CRegPrefs::CRegPrefs(HKEY hkeyRoot, LPCTSTR pszKeyPath)
{
	// init members
	m_hkey = NULL;
	m_bAutoDelete = false;

	// open key
	Open(hkeyRoot, pszKeyPath);
}


inline HRESULT CRegPrefs::Open(HKEY hkeyRoot, LPCTSTR pszKeyPath)
{
	// close previous
	Close();

	// open specified key
	LONG nResult = ::RegCreateKeyEx(hkeyRoot, pszKeyPath, 0, NULL, 
		REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &m_hkey, NULL);
	if (nResult == ERROR_SUCCESS)
		m_bAutoDelete = true;
	return HRESULT_FROM_WIN32(nResult);
}


inline void CRegPrefs::Close()
{
	// close key if necessary
	if (m_hkey != NULL && m_bAutoDelete)
		::RegCloseKey(m_hkey);
	m_hkey = NULL;
	m_bAutoDelete = false;
}


inline bool CRegPrefs::IsOpen() const
{
	// check if open
	return m_hkey != NULL;
}


inline HRESULT CRegPrefs::Read(LPCTSTR pszName, LPTSTR pszValue, int nValueLength, int * pnValueLength) const
{
	// ensure open
	_ASSERTE(m_hkey != NULL);

	// read string from registry
	DWORD dwType = 0;
	DWORD dwDataLength = nValueLength * sizeof(TCHAR);
	LONG nResult = ::RegQueryValueEx(m_hkey, pszName, NULL, &dwType, 
		reinterpret_cast<BYTE *>(pszValue), &dwDataLength);

	// check type
	if (nResult == ERROR_SUCCESS && dwType != REG_SZ && 
		dwType != REG_MULTI_SZ && dwType != REG_EXPAND_SZ)
	{
		// bad type
		return E_FAIL;
	}
	else
	{
		// set actual/needed length if requested
		if (pnValueLength != NULL)
			*pnValueLength = dwDataLength / sizeof(TCHAR);

		// return result
		return HRESULT_FROM_WIN32(nResult);
	}
}


inline HRESULT CRegPrefs::Read(LPCTSTR pszName, LONG * pnValue) const
{
	// ensure open
	_ASSERTE(m_hkey != NULL);
	_ASSERTE(pnValue != NULL);
	_ASSERTE(sizeof(LONG) == sizeof(DWORD));

	// read value from registry
	DWORD dwType = 0;
	DWORD dwDataLength = sizeof(DWORD);
	LONG nResult = ::RegQueryValueEx(m_hkey, pszName, NULL, &dwType, 
		reinterpret_cast<BYTE *>(pnValue), &dwDataLength);

	// check type
	if (nResult == ERROR_SUCCESS && dwType != REG_DWORD)
		return E_FAIL;
	else
		return HRESULT_FROM_WIN32(nResult);
}


inline HRESULT CRegPrefs::Write(LPCTSTR pszName, LPCTSTR pszValue) const
{
	// ensure open
	_ASSERTE(m_hkey != NULL);

	// write string to registry
	DWORD dwDataLength = (lstrlen(pszValue) + 1) * sizeof(TCHAR);
	LONG nResult = ::RegSetValueEx(m_hkey, pszName, 0, REG_SZ,
		reinterpret_cast<const BYTE *>(pszValue), dwDataLength);
	return HRESULT_FROM_WIN32(nResult);
}


inline HRESULT CRegPrefs::Write(LPCTSTR pszName, LONG nValue) const
{
	// ensure open
	_ASSERTE(m_hkey != NULL);
	_ASSERTE(sizeof(LONG) == sizeof(DWORD));

	// write value to registry
	LONG nResult = ::RegSetValueEx(m_hkey, pszName, 0, REG_DWORD, 
		reinterpret_cast<const BYTE *>(&nValue), sizeof(DWORD));
	return HRESULT_FROM_WIN32(nResult);
}


inline CRegPrefs::~CRegPrefs()
{
	// close first
	Close();
}

}   // namespace Attila

#ifndef _ATTILA_NOUSE_NAMESPACE
using namespace Attila;
#endif

#endif  // INC_ATTILAREGPREFS
