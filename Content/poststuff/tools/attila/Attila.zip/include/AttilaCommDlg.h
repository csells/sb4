// AttilaCommDlg.h
/////////////////////////////////////////////////////////////////////////////
// This is part of the Attila library.
// Copyright (c) 1999, Attila contributors (see ReadMe.htm).
// All rights reserved. No warranties extended.
/////////////////////////////////////////////////////////////////////////////

#pragma once
#ifndef INC_ATTILACOMMDLG
#define INC_ATTILACOMMDLG

#include "commdlg.h"
#include "dlgs.h"

namespace Attila
{

/////////////////////////////////////////////////////////////////////////////
// CCommonDialogT - base class for common dialogs

template <typename T>
class CCommonDialogT : public T
{
// Implementation
protected:
	CCommonDialogT(DWORD flags)
	{
		ZeroMemory(this, sizeof(T));
		lStructSize = sizeof(T);
		Flags = flags;
		// The reinterpret_cast is necessary because of CHOOSECOLOR
		reinterpret_cast<HINSTANCE&>(hInstance) = _Module.GetModuleInstance();
	}
	static UINT GetHelpMessage()
	{
		static UINT HelpMessage = ::RegisterWindowMessage(HELPMSGSTRING);
		return HelpMessage;
	}
};

/////////////////////////////////////////////////////////////////////////////
// CHookedCommonDlgT - support for hooking common dialogs without subclassing
//
// Unfortunately, there's no way to change the hook procedure once the
// window has been created.  Solution: point the hook procedure at the
// thunk before the window is created, and use a CBT hook to actually
// initialize m_hwnd.

template <class TBase = CWindow>
class CHookedCommonDlgT : public CWindowImplBaseT<TBase, CNullTraits>
{
// Implementation
protected:
	struct CreateData
	{
		// We can't use m_thunk.cd because the thunk is already in use.
		_AtlCreateWndData  m_cd;
		HHOOK              m_hook;
		CHookedCommonDlgT *m_pThis;
	};
	typedef UINT (CALLBACK *COMMONHOOKPROC)(HWND, UINT, WPARAM, LPARAM);

	COMMONHOOKPROC CreateHook(CreateData & cd)
	{
		_Module.AddCreateWndData(&cd.m_cd, &cd);
        cd.m_hook = SetWindowsHookEx(WH_CBT, WinHookProc, _Module.GetModuleInstance(), GetCurrentThreadId());
		cd.m_pThis = this;

		m_thunk.Init(HookProc, this);
		return reinterpret_cast<COMMONHOOKPROC>(&(m_thunk.thunk));
	}

	BEGIN_MSG_MAP(CHookedCommonDlgT)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	END_MSG_MAP()

	LRESULT OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		CenterWindow();
		return 0;
	}

	static LRESULT CALLBACK WinHookProc(int nCode, WPARAM wParam, LPARAM lParam)
	{
		if (nCode == HCBT_CREATEWND)
		{
			HWND            hwnd = reinterpret_cast<HWND>(wParam);
			CBT_CREATEWND  *pcs = reinterpret_cast<CBT_CREATEWND*>(lParam);
			CreateData     *cd = reinterpret_cast<CreateData*>(_Module.ExtractCreateWndData());
			UnhookWindowsHookEx(cd->m_hook);
			cd->m_pThis->m_hWnd = hwnd;
		}

		return 0;
    }
	static LRESULT CALLBACK HookProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
	{
		CHookedCommonDlgT *pThis = reinterpret_cast<CHookedCommonDlgT*>(hwnd);
		if (pThis->m_hWnd == NULL)
		{
			return 0;
		}

		// pass to the message map to process
		LRESULT result;
		BOOL bRet = pThis->ProcessWindowMessage(hwnd, msg, wp, lp, result, 0);
		if (!bRet && msg == WM_NCDESTROY)
		{
			// clear out window handle
			HWND hwnd = pThis->m_hWnd;
			pThis->m_hWnd = NULL;

			// clean up after window is destroyed
			pThis->OnFinalMessage(hwnd);
		}

		// We're only interested in whether or not the message was handled.
		// If we return FALSE, default processing will happen
		return bRet;
	}
};

/////////////////////////////////////////////////////////////////////////////
// CFileDialog - common base for Open and Save

class CFileDialog : public CCommonDialogT<OPENFILENAME>
{
public:
	CFileDialog(LPCTSTR pszFilter,
		LPCTSTR pszInitialFile,
		LPCTSTR pszDefExt,
		DWORD dwFlags)
		: CCommonDialogT<OPENFILENAME>(dwFlags)
	{
		lpstrFilter = pszFilter;
		if (pszInitialFile)
		{
			lstrcpy(m_pszFile, pszInitialFile);
		}
		else
		{
			*m_pszFile = 0;
		}
		lpstrFile = m_pszFile;
		nMaxFile = sizeof(m_pszFile) / sizeof(*m_pszFile);
		lpstrDefExt = pszDefExt;
    }

private:
    TCHAR m_pszFile[MAX_PATH+1];
};

/////////////////////////////////////////////////////////////////////////////
// CHookedFileDlgT - CHookedCommonDlgT plus a bunch of file dialog-related goodies

template <typename TBase = CWindow>
class CHookedFileDlgT : public CHookedCommonDlgT<TBase>
{
public:
	int GetFilePath(LPTSTR lpszStringBuf, int nMaxCount) const
	{
		ATLASSERT(::IsWindow(m_hWnd));
		ATLASSERT((Flags & OFN_EXPLORER));
		return ::SendMessage(GetParent(), CDM_GETFILEPATH, nMaxCount, lpszStringBuf);
	}
	int GetFolderIdList(LPVOID buf, int nMaxCount) const
	{
		ATLASSERT(::IsWindow(m_hWnd));
		ATLASSERT((Flags & OFN_EXPLORER));
		return ::SendMessage(GetParent(), CDM_GETFOLDERIDLIST, nMaxCount, buf);
	}
	int GetFolderPath(LPTSTR lpszStringBuf, int nMaxCount) const
	{
		ATLASSERT(::IsWindow(m_hWnd));
		ATLASSERT((Flags & OFN_EXPLORER));
		return ::SendMessage(GetParent(), CDM_GETFOLDERPATH, nMaxCount, lpszStringBuf);
	}
	int GetSpec(LPTSTR lpszStringBuf, int nMaxCount) const
	{
		ATLASSERT(::IsWindow(m_hWnd));
		ATLASSERT((Flags & OFN_EXPLORER));
		return ::SendMessage(GetParent(), CDM_GETSPEC, nMaxCount, lpszStringBuf);
	}
	void HideControl(int ctrlId)
	{
		ATLASSERT(::IsWindow(m_hWnd));
		ATLASSERT((Flags & OFN_EXPLORER));
		return ::SendMessage(GetParent(), CDM_HIDECONTROL, ctrlId, 0);
	}
	void SetControlText(int ctrlId, LPCTSTR ctrlText)
	{
		ATLASSERT(::IsWindow(m_hWnd));
		ATLASSERT((Flags & OFN_EXPLORER));
		return ::SendMessage(GetParent(), CDM_SETCONTROLTEXT, ctrlId, ctrlText);
	}
	void SetDefExt(LPCTSTR extension)
	{
		ATLASSERT(::IsWindow(m_hWnd));
		ATLASSERT((Flags & OFN_EXPLORER));
		return ::SendMessage(GetParent(), CDM_SETDEFEXT, 0, extension);
	}
	static UINT GetSelChangeMessage()
	{
		static UINT SelChangeMessage = ::RegisterWindowMessage(LBSELCHSTRING);
		return SelChangeMessage;
	}
	static UINT GetFileOKMessage()
	{
		static UINT FileOKMessage = ::RegisterWindowMessage(FILEOKSTRING);
		return FileOKMessage;
	}
	static UINT GetShareViolationMessage()
	{
		static UINT ShareViolationMessage = ::RegisterWindowMessage(SHAREVISTRING);
		return ShareViolationMessage;
	}
};

/////////////////////////////////////////////////////////////////////////////
// CFileOpenDialog - open an existing file

class CFileOpenDialog : public CFileDialog
{
public:
	CFileOpenDialog(LPCTSTR pszFilter = 0,
		LPCTSTR pszInitialFile = 0,
		LPCTSTR pszDefExt = 0,
		DWORD dwFlags = OFN_PATHMUSTEXIST)
	: CFileDialog(pszFilter, pszInitialFile, pszDefExt, dwFlags)
	{
	}

	int DoModal(HWND hwndParent = ::GetActiveWindow())
	{
		hwndOwner = hwndParent;
		return (::GetOpenFileName(this) ? IDOK : IDCANCEL);
	}
};

/////////////////////////////////////////////////////////////////////////////
// CFileOpenDialogEx - open an existing file (hooked dialog box)

template <typename TBase = CWindow>
class CFileOpenDialogEx : public CFileDialog, public CHookedFileDlgT<TBase>
{
public:
	CFileOpenDialogEx(LPCTSTR pszFilter = 0,
		LPCTSTR pszInitialFile = 0,
		LPCTSTR pszDefExt = 0,
		DWORD dwFlags = OFN_PATHMUSTEXIST)
	: CFileDialog(pszFilter, pszInitialFile, pszDefExt, dwFlags)
	{
	}
	int DoModal(HWND hwndParent = ::GetActiveWindow())
	{
		CreateData cd;
		lpfnHook = CreateHook(cd);
		Flags |= OFN_ENABLEHOOK;
		hwndOwner = hwndParent;
		return (::GetOpenFileName(this) ? IDOK : IDCANCEL);
	}
};

/////////////////////////////////////////////////////////////////////////////
// CFileSaveDialog - save to a file

class CFileSaveDialog : public CFileDialog
{
public:
	CFileSaveDialog(LPCTSTR pszFilter = 0,
		LPCTSTR pszInitialFile = 0,
		LPCTSTR pszDefExt = 0,
		DWORD dwFlags = OFN_OVERWRITEPROMPT)
	: CFileDialog(pszFilter, pszInitialFile, pszDefExt, dwFlags)
	{
	}

	int DoModal(HWND hwndParent = ::GetActiveWindow())
	{
		hwndOwner = hwndParent;
		return (::GetSaveFileName(this) ? IDOK : IDCANCEL);
	}
};

/////////////////////////////////////////////////////////////////////////////
// CFileSaveDialogEx - save to a file (hooked dialog box)

template <typename TBase = CWindow>
class CFileSaveDialogEx : public CFileDialog, public CHookedFileDlgT<TBase>
{
public:
	CFileSaveDialogEx(LPCTSTR pszFilter = 0,
		LPCTSTR pszInitialFile = 0,
		LPCTSTR pszDefExt = 0,
		DWORD dwFlags = OFN_OVERWRITEPROMPT)
	: CFileDialog(pszFilter, pszInitialFile, pszDefExt, dwFlags)
	{
	}
	int DoModal(HWND hwndParent = ::GetActiveWindow())
	{
		CreateData cd;
		lpfnHook = CreateHook(cd);
		Flags |= OFN_ENABLEHOOK;
		hwndOwner = hwndParent;
		return (::GetSaveFileName(this) ? IDOK : IDCANCEL);
	}
};

/////////////////////////////////////////////////////////////////////////////
// CFontDialog - used to select a font

class CFontDialog : public CCommonDialogT<CHOOSEFONT>
{
public:
	CFontDialog(LPLOGFONT lplfInitial = NULL,
			DWORD dwFlags = CF_EFFECTS | CF_SCREENFONTS,
			HDC hdcPrinter = NULL)
		: CCommonDialogT<CHOOSEFONT>(dwFlags)
	{
		ZeroMemory(&m_styleName, sizeof(m_styleName));
		lpszStyle = static_cast<LPTSTR>(m_styleName);

		if (lplfInitial)
		{
			Flags |= CF_INITTOLOGFONTSTRUCT;
			lpLogFont = lplfInitial;
			m_lf = *lplfInitial;
		}
		else
		{
			ZeroMemory(&m_lf, sizeof(m_lf));
			lpLogFont = &m_lf;
		}

		if (hdcPrinter)
		{
			hDC = hdcPrinter;
			Flags |= CF_PRINTERFONTS;
		}
	}

#ifdef _RICHEDIT_
	CFontDialog(const CHARFORMAT& charformat,
			DWORD dwFlags = CF_SCREENFONTS,
			HDC hdcPrinter = NULL)
		: CCommonDialogT<CHOOSEFONT>(dwFlags)
	{
		ZeroMemory(&m_styleName, sizeof(m_styleName));
		lpszStyle = m_styleName;

		ZeroMemory(&m_lf, sizeof(m_lf));
		lpLogFont = &m_lf;
		Flags = dwFlags |= CF_INITTOLOGFONTSTRUCT | FillInLogFont(charformat);

		if (hdcPrinter)
		{
			hDC = hdcPrinter;
			Flags |= CF_PRINTERFONTS;
		}
		if (charformat.dwMask & CFM_COLOR)
			rgbColors = charformat.crTextColor;
	}
#endif // _RICHEDIT_

// Operations
	int DoModal(HWND hwndParent = ::GetActiveWindow())
	{
		hwndOwner = hwndParent;
		int nResult = ::ChooseFont(this);
		if (nResult == IDOK)
		{
			// copy logical font from user's initialization buffer (if needed)
			if (lpLogFont != &m_lf)
			{
				m_lf = *lpLogFont;
			}
			return IDOK;
		}
		return nResult ? nResult : IDCANCEL;
	}

	// Get the selected font
	void GetCurrentFont(LPLOGFONT lplf)
	{
		ATLASSERT(lplf);
		*lplf = m_lf;
	}

	// Helpers for parsing information after successful return
	LPCTSTR GetFaceName() const   // return the face name of the font
	{
		return lpLogFont->lfFaceName;
	}
	LPCTSTR GetStyleName() const  // return the style name of the font
	{
		return lpszStyle;
	}
	int GetSize() const           // return the pt size of the font
	{
		return iPointSize;
	}
	COLORREF GetColor() const     // return the color of the font
	{
		return rgbColors;
	}
	int GetWeight() const         // return the chosen font weight
	{
		return lpLogFont->lfWeight;
	}
	bool IsStrikeOut() const      // return true if strikeout
	{
		return lpLogFont->lfStrikeOut ? true : false;
	}
	BOOL IsUnderline() const      // return true if underline
	{
		return lpLogFont->lfUnderline ? true : false;
	}
	BOOL IsBold() const           // return true if bold font
	{
		return lpLogFont->lfWeight >= FW_BOLD ? true : false;
	}
	BOOL IsItalic() const         // return true if italic font
	{
		return lpLogFont->lfItalic ? true : false;
	}

#ifdef _RICHEDIT_
	// CHARFORMAT Implementation
	void GetCharFormat(CHARFORMAT& cf) const
	{
		cf.dwEffects = 0;
		cf.dwMask = 0;
		if ((Flags & CF_NOSTYLESEL) == 0)
		{
			cf.dwMask |= CFM_BOLD | CFM_ITALIC;
			cf.dwEffects |= (IsBold()) ? CFE_BOLD : 0;
			cf.dwEffects |= (IsItalic()) ? CFE_ITALIC : 0;
		}
		if ((Flags & CF_NOSIZESEL) == 0)
		{
			cf.dwMask |= CFM_SIZE;
			// GetSize() returns in tenths of points so multiply by 2 to get twips
			cf.yHeight = GetSize()*2;
		}

		if ((Flags & CF_NOFACESEL) == 0)
		{
			cf.dwMask |= CFM_FACE;
			cf.bPitchAndFamily = lpLogFont->lfPitchAndFamily;
			lstrcpy(cf.szFaceName, GetFaceName());
		}

		if (Flags & CF_EFFECTS)
		{
			cf.dwMask |= CFM_UNDERLINE | CFM_STRIKEOUT | CFM_COLOR;
			cf.dwEffects |= (IsUnderline()) ? CFE_UNDERLINE : 0;
			cf.dwEffects |= (IsStrikeOut()) ? CFE_STRIKEOUT : 0;
			cf.crTextColor = GetColor();
		}
		if ((Flags & CF_NOSCRIPTSEL) == 0)
		{
			cf.bCharSet = lpLogFont->lfCharSet;
			cf.dwMask |= CFM_CHARSET;
		}
		cf.yOffset = 0;
	}

	DWORD FillInLogFont(const CHARFORMAT& cf)
	{
		DWORD dwFlags = 0;
		if (cf.dwMask & CFM_SIZE)
		{
			// TODO: Replace with GDI wrappers?
			HDC dc = ::CreateDC(_T("DISPLAY"), NULL, NULL, NULL);
			LONG yPerInch = ::GetDeviceCaps(dc, LOGPIXELSY);
			m_lf.lfHeight = -(int) ((cf.yHeight * yPerInch) / 1440);
		}
		else
			m_lf.lfHeight = 0;

		m_lf.lfWidth = 0;
		m_lf.lfEscapement = 0;
		m_lf.lfOrientation = 0;

		if ((cf.dwMask & (CFM_ITALIC|CFM_BOLD)) == (CFM_ITALIC|CFM_BOLD))
		{
			m_lf.lfWeight = (cf.dwEffects & CFE_BOLD) ? FW_BOLD : FW_NORMAL;
			m_lf.lfItalic = (BYTE)((cf.dwEffects & CFE_ITALIC) ? TRUE : FALSE);
		}
		else
		{
			dwFlags |= CF_NOSTYLESEL;
			m_lf.lfWeight = FW_DONTCARE;
			m_lf.lfItalic = FALSE;
		}

		if ((cf.dwMask & (CFM_UNDERLINE|CFM_STRIKEOUT|CFM_COLOR)) ==
			(CFM_UNDERLINE|CFM_STRIKEOUT|CFM_COLOR))
		{
			dwFlags |= CF_EFFECTS;
			m_lf.lfUnderline = (BYTE)((cf.dwEffects & CFE_UNDERLINE) ? TRUE : FALSE);
			m_lf.lfStrikeOut = (BYTE)((cf.dwEffects & CFE_STRIKEOUT) ? TRUE : FALSE);
		}
		else
		{
			m_lf.lfUnderline = (BYTE)FALSE;
			m_lf.lfStrikeOut = (BYTE)FALSE;
		}

		if (cf.dwMask & CFM_CHARSET)
			m_lf.lfCharSet = cf.bCharSet;
		else
			dwFlags |= CF_NOSCRIPTSEL;
		m_lf.lfOutPrecision = OUT_DEFAULT_PRECIS;
		m_lf.lfClipPrecision = CLIP_DEFAULT_PRECIS;
		m_lf.lfQuality = DEFAULT_QUALITY;
		if (cf.dwMask & CFM_FACE)
		{
			m_lf.lfPitchAndFamily = cf.bPitchAndFamily;
			lstrcpy(m_lf.lfFaceName, cf.szFaceName);
		}
		else
		{
			m_lf.lfPitchAndFamily = DEFAULT_PITCH|FF_DONTCARE;
			m_lf.lfFaceName[0] = (TCHAR)0;
		}
		return dwFlags;
	}
#endif // _RICHEDIT_

protected:
	TCHAR m_styleName[64]; // contains style name after return
	LOGFONT m_lf; // default LOGFONT to store the info
};

/////////////////////////////////////////////////////////////////////////////
// CFontDialogEx - used to select a font (hooked dialog box)

template <typename TBase = CWindow>
class CFontDialogEx : public CFontDialog, public CHookedCommonDlgT<TBase>
{
public:
	CFontDialogEx(LPLOGFONT lplfInitial = NULL,
			DWORD dwFlags = CF_EFFECTS | CF_SCREENFONTS,
			HDC hdcPrinter = NULL)
		: CFontDialog(lplfInitial, dwFlags, hdcPrinter)
	{
	}

#ifdef _RICHEDIT_
	CFontDialogEx(const CHARFORMAT& charformat,
			DWORD dwFlags = CF_SCREENFONTS,
			HDC hdcPrinter = NULL)
		: CFontDialog(charformat, dwFlags, hdcPrinter)
	{
	}
#endif
	int DoModal(HWND hwndParent = ::GetActiveWindow())
	{
		CreateData cd;
		lpfnHook = CreateHook(cd);
		Flags |= CF_ENABLEHOOK;
		return CFontDialog::DoModal(hwndParent);
	}
	void GetCurrentFont(LPLOGFONT lplf) const
	{
		ATLASSERT(lplf != NULL);

		if (m_hWnd != NULL)
			SendMessage(WM_CHOOSEFONT_GETLOGFONT, 0, (DWORD)(LPVOID)lplf);
		else
			*lplf = m_lf;
	}
	void SetCurrentFont(LPLOGFONT lplf)
	{
		ATLASSERT(lplf != NULL);

		if (m_hWnd != NULL)
			SendMessage(WM_CHOOSEFONT_SETLOGFONT, 0, (DWORD)(LPVOID)lplf);
		else
			m_lf = *lplf;
	}
};

/////////////////////////////////////////////////////////////////////////////
// CColorDialog - used to select a color

class CColorDialog : public CCommonDialogT<CHOOSECOLOR>
{
public:
// Constructors
	CColorDialog(COLORREF clrInit = 0, DWORD dwFlags = 0,
			COLORREF *customColors = GetCustomColors())
		: CCommonDialogT<CHOOSECOLOR>(dwFlags)
	{
		lpCustColors = customColors;
		if ((rgbResult = clrInit) != 0)
			Flags |= CC_RGBINIT;
	}

// Operations
	int DoModal(HWND hwndParent = ::GetActiveWindow())
	{
		hwndOwner = hwndParent;
		int nResult = ::ChooseColor(this);
		return nResult ? nResult : IDCANCEL;
	}

	// Helpers for parsing information after successful return
	COLORREF GetColor() const
	{
		return rgbResult;
	}

protected:
	static COLORREF *GetCustomColors()
	{
		// Is this approach thread-safe?
		// custom colors are initialized to white
		static COLORREF CustomColors[16] =
		{
			RGB(255, 255, 255),
			RGB(255, 255, 255),
			RGB(255, 255, 255),
			RGB(255, 255, 255),
			RGB(255, 255, 255),
			RGB(255, 255, 255),
			RGB(255, 255, 255),
			RGB(255, 255, 255),
			RGB(255, 255, 255),
			RGB(255, 255, 255),
			RGB(255, 255, 255),
			RGB(255, 255, 255),
			RGB(255, 255, 255),
			RGB(255, 255, 255),
			RGB(255, 255, 255),
			RGB(255, 255, 255),
		};
		return CustomColors;
	}
};

/////////////////////////////////////////////////////////////////////////////
// CColorDialogEx - save to a file (hooked dialog box)

template <typename TBase = CWindow>
class CColorDialogEx : public CColorDialog, public CHookedCommonDlgT<TBase>
{
public:
	CColorDialogEx(COLORREF clrInit = 0, DWORD dwFlags = 0,
			COLORREF *customColors = GetCustomColors())
		: CColorDialog(clrInit, dwFlags, customColors)
	{
	}
	int DoModal(HWND hwndParent = ::GetActiveWindow())
	{
		CreateData cd;
		lpfnHook = CreateHook(cd);
		Flags |= CC_ENABLEHOOK;
		return CColorDialog::DoModal(hwndParent);
	}
	void SetRGB(COLORREF color)
	{
		static UINT SetRGBMessage = ::RegisterWindowMessage(SETRGBSTRING);

		ATLASSERT(::IsWindow(m_hWnd));
		SendMessage(SetRGBMessage, 0, color);
	}
	static UINT GetColorOKMessage()
	{
		static UINT ColorOKMessage = ::RegisterWindowMessage(COLOROKSTRING);
		return ColorOKMessage;
	}
};

/////////////////////////////////////////////////////////////////////////////
// CFindReplaceDialog - used to find or find and replace
//
// This is the right version to use when not subclassing and
// when taking full responsibility for the lifetime of the object.
// On the other hand, I'm not entirely sure it's useful as is.

class CFindReplaceDialog : public CCommonDialogT<FINDREPLACE>
{
public:
// Constructors
	CFindReplaceDialog() : CCommonDialogT<FINDREPLACE>(0)
	{
		lpstrFindWhat = m_szFindWhat;
		m_szFindWhat[0] = '\0';
		m_szReplaceWith[0] = '\0';
	}

	BOOL Create(BOOL bFindDialogOnly, // TRUE for Find, FALSE for FindReplace
		LPCTSTR lpszFindWhat = NULL,
		LPCTSTR lpszReplaceWith = NULL,
		DWORD dwFlags = FR_DOWN,
		HWND parentWnd = ::GetActiveWindow())
	{
		ATLASSERT(parentWnd);

		wFindWhatLen = sizeof(m_szFindWhat) / sizeof(m_szFindWhat[0]);
		lpstrReplaceWith = (LPTSTR)m_szReplaceWith;
		wReplaceWithLen = sizeof(m_szReplaceWith) / sizeof(m_szReplaceWith[0]);
		Flags |= dwFlags;
		hwndOwner = parentWnd;

		if (lpszFindWhat)
			lstrcpyn(m_szFindWhat, lpszFindWhat, wFindWhatLen);

		if (lpszReplaceWith)
			lstrcpyn(m_szReplaceWith, lpszReplaceWith, wReplaceWithLen);

		HWND hWnd;
		if (bFindDialogOnly)
			hWnd = ::FindText(this);
		else
			hWnd = ::ReplaceText(this);

		return hWnd != NULL;
	}
	virtual void OnFinalMessage(HWND /*hWnd*/)
	{
		delete this;
	}

// Operations
	// Helpers for parsing information after successful return
	LPCTSTR GetReplaceString() const// get replacement string
	{
		return lpstrReplaceWith;
	}
	LPCTSTR GetFindString() const   // get find string
	{
		return lpstrFindWhat;
	}
	bool SearchDown() const         // TRUE if search down, FALSE is up
	{
		Flags & FR_DOWN ? true : false;
	}
	bool FindNext() const           // TRUE if command is find next
	{
		return Flags & FR_FINDNEXT ? true : false;
	}
	bool MatchCase() const          // TRUE if matching case
	{
		return Flags & FR_MATCHCASE ? true : false;
	}
	bool MatchWholeWord() const     // TRUE if matching whole words only
	{
		return Flags & FR_WHOLEWORD ? true : false;
	}
	bool ReplaceCurrent() const     // TRUE if replacing current string
	{
		return Flags & FR_REPLACE ? true : false;
	}
	bool ReplaceAll() const         // TRUE if replacing all occurrences
	{
		return Flags & FR_REPLACEALL ? true : false;
	}
	bool IsTerminating() const      // TRUE if terminating dialog
	{
		return Flags & FR_DIALOGTERM ? true : false;
	}

	static UINT GetFindMessage()
	{
		static UINT FindMessage = ::RegisterWindowMessage(FINDMSGSTRING);
		return FindMessage;
	}

// Implementation
protected:
	TCHAR m_szFindWhat[128];
	TCHAR m_szReplaceWith[128];
};

/////////////////////////////////////////////////////////////////////////////
// CFindReplaceDialogEx - used to find or find and replace (hooked dialog box)
//
// This dialog is meant to be created on the heap.  If created on the stack
// or as a member variable of another object, the subclass should override
// OnFinalMessage to do nothing.
//
// After creating the window

template <typename TDeriving, typename TBase = CWindow>
class CFindReplaceDialogEx : public CFindReplaceDialog, public CHookedCommonDlgT<TBase>
{
public:
// Constructors
	CFindReplaceDialogEx()
	{
		m_ownerWnd = NULL;
	}

	BOOL Create(BOOL bFindDialogOnly, // TRUE for Find, FALSE for FindReplace
		LPCTSTR lpszFindWhat = NULL,
		LPCTSTR lpszReplaceWith = NULL,
		DWORD dwFlags = FR_DOWN,
		HWND parentWnd = ::GetActiveWindow())
	{
		CreateData cd;
		lpfnHook = CreateHook(cd);
		dwFlags |= FR_ENABLEHOOK;
		m_ownerWnd = parentWnd;

		return CFindReplaceDialog::Create(bFindDialogOnly, lpszFindWhat, lpszReplaceWith, dwFlags, parentWnd);
	}
	virtual void OnFinalMessage(HWND /*hWnd*/)
	{
		// Should never have gotten here
		ATLASSERT(FALSE);
	}

	BEGIN_MSG_MAP(FindReplaceDialogEx)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
		MESSAGE_HANDLER(GetFindMessage(), OnFindMessage)
	END_MSG_MAP()

protected:
	void OnDialogTermination(FINDREPLACE *)
	{
		m_hWnd = NULL;
		delete this;
	}
	void OnFindNext(FINDREPLACE *fm)
	{
		// Default behavior: forward message to "real" owner
		::SendMessage(m_ownerWnd, GetFindMessage(), 0, reinterpret_cast<LPARAM>(fm));
	}
	void OnReplace(FINDREPLACE *fm)
	{
		// Default behavior: forward message to "real" owner
		::SendMessage(m_ownerWnd, GetFindMessage(), 0, reinterpret_cast<LPARAM>(fm));
	}
	void OnReplaceAll(FINDREPLACE *fm)
	{
		// Default behavior: forward message to "real" owner
		::SendMessage(m_ownerWnd, GetFindMessage(), 0, reinterpret_cast<LPARAM>(fm));
	}
	LRESULT OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM lp, BOOL& /*bHandled*/)
	{
		// Set the owner window to be this window, so that we will get
		// notifications of window closing
		TDeriving * derived = static_cast<TDeriving*>(this);
		derived->hwndOwner = *this;
		return 0;
	}
	LRESULT OnFindMessage(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM lp, BOOL& bHandled)
	{
		TDeriving * derived = static_cast<TDeriving*>(this);
		FINDREPLACE * fr = reinterpret_cast<FINDREPLACE*>(lp);
		if (fr->Flags & FR_FINDNEXT)
			derived->OnFindNext(fr);
		if (fr->Flags & FR_REPLACE)
			derived->OnReplace(fr);
		if (fr->Flags & FR_REPLACEALL)
			derived->OnReplaceAll(fr);
		if (fr->Flags & FR_DIALOGTERM)
			derived->OnDialogTermination(fr);
		return 0;
	}

// Implementation
protected:
	HWND m_ownerWnd;
};

/////////////////////////////////////////////////////////////////////////////
// CPrintSupportDlgT - common base for Print and Page Setup

template <typename T>
class CPrintSupportDlgT : public CCommonDialogT<T>
{
public:
	CPrintSupportDlgT(DWORD flags) : CCommonDialogT<T>(flags)
	{
	}
	LPDEVMODE GetDevMode() const    // return DEVMODE
	{
		if (hDevMode == NULL)
			return NULL;
		return reinterpret_cast<LPDEVMODE>(::GlobalLock(hDevMode));
	}
	LPCTSTR GetDriverName() const   // return driver name
	{
		if (hDevNames == NULL)
			return _T("");

		LPDEVNAMES lpDev = reinterpret_cast<LPDEVNAMES>(GlobalLock(hDevNames));
		return reinterpret_cast<LPCTSTR>(lpDev) + lpDev->wDriverOffset;
	}
	LPCTSTR GetDeviceName() const   // return device name
	{
		if (hDevNames == NULL)
			return _T("");

		LPDEVNAMES lpDev = reinterpret_cast<LPDEVNAMES>(GlobalLock(hDevNames));
		return reinterpret_cast<LPCTSTR>(lpDev) + lpDev->wDeviceOffset;
	}
	LPCTSTR GetPortName() const     // return output port name
	{
		if (hDevNames == NULL)
			return _T("");

		LPDEVNAMES lpDev = reinterpret_cast<LPDEVNAMES>(GlobalLock(hDevNames));
		return reinterpret_cast<LPCTSTR>(lpDev) + lpDev->wOutputOffset;
	}

	// This helper creates a DC based on the DEVNAMES and DEVMODE structures.
	// This DC is returned, but also stored in hDC as though it had been
	// returned by CommDlg.  It is assumed that any previously obtained DC
	// has been/will be deleted by the user.  This may be
	// used without ever invoking the print/print setup dialogs.
	
	// TODO: Evaluate whether or not this belongs here
	HDC CreatePrinterDC()
	{
		if (hDevNames == NULL)
			return NULL;

		LPDEVNAMES lpDevNames = reinterpret_cast<LPDEVNAMES>(::GlobalLock(hDevNames));
		if (lpDevNames == NULL)
			return NULL;
		LPDEVMODE  lpDevMode = (hDevMode != NULL) ?
							reinterpret_cast<LPDEVMODE>(::GlobalLock(hDevMode)) : NULL;

		LPCTSTR baseAddr = reinterpret_cast<LPCTSTR>(lpDevNames);
		hDC = ::CreateDC(baseAddr + lpDevNames->wDriverOffset,
			baseAddr + lpDevNames->wDeviceOffset,
			baseAddr + lpDevNames->wOutputOffset,
			lpDevMode);

		::GlobalUnlock(hDevNames);
		if (hDevMode != NULL)
			::GlobalUnlock(hDevMode);
		return hDC;
	}
};

/////////////////////////////////////////////////////////////////////////////
// CPrintDialog - used for Print

class CPrintDialog : public CPrintSupportDlgT<PRINTDLG>
{
public:
// Constructors
	CPrintDialog(bool bPrintSetupOnly,
		// TRUE for Print Setup, FALSE for Print Dialog
		DWORD dwFlags = PD_ALLPAGES | PD_USEDEVMODECOPIES | PD_NOPAGENUMS
			| PD_HIDEPRINTTOFILE | PD_NOSELECTION)
		: CPrintSupportDlgT<PRINTDLG>(dwFlags)
	{
		if (bPrintSetupOnly)
		{
			Flags |= PD_PRINTSETUP;
		}
		else
		{
			Flags |= PD_RETURNDC;
		}

		// This is what MFC does.  Is it what we want?
		Flags &= ~PD_RETURNIC; // do not support information context
	}

// Operations
	int DoModal(HWND hwndParent = ::GetActiveWindow())
	{
		hwndOwner = hwndParent;
		int nResult = ::PrintDlg(this);
		return nResult ? nResult : IDCANCEL;
	}

	// GetDefaults will not display a dialog but will get
	// device defaults
	BOOL GetDefaults()
	{
		Flags |= PD_RETURNDEFAULT;
		return ::PrintDlg(this);
	}

	// Helpers for parsing information after successful return
	int GetCopies() const           // num. copies requested
	{
		if (Flags & PD_USEDEVMODECOPIES)
			return GetDevMode()->dmCopies;
		else
			return nCopies;
	}
	bool PrintCollate() const       // TRUE if collate checked
	{
		return Flags & PD_COLLATE ? true : false;
	}
	bool PrintSelection() const     // TRUE if printing selection
	{
		return Flags & PD_SELECTION ? true : false;
	}
	bool PrintAll() const           // TRUE if printing all pages
	{
		return !PrintRange() && !PrintSelection();
	}
	bool PrintRange() const         // TRUE if printing page range
	{
		return Flags & PD_PAGENUMS ? true : false;
	}
	int GetFromPage() const         // starting page if valid
	{
		return (PrintRange() ? nFromPage : -1);
	}
	int GetToPage() const           // starting page if valid
	{
		return (PrintRange() ? nToPage : -1);
	}
	HDC GetPrinterDC() const        // return HDC (caller must delete)
	{
		ATLASSERT(Flags & PD_RETURNDC);
		return hDC;
	}
};

/////////////////////////////////////////////////////////////////////////////
// CPrintDialogEx - used for Print (hooked dialog box)
//

template <typename TBase = CWindow>
class CPrintDialogEx : public CPrintDialog, CHookedCommonDlgT<TBase>
{
public:
	CPrintDialogEx(bool bPrintSetupOnly,
		// TRUE for Print Setup, FALSE for Print Dialog
		DWORD dwFlags = PD_ALLPAGES | PD_USEDEVMODECOPIES | PD_NOPAGENUMS
			| PD_HIDEPRINTTOFILE | PD_NOSELECTION)
		: CPrintDialog(bPrintSetupOnly, dwFlags)
	{
	}

	int DoModal(HWND hwndParent = ::GetActiveWindow())
	{
		CreateData cd;
		lpfnPrintHook = CreateHook(cd);
		Flags |= PD_ENABLEPRINTHOOK;
		return CPrintDialog::DoModal(hwndParent);
	}
};

/////////////////////////////////////////////////////////////////////////////
// Page Setup dialog

class CPageSetupDialog : public CPrintSupportDlgT<PAGESETUPDLG>
{
public:
// Constructors
	CPageSetupDialog(DWORD dwFlags = 0)
		: CPrintSupportDlgT<PAGESETUPDLG>(dwFlags)
	{
	}

// Attributes
	SIZE GetPaperSize() const
	{
		SIZE size = {ptPaperSize.x, ptPaperSize.y};
		return size;
	}
	void GetMargins(LPRECT lpRectMargins, LPRECT lpRectMinMargins) const
	{
		if (lpRectMargins != NULL)
			memcpy(lpRectMargins, &rtMargin, sizeof(RECT));
		if (lpRectMinMargins != NULL)
			memcpy(lpRectMinMargins, &rtMinMargin, sizeof(RECT));
	}

// Operations
	int DoModal(HWND hwndParent = ::GetActiveWindow())
	{
		hwndOwner = hwndParent;
		int nResult = ::PageSetupDlg(this);
		return nResult ? nResult : IDCANCEL;
	}
};

/////////////////////////////////////////////////////////////////////////////
// CPageSetupDialogEx - used for Page Setup (hooked dialog box)
//
// To support hooking both the Page Setup and the Print Preview windows,
// we'll use the main message map for "Page Setup" and ALT_MSG_MAP 1 for
// the Print Preview window.  We're not actually interested in subclassing
// the Print Preview window (which is basically a static child of the
// Page Setup dialog).  Instead, we're interested only in specific
// notifications WM_PSD_*.

template <typename TBase = CWindow, typename TPaint = CWindow>
class CPageSetupDialogEx : public CPageSetupDialog, public CHookedCommonDlgT<TBase>
{
public:
	CPageSetupDialogEx(DWORD dwFlags = 0)
		: CPageSetupDialog(dwFlags)
	{
	}

	int DoModal(HWND hwndParent = ::GetActiveWindow())
	{
		CreateData cd;
		lpfnPageSetupHook = CreateHook(cd);
		lpfnPagePaintHook = reinterpret_cast<LPPAGEPAINTHOOK>(&(m_paintThunk.thunk));
		Flags |= PSD_ENABLEPAGEPAINTHOOK | PSD_ENABLEPAGESETUPHOOK;
		return CPageSetupDialog::DoModal(hwndParent);
	}

protected:
	TPaint m_paintWindow;
	CWndProcThunk m_paintThunk;

	BEGIN_MSG_MAP(CPageSetupDialogEx)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	ALT_MSG_MAP(1)
	END_MSG_MAP()

	LRESULT OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		m_paintWindow = GetDlgItem(rct1);
		m_paintThunk.Init(PaintDlgProc, this);
		return 0;
	}
	static LRESULT CALLBACK PaintDlgProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
	{
		// This HWND is a STATIC that represents the drawing area
		CPageSetupDialogEx *pThis = reinterpret_cast<CPageSetupDialogEx*>(hwnd);
		ATLASSERT(pThis->m_paintWindow.m_hWnd != NULL);

		// pass to the message map to process
		LRESULT result;
		BOOL bRet = pThis->ProcessWindowMessage(hwnd, msg, wp, lp, result, 1);

		// We're only interested in whether or not the message was handled.
		return bRet;
	}
};

}   // namespace Attila

#ifndef _ATTILA_NOUSE_NAMESPACE
using namespace Attila;
#endif

#endif // INC_ATTILACOMMDLG
