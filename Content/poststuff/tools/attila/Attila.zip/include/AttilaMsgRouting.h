// AttilaMsgRouting.h: Helper macros for chaining pointers and filtering messages
/////////////////////////////////////////////////////////////////////////////
// This is part of the Attila library.
// Copyright (c) 1999, Attila contributors (see ReadMe.htm).
// All rights reserved. No warranties extended.
/////////////////////////////////////////////////////////////////////////////

#pragma once
#ifndef INC_ATTILAMSGROUTING
#define INC_ATTILAMSGROUTING

namespace Attila
{

// Checks for specific message type before processing
#define BEGIN_MSG_MAP_FILTER(theClass, theMessage) \
public: \
	BOOL ProcessWindowMessage(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, LRESULT& lResult, DWORD dwMsgMapID = 0) \
	{ \
		if(uMsg == theMessage) \
		{ \
			BOOL bHandled(TRUE); \
			hWnd; \
			uMsg; \
			wParam; \
			lParam; \
			lResult; \
			bHandled; \
			switch(dwMsgMapID) \
			{ \
			case 0:

// Add the missing curly brace
#define END_MSG_MAP_FILTER() \
				break; \
			default: \
				ATLTRACE2(atlTraceWindowing, 0, _T("Invalid message map ID (%i)\n"), dwMsgMapID); \
				ATLASSERT(FALSE); \
				break; \
			} \
		} \
		return FALSE; \
	} 


// Chain to another message map based on message type
#define CHAIN_MSG_MAP_FILTER(theChainMember, theMessage) \
	{ \
		if(uMsg == theMessage) \
		{ \
			if(theChainMember::ProcessWindowMessage(hWnd, uMsg, wParam, lParam, lResult)) \
				return TRUE; \
		} \
	}

// Ensure pointer validity before making the chain call
#define CHAIN_MSG_MAP_ALT_PTR(theChainMember, msgMapID) \
	{ \
		if(theChainMember) \
		{ \
			if(theChainMember->ProcessWindowMessage(hWnd, uMsg, wParam, lParam, lResult, msgMapID)) \
				return TRUE; \
		} \
	}

// Chain to another message map's alternate entry based on message type
#define CHAIN_MSG_MAP_ALT_FILTER(theChainMember, theMessage, msgMapID) \
	{ \
		if(uMsg == theMessage) \
		{ \
			if(theChainMember::ProcessWindowMessage(hWnd, uMsg, wParam, lParam, lResult, msgMapID)) \
				return TRUE; \
		} \
	}

// Chain to a member variable message map based on message type
#define CHAIN_MSG_MAP_MEMBER_FILTER(theChainMember, theMessage) \
	{ \
		if(uMsg == theMessage) \
		{ \
			if(theChainMember.ProcessWindowMessage(hWnd, uMsg, wParam, lParam, lResult)) \
				return TRUE; \
		} \
	}

// Ensure pointer validity before making the chain call
#define CHAIN_MSG_MAP_PTR(theChainMember) \
	{ \
		if(theChainMember) \
		{ \
			if(theChainMember->ProcessWindowMessage(hWnd, uMsg, wParam, lParam, lResult, 0)) \
				return TRUE; \
		} \
	}

// Match message type and then ensure pointer validity
#define CHAIN_MSG_MAP_PTR_FILTER(theChainMember, theMessage) \
	{ \
		if(uMsg == theMessage) \
		{ \
			CHAIN_MSG_MAP_PTR(theChainMember) \
		} \
	}

#define END_MSG_FILTER(theMessage) \
	{ \
		if(uMsg == theMessage) \
		{ \
			return TRUE; \
		} \
	}

/////////////////////////////////////////////////////////////////////
// CFilteredMsgPath - 
// provides easy usage of message filtering macros within the context
// of a class foreign to an existing hierarchy
/////////////////////////////////////////////////////////////////////
template <typename NextNode, UINT uMsg = WM_COMMAND, UINT uMapId = 0>
struct CFilteredMsgPath : public CMessageMap
{
	CFilteredMsgPath(NextNode *pNext = 0) : m_pNext(pNext), 
										    m_uMsg(uMsg), 
											m_uMapId(uMapId) {}
	virtual ~CFilteredMsgPath() {}
	
	BEGIN_MSG_MAP_FILTER(CFilteredMsgPath, m_uMsg)
	CHAIN_MSG_MAP_ALT_PTR(m_pNext, m_uMapId)
	END_MSG_MAP_FILTER()

	NextNode *m_pNext;
	UINT m_uMsg;
	UINT m_uMapId;
};

/*
/////////////////////////////////////////////////////////////////////
// CFilteredMsgHierarchy - 
// Provides easy usage of message filtering macros within the context
// of class scope resolution.
// NOTE: This is probably a dead end. Can't seem to find a way to elegantly
//       handle multiple message types in conjunction with MI.
/////////////////////////////////////////////////////////////////////
template <typename NextNode, UINT uMsg = WM_COMMAND, UINT uMapId = 0>
struct CFilteredMsgHierarchy : public NextNode
{
	CFilteredMsgHierarchy() : m_uMsg(uMsg), m_uMapId(uMapId) {}
	virtual ~CFilteredMsgHierarchy() {}
	
	BEGIN_MSG_MAP_FILTER(CFilteredMsgHierarchy, m_uMsg)
	CHAIN_MSG_MAP_ALT(NextNode, m_uMapId)
	END_MSG_MAP_FILTER()

	UINT m_uMsg;
	UINT m_uMapId;
};
*/

}   // namespace Attila

#ifndef _ATTILA_NOUSE_NAMESPACE
using namespace Attila;
#endif

#endif // INC_ATTILAMSGROUTING
