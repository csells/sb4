// AttilaWindowSerializer.h
/////////////////////////////////////////////////////////////////////////////
// This is part of the Attila library.
// Copyright (c) 1999, Attila contributors (see ReadMe.htm).
// All rights reserved. No warranties extended.
/////////////////////////////////////////////////////////////////////////////

#pragma once
#ifndef INC_ATTILAWINDOWSERIALIZER
#define INC_ATTILAWINDOWSERIALIZER

#include "AttilaRegPrefs.h"

namespace Attila
{

const DWORD wsFlagPoint = 0x1;
const DWORD wsFlagSize = 0x2;
const DWORD wsFlagMinimized = 0x4;
const DWORD wsFlagMaximized = 0x8;

const DWORD wsFlagRect = wsFlagPoint | wsFlagSize;

const DWORD wsFlagMainFrame = wsFlagRect | wsFlagMaximized;
const DWORD wsFlagChildFrame = wsFlagRect | wsFlagMaximized | wsFlagMinimized;


template <class TPrefs>
class CWindowSerializerBase
{
// Operations
public:
	HRESULT Remember(LPCTSTR pszName, HWND hwnd, DWORD dwFlags) const;
	HRESULT Restore(LPCTSTR pszName, HWND hwnd, int nCmdShow = -1) const;

// Implementation Data
protected:
	TPrefs m_prefs;
};


class CRegWindowSerializer : public CWindowSerializerBase<CRegPrefs>
{
// Construction
public:
	CRegWindowSerializer() {}
	CRegWindowSerializer(HKEY hkeyRoot, LPCTSTR pszKeyPath) { m_prefs.Open(hkeyRoot, pszKeyPath); }

	HRESULT Open(HKEY hkeyRoot, LPCTSTR pszKeyPath) { return m_prefs.Open(hkeyRoot, pszKeyPath); }
	void Close() { m_prefs.Close(); }
};


template <class TPrefs>
HRESULT CWindowSerializerBase<TPrefs>::Remember(LPCTSTR pszName, HWND hwnd, DWORD dwFlags) const
{
	// get window placement
	WINDOWPLACEMENT wndpl;
	ZeroMemory(&wndpl, sizeof(wndpl));
	wndpl.length = sizeof(WINDOWPLACEMENT);
	if (!::GetWindowPlacement(hwnd, &wndpl))
		return HRESULT_FROM_WIN32(::GetLastError());

	// determine minimized/maximized state
	bool bMinimized = wndpl.showCmd == SW_SHOWMINIMIZED;
	bool bMaximized = wndpl.showCmd == SW_SHOWMAXIMIZED ||
		(bMinimized && (wndpl.flags & WPF_RESTORETOMAXIMIZED));

	// allocate buffer for value name
	int nNameLength = lstrlen(pszName);
	TCHAR * pszValueName = new TCHAR [nNameLength + 32];
	lstrcpy(pszValueName, pszName);

	// store placement data
	HRESULT hr = S_OK;
	do
	{
		// remember flags
		lstrcpy(pszValueName + nNameLength, _T("-Flags"));
		hr = m_prefs.Write(pszValueName, dwFlags);
		if (FAILED(hr)) break;

		// check for point flag
		if (dwFlags & wsFlagPoint)
		{
			// remember left and top coordinates
			lstrcpy(pszValueName + nNameLength, _T("-Left"));
			hr = m_prefs.Write(pszValueName, wndpl.rcNormalPosition.left);
			if (FAILED(hr)) break;
			lstrcpy(pszValueName + nNameLength, _T("-Top"));
			hr = m_prefs.Write(pszValueName, wndpl.rcNormalPosition.top);
			if (FAILED(hr)) break;
		}
		
		// check for size flag
		if (dwFlags & wsFlagSize)
		{
			// remember width and height
			lstrcpy(pszValueName + nNameLength, _T("-Width"));
			hr = m_prefs.Write(pszValueName, wndpl.rcNormalPosition.right - wndpl.rcNormalPosition.left);
			if (FAILED(hr)) break;
			lstrcpy(pszValueName + nNameLength, _T("-Height"));
			hr = m_prefs.Write(pszValueName, wndpl.rcNormalPosition.bottom - wndpl.rcNormalPosition.top);
			if (FAILED(hr)) break;
		}

		// check for minimized flag
		if (dwFlags & wsFlagMinimized)
		{
			// remember minimized state
			lstrcpy(pszValueName + nNameLength, _T("-Minimized"));
			hr = m_prefs.Write(pszValueName, bMinimized ? 1 : 0);
			if (FAILED(hr)) break;
		}

		// check for maximized flag
		if (dwFlags & wsFlagMaximized)
		{
			// remember maximized state
			lstrcpy(pszValueName + nNameLength, _T("-Maximized"));
			hr = m_prefs.Write(pszValueName, bMaximized ? 1 : 0);
			if (FAILED(hr)) break;
		}
	}
	while (0);

	// free buffer
	delete [] pszValueName;

	// return result
	return hr;
}


template <class TPrefs>
HRESULT CWindowSerializerBase<TPrefs>::Restore(LPCTSTR pszName, HWND hwnd, int nCmdShow) const
{
	// get window placement
	WINDOWPLACEMENT wndpl;
	ZeroMemory(&wndpl, sizeof(wndpl));
	wndpl.length = sizeof(WINDOWPLACEMENT);
	if (!::GetWindowPlacement(hwnd, &wndpl))
		return HRESULT_FROM_WIN32(::GetLastError());

	// allocate buffer for value name
	int nNameLength = lstrlen(pszName);
	TCHAR * pszValueName = new TCHAR [nNameLength + 32];
	lstrcpy(pszValueName, pszName);

	// load placement data
	HRESULT hr = S_OK;
	bool bMinimized = false;
	bool bMaximized = false;
	do
	{
		// preferences value
		LONG nValue = 0;

		// restore flags
		lstrcpy(pszValueName + nNameLength, _T("-Flags"));
		hr = m_prefs.Read(pszValueName, &nValue);
		if (FAILED(hr)) break;
		DWORD dwFlags = nValue;

		// check for point flag
		if (dwFlags & wsFlagPoint)
		{
			// restore left and top coordinates
			lstrcpy(pszValueName + nNameLength, _T("-Left"));
			hr = m_prefs.Read(pszValueName, &nValue);
			if (FAILED(hr)) break;
			wndpl.rcNormalPosition.right += nValue - wndpl.rcNormalPosition.left;
			wndpl.rcNormalPosition.left = nValue;
			lstrcpy(pszValueName + nNameLength, _T("-Top"));
			hr = m_prefs.Read(pszValueName, &nValue);
			if (FAILED(hr)) break;
			wndpl.rcNormalPosition.bottom += nValue - wndpl.rcNormalPosition.top;
			wndpl.rcNormalPosition.top = nValue;
		}
		
		// check for size flag
		if (dwFlags & wsFlagSize)
		{
			// restore width and height
			lstrcpy(pszValueName + nNameLength, _T("-Width"));
			hr = m_prefs.Read(pszValueName, &nValue);
			if (FAILED(hr)) break;
			wndpl.rcNormalPosition.right = wndpl.rcNormalPosition.left + nValue;
			lstrcpy(pszValueName + nNameLength, _T("-Height"));
			hr = m_prefs.Read(pszValueName, &nValue);
			if (FAILED(hr)) break;
			wndpl.rcNormalPosition.bottom = wndpl.rcNormalPosition.top + nValue;
		}

		// check for minimized flag
		if (dwFlags & wsFlagMinimized)
		{
			// restore minimized state
			lstrcpy(pszValueName + nNameLength, _T("-Minimized"));
			hr = m_prefs.Read(pszValueName, &nValue);
			if (FAILED(hr)) break;
			bMinimized = nValue ? true : false;
		}

		// check for maximized flag
		if (dwFlags & wsFlagMaximized)
		{
			// restore maximized state
			lstrcpy(pszValueName + nNameLength, _T("-Maximized"));
			hr = m_prefs.Read(pszValueName, &nValue);
			if (FAILED(hr)) break;
			bMaximized = nValue ? true : false;
		}
	}
	while (0);

	// free buffer
	delete [] pszValueName;

	// ensure success
	if (SUCCEEDED(hr))
	{
		// set minimized/maximized information
		wndpl.showCmd = bMinimized ? SW_SHOWMINNOACTIVE :
			bMaximized ? SW_SHOWMAXIMIZED : SW_SHOWNORMAL;
		wndpl.flags = bMaximized ? WPF_RESTORETOMAXIMIZED : WPF_SETMINPOSITION;
		wndpl.ptMinPosition.x = 0;
		wndpl.ptMinPosition.y = 0;
		wndpl.ptMaxPosition.x = -::GetSystemMetrics(SM_CXBORDER);
		wndpl.ptMaxPosition.y = -::GetSystemMetrics(SM_CYBORDER);

		// check nCmdShow for overrides
		if (nCmdShow == SW_SHOWMINIMIZED || nCmdShow == SW_SHOWMINNOACTIVE || nCmdShow == SW_MINIMIZE)
			wndpl.showCmd = SW_SHOWMINNOACTIVE;
		else if (nCmdShow == SW_SHOWMAXIMIZED || nCmdShow == SW_MAXIMIZE)
			wndpl.showCmd = SW_SHOWMAXIMIZED;

		// set window placement
		if (!::SetWindowPlacement(hwnd, &wndpl))
			hr = HRESULT_FROM_WIN32(::GetLastError());
	}
	
	// return result
	return hr;
}

}   // namespace Attila

#ifndef _ATTILA_NOUSE_NAMESPACE
using namespace Attila;
#endif

#endif  // INC_ATTILAWINDOWSERIALIZER
