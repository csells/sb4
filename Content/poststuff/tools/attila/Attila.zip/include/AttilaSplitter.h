// AttilaSplitter.h
/////////////////////////////////////////////////////////////////////////////
// This is part of the Attila library.
// Copyright (c) 1999, Attila contributors (see ReadMe.htm).
// All rights reserved. No warranties extended.
/////////////////////////////////////////////////////////////////////////////
// History:
//  -11/10/99:
//   Stovin, John [stovinj@genrad.com] fixed a bug in RepositionSplitters
//   that could cause a missing splitter .
//
//  -11/2/99:
//   Dragging splitter outside the window vertically bug fix
//   by Nathaniel Gibbs [NathanGibbs@ADTECHLLC.com].

#pragma once
#ifndef INC_ATTILASPLITTER
#define INC_ATTILASPLITTER

namespace Attila
{

const int nFudgeTop    =6;
const int nFudgeRight  =6;

typedef CWinTraits<	WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS> CSplitterWinTraits;


template < typename TParentView, typename TContainedView, bool bIsVertical = true>
class CSplitterImpl : public CWindowImpl<CSplitterImpl>
{
public:
	//No CS_xREDRAW to avoid flicker
	DECLARE_WND_CLASS_EX(_T("Attila_SplitterBase"), CS_DBLCLKS, COLOR_BTNFACE)
	
	HWND Create(HWND    hWndParent,
			RECT&   rcPos,
			LPCTSTR szWindowName	=	0, 
			DWORD   dwStyle			=	WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS, //These flags will help Erase Bkgnd
			DWORD   dwExStyle		=	0,
			UINT	nID				=	0 
		   )
	{
		
		if (GetWndClassInfo().m_lpszOrigName == NULL)
			GetWndClassInfo().m_lpszOrigName = GetWndClassName();
		ATOM atom = GetWndClassInfo().Register(&m_pfnSuperWindowProc);

		dwStyle = GetWndStyle(dwStyle);
		dwExStyle = GetWndExStyle(dwExStyle);

		return CWindowImpl<CSplitterImpl>::Create(hWndParent,rcPos,szWindowName,dwStyle,dwExStyle,nID);
	}

public:
	CSplitterImpl(TParentView *pView,float fltRatio = 0.5)  :	m_pControllingView(pView),
																m_bAmIBeingDragged(false),
																m_bSelected (false),
																m_hCursor(0),
																m_fltRatio(fltRatio)


	{
		if(bIsVertical)
			m_hCursor = ::LoadCursor(0,IDC_SIZEWE); 
		else
			m_hCursor = ::LoadCursor(0,IDC_SIZENS);
	}

	~CSplitterImpl(){}

public: //msgmap
	BEGIN_MSG_MAP(CSplitterImpl)
		MESSAGE_HANDLER(WM_CREATE, OnCreate)
		MESSAGE_HANDLER(WM_DESTROY, OnDestroy)		
		MESSAGE_HANDLER(WM_PAINT, OnPaint)
		MESSAGE_HANDLER(WM_ERASEBKGND, OnEraseBackground)
			
		MESSAGE_HANDLER(WM_LBUTTONDOWN, OnLBtnDown)
		MESSAGE_HANDLER(WM_MOUSEMOVE, OnMouseMove)
		MESSAGE_HANDLER(WM_LBUTTONUP, OnLBtnUp)
		MESSAGE_HANDLER(WM_SETCURSOR, OnSetCursor)
	END_MSG_MAP()

public:
	LRESULT OnCreate(UINT, WPARAM, LPARAM, BOOL&)
	{
		RECT rc; GetClientRect(&rc);
		m_ContainedView.Create(m_hWnd,rc);
		
		if(m_pControllingView)
		{
			m_pControllingView->GetSiblingWnd(m_wndSibling);
		}

		BringWindowToTop();
		return 0L;
	}

	LRESULT OnDestroy(UINT, WPARAM,LPARAM , BOOL&)
	{
		m_ContainedView.DestroyWindow();
		return 0L;
	}

	LRESULT OnPaint(UINT, WPARAM, LPARAM, BOOL& bHandled)
	{
		RECT rc; GetSplitterRect(&rc);

		PAINTSTRUCT ps;	
		DrawSplitter(BeginPaint(&ps),&rc);

		EndPaint(&ps);
		
		bHandled = FALSE;
		return 0L;
	}

	//Even after this there's a flicker in the children due to 
	//the call to DefWindowProc during the resizing of the outer frame
	//.Will find a cure for this..
	LRESULT OnEraseBackground(UINT, WPARAM wParam, LPARAM, BOOL&)
	{
		DefWindowProc();
		
		RECT rc;GetSplitterRect(&rc);

		DrawSplitter((HDC)wParam,&rc);
				
		return 1;
	}

public://all mouse msgs
	LRESULT OnSetCursor(UINT,WPARAM wParam,LPARAM lParam,BOOL&)
	{
		HWND hWnd = (HWND)wParam;
		if((hWnd == m_hWnd) && (LOWORD(lParam) == HTCLIENT) && !m_bAmIBeingDragged)
		{
			
			// JR - If we are the same window, and the hit test area is our client area,
			//  and we aren't being dragged.  Tell Windows that we processed the
			//  message.  We will really set the cursor in our WM_MOUSEMOVE handler
			//  because we have a point that we can hit test with.
			return TRUE;
		}

		// Otherwise, just let windows set the cursor for us.
		return FALSE;
	}

	LRESULT OnLBtnDown(UINT,WPARAM,LPARAM,BOOL&)
	{
		m_bSelected = true;
		
		//Initialize the Drag Rect each time
		SetRect(&m_rcDrag,0,0,0,0);
		
		//Capture Mr.Mouse :-)
		SetCapture();
		
		return 0L;
	}
	LRESULT OnMouseMove(UINT,WPARAM,LPARAM lParam,BOOL&)
	{
		if(m_bSelected)
		{
			m_bAmIBeingDragged = true;
			CWindow wnd ;  wnd.Attach(GetParent());
			RECT rcWindow; wnd.GetWindowRect(&rcWindow);
			POINTS ptNew = MAKEPOINTS(lParam);

			
			//Paint the DraggingSplitter
			HDC hDC = ::GetDC(0);
			wnd.InvalidateRect(&m_rcDrag);
											
			//erase old	
			EraseDragRect();
			
			if(bIsVertical)
			{
			//NJG - Double check to make sure the the Point was not beyond the Parent's window
				if ( ptNew.x <= 0) 
					SetRect(&m_rcDrag,rcWindow.left, rcWindow.top, rcWindow.left + 3, rcWindow.bottom);
				else if ( (ptNew.x > 0 ) && ( (ptNew.x + rcWindow.left + 3) < rcWindow.right ) )
					SetRect(&m_rcDrag,rcWindow.left + ptNew.x ,rcWindow.top,rcWindow.left + ptNew.x + 3,rcWindow.bottom);
				else
					SetRect(&m_rcDrag,rcWindow.right - 6, rcWindow.top, rcWindow.right -3, rcWindow.bottom);

			}
			else
			{
			//NJG - Double check to make sure the the Point was not beyond the Parent's window
				if ( ptNew.y <= 0 )
					SetRect(&m_rcDrag, rcWindow.left, rcWindow.top, rcWindow.right, rcWindow.top + 3);
				else if ( (ptNew.y > 0 ) && ( (ptNew.y + rcWindow.top + 3) < ( rcWindow.bottom ) ) )
					SetRect(&m_rcDrag,rcWindow.left, rcWindow.top + ptNew.y ,rcWindow.right ,rcWindow.top + ptNew.y + 3);
				else
					SetRect(&m_rcDrag, rcWindow.left, rcWindow.bottom -3, rcWindow.right, rcWindow.bottom );

			}

			//paint new
			PatBlt(hDC, m_rcDrag.left, m_rcDrag.top, m_rcDrag.right - m_rcDrag.left, m_rcDrag.bottom -m_rcDrag.top,PATINVERT);
						
			::ReleaseDC(0,hDC);
			wnd.Detach();
		}
		else
		{
			// JR - We set the cursor here so that we don't get flicker when the mouse is
			//  over the contained view.
			RECT splitRect;
			GetSplitterRect(&splitRect);

			POINT p; 
			p.x = LOWORD(lParam); 
			p.y = HIWORD(lParam);

			if(PtInRect(&splitRect,p))
				SetCursor(m_hCursor);
		}
		return 0L;
	}

	LRESULT OnLBtnUp(UINT,WPARAM,LPARAM lParam,BOOL&)
	{
		m_bSelected = false;
		if(!m_bAmIBeingDragged)
		{
			//This means that he's just clicking on the splitter without moving(what a waste of time)
			ReleaseCapture();
			return 0L;
		}
		
		m_bAmIBeingDragged	= false;
		CWindow wnd;wnd.Attach(GetParent());
		
		EraseDragRect();

		RECT rcViewOne; GetClientRect(&rcViewOne);
		RECT rcParent;  wnd.GetClientRect(&rcParent);

		RECT rcSibling;
		
		POINTS ptNew = MAKEPOINTS(lParam);
		// JR - Because of a fix for the cursor flicker, when we stop dragging the cursor
		//  is a few pixels beneath or beside the splitter bar.  So if we drag then stop.  
		//  the cursor would have to be moved to the left or up to get the drag cursor
		//  back.  After watching a couple of other splitters, most have a jump right at the
		//  end of dragging.  This signifies to me that they have the same problem :)
		//  So to fix it, we just fudge the right and the bottom of the rects before 
		//  setting them.
		if(bIsVertical)
		{
			//NJG - Double check to make sure the the Point was not beyond the Parent's window
			if ( ptNew.x <= 0 )
				rcViewOne.right = nFudgeRight;
			else if ( ptNew.x < (rcParent.right - nFudgeRight) )
				rcViewOne.right = ptNew.x + nFudgeRight;
			else
				rcViewOne.right = rcParent.right;
			
			SetRect(&rcSibling,rcViewOne.right,rcViewOne.top,rcParent.right,rcViewOne.bottom);

		}
		else
		{
			//NJG - Double check to make sure the the Point was not beyond the Parent's window
			if ( ptNew.y <= 0 )
				rcViewOne.bottom = nFudgeTop;
			else if ( ptNew.y < ( rcParent.bottom - nFudgeTop ) )
				rcViewOne.bottom = ptNew.y + nFudgeTop;
			else
				rcViewOne.bottom = rcParent.bottom;
			SetRect(&rcSibling,rcViewOne.left,rcViewOne.bottom,rcViewOne.right,rcParent.bottom);
		}
		
		ResizeViews(&rcViewOne, &rcSibling);	
				
		ReleaseCapture();

		wnd.Detach();
		return 0L;
	}

public://helpers
	LRESULT RepositionSplitters(LPRECT lprc) 
	{
		if(!lprc){ return -1; }
        if (::IsRectEmpty(lprc)) return 0L;
		RECT rcView1, rcView2;

		//Initialize rects
		SetRect(&m_rcParent,lprc->left,lprc->top,lprc->right,lprc->bottom);
		SetRect(&rcView1,lprc->left,lprc->top,lprc->right,lprc->bottom);
		SetRect(&rcView2,lprc->left,lprc->top,lprc->right,lprc->bottom);

		if(bIsVertical)
		{
			int nWidth = (m_rcParent.right- m_rcParent.left);
			rcView1.right  = rcView1.left + (int)(nWidth * m_fltRatio);
			rcView2.left   = rcView1.right;
			ResizeViews(&rcView1, &rcView2,SWP_NOZORDER|SWP_NOACTIVATE|SWP_DEFERERASE|SWP_NOSENDCHANGING);
		}
		else
		{
			int nHeight = (m_rcParent.bottom - m_rcParent.top);
			rcView1.bottom  = rcView1.top + (int)(nHeight * m_fltRatio);
			rcView2.top   = rcView1.bottom;
			ResizeViews(&rcView1, &rcView2,SWP_NOZORDER|SWP_NOACTIVATE|SWP_DEFERERASE|SWP_NOSENDCHANGING);
		}

		return 0L;
	}
	
public:
	float			GetAspectRatio() const		{ return m_fltRatio; }
	TContainedView*	GetContainedView()  		{ return &m_ContainedView; }
private:
	LRESULT DrawSplitter(HDC hDC,LPRECT lprc) const
	{
		::DrawEdge(hDC,lprc,EDGE_RAISED,BF_RECT|BF_TOPRIGHT|BF_ADJUST);
		return 0L;
	}
	
	LRESULT EraseDragRect()
	{
		HDC hDC = ::GetDC(0);
		
		PatBlt(hDC, m_rcDrag.left, m_rcDrag.top, m_rcDrag.right - m_rcDrag.left, m_rcDrag.bottom -m_rcDrag.top,PATINVERT);
		
		::ReleaseDC(0,hDC);
		return 0L;
	}

	LRESULT GetSplitterRect(LPRECT lprc)
	{
		GetClientRect(lprc);

		if(bIsVertical)
		{
			lprc->left = lprc->right - nFudgeRight - 2;
		}
		else
		{
			lprc->top = lprc->bottom - nFudgeTop -3;
		}

		return 0L;
	}

	LRESULT ResizeViews(LPRECT lprcViewOne, LPRECT lprcViewTwo, DWORD dwRedrawFlags = SWP_NOZORDER)
	{
		SetWindowPos(HWND_TOP,lprcViewOne,SWP_NOZORDER);

		int nView1Width = (lprcViewOne->right - lprcViewOne->left);
		int nView1Height = lprcViewOne->bottom - lprcViewOne->top;
		int nParentWidth = (m_rcParent.right -m_rcParent.left);
		int nParentHeight = (m_rcParent.bottom -m_rcParent.top);

		if(bIsVertical)
		{
			m_ContainedView.SetWindowPos(	0,	
											lprcViewOne->left,lprcViewOne->top,
											(nView1Width - nFudgeRight - 1),
											nView1Height,
											dwRedrawFlags
										);
			
			m_fltRatio = (float)(nView1Width)/ (float)(nParentWidth) ;
	
		}
		else
		{
			m_ContainedView.SetWindowPos(	0,	
											lprcViewOne->left,lprcViewOne->top,
											nView1Width,
											(nView1Height - nFudgeTop - 3),//1 ,
											dwRedrawFlags
										);
			m_fltRatio = (float)(nView1Height)/ (float)(nParentHeight) ;
				
		}
		
		m_wndSibling.SetWindowPos(NULL,lprcViewTwo,dwRedrawFlags);

		return 0L;
	}

private: 
	TParentView		*m_pControllingView;
	TContainedView	 m_ContainedView; 
	CWindow			 m_wndSibling;
	bool			 m_bAmIBeingDragged;
	bool			 m_bSelected ;	
	HCURSOR			 m_hCursor;
	RECT			 m_rcDrag;
	RECT			 m_rcParent;
	float			 m_fltRatio;
};

}   // namespace Attila

#ifndef _ATTILA_NOUSE_NAMESPACE
using namespace Attila;
#endif

#endif  // INC_ATTILASPLITTER
