// AttilaCommon.h
/////////////////////////////////////////////////////////////////////////////
// This is part of the Attila library.
// Copyright (c) 1999, Attila contributors (see ReadMe.htm).
// All rights reserved. No warranties extended.
/////////////////////////////////////////////////////////////////////////////

#pragma once
#ifndef INC_ATTILACOMMON
#define INC_ATTILACOMMON

#include "atlwin.h"
#include "commctrl.h"
#include "AttilaControls.H"
#include "AttilaRes.h"
#include "AttilaWrappers.h"

// Compile-time assert
#ifndef CTASSERT
#ifdef _DEBUG
#define CTASSERT(_ex) { int _rg[_ex ? 1 : -1]; _rg; }
#else   // !_DEBUG
#define CTASSERT(_ex)
#endif  // _DEBUG
#endif  // !CTASSERT

#ifdef _DEBUG
#define ATLVERIFY(_ex) ATLASSERT(_ex)
#else
#define ATLVERIFY(_ex) ((void)(_ex))
#endif

#ifndef HR
#define HR(_ex) { HRESULT _hr = _ex; if( FAILED(_hr) ) return _hr; }
#endif

namespace Attila
{

/////////////////////////////////////////////////////////////////////////////
// Traits

typedef CWinTraits<	WS_CLIPCHILDREN		| 
					WS_CLIPSIBLINGS		|
					WS_CHILD			|
					WS_VISIBLE, 
					WS_EX_STATICEDGE>		CViewWinTraits;

typedef CWinTraits<	WS_CHILD | 
					WS_VISIBLE | 
					WS_CLIPCHILDREN | 
					WS_CLIPSIBLINGS | 
					TBSTYLE_TOOLTIPS|
					TBSTYLE_FLAT|
					CCS_NORESIZE|
					CCS_NOMOVEY|
					CCS_NODIVIDER|
					CCS_TOP,0> CToolBarWinTraits;

typedef CWinTraits<	WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | 
					WS_CLIPSIBLINGS | SBARS_SIZEGRIP> CStatusBarWinTraits;

typedef CWinTraits<	WS_CLIPCHILDREN		| 
					WS_CLIPSIBLINGS		|
					WS_CHILD			|
					WS_BORDER			|
					WS_VISIBLE, 
					WS_EX_CLIENTEDGE>	CInofBarWinTraits;

typedef CWinTraits<	WS_CHILD			| 
					WS_VISIBLE			| 
					WS_CLIPCHILDREN		|	 
					WS_CLIPSIBLINGS		| 
					TBSTYLE_FLAT		|
					TBSTYLE_TRANSPARENT	|
					CCS_NORESIZE		| // TODO: ???
					CCS_NOMOVEY			|
					CCS_NODIVIDER		|
					CCS_NOPARENTALIGN,0> CMenuBarTraits;

typedef CFrameWinTraits CMdiFrameWinTraits;

/////////////////////////////////////////////////////////////////////////////
// Custom messages

const UINT WM_CREATE_NEW_APPFRAME   = WM_APP + 100;
const UINT WM_APPFRAME_SHUTING_DOWN = WM_APP + 101;

// WM_CMDUI -- The Attila equivalent of an MFC COMMAND_UI notification message.
//		wParam - command Id
//		lparam - CCmdUI*
//		retval - unused

const UINT WM_CMDUI					= WM_APP + 102;	// JMO: added for CMDUI

// WM_IDLECMDUI -- The Attila equivalent of WM_IDLEUPDATECMDUI in MFC
//		wParam - unused
//		lparam - unused
//		retval - unused

const UINT WM_IDLECMDUI				= WM_APP + 103;	// JMO: added for CMDUI

// WM_SBGETPANECMDID -- Gets the command ID (if any) of a status bar pane
//		wParam - zero-based index of the pane whose command Id is to be retrieved
//		lParam - unused
//		retval - the COMMAND ID of the pane (or zero if it had no ID)

const UINT WM_SBGETPANECMDID		= WM_APP + 104;	// JMO: added for CMDUI

// WM_SBGETPANESTYLE -- Gets the Attila status bar style (ASBT_xxx ) of a status bar pane
//		wParam - zero-based index of the pane whose command Id is to be retrieved
//		lParam - unused
//		retval - the bitmask of styles of the pane

const UINT WM_SBGETPANESTYLE		= WM_APP + 105;

// WM_SBSETPANESTYLE -- Sets the Attila status bar style (ASBT_xxx ) of a status bar pane
//		wParam - zero-based index of the pane whose command Id is to be retrieved
//		lParam - unused
//		retval - the bitmask of styles of the pane

const UINT WM_SBSETPANESTYLE		= WM_APP + 106;


/////////////////////////////////////////////////////////////////////////////
// Macros

#define MOUSE_X(l) ((short)(l))
#define MOUSE_Y(l) ((short)(((DWORD)(l) >> 16) & 0xFFFF))

#if (_WIN32_IE >= 0x0400)
#define ICC_ALL 0x2FFF
#else
#define ICC_ALL 0x4FF
#endif

/////////////////////////////////////////////////////////////////////////////
/*template <DWORD t_dwClasses = ICC_WIN95_CLASSES,bool t_bRichEdit = false>
struct CAutoCommonCtrlsInit
{
	CAutoCommonCtrlsInit():m_hInstRichEdit(0)
	{

		INITCOMMONCONTROLSEX icex;
		icex.dwSize  = sizeof(INITCOMMONCONTROLSEX);
		icex.dwICC   =  t_dwClasses;
		::InitCommonControlsEx(&icex);

		if(t_bRichEdit)
			m_hInstRichEdit = ::LoadLibrary(_T("RICHED32.DLL"));
	}
	
	~CAutoCommonCtrlsInit()
	{
		if(t_bRichEdit && m_hInstRichEdit)
			::FreeLibrary(m_hInstRichEdit);m_hInstRichEdit = 0;
	}
private:
	HINSTANCE m_hInstRichEdit; 
};

typedef CAutoCommonCtrlsInit<	ICC_COOL_CLASSES		|
								ICC_BAR_CLASSES			|
								ICC_TAB_CLASSES			|
								ICC_WIN95_CLASSES		|
								ICC_LISTVIEW_CLASSES	|
								ICC_TREEVIEW_CLASSES,false> CAutoCommCtrlsInit_Std;

typedef CAutoCommonCtrlsInit<	ICC_COOL_CLASSES		|
								ICC_BAR_CLASSES			|
								ICC_TAB_CLASSES			|
								ICC_WIN95_CLASSES		|
								ICC_LISTVIEW_CLASSES	|
								ICC_TREEVIEW_CLASSES,true> CAutoCommCtrlsInit_StdWithRichEdit;

typedef CAutoCommonCtrlsInit<	ICC_COOL_CLASSES		|
								ICC_BAR_CLASSES			|
								ICC_TAB_CLASSES			|
								ICC_WIN95_CLASSES		|
								ICC_LISTVIEW_CLASSES	|
								ICC_TREEVIEW_CLASSES	|
								ICC_PAGESCROLLER_CLASS	|
								ICC_INTERNET_CLASSES	| 
								ICC_DATE_CLASSES		|
								ICC_ANIMATE_CLASS		| 
								ICC_UPDOWN_CLASS		|
								ICC_USEREX_CLASSES		|
								ICC_HOTKEY_CLASS,true> CAutoCommCtrlsInit_All;
*/

}   // namespace Attila

#ifndef _ATTILA_NOUSE_NAMESPACE
using namespace Attila;
#endif

#endif  // INC_ATTILACOMMON
