// AttilaGdi.h
/////////////////////////////////////////////////////////////////////////////
// This is part of the Attila library.
// Copyright (c) 1999, Attila contributors (see ReadMe.htm).
// All rights reserved. No warranties extended.
/////////////////////////////////////////////////////////////////////////////
// History:
//  -11/22/99:
//   John Stovin [stovinj@genrad.com] did some work on the GDI class hierarchy.
//
//  -11/19/99:
//   Brad Wilson [bradw@pobox.com] added TextOut and SelectClipRgn to CGdiDC.
//
//  -11/18/99:
//   Dropped usage of COLORMAP unless commctrl.h was included.
//
//  -11/10/99:
//   Chris Sells [csells@develop.com] removed CGdiRectangle in favor of
//   CRect in AttilaWrappers.h.

#ifndef __ATTILAGDI_H__
#define __ATTILAGDI_H__

namespace Attila
{

// Disallows object assignment and copying...
#define ATTILA_DECLARE_NO_COPY( T ) \
private:\
	T(const T&);\
	T& operator=(const T&);
// John Stovin 22/11/99 
// Disallows object assignment only
#define ATTILA_DECLARE_NO_ASSIGN( T ) \
private:\
	T& operator=(const T&);
// John Stovin 22/11/99 - end

/**
 * Basic behavior of GDI objects.
 * 
 * @param T derived class.`T should provide
 * a method for freeing up the allocated resources:
 * void Free();
 *
 * @author Rodrigo B. de Oliveira
 */
template <typename T, typename THandle>
class CGdiObjectBase
{
	ATTILA_DECLARE_NO_COPY(CGdiObjectBase)

protected:
	typedef CGdiObjectBase<T, THandle> _GdiBase;	

	THandle m_hObj; // the GDI handle	
	
	CGdiObjectBase() : m_hObj(0)
	{
	}

	CGdiObjectBase(THandle hObj) : m_hObj(hObj)
	{
	}

	void InternalSetHandle(THandle hObj)
	{		
		m_hObj = hObj;
	}

public:
	THandle GetHandle() const
	{
		return m_hObj;
	}

	void Attach(THandle hObj)
	{		
		static_cast<T*>(this)->Free();
		m_hObj = hObj;
	}	

	THandle Detach()
	{
		THandle hRetValue = m_hObj;
		m_hObj = 0;
		return hRetValue;
	}

	void Release()
	{
		static_cast<T*>(this)->Free();
		m_hObj = 0;
	}

	BOOL IsValid() const
	{
		return 0 != m_hObj;
	}
	
	operator THandle() const
	{
		return m_hObj;
	}

	BOOL operator!() const
	{
		return 0 == m_hObj;
	}

	// GDI polimorfic functions...
	int GetObjectType() const
	{
		return ::GetObjectType(m_hObj);
	}
};

/**
 * Base class for GDI objects like PEN, BRUSH, BITMAPs
 * whose destruction protocol is ::DeleteObject.
 *
 * @author Rodrigo B. de Oliveira
 *
 */

template <typename T, typename THandle>
class CGdiObject : public CGdiObjectBase<T, THandle>
{
protected:
	CGdiObject()
	{
	}

	CGdiObject(THandle h) : CGdiObjectBase<T, THandle>(h)
	{
	}

public:
	explicit CGdiObject(int nStockObject)
		: CGdiObjectBase<T, THandle>(static_cast<THandle>(::GetStockObject(nStockObject)))
	{
		ATLASSERT( IsValid() );
	}

	~CGdiObject()
	{
		if (IsValid())
			static_cast<T*>(this)->Free();
	}

	void GetStockObject(int nStockObject)
	{
		Attach( static_cast<THandle>(::GetStockObject(nStockObject)) );
	}

	void Free()
	{
		::DeleteObject(GetHandle());
	}
};



/**
 * HBRUSH Wrapper class.
 *
 * @author Rodrigo B. de Oliveira
 *
 */

class CGdiBrush : public CGdiObject<CGdiBrush, HBRUSH>
{
public:
	CGdiBrush()
	{
	}

	explicit CGdiBrush(HBRUSH hBrush)
		: CGdiObject<CGdiBrush, HBRUSH>(hBrush)
	{
	}

	explicit CGdiBrush(int nStockObject)
		: CGdiObject<CGdiBrush, HBRUSH>(nStockObject)
	{
		ATLASSERT( IsValid() );
	}	

	explicit CGdiBrush(const LOGBRUSH* lplb)
		: CGdiObject<CGdiBrush, HBRUSH>( ::CreateBrushIndirect(lplb) )
	{
		ATLASSERT( IsValid() );
	}

	CGdiBrush(const void* lpPackedDIB, UINT iUsage)
		: CGdiObject<CGdiBrush, HBRUSH>( ::CreateDIBPatternBrushPt(lpPackedDIB, iUsage) )
	{
		ATLASSERT( IsValid() );
	}

	CGdiBrush(int fnStyle, COLORREF color)
		: CGdiObject<CGdiBrush, HBRUSH>( ::CreateHatchBrush(fnStyle, color) )
	{
		ATLASSERT( IsValid() );
	}

	explicit CGdiBrush(COLORREF color)
		: CGdiObject<CGdiBrush, HBRUSH>( ::CreateSolidBrush(color) )
	{
		ATLASSERT( IsValid() );
	}

	explicit CGdiBrush(HBITMAP hBitmap)
		: CGdiObject<CGdiBrush, HBRUSH>( ::CreatePatternBrush(hBitmap) )
	{
		ATLASSERT( IsValid() );
	}
	
	BOOL GetSysColorBrush(int nIndex)
	{
		Attach( ::GetSysColorBrush(nIndex) );
		return IsValid();
	}

	BOOL CreateSolidBrush(COLORREF color)
	{
		Attach( ::CreateSolidBrush(color) );
		return IsValid();
	}

	BOOL CreateBrushIndirect(const LOGBRUSH* lplb)
	{
		Attach( ::CreateBrushIndirect(lplb) );
		return IsValid();
	}

	BOOL CreateHatchBrush(int fnStyle, COLORREF color)
	{
		Attach( ::CreateHatchBrush(fnStyle, color) );
		return IsValid();
	}

	BOOL CreatePatternBrush(HBITMAP hBitmap)
	{
		Attach( ::CreatePatternBrush(hBitmap) );
		return IsValid();
	}
	
	BOOL CreateDIBPatternBrushPt(const void* lpPackedDIB, UINT iUsage)
	{
		Attach( ::CreateDIBPatternBrushPt(lpPackedDIB, iUsage) );
		return IsValid();
	}

	// Creates a brush from a 8x8 bitmapped pattern.	
	BOOL CreatePatternBrush(const unsigned char bits[])
	{
		ATLASSERT( !::IsBadReadPtr(bits, 8) );

		BOOL bRetValue = FALSE;

		HBITMAP hBitmap = ::CreateBitmap(8, 8, 1, 1, bits);
		if (hBitmap)
		{
			bRetValue = CreatePatternBrush(hBitmap);
			::DeleteObject(hBitmap);
		}

		return bRetValue;
	}	
};


/**
 * HPEN Wrapper class.
 *
 * @author Rodrigo B. de Oliveira
 *
 */

class CGdiPen : public CGdiObject<CGdiPen, HPEN>
{
	ATTILA_DECLARE_NO_COPY(CGdiPen)

public:
	CGdiPen()
	{
	}

	explicit CGdiPen(const COLORREF& color, int nPenWidth = 1, int nPenStyle = PS_SOLID)
		: CGdiObject<CGdiPen, HPEN>( ::CreatePen(nPenStyle, nPenWidth, color) )
	{
		ATLASSERT( IsValid() );
	}

	explicit CGdiPen(int nStockObject)
		: CGdiObject<CGdiPen, HPEN>(nStockObject)
	{
	}

	explicit CGdiPen(HPEN hPen)
		: CGdiObject<CGdiPen, HPEN>(hPen)
	{
	}

	BOOL CreatePen(COLORREF crColor, int nWidth = 1, int nPenStyle = PS_SOLID)
	{
		Attach( ::CreatePen(nPenStyle, nWidth, crColor) );
		return 0 != GetHandle();
	}	

	BOOL CreatePenIndirect(CONST LOGPEN* lplgpn)
	{
		Attach( ::CreatePenIndirect(lplgpn) );
		return 0 != GetHandle();
	}

	BOOL ExtCreatePen(DWORD dwPenStyle, DWORD dwWidth, CONST LOGBRUSH* lplb,
		DWORD dwStyleCount = 0, CONST DWORD* lpStyle = 0)
	{
		Attach( ::ExtCreatePen(dwPenStyle, dwWidth, lplb, dwStyleCount, lpStyle) );
		return 0 != GetHandle();
	}
};


/**
 * HFONT Wrapper class.
 *
 * @author Rodrigo B. de Oliveira
 *
 */

class CGdiFont : public CGdiObject<CGdiFont, HFONT>
{
public:
	static int PointSizeToDeviceSize(HDC hdc, int PointSize)
	{
		return -::MulDiv(PointSize, ::GetDeviceCaps(hdc, LOGPIXELSY), 72);
	}

	CGdiFont()
	{
	}

	CGdiFont(HFONT hFont)
		: CGdiObject<CGdiFont, HFONT>(hFont)
	{
	}

	CGdiFont(LPCTSTR lpszFace, int nHeight = 0,
		int fnWeight = FW_DONTCARE,		
		DWORD fdwItalic = FALSE,
		DWORD fdwUnderline = FALSE,
		DWORD fdwStrikeOut = FALSE,
		int nWidth = 0,
		int nEscapement = 0, int nOrientation = 0, 
		DWORD fdwCharSet = DEFAULT_CHARSET,
		DWORD fdwOutputPrecision = OUT_DEFAULT_PRECIS,
		DWORD fdwClipPrecision = CLIP_DEFAULT_PRECIS,
		DWORD fdwQuality = DEFAULT_QUALITY,
		DWORD fdwPitchAndFamily = DEFAULT_PITCH | FF_DONTCARE)
	{
		InternalSetHandle( ::CreateFont(nHeight, nWidth, nEscapement, nOrientation,
			fnWeight, fdwItalic, fdwUnderline, fdwStrikeOut,
			fdwCharSet, fdwOutputPrecision, fdwClipPrecision,
			fdwQuality, fdwPitchAndFamily, lpszFace) );

		ATLASSERT( IsValid() );
	}

	CGdiFont(HDC hdc, LPCTSTR lpszFace, int nPointHeight = 0,
		int fnWeight = FW_DONTCARE,
		DWORD fdwItalic = FALSE,
		DWORD fdwUnderline = FALSE,
		DWORD fdwStrikeOut = FALSE,
		int nWidth = 0,
		int nEscapement = 0, int nOrientation = 0, 
		DWORD fdwCharSet = DEFAULT_CHARSET,
		DWORD fdwOutputPrecision = OUT_DEFAULT_PRECIS,
		DWORD fdwClipPrecision = CLIP_DEFAULT_PRECIS,
		DWORD fdwQuality = DEFAULT_QUALITY,
		DWORD fdwPitchAndFamily = DEFAULT_PITCH | FF_DONTCARE)
	{
		InternalSetHandle( ::CreateFont(PointSizeToDeviceSize(hdc, nPointHeight), nWidth, nEscapement, nOrientation,
			fnWeight, fdwItalic, fdwUnderline, fdwStrikeOut,
			fdwCharSet, fdwOutputPrecision, fdwClipPrecision,
			fdwQuality, fdwPitchAndFamily, lpszFace) );		

		ATLASSERT( IsValid() );
	}

	explicit CGdiFont(const LOGFONT* lplf)
		: CGdiObject<CGdiFont, HFONT>( ::CreateFontIndirect(lplf) )
	{
		ATLASSERT( IsValid() );
	}

	BOOL CreateFont(LPCTSTR lpszFace, int nHeight = 0,
		int fnWeight = FW_DONTCARE,		
		DWORD fdwItalic = FALSE,
		DWORD fdwUnderline = FALSE,
		DWORD fdwStrikeOut = FALSE,
		int nWidth = 0,
		int nEscapement = 0, int nOrientation = 0, 
		DWORD fdwCharSet = DEFAULT_CHARSET,
		DWORD fdwOutputPrecision = OUT_DEFAULT_PRECIS,
		DWORD fdwClipPrecision = CLIP_DEFAULT_PRECIS,
		DWORD fdwQuality = DEFAULT_QUALITY,
		DWORD fdwPitchAndFamily = DEFAULT_PITCH | FF_DONTCARE)
	{
		Attach( ::CreateFont(nHeight, nWidth, nEscapement, nOrientation,
			fnWeight, fdwItalic, fdwUnderline, fdwStrikeOut,
			fdwCharSet, fdwOutputPrecision, fdwClipPrecision,
			fdwQuality, fdwPitchAndFamily, lpszFace) );

		return IsValid(); 
	}

	BOOL CreateFont(HDC hdc, LPCTSTR lpszFace, int nPointHeight = 0,
		int fnWeight = FW_DONTCARE,
		DWORD fdwItalic = FALSE,
		DWORD fdwUnderline = FALSE,
		DWORD fdwStrikeOut = FALSE,
		int nWidth = 0,
		int nEscapement = 0, int nOrientation = 0, 
		DWORD fdwCharSet = DEFAULT_CHARSET,
		DWORD fdwOutputPrecision = OUT_DEFAULT_PRECIS,
		DWORD fdwClipPrecision = CLIP_DEFAULT_PRECIS,
		DWORD fdwQuality = DEFAULT_QUALITY,
		DWORD fdwPitchAndFamily = DEFAULT_PITCH | FF_DONTCARE)
	{
		Attach( ::CreateFont(PointSizeToDeviceSize(hdc, nPointHeight), nWidth, nEscapement, nOrientation,
			fnWeight, fdwItalic, fdwUnderline, fdwStrikeOut,
			fdwCharSet, fdwOutputPrecision, fdwClipPrecision,
			fdwQuality, fdwPitchAndFamily, lpszFace) );

		return IsValid();
	}
};




/**
 * HRGN Wrapper class.
 *
 * @author Jim Murphy
 */

class CGdiRegion : public CGdiObjectBase<CGdiRegion, HRGN>
{
	ATTILA_DECLARE_NO_COPY(CGdiRegion)

public:
	CGdiRegion()
	{
	}
	CGdiRegion(HRGN hrgn) : _GdiBase(hrgn)
	{
	}
	explicit CGdiRegion(int x1, int y1, int x2, int y2)
	{
		Attach(::CreateRectRgn(x1, y1, x2, y2));
	}
	virtual ~CGdiRegion()
	{
	}
	BOOL CreateRectRgn(int x1, int y1, int x2, int y2)
	{
		Attach(::CreateRectRgn(x1, y1, x2, y2));
		return 0 != GetHandle();
	}
	BOOL CreateRectRgn(RECT& rRect)
	{
		Attach(::CreateRectRgnIndirect(&rRect));
		return 0 != GetHandle();
	}
	BOOL CreateEllipticRgn(int x1, int y1, int x2, int y2)
	{
		Attach(::CreateEllipticRgn(x1, y1, x2, y2));
		return 0 != GetHandle();
	}
	BOOL CreateEllipticRgn(RECT& rRect)
	{
		Attach(::CreateEllipticRgnIndirect(&rRect));
		return 0 != GetHandle();
	}
	BOOL CreatePolygonRgn(LPPOINT lpPoints, int nCount, int nMode)
	{
		Attach(::CreatePolygonRgn(lpPoints, nCount, nMode));
		return 0 != GetHandle();
	}
	BOOL CreatePolyPolygonRgn(LPPOINT lpPoints, LPINT lpPolyCounts, int nCount, int nPolyFillMode)
	{
		Attach(::CreatePolyPolygonRgn(lpPoints, lpPolyCounts, nCount, nPolyFillMode));
		return 0 != GetHandle();
	}
	BOOL CreateRoundRectRgn(int x1, int y1, int x2, int y2, int x3, int y3)
	{
		Attach(::CreateRoundRectRgn(x1, y1, x2, y2, x3, y3));
		return 0 != GetHandle();
	}
	BOOL CreateFromPath(HDC hdc)
	{
		ATLASSERT(hdc != NULL);
		Attach(::PathToRegion(hdc));
		return 0 != GetHandle();
	}
	BOOL CreateFromData(const XFORM* lpXForm, int nCount, const RGNDATA* pRgnData)
	{
		Attach(::ExtCreateRegion(lpXForm, nCount, pRgnData));
		return 0 != GetHandle();
	}
	void SetRectRgn(int x1, int y1, int x2, int y2)
	{
		ATLASSERT(GetHandle() != NULL);
		::SetRectRgn(GetHandle(), x1, y1, x2, y2);
	}
	void SetRectRgn(LPCRECT lpRect)
	{
		ATLASSERT(GetHandle() != NULL);
		::SetRectRgn(GetHandle(), lpRect->left, lpRect->top, lpRect->right, lpRect->bottom);
	}
	int CombineRgn(CGdiRegion* rgn1, CGdiRegion* rgn2, int mode)
	{
		ATLASSERT(GetHandle());
		return ::CombineRgn(GetHandle(), rgn1->GetHandle(), rgn2->GetHandle(), mode);
	}
	int CopyRgn(CGdiRegion* rgn)
	{
		ATLASSERT(rgn);
		return ::CombineRgn(GetHandle(), rgn->GetHandle(), NULL, RGN_COPY);
	}
	int OffsetRgn(int x, int y)
	{
		ATLASSERT(GetHandle());
		return ::OffsetRgn(GetHandle(), x, y);
	}
	int OffsetRgn(const POINT & point)
	{
		ATLASSERT(GetHandle());
		return ::OffsetRgn(GetHandle(), point.x, point.y);
	}
	int GetRgnBox(LPRECT lpRect) const
	{
		ATLASSERT(GetHandle() != NULL);
		return ::GetRgnBox(GetHandle(), lpRect); 
	}
	BOOL PtInRegion(int x, int y) const
	{
		ATLASSERT(GetHandle() != NULL);
		return ::PtInRegion(GetHandle(), x, y);
	}
	BOOL PtInRegion(const POINT & point) const
	{
		ATLASSERT(GetHandle() != NULL);
		return ::PtInRegion(GetHandle(), point.x, point.y);
	}
	BOOL RectInRegion(LPCRECT lpRect) const
	{
		ATLASSERT(GetHandle() != NULL);
		return ::RectInRegion(GetHandle(), lpRect);
	}
	int GetRegionData(LPRGNDATA data, int count) const
	{
		ATLASSERT(GetHandle() != NULL);
		return static_cast<int>(::GetRegionData(GetHandle(), count, data));
	}

	// operators

	bool operator==(HRGN rhs)
	{
		ATLASSERT(GetHandle());
		return ::EqualRgn(GetHandle(), rhs) == TRUE;
	}
	bool operator!=(HRGN rhs)
	{
		return *this==(rhs);
	}
	HRGN operator+=(const POINT & point)
	{
		OffsetRgn(point);
		return GetHandle();
	}
	HRGN operator-=(const POINT & point)
	{
		POINT pt;
		pt.x = -point.x;
		pt.y = -point.y;
		OffsetRgn(pt);
		return GetHandle();
	}

	void Free()
	{
		::DeleteObject(GetHandle());
	}

};

inline HRGN operator+(CGdiRegion& r1, CGdiRegion& r2)
{
	ATLASSERT(r1);
	ATLASSERT(r2);
	CGdiRegion r3(0, 0, 0, 0);
	::CombineRgn(r3, r1, r2, RGN_OR);
	return r3;
}

inline HRGN operator|(CGdiRegion& r1, CGdiRegion& r2)
{
	return operator+(r1, r2);
}

inline HRGN operator-(CGdiRegion& r1, CGdiRegion& r2)
{
	ATLASSERT(r1);
	ATLASSERT(r2);
	CGdiRegion r3(0, 0, 0, 0);
	::CombineRgn(r3, r1, r2, RGN_DIFF);
	return r3;
}

inline HRGN operator&(CGdiRegion& r1, CGdiRegion& r2)
{
	ATLASSERT(r1);
	ATLASSERT(r2);
	CGdiRegion r3(0, 0, 0, 0);
	::CombineRgn(r3, r1, r2, RGN_AND);
	return r3;
}

inline HRGN operator^(CGdiRegion& r1, CGdiRegion& r2)
{
	ATLASSERT(r1);
	ATLASSERT(r2);
	CGdiRegion r3(0, 0, 0, 0);
	::CombineRgn(r3, r1, r2, RGN_XOR);
	return r3;
}



/**
 * HBITMAP Wrapper class.
 *
 * @author Jim Murphy
 */

class CGdiBitmap : public CGdiObject<CGdiBitmap, HBITMAP>
{
	ATTILA_DECLARE_NO_COPY(CGdiBitmap)

public:

	CGdiBitmap()
	{
	}

	CGdiBitmap(HDC hdc, int nWidth, int nHeight)	: 
		CGdiObject<CGdiBitmap, HBITMAP>( ::CreateCompatibleBitmap(hdc, nWidth, nHeight) )
	{
		ATLASSERT( IsValid() );
	}

	virtual ~CGdiBitmap()
	{
	}

	BOOL LoadBitmap(LPCTSTR lpszResourceName, HINSTANCE hinst = 0)
	{ 
		if (hinst == 0)
			hinst = _Module.GetModuleInstance();

		Attach(::LoadBitmap(hinst, lpszResourceName));
		return 0 != GetHandle();
	}
	BOOL LoadBitmap(UINT nIDResource, HINSTANCE hinst = 0)
	{ 
		if (hinst == 0)
			hinst = _Module.GetModuleInstance();

		Attach(::LoadBitmap(hinst, MAKEINTRESOURCE(nIDResource))); 
		return 0 != GetHandle();
	}
	
	BOOL LoadOEMBitmap(UINT nIDBitmap)
	{ 
		Attach(::LoadBitmap(NULL, MAKEINTRESOURCE(nIDBitmap))); 
		return 0 != GetHandle();
	}

#ifdef _INC_COMMCTRL
	BOOL LoadMappedBitmap(UINT nIDBitmap, HINSTANCE hinst = 0, UINT nFlags = 0, LPCOLORMAP lpColorMap = NULL, int nMapSize = 0)
	{ 
		if (hinst == 0)
			hinst = _Module.GetModuleInstance();

		Attach(::CreateMappedBitmap(hinst, nIDBitmap, (WORD)nFlags, lpColorMap, nMapSize)); 
		return 0 != GetHandle();
	}
#endif

	BOOL LoadBitmapFromFile(LPCTSTR szFileName)
	{ 
		Attach(static_cast<HBITMAP>(LoadImage(0, szFileName, IMAGE_BITMAP,  0, 0, LR_LOADFROMFILE))); 
		return 0 != GetHandle();
	}

	BOOL CreateBitmap(int nWidth, int nHeight, UINT nPlanes, UINT nBitcount, const void* lpBits)
	{ 
		Attach(::CreateBitmap(nWidth, nHeight, nPlanes, nBitcount, lpBits)); 
		return 0 != GetHandle();
	}
	BOOL CreateBitmapIndirect(LPBITMAP lpBitmap)
	{ 
		Attach(::CreateBitmapIndirect(lpBitmap)); 
		return 0 != GetHandle();
	}
	BOOL CreateCompatibleBitmap(HDC hDC, int nWidth, int nHeight)
	{ 
		Attach(::CreateCompatibleBitmap(hDC, nWidth, nHeight)); 
		return 0 != GetHandle();
	}
	BOOL CreateDiscardableBitmap(HDC hDC, int nWidth, int nHeight)
	{ 
		Attach(::CreateDiscardableBitmap(hDC, nWidth, nHeight)); 
		return 0 != GetHandle();
	}
	int GetBitmap(BITMAP* pBitMap)
	{ 
		ATLASSERT(GetHandle() != NULL);
		return ::GetObject(GetHandle(), sizeof(BITMAP), pBitMap); 
	}
	DWORD SetBitmapBits(DWORD dwCount, const void* lpBits)
	{ 
		return ::SetBitmapBits(GetHandle(), dwCount, lpBits); 
	}
	DWORD GetBitmapBits(DWORD dwCount, LPVOID lpBits) const
	{ 
		return ::GetBitmapBits(GetHandle(), dwCount, lpBits); 
	}
	SIZE SetBitmapDimension(int nWidth, int nHeight)
	{
		SIZE size;
		::SetBitmapDimensionEx(GetHandle(), nWidth, nHeight, &size);
		return size;
	}
	SIZE GetBitmapDimension(void) const
	{
		SIZE size;
		::GetBitmapDimensionEx(GetHandle(), &size);
		return size;
	}
};



/**
 * HPALETTE Wrapper class.
 *
 * @author Jim Murphy
 */

class CGdiPalette : public CGdiObject<CGdiPalette, HPALETTE>
{
	ATTILA_DECLARE_NO_COPY(CGdiPalette)

public:
	CGdiPalette()
	{
	}
	virtual ~CGdiPalette()
	{
	}
	BOOL CreatePalette(LPLOGPALETTE lpLogPalette)
	{ 
		Attach(::CreatePalette(lpLogPalette)); 
		return 0 != GetHandle();
	}
	BOOL CreateHalftonePalette(HDC hDC)
	{ 
		ATLASSERT(hDC != NULL); 
		Attach(::CreateHalftonePalette(hDC));
		return 0 != GetHandle();
	}
	int GetEntryCount()
	{ 
		ATLASSERT(GetHandle() != NULL); 
		WORD nEntries = 0;
		::GetObject(GetHandle(), sizeof(WORD), &nEntries); 
		return (int)nEntries; 
	}
	UINT GetPaletteEntries(UINT nStartIndex, UINT nNumEntries, LPPALETTEENTRY lpPaletteColors) const
	{ 
		ATLASSERT(GetHandle() != NULL); 
		return ::GetPaletteEntries(GetHandle(), nStartIndex, nNumEntries, lpPaletteColors); 
	}
	UINT SetPaletteEntries(UINT nStartIndex, UINT nNumEntries, LPPALETTEENTRY lpPaletteColors)
	{ 
		ATLASSERT(GetHandle() != NULL); 
		return ::SetPaletteEntries(GetHandle(), nStartIndex, nNumEntries, lpPaletteColors); 
	}
	void AnimatePalette(UINT nStartIndex, UINT nNumEntries, LPPALETTEENTRY lpPaletteColors)
	{ 
		ATLASSERT(GetHandle() != NULL); 
		::AnimatePalette(GetHandle(), nStartIndex, nNumEntries, lpPaletteColors); 
	}
	UINT GetNearestPaletteIndex(COLORREF crColor) const
	{ 
		ATLASSERT(GetHandle() != NULL); 
		return ::GetNearestPaletteIndex(GetHandle(), crColor); 
	}
	BOOL ResizePalette(UINT nNumEntries)
	{ 
		ATLASSERT(GetHandle() != NULL); 
		return ::ResizePalette(GetHandle(), nNumEntries); 
	}
};

// John Stovin 22/11/99 
// a non-template (but virtual) base class for DC objects, so that we can pass them around easily
// moved all the non-templated methods up to this class so that they don't get recreated
// every time we derive a new class from CGdiDC
class CGdiDC : public CGdiObject<CGdiDC, HDC>
{
	ATTILA_DECLARE_NO_COPY(CGdiDC)

protected:
	int m_nInitialState;

	BOOL InternalSaveState()
	{
		if (0 == m_nInitialState)
		{
			m_nInitialState = ::SaveDC(GetHandle());
			ATLASSERT( "Error saving HDC state!" && m_nInitialState );
		}
		return 0 != m_nInitialState;
	}

	void InternalRestoreState()
	{			
		if (m_nInitialState)
		{
#ifdef _DEBUG
			ATLASSERT( ::RestoreDC(GetHandle(), m_nInitialState) );
#else
			::RestoreDC(GetHandle(), m_nInitialState);
#endif
		}
	}

	CGdiDC() : m_nInitialState(0)
	{
	}

	explicit CGdiDC(HDC hdc)
		: CGdiObject<CGdiDC, HDC>(hdc), m_nInitialState(0)
	{
	}

	template <typename TGDIObj>
	TGDIObj InternalSelectObject(TGDIObj obj)
	{
		InternalSaveState();
		return static_cast<TGDIObj>(::SelectObject(GetHandle(), obj));
	}

public:
	// all the real DC objects must inherit from this, so needs a virtual destructor
	// pure virtual to force this to be a virtual base class
	virtual ~CGdiDC() = 0;

	int SaveDC()
	{
		ATLASSERT( IsValid() );
		
		// Make sure we always have the initial state of the DC...
		return m_nInitialState
			? ::SaveDC(GetHandle())
			: m_nInitialState = ::SaveDC(GetHandle());
	}

	BOOL RestoreDC(int nSaveDC = -1)
	{
		ATLASSERT( IsValid() );

		// Trying to restore the initial state...
		if (m_nInitialState == nSaveDC)
			m_nInitialState = 0;

		return ::RestoreDC(GetHandle(), nSaveDC);
	}

	/**
	 * Restore the initial state of the DC (before any SelectObjects, etc).
	 */
	BOOL RestoreInitialDC()
	{
		ATLASSERT( IsValid() );

		BOOL bRetValue = TRUE;
		if (m_nInitialState)
		{
			bRetValue = RestoreDC(m_nInitialState);
			m_nInitialState = 0;
		}
		return bRetValue;
	}

	BOOL CancelDC()
	{
		ATLASSERT( IsValid() );
		return ::CancelDC( GetHandle() );
	}
	
	HGDIOBJ SelectObject(HGDIOBJ hObj)
	{		
		ATLASSERT( IsValid() );
		return InternalSelectObject(hObj);
	}

	HBRUSH SelectObject(HBRUSH hBrush)
	{
		ATLASSERT( IsValid() );
		return InternalSelectObject(hBrush);
	}

	HFONT SelectObject(HFONT hFont)
	{
		ATLASSERT( IsValid() );
		return InternalSelectObject(hFont);
	}
	
	HPEN SelectObject(HPEN hPen)
	{
		ATLASSERT( IsValid() );
		return InternalSelectObject(hPen);
	}	

	HBITMAP SelectObject(HBITMAP hBitmap)
	{
		ATLASSERT( IsValid() );
		return InternalSelectObject(hBitmap);
	}

	COLORREF SetTextColor(COLORREF color)
	{
		ATLASSERT( IsValid() );
		InternalSaveState();
		return ::SetTextColor(GetHandle(), color);
	}

	int SetBkMode(int nMode)
	{
		ATLASSERT( IsValid() );
		InternalSaveState();
		return ::SetBkMode(GetHandle(), nMode);
	}

	int DrawText(LPCTSTR s, int nTextLen, RECT* lprc, int flags)
	{
		ATLASSERT( IsValid() );
		return ::DrawText(GetHandle(), s, nTextLen, lprc, flags);
	}

	int DrawText(LPCTSTR s, const RECT& rc, int flags = DT_SINGLELINE|DT_VCENTER|DT_CENTER, int nTextLen = -1) const
	{
		ATLASSERT( IsValid() );
		return ::DrawText(GetHandle(), s, nTextLen, const_cast<RECT*>(&rc), flags);
	}	

	BOOL ExtTextOut(int x, int y, UINT nOptions, const RECT *pRect, LPCTSTR lpszString, UINT nCount, const int *lpDxWidths = NULL)
	{ 
		ATLASSERT( IsValid() );
		return ::ExtTextOut(GetHandle(), x, y, nOptions, pRect, lpszString, nCount, lpDxWidths); 
	}
	UINT SetTextAlign(UINT nFlags)
	{
		ATLASSERT( IsValid() );
		return ::SetTextAlign(GetHandle(), nFlags);
	}
	UINT GetTextAlign(UINT nFlags) const
	{
		ATLASSERT( IsValid() );
		return ::GetTextAlign(GetHandle());
	}

	BOOL Rectangle(int l, int t, int r, int b) const
	{
		ATLASSERT( IsValid() );
		return ::Rectangle(GetHandle(), l, t, r, b);
	}

	BOOL Rectangle(const RECT& rc) const
	{
		ATLASSERT( IsValid() );
		return ::Rectangle(GetHandle(), rc.left, rc.top, rc.right, rc.bottom);
	}

	BOOL Ellipse(int x0, int y0, int x2, int y2) const
	{
		ATLASSERT( IsValid() );
		return ::Ellipse(GetHandle(), x0, y0, x2, y2);
	}

	BOOL Ellipse(const RECT& rc) const
	{
		ATLASSERT( IsValid() );
		return ::Ellipse(GetHandle(), rc.left, rc.top, rc.right, rc.bottom);
	}

	BOOL Circle(int x, int y, int radius) const
	{
		ATLASSERT( IsValid() );
		return ::Ellipse(GetHandle(), x-radius, y-radius, x+radius, y+radius);
	}

	BOOL GetBrushOrgEx(LPPOINT lppt) const
	{
		ATLASSERT( IsValid() );
		return ::GetBrushOrgEx(GetHandle(), lppt);
	}

	BOOL SetBrushOrgEx(int nXOrg, int nYOrg, LPPOINT lpPreviousOrg = NULL)
	{
		ATLASSERT( IsValid() );
		return ::SetBrushOrgEx(GetHandle(), nXOrg, nYOrg, lpPreviousOrg);
	}

	BOOL PatBlt(int nXLeft, int nYLeft, int nWidth, int nHeight, DWORD dwRop = PATCOPY)
	{
		ATLASSERT( IsValid() );
		return ::PatBlt(GetHandle(), nXLeft, nYLeft, nWidth, nHeight, dwRop);
	} 

	int GetDeviceCaps(int nIndex) const
	{
		ATLASSERT( IsValid() );
		return ::GetDeviceCaps(GetHandle(), nIndex);
	}

	BOOL BitBlt(int nDestX, int nDestY, int nWidth, int nHeight, HDC hdcSource, int nSourceX = 0, int nSourceY = 0, DWORD dwRop = SRCCOPY)
	{
		ATLASSERT( IsValid() );
		return ::BitBlt(GetHandle(), nDestX, nDestY, nWidth, nHeight, hdcSource, nSourceX, nSourceY, dwRop);
	}

	BOOL BitBlt(const RECT& rcDest, HDC hdcSource, int nSourceX = 0, int nSourceY = 0, DWORD dwRop = SRCCOPY)
	{
		return BitBlt(rcDest.left, rcDest.top, rcDest.right - rcDest.left + 1, rcDest.bottom - rcDest.top + 1, hdcSource, nSourceX, nSourceY, dwRop);
	}

	BOOL FillRgn(HRGN hRgn, HBRUSH hBrush)
	{ 
		ATLASSERT( IsValid() );
		return ::FillRgn(GetHandle(), hRgn, hBrush);
	}

	BOOL FrameRgn(HRGN hRgn, HBRUSH hBrush, int nWidth, int nHeight)
	{ 
		ATLASSERT( IsValid() );
		return ::FrameRgn(GetHandle(), hRgn, hBrush, nWidth, nHeight); 
	}

	BOOL InvertRgn(HRGN hRgn)
	{
		ATLASSERT( IsValid() );
		return ::InvertRgn(GetHandle(), hRgn); 
	}
	
	BOOL PaintRgn(HRGN hRgn)
	{
		ATLASSERT( IsValid() );
		return ::PaintRgn(GetHandle(), hRgn); 
	}
	BOOL AbortPath()
	{ 
		ATLASSERT( IsValid() ); 
		return ::AbortPath(GetHandle()); 
	}
	BOOL BeginPath()
	{ 
		ATLASSERT( IsValid() );
 
		return ::BeginPath(GetHandle()); 
	}
	BOOL CloseFigure()
	{ 
		ATLASSERT( IsValid() ); 
		return ::CloseFigure(GetHandle()); 
	}
	BOOL EndPath()
	{ 
		ATLASSERT( IsValid() ); 
		return ::EndPath(GetHandle()); 
	}
	BOOL FillPath()
	{ 
		ATLASSERT( IsValid() ); 
		return ::FillPath(GetHandle()); 
	}
	BOOL FlattenPath()
	{ 
		ATLASSERT( IsValid() ); 
		return ::FlattenPath(GetHandle()); 
	}
	int GetPath(LPPOINT lpPoints, BYTE *lpTypes, int nCount) const
	{ 
		ATLASSERT( IsValid() ); 
		return ::GetPath(GetHandle(), lpPoints, lpTypes, nCount); 
	}
	float GetMiterLimit() const
	{ 
		ATLASSERT( IsValid() ); 
		float fMiterLimit = 0.0f;
		ATLVERIFY(::GetMiterLimit(GetHandle(), &fMiterLimit)); 
		return fMiterLimit; 
	}
	BOOL SetMiterLimit(float fMiterLimit)
	{ 
		ATLASSERT( IsValid() ); 
		return ::SetMiterLimit(GetHandle(), fMiterLimit, NULL); 
	}
	BOOL StrokeAndFillPath()
	{ 
		ATLASSERT( IsValid() ); 
		return ::StrokeAndFillPath(GetHandle()); 
	}
	BOOL StrokePath()
	{ 
		ATLASSERT( IsValid() ); 
		return ::StrokePath(GetHandle()); 
	}
	BOOL WidenPath()
	{ 
		ATLASSERT( IsValid() ); 
		return ::WidenPath(GetHandle()); 
	}
};

// need a body for a pure virtual destructor, because it will get called anyway
inline CGdiDC::~CGdiDC() {}

/**
 * HDC Wrapper class.
 *
 * @author Rodrigo B. de Oliveira
 *
 */

template <typename T>
class CGdiDCBase : public CGdiDC
{
	ATTILA_DECLARE_NO_COPY(CGdiDCBase)

protected:
	CGdiDCBase() : CGdiDC()
	{
	}

	explicit CGdiDCBase(HDC hdc)
		: CGdiDC(hdc)
	{
	}

public:
	~CGdiDCBase()
	{
		if (IsValid())
		{
			InternalRestoreState();
			static_cast<T*>(this)->Free();
		}
	}


};
// John Stovin 22/11/99 - end


/**
 * Memory DC class
 *
 * @author Rodrigo B. de Oliveira
 *
*/

class CGdiMemDC : public CGdiDCBase<CGdiMemDC>
{
	ATTILA_DECLARE_NO_ASSIGN(CGdiMemDC)

	void Free()
	{
		::DeleteDC(GetHandle());
	}

	friend CGdiDCBase<CGdiMemDC>;
	friend CGdiObjectBase<CGdiDC, HDC>;

public:
	CGdiMemDC()
	{
	}

	// Creates a memory DC compatible with hdcOther.
	explicit CGdiMemDC(HDC hdcOther)
		: CGdiDCBase<CGdiMemDC>( ::CreateCompatibleDC(hdcOther) )
	{
		ATLASSERT( IsValid() );
	}

// John Stovin 22/11/99
	// construct a new DC based on an existing CGdiDC-derived object
	explicit CGdiMemDC(const CGdiDC& dc)
		: CGdiDCBase<CGdiMemDC>( ::CreateCompatibleDC(static_cast<HDC>(dc)) )
	{
		ATLASSERT( IsValid() );
	}
// John Stovin 22/11/99 - end

	// Creates a memory DC compatible with hdcOther
	// with the bitmap hbmpSurface as drawing surface (SelectObject).
	CGdiMemDC(HDC hdcOther, HBITMAP hbmpSurface)
		: CGdiDCBase<CGdiMemDC>( ::CreateCompatibleDC(hdcOther) )
	{
		SelectObject(hbmpSurface);
	}

	BOOL CreateCompatibleDC(HDC hdcOther)
	{
		Attach( ::CreateCompatibleDC(hdcOther) );
		return IsValid();
	}

	BOOL CreateCompatibleDC(HDC hdcOther, HBITMAP hbmpSurface)
	{
		Attach( ::CreateCompatibleDC(hdcOther) );
		return IsValid() ? NULL != SelectObject(hbmpSurface) : FALSE;
	}
};


/**
 * Base class for window-based dc wrappers (dcs that must remember
 * the windows from which they were acquired).
 *
 * @author Rodrigo B. de Oliveira
 *
*/

template <typename T>
class CGdiWindowDCBase : public CGdiDCBase<T>
{
	void Attach(HDC);

	void Free()
	{
		::ReleaseDC(m_hWnd, GetHandle());
	}

	friend CGdiDCBase<T>;

protected:
	HWND m_hWnd;

	CGdiWindowDCBase() : m_hWnd(0)
	{
	}

	CGdiWindowDCBase(HDC hdc, HWND hWnd)
		: CGdiDCBase<T>(hdc), m_hWnd(hWnd)
	{
	}
};



/**
 * Window DC
 *
 * @author Rodrigo B. de Oliveira
 *
*/

class CGdiWindowDC : public CGdiWindowDCBase<CGdiWindowDC>
{	
	ATTILA_DECLARE_NO_COPY(CGdiWindowDC)	

public:	
	explicit CGdiWindowDC(HWND hWnd)
		: CGdiWindowDCBase<CGdiWindowDC>( ::GetWindowDC(hWnd), hWnd )
	{
		ATLASSERT( IsValid() );
	}
};


/**
 * Window DC
 *
 * @author Rodrigo B. de Oliveira
 *
*/

class CGdiClientDC : public CGdiWindowDCBase<CGdiClientDC>
{	
	ATTILA_DECLARE_NO_COPY(CGdiClientDC)	

public:
	explicit CGdiClientDC(HWND hWnd)
		: CGdiWindowDCBase<CGdiClientDC>( ::GetDC(hWnd), hWnd )
	{
		ATLASSERT( IsValid() );
	}
};



/**
 * Paint DC -- takes care of calling BeginPaint and EdPaint.
 *
 * @author Rodrigo B. de Oliveira
 *
*/

class CGdiPaintDC : public CGdiDCBase<CGdiPaintDC>
{
private:
	void Attach(HDC); // Attach makes no sense for this class.
	ATTILA_DECLARE_NO_COPY(CGdiPaintDC)

	void Free()
	{
		::EndPaint(m_hWnd, &m_ps);
	}

	friend CGdiDCBase<CGdiPaintDC>;

protected:
	PAINTSTRUCT m_ps;
	HWND m_hWnd;

public:
	explicit CGdiPaintDC(HWND hWnd)
		: CGdiDCBase<CGdiPaintDC>( ::BeginPaint(hWnd, &m_ps) )
	{		
		ATLASSERT( IsValid() );
	}	

	HWND GetHWND() const
	{
		return m_hWnd;
	}

	const PAINTSTRUCT& GetPAINTSTRUCT() const 
	{
		return m_ps;
	}	
};


}   // namespace Attila

#ifndef _ATTILA_NOUSE_NAMESPACE
using namespace Attila;
#endif

#endif
