// AttilaWrappers.h
/////////////////////////////////////////////////////////////////////////////
// This is part of the Attila library.
// Copyright (c) 1999, Attila contributors (see ReadMe.htm).
// All rights reserved. No warranties extended.
/////////////////////////////////////////////////////////////////////////////
// History:
// -11/10/99:
//  Robert MacFadyen [robmc@interlog.com] fixed "must return a value"
//  for CRect Intersect, Union and Subtract.

#pragma once
#ifndef INC_ATTILAWRAPPERS
#define INC_ATTILAWRAPPERS

namespace Attila
{

/////////////////////////////////////////////////////////////////////////////
// CPoint - wraps a Windows POINT structure

class CPoint : public POINT
{
public:
	CPoint()
	{
		x = 0;
		y = 0;
	}
	CPoint(int ix, int iy)
	{
		x = ix;
		y = iy;
	}
	CPoint(POINT ip)
	{
		x = ip.x;
		y = ip.y;
	}
	CPoint(SIZE is)
	{
		x = is.cx;
		y = is.cy;
	}
	CPoint(const CPoint& p)
	{
		x = p.x;
		y = p.y;
	}
	const CPoint& operator=(const POINT& p)
	{
		x = p.x;
		y = p.y;
		return *this;
	}
	const CPoint& operator=(const CPoint& p)
	{
		x = p.x;
		y = p.y;
		return *this;
	}
	CPoint MulDiv(int multiplier, int divisor) const
	{
		return CPoint(::MulDiv(x, multiplier, divisor), ::MulDiv(y, multiplier, divisor));
	}
};

inline bool operator==(const POINT& p1, const POINT& p2)
{
	return (p1.x == p2.x) && (p1.y == p2.y);
}

inline bool operator!=(const POINT& p1, const POINT& p2)
{
	return (p1.x != p2.x) || (p1.y != p2.y);
}

inline void operator+=(POINT& p1, const SIZE& s1)
{
	p1.x += s1.cx;
	p1.y += s1.cy;
}

inline void operator+=(POINT& p1, const POINT& p2)
{
	p1.x += p2.x;
	p1.y += p2.y;
}

inline void operator-=(POINT& p1, const SIZE& s1)
{
	p1.x -= s1.cx;
	p1.y -= s1.cy;
}

inline CPoint operator+(const POINT& p1, const SIZE& s1)
{
	return CPoint(p1.x + s1.cx, p1.y + s1.cy);
}

inline CPoint operator+(const POINT& p1, const POINT& p2)
{
	return CPoint(p1.x + p2.x, p1.y + p2.y);
}

inline CPoint operator+(const SIZE& s1, const POINT& p1)
{
	return CPoint(p1.x + s1.cx, p1.y + s1.cy);
}

inline CPoint operator-(const POINT& p1, const SIZE& s1)
{
	return CPoint(p1.x - s1.cx, p1.y - s1.cy);
}

inline CPoint operator-(const POINT& p1)
{
	return CPoint(-p1.x, -p1.y);
}

/////////////////////////////////////////////////////////////////////////////
// CSize - wraps a Windows SIZE structure

class CSize : public SIZE
{
public:
	CSize()
	{
		cx = 0;
		cy = 0;
	}
	CSize(int ix, int iy)
	{
		cx = ix;
		cy = iy;
	}
	CSize(POINT ip)
	{
		cx = ip.x;
		cy = ip.y;
	}
	CSize(SIZE is)
	{
		cx = is.cx;
		cy = is.cy;
	}
	CSize(const CSize& s)
	{
		cx = s.cx;
		cy = s.cy;
	}
	const CSize& operator=(const SIZE& s)
	{
		cx = s.cx;
		cy = s.cy;
		return *this;
	}
	const CSize& operator=(const CSize& s)
	{
		cx = s.cx;
		cy = s.cy;
		return *this;
	}
	CSize MulDiv(int multiplier, int divisor) const
	{
		return CSize(::MulDiv(cx, multiplier, divisor), ::MulDiv(cy, multiplier, divisor));
	}
};

inline bool operator==(const SIZE& s1, const SIZE& s2)
{
	return (s1.cx == s2.cx) && (s1.cy == s2.cy);
}

inline bool operator!=(const SIZE& s1, const SIZE& s2)
{
	return (s1.cx != s2.cx) || (s1.cy != s2.cy);
}

inline void operator+=(SIZE& s1, const SIZE& s2)
{
	s1.cx += s2.cx;
	s1.cy += s2.cy;
}

inline void operator-=(SIZE& s1, const SIZE& s2)
{
	s1.cx -= s2.cx;
	s1.cy -= s2.cy;
}

inline CSize operator*=(SIZE& s1, double n)
{
	return CSize((LONG)(s1.cx * n), (LONG)(s1.cy * n));
}

inline CSize operator+(const SIZE& s1, const SIZE& s2)
{
	return CSize(s1.cx + s2.cx, s1.cy + s2.cy);
}

inline CSize operator-(const SIZE& s1, const SIZE& s2)
{
	return CSize(s1.cx - s2.cx, s1.cy - s2.cy);
}

inline CSize operator-(const SIZE& s1)
{
	return CSize(-s1.cx, -s1.cy);
}

inline CSize operator-(const POINT& p1, const POINT& p2)
{
	return CSize(p1.x - p2.x, p1.y - p2.y);
}

inline CSize operator*(const SIZE& s1)
{
	return CSize(-s1.cx, -s1.cy);
}

/////////////////////////////////////////////////////////////////////////////
// CRect - Wraps a Windows RECT structure

class CRect : public RECT
{
public:
	CRect()
	{
		left = 0;
		top = 0;
		right = 0;
		bottom = 0;
	}
	CRect(int l, int t, int r, int b)
	{
		left = l;
		top = t;
		right = r;
		bottom = b;
	}
	CRect(const RECT& r)
	{
		left = r.left;
		top = r.top;
		right = r.right;
		bottom = r.bottom;
	}
	CRect(const CRect& r)
	{
		left = r.left;
		top = r.top;
		right = r.right;
		bottom = r.bottom;
	}
	CRect(const RECT *r)
	{
		left = r->left;
		top = r->top;
		right = r->right;
		bottom = r->bottom;
	}
	CRect(const POINT& point, const SIZE& size)
	{
		left = point.x;
		top = point.y;
		right = point.x + size.cx;
		bottom = point.y + size.cy;
	}
	CRect(const POINT& topLeft, const POINT& bottomRight)
	{
		left = topLeft.x;
		top = topLeft.y;
		right = bottomRight.x;
		bottom = bottomRight.y;
	}
	const CRect& operator=(const RECT& r)
	{
		left = r.left;
		top = r.top;
		right = r.right;
		bottom = r.bottom;
		return *this;
	}
	const CRect& operator=(const CRect& r)
	{
		left = r.left;
		top = r.top;
		right = r.right;
		bottom = r.bottom;
		return *this;
	}

	int Width() const
	{
		return right - left;
	}
	int Height() const
	{
		return bottom - top;
	}
	CSize Size() const
	{
		return CSize(right - left, bottom - top);
	}
	POINT& TopLeft()
	{
		return *(reinterpret_cast<POINT*>(this));
	}
	POINT& BottomRight()
	{
		return *(reinterpret_cast<POINT*>(this) + 1);
	}
	const POINT& TopLeft() const
	{
		return *(reinterpret_cast<const POINT*>(this));
	}
	const POINT& BottomRight() const
	{
		return *(reinterpret_cast<const POINT*>(this) + 1);
	}
	CPoint CenterPoint() const
	{
		return CPoint((left+right)/2, (top+bottom)/2);
	}
	void SwapLeftRight()
	{
		LONG temp = left;
		left = right;
		right = temp;
	}

	operator RECT*()
	{
		return this;
	}
	operator const RECT*() const
	{
		return this;
	}

	BOOL IsRectEmpty() const
	{
		return ::IsRectEmpty(this);
	}
	BOOL IsRectNull() const
	{
		return (left == 0 && top == 0 && right == 0 && bottom == 0);
	}
	BOOL PtInRect(POINT point) const
	{
		return ::PtInRect(this, point);
	}

	void SetRect(int l, int t, int r, int b)
	{
		left = l;
		top = t;
		right = r;
		bottom = b;
	}
	void SetRect(const POINT& point, const SIZE& size)
	{
		left = point.x;
		top = point.y;
		right = point.x + size.cx;
		bottom = point.y + size.cy;
	}
	void SetRect(const POINT& topLeft, const POINT& bottomRight)
	{
		left = topLeft.x;
		top = topLeft.y;
		right = bottomRight.x;
		bottom = bottomRight.y;
	}
	void SetRectEmpty()
	{
		left = 0;
		top = 0;
		right = 0;
		bottom = 0;
	}
	void CopyRect(const RECT *r)
	{
		::CopyRect(this, r);
	}

	BOOL EqualRect(const RECT *r) const
	{
		return ::EqualRect(this, r);
	}
	void InflateRect(int d)
	{
		::InflateRect(this, d, d);
	}
	void InflateRect(int x, int y)
	{
		::InflateRect(this, x, y);
	}
	void InflateRect(const SIZE& size)
	{
		::InflateRect(this, size.cx, size.cy);
	}
	void InflateRect(const RECT *r)
	{
		left -= r->left;
		top -= r->top;
		right += r->right;
		bottom += r->bottom;
	}
	void InflateRect(int l, int t, int r, int b)
	{
		left -= l;
		top -= t;
		right += r;
		bottom += b;
	}
	void DeflateRect(int x, int y)
	{
		::InflateRect(this, -x, -y);
	}
	void DeflateRect(SIZE size)
	{
		::InflateRect(this, -size.cx, -size.cy);
	}
	void DeflateRect(const RECT *r)
	{
		left += r->left;
		top += r->top;
		right -= r->right;
		bottom -= r->bottom;
	}
	void DeflateRect(int l, int t, int r, int b)
	{
		left += l;
		top += t;
		right -= r;
		bottom -= b;
	}
	void OffsetRect(int x, int y)
	{
		::OffsetRect(this, x, y);
	}
	void OffsetRect(const SIZE& size)
	{
		::OffsetRect(this, size.cx, size.cy);
	}
	void OffsetRect(POINT point)
	{
		::OffsetRect(this, point.x, point.y);
	}
	void NormalizeRect()
	{
		int nTemp;
		if (left > right)
		{
			nTemp = left;
			left = right;
			right = nTemp;
		}
		if (top > bottom)
		{
			nTemp = top;
			top = bottom;
			bottom = nTemp;
		}
	}

	BOOL IntersectRect(const RECT *r1, const RECT *r2)
	{
		return ::IntersectRect(this, r1, r2);
	}
	BOOL UnionRect(const RECT *r1, const RECT *r2)
	{
		return ::UnionRect(this, r1, r2);
	}
	BOOL SubtractRect(const RECT *r1, const RECT *r2)
	{
		return ::SubtractRect(this, r1, r2);
	}

	CRect MulDiv(int multiplier, int divisor) const
	{
		return CRect(
			::MulDiv(left, multiplier, divisor),
			::MulDiv(top, multiplier, divisor),
			::MulDiv(right, multiplier, divisor),
			::MulDiv(bottom, multiplier, divisor));
	}
};

inline bool operator==(const RECT& rect1, const RECT& rect2)
{
    return ::EqualRect(&rect1, &rect2) ? true : false;
}

inline bool operator!=(const RECT& rect1, const RECT& rect2)
{
	return !::EqualRect(&rect1, &rect2);
}

inline void operator+=(RECT& rect, const POINT& point)
{
	::OffsetRect(&rect, point.x, point.y);
}

inline void operator+=(RECT& rect, const SIZE& size)
{
	::OffsetRect(&rect, size.cx, size.cy);
}

inline void operator+=(RECT& rect1, const RECT& rect2)
{
	rect1.left -= rect2.left;
	rect1.top -= rect2.top;
	rect1.right += rect2.right;
	rect1.bottom += rect2.bottom;
}

inline void operator-=(RECT& rect, const POINT& point)
{
	::OffsetRect(&rect, -point.x, -point.y);
}

inline void operator-=(RECT& rect, const SIZE& size)
{
	::OffsetRect(&rect, -size.cx, -size.cy);
}

inline void operator-=(RECT& rect1, const RECT& rect2)
{
	rect1.left += rect2.left;
	rect1.top += rect2.top;
	rect1.right -= rect2.right;
	rect1.bottom -= rect2.bottom;
}

inline void operator&=(RECT& rect1, const RECT& rect2)
{
	::IntersectRect(&rect1, &rect1, &rect2);
}

inline void operator|=(RECT& rect1, const RECT& rect2)
{
	::UnionRect(&rect1, &rect1, &rect2);
}

inline CRect operator+(const RECT& rect, const POINT point)
{
	CRect r(rect);
	::OffsetRect(&r, point.x, point.y);
	return r;
}

inline CRect operator-(const RECT& rect, const POINT& point)
{
	CRect r(rect);
	::OffsetRect(&r, -point.x, -point.y);
	return r;
}

inline CRect operator+(const RECT& rect1, const RECT& rect2)
{
	CRect r(rect1);
	r += rect2;
	return r;
}

inline CRect operator+(const RECT& rect, const SIZE& size)
{
	CRect r(rect);
	::OffsetRect(&r, size.cx, size.cy);
	return r;
}

inline CRect operator-(const RECT& rect, const SIZE& size)
{
	CRect r(rect);
	::OffsetRect(&r, -size.cx, -size.cy);
	return r;
}

inline CRect operator-(const RECT& rect1, const RECT& rect2)
{
	CRect r(rect1);
	r -= rect2;
	return r;
}

inline CRect operator&(const RECT& rect1, const RECT& rect2)
{
	RECT r;
	::IntersectRect(&r, &rect1, &rect2);
	return CRect(r);
}

inline CRect operator|(const RECT& rect1, const RECT& rect2)
{
	RECT r;
	::UnionRect(&r, &rect1, &rect2);
	return CRect(r);
}

/////////////////////////////////////////////////////////////////////////////
// CMenu

class CMenu
{
public:
	HMENU m_hMenu;

// Constructors
	CMenu(HMENU menu = NULL)
	{
		m_hMenu = menu;
	}
	CMenu& operator=(HMENU menu)
	{
		m_hMenu = menu;
		return *this;
	}
	BOOL Attach(HMENU menu)
	{
		ATLASSERT(::IsMenu(menu));
		m_hMenu = menu;
		return (m_hMenu != 0);
	}
	HMENU Detach()
	{
		HMENU menu = m_hMenu;
		m_hMenu = NULL;
		return menu;
	}
	BOOL CreateMenu()
	{
		return Attach(::CreateMenu());
	}
	BOOL CreatePopupMenu()
	{
		return Attach(::CreatePopupMenu());
	}
	BOOL LoadMenu(LPCTSTR lpszResourceName)
	{
		return Attach(::LoadMenu(_Module.GetModuleInstance(), lpszResourceName));
	}
	BOOL LoadMenu(UINT nIDResource)
	{
		return Attach(::LoadMenu(_Module.GetModuleInstance(),
			MAKEINTRESOURCE(nIDResource)));
	}
	BOOL LoadMenuIndirect(const void* lpMenuTemplate)
	{
		return Attach(::LoadMenuIndirect(lpMenuTemplate));
	}
	BOOL DestroyMenu()
	{
		if (m_hMenu == NULL)
			return FALSE;
		return ::DestroyMenu(Detach());
	}

// Attributes
	operator HMENU() const
	{
		return m_hMenu;
	}

// CMenu Operations
	BOOL DeleteMenu(UINT nPosition, UINT nFlags)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::DeleteMenu(m_hMenu, nPosition, nFlags);
	}

	BOOL TrackPopupMenu(UINT nFlags, int x, int y, HWND hWnd, LPCRECT lpRect = 0)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::TrackPopupMenu(m_hMenu, nFlags, x, y, 0, hWnd, lpRect);
	}

// CMenuItem Operations
	BOOL AppendMenu(UINT nFlags, UINT nIDNewItem = 0, LPCTSTR lpszNewItem = NULL)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::AppendMenu(m_hMenu, nFlags, nIDNewItem, lpszNewItem);
	}
	BOOL AppendMenu(UINT nFlags, UINT nIDNewItem, HBITMAP bmp)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::AppendMenu(m_hMenu, nFlags | MF_BITMAP, nIDNewItem,
			reinterpret_cast<LPCTSTR>(bmp));
	}
	UINT CheckMenuItem(UINT nIDCheckItem, UINT nCheck)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::CheckMenuItem(m_hMenu, nIDCheckItem, nCheck);
	}
	UINT EnableMenuItem(UINT nIDEnableItem, UINT nEnable)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::EnableMenuItem(m_hMenu, nIDEnableItem, nEnable);
	}
	UINT GetMenuItemCount() const
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::GetMenuItemCount(m_hMenu);
	}
	UINT GetMenuItemID(int nPos) const
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::GetMenuItemID(m_hMenu, nPos);
	}
	UINT GetMenuState(UINT nID, UINT nFlags) const
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::GetMenuState(m_hMenu, nID, nFlags);
	}
	int GetMenuString(UINT nIDItem, LPTSTR lpString, int nMaxCount, UINT nFlags) const
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::GetMenuString(m_hMenu, nIDItem, lpString, nMaxCount, nFlags);
	}
	BOOL GetMenuItemInfo(UINT nIDItem, LPMENUITEMINFO lpMenuItemInfo, BOOL fByPos = FALSE)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::GetMenuItemInfo(m_hMenu, nIDItem, fByPos, lpMenuItemInfo);
	}
	HMENU GetSubMenu(int nPos) const
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::GetSubMenu(m_hMenu, nPos);
	}
	BOOL InsertMenu(UINT nPosition, UINT nFlags, UINT nIDNewItem = 0,
					LPCTSTR lpszNewItem = NULL)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::InsertMenu(m_hMenu, nPosition, nFlags, nIDNewItem, lpszNewItem);
	}
	BOOL InsertMenu(UINT nPosition, UINT nFlags, UINT nIDNewItem, HBITMAP bmp)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::InsertMenu(m_hMenu, nPosition, nFlags | MF_BITMAP, nIDNewItem,
			reinterpret_cast<LPCTSTR>(bmp));
	}
	BOOL ModifyMenu(UINT nPosition, UINT nFlags, UINT nIDNewItem = 0,
					LPCTSTR lpszNewItem = NULL)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::ModifyMenu(m_hMenu, nPosition, nFlags, nIDNewItem, lpszNewItem);
	}
	BOOL ModifyMenu(UINT nPosition, UINT nFlags, UINT nIDNewItem, HBITMAP bmp)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::ModifyMenu(m_hMenu, nPosition, nFlags | MF_BITMAP, nIDNewItem,
			reinterpret_cast<LPCTSTR>(bmp));
	}
	BOOL RemoveMenu(UINT nPosition, UINT nFlags)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::RemoveMenu(m_hMenu, nPosition, nFlags);
	}
	BOOL SetMenuItemBitmaps(UINT nPosition, UINT nFlags, HBITMAP bmpUnchecked,
							HBITMAP bmpChecked)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::SetMenuItemBitmaps(m_hMenu, nPosition, nFlags, bmpUnchecked, bmpChecked);
	}
	BOOL CheckMenuRadioItem(UINT nIDFirst, UINT nIDLast, UINT nIDItem, UINT nFlags)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::CheckMenuRadioItem(m_hMenu, nIDFirst, nIDLast, nIDItem, nFlags);
	}
	BOOL SetDefaultItem(UINT uItem, BOOL fByPos = FALSE)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::SetMenuDefaultItem(m_hMenu, uItem, fByPos);
	}
	UINT GetDefaultItem(UINT gmdiFlags, BOOL fByPos = FALSE)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::GetMenuDefaultItem(m_hMenu, fByPos, gmdiFlags);
	}

// Context Help Functions
	BOOL SetMenuContextHelpId(DWORD dwContextHelpId)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::SetMenuContextHelpId(m_hMenu, dwContextHelpId);
	}
	DWORD GetMenuContextHelpId() const
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::GetMenuContextHelpId(m_hMenu);
	}
};

}   // namespace Attila

#ifndef _ATTILA_NOUSE_NAMESPACE
using namespace Attila;
#endif

#endif //INC_ATTILAWRAPPERS
