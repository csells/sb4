// AttilaOleDlg.h
/////////////////////////////////////////////////////////////////////////////
// This is part of the Attila library.
// Copyright (c) 1999, Attila contributors (see ReadMe.htm).
// All rights reserved. No warranties extended.
/////////////////////////////////////////////////////////////////////////////

#pragma once
#ifndef INC_ATTILAOLEDLG
#define INC_ATTILAOLEDLG

#include "oledlg.h"

namespace Attila
{

/////////////////////////////////////////////////////////////////////////////
// COleUIDialogT - base class for OLE UI dialogs

template <typename T>
class COleUIDialogT : public T
{
// Implementation
public:
	UINT GetLastError() const
	{
		return m_lastError;
	}
protected:
	COleUIDialogT(DWORD flags)
	{
		ZeroMemory(this, sizeof(T));
		cbStruct = sizeof(T);
		dwFlags = flags;
		// reinterpret_cast<HINSTANCE&>(hInstance) = _Module.GetModuleInstance();
		hInstance = _Module.GetModuleInstance();
		m_lastError = 0;
	}
	int MapResult(UINT result)
	{
		m_lastError = result;
		if (result == OLEUI_OK)
			return IDOK;
		else if (result == OLEUI_CANCEL)
			return IDCANCEL;
		else
			return -1;
	}
private:
	UINT m_lastError;
};

/////////////////////////////////////////////////////////////////////////////
// CHookedOleUIDlgT - support for hooking OLE UI dialogs without subclassing
//
// Unfortunately, there's no way to change the hook procedure once the
// window has been created.  Solution: point the hook procedure at the
// thunk before the window is created, and use a CBT hook to actually
// initialize m_hwnd.

template <class TBase = CWindow>
class CHookedOleUIDlgT : public CWindowImplBaseT<TBase, CNullTraits>
{
// Implementation
protected:
	struct CreateData
	{
		// We can't use m_thunk.cd because the thunk is already in use.
		_AtlCreateWndData  m_cd;
		HHOOK              m_hook;
		CHookedOleUIDlgT  *m_pThis;
	};

	LPFNOLEUIHOOK CreateHook(CreateData & cd)
	{
		_Module.AddCreateWndData(&cd.m_cd, &cd);
        cd.m_hook = SetWindowsHookEx(WH_CBT, WinHookProc, _Module.GetModuleInstance(), GetCurrentThreadId());
		cd.m_pThis = this;

		m_thunk.Init(HookProc, this);
		return reinterpret_cast<LPFNOLEUIHOOK>(&(m_thunk.thunk));
	}

	BEGIN_MSG_MAP(CHookedOleUIDlgT)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	END_MSG_MAP()

	LRESULT OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		CenterWindow();
		return 0;
	}

	static LRESULT CALLBACK WinHookProc(int nCode, WPARAM wParam, LPARAM lParam)
	{
		if (nCode == HCBT_CREATEWND)
		{
			HWND            hwnd = reinterpret_cast<HWND>(wParam);
			CBT_CREATEWND  *pcs = reinterpret_cast<CBT_CREATEWND*>(lParam);
			CreateData     *cd = reinterpret_cast<CreateData*>(_Module.ExtractCreateWndData());
			UnhookWindowsHookEx(cd->m_hook);
			cd->m_pThis->m_hWnd = hwnd;
		}

		return 0;
    }
	static LRESULT CALLBACK HookProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
	{
		CHookedOleUIDlgT *pThis = reinterpret_cast<CHookedOleUIDlgT*>(hwnd);
		if (pThis->m_hWnd == NULL)
		{
			return 0;
		}

		// pass to the message map to process
		LRESULT result;
		BOOL bRet = pThis->ProcessWindowMessage(hwnd, msg, wp, lp, result, 0);
		if (!bRet && msg == WM_NCDESTROY)
		{
			// clear out window handle
			HWND hwnd = pThis->m_hWnd;
			pThis->m_hWnd = NULL;

			// clean up after window is destroyed
			pThis->OnFinalMessage(hwnd);
		}

		// We're only interested in whether or not the message was handled.
		// If we return FALSE, default processing will happen
		return bRet;
	}
};

/////////////////////////////////////////////////////////////////////////////
// COleUIBusyDlg - invokes the standard Busy dialog

class COleUIBusyDlg : public COleUIDialogT<OLEUIBUSY>
{
public:
// Constructors
	COleUIBusyDlg(HTASK htask, DWORD dwFlags = 0)
		: COleUIDialogT<OLEUIBUSY>(dwFlags)
	{
		hTask = htask;
	}

// Operations
	int DoModal(HWND hwndParent = ::GetActiveWindow())
	{
		hWndOwner = hwndParent;
		return MapResult(::OleUIBusy(this));
	}
};

/////////////////////////////////////////////////////////////////////////////
// COleUIBusyDlgEx - invokes the standard Busy dialog (hooked dialog box)

template <typename TBase = CWindow>
class COleUIBusyDlgEx : public COleUIBusyDlg, public CHookedOleUIDlgT<TBase>
{
public:
	COleUIBusyDlgEx(HTASK htask, DWORD dwFlags = 0)
		: COleUIBusyDlg(htask, dwFlags)
	{
	}
	int DoModal(HWND hwndParent = ::GetActiveWindow())
	{
		CreateData cd;
		lpfnHook = CreateHook(cd);
		return COleUIBusyDlg::DoModal(hwndParent);
	}
};

/////////////////////////////////////////////////////////////////////////////
// COleUIInsertObjectDlg - invokes the standard Insert Object dialog

class COleUIInsertObjectDlg : public COleUIDialogT<OLEUIINSERTOBJECT>
{
public:
// Constructors
	COleUIInsertObjectDlg(DWORD dwFlags = 0)
		: COleUIDialogT<OLEUIINSERTOBJECT>(dwFlags)
	{
		lpszFile = m_szFileName;
		cchFile = sizeof(m_szFileName) / sizeof(*m_szFileName);
		m_szFileName[0] = '\0';
	}
	~COleUIInsertObjectDlg()
	{
		if (hMetaPict)
		{
			LPMETAFILEPICT pmfp = reinterpret_cast<LPMETAFILEPICT>(GlobalLock(hMetaPict));
			DeleteMetaFile(pmfp->hMF);
			GlobalUnlock(hMetaPict);
			GlobalFree(hMetaPict);
		}
	}

// Operations
	int DoModal(HWND hwndParent = ::GetActiveWindow())
	{
		hWndOwner = hwndParent;
		return MapResult(::OleUIInsertObject(this));
	}

	HGLOBAL DetachPict()
	{
		HGLOBAL pict = hMetaPict;
		hMetaPict = NULL;
		return pict;
	}
private:
    TCHAR m_szFileName[MAX_PATH+1];
};

/////////////////////////////////////////////////////////////////////////////
// COleUIInsertObjectDlgEx - invokes the standard Insert Object dialog (hooked dialog box)

template <typename TBase = CWindow>
class COleUIInsertObjectDlgEx : public COleUIInsertObjectDlg, public CHookedOleUIDlgT<TBase>
{
public:
	COleUIInsertObjectDlgEx(DWORD dwFlags = 0)
		: COleUIInsertObjectDlg(dwFlags)
	{
	}
	int DoModal(HWND hwndParent = ::GetActiveWindow())
	{
		CreateData cd;
		lpfnHook = CreateHook(cd);
		return COleUIInsertObjectDlg::DoModal(hwndParent);
	}
};

}   // namespace Attila

#ifndef _ATTILA_NOUSE_NAMESPACE
using namespace Attila;
#endif

#endif // INC_ATTILAOLEDLG
