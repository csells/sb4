// AtlList.h
// Written by Shawn A. VanNess [xonix@MINDSPRING.COM]
// Placed into Attila by Chris Sells [csells@develop.com] and fixed some
// problems w/ the iterator.

#pragma once

#ifndef INC_ATLLIST
#define INC_ATLLIST
namespace Attila
{
    
// CSimpleList requires T to have a meaningful default-ctor, copy-ctor, and 
// assignment-operator.  The Sort method requires T::operator<, and the 
// Find and RemoveDups methods require T::operator==.

template<class T>
class CSimpleList
{
    struct node
    {
        T t;
        node* pPrev;
        node* pNext;
        
        node() { pPrev = pNext = 0; }
    };
    
    int m_nCount;
    node* m_pHead;
    node* m_pTail;
    
    public:
        
    // Initializers
    
    CSimpleList()
    {
        m_nCount = 0;
        m_pHead = m_pTail = 0;
    }
    
    CSimpleList(const CSimpleList<T>& src)
    {
        m_nCount = 0;
        m_pHead = m_pTail = 0;
        (*this) = src;
    }
    
    CSimpleList& operator=(const CSimpleList<T>& src)
    { 
        RemoveAll();
        Append(src);
        return (*this);
    }
    
    ~CSimpleList()
    { RemoveAll(); }
    
    // Accessors
    
    int Count() const
    { return m_nCount; }
    
    bool IsEmpty() const
    { return (m_nCount==0); }
    
    struct iterator
    {
        node* ptr;
        
        iterator() { ptr = 0; }
        iterator(node* p) { ptr = p; }
        iterator(const iterator& x) { ptr = x.ptr; }
        
        T& operator*() 
        { ATLASSERT(ptr); return ptr->t; }
        T& operator->()
        { ATLASSERT(ptr); return ptr->t; }
        
        iterator& operator++() { ATLASSERT(ptr); ptr = ptr->pNext; return (*this); }
        iterator& operator--() { ATLASSERT(ptr); ptr = ptr->pPrev; return (*this); }
        
        iterator operator++(int) { ATLASSERT(ptr); iterator ptrOld = ptr; ptr = ptr->pNext; return ptrOld; }
        iterator operator--(int) { ATLASSERT(ptr); iterator ptrOld = ptr; ptr = ptr->pPrev; return ptrOld; }
        
        bool operator==(const iterator& x) { return (ptr==x.ptr) ? (true) : (false); }
        bool operator!=(const iterator& x) { return (ptr==x.ptr) ? (false) : (true); }
    };
    
    iterator Head() const
    { return iterator(m_pHead); }
    
    iterator Tail() const
    { return iterator(m_pTail); }
    
    iterator Begin() const
    { return iterator(m_pHead); }
    
    iterator End() const
    { return iterator(0); }
    
    iterator Find(T& a) const
    {
        for(iterator p = Begin(); p != End(); p++)
            if (*p == a) // requires meaningful T::operator==
                return p;
            
            return 0;
    }
    
    // Operations
    
    void Add(T& a)
    {
        m_nCount++;
        node* p = new node;
        ATLASSERT(p);
        
        p->pPrev = m_pTail;
        p->pNext = 0;
        p->t = a;
        
        if (!m_pHead) m_pHead = p;
        
        if (m_pTail) m_pTail->pNext = p;
        m_pTail = p;
    }
    
    void Append(const CSimpleList<T>& src)
    {
        for(iterator p = src.Begin(); p != src.End(); p++)
            Add(*p);
    }
    
    void RemoveAt(iterator p)
    {
        node* pn = p.ptr;
        if (!pn) return;
        
        if (pn->pPrev) pn->pPrev->pNext = pn->pNext;
        else m_pHead = pn->pNext;
        
        if (pn->pNext) pn->pNext->pPrev = pn->pPrev;
        else m_pTail = pn->pPrev;
        
        delete pn;
        m_nCount--;
    }
    
    void RemoveAll()
    { 
        while (!IsEmpty()) 
            RemoveAt(Tail()); 
    }
    
    void InsertAt(iterator it, T& a)
    {
        // If we're at the end, add
        if( it == End() )
        {
            Add(a);
            return;
        }
        
        // Insert in front of p
        node* p = it.ptr;
        node* pNew = new node;
        m_nCount++;
        
        // Set up prev node
        if( p->pPrev )
        {
            p->pPrev->pNext = pNew;
        }
        
        // Set up new node
        pNew->pPrev = p->pPrev;
        pNew->pNext = p;
        pNew->t = a;
        
        // Move current node down one
        p->pPrev = pNew;
        
        // Is the new node the new head?
        if( !pNew->pPrev ) m_pHead = pNew;
    }
};

}   // namespace Attila

#ifndef _ATTILA_NOUSE_NAMESPACE
using namespace Attila;
#endif

#endif  // INC_ATLLIST
