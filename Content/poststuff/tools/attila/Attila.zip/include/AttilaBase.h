// AttilaBase.h
/////////////////////////////////////////////////////////////////////////////
// This is part of the Attila library.
// Copyright (c) 1999, Attila contributors (see ReadMe.htm).
// All rights reserved. No warranties extended.
/////////////////////////////////////////////////////////////////////////////

#pragma once
#ifndef INC_ATTILABASE
#define INC_ATTILABASE

#include "AttilaCommon.H"
#include "AttilaTranslate.h"

namespace Attila
{


}   // namespace Attila

#ifndef _ATTILA_NOUSE_NAMESPACE
using namespace Attila;
#endif

#endif // INC_ATTILABASE
