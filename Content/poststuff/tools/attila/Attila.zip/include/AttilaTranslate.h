// AttilaTranslate.h
/////////////////////////////////////////////////////////////////////////////
// This is part of the Attila library.
// Copyright (c) 1999, Attila contributors (see ReadMe.htm).
// All rights reserved. No warranties extended.
/////////////////////////////////////////////////////////////////////////////

#pragma once
#ifndef INC_ATTILATRANSLATE
#define INC_ATTILATRANSLATE

namespace Attila
{

class CMsgTranslator;

class CTranslators
{
private:
	DWORD m_dwTLS;
	BOOL  m_bHaveTLS;

private:
	CTranslators()
	{
		m_dwTLS = 0;
		m_bHaveTLS = FALSE;
	}

	~CTranslators()
	{
		if(m_bHaveTLS)
		{
			delete (CSimpleValArray<CMsgTranslator*>*)TlsGetValue(m_dwTLS);
			TlsFree(m_dwTLS);
		}
	}

private:
	void Add(CMsgTranslator* pTranslator)
	{
		GetTranslators().Add(pTranslator);
	}	

	void Remove(CMsgTranslator* pTranslator)
	{
		GetTranslators().Remove(pTranslator);
	}

	CSimpleValArray<CMsgTranslator*>& GetTranslators()
	{
		if(!m_bHaveTLS)
		{
			m_dwTLS = TlsAlloc();
			m_bHaveTLS = m_dwTLS != 0xFFFFFFFF;
		}

		typedef CSimpleValArray<CMsgTranslator*> transarray;
		transarray* pArray = 0;
		if(m_bHaveTLS)
		{
			pArray = (transarray*)TlsGetValue(m_dwTLS);
			if(!pArray)
			{
				pArray = new transarray();
				TlsSetValue(m_dwTLS,pArray);
			}
		}
		ATLASSERT(pArray != NULL);
		return *pArray;
	}

	friend class CMsgTranslator;
};

/////////////////////////////////////////////////////////////////////////////
// Anyone who wants to have the Translate() called from WinMain somehow,
// has to derive from this.
// This is just like PreTranslateMessage or PreTranslateAccelerator. Only that
// we dont burden every class with this.

class ATL_NO_VTABLE CMsgTranslator
{
	// Construction/Destruction
	//  Add to the chain and remove from the chain of translators.
protected:
	CMsgTranslator()
	{
		CTranslators* pArray = GetTranslators();
		if(pArray)
			pArray->Add(this);
	}

	virtual ~CMsgTranslator()
	{
		CTranslators* pArray = GetTranslators();
		if(pArray)
			pArray->Remove(this);
	}

	// This is used internally only, but should we allow
	//  others access??
	struct Holder
	{
		CTranslators* pTrans;
		BOOL bDestroyed;
	};

	static CTranslators* GetTranslators()
	{
		static Holder holder = { NULL, FALSE };

		if(!holder.pTrans && !holder.bDestroyed)
		{
			
			holder.pTrans = new CTranslators();
			_Module.AddTermFunc(_FreeTranslators,(DWORD)&holder);
		}

		return holder.bDestroyed ? NULL : holder.pTrans;
	}

	static void __stdcall _FreeTranslators( DWORD dw )
	{
		Holder* pHolder = (Holder*)dw;
		delete pHolder->pTrans;
		pHolder->pTrans = NULL;
		pHolder->bDestroyed = TRUE;
	}

public:
	static BOOL RunThroughTranslators(const MSG& rmsg,HACCEL haccel=0)
	{
		CTranslators* translators = GetTranslators();
		int numTranslators = translators->GetTranslators().GetSize();

		BOOL bRet = FALSE;
		for( int translator = 0; translator < numTranslators; ++translator )
			if(bRet = translators->GetTranslators()[translator]->Translate(rmsg,haccel))
				break;

		return bRet;
	}

public:
 	virtual BOOL Translate(const MSG& rmsg,HACCEL hAccel) = 0;
};

}   // namespace Attila

#ifndef _ATTILA_NOUSE_NAMESPACE
using namespace Attila;
#endif

#endif  // INC_ATTILATRANSLATE
