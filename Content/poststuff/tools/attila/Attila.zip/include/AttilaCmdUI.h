// AttilaCommandUI.h
/////////////////////////////////////////////////////////////////////////////
// This is part of the Attila library.
// Copyright (c) 1999, Attila contributors (see license.txt).
// All rights reserved. No warranties extended.
/////////////////////////////////////////////////////////////////////////////
// This header declares the following
//	CCmdUI
//		CMenuCmdUI
//		CWindowCmdUI
//		CStatusBarCtrlCmdUI
//		CToolBarCtrlCmdUI
//
// CCmdUIStatusBarT
//		CCmdUIStatuBar
// CIdleUIWindowT
//		CIdleUIToolBar
//
// CCmdUIDlg
/////////////////////////////////////////////////////////////////////////////
// History:
// 11/7/99:
//  -Joseph M. O'Leary [jmoleary@earthlink.net] added code to track changes
//   in command UI routing to reduce flicker.
//
// 11/2/99:
//  -Fixed a Unicode bug in CStatusBarCtrlCmdUI::SetCheck discovered by
//   Tom Minor [tminor@att.com].

#pragma once

#ifndef INC_ATTILACOMMANDUI
#define INC_ATTILACOMMANDUI

#include <AttilaCommon.h>
#include <AttilaTranslate.h>
#include <AttilaControls.h>
#include <AttilaBars.h>
#include <AttilaMsgPump.h>

namespace Attila
{
	
// -----------------------------------------------------------------------------
// Message Map Macros for UPDATE_COMMAND_UI processing
// -----------------------------------------------------------------------------


// Declare a normal, MFC-style COMMAND_UI member handler function
#define COMMAND_UI_HANDLER(id, CmdUIFunc) \
     if ( uMsg == WM_CMDUI && (id) == wParam ) \
     { \
		CCmdUI* pCmdUI = reinterpret_cast<CCmdUI*>(lParam); \
		CmdUIFunc((id), pCmdUI); \
		lResult = 0; \
		bHandled = !pCmdUI->ShouldRoutingContinue(); \
		if ( bHandled ) \
			return TRUE; \
	}
// Declare a COMMAND_UI handler for a range of control IDs
#define COMMAND_UI_HANDLER_RANGE(idLow, idHigh, CmdUIFunc) \
     if ( uMsg == WM_CMDUI && idLow <= wParam && idHigh >= wParam ) \
     { \
		CCmdUI* pCmdUI = reinterpret_cast<CCmdUI*>(lParam); \
		CmdUIFunc((wParam), pCmdUI); \
		lResult = 0; \
		bHandled = !pCmdUI->ShouldRoutingContinue(); \
		if ( bHandled ) \
			return TRUE; \
	}

// Enable or disable an control by default.
#define COMMAND_UI_DEFAULT(id, bEnable) \
     if ( uMsg == WM_CMDUI && (id) == wParam ) \
     { \
		bHandled = TRUE; \
		lResult = 0; \
		reinterpret_cast<CCmdUI*>(lParam)->Enable((bEnable));\
		return TRUE; \
	}

// Enable or disable a range of controls by default
#define COMMAND_UI_DEFAULT_RANGE(idLow, bEnable) \
     if ( uMsg == WM_CMDUI && (idLow) <= wParam && (idHigh) >= wParam ) \
     { \
		bHandled = TRUE; \
		lResult = 0; \
		reinterpret_cast<CCmdUI*>(lParam)->Enable((bEnable));\
		return TRUE; \
	}

// Simpler ways to enable/disable controls than the above macros
#define COMMAND_UI_DISABLE(id)					COMMAND_UI_DEFAULT((id), false)
#define COMMAND_UI_ENABLE(id)					COMMAND_UI_DEFAULT((id), true)
#define COMMAND_UI_DISABLE_RANGE(idLow, idHigh)	COMMAND_UI_DEFAULT_RANGE((idLow), (idHigh), false)
#define COMMAND_UI_ENABLE_RANGE(idLow, idHigh)	COMMAND_UI_DEFAULT_RANGE((idLow), (idHigh), true)


// Attila status bar types:
// If this were MFC world, these values would be the SBPS_xxx values.
// Since MFC has seen fit to define its own status bar styles, and those styles
// use some of the high bits in the normal SBT_xxx series, it seems to me that
// the Win32 common control guys are effectively prevented from defining new
// SBT_xxx codes with those values, lest they break legacy MFC code.  Therefore
// I think it is safe for me to define equivalent Attila status bar pane styles
// styles using the same bits.

#define ASBT_NORMAL			0x00000000
#define ASBT_NOBORDERS		SBT_NOBORDERS
#define ASBT_POPOUT			SBT_POPOUT
#define ASBT_OWNERDRAW		SBT_OWNERDRAW
#define ASBT_RTLREADING		SBT_RTLREADING
#if (_WIN32_IE >= 0x0400)
	#define	ASBT_TOOLTIPS	SBT_TOOLTIPS
#endif

// ...our custom styles

#define ASBT_DISABLED		0x04000000	// custom style: hides the text
#define ASBT_STRETCH	    0x08000000  // custom style stretch to fill status bar

// ASBT_CUSTOM: Defined to be the ANDing of only our custom styles not the Win32 ones

#define ASBT_CUSTOM			(ASBT_DISABLED | ASBT_STRETCH)

// =============================================================================
// CLASS CCmdUI -- abstract base class -- protocol for Command UI updating
// =============================================================================

class CCmdUI 
{
public:
						CCmdUI();
	virtual				~CCmdUI();


// Attributes
			UINT		m_nId;
			UINT		m_nIdx;		// menu item or other index

	// Operations for client code to do in ON_UPDATE_COMMAND_UI

	virtual	void		Enable(BOOL bOn=TRUE) = 0;
	virtual	void		SetCheck(int nCheck = 1) = 0;   // 0, 1 or 2 
	virtual	void		SetRadio(BOOL bOn) = 0;
	virtual	void		SetText(LPCTSTR szText) = 0;

			void		ContinueRouting();

	// Methods usually called by the framework, not the client code:

	virtual BOOL		DoUpdate(CMessageMap* pMap);// directly through map
	virtual BOOL		DoUpdate(HWND hWnd);		// via ::SendMessage
			bool		IsEnableChanged() const;
			bool		IsChanged(DWORD dwFlags) const;
			bool		ShouldRoutingContinue() const;

	// Implementation

	virtual void		Reset();					// call between each Update()

protected:
			DWORD		m_dwChanged;
			bool		m_bContinueRouting;
	enum
	{
		CMDUI_ENABLE,
		CMDUI_TEXT,
		CMDUI_RADIO,
		CMDUI_CHECK
	};
};

// -----------------------------------------------------------------------------
// CCmdUI -- inline methods
// -----------------------------------------------------------------------------
inline CCmdUI::CCmdUI()
{
	// zero out everything

	m_nId				= 0;
	m_nIdx				= 0;
	m_dwChanged			= 0;
	m_bContinueRouting	= false;
}
inline CCmdUI::~CCmdUI()
{
}

// ContinueRouting allows you to do partial updates in several places

inline void CCmdUI::ContinueRouting()
{
	m_bContinueRouting	= true;
}
inline bool	CCmdUI::ShouldRoutingContinue() const
{
	return m_bContinueRouting;
}
inline bool CCmdUI::IsEnableChanged() const
{
	return IsChanged(CMDUI_ENABLE);
}
inline bool CCmdUI::IsChanged(DWORD dwFlags) const
{
	return 0 != (m_dwChanged & dwFlags);
}
inline void CCmdUI::Reset()
{
	m_dwChanged	= 0;
}

// The safest way for a framework to do updates -- via SendMessage

inline BOOL CCmdUI::DoUpdate(HWND hWnd)
{
	ATLASSERT(::IsWindow(hWnd));

	Reset();

//	if (m_nId < 0 || LOWORD(m_nId) == 0xFFFF)
//		return TRUE;     // ignore invalid IDs

	LRESULT lResult		= 0;
	BOOL bResult		= ::SendMessage(hWnd,
										WM_CMDUI,
										m_nId,
										reinterpret_cast<LPARAM>(this));
	return bResult;
}

// If the framework calls this overload, 'pMap' must point to the
// ORIGINAL framework object, not just some temporary CWindow
// wrapper whipped up on the stack.

inline BOOL CCmdUI::DoUpdate(CMessageMap* pMap)
{
	ATLASSERT(NULL != pMap);

	if (m_nId == 0 || LOWORD(m_nId) == 0xFFFF)
		return TRUE;     // ignore invalid IDs

	Reset();
	LRESULT lResult		= 0;
	BOOL bResult = pMap->ProcessWindowMessage(NULL,
											  WM_CMDUI,
											  m_nId,
											  reinterpret_cast<LPARAM>(this), 
											  lResult,
											  0);
	if ( !bResult )
		ATLASSERT(m_dwChanged != 0);

	
	return bResult;
}




// =============================================================================
// CLASS CMenuCmdUI
// =============================================================================

class CMenuCmdUI : public CCmdUI
{
public:
// Attributes
			CMenuCmdUI(HMENU hMenu);

			// if a menu item
			const HMENU		m_hMenu;		// must not be NULL
			HMENU			m_hSubMenu;		// sub containing menu item
											//    if a popup sub menu -
											//    ID is for first in popup
			HMENU			m_hParentMenu;	// NULL if parent menu not easily determined
											//  (probably a secondary popup menu)

	// Operations to do in a COMMAND_UI_HANDLER

			void			Enable(BOOL bOn = TRUE);
			void			SetCheck(int nCheck = 1);   // 0, 1 or 2 (indeterminate)
			void			SetRadio(BOOL bOn = TRUE);
			void			SetText(LPCTSTR szText);
			bool			DoAllUpdates(HWND hWnd);
};

// -----------------------------------------------------------------------------
// CMenuCmdUI -- inline methods
// -----------------------------------------------------------------------------

inline CMenuCmdUI::CMenuCmdUI(HMENU hMenu) : m_hMenu(hMenu)
{
	m_hParentMenu		= NULL;
	m_hSubMenu			= NULL;
	Reset();
}


inline void CMenuCmdUI::Enable(BOOL bOn)
{
	ATLASSERT(NULL != m_hMenu);
	#define EMI_FAIL	0xFFFFFFFF
	if ( NULL == m_hSubMenu ) // leave popups alone (until they popup!)
	{
		UINT nEnable = MF_BYPOSITION | (bOn ? MF_ENABLED : (MF_DISABLED|MF_GRAYED));
		if ( EMI_FAIL == ::EnableMenuItem(m_hMenu, m_nIdx, nEnable) )
			ATLTRACE(_T("Cannot enable menu 0x%X item %d\n"), m_hMenu,  m_nIdx);
		else
			m_dwChanged |= CMDUI_ENABLE;
	}
}

inline void CMenuCmdUI::SetCheck(int nCheck)
{
	// Don't indirectly change popup menus

	if ( m_hMenu != NULL && NULL == m_hSubMenu )
	{
		MENUITEMINFO mii	= { sizeof(MENUITEMINFO), MIIM_CHECKMARKS | MIIM_STATE };

		if ( !::GetMenuItemInfo(m_hMenu, m_nId, FALSE, &mii) )
		{
			ATLTRACE(_T("Failed to get info for menu 0x%X, item 0x%X: 0x%X\n"),
				m_hMenu, m_nId, ::GetLastError());
		}
		else
		{
			DWORD dwOldState	= mii.fState;

			if ( nCheck != 0 )
				mii.fState	|= MFS_CHECKED;
			else
				mii.fState	&= (~MFS_CHECKED);

			mii.hbmpChecked	= NULL;

			if ( !SetMenuItemInfo(m_hMenu, m_nId, FALSE, &mii) )
			{
				ATLTRACE(_T("Failed to set info for menu 0x%X, item 0x%X: 0x%X\n"),
				m_hMenu, m_nId, ::GetLastError());
			}
			
			// Signal that the check state has changed, if it has

			if ( dwOldState != mii.fState )
				m_dwChanged |= CMDUI_CHECK;
		}
	}
}

const BYTE _theDot[]	= { 0x6,	//	00000110
							0xF,	//  00001111
							0xF,	//  00001111
							0xF,	//  00001111
							0x6 };	//  00000110

#define DOT_WIDTH   4
#define DOT_HEIGHT  5
// TODO: -- this is lifted from MFC but with the new menu CMD UI functions
// in Win32, we shouldn't need it.  There is already a way to make a menu 
// item radio style.  Need to investigate this more
inline bool LoadDotBitmap(HBITMAP& bmDot)
{
	int cx			= ::GetSystemMetrics(SM_CXMENUCHECK);
	int cy			= ::GetSystemMetrics(SM_CYMENUCHECK);
	if ( 32 < cx )
		cx = 32;
	if ( 32 < cy )
		cy = 32;


	int iwRow		= (cx + 15) / 16;		// # of WORDs per raster line
	int nShift		= (cx - DOT_WIDTH) / 2;	// # of bits to shift over
	nShift			+= ((iwRow * 16) - cx);// padding for word alignment

	if ( nShift > 16 - DOT_WIDTH )
		nShift		= 16 - DOT_WIDTH;		// maximum shift for 1 word


	BYTE byDot[sizeof(WORD) * 32 * 2];
	FillMemory(byDot, sizeof(byDot), 0xFF);
	BYTE* pbOut		= &byDot[iwRow * sizeof(WORD) * sizeof(cy-(DOT_HEIGHT+1)) >> 1];
	const BYTE* pbIn= _theDot;

	for (int y = 0; y < DOT_HEIGHT; y++)
	{
		WORD w		= (WORD)~(((DWORD)*pbIn++) << nShift);
		pbOut[0]	= HIBYTE(w);
		pbOut[1]	= LOBYTE(w);
		pbOut		+= iwRow * sizeof(WORD);
	}

	bmDot				= ::CreateBitmap(cx, cy, 1, 1, (LPVOID)&byDot);
	return NULL != bmDot;
}
inline void CMenuCmdUI::SetRadio(BOOL bOn)
{
	SetCheck(bOn); 
	if ( bOn && NULL != m_hMenu && NULL == m_hSubMenu )
	{
		static HBITMAP hbmDot	= NULL;
		static bool bTried		= false;
		if ( NULL == hbmDot && !bTried )
		{
			bTried = true;
			LoadDotBitmap(hbmDot);
		}

		if ( NULL != hbmDot )
			SetMenuItemBitmaps(m_hMenu, m_nIdx, MF_BYPOSITION, NULL, hbmDot);
	}
}



inline void CMenuCmdUI::SetText(LPCTSTR szText)
{
	#define GMS_FAIL	0xFFFFFFFF	// more descriptive than 0xFFFFFFFF
	ATLASSERT(NULL != szText);
	ATLASSERT(!IsBadStringPtr(szText, 100)); 

	if ( NULL != m_hMenu )
	{
		if ( NULL == m_hSubMenu ) // Don't change popup menus indirectly
		{
			UINT nState		= ::GetMenuState(m_hMenu, m_nIdx, MF_BYPOSITION);
			if ( GMS_FAIL == nState )
			{
				ATLTRACE(_T("Menu 0x%X item %d not found\n"), m_hMenu, m_nIdx);
			}
			else
			{
				// We don't care about about bitmaps, owner-draw, or separators

				nState			&= ~(MF_BITMAP|MF_OWNERDRAW|MF_SEPARATOR);
				UINT nFlags		= MF_BYPOSITION | MF_STRING | nState;

				if ( !::ModifyMenu(m_hMenu, m_nIdx, nFlags, m_nId, szText) )
					ATLTRACE(_T("Failed to modify menu 0x%X -- reason 0x%X\n"),
							 m_hMenu, ::GetLastError());
			}
		}
	}

	// Flickering is not really an issue with menus, so if this is called, we
	// can just assume that the item state was changed

	m_dwChanged |= CMDUI_TEXT;
}

// -----------------------------------------------------------------------------
// FUNCTION: CMenuCmdUI::DoAllUpdates
// REMARKS:
//		Here we update all items in the menu that just popped up
//
// PARAMETERS:
//		hWnd - the target window (to which we send the WM_CMDUI message)
// -----------------------------------------------------------------------------
inline bool CMenuCmdUI::DoAllUpdates(HWND hWnd)
{
	// Handle our possible short circuits.  The method returns FALSE, regardless.

	ATLASSERT(::IsMenu(m_hMenu));

	if ( !::IsMenu(m_hMenu) )
		return false;
	else if ( NULL == hWnd )// If there's no window, there's not much point
		return false;

	CWindow wnd(hWnd);

	// Look to see if we can find a parent menu for it.  Note - MFC did some
	// checking for a menu being popup in a top level window.  Not sure if
	// it was necessary

	HMENU hParentMenu = wnd.GetMenu();

	if ( NULL == hParentMenu )
	{
		CWindow wndParent(wnd.GetTopLevelParent());

		if ( NULL != wndParent.m_hWnd && NULL != (hParentMenu = wndParent.GetMenu())  )
		{
			// Child windows don't have menus go up til we find a non-child or we're done

			int nParentIdxMax = ::GetMenuItemCount(hParentMenu);
			for ( int nIdx = 0; nIdx < nParentIdxMax && NULL == m_hParentMenu; nIdx++ )
			{	
				if ( ::GetSubMenu(hParentMenu, nIdx) == m_hMenu )
					m_hParentMenu = hParentMenu;
			}
		}
	}

	UINT nIdxMax		= ::GetMenuItemCount(m_hMenu);

	for ( m_nIdx=0; m_nIdx < (UINT)nIdxMax; m_nIdx++ )
	{
		#define GMII_NULL_OR_OPENS_SUB 0xFFFFFFFF // a tad more descriptive
		m_nId			= ::GetMenuItemID(m_hMenu, m_nIdx);

		if ( 0 != m_nId )
		{
			if ( GMII_NULL_OR_OPENS_SUB == m_nId )
			{
				// Might open a submenu.  Try to route to first item of that popup

				m_hSubMenu = ::GetSubMenu(m_hMenu, m_nIdx);

				if ( NULL == m_hSubMenu ||
					(m_nId = ::GetMenuItemID(m_hSubMenu, 0)) == 0 ||
					GMII_NULL_OR_OPENS_SUB == m_nId)
				{
					continue;       // first item of popup can't be routed to
				}
				DoUpdate(hWnd);    // popups are never auto disabled
			}
			else
			{
				// normal menu item

				m_hSubMenu = NULL;
				DoUpdate(hWnd);
			}

			// If something was added or deleted from the menu, we need to adjust now

			UINT nCount			= ::GetMenuItemCount(m_hMenu);
			if ( nCount < nIdxMax )
			{
				m_nIdx -= (nIdxMax - nCount);
				while ( m_nIdx < nCount &&
					    ::GetMenuItemID(m_hMenu, m_nIdx) == m_nId )
				{
					m_nIdx++;
				}
			}
			nIdxMax = nCount;
			Reset();
		}
	}
	return true;
}

// =============================================================================
// CLASS CWindowCmdUI -- really mainly for dialogs containing controls but
//						 could be any kind of window.
// =============================================================================

class CWindowCmdUI : public CCmdUI
{
public:
			CWindowCmdUI(CWindow* pWnd);

			CWindow* const	m_pWnd;
			CWindow*		m_pCtl;
			void			Enable(BOOL bOn = TRUE);
			void			SetCheck(int nCheck = 1);   // 0, 1 or 2 (indeterminate)
			void			SetRadio(BOOL bOn = TRUE);
			void			SetText(LPCTSTR szText);
			bool			DoAllUpdates(HWND hWnd);

};

// -----------------------------------------------------------------------------
// CWindowCmdUI -- inline methods
// -----------------------------------------------------------------------------

inline CWindowCmdUI::CWindowCmdUI(CWindow* pWnd) : m_pWnd(pWnd)
{
}
inline void CWindowCmdUI::Enable(BOOL bOn)
{
	ATLASSERT(NULL != m_pCtl);

	// MFC trick (aren't they all?):  If the control to be disabled
	// has the focus, set the focus to the next control first.

	if ( !bOn &&  ::GetFocus() == m_pCtl->m_hWnd )
	{
		CWindow wndParent(m_pCtl->GetParent());
		::SetFocus(wndParent.GetNextDlgTabItem(m_pCtl->m_hWnd, FALSE));
	}

	m_pCtl->EnableWindow(bOn);
}
inline void CWindowCmdUI::SetCheck(int nCheck)
{
	ATLASSERT(NULL != m_pCtl);

	// Can only check it if it's a button


	if ( 0 != (m_pCtl->SendMessage(WM_GETDLGCODE) & DLGC_BUTTON) )
	{
		// If the check state is changing, set the appropriate bit

		if ( m_pCtl->SendMessage(BM_GETCHECK) != nCheck )
			m_dwChanged |= CMDUI_CHECK;

		// ...and change the state.

	 	m_pCtl->SendMessage(BM_SETCHECK, nCheck);
	}
}
inline void CWindowCmdUI::SetRadio(BOOL bOn)
{
	ATLASSERT(NULL != m_pCtl);
}
inline void CWindowCmdUI::SetText(LPCTSTR szText)
{
	ATLASSERT(NULL != m_pCtl);

	// MFC trick:  don't set text if it is not changing -- avoids flash

	TCHAR szBuf[256];
	m_pCtl->GetWindowText(szBuf, 255);
	if ( 0 != lstrcmp(szText, szBuf) )
	{
		m_pCtl->SetWindowText(szText);
		m_dwChanged		|= CMDUI_TEXT;
	}
}
inline bool CWindowCmdUI::DoAllUpdates(HWND hwTarget)
{
	CWindow wndTarget(NULL == hwTarget ? m_pWnd->m_hWnd : hwTarget);

	if ( NULL == wndTarget.m_hWnd )
		return false;

	DWORD dwChanged		= 0;

	// Walk all child windows - assume the IDs are for buttons

	for ( HWND hWndChild	= wndTarget.GetTopWindow();
		  hWndChild != NULL;
		  hWndChild			= ::GetNextWindow(hWndChild, GW_HWNDNEXT))
	{
		CWindow wndChild(hWndChild);
		m_pCtl				= &wndChild;
		m_nId				= (UINT)::GetDlgCtrlID(hWndChild);

		// MFC checks for relect handlers around here.  We don't have message
		// reflection so we cannot

		if ( NULL != hWndChild )
		{
			if ( !DoUpdate(wndChild.m_hWnd) )
				DoUpdate(hwTarget);

			// MFC would automatically disable any control that had no command
			// handler (with some exceptions).  However in Attila we cannot
			// determine at runtime whether or not command handlers exist so
			// we'll just leave everything enabled by default.
		}

		dwChanged |= m_dwChanged;

		// JMO: This does not appear to be needed so for now it's commented out.
		
		//if ( 0 != m_dwChanged )
		//	m_pCtl->RedrawWindow();
	}

	return true;
}

// =============================================================================
// CLASS: CStatusBarCtrlCmdUI
// REMARKS:
//		This class implements the CCmdUI interface on status bars
// =============================================================================

class CStatusBarCtrlCmdUI : public CCmdUI
{
public:
			CStatusBarCtrlCmdUI (ATLControls::CStatusBarCtrl* pCtrl);

			// Operations to do in WM_CMDUI notifications

			void		Enable(BOOL bOn=TRUE);
			void		SetCheck(int nCheck=1);
			void		SetRadio(BOOL bOn=TRUE);
			void		SetText(LPCTSTR szText);

			// Stuff that only the originator calls

			bool		DoAllUpdates(HWND hwTarget);
			
protected:
			ATLControls::CStatusBarCtrl* const	m_pCtrl;
};

// -----------------------------------------------------------------------------
// CStatusBarCtrlCmdUI -- inline methods
// -----------------------------------------------------------------------------
inline bool CStatusBarCtrlCmdUI::DoAllUpdates(HWND hwTarget)
{
	UINT nParts			= m_pCtrl->GetParts(0, NULL);
	DWORD dwChanged		= 0;

	for (m_nIdx=0; m_nIdx < nParts; m_nIdx++)
	{
		Reset();
		m_nId	= m_pCtrl->SendMessage(WM_SBGETPANECMDID, m_nIdx, 0);
		if ( !DoUpdate(static_cast<HWND>(*m_pCtrl)) )
			DoUpdate(hwTarget);

		dwChanged |= m_dwChanged;
	}
	
	// If text or enabled state has changed, redraw the window.  Note that
	// enabling/disabling a status bar pane means showing/hiding its text

	if ( 0 != dwChanged )
		m_pCtrl->RedrawWindow();

	return true;

}

inline CStatusBarCtrlCmdUI::CStatusBarCtrlCmdUI(ATLControls::CStatusBarCtrl* pCtrl)
	: m_pCtrl(pCtrl)
{
	ATLASSERT(NULL != m_pCtrl);
	ATLASSERT(m_pCtrl->IsWindow());
}

inline void CStatusBarCtrlCmdUI::Enable(BOOL bOn)
{
	ATLASSERT(NULL != m_pCtrl);
	ATLASSERT(m_pCtrl->IsWindow());

	UINT nStyleOld	= m_pCtrl->SendMessage(WM_SBGETPANESTYLE, m_nIdx, 0);
	UINT nStyleNew	= nStyleOld;

	if ( bOn )
		nStyleNew	&= ~ASBT_DISABLED;
	else
		nStyleNew	|= ASBT_DISABLED;

	if ( nStyleNew != nStyleOld )
		m_dwChanged |= CMDUI_ENABLE;

	m_pCtrl->SendMessage(WM_SBSETPANESTYLE, m_nIdx, nStyleNew);
}

inline void CStatusBarCtrlCmdUI::SetCheck(int nCheck)
{
	ATLASSERT(NULL != m_pCtrl);
	ATLASSERT(m_pCtrl->IsWindow());
	int nTypeOld	= 0;
	int nLen		= m_pCtrl->GetTextLength(m_nIdx, &nTypeOld);
	int nTypeNew	= nTypeOld;
	ATLASSERT(nLen < 256);

	// Determine the new state of the SBT_POPOUT flag

	if ( nCheck > 0 )
	{
		if ( 0 != (nTypeNew & SBT_POPOUT) )
			nTypeNew &= ~SBT_POPOUT;
	}
	else
	{

		if ( 0 == (nTypeNew & SBT_POPOUT) )
			nTypeNew |= SBT_POPOUT;
	}
	
	// However only actually do the updating if the check style has changed.

	if ( nTypeNew != nTypeOld )
	{
		m_dwChanged	|= CMDUI_CHECK;
		TCHAR szBuf[256];
		m_pCtrl->GetText(m_nIdx, szBuf);
		m_pCtrl->SetText(m_nIdx, szBuf, nTypeNew);
	}
}
inline void CStatusBarCtrlCmdUI::SetRadio(BOOL bOn)
{
	ATLASSERT(NULL != m_pCtrl);
	ATLASSERT(m_pCtrl->IsWindow());
	SetCheck(bOn ? 1 : 0);
}
inline void CStatusBarCtrlCmdUI::SetText(LPCTSTR szText)
{
	ATLASSERT(NULL != m_pCtrl);
	ATLASSERT(m_pCtrl->IsWindow());

	TCHAR szBuf[256];
	m_pCtrl->GetText(m_nIdx, szBuf);
	if ( 0 != lstrcmp(szText, szBuf) )
	{
		m_pCtrl->SetText(m_nIdx, szText, 0);
		m_dwChanged		|= CMDUI_TEXT;
	}
	// TODO -- account for varying types of drawing
	//         such as owner-drawn status bars
}



// =============================================================================
// CLASS CToolBarCtrlCmdUI
// REMARKS:
//		This class CCmdUI derivative is meant for control
// =============================================================================
class CToolBarCtrlCmdUI : public CCmdUI
{
public:
			CToolBarCtrlCmdUI(ATLControls::CToolBarCtrl* pCtrl);


			// Operations to do in WM_CMDUI notifications

			void		Enable(BOOL bOn = TRUE);
			void		SetCheck(int nCheck = 1);   // 0, 1 or 2 (indeterminate)
			void		SetRadio(BOOL bOn = TRUE);
			void		SetText(LPCTSTR szText);

			// Stuff that only the originator calls

			bool		DoAllUpdates(HWND hwTarget);

protected:
			ATLControls::CToolBarCtrl* const m_pCtrl;
};


// -----------------------------------------------------------------------------
// CToolBarCtrlCmdUI -- inline methods
// -----------------------------------------------------------------------------
inline CToolBarCtrlCmdUI::CToolBarCtrlCmdUI(ATLControls::CToolBarCtrl* pCtrl)
	: m_pCtrl(pCtrl)
{
	ATLASSERT(NULL != m_pCtrl);
	ATLASSERT(m_pCtrl->IsWindow());
}
inline void CToolBarCtrlCmdUI::Enable(BOOL bOn)
{
	ATLASSERT(NULL != m_pCtrl);
	ATLASSERT(m_pCtrl->IsWindow());
	if ( m_pCtrl->IsButtonEnabled(m_nId) != bOn )
		m_dwChanged |= CMDUI_ENABLE;

	m_pCtrl->EnableButton(m_nId, bOn);
}

inline void CToolBarCtrlCmdUI::SetCheck(int nCheck)
{
	ATLASSERT(NULL != m_pCtrl);
	ATLASSERT(m_pCtrl->IsWindow());
	if ( nCheck > 1 )
		m_pCtrl->Indeterminate(m_nId, TRUE);
	else
		m_pCtrl->CheckButton(nCheck != 0);
}
inline void CToolBarCtrlCmdUI::SetRadio(BOOL bOn)
{
	ATLASSERT(NULL != m_pCtrl);
	ATLASSERT(m_pCtrl->IsWindow());
	m_pCtrl->CheckButton(m_nId, bOn);
}
inline void CToolBarCtrlCmdUI::SetText(LPCTSTR szText)
{
	ATLASSERT(NULL != m_pCtrl);
	ATLASSERT(m_pCtrl->IsWindow());

	TCHAR szBuf[256];
	TBBUTTONINFO tbbi = {sizeof(TBBUTTONINFO), TBIF_TEXT, 0, 0, 0, 0, 0, 0, szBuf, 255 };
	m_pCtrl->GetButtonInfo(m_nId, &tbbi);

	if ( 0 != lstrcmp(szText, tbbi.pszText) )
	{
		tbbi.pszText = const_cast<PTSTR>(szText);
		m_pCtrl->SetButtonInfo(m_nId, &tbbi);
		m_dwChanged		|= CMDUI_TEXT;
	}
}


inline bool CToolBarCtrlCmdUI::DoAllUpdates(HWND hwTarget)
{
	UINT nIdxMax	= m_pCtrl->GetButtonCount();

	for ( m_nIdx = 0; m_nIdx < nIdxMax; m_nIdx++ )
	{
		TBBUTTON tbb;
		ZeroMemory(&tbb, sizeof(TBBUTTON));

		if ( !m_pCtrl->GetButton(m_nIdx, &tbb) )
			ATLTRACE(_T("Unable to get info for button %d\n"), m_nIdx);
		else
			m_nId = tbb.idCommand;

		if ( 0 == (tbb.fsStyle & TBSTYLE_SEP) )
		{
			// MFC checks for reflections in the sending window at this
			// point (in our case, that would be m_ctrl).  However I don't
			// know how we would do this.

			DoUpdate(hwTarget);							
		}
	}
	return true;
}






// =============================================================================
// CLASS TEMPLATE: CIdleUIWindowT
// REMARKS:
//		A simple way of declaring some kind of attila control=bar class
//		derivative that's ready for WM_IDLECMDUI Requires the class to have a
//		default constructor.   If it doesn't you can reproduce this stuff easily
//		enough.
//
// PARAMETERS:
//		TBase - the name of the base, CWindow derived class.  
//		TCmdUI - the name of the CCmdUI class for handling command UI stuff
// =============================================================================

template <typename TBase, typename TCmdUI>
class CIdleUIWindowT : public TBase
{
	typedef	CIdleUIWindowT<TBase, TCmdUI>	thisClass;
	typedef TBase							baseClass;

public:
	CIdleUIWindowT()
	{
	}
	~CIdleUIWindowT()
	{
	}
	BEGIN_MSG_MAP(thisClass)
		MESSAGE_HANDLER(WM_IDLECMDUI, OnIdleCmdUI)
		CHAIN_MSG_MAP(baseClass)
	END_MSG_MAP()
	LRESULT OnIdleCmdUI(UINT, WPARAM, LPARAM, BOOL& bHandled);
};

// TODO -- we find the first parent frame by checking for the window styles
// WS_EX_APPWINDOW or WS_EX_MDICHILD.  This is not a very good way of checking.
// We need a better way to find the AttilaFrame that surrounds us so we can
// plug the WM_CMDUI message into the Attila framework.
// MFC has it easier, every window has an IsFrameWindow() function.

template<typename TWindow>
inline bool IsAttilaFrameWindow(TWindow& wnd)
{
	return 0 != (wnd.GetStyle() & (WS_EX_APPWINDOW | WS_EX_MDICHILD) );
}

template<typename TBase, typename TCmdUI>
LRESULT CIdleUIWindowT<TBase, TCmdUI>::OnIdleCmdUI(UINT, WPARAM, LPARAM, BOOL& bHandled)
{
	bHandled		= FALSE;
	bool bFound		= false;
	CWindow wnd		= GetParent();

	while ( !bFound && wnd.IsWindow() )
	{
		bFound		= IsAttilaFrameWindow(wnd);
		if ( !bFound )
			wnd = wnd.GetParent();
	};
	if ( bFound )
	{
		TCmdUI cmdUI(this);
		cmdUI.DoAllUpdates(wnd);
	}
	return 0;
}

// =============================================================================
// CLASS TEMPLATE: CCmdUIDlgT
// REMARKS:
//		
//
// PARAMETERS:
//		TBase - the name of the baseclass, derived from CDialogImpl.  
//		TCmdUI - the name of the CCmdUI class for handling command UI stuff
// =============================================================================
template <typename TDlg, typename TCmdUI=CWindowCmdUI>
class CCmdUIDlgT : public TDlg
{
	typedef	CCmdUIDlgT<TDlg, TCmdUI>	thisClass;
	typedef TDlg						baseClass;

public:

	BEGIN_MSG_MAP(thisClass)
		MESSAGE_HANDLER(WM_IDLECMDUI, OnIdleCmdUI)
		CHAIN_MSG_MAP(baseClass)
	END_MSG_MAP()

					CCmdUIDlgT();
					~CCmdUIDlgT();
		LRESULT		OnIdleCmdUI(UINT, WPARAM, LPARAM, BOOL& bHandled);
};

template <typename TDlg, typename TCmdUI>
CCmdUIDlgT<TDlg, TCmdUI>::CCmdUIDlgT()
{
}
template <typename TDlg, typename TCmdUI>
CCmdUIDlgT<TDlg, TCmdUI>::~CCmdUIDlgT()
{
	ATLASSERT(!::IsWindow(m_hWnd));
}

template <typename TDlg, typename TCmdUI>
LRESULT	CCmdUIDlgT<TDlg, TCmdUI>::OnIdleCmdUI(UINT, WPARAM, LPARAM, BOOL& bHandled)
{
	bHandled		= FALSE;
	if ( ::IsWindow(m_hWnd) )
	{
		TCmdUI cmdUI(this);
		cmdUI.DoAllUpdates(m_hWnd);
	}
	return 0;
}






// =============================================================================
// CLASS: CStatusBarPane
//
// REMARKS:
//		This is a support class, used by the CCmdUIStatusBar<> template (which
//		is defined below).  It helps simplify the CCmdUIStatusBar methods.  Its
//		member variables allow us to avoid having to dynamically allocate a lot
//		of memory every time we need to resize the panes.
// =============================================================================
#define STRING_WIDTH_EXTRA	6	// because GetTextExtentPoint32 is just not accurate enough

class CStatusBarPane
{
public:
	UINT	m_nCmdId;
	LPTSTR	m_pText;
	int		m_nWidth;
	int		m_nType;

				CStatusBarPane();
				~CStatusBarPane();
	bool		Initialize(UINT nCmdId, HDC hdcScreen);
};
inline CStatusBarPane::CStatusBarPane()
{
	m_nCmdId		= 0;
	m_pText			= NULL;
	m_nWidth		= 0;
	m_nType			= ASBT_NORMAL;
}
// Initialize: Load the string resource and calculate initial width
inline bool CStatusBarPane::Initialize(UINT nCmdId, HDC hdcScreen)
{
	m_nCmdId			= nCmdId;
	bool bSuccess		= false;

	if ( 0 != nCmdId )
	{
		// Get the resource name via MAKEINTRESOURCE.  

		LPCTSTR szResName	= MAKEINTRESOURCE((m_nCmdId>>4)+1);
		HRSRC hrsrc			= NULL;
		HINSTANCE hModule	= ::GetModuleHandle(NULL);
		DWORD dwSize		= 0;
		SIZE size;

		if ( NULL == (hrsrc=::FindResource(hModule, szResName, RT_STRING)) )
			ATLTRACE(_T("Warning: failed to find indicator string 0x%04X.\n"), m_nCmdId);
		else if ( 0 == (dwSize=::SizeofResource(hModule, hrsrc)) )
			ATLTRACE(_T("Warning: zero sized indicator string 0x%04X.\n"), m_nCmdId);
		else if ( NULL == (m_pText=new TCHAR[dwSize+sizeof(TCHAR)]) )
			ATLTRACE(_T("Unable to allocate memory: 0x%X\n"), ::GetLastError());
		else if ( !::LoadString(hModule, m_nCmdId, m_pText, dwSize/sizeof(TCHAR)) )
			ATLTRACE(_T("Warning: failed to load indicator string 0x%04X.\n"), m_nCmdId);
		else if ( !::GetTextExtentPoint32(hdcScreen, m_pText, lstrlen(m_pText) * sizeof(TCHAR), &size) )
			ATLTRACE(_T("Unable to determine string width\n"));
		else
		{
			m_nWidth	= STRING_WIDTH_EXTRA + size.cx;
			bSuccess	= true;
		}
	}
	else
	{
		m_pText			= new TCHAR[1];
		bSuccess		= true;
		m_nType			|= ASBT_NOBORDERS;
	}
	return bSuccess;
}
inline CStatusBarPane::~CStatusBarPane()
{
	if ( NULL != m_pText )
		delete [] m_pText;
}

// =============================================================================
// CLASS TEMPLATE CCmdUIStatusBar
// REMARKS:
//		This template allows one to graft command UI handling capabilities on
//		to an existing CStatusBar-derived class (or CStatusBar itself).
//
//		The CIdleUIWindowT template (above) adds idle time command UI processing to
//
// PARAMETERS:
//		TBarBase -	the name of the base, CStatusBar derived class.  Defaults to
//					CStatusBar.  However if you have some customized derivative
//					of CStatusBar, replace this parameter with it
//		TCmdUI - the name of the CCmdUI class for handling status bar CCmdUI
//				 stuff.  This is in case CStatusBarCtrlCmdUI doesn't cut the
//				 mustard for your purposes. Write your own, if you want
// =============================================================================

template<typename TBarBase=CStatusBar, typename TCmdUI=CStatusBarCtrlCmdUI>
class CCmdUIStatusBarT : public CIdleUIWindowT<TBarBase, TCmdUI>
{
	typedef CIdleUIWindowT<TBarBase, TCmdUI>		baseClass;
	typedef CCmdUIStatusBarT<TBarBase, TCmdUI>	thisClass;

	CStatusBarPane*	m_pPanes;
	UINT		m_nPanes;
	bool		m_bDisableHandler;


public:

	BEGIN_MSG_MAP(thisClass)
		MESSAGE_HANDLER(WM_SBGETPANECMDID, OnGetPaneCmdId)
		MESSAGE_HANDLER(SB_SETTEXT, OnSetTextIntercept)
		MESSAGE_HANDLER(SB_SETPARTS, OnSetPartsIntercept)
		MESSAGE_HANDLER(WM_SIZE, OnSizeIntercept)
		MESSAGE_HANDLER(WM_SBGETPANESTYLE, OnGetPaneStyle)
		MESSAGE_HANDLER(WM_SBSETPANESTYLE, OnSetPaneStyle)
		CHAIN_MSG_MAP(baseClass)
	END_MSG_MAP()

			LRESULT OnSetTextIntercept(UINT, WPARAM, LPARAM, BOOL&);
			LRESULT OnSetPartsIntercept(UINT, WPARAM, LPARAM, BOOL&);
			LRESULT OnSizeIntercept(UINT, WPARAM, LPARAM, BOOL&);
			LRESULT OnGetPaneCmdId(UINT, WPARAM, LPARAM, BOOL&);
			LRESULT OnGetPaneStyle(UINT, WPARAM, LPARAM, BOOL&);
			LRESULT OnSetPaneStyle(UINT, WPARAM, LPARAM, BOOL&);

					CCmdUIStatusBarT();
					~CCmdUIStatusBarT();
			BOOL	SetIndicators(const UINT* pIds, int nIdCount);
			BOOL	UpdatePanes();
			void	SetPaneInfo(int nIdx, UINT nCmdId, UINT nStyle, int cxWidth);
			void	SetPaneStyle(int nIdx, UINT nStyle);
			UINT	GetPaneStyle(int nIdx) const;
};
template<typename TBarBase, typename TCmdUI>
CCmdUIStatusBarT<TBarBase, TCmdUI>::CCmdUIStatusBarT()
	: m_pPanes(NULL), m_nPanes(0), m_bDisableHandler(false)
{
}
template<typename TBarBase, typename TCmdUI>
inline CCmdUIStatusBarT<TBarBase, TCmdUI>::~CCmdUIStatusBarT()
{
	if ( NULL != m_pPanes )
		delete [] m_pPanes;

}

// SetPaneInfo:  much like CStatusBar's function of the same name
template<typename TBarBase, typename TCmdUI>
void SetPaneInfo(int nIdx, UINT nCmdId, UINT nStyle, int cxWidth)
{
	if ( nIdx < m_nPanes )
	{
		CStatusBarPane& pane	= m_pPanes[nIdx];
		pane.m_nCmdId	= nCmdId;
		pane.m_nWidth	= cxWidth;
		SetPaneStyle(nIdx, nStyle);
	}
}
// GetPaneStyle/SetPaneStyle: Just like MFC's CStatusBar functions of
// the same name.  The main difference is that our custom styles start
// with an "ASBT_" prefix instead of an "SBPS_" prefix.
template<typename TBarBase, typename TCmdUI>
UINT CCmdUIStatusBarT<TBarBase, TCmdUI>::GetPaneStyle(int nIdx) const
{
	return (UINT)nIdx < m_nPanes  ? m_pPanes[nIdx].m_nType : 0;
}

// SetPaneStyle: Just like MFC's CStatusBar::SetPaneStyle.  The only
// difference is that our custom styles start with an "ASBT_" prefix
// instead of an "SBPS_" prefix
// The normal Win32 SBT_xxx values work just fine too.
template<typename TBarBase, typename TCmdUI>
void CCmdUIStatusBarT<TBarBase, TCmdUI>::SetPaneStyle(int nIdx, UINT nStyle)
{
	if ( (UINT)nIdx < m_nPanes )
	{
		CStatusBarPane& pane	= m_pPanes[nIdx];
		UINT nOldStyle	= pane.m_nType;

		// In a fight between stretchy style and owner-drawn style, owner-drawn wins.

		if ( 0 != (nStyle & ASBT_STRETCH) && 0 != (nStyle & ASBT_OWNERDRAW) )
			nStyle &= ~ ASBT_STRETCH;

		pane.m_nType	= nStyle;
		if ( 0 == (nStyle & ASBT_OWNERDRAW) )
			SetText(nIdx, pane.m_pText, nStyle);

		// If we turned on stretchy style, recalculate the layout.

		if ( 0 == (nOldStyle & ASBT_STRETCH) && 0 != (nStyle & ASBT_STRETCH) )
			UpdatePanes();
	}
}

template<typename TBarBase, typename TCmdUI>
LRESULT CCmdUIStatusBarT<TBarBase, TCmdUI>::OnSizeIntercept(UINT,
															WPARAM wParam,
															LPARAM lParam,
															BOOL& bHandled)
{
	bHandled				= FALSE;
	if ( 0 != m_nPanes )
		UpdatePanes();

	return 0;
}
// METHOD: OnSetTextIntercept
// REMARKS:
//		Intercept SB_SETTEXT in order to keep our idea of the text and style up to date
//		with what the underlying control has.  Better to do the heap allocation for our
//		copy of the string here, on the relatively infrequent SB_SETTEXT messages than
//		every time we need to recalculate the pane widths.

template<typename TBarBase, typename TCmdUI>
LRESULT CCmdUIStatusBarT<TBarBase, TCmdUI>::OnSetTextIntercept(UINT,
															   WPARAM wParam,
															   LPARAM lParam,
															   BOOL& bHandled)
{
	bHandled						= FALSE;
	UINT nPane						= wParam & 0x000000FF;
	UINT nType						= wParam & ~0xFFFFFF00;

	if ( !m_bDisableHandler && nPane < m_nPanes )
	{
		CStatusBarPane& pane		= m_pPanes[nPane];

		// Take the new style, but only change the standard, non-custom bits.  The only way to
		// change the custom styles is through a call to SetPaneStyle()

		pane.m_nType				&= ASBT_CUSTOM;
		pane.m_nType				|= (nType & ~ASBT_CUSTOM);


		if ( 0 == (nType & SBT_OWNERDRAW) )	// for owner-drawn panes, lParam could be anything
		{
			bool bTextChanged		= false;

			// Get the string.  Avoid NULLs

			LPCTSTR pText			= reinterpret_cast<LPTSTR>(lParam);
			if ( NULL == pText )
				pText				= _T("");

			if ( NULL == pane.m_pText || 0 != lstrcmp(pane.m_pText, pText) )
			{
				// Free any previous text that may be there

				if ( NULL != pane.m_pText )
					delete [] pane.m_pText;

				// ...and copy in the new text.
				 
				pane.m_pText		= new TCHAR[lstrlen(pText)+1];
				lstrcpy(pane.m_pText, pText);
				bTextChanged		= true;
			}

			// A "disabled" status bar pane simply shows no text.

			if ( pane.m_nType & ASBT_DISABLED && lstrlen(pane.m_pText) > 0  )
			{
				bHandled			= true;		// prevent the message from actually reaching the control
				m_bDisableHandler	= true;		// we're about to set the text, let our settext handler know
				SetText(nPane, _T(""), nType);
				m_bDisableHandler	= false;	// reallow future messages to reach their controls
			}

			if ( bTextChanged && 0 != (pane.m_nType & ASBT_STRETCH) )
				UpdatePanes();
		}
	}
	return 0;
}
template<typename TBarBase, typename TCmdUI>
LRESULT CCmdUIStatusBarT<TBarBase, TCmdUI>::OnSetPartsIntercept(UINT,
																WPARAM wParam,
																LPARAM lParam,
																BOOL& bHandled)
{
	// If we are not in the middle of setting the indicators and the number of parts
	// does not match the number of panes we've set up, they're doing this out of band

	bHandled				= FALSE;
	if ( !m_bDisableHandler && m_nPanes != wParam && 0 != m_nPanes )
	{
		ATLTRACE(_T("CCmdUIStatusBar -- received SB_SETPARTS outside of SetIndicators()\n"));
		ATLTRACE(_T("Command UI Updating may no longer work properly for this status bar\n"));
		delete [] m_pPanes;
		m_nPanes			= 0;
	}
	return 0;

}

// OnGetPaneStyle/OnSetPaneStyle
// Since the CCmdUI object that deals with us cannot know whether or not we are
// a CCmdUIStatusBarT or some other type of statusbar, we allow it to get and
// set the pane styles via custom window messages, rather than virtual functions
template<typename TBarBase, typename TCmdUI>
LRESULT CCmdUIStatusBarT<TBarBase, TCmdUI>::OnGetPaneStyle(UINT,
														   WPARAM wParam,
														   LPARAM lParam,
														   BOOL& bHandled)
{
	UINT nIdx				= wParam;
	bHandled				= TRUE;
	return GetPaneStyle(nIdx);
}
template<typename TBarBase, typename TCmdUI>
LRESULT CCmdUIStatusBarT<TBarBase, TCmdUI>::OnSetPaneStyle(UINT,
														   WPARAM wParam,
														   LPARAM lParam,
														   BOOL& bHandled)
{
	UINT nIdx				= wParam;
	UINT nStyle				= lParam;
	bHandled				= TRUE;
	SetPaneStyle(nIdx, nStyle);
	return 0;
}

// OnGetPaneCmdId: Another custom windows message handler.  Given a pane
// index, retrieve the comannd ID for it.
template<typename TBarBase, typename TCmdUI>
LRESULT CCmdUIStatusBarT<TBarBase, TCmdUI>::OnGetPaneCmdId(UINT,
														   WPARAM wParam,
														   LPARAM,
														   BOOL& bHandled)
{
	UINT nIdx				= wParam;
	UINT nCmdId				= 0;
	if ( nIdx < m_nPanes && NULL != m_pPanes )
		nCmdId				= m_pPanes[nIdx].m_nCmdId;

	return nCmdId;
}

			
// SetIndicators -- allow the user to assign COMMAND IDs to each pane  of the
// status bar for CMDUI processing. Just like MFC's CStatusBar function of the
// same name
template<typename TBarBase, typename TCmdUI>
BOOL CCmdUIStatusBarT<TBarBase, TCmdUI>::SetIndicators(const UINT* pIds, int nIdCount)
{
	ATLASSERT(nIdCount >= 1);
	ATLASSERT(::IsWindow(m_hWnd));
	if ( 0 == nIdCount || NULL == pIds )
		return FALSE;

	HANDLE hHeap			= GetProcessHeap();
	UINT nBytes				= sizeof(CStatusBarPane) * nIdCount;
	UINT nIdx				= 0;

	if ( NULL != m_pPanes )
		::HeapFree(hHeap, 0, m_pPanes);

	// Allocate the pane objects.  They don't do much besides hold data we need.

	m_nPanes				= nIdCount;
	m_pPanes				= new CStatusBarPane[m_nPanes];

	// To calculate the widths of strings, we need the correct font selected.

	HFONT hFont				= (HFONT)SendMessage(WM_GETFONT);
	HDC hdcScreen			= ::GetDC(NULL);
	HGDIOBJ hOldFont		= NULL;

	if ( NULL != hFont)
		hOldFont		= ::SelectObject(hdcScreen, hFont);

	LPVOID pVoid			= ::HeapAlloc(hHeap, HEAP_ZERO_MEMORY, sizeof(int) * m_nPanes);
	int* rights				= reinterpret_cast<int*>(pVoid);
	m_bDisableHandler		= true;		// disable the SB_SETPARTS handler sanity check

	SetParts(m_nPanes, rights);
	::HeapFree(hHeap, 0, pVoid);

	for (nIdx=0; nIdx < m_nPanes; nIdx++)
	{
		CStatusBarPane& pane= m_pPanes[nIdx];
		pane.Initialize(pIds[nIdx], hdcScreen);
		SetText(nIdx, pane.m_pText, pane.m_nType);
	}

	m_bDisableHandler		= false;	// reenable the SB_SETPARTS handler sanity check

	if ( NULL == hOldFont )
		::SelectObject(hdcScreen, hOldFont);

	return UpdatePanes();
}


template<typename TBarBase, typename TCmdUI>
BOOL CCmdUIStatusBarT<TBarBase, TCmdUI>::UpdatePanes()
{
	ATLASSERT(::IsWindow(m_hWnd));

	// Allocate an array for the parts
	
	int nHorz;
	int nVert;
	int nSpacing;
	if ( !GetBorders(nHorz, nVert, nSpacing) )
	{
		ATLTRACE(_T("Unable to determine borders for status bar\n"));
		return FALSE;
	}

	UINT nPanes				= GetParts(0, NULL);
	if ( nPanes != m_nPanes )
	{
		ATLTRACE(_T("Status bar has %d panes but our array has %d.  Panes ")
				 _T("have been changed outside of SetIndicators() -- cannot resize\n"),
				 nPanes, m_nPanes);
		return FALSE;
	}

	// Calculate how much space we have to work with.  Adjust for borders

	RECT rect;
	GetWindowRect(&rect);
	rect.left				+= nHorz;
	rect.right				-= nHorz;
	rect.top				+= nVert;
	rect.bottom				-= nVert;
	int nExtra				= rect.right - rect.left;	// space remaining
	UINT nIdx				= 0;

	// account for size grip

	int nGripWidth			= ::GetSystemMetrics(SM_CXVSCROLL) + ::GetSystemMetrics(SM_CXBORDER) * 2;
	if ( nGripWidth < nExtra )
		nExtra				-= nGripWidth;

	int nRight				= 0;
	bool bZeroIdSeen		= false;					// for sanity checking

	// Copy the IDs from the array and attempt to load the text for each one.

	BOOL bResult = TRUE;
	if ( 0 < m_nPanes && NULL != m_pPanes )
	{
		HFONT hFont			= (HFONT)SendMessage(WM_GETFONT);
		HDC hdcScreen		= ::GetDC(NULL);
		HGDIOBJ hOldFont	= NULL;

		if ( NULL != hFont)
			hOldFont		= ::SelectObject(hdcScreen, hFont);

		HINSTANCE hModule	= ::GetModuleHandle(NULL);
		DWORD dwSize		= 0;
		int nTotalCount		= 0;

		for (nIdx = 0; nIdx < m_nPanes; nIdx++)		// for left to right calc
		{
			CStatusBarPane& pane	= m_pPanes[nIdx];
			if ( 0 == pane.m_nCmdId )
			{
				ATLASSERT(!bZeroIdSeen);
				bZeroIdSeen	= true;
			}

			SIZE size;
			int nWidth		= 0;

			if ( 0 == (pane.m_nType & ASBT_OWNERDRAW) )
			{
				if ( 0 == pane.m_nCmdId )
				{
					nWidth	= -1;
				}
				else if ( 0 != (pane.m_nType & ASBT_STRETCH) )
				{
					LPCTSTR pText	= pane.m_pText;
					if ( !::GetTextExtentPoint32(hdcScreen, pText, lstrlen(pText) * sizeof(TCHAR), &size) )
						ATLTRACE(_T("Unable to determine string width\n"));
					else
						nWidth		= STRING_WIDTH_EXTRA + size.cx;
				}
				else
				{
					nWidth	= pane.m_nWidth;
				}
			}

			pane.m_nWidth	= nWidth;
			
		}

		// We have determined the widths of all panes.  Now determine the width
		// of the one allowed stretchy pane.

		UINT nNonStretchySpace		= 0;
		UINT nIdx					= 0;

		if ( bZeroIdSeen )
		{
			UINT nStretchyIdx		= 0;
			for ( nIdx = 0; nIdx < m_nPanes; nIdx++ )
			{
				if ( 0 != m_pPanes[nIdx].m_nCmdId )
					nNonStretchySpace += m_pPanes[nIdx].m_nWidth + nSpacing;
				else
					nStretchyIdx	= nIdx;

			}
			m_pPanes[nStretchyIdx].m_nWidth	= nExtra - nNonStretchySpace;
		}

		HANDLE hHeap			= GetProcessHeap();
		LPVOID pVoid			= ::HeapAlloc(hHeap, HEAP_ZERO_MEMORY, sizeof(int) * m_nPanes);
		int* rights				= reinterpret_cast<int*>(pVoid);

		for ( nIdx=0; nIdx < m_nPanes; nIdx++ )
		{
			CStatusBarPane& pane= m_pPanes[nIdx];
			nRight				+= pane.m_nWidth;
			rights[nIdx]		= nRight;
			nRight				+= nSpacing;
			nExtra				-= pane.m_nWidth + nSpacing;
		}

		// Reset the widths

		SetParts(m_nPanes, rights);
		::HeapFree(hHeap, 0, pVoid);

		if ( NULL == hOldFont )
			::SelectObject(hdcScreen, hOldFont);
	}
	return bResult;
}
typedef CIdleUIWindowT<CToolBar, CToolBarCtrlCmdUI>			CIdleUIToolBar;
typedef CCmdUIStatusBarT<CStatusBar>						CCmdUIStatusBar;


};		// namespace Attila

#ifndef _ATTILA_NOUSE_NAMESPACE
	using namespace Attila;
#endif



#endif