/* MIDL: this ALWAYS GENERATED file contains the definitions for the interfaces */
