//////////////////////////////////////////////////////////////////////
// GenericView.h - Definition and Implementation of CGenericView
//                 Defintiion and Implementation of CViewImpl

#ifndef AFX_GENERICVIEW_H__D0426FD0_54FB_11D3_99D9_00A0C92C7949__INCLUDED_
#define AFX_GENERICVIEW_H__D0426FD0_54FB_11D3_99D9_00A0C92C7949__INCLUDED_

#pragma once

/////////////////////////////////////////////////////////////////////////////////
// CGenericView - Represents default document interaction
/////////////////////////////////////////////////////////////////////////////////
class CGenericView : public CMessageMap, public CDocumentClient
{
		BEGIN_MSG_MAP(CGenericView)
		ALT_MSG_MAP(WM_COMMAND)
			COMMAND_ID_HANDLER(ID_FILE_OPEN, OnOpen)
			COMMAND_ID_HANDLER(ID_FILE_SAVE, OnSave)
			COMMAND_ID_HANDLER(ID_FILE_SAVE_AS, OnSaveAs)
		END_MSG_MAP()

		// Default document interactions
		LRESULT OnOpen(WORD, WORD, HWND, BOOL&)
		{
			CDocument *pDoc = GetDocument();
			ATLASSERT(pDoc);
			bool bFailed(false);
			pDoc->OnOpen(bFailed);
			return bFailed ? 0L : -1L;
		}

		LRESULT OnSave(WORD, WORD, HWND, BOOL& bHandled)
		{
			CDocument *pDoc = GetDocument();
			ATLASSERT(pDoc);
			bool bFailed(false);
			pDoc->OnSave(bFailed);
			return bFailed ? 0L : -1L;
		}

		LRESULT OnSaveAs(WORD, WORD, HWND, BOOL& bHandled)
		{
			CDocument *pDoc = GetDocument();
			ATLASSERT(pDoc);
			bool bFailed(false);
			pDoc->OnSaveAs(bFailed);
			return bFailed ? 0L : -1L;
		}
};


/////////////////////////////////////////////////////////////////////////////////
// CViewImpl - Represents a parent window for a common control
// NOTE: CViewWindowImpl is defined in AttilaFrame.h and is basically just a NOOP
/////////////////////////////////////////////////////////////////////////////////

// In addition to CCtrlWinTraits, basic style requirements for a view's control
typedef CWinTraitsOR<WS_VSCROLL | WS_HSCROLL, 0> ctrlTraits;

template <typename TCtrl = CWindow, typename TWinTraits = ctrlTraits>
class CViewImpl : public CViewWindowImpl<CViewImpl>, public CGenericView
{
	public:

		typedef CGenericView				cmdClass; // Route WM_COMMAND 
		typedef CViewWindowImpl<CViewImpl>	baseClass;
		typedef CViewImpl					thisClass;

		CViewImpl() {}
		virtual ~CViewImpl() {}

		BEGIN_MSG_MAP(thisClass)
		CHAIN_MSG_MAP_ALT_FILTER(cmdClass, WM_COMMAND, WM_COMMAND)
		MESSAGE_HANDLER(WM_CREATE, OnCreate)
		MESSAGE_HANDLER(WM_SIZE, OnSize)
		CHAIN_MSG_MAP(baseClass)
		END_MSG_MAP()

		LRESULT OnCreate(UINT, WPARAM, LPARAM, BOOL&);
		LRESULT OnSize(UINT, WPARAM, LPARAM, BOOL&);

	protected:

		TCtrl m_Ctrl;
};

//
// Create the control with this windows client area
//
template <typename TCtrl, typename TWinTraits>
LRESULT CViewImpl<TCtrl, TWinTraits>::OnCreate(UINT, WPARAM, LPARAM, BOOL&)
{
	RECT Rect;
	GetClientRect(&Rect);
	
	HWND hWnd = m_Ctrl.Create(m_hWnd, 
		                      Rect, 
							  0, 
							  TWinTraits::GetWndStyle(0), 
							  TWinTraits::GetWndExStyle(0));
	
	ATLASSERT(hWnd);

	return (hWnd) ? 0L : -1L;
}

//
// Ensure proper sizing behavior
//
template <typename TCtrl, typename TWinTraits>
LRESULT CViewImpl<TCtrl, TWinTraits>::OnSize(UINT, WPARAM, LPARAM, BOOL &bResult)
{
	bResult = FALSE;
	RECT Rect;
	GetClientRect(&Rect);
	m_Ctrl.MoveWindow(&Rect);
	return 0L;
}

#endif // !defined(AFX_GENERICVIEW_H__D0426FD0_54FB_11D3_99D9_00A0C92C7949__INCLUDED_)
