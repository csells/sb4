// ListView.h

#ifndef AFX_LISTVIEWIMPL_H__D0426FD0_54FB_11D3_99D9_00A0C92C7949__INCLUDED_
#define AFX_LISTVIEWIMPL_H__D0426FD0_54FB_11D3_99D9_00A0C92C7949__INCLUDED_

#pragma once

#include "GenericView.h"

// A report style list control with gridlines
typedef CWinTraitsOR<LVS_REPORT | LVS_SINGLESEL | LVS_SHOWSELALWAYS, 0, ctrlTraits> listTraits;

//
// CListViewImpl
//
class CListViewImpl : public CViewImpl<CListViewCtrl, listTraits>
{
	public:
		
		typedef CViewImpl<CListViewCtrl, listTraits>	baseClass;
		typedef CListViewImpl							thisClass;

		CListViewImpl() {}
		virtual ~CListViewImpl() {}

		BEGIN_MSG_MAP(thisClass)
		MESSAGE_HANDLER(WM_CREATE, OnCreate)
		COMMAND_ID_HANDLER(ID_FILE_PRINT, OnPrint)
		COMMAND_ID_HANDLER(ID_FILE_PRINT_PREVIEW, OnPrintPreview)
		MESSAGE_HANDLER(WM_COMMAND, OnCommand);
		CHAIN_MSG_MAP(baseClass)
		END_MSG_MAP()

		LRESULT OnCreate(UINT, WPARAM, LPARAM, BOOL&);
		LRESULT OnPrint(WORD, WORD, HWND, BOOL&);
		LRESULT OnPrintPreview(WORD, WORD, HWND, BOOL&);
		LRESULT OnCommand(UINT uInt, WPARAM wParam, LPARAM lParam, BOOL &bHandled);
};

//
// Insert some columns
//
LRESULT CListViewImpl::OnCreate(UINT uInt, WPARAM wParam, LPARAM lParam, BOOL &bHandled)
{
	// Let the base class create our control
	baseClass::OnCreate(uInt, wParam, lParam, bHandled);

	// These have to be set *after* creation has occured
	ListView_SetExtendedListViewStyle(m_Ctrl.m_hWnd, LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT);

	RECT Rect;
	m_Ctrl.GetClientRect(&Rect);

	LV_COLUMN lvcol;
	ZeroMemory(&lvcol, sizeof(LV_COLUMN));
	lvcol.mask = LVCF_FMT | LVCF_TEXT | LVCF_SUBITEM | LVCF_ORDER | LVCF_WIDTH;

	lvcol.iOrder = 0;
	lvcol.pszText = _T("HWND");
	lvcol.cx = Rect.right / 4;
	m_Ctrl.InsertColumn(0, &lvcol);

	lvcol.iOrder = 1;
	lvcol.iSubItem = 1;
	lvcol.pszText = _T("Message");
	lvcol.cx = Rect.right / 2;
	m_Ctrl.InsertColumn(1, &lvcol);

	lvcol.iOrder = 2;
	lvcol.iSubItem = 1;
	lvcol.pszText = _T("Handled?");
	lvcol.cx = Rect.right / 4;
	m_Ctrl.InsertColumn(2, &lvcol);

	return 0L;
}

LRESULT CListViewImpl::OnPrint(WORD, WORD, HWND hWnd, BOOL &bHandled)
{
	int iCnt = m_Ctrl.GetItemCount();
	TCHAR szBuf[128] = _T("");
	itoa((int)hWnd, szBuf, 10);
	m_Ctrl.AddItem(iCnt, 0, szBuf);
	m_Ctrl.AddItem(iCnt, 1, _T("Print"));
	m_Ctrl.AddItem(iCnt, 2, (bHandled) ? _T("Yes") : _T("No"));
	return 0L; 
}

LRESULT CListViewImpl::OnPrintPreview(WORD, WORD, HWND hWnd, BOOL &bHandled) 
{ 
	int iCnt = m_Ctrl.GetItemCount();
	TCHAR szBuf[128] = "";
	itoa((int)hWnd, szBuf, 10);
	m_Ctrl.AddItem(iCnt, 0, szBuf);
	m_Ctrl.AddItem(iCnt, 1, _T("Print Preview"));
	m_Ctrl.AddItem(iCnt, 2, (bHandled) ? _T("Yes") : _T("No"));
	return 0L; 
}

LRESULT CListViewImpl::OnCommand(UINT uInt, WPARAM wParam, LPARAM lParam, BOOL &bHandled)
{
	bHandled = FALSE;
	int iCnt = m_Ctrl.GetItemCount();
	TCHAR szBuf[128] = "";
	itoa((int)lParam, szBuf, 10);
	m_Ctrl.AddItem(iCnt, 0, szBuf);
	m_Ctrl.AddItem(iCnt, 1, _T("WM_COMMAND"));
	m_Ctrl.AddItem(iCnt, 2, (bHandled) ? _T("Yes") : _T("No"));
	return 0L; 
}

#endif //AFX_LISTVIEWIMPL_H__D0426FD0_54FB_11D3_99D9_00A0C92C7949__INCLUDED_