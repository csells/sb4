// CmdRouteWnd.cpp : Implementation of WinMain

#include "stdafx.h"
#include "resource.h"
#include "MainFrame.h"

CComModule _Module;

/////////////////////////////////////////////////////////////////////////////
//
extern "C" int WINAPI _tWinMain(HINSTANCE hInst, 
								HINSTANCE hPrevInst, 
								LPTSTR lpCmdLine, 
								int nCmdShow)
{
    _Module.Init(0, hInst);

    INITCOMMONCONTROLSEX iccx = { sizeof(iccx), ICC_ALL };	
	if ( !InitCommonControlsEx(&iccx) )						
		return -1;											

	CMainFrame Frame;
	
	HMENU hMenu = LoadMenu(hInst, MAKEINTRESOURCE(IDR_FRAME_MENU));

	Frame.Create(0, CWindow::rcDefault, __T("Attila Window"), 0, 0, (UINT)hMenu);
	if(!Frame)
		return -1;

	Frame.CenterWindow();
	Frame.ShowWindow(nCmdShow);
	Frame.UpdateWindow();
	
    // Enter the modified message loop
    MSG Msg;
    while(GetMessage(&Msg, 0, 0, 0))
    {
        if(!CMsgTranslator::RunThroughTranslators(Msg))
        {
            TranslateMessage(&Msg);
            DispatchMessage(&Msg);
        }
    }

	_Module.Term();
    return Msg.wParam;
}
