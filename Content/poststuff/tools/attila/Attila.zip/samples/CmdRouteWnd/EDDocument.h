// EDDocument.h: interface for the CEDDocument class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EDDOCUMENT_H__110EE491_4F3E_11D3_95BB_0004AC868400__INCLUDED_)
#define AFX_EDDOCUMENT_H__110EE491_4F3E_11D3_95BB_0004AC868400__INCLUDED_

#pragma once

#include "AttilaDocument.h"

// A simple NOOP document for now
class CEDDocument : public CDocument 
{
	public:

		CEDDocument() {}
		virtual ~CEDDocument() {}
};

#endif // !defined(AFX_EDDOCUMENT_H__110EE491_4F3E_11D3_95BB_0004AC868400__INCLUDED_)
