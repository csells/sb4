// MainFrame.h: Declarations and Definitions for the main window
//              and child frames.
//////////////////////////////////////////////////////////////////////

#if !defined(_MAINFRAME_H__031E73D0_4DDB_11D3_99CC_00A0C92C7949__INCLUDED_)
#define _MAINFRAME_H__031E73D0_4DDB_11D3_99CC_00A0C92C7949__INCLUDED_

#pragma once

#include "AttilaMsgRouting.h"

#include "ListView.h"
#include "EDDocument.h"
#include "DocTemplate.h"

///////////////////////////////////////////////////////////////////////
// Child frame window
// Template parameter TView represents some CViewWindowImpl derivation
// and is stored internally as a member.
///////////////////////////////////////////////////////////////////////
template <typename TView>
class CEDChildFrame : public CMdiChildWindowImpl<CEDChildFrame>
{
	public:

		typedef CMdiChildWindowImpl<CEDChildFrame>	baseClass;
		typedef CEDChildFrame						thisClass;

		CEDChildFrame() : m_CmdPath(&m_View) {}
		virtual ~CEDChildFrame() {}

		BEGIN_MSG_MAP(thisClass)
		CHAIN_MSG_MAP_MEMBER(m_CmdPath)
		MESSAGE_HANDLER(WM_CREATE, OnCreate)
		MESSAGE_HANDLER(WM_SIZE, OnSize)
		CHAIN_MSG_MAP(baseClass)
		END_MSG_MAP()

		HWND Create(HWND hwndMdiClient, 
		            RECT& rcPos, 
					LPCTSTR szWindowName = 0,
                    DWORD dwStyle = 0, 
					HMENU hmenu = 0, 
					LPARAM lParam = 0);

		LRESULT OnCreate(UINT, WPARAM, LPARAM, BOOL&);
		LRESULT OnSize(UINT, WPARAM, LPARAM, BOOL&);
		
		bool AttachDocument(CDocument* pDoc)
		{
			return m_View.AttachDocument(pDoc);
		}

	protected:

		TView m_View;
		CFilteredMsgPath<TView>	m_CmdPath; // Defaults to WM_COMMAND
};

// Specify a menu for the child frames
template <typename TView>
HWND CEDChildFrame<TView>::Create(HWND hwndMdiClient, 
								  RECT& rcPos, 
								  LPCTSTR szWindowName,
								  DWORD dwStyle, 
								  HMENU hmenu, 
								  LPARAM lParam)
{
	hmenu =	LoadMenu(_Module.m_hInst, MAKEINTRESOURCE(IDR_CHILD_MENU));

	return baseClass::Create(hwndMdiClient, 
				             rcPos, 
							 szWindowName, 
							 dwStyle,
							 hmenu,
							 lParam);
}

// Create the view for this frame
template <typename TView>
LRESULT CEDChildFrame<TView>::OnCreate(UINT, WPARAM, LPARAM, BOOL&)
{
	RECT Rect;
	GetClientRect(&Rect);
	HWND hWnd = m_View.Create(m_hWnd, Rect);
	
	return hWnd ? 0L : -1L;
}

// Ensure that the view stays in shape
template <typename TView>
LRESULT CEDChildFrame<TView>::OnSize(UINT, WPARAM, LPARAM, BOOL &bResult)
{
	bResult = FALSE;
	RECT Rect;
	GetClientRect(&Rect);
	m_View.MoveWindow(&Rect);
	return -1L;
}

///////////////////////////////////////////////////////////////
// Document templates
///////////////////////////////////////////////////////////////
typedef CDocTemplate < CEDDocument, CEDChildFrame<CListViewImpl> >	CListTemplate;

///////////////////////////////////////////////////////////////
// Main Application Frame Window
///////////////////////////////////////////////////////////////
class CMainFrame : public CMdiFrameWindowImpl<CMainFrame>
{
	public:

		typedef CMdiFrameWindowImpl<CMainFrame>	baseClass;
		typedef CMainFrame						thisClass;

		CMainFrame() {}

		// Plug all the potential leaks
		virtual ~CMainFrame()
		{
			for(int x(0); x < m_pListViews.GetSize(); x++)
				delete m_pListViews[x];
		}

		// See AttilaMsgRouting.h for definitions of these macros
		BEGIN_MSG_MAP(thisClass)
		
		CHAIN_MSG_MAP_ALT_FILTER(baseClass, WM_COMMAND, WM_COMMAND)
			COMMAND_ID_HANDLER(ID_FILE_NEW, OnFileNew)
		END_MSG_FILTER(WM_COMMAND)
	    
		CHAIN_MSG_MAP(baseClass)
		END_MSG_MAP()

		LRESULT OnFileNew(WORD, WORD, HWND, BOOL&);

	protected:

		// A collection of Doc/View/ChildFrames
		CSimpleArray< CListTemplate* > m_pListViews;
}; 

//
// Create a new Frame with an list control for a view
//
LRESULT CMainFrame::OnFileNew(WORD, WORD, HWND, BOOL&)
{
	//CTxtDocTemplate *pTxtDocTemplate = new CTxtDocTemplate;
	CListTemplate *pListViewFrame = new CListTemplate;
	
	RECT Rect;
	GetClientRect(&Rect);
	Rect.right /=2;
	Rect.bottom /= 2;
	
	// This is an ugly memory hog, but it's just test code for now
	if(pListViewFrame->Create(m_wndClient.m_hWnd, Rect))
	{
		m_pListViews.Add(pListViewFrame);
	}

	return 0L;
}

#endif // !defined(_MAINFRAME_H__031E73D0_4DDB_11D3_99CC_00A0C92C7949__INCLUDED_)
