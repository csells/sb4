//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CmdRouteWnd.rc
//
#define IDS_PROJNAME                    100
#define IDR_CmdRouteWnd                 101
#define IDR_FRAME_MENU                  201
#define IDR_CHILD_MENU                  202
#define IDR_MAINFRAME                   202
#define ID_FILE_SAVE_ALL                32778
#define ID_VIEW_TOOLBAR                 32779
#define ID_VIEW_STATUSBAR               32780
#define ID_UI_TEST1                     32781
#define ID_FILE_NEW_EDIT                32782
#define ID_FILE_NEW_LIST                32783
#define ID_FILE_NEW_TREE                32784

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        203
#define _APS_NEXT_COMMAND_VALUE         32785
#define _APS_NEXT_CONTROL_VALUE         203
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
