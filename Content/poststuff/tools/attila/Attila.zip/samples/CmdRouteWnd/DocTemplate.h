// DocTemplate.h: interface for the CDocTemplate class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DOCTEMPLATE_H__110EE492_4F3E_11D3_95BB_0004AC868400__INCLUDED_)
#define AFX_DOCTEMPLATE_H__110EE492_4F3E_11D3_95BB_0004AC868400__INCLUDED_

#pragma once

// 1) Create the Document
// 2) Create the Frame containing the View
// 3) Plumb it all together

template <typename TDoc, typename TFrame>
class CDocTemplate  
{
	public:
		
		CDocTemplate() : m_pDoc(0), m_pViewFrame(0) {}
		virtual ~CDocTemplate()	{ Cleanup(); }

		// Create all the components and plumb them
		BOOL Create(HWND hParent, RECT &Rect)
		{
			BOOL bResult(FALSE);
			
			// Ensure against redundant calls
			if(m_pDoc || m_pViewFrame)
				return bResult;
			
			// Attempt to create the doc and view
			m_pDoc = new TDoc;
			m_pViewFrame = new TFrame;
			if(!m_pDoc || !m_pViewFrame)
			{
				Cleanup();
				return bResult;
			}

			// Ok, the Doc and View are viable
			m_pViewFrame->AttachDocument(m_pDoc);

			HWND hFrameWnd = m_pViewFrame->Create(hParent, Rect);
			if(!hFrameWnd)
			{
				Cleanup();
			}

			return bResult;
		}

	protected:

		// Something bad happened!
		void Cleanup()
		{
			if(m_pDoc)
				delete m_pDoc;
					
			if(m_pViewFrame)
				delete m_pViewFrame;
		}

		TDoc *m_pDoc;
		TFrame *m_pViewFrame;
};

#endif // !defined(AFX_DOCTEMPLATE_H__110EE492_4F3E_11D3_95BB_0004AC868400__INCLUDED_)
