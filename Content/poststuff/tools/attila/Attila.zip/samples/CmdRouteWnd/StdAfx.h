// stdafx.h

#if !defined(AFX_STDAFX_H__41586281_4DD9_11D3_99CC_00A0C92C7949__INCLUDED_)
#define AFX_STDAFX_H__41586281_4DD9_11D3_99CC_00A0C92C7949__INCLUDED_

#pragma once

#define WIN32_LEAN_AND_MEAN

#include <atlbase.h>
extern CComModule _Module;

// Attila includes
#include <AttilaFrame.h>
#include <AttilaControls.h>
#include <AttilaView.h>
#include <AttilaDocument.h>
#include <AttilaMsgRouting.h>

#pragma comment (lib, "comctl32.lib")

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__41586281_4DD9_11D3_99CC_00A0C92C7949__INCLUDED)
