// EditFrame.h

#pragma once
#ifndef INC_APPFRAME
#define INC_APPFRAME

class CMyEditView: public CViewWindowImpl<CMyEditView,CEdit,CWinTraitsOR<WS_VSCROLL|WS_HSCROLL|ES_MULTILINE|ES_AUTOVSCROLL|ES_AUTOHSCROLL, WS_EX_CLIENTEDGE> >
{
public:
	typedef CViewWindowImpl<CMyEditView,CEdit,
                            CWinTraitsOR<WS_VSCROLL|WS_HSCROLL|ES_MULTILINE|ES_AUTOVSCROLL|ES_AUTOHSCROLL, WS_EX_CLIENTEDGE> > baseclass;
	BEGIN_MSG_MAP(CMyEditView)
		CHAIN_MSG_MAP(baseclass)
	END_MSG_MAP()
};

class CMyEditFrame: public CFrameWindowImpl<CMyEditFrame>
{
public:
	typedef CFrameWindowImpl<CMyEditFrame> baseClass;
	CMyEditFrame(){}

public:
	BEGIN_MSG_MAP(CMyEditFrame)
		MESSAGE_HANDLER(WM_CREATE, OnCreate)
		MESSAGE_HANDLER(WM_SETFOCUS, OnSetFocus)
		MESSAGE_HANDLER(WM_SIZE, OnSize)		
		COMMAND_ID_HANDLER(ID_APP_EXIT, OnAppExit) 
		COMMAND_ID_HANDLER(ID_APP_ABOUT, OnAbout) 
		CHAIN_MSG_MAP(baseClass)
	END_MSG_MAP()

public://handlers
	LRESULT OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		//Create the Statusbar
		m_wndStatusBar.Create(m_hWnd,CWindow::rcDefault);
		
		//Create the View
		m_View.Create(m_hWnd,CWindow::rcDefault);

		//Fill an array of Toolbar buttons
		TBBUTTON tbButtons[] = 
		{
			{ 0,	ID_FILE_NEW,						TBSTATE_ENABLED				,TBSTYLE_BUTTON, 0L, 0},
			{ 1,	ID_FILE_OPEN,						TBSTATE_ENABLED				,TBSTYLE_BUTTON, 0L, 0},
			{ 2,	ID_FILE_SAVE,						TBSTATE_ENABLED				,TBSTYLE_BUTTON, 0L, 0},
			{ 3,	ID_EDIT_CUT,						TBSTATE_ENABLED				,TBSTYLE_BUTTON, 0L, 0},
			{ 4,	ID_EDIT_COPY,						TBSTATE_ENABLED				,TBSTYLE_BUTTON, 0L, 0},
			{ 5,	ID_EDIT_PASTE,						TBSTATE_ENABLED				,TBSTYLE_BUTTON, 0L, 0},
			{ 6,	ID_APP_ABOUT,						TBSTATE_ENABLED				,TBSTYLE_BUTTON, 0L, 0}
		};

		//Create the Toolbar
		m_wndToolBar.Create(m_hWnd,CWindow::rcDefault,tbButtons,7,IDR_MAINFRAME);
		
		return 0L;
	}

	LRESULT OnSetFocus(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		m_View.SetFocus();
		return 0L;
	}

	LRESULT OnSize(UINT  uMsg , WPARAM  wParam , LPARAM  lParam , BOOL&  bHandled)
	{
		bHandled = ResizeElements();
		return 0L;
	}
	LRESULT OnAppExit(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{	
		DestroyWindow(); //Will make the Frame call PostQuitMessage
		return 0L;
	}
	LRESULT OnAbout(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		CSimpleDialog<IDD_ABOUT> dlg;
		dlg.DoModal();
		return 0L;
	}

public: //virtuals
	BOOL ResizeElements()
	{
		m_wndStatusBar.SendMessage(WM_SIZE);
		RECT rc,rcToolPanel,rcStatus;
		GetClientRect(&rc);
		
		GetClientRect(&rc);
		m_wndToolBar.SetWindowPos(NULL,rc.left, rc.top, rc.right - rc.left,30,SWP_NOZORDER | SWP_NOACTIVATE);
				
		m_wndToolBar.GetWindowRect(&rcToolPanel);
		rc.top +=  (rcToolPanel.bottom - rcToolPanel.top);

		m_wndStatusBar.GetWindowRect(&rcStatus);
		rc.bottom -= (rcStatus.bottom - rcStatus.top);
		
		m_View.SetWindowPos(NULL, rc.left, rc.top,rc.right - rc.left, rc.bottom - rc.top,
							SWP_NOZORDER | SWP_NOACTIVATE);

		return TRUE;
	}

private:
	CMyEditView			m_View;
	CToolBar			m_wndToolBar;		
	CStatusBar			m_wndStatusBar;	
};

#endif  // INC_APPFRAME
