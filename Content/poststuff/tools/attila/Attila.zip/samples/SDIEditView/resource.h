//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SDIEditView.rc

#include <attilares.h>

#define IDS_PROJNAME                    100
#define IDR_SDIEditView                 100
#define IDD_ABOUT                       100
#define IDR_MAINFRAME                   128
#define IDR_MENU                        129
#define IDC_EDIT1                       201
#define ID_FILE_EXIT                    32770
#define ID_OPTIONS_FREEZEEVENTS         32776
#define ID_OPTIONS_DESIGNMODE           32779
#define ID_BUTTON32790                  32790
#define ID_CONTROL_INVOKEMETHODS        32815
#define ID_CONTAINER_AMBIENTPROPERTIES  32817
#define ID_EDIT_PROPERTIES              32848
#define ID_TOOLS_MACROS                 32853
#define ID_FILE_NEW                     0xE100
#define ID_FILE_CLOSE                   0xE102
#define ID_FILE_SAVE                    0xE103
#define ID_FILE_SAVE_AS                 0xE104
#define ID_FILE_PRINT_SETUP             0xE106
#define ID_FILE_PRINT                   0xE107
#define ID_FILE_PRINT_PREVIEW           0xE109
#define ID_FILE_MRU_FILE1               0xE110
#define ID_EDIT_CLEAR                   0xE120
#define ID_EDIT_COPY                    0xE122
#define ID_EDIT_CUT                     0xE123
#define ID_EDIT_PASTE                   0xE125
#define ID_EDIT_PASTE_SPECIAL           0xE127
#define ID_EDIT_UNDO                    0xE12B
#define ID_WINDOW_NEW                   0xE130
#define ID_WINDOW_ARRANGE               0xE131
#define ID_WINDOW_CASCADE               0xE132
#define ID_WINDOW_TILE_HORZ             0xE133
#define ID_APP_ABOUT                    0xE140
#define ID_APP_EXIT                     0xE141
#define ID_OLE_INSERT_NEW               0xE200
#define ID_OLE_EDIT_LINKS               0xE201
#define ID_OLE_VERB_FIRST               0xE210
#define ID_VIEW_TOOLBAR                 0xE800
#define ID_VIEW_STATUS_BAR              0xE801

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         202
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
