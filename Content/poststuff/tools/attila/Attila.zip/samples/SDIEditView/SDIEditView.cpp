// SDIEditView.cpp

#include "stdafx.h"
#include "resource.h"
#include "EditFrame.H"

CComModule _Module;

extern "C" int WINAPI _tWinMain(HINSTANCE hInstance, HINSTANCE, LPTSTR lpCmdLine, int nShowCmd)
{
    _Module.Init(0, hInstance);
    	
    // Init common controls
    INITCOMMONCONTROLSEX iccx = { sizeof(iccx), ICC_ALL };
	InitCommonControlsEx(&iccx);

	// Create the App Frame
	CMyEditFrame frame;
	HMENU hmenu = LoadMenu(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_MAINFRAME));
	frame.Create(::GetDesktopWindow(),CWindow::rcDefault,_T("Edit View"),0,0,(UINT)hmenu);
	frame.CenterWindow();
	frame.ShowWindow(nShowCmd);
	frame.UpdateWindow();

    MSG msg;
    while (GetMessage(&msg, 0, 0, 0))
	{
        if( !CMsgTranslator::RunThroughTranslators(msg) )
		{
	        TranslateMessage(&msg);
	        DispatchMessage(&msg);
        }
	}

    _Module.Term();
	return msg.wParam;
}
