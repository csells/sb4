#ifndef _STDAFX_H_
#define _STDAFX_H_

#include <tchar.h>
#include <atlbase.h>
extern CComModule _Module;
#include <atlcom.h>
#include <atlwin.h>
#define _ATTILA_USES_STL
#include <AttilaDlgData.h>

#ifndef BEGIN_OBJECT_MAP
#define BEGIN_OBJECT_MAP(x)
#endif

#ifndef END_OBJECT_MAP
#define END_OBJECT_MAP()
#endif

#endif
