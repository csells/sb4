//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Ddx_ddv.rc
//
#define IDD_TESTDIALOG                  101
#define IDC_INT_1                       1000
#define IDC_INT_2                       1001
#define IDC_CHARS                       1002
#define IDC_STL_1                       1003
#define IDC_STL_2                       1004
#define IDC_FLOAT                       1005
#define ID_VALIDATE                     1006
#define IDC_SLIDER                      1008
#define IDC_CHECK_1                     1009
#define IDC_RADIO_1                     1010
#define IDC_RADIO_2                     1011
#define IDC_RADIO_3                     1012
#define IDC_SCROLL                      1013
#define IDC_CHECK_2                     1014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
