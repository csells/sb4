#include "stdafx.h"
#include "TestDialog.h"

BEGIN_OBJECT_MAP(ObjectMap)
END_OBJECT_MAP()

CComModule _Module;

int
APIENTRY _tWinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR 
		lpCmdLine, int nCmdShow )
{
	InitCommonControls();

	_Module.Init( ObjectMap, hInstance );
	CTestDialog().DoModal();
	_Module.Term();
	
	return 0;
}
