#pragma once

#ifndef __TESTDIALOG_H_
#define __TESTDIALOG_H_

#include "resource.h"

#ifndef ATLVERIFY
	#ifdef _DEBUG
		#define ATLVERIFY(x) ATLASSERT(x)
	#else
		#define ATLVERIFY(x) (x)
	#endif
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestDialog

class CTestDialog : 
	public CDialogImpl<CTestDialog>
{
public:
	CTestDialog()
	{
	}

	~CTestDialog()
	{
	}

	enum { IDD = IDD_TESTDIALOG };

BEGIN_MSG_MAP(CTestDialog)
	MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	COMMAND_ID_HANDLER(ID_VALIDATE, OnValidate)
	COMMAND_ID_HANDLER(IDOK, OnOK)
END_MSG_MAP()

BEGIN_DDX_MAP(CTestDialog)
	DDX_CONTROL(IDC_INT_1, m_editCtrl)
	DDX_INTEGER_FORMAT(IDC_INT_1, m_nInteger1, true, "0x%08X")
	DDX_INTEGER_RANGE(IDC_INT_2, m_dwInteger2, false, 16, 48)
	DDX_FLOAT_RANGE(IDC_FLOAT, m_dFloat, 1.0, 7.5)
	DDX_STRING_LENGTH(IDC_CHARS, m_szChars, 50)
	DDX_STL_STRING(IDC_STL_1, m_strStl1)
	DDX_STL_STRING_LENGTH(IDC_STL_2, m_strStl2, 50)
	DDX_CHECK(IDC_CHECK_1, m_nCheck1)
	DDX_CHECK(IDC_CHECK_2, m_nCheck2)
	DDX_RADIO(IDC_RADIO_1, m_nRadio)
	DDX_SCROLL_RANGE(IDC_SCROLL, m_nScroll, 0, 100)
	DDX_SLIDER_RANGE(IDC_SLIDER, m_nSlider, 0, 100)
END_DDX_MAP()

public:
	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		//  Initialize our data

		m_nInteger1  = 843598;
		m_dwInteger2 = 32;
		m_dFloat     = 3.0;
		m_nCheck1    = 1;
		m_nCheck2    = 2;
		m_nRadio     = 1;
		m_nScroll    = 50;
		m_nSlider    = 25;

		lstrcpy( m_szChars, "Character array" );

		m_strStl1 = "STL String #1";
		m_strStl2 = "STL String #2";

		//  Update the controls

		ATLVERIFY( UpdateData( false ));

		return 1;
	}

	LRESULT OnValidate(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		if( !UpdateData())
			return 0;

		//  Break here if you want to see all the validated data

		MessageBox( "All data is valid.", "DDX/DDV Sample", MB_ICONINFORMATION );
		return 0;
	}

	LRESULT OnOK(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		EndDialog( IDOK );
		return 0;
	}

private:
	CWindow                  m_editCtrl;
	int                      m_nInteger1;
	DWORD                    m_dwInteger2;
	double                   m_dFloat;
	char                     m_szChars[ 51 ];
	std::basic_string<TCHAR> m_strStl1;
	std::basic_string<TCHAR> m_strStl2;
	int                      m_nCheck1;
	int                      m_nCheck2;
	int                      m_nRadio;
	int                      m_nScroll;
	int                      m_nSlider;
};

#endif //__TESTDIALOG_H_
