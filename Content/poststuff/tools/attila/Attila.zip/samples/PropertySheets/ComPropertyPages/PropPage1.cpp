// PropPage1.cpp : Implementation of CPropPage1
#include "stdafx.h"
#include "ComPropertyPages.h"
#include "PropPage1.h"

/////////////////////////////////////////////////////////////////////////////
// CPropPage1

