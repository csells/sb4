//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ComPropertyPages.rc
//
#define IDS_PROJNAME                    100
#define IDS_TITLEPropPage1              101
#define IDS_HELPFILEPropPage1           102
#define IDS_DOCSTRINGPropPage1          103
#define IDR_PROPPAGE1                   104
#define IDD_PROPPAGE1                   105
#define IDC_CALENDAR1                   201
#define IDC_EDIT1                       202
#define IDC_EDIT2                       203
#define IDC_DIRTY                       204

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         205
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
