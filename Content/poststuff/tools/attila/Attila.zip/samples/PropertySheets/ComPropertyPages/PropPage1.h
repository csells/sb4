// PropPage1.h : Declaration of the CPropPage1

#ifndef __PROPPAGE1_H_
#define __PROPPAGE1_H_

#include "resource.h"       // main symbols

EXTERN_C const CLSID CLSID_PropPage1;

/////////////////////////////////////////////////////////////////////////////
// CPropPage1
class ATL_NO_VTABLE CPropPage1 :
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CPropPage1, &CLSID_PropPage1>,
	public IPropertyPageImpl<CPropPage1>,
	public CAxDialogImpl<CPropPage1>
{
public:
	CPropPage1() 
	{
		m_dwTitleID = IDS_TITLEPropPage1;
		m_dwHelpFileID = IDS_HELPFILEPropPage1;
		m_dwDocStringID = IDS_DOCSTRINGPropPage1;
	}

	enum {IDD = IDD_PROPPAGE1};

DECLARE_REGISTRY_RESOURCEID(IDR_PROPPAGE1)
DECLARE_NOT_AGGREGATABLE(CPropPage1)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CPropPage1) 
	COM_INTERFACE_ENTRY(IPropertyPage)
END_COM_MAP()

BEGIN_MSG_MAP(CPropPage1)
	CHAIN_MSG_MAP(IPropertyPageImpl<CPropPage1>)
	COMMAND_HANDLER(IDC_DIRTY, BN_CLICKED, OnClickedDirty)
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	STDMETHOD(Apply)(void)
	{
		ATLTRACE(_T("CPropPage1::Apply\n"));
		for (UINT i = 0; i < m_nObjects; i++)
		{
			// Do something interesting here
			// ICircCtl* pCirc;
			// m_ppUnk[i]->QueryInterface(IID_ICircCtl, (void**)&pCirc);
			// pCirc->put_Caption(CComBSTR("something special"));
			// pCirc->Release();
		}
		m_bDirty = FALSE;
		return S_OK;
	}

	LRESULT OnClickedDirty(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		SetDirty(TRUE);
		return 0;
	}
};

#endif //__PROPPAGE1_H_
