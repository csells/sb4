//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PropertySheets.rc
//
#define IDD_MAINDLG                     104
#define IDD_FIRST_PAGE                  106
#define IDD_SECOND_PAGE                 107
#define IDD_THIRD_PAGE                  108
#define IDC_CALENDAR1                   201
#define IDC_EDIT1                       1007
#define IDC_EDIT2                       1008
#define IDC_MODALWIZARD                 1009
#define IDC_MODALPROPSHEET              1010
#define IDC_MODELESSPROPSHEET           1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
