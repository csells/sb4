// PropertySheets.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "resource.h"
#import "mscal.ocx" raw_interfaces_only, raw_native_types, no_namespace, named_guids
#include "ComPropertyPages\ComPropertyPages.h"
#include "ComPropertyPages\ComPropertyPages_i.c"
#include <AttilaPropSheet.h>

class CFirstPage : public CPropertyPageImpl<CFirstPage>
{
public:
	BEGIN_MSG_MAP(CFirstPage)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
		MESSAGE_HANDLER(WM_LBUTTONDOWN, OnLButtonDown)
		NOTIFY_CODE_HANDLER(PSN_SETACTIVE, OnSetActive)
		NOTIFY_CODE_HANDLER(PSN_APPLY, OnApply)
        CHAIN_MSG_MAP(CPropertyPageImpl<CFirstPage>)
	END_MSG_MAP()
	enum { IDD = IDD_FIRST_PAGE };

    LRESULT OnInitDialog(UINT, WPARAM, LPARAM, BOOL&)
	{
		CWindow(GetParent()).CenterWindow();
		return 1;
	}

	LRESULT OnLButtonDown(UINT, WPARAM, LPARAM, BOOL&)
	{
		MessageBox("Ouch!");
		return 0;
	}

	LRESULT OnSetActive(int, LPNMHDR, BOOL&)
	{
		CPropertySheet sheet(GetParent());
		sheet.SetWizButtons(PSWIZB_NEXT);
		return 0;
	}

	LRESULT OnApply(int, LPNMHDR, BOOL&)
	{
        MessageBox("CFirstPage::OnApply()");
		return 0;
	}
};

class CSecondPage : public CPropertyPageImpl<CSecondPage>
{
public:
	BEGIN_MSG_MAP(CSecondPage)
		NOTIFY_CODE_HANDLER(PSN_SETACTIVE, OnSetActive)
        CHAIN_MSG_MAP(CPropertyPageImpl<CSecondPage>)
	END_MSG_MAP()
	enum { IDD = IDD_SECOND_PAGE };

	LRESULT OnSetActive(int, LPNMHDR, BOOL&)
	{
		CPropertySheet sheet(GetParent());
		sheet.SetWizButtons(PSWIZB_BACK | PSWIZB_NEXT);
		return 0;
	}
};

class CForthPage : public CPropertyPageSiteImpl<CForthPage, &CLSID_PropPage1>
{
public:
    typedef CPropertyPageSiteImpl<CForthPage, &CLSID_PropPage1> _baseClass;

	BEGIN_MSG_MAP(CForthPage)
		NOTIFY_CODE_HANDLER(PSN_SETACTIVE, OnSetActive)
        CHAIN_MSG_MAP(_baseClass)
	END_MSG_MAP()

	LRESULT OnSetActive(int, LPNMHDR, BOOL&)
	{
		CPropertySheet sheet(GetParent());
		sheet.SetWizButtons(PSWIZB_BACK | PSWIZB_FINISH);
                
		return 0;
	}
};

class CThirdPage :
	public CAxPropertyPageImpl<CThirdPage>,
	public IDispEventImpl<IDC_CALENDAR1, CThirdPage>
{
public:
	BEGIN_MSG_MAP(CThirdPage)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
		NOTIFY_CODE_HANDLER(PSN_SETACTIVE, OnSetActive)
		MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
        CHAIN_MSG_MAP(CAxPropertyPageImpl<CThirdPage>)
	END_MSG_MAP()
	enum { IDD = IDD_THIRD_PAGE };

	LRESULT OnInitDialog(UINT, WPARAM, LPARAM, BOOL&)
	{
		AtlAdviseSinkMap(this, true);
		return 0;
	}
	LRESULT OnSetActive(int, LPNMHDR, BOOL&)
	{
		CPropertySheet sheet(GetParent());
		sheet.SetWizButtons(PSWIZB_BACK | PSWIZB_NEXT);
		CForthPage *page = new CForthPage;
		sheet.AddPage(page);
		return 0;
	}
	VOID __stdcall OnClickProgress()
	{
		MessageBox("Hee hee hee!");
	}
	LRESULT OnDestroy(UINT, WPARAM, LPARAM, BOOL&)
	{
		AtlAdviseSinkMap(this, false);
		return 0;
	}
public :
	BEGIN_SINK_MAP(CThirdPage)
		SINK_ENTRY(IDC_CALENDAR1, DISPID_DBLCLICK, OnDblClickCalendar1)
	END_SINK_MAP()

	VOID __stdcall OnDblClickCalendar1()
	{
        MessageBox(__T("Ouch!"));
	}
};

class CMyPropertySheet : public CPropertySheetImpl<CMyPropertySheet>
{
public:
	typedef CPropertySheetImpl<CMyPropertySheet> baseClass;

    CMyPropertySheet(LPCTSTR pszCaption) : baseClass(pszCaption)
    {
    }

    // NOTE: Would be nice to be able to set default
    //       wizard buttons based on order
	BEGIN_PROPPAGE_MAP(CMyPropertySheet)
		PROPPAGE_ENTRY(m_page1)
		PROPPAGE_ENTRY(m_page2)
		PROPPAGE_ENTRY(m_page3)
	END_PROPPAGE_MAP()

	BEGIN_MSG_MAP(CMyPropertySheet)
		CHAIN_MSG_MAP(baseClass)
	END_MSG_MAP()

public:
	CFirstPage  m_page1;
	CSecondPage m_page2;
	CThirdPage  m_page3;
};

class CMainDlg : public CDialogImpl<CMainDlg>
{
public:
    BEGIN_MSG_MAP(CMainDlg)
        COMMAND_ID_HANDLER(IDC_MODALWIZARD, OnModalWizard)
        COMMAND_ID_HANDLER(IDC_MODALPROPSHEET, OnModalPropSheet)
        COMMAND_ID_HANDLER(IDC_MODELESSPROPSHEET, OnModelessPropSheet)
        COMMAND_ID_HANDLER(IDCANCEL, OnCancel)
        MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
    END_MSG_MAP()

    enum { IDD = IDD_MAINDLG };

private:
    LRESULT OnModalWizard(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
    {
	    // Modal Wizard
	    CMyPropertySheet    sheet("My Properties");
	    sheet.dwFlags |= PSH_WIZARD;

	    if (sheet.DoModal(m_hWnd) == IDOK)
	    {
		    MessageBox("OK", "Result");
	    }
	    else
	    {
		    MessageBox("Cancel", "Result");
	    }
        
        return 0;
    }
    
    LRESULT OnModalPropSheet(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
    {
	    // Modal Property Page
	    CMyPropertySheet    sheet("My Properties");
        sheet.dwFlags &= ~PSH_NOAPPLYNOW;

	    if (sheet.DoModal(m_hWnd) == IDOK)
	    {
		    MessageBox("OK", "Result");
	    }
	    else
	    {
		    MessageBox("Cancel", "Result");
	    }
        
        return 0;
    }
    
    LRESULT OnModelessPropSheet(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
    {
        // Modeless Property Page
	    CMyPropertySheet    sheet("My Properties");
        sheet.dwFlags &= ~PSH_WIZARD & ~PSH_NOAPPLYNOW;
        sheet.Create(m_hWnd);

        // Spin the message loop
        MSG msg;
        while( GetMessage(&msg, 0, 0, 0) )
        {
            if( !sheet.Translate(msg) ) DispatchMessage(&msg);
            if( !sheet.m_hWnd ) break;
        }

        return 0;
    }
    
    LRESULT OnCancel(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
    {
        EndDialog(IDCANCEL);
        return 0;
    }

	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		CenterWindow();
		return 0;
	}
};

CComModule _Module;

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
    HRESULT hRes = CoInitialize(NULL);
    ATLASSERT(SUCCEEDED(hRes));

	_Module.Init(0, hInstance);

    CMainDlg().DoModal();

	_Module.Term();
    CoUninitialize();
	return 0;
}
