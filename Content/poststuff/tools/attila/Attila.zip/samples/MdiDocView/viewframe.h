// viewframe.h

#ifndef VIEWFRAME_H_INCLUDE
#define VIEWFRAME_H_INCLUDE

#pragma once

//
// ViewFrame
//
template <class ViewT>
class CViewFrame : public CMdiChildWindowImpl<CViewFrame>
{
    typedef CMdiChildWindowImpl<CViewFrame> _baseClass;

public:

BEGIN_MSG_MAP(CViewFrame)
    MESSAGE_HANDLER(WM_CREATE, OnCreate)    
	MESSAGE_HANDLER(WM_SIZE, OnSize)
    MESSAGE_HANDLER(WM_ERASEBKGND, OnEraseBackground)
    MESSAGE_HANDLER(WM_CLOSE, OnClose)
    MESSAGE_HANDLER(WM_QUERYENDSESSION, OnQueryEndSession)

    COMMAND_ID_HANDLER(ID_WINDOW_NEW, OnWindowNew)

    // Route messages to the base class
    CHAIN_MSG_MAP(_baseClass)

    // Route command messages to the view
    if (uMsg == WM_COMMAND)
    {
        CHAIN_MSG_MAP_MEMBER(m_View)
    }
END_MSG_MAP()

// Message handlers
private:
    LRESULT OnCreate(UINT, WPARAM, LPARAM, BOOL&);
	LRESULT OnSize(UINT, WPARAM, LPARAM, BOOL&);
	LRESULT OnEraseBackground(UINT, WPARAM, LPARAM, BOOL&);
    LRESULT OnClose(UINT, WPARAM, LPARAM, BOOL&);
    LRESULT OnQueryEndSession(UINT, WPARAM, LPARAM, BOOL&);
    LRESULT OnWindowNew(WORD, WORD, HWND, BOOL&);

// Overrides
public:
    void OnFinalMessage(HWND /*hwnd*/);

// Utilities
public:
    ViewT& GetView()
    {
        return m_View;
    }

// Data
private:
    ViewT       m_View;
};

template <class ViewT> LRESULT 
CViewFrame<ViewT>::OnCreate(UINT, WPARAM, LPARAM, BOOL&)
{
	if (m_View.Create(m_hWnd, CWindow::rcDefault) == NULL)
    {
        return -1L;
    }
    return 0L;
}

template <class ViewT> LRESULT 
CViewFrame<ViewT>::OnSize(UINT, WPARAM wParam, LPARAM lParam, BOOL&)
{
    WORD nWidth = LOWORD(lParam);   // width of client area 
    WORD nHeight= HIWORD(lParam);   // height of client area 
    m_View.MoveWindow(0, 0, nWidth, nHeight);
	return 0L;
}

template <class ViewT> LRESULT 
CViewFrame<ViewT>::OnEraseBackground(UINT, WPARAM, LPARAM, BOOL&)
{
    return 1L;
}

template <class ViewT>
void CViewFrame<ViewT>::OnFinalMessage(HWND /*hwnd*/)
{
    delete this;
}

template <class ViewT> LRESULT 
CViewFrame<ViewT>::OnQueryEndSession(UINT, WPARAM, LPARAM, BOOL&)
{
    return m_View.IsDocumentSafe(m_hWnd, _T("WindowsApp")) ? 1L : 0L;
}

template <class ViewT> LRESULT 
CViewFrame<ViewT>::OnClose(UINT, WPARAM, LPARAM, BOOL&)
{
    if (m_View.IsDocumentSafe(m_hWnd, _T("WindowsApp")))
    {
        ::PostMessage(GetParent(), WM_MDIDESTROY, (WPARAM)m_hWnd, 0L);
    }

    return 0L;
}

template <class ViewT> LRESULT 
CViewFrame<ViewT>::OnWindowNew(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
    // Create the frame/view
    CViewFrame<ViewT>* pViewFrame = new CViewFrame<ViewT>();
    if (pViewFrame != NULL)
    {
        pViewFrame->Create(GetParent(), CWindow::rcDefault);

        // Attach the document to the view
        ViewT& newView = pViewFrame->GetView();
        bool bAttached = newView.AttachDocument(m_View.GetDocument());
        _ASSERTE(bAttached);
    }

    return 0L;
}

#endif // !VIEWFRAME_H_INCLUDE
