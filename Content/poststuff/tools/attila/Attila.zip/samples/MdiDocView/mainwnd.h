// mainwnd.h

#pragma once
class CMyDoc;

///////////////////////////////////////////////////////////////////
// A main window class

// Main window class
class CMainWindow : public CMdiFrameWindowImpl<CMainWindow>
{
    typedef CMdiFrameWindowImpl<CMainWindow> _baseClass;

public:
    // ctor / dtor
    CMainWindow();
    virtual ~CMainWindow();

BEGIN_MSG_MAP(CMainWindow)
    COMMAND_ID_HANDLER(ID_FILE_NEW, OnFileNew)
    COMMAND_ID_HANDLER(ID_FILE_OPEN, OnFileOpen)
    COMMAND_ID_HANDLER(ID_FILE_EXIT, OnAppExit)
    COMMAND_ID_HANDLER(ID_HELP_ABOUT, OnHelpAbout)

    // All of the rest of standard Window menu items are pre-defined
    // and handled in CMdiFrameWindowImpl. However, these four don't have
    // standard menu item IDs and therefore need to be forwarded manually.
    COMMAND_ID_HANDLER(ID_WINDOW_CLOSE, _baseClass::OnWindowClose)
    COMMAND_ID_HANDLER(ID_WINDOW_CLOSEALL, _baseClass::OnWindowCloseAll)
    COMMAND_ID_HANDLER(ID_WINDOW_NEXT, _baseClass::OnWindowNext)
    COMMAND_ID_HANDLER(ID_WINDOW_PREVIOUS, _baseClass::OnWindowPrevious)

    // Pass messages to base class
    if (uMsg == WM_COMMAND)
    {
        CHAIN_MSG_MAP_ALT(_baseClass, WM_COMMAND)
    }
    else
    {
        CHAIN_MSG_MAP(_baseClass)
    }
END_MSG_MAP()

// Message handlers
private:
    LRESULT OnFileOpen(WORD, WORD, HWND, BOOL&);
    LRESULT OnFileExit(WORD, WORD, HWND, BOOL&);
    LRESULT OnHelpAbout(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);

public:
    LRESULT OnFileNew(WORD, WORD, HWND, BOOL&);

// Overrides
public:
    virtual void OnFinalMessage(HWND /*hwnd*/);

private:
    CSimpleArray<CMyDoc*>  m_docs;
    unsigned short         m_nDocsCreated;
};
