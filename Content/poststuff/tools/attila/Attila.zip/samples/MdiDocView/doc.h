// doc.h
#ifndef DOC_H_INCLUDE
#define DOC_H_INCLUDE

#pragma once

class CMyDoc : public CDocument
{
public:
    // ctor
    CMyDoc();

// Overrides
public:
    void DeleteContents();
    const TCHAR* GetFilterString() const;
    const TCHAR* GetDefaultExtension() const;

// Serialize
public:
    bool Save(const TCHAR* szPathName);
    bool Load(const TCHAR* szPathName);


// Data access
public:
    void SetText(const TCHAR* szText);
    const TCHAR* GetText() const;

// Data
private:
    TCHAR m_Text[50];
};

#endif // !DOC_H_INCLUDE

