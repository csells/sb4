// view.cpp

#include "stdafx.h"
#include "view.h"
#include "doc.h"
#include "stringdlg.h"
#include "stringlistdlg.h"

//
// Overrides
//
void CMyView::OnDocumentModified()
{
    if (IsWindow())
    {
        Invalidate();
    }
}

void CMyView::OnDocumentNameChanged(const TCHAR* szName)
{
    static TCHAR szDelimiters[] = _T("\\/");

    TCHAR* szFileName, szBuffer[MAX_PATH + 1];
    _tcscpy(szBuffer, szName);

    TCHAR* szToken = szFileName = _tcstok(szBuffer, szDelimiters);
    while (szToken != NULL)
    {
        szToken = _tcstok(NULL, szDelimiters);
        if (szToken != NULL)
        {
            szFileName = szToken;
        }
    }

    if (GetDocument()->GetClientCount() > 1)
    {
        const CSimpleArray<CDocumentClient*>& aClients = GetDocument()->GetClients();
        CDocumentClient* pDocClient = this;
        int clientId = aClients.Find(pDocClient);
        wsprintf(szBuffer, "%s:%d", szFileName, ++clientId);
    }
    else
    {
        _tcscpy(szBuffer, szFileName);
    }

    ::SetWindowText(GetParent(), szBuffer);
}

void CMyView::OnDocumentClientAdded(CDocumentClient* pClient)
{
    OnDocumentNameChanged(GetDocument()->GetName());
}

//
// Utilities
//
CMyDoc* CMyView::GetDocument() const
{
    return static_cast<CMyDoc*>(CDocumentClient::GetDocument());
}

//
// Message handlers
//
LRESULT CMyView::OnPaint(UINT, WPARAM, LPARAM, BOOL& bHandled)
{
    PAINTSTRUCT ps;
    HDC hdc = BeginPaint(&ps);
    RECT rect; GetClientRect(&rect);

    DrawText(hdc, GetDocument()->GetText(), -1, &rect,
             DT_CENTER | DT_VCENTER | DT_SINGLELINE);

    EndPaint(&ps);
    return 0L;
}

LRESULT CMyView::OnFileSave(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
    bool bFailed;
    if (!GetDocument()->OnSave(bFailed) && bFailed)
    {
        TCHAR szText[256];
        const TCHAR* szName = GetDocument()->GetName();
        wsprintf(szText, _T("Error saving %s."), szName);
        
        MessageBox(szText, _T("WindowsApp"), MB_RETRYCANCEL | MB_ICONERROR);
    }
    return 0L;
}

LRESULT CMyView::OnFileSaveAs(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
    bool bFailed;
    if (!GetDocument()->OnSaveAs(bFailed) && bFailed)
    {
        TCHAR szText[256];
        const TCHAR* szName = GetDocument()->GetName();
        wsprintf(szText, _T("Error saving %s."), szName);
        
        MessageBox(szText, _T("WindowsApp"), MB_RETRYCANCEL | MB_ICONERROR);
    }
    return 0L;
}

LRESULT CMyView::OnEditString(WORD, UINT, HWND, BOOL&)
{
    CStringDlg  dlg;
    strcpy(dlg.m_sz, GetDocument()->GetText());

    if (dlg.DoModal(m_hWnd) == IDOK) 
    {
        GetDocument()->SetText(dlg.m_sz);
    }

    return 0;
}

LRESULT CMyView::OnChooseString(WORD, UINT, HWND, BOOL&)
{
    CStringListDlg  dlg;
    strcpy(dlg.m_sz, GetDocument()->GetText());

    if (dlg.DoModal(m_hWnd) == IDOK) 
    {
        GetDocument()->SetText(dlg.m_sz);
    }

    return 0;
}
