// view.h

#ifndef VIEW_H_INCLUDE
#define VIEW_H_INCLUDE

#pragma once
class CMyDoc;

//
// MyView
//
class CMyView : public CViewWindowImpl<CMyView>,
                public CDocumentClient
{
    typedef CViewWindowImpl<CMyView> _baseClass;

public:

BEGIN_MSG_MAP(CMyView)
    MESSAGE_HANDLER(WM_PAINT, OnPaint)
    COMMAND_ID_HANDLER(ID_FILE_SAVE, OnFileSave)
    COMMAND_ID_HANDLER(ID_FILE_SAVEAS, OnFileSaveAs)
    COMMAND_ID_HANDLER(ID_EDIT_STRING, OnEditString)
    COMMAND_ID_HANDLER(ID_CHOOSE_STRING, OnChooseString)

    // Route messages to the base class
    CHAIN_MSG_MAP(_baseClass)
END_MSG_MAP()

// Message handlers
private:
    LRESULT OnPaint(UINT, WPARAM, LPARAM, BOOL&);
    LRESULT OnFileSave(WORD, WORD, HWND, BOOL&);
    LRESULT OnFileSaveAs(WORD, WORD, HWND, BOOL&);
    LRESULT OnEditString(WORD, UINT, HWND, BOOL&);
    LRESULT OnChooseString(WORD, UINT, HWND, BOOL&);

// Overrides
private:
    void OnDocumentModified();
    void OnDocumentNameChanged(const TCHAR* szName);
    void OnDocumentClientAdded(CDocumentClient* pClient);

// Utilities
public:
    CMyDoc* GetDocument() const;

// Data
private:
};

#endif // !VIEW_H_INCLUDE
