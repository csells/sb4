// mainwnd.cpp

#include "stdafx.h"
#include "mainwnd.h"
#include "view.h"
#include "viewframe.h"
#include "doc.h"
#include "aboutbox.h"

CMainWindow::CMainWindow() : m_nDocsCreated(0)
{
    // Retrieve the window class information
    CWndClassInfo& wci = GetWndClassInfo();

    // If the wc hasn't already been registered, update it
    if (!wci.m_atom) 
    {
        wci.m_wc.hIcon = LoadIcon(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDI_BAREBONES));
        wci.m_wc.hIconSm = (HICON)::LoadImage(_Module.GetResourceInstance(), 
                           MAKEINTRESOURCE(IDI_BAREBONES), IMAGE_ICON, 16, 16, LR_DEFAULTCOLOR);
        wci.m_wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
        wci.m_bSystemCursor = FALSE;
        wci.m_lpszCursorID = MAKEINTRESOURCE(IDC_BAREBONES);
    }
}

CMainWindow::~CMainWindow()
{
    for (int i = 0; i < m_docs.GetSize(); ++i)
    {
        CMyDoc* pDoc = m_docs[i];
        delete pDoc;
    }
}

//
// Message handles
//
LRESULT CMainWindow::OnFileExit(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
    DestroyWindow();
    return 0L;
}

LRESULT CMainWindow::OnFileNew(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
    // Create the document
    CMyDoc* pDoc = new CMyDoc();
    if (pDoc != NULL)
    {
        // Create the frame/view
        CViewFrame<CMyView>* pViewFrame = new CViewFrame<CMyView>();
        if (pViewFrame != NULL)
        {
            pViewFrame->Create(m_wndClient, CWindow::rcDefault);

            // Attach the document to the view
            bool bAttached = pViewFrame->GetView().AttachDocument(pDoc);
            _ASSERTE(bAttached);
        }
        else
        {
            delete pDoc;
            return 0L;
        }

        // Set the document defaults
        m_nDocsCreated++;
        TCHAR szName[_MAX_PATH];
        wsprintf(szName, "Untitled%d", m_nDocsCreated);

        pDoc->SetName(szName);
        pDoc->SetText(_T("ATL Doc/View - MDI Sample"));

        // Track the document
        BOOL bSuccess = m_docs.Add(pDoc);
        _ASSERTE(bSuccess);
    }

    return 0L;
}

LRESULT CMainWindow::OnFileOpen(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
    // Create the document
    CMyDoc* pDoc = new CMyDoc();
    if (pDoc != NULL)
    {
        // Open the document
        bool bFailed;
        if (!pDoc->OnOpen(bFailed) && bFailed)
        {
            MessageBox(_T("Error loading file"), _T("WindowsApp"), MB_OK | MB_ICONERROR);
            delete pDoc;
            return 0L;
        }

        // Create the frame/view
        CViewFrame<CMyView>* pViewFrame = new CViewFrame<CMyView>();
        if (pViewFrame != NULL)
        {
            pViewFrame->Create(m_wndClient, CWindow::rcDefault, pDoc->GetName());

            // Attach the document to the view
            bool bAttached = pViewFrame->GetView().AttachDocument(pDoc);
            _ASSERTE(bAttached);
        }
        else
        {
            delete pDoc;
            return 0L;
        }

        // Track the document
        BOOL bSuccess = m_docs.Add(pDoc);
        _ASSERTE(bSuccess);
    }

    return 0L;
}

LRESULT CMainWindow::OnHelpAbout(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
    CAboutBox dlg;
    dlg.DoModal();
    return 0;
}

//
// Overrides
//
void CMainWindow::OnFinalMessage(HWND /*hwnd*/)
{ 
    PostQuitMessage(0); 
}
