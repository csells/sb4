// mainwnd.h

#pragma once

#include "view.h"
#include "doc.h"

///////////////////////////////////////////////////////////////////
// A main window class

// Main Window Traits
typedef CWinTraitsOR<0, WS_EX_CLIENTEDGE, CFrameWinTraits> CMainWinTraits;

// Main window class
class CMainWindow : public CWindowImpl<CMainWindow, CWindow, CMainWinTraits>
{
public:
    // ctor
    CMainWindow();

BEGIN_MSG_MAP(CMainWindow)
    // Handle main window messages
    MESSAGE_HANDLER(WM_CREATE, OnCreate)    
    MESSAGE_HANDLER(WM_SIZE, OnSize)    

    // Route unhandled command messages to the view
    if (uMsg == WM_COMMAND || uMsg == WM_CLOSE)
        CHAIN_MSG_MAP_ALT_MEMBER(m_view, 0)

    // Pick up messages the view hasn't handled
    COMMAND_ID_HANDLER(ID_HELP_ABOUT, OnHelpAbout)
END_MSG_MAP()

// Message handlers
private:
    LRESULT OnCreate(UINT nMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
    LRESULT OnSize(UINT nMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
    LRESULT OnHelpAbout(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);

// Overrides
public:
    virtual void OnFinalMessage(HWND /*hwnd*/);

private:
    CMyView m_view;
    CMyDoc  m_doc;        
};

