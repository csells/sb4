// view.h

#ifndef VIEW_H_INCLUDE
#define VIEW_H_INCLUDE

#pragma once

#include "doc.h"
class CMainWindow;

//
// MyView
//
class CMyView : public CWindowImpl<CMyView>,
                public CDocumentClient
{
public:
    // ctor
    CMyView(CMainWindow* pParentWnd);

BEGIN_MSG_MAP(CMyView)
    MESSAGE_HANDLER(WM_PAINT, OnPaint)
    MESSAGE_HANDLER(WM_CLOSE, OnClose)
    COMMAND_ID_HANDLER(ID_FILE_NEW, OnFileNew)
    COMMAND_ID_HANDLER(ID_FILE_OPEN, OnFileOpen)
    COMMAND_ID_HANDLER(ID_FILE_SAVE, OnFileSave)
    COMMAND_ID_HANDLER(ID_FILE_SAVEAS, OnFileSaveAs)
    COMMAND_ID_HANDLER(ID_FILE_EXIT, OnFileExit)
    COMMAND_ID_HANDLER(ID_EDIT_STRING, OnEditString)
    COMMAND_ID_HANDLER(ID_CHOOSE_STRING, OnChooseString)
END_MSG_MAP()


// Message handlers
private:
    LRESULT OnClose(UINT, WPARAM, LPARAM, BOOL&);
    LRESULT OnPaint(UINT, WPARAM, LPARAM, BOOL&);
    LRESULT OnSysCommand(UINT, WPARAM, LPARAM, BOOL&);
    LRESULT OnFileNew(WORD, WORD, HWND, BOOL&);
    LRESULT OnFileOpen(WORD, WORD, HWND, BOOL&);
    LRESULT OnFileSave(WORD, WORD, HWND, BOOL&);
    LRESULT OnFileSaveAs(WORD, WORD, HWND, BOOL&);
    LRESULT OnFileExit(WORD, WORD, HWND, BOOL&);
    LRESULT OnEditString(WORD, UINT, HWND, BOOL&);
    LRESULT OnChooseString(WORD, UINT, HWND, BOOL&);

// Overrides
private:
    void OnDocumentModified();

// Utilities
private:
    CMyDoc* GetDocument() const;

// Data
private:
    CMainWindow* m_pMainWnd;
};

//
// Utilities
//
inline CMyDoc* CMyView::GetDocument() const
{
    return static_cast<CMyDoc*>(CDocumentClient::GetDocument());
}


#endif // !VIEW_H_INCLUDE
