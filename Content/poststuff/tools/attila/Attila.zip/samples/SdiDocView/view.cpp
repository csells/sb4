// view.cpp

#include "stdafx.h"
#include "view.h"
#include "mainwnd.h"
#include "stringdlg.h"
#include "stringlistdlg.h"

CMyView::CMyView(CMainWindow* pParentWnd)
{
    _ASSERTE(pParentWnd != NULL);
    m_pMainWnd = pParentWnd;
}

//
// Overrides
//
void CMyView::OnDocumentModified()
{
    if (IsWindow())
    {
        Invalidate();
    }
}

//
// Message handlers
//

LRESULT CMyView::OnClose(UINT, WPARAM, LPARAM, BOOL& bHandled)
{
    return OnFileExit(0, 0, NULL, bHandled);
}

LRESULT CMyView::OnPaint(UINT, WPARAM, LPARAM, BOOL& bHandled)
{
    PAINTSTRUCT ps;
    HDC hdc = BeginPaint(&ps);
    RECT rect; GetClientRect(&rect);

    DrawText(hdc, GetDocument()->GetText(), -1, &rect,
             DT_CENTER | DT_VCENTER | DT_SINGLELINE);

    EndPaint(&ps);
    return 0;
}

LRESULT CMyView::OnFileNew(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
    if (IsDocumentSafe(m_hWnd, _T("WindowsApp")))
    {
        GetDocument()->OnNew();
    }
    return 0L;
}

LRESULT CMyView::OnFileOpen(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
    if (IsDocumentSafe(m_hWnd, _T("WindowsApp")))
    {
        bool bFailed;
        if (!GetDocument()->OnOpen(bFailed) && bFailed)
        {
            MessageBox(_T("Error loading file."), 
                       _T("WindowsApp"), 
                       MB_OK | MB_ICONERROR);
        }
    }
    return 0L;
}

LRESULT CMyView::OnFileSave(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
    bool bFailed;
    if (!GetDocument()->OnSave(bFailed) && bFailed)
    {
        TCHAR szText[256];
        const TCHAR* szName = GetDocument()->GetName();
        wsprintf(szText, _T("Error saving %s."), szName);
        
        MessageBox(szText, _T("WindowsApp"), MB_RETRYCANCEL | MB_ICONERROR);
    }
    return 0L;
}

LRESULT CMyView::OnFileSaveAs(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
    bool bFailed;
    if (!GetDocument()->OnSaveAs(bFailed) && bFailed)
    {
        TCHAR szText[256];
        const TCHAR* szName = GetDocument()->GetName();
        wsprintf(szText, _T("Error saving %s."), szName);
        
        MessageBox(szText, _T("WindowsApp"), MB_RETRYCANCEL | MB_ICONERROR);
    }
    return 0L;
}

LRESULT CMyView::OnFileExit(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
    if (IsDocumentSafe(m_hWnd, _T("WindowsApp")))
    {
        m_pMainWnd->DestroyWindow();
    }
    return 0L;
}

LRESULT CMyView::OnEditString(WORD, UINT, HWND, BOOL&)
{
    CStringDlg  dlg;
    strcpy(dlg.m_sz, GetDocument()->GetText());

    if (dlg.DoModal(m_hWnd) == IDOK) 
    {
        GetDocument()->SetText(dlg.m_sz);
    }

    return 0;
}

LRESULT CMyView::OnChooseString(WORD, UINT, HWND, BOOL&)
{
    CStringListDlg  dlg;
    strcpy(dlg.m_sz, GetDocument()->GetText());

    if (dlg.DoModal(m_hWnd) == IDOK) 
    {
        GetDocument()->SetText(dlg.m_sz);
    }

    return 0;
}
