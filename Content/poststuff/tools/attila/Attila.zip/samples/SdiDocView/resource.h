//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WindowsApp.rc
//
#define IDC_MYICON                      2
#define IDD_WINDOWSAPP_DIALOG           102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDC_BAREBONES                   104
#define ID_HELP_ABOUT                   104
#define IDM_EXIT                        105
#define ID_FILE_EXIT                    105
#define IDS_HELLO                       106
#define IDI_WINDOWSAPP                  107
#define IDI_BAREBONES                   107
#define IDI_SMALL                       108
#define IDC_WINDOWSAPP                  109
#define IDR_MENU                        109
#define IDR_MAINFRAME                   128
#define IDD_SET_STRING                  130
#define IDD_CHOOSE_STRING               131
#define IDC_STRING                      1002
#define IDC_LIST                        1003
#define ID_EDIT_STRING                  32771
#define ID_CHOOSE_STRING                32772
#define ID_FILE_NEW                     32773
#define ID_FILE_OPEN                    32774
#define ID_FILE_SAVE                    32775
#define ID_FILE_SAVEAS                  32776
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
