// mainwnd.cpp

#include "stdafx.h"
#include "mainwnd.h"
#include "aboutbox.h"

CMainWindow::CMainWindow() : m_view(this)
{
    // Retrieve the window class information
    CWndClassInfo& wci = GetWndClassInfo();

    // If the wc hasn't already been registered, update it
    if (!wci.m_atom) 
    {
        wci.m_wc.hIcon = LoadIcon(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDI_BAREBONES));
        wci.m_wc.hIconSm = (HICON)::LoadImage(_Module.GetResourceInstance(), 
                           MAKEINTRESOURCE(IDI_BAREBONES), IMAGE_ICON, 16, 16, LR_DEFAULTCOLOR);
        wci.m_wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
        wci.m_bSystemCursor = FALSE;
        wci.m_lpszCursorID = MAKEINTRESOURCE(IDC_BAREBONES);
    }

    // Attach the view as a client of the document
    bool bSuccess = m_view.AttachDocument(&m_doc);
    _ASSERTE(bSuccess);

    m_doc.SetText(_T("ATL Doc/View"));
}

//
// Message handles
//
LRESULT CMainWindow::OnCreate(UINT nMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
    HWND hWnd = m_view.Create(m_hWnd, CWindow::rcDefault);
    return (hWnd != NULL) ? 0 : -1;
}

LRESULT CMainWindow::OnSize(UINT nMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
    RECT rect = { 0, 0, LOWORD(lParam), HIWORD(lParam) };
    return m_view.MoveWindow(&rect);
}

LRESULT CMainWindow::OnHelpAbout(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
    CAboutBox dlg;
    dlg.DoModal();
    return 0;
}

//
// Overrides
//
void CMainWindow::OnFinalMessage(HWND /*hwnd*/)
{ 
    PostQuitMessage(0); 
}
