// GDI.cpp : Defines the entry point for the application.
//

#include "stdafx.h"

CComModule _Module;

class CGdiView : public CViewWindowImpl<CGdiView>
{
public:
	typedef CViewWindowImpl<CGdiView> _super;

BEGIN_MSG_MAP(CGdiView)
	MESSAGE_HANDLER(WM_PAINT, OnPaint)
	CHAIN_MSG_MAP(_super)
END_MSG_MAP()

	LRESULT OnPaint(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		CRect rcClient;
		GetClientRect(&rcClient);
		CRect rc( rcClient );

		CGdiPaintDC dc(m_hWnd);

		CGdiBitmap bmpSurface( dc, rcClient.Width(), rcClient.Height() );
		CGdiMemDC memDC( dc, bmpSurface );  

		// Erases the bitmap background...
		CGdiBrush brBack( RGB( 0x46, 0x82, 0xB4 ));
		memDC.SelectObject( brBack );
		memDC.Rectangle(rc);

		CGdiPen pen(RGB( 0x46, 0x82, 0xB4 ), 1, PS_DASH);
		memDC.SelectObject(pen);

//		CGdiBrush bkBrush(HS_CROSS, RGB( 0x46, 0x82, 0xB4 ));
//		memDC.SelectObject(bkBrush);

		CGdiBitmap bmp;
		bmp.LoadBitmapFromFile(_T("paisley.bmp"));
		CGdiBrush bmpBrush(bmp);

		memDC.SelectObject(bmpBrush);

		rc.InflateRect(-20);  

		memDC.Rectangle(rc);
		memDC.Ellipse(rc);

		memDC.SetBkMode(TRANSPARENT);  

		CGdiBrush brush(NULL_BRUSH); // GetStockObject...
		pen.CreatePen(RGB( 0xB2, 0x22, 0x22 ), 2);
		memDC.SelectObject(pen);
		memDC.SelectObject(brush);

		rc.InflateRect(-50);
		memDC.Ellipse(rc);  

		static unsigned char pattern[] = {
				0x0A, 0xA0, 0x0A, 0xA0, 
				0x0A, 0xA0, 0x0A, 0xA0 };

		brush.CreatePatternBrush(pattern);
		memDC.SelectObject(brush);

		// This will set the brush foreground color
		// since it was created from a monochrome bitmap.
		memDC.SetTextColor(RGB( 0xD2, 0xB4, 0x8C ));
		memDC.Rectangle(rc);  


		// fun with regions


		CGdiRegion rgn, rgn2;
		long h = rc.Height() / 2;
		long w = rc.Width() / 2;
		CRect r;

		// top left
		r.SetRect(rc.left, rc.top, rc.left + w, rc.top + h);
		rgn.CreateEllipticRgn(r);
		rgn2.CreateRectRgn(r.left, r.top, r.right / 2, r.bottom / 2);
		memDC.InvertRgn(rgn ^ rgn2);

		// top right
		r.SetRect(rc.left + w, rc.top, rc.right, rc.top + h);
		rgn.CreateEllipticRgn(r);
		r.InflateRect(-min(r.Width()/3, r.Height()/3));
		rgn2.CreateRectRgn(r);
		memDC.FillRgn(rgn ^ rgn2, CGdiBrush(RGB( 0x8F, 0xBC, 0x8F )));
		memDC.FrameRgn(rgn ^ rgn2, brBack, 10, 2);

		// bottom left
		r.SetRect(rc.left, rc.top + h, rc.left + w, rc.bottom);
		rgn.CreateEllipticRgn(r);
		rgn2.CreateRectRgn(r.left, r.top + h/2, r.right - w/2, r.bottom);
		memDC.FillRgn(rgn ^ rgn2, CGdiBrush(RGB( 0xFF, 0xA5, 0x00 )));
		memDC.FrameRgn(rgn ^ rgn2, brBack, 10, 2);
		
		// bottom right
		r.SetRect(rc.left + w, rc.top + h, rc.right, rc.bottom);
		rgn.CreateEllipticRgn(r);
		rgn2.CreateRectRgn(r);
		memDC.InvertRgn(rgn ^ rgn2);
		memDC.FillRgn(rgn ^ rgn2, CGdiBrush(RGB( 0x46, 0x82, 0xB4 )));

		memDC.SetTextAlign(TA_CENTER | TA_BASELINE);
		CGdiFont font(memDC, _T("Courier New"), 64, FW_BOLD);
		memDC.SelectObject(font);  

		memDC.BeginPath();
		memDC.ExtTextOut((rc.left + rc.right) / 2, (rc.top + rc.bottom) / 2, 0, NULL, _T("Attila Rules!"), 12);
		memDC.EndPath();

		CGdiRegion rgnText;
		rgnText.CreateFromPath(memDC);
		memDC.InvertRgn(rgnText);
		memDC.FrameRgn(rgnText, brBack, 2, 2);

		dc.BitBlt(rcClient, memDC);

		return 1L;
	}
};

class CGdiFrame : public CFrameWindowImpl<CGdiFrame>
{
public:
	typedef CFrameWindowImpl<CGdiFrame> _super;

BEGIN_MSG_MAP(CGdiFrame)
	MESSAGE_HANDLER(WM_CREATE, OnCreate)
	CHAIN_MSG_MAP(_super)
END_MSG_MAP()

protected:
	LRESULT OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{		
		m_view.Create(m_hWnd, CWindow::rcDefault);
		return 1L;
	}

	virtual BOOL ResizeElements()
	{
		RECT rc;
		GetClientRect(&rc);
		m_view.SetWindowPos(NULL, rc.left, rc.top,rc.right - rc.left, rc.bottom - rc.top,
            SWP_NOZORDER | SWP_NOACTIVATE);
		return TRUE;
	}

	CGdiView m_view;
};

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR     lpCmdLine,
                     int       nCmdShow)
{
	_Module.Init(0, hInstance);

 	CGdiFrame    frame;
	
	frame.Create(0, CWindow::rcDefault, _T("GDI rules!"));
	frame.CenterWindow();
	frame.ShowWindow(nCmdShow);
	frame.UpdateWindow();
	
	MSG msg;
	while (GetMessage(&msg, 0, 0, 0))
	{
		if(!CMsgTranslator::RunThroughTranslators(msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	_Module.Term();

	return 0;
}



