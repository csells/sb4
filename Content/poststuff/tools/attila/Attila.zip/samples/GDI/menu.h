
/////////////////////////////////////////////////////////////////////////////
// CMenu

class CMenu
{
public:
	HMENU m_hMenu;

// Constructors
	CMenu(HMENU menu = NULL)
	{
		m_hMenu = menu;
	}
	CMenu& operator=(HMENU menu)
	{
		m_hMenu = menu;
		return *this;
	}
	BOOL Attach(HMENU menu)
	{
		ATLASSERT(::IsMenu(menu));
		m_hMenu = menu;
		return (m_hMenu != 0);
	}
	HMENU Detach()
	{
		HMENU menu = m_hMenu;
		m_hMenu = NULL;
		return menu;
	}
	BOOL CreateMenu()
	{
		return Attach(::CreateMenu());
	}
	BOOL CreatePopupMenu()
	{
		return Attach(::CreatePopupMenu());
	}
	BOOL LoadMenu(LPCTSTR lpszResourceName)
	{
		return Attach(::LoadMenu(_Module.GetModuleInstance(), lpszResourceName));
	}
	BOOL LoadMenu(UINT nIDResource)
	{
		return Attach(::LoadMenu(_Module.GetModuleInstance(),
			MAKEINTRESOURCE(nIDResource)));
	}
	BOOL LoadMenuIndirect(const void* lpMenuTemplate)
	{
		return Attach(::LoadMenuIndirect(lpMenuTemplate));
	}
	BOOL DestroyMenu()
	{
		if (m_hMenu == NULL)
			return FALSE;
		return ::DestroyMenu(Detach());
	}

// Attributes
	operator HMENU() const
	{
		return m_hMenu;
	}

// CMenu Operations
	BOOL DeleteMenu(UINT nPosition, UINT nFlags)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::DeleteMenu(m_hMenu, nPosition, nFlags);
	}

	BOOL TrackPopupMenu(UINT nFlags, int x, int y, HWND hWnd, LPCRECT lpRect = 0)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::TrackPopupMenu(m_hMenu, nFlags, x, y, 0, hWnd, lpRect);
	}

// CMenuItem Operations
	BOOL AppendMenu(UINT nFlags, UINT nIDNewItem = 0, LPCTSTR lpszNewItem = NULL)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::AppendMenu(m_hMenu, nFlags, nIDNewItem, lpszNewItem);
	}
	BOOL AppendMenu(UINT nFlags, UINT nIDNewItem, HBITMAP bmp)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::AppendMenu(m_hMenu, nFlags | MF_BITMAP, nIDNewItem,
			reinterpret_cast<LPCTSTR>(bmp));
	}
	UINT CheckMenuItem(UINT nIDCheckItem, UINT nCheck)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::CheckMenuItem(m_hMenu, nIDCheckItem, nCheck);
	}
	UINT EnableMenuItem(UINT nIDEnableItem, UINT nEnable)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::EnableMenuItem(m_hMenu, nIDEnableItem, nEnable);
	}
	UINT GetMenuItemCount() const
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::GetMenuItemCount(m_hMenu);
	}
	UINT GetMenuItemID(int nPos) const
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::GetMenuItemID(m_hMenu, nPos);
	}
	UINT GetMenuState(UINT nID, UINT nFlags) const
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::GetMenuState(m_hMenu, nID, nFlags);
	}
	int GetMenuString(UINT nIDItem, LPTSTR lpString, int nMaxCount, UINT nFlags) const
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::GetMenuString(m_hMenu, nIDItem, lpString, nMaxCount, nFlags);
	}
	BOOL GetMenuItemInfo(UINT nIDItem, LPMENUITEMINFO lpMenuItemInfo, BOOL fByPos = FALSE)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::GetMenuItemInfo(m_hMenu, nIDItem, fByPos, lpMenuItemInfo);
	}
	HMENU GetSubMenu(int nPos) const
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::GetSubMenu(m_hMenu, nPos);
	}
	BOOL InsertMenu(UINT nPosition, UINT nFlags, UINT nIDNewItem = 0,
					LPCTSTR lpszNewItem = NULL)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::InsertMenu(m_hMenu, nPosition, nFlags, nIDNewItem, lpszNewItem);
	}
	BOOL InsertMenu(UINT nPosition, UINT nFlags, UINT nIDNewItem, HBITMAP bmp)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::InsertMenu(m_hMenu, nPosition, nFlags | MF_BITMAP, nIDNewItem,
			reinterpret_cast<LPCTSTR>(bmp));
	}
	BOOL ModifyMenu(UINT nPosition, UINT nFlags, UINT nIDNewItem = 0,
					LPCTSTR lpszNewItem = NULL)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::ModifyMenu(m_hMenu, nPosition, nFlags, nIDNewItem, lpszNewItem);
	}
	BOOL ModifyMenu(UINT nPosition, UINT nFlags, UINT nIDNewItem, HBITMAP bmp)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::ModifyMenu(m_hMenu, nPosition, nFlags | MF_BITMAP, nIDNewItem,
			reinterpret_cast<LPCTSTR>(bmp));
	}
	BOOL RemoveMenu(UINT nPosition, UINT nFlags)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::RemoveMenu(m_hMenu, nPosition, nFlags);
	}
	BOOL SetMenuItemBitmaps(UINT nPosition, UINT nFlags, HBITMAP bmpUnchecked,
							HBITMAP bmpChecked)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::SetMenuItemBitmaps(m_hMenu, nPosition, nFlags, bmpUnchecked, bmpChecked);
	}
	BOOL CheckMenuRadioItem(UINT nIDFirst, UINT nIDLast, UINT nIDItem, UINT nFlags)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::CheckMenuRadioItem(m_hMenu, nIDFirst, nIDLast, nIDItem, nFlags);
	}
	BOOL SetDefaultItem(UINT uItem, BOOL fByPos = FALSE)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::SetMenuDefaultItem(m_hMenu, uItem, fByPos);
	}
	UINT GetDefaultItem(UINT gmdiFlags, BOOL fByPos = FALSE)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::GetMenuDefaultItem(m_hMenu, fByPos, gmdiFlags);
	}

// Context Help Functions
	BOOL SetMenuContextHelpId(DWORD dwContextHelpId)
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::SetMenuContextHelpId(m_hMenu, dwContextHelpId);
	}
	DWORD GetMenuContextHelpId() const
	{
		ATLASSERT(::IsMenu(m_hMenu));
		return ::GetMenuContextHelpId(m_hMenu);
	}
};

