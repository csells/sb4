// Class CViewTextDlg -- copied from the MdiDocView sample
// This is work in progress -- attempting to demonstrate command UI in a dialog
// Not done yet.

#include "AttilaCmdUI.h"
#include <WinUser.h>

class CViewTextDlgT : public CDialogImpl<CViewTextDlgT>
{
	typedef  CDialogImpl<CViewTextDlgT> baseClass;

public:

	BEGIN_MSG_MAP(CViewTextDlgT)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
		COMMAND_ID_HANDLER(IDOK, OnOK)
		COMMAND_ID_HANDLER(IDCANCEL, OnCancel)
		COMMAND_UI_HANDLER(IDOK, OnUpdateOK)
		MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
	END_MSG_MAP()

	enum { IDD = IDD_VIEW_TEXT };
		TCHAR		m_szViewText[256];
		LPTSTR		m_pOldText;

	CViewTextDlgT()
	{
		m_pOldText	= NULL;
	}
	void Init(LPTSTR pOldText)
	{
		m_pOldText	= pOldText;
	}
	void OnUpdateOK(UINT nId, CCmdUI* pCmdUI)
	{
		// Check the length of the string
		int nLen = m_edtText.GetWindowTextLength();

		// Enable the OK button only if the string is of non-zero length
		pCmdUI->Enable(nLen ? TRUE : FALSE);
	}
	LPCTSTR GetText() const
	{
		return m_szViewText;
	}

private:
	LRESULT OnDestroy(UINT, WPARAM, LPARAM, BOOL&)
	{
		*m_szViewText	= 0;
		return 0;
	}
	LRESULT OnInitDialog(UINT, WPARAM, LPARAM, BOOL&)
	{
		CenterWindow();

		*m_szViewText		= 0;

		// Cache HWNDs
		m_edtText.Attach(GetDlgItem(IDC_VIEW_TEXT));
		m_ok.Attach(GetDlgItem(IDOK));

		// Copy the string from the data member to the child control (DDX)
		m_edtText.SetWindowText(m_szViewText);

		m_edtText.SetFocus();

		return 1; // Let dialog manager set initial focus
	}


	LRESULT OnOK(WORD, UINT, HWND, BOOL&)
	{
		// Copy the string from the child control to the data member (DDX)

		m_edtText.GetWindowText(m_szViewText, 255);
		if ( NULL != m_pOldText )
			lstrcpy(m_pOldText, m_szViewText);

		::RedrawWindow(GetParent(), NULL, NULL, RDW_INVALIDATE | RDW_ERASE | RDW_ALLCHILDREN);

		EndDialog(0);
		return 0;
	}

	LRESULT OnCancel(WORD, UINT, HWND, BOOL&)
	{
		EndDialog(0);
		return 0;
	}

private:
	CWindow m_edtText;
	CWindow m_ok;
};


typedef CCmdUIDlgT<CViewTextDlgT> CViewTextDlg;
