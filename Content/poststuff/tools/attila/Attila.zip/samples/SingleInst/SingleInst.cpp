// SingleInst.cpp

#include "stdafx.h"
#include "resource.h"
#include "MyMainFrame.H"

CMyModule _Module;

void CMyModule::On2ndInstance(LPCTSTR pszCmdLine)
{
    MessageBox(0, pszCmdLine, __T("2nd Instance Command Line:"), MB_SETFOREGROUND);
}

extern "C" int WINAPI _tWinMain(HINSTANCE hInstance,HINSTANCE , LPTSTR lpCmdLine, int nShowCmd)
{
    _Module.Init(lpCmdLine, 0, hInstance);
    
	if( _Module.Is2ndInstance() )
	{
		_Module.Term();
		return 0L;
	}

    // Init common controls
    INITCOMMONCONTROLSEX iccx = { sizeof(iccx), ICC_ALL };
	InitCommonControlsEx(&iccx);

	//Create the App Frame
	CMyFrame frame;
	HMENU hmenu = LoadMenu(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_MAINFRAME));
	frame.Create(0, CWindow::rcDefault, _T("Single Instance App"), 0, 0, (UINT)hmenu);
	frame.CenterWindow();
	frame.ShowWindow(nShowCmd);
	frame.UpdateWindow();

    MSG msg;
	AttilaPumpMessagesWithCmdUI(&frame, &msg);

    _Module.Term();
	return msg.wParam;
}
