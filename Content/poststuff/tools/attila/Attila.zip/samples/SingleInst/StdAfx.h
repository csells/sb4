// stdafx.h : include file for standard system include files,
//      or project specific include files that are used frequently,
//      but are changed infrequently

#if !defined(AFX_STDAFX_H__B479F360_124E_11D3_BA9E_000000000000__INCLUDED_)
#define AFX_STDAFX_H__B479F360_124E_11D3_BA9E_000000000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers

#include <atlbase.h>
#include <AttilaModules.H>

class CMyModule :
    public CComModule,
    public CComSingleInstanceModule<CMyModule>
{
public:
	HRESULT Init(LPCTSTR pszCmdLine, _ATL_OBJMAP_ENTRY* p, HINSTANCE h, const GUID* plibid = NULL)
	{
		HRESULT hr = CComModule::Init(p, h, plibid);
        if( FAILED(hr) ) return hr;

        hr = CComSingleInstanceModule<CMyModule>::Init(pszCmdLine);
        if( FAILED(hr) ) return hr;

        return S_OK;
	}

	void Term()
	{
        CComSingleInstanceModule<CMyModule>::Term();
		CComModule::Term();
	}

    void On2ndInstance(LPCTSTR pszCmdLine);
};

extern CMyModule _Module;

#include <AttilaFrame.H>
#include <AttilaView.H>
#include <Attilabars.H>
#include <AttilaCmdUI.h>
#include <AttilaRes.h>
#include <AttilaMsgPump.h>

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__B479F360_124E_11D3_BA9E_000000000000__INCLUDED)
