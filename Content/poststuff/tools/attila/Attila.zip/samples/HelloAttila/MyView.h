// MyView.h

#pragma once
#ifndef INC_MYVIEW
#define INC_MYVIEW

/////////////////////////////////////////////////////////////////////////////
// This is the View parented by the Frame

class CMyView: public CViewWindowImpl<CMyView>
{
public:
	typedef CViewWindowImpl<CMyView> baseclass;

	BEGIN_MSG_MAP(CMyView)
		MESSAGE_HANDLER(WM_PAINT, OnPaint)
		CHAIN_MSG_MAP(baseclass)
	END_MSG_MAP()

	LRESULT OnPaint(UINT, WPARAM, LPARAM, BOOL&)
    {
        ATLTRACE("OnPaint()\n");

        // Paint the window
        PAINTSTRUCT ps;
        HDC         hdc = BeginPaint(&ps);
        
        SetTextColor(hdc, RGB(255,0,0) );

        RECT    rect; GetClientRect(&rect);
        DrawText(hdc, __T("Hello, Attila!"), -1, &rect, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
        
        EndPaint(&ps);
        return 0;
    }
};

#endif  // INC_MYVIEW
