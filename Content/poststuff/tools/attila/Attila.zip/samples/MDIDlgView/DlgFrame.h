// DlgFrame.h

#pragma once
#ifndef INC_DLGFRAME
#define INC_DLGFRAME

/////////////////////////////////////////////////////////////////////////////
// This is the View parented by the Frame

class CMyDialogView: public CViewDialogImpl<CMyDialogView>
{
public:
	typedef CViewDialogImpl<CMyDialogView> baseclass;
	
	BEGIN_MSG_MAP(CMyDialogView)
		CHAIN_MSG_MAP(baseclass)
	END_MSG_MAP()
	
	enum { IDD = IDD_FORMVIEW };
};


/////////////////////////////////////////////////////////////////////////////
// This is the MDI Child Frame parenting the View

class CDialogMdiChild: public CMdiChildWindowImpl<CDialogMdiChild>
{
public:
	typedef CMdiChildWindowImpl<CDialogMdiChild>	baseclass;
	
	BEGIN_MSG_MAP(CDialogMdiChild)
		MESSAGE_HANDLER(WM_CREATE, OnCreate)    
		MESSAGE_HANDLER(WM_SETFOCUS, OnSetFocus)    
		MESSAGE_HANDLER(WM_SIZE, OnSize)
		MESSAGE_HANDLER(WM_ERASEBKGND, OnEraseBKGnd)
		CHAIN_MSG_MAP(baseclass)
	END_MSG_MAP()	

    LRESULT OnCreate(UINT, WPARAM, LPARAM, BOOL&)
    {
		m_ChildDlgView.Create(m_hWnd);
        return 0;
    }

	LRESULT OnEraseBKGnd(UINT, WPARAM, LPARAM, BOOL&)
    {
        return 1;//reduces flicker
    }
	
	LRESULT OnSetFocus(UINT, WPARAM, LPARAM, BOOL&)
    {
		m_ChildDlgView.SetFocus();
        return 0;
    }
    
	LRESULT OnSize(UINT , WPARAM , LPARAM , BOOL& )
	{
		DefWindowProc();
		RECT rc; ::GetClientRect(GetParent(),&rc);
		m_ChildDlgView.SetWindowPos(HWND_TOP, &rc,SWP_NOZORDER | SWP_NOACTIVATE);
		return 0L;
	}

    /*
	BOOL Translate(MSG* pmsg,HACCEL hAccel)
	{
		return m_ChildDlgView.Translate(pmsg,hAccel);
	}
    */

    void OnFinalMessage(HWND)
    {
        delete this;
    }

private:
	CMyDialogView  m_ChildDlgView;
};

#endif
