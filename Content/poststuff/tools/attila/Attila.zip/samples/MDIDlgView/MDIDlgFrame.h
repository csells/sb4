// MDIDlgFrame.h

#pragma once
#ifndef INC_MDIFRAME
#define INC_MDIFRAME

#include "HelloFrame.h"
#include "RectFrame.h"
#include "DlgFrame.h"

class CMyMdiDlgFrame : public CMdiFrameWindowImpl<CMyMdiDlgFrame>
{
public:
    CMyMdiDlgFrame() {}
    
    typedef CMdiFrameWindowImpl<CMyMdiDlgFrame> baseClass;

    BEGIN_MSG_MAP(CMyMdiDlgFrame)
        MESSAGE_HANDLER(WM_CREATE, OnCreate)
        MESSAGE_HANDLER(WM_SIZE, OnSize)		
        
        COMMAND_ID_HANDLER(IDM_FILE_NEWHELLO, OnFileNewHello)
        COMMAND_ID_HANDLER(IDM_FILE_NEWRECT, OnFileNewRect)
        COMMAND_ID_HANDLER(IDM_FILE_NEWDIALOG, OnFileNewDlg)
        COMMAND_ID_HANDLER(ID_APP_EXIT, OnAppExit)
        COMMAND_ID_HANDLER(ID_APP_ABOUT, OnAbout)
        // All of the rest of standard Window menu items are pre-defined
        // and handled in CMdiFrameWindowImpl. However, these four don't have
        // standard menu item IDs and therefore need to be forwarded manually.
        COMMAND_ID_HANDLER(ID_WINDOW_CLOSE, baseClass::OnWindowClose)
        COMMAND_ID_HANDLER(ID_WINDOW_CLOSEALL, baseClass::OnWindowCloseAll)
        COMMAND_ID_HANDLER(ID_WINDOW_NEXT, baseClass::OnWindowNext)
        COMMAND_ID_HANDLER(ID_WINDOW_PREVIOUS, baseClass::OnWindowPrevious)
        CHAIN_MSG_MAP(baseClass)
    END_MSG_MAP()
        
    LRESULT OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
    {
        // Create the Statusbar
        m_wndStatusBar.Create(m_hWnd,CWindow::rcDefault);
        
        // Fill an array of Toolbar buttons
        TBBUTTON tbButtons[] = 
        {
            { 0,	IDM_FILE_NEWHELLO,					TBSTATE_ENABLED				,TBSTYLE_BUTTON, 0L, 0},
            { 1,	IDM_FILE_NEWRECT,					TBSTATE_ENABLED				,TBSTYLE_BUTTON, 0L, 0},
            { 2,	IDM_FILE_NEWDIALOG,					TBSTATE_ENABLED				,TBSTYLE_BUTTON, 0L, 0},
            { 3,	ID_FILE_OPEN,						0							,TBSTYLE_BUTTON, 0L, 0},
            { 4,	ID_FILE_SAVE,						0							,TBSTYLE_BUTTON, 0L, 0},
            { 5,	ID_EDIT_CUT,						0							,TBSTYLE_BUTTON, 0L, 0},
            { 6,	ID_EDIT_COPY,						0							,TBSTYLE_BUTTON, 0L, 0},
            { 7,	ID_EDIT_PASTE,						0							,TBSTYLE_BUTTON, 0L, 0},
            { 8,	ID_APP_ABOUT,						TBSTATE_ENABLED				,TBSTYLE_BUTTON, 0L, 0}
        };
        
        // Create the Toolbar
        m_wndToolBar.Create(m_hWnd,CWindow::rcDefault,tbButtons,9,IDR_MAINFRAME);
        
        bHandled = FALSE;	
        return 0L;
    }
    
    LRESULT OnSize(UINT  uMsg , WPARAM  wParam , LPARAM  lParam , BOOL&  bHandled)
    {
        bHandled = ResizeElements();
        return 0L;
    }
    
    LRESULT OnFileNewDlg(WORD, WORD, HWND, BOOL&)
    {
        // Create a Dlg child window
        static HMENU hmenu = LoadMenu(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_MENU));
        CDialogMdiChild* pChild = new CDialogMdiChild;
        pChild->Create(m_wndClient, CWindow::rcDefault, __T("DialogView"), 0, hmenu);
        
        return 0;
    }
    
    LRESULT OnFileNewHello(WORD, WORD, HWND, BOOL&)
    {
        // Create a Hello child window
        static HMENU    hmenu = LoadMenu(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_HELLO));
        CHelloMdiChild*  pChild = new CHelloMdiChild;
        pChild->Create(m_wndClient, CWindow::rcDefault, __T("Hello"), 0, hmenu);
        return 0;
    }
    
    LRESULT OnFileNewRect(WORD, WORD, HWND, BOOL&)
    {
        // Create a Rect child window
        static HMENU    hmenu = LoadMenu(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_RECT));
        CRectMdiChild*  pChild = new CRectMdiChild;
        pChild->Create(m_wndClient, CWindow::rcDefault, __T("Rectangles"), 0, hmenu);
        return 0;
    }

    LRESULT OnAppExit(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
    {	
        DestroyWindow(); //Will make the Frame call PostQuitMessage
        return 0L;
    }

    LRESULT OnAbout(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
    {
        CSimpleDialog<IDD_ABOUT> dlg;
        dlg.DoModal();
        return 0L;
    }

public://virtuals
    BOOL ResizeElements()
    {
        m_wndStatusBar.SendMessage(WM_SIZE);
        RECT rc,rcToolPanel,rcStatus;
        GetClientRect(&rc);
        
        GetClientRect(&rc);
        m_wndToolBar.SetWindowPos(NULL,rc.left, rc.top, rc.right - rc.left,30,SWP_NOZORDER | SWP_NOACTIVATE);
        
        m_wndToolBar.GetWindowRect(&rcToolPanel);
        rc.top +=  (rcToolPanel.bottom - rcToolPanel.top);
        
        m_wndStatusBar.GetWindowRect(&rcStatus);
        rc.bottom -= (rcStatus.bottom - rcStatus.top);
        
        m_wndClient.SetWindowPos(NULL, rc.left, rc.top,rc.right - rc.left, rc.bottom - rc.top,
            SWP_NOZORDER | SWP_NOACTIVATE);
        
        return TRUE;
    }
    
private:
    CToolBar			m_wndToolBar;		
    CStatusBar			m_wndStatusBar;	
};

#endif // INC_MDIFRAME
