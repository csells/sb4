// RectFrame.h

#pragma once
#ifndef INC_RECTFRAME
#define INC_RECTFRAME

/////////////////////////////////////////////////////////////////////////////
// This is the View parented by the Frame

class CRectView: public CViewWindowImpl<CRectView>
{
public:
	typedef CViewWindowImpl<CRectView> baseclass;

	BEGIN_MSG_MAP(CRectView)
		MESSAGE_HANDLER(WM_CREATE, OnCreate)
		MESSAGE_HANDLER(WM_TIMER, OnTimer)
		MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
		CHAIN_MSG_MAP(baseclass)
	END_MSG_MAP()

	LRESULT OnCreate(UINT, WPARAM, LPARAM, BOOL&)
    {
        SetTimer(1, 250);
        return 0;
    }

    LRESULT OnTimer(UINT, WPARAM, LPARAM, BOOL&)
    {
        if( IsIconic() ) return 0;

        RECT    rect; GetClientRect(&rect);
        long    cxClient = rect.right - rect.left;
        long    cyClient = rect.bottom - rect.top;
        long    xLeft    = rand () % (cxClient ? cxClient : 1);
        long    xRight   = rand () % (cxClient ? cxClient : 1);
        long    yTop     = rand () % (cyClient ? cyClient : 1);
        long    yBottom  = rand () % (cyClient ? cyClient : 1);
        long    nRed     = rand () & 255;
        long    nGreen   = rand () & 255;
        long    nBlue    = rand () & 255;
        HDC     hdc = GetDC();
        HBRUSH  hbrush = CreateSolidBrush(RGB (nRed, nGreen, nBlue));

        SelectObject(hdc, hbrush);
        Rectangle(hdc, min(xLeft, xRight), min(yTop, yBottom), max(xLeft, xRight), max(yTop, yBottom));
        ReleaseDC(hdc);
        DeleteObject(hbrush);

        return 0;
    }

    LRESULT OnDestroy(UINT, WPARAM, LPARAM, BOOL&)
    {
        KillTimer(1);
        return 0;
    }
};

/////////////////////////////////////////////////////////////////////////////
// This is the MDI Child Frame parenting the View

class CRectMdiChild : public CMdiChildWindowImpl<CRectMdiChild>
{
public:
	typedef CMdiChildWindowImpl<CRectMdiChild> baseClass;

BEGIN_MSG_MAP(CRectMdiChild)
 MESSAGE_HANDLER(WM_CREATE, OnCreate)
	MESSAGE_HANDLER(WM_SETFOCUS, OnSetFocus)
	MESSAGE_HANDLER(WM_SIZE, OnSize)		
    CHAIN_MSG_MAP(baseClass)
END_MSG_MAP()
  
	LRESULT OnCreate(UINT, WPARAM , LPARAM , BOOL& )
	{
		//Create the View
		m_RectView.Create(m_hWnd,CWindow::rcDefault);
		return 0L;
	}
	LRESULT OnSize(UINT,WPARAM,LPARAM,BOOL& bHandled)
	{
		DefWindowProc();
		bHandled = ResizeElements();
		return 0L;
	}
    
	LRESULT OnSetFocus(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		m_RectView.SetFocus();
		return 0L;
	}

public: //virtuals
	BOOL ResizeElements()
	{
		RECT rc; GetClientRect(&rc);
		m_RectView.SetWindowPos(NULL, &rc,SWP_NOZORDER | SWP_NOACTIVATE);
		return TRUE;
	}
    void OnFinalMessage(HWND)
    {
        delete this;
    }

private:
	CRectView				m_RectView;
};

#endif // INC_RECTFRAME
