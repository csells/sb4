// HelloView.h

#pragma once
#ifndef INC_HELLOFRAME
#define INC_HELLOFRAME

/////////////////////////////////////////////////////////////////////////////
// This is the View parented by the Frame

class CHelloView: public CViewWindowImpl<CHelloView>
{
public:
    typedef CViewWindowImpl<CHelloView> baseClass;
    
    CHelloView(): m_nColorIndex(0) {}
    
    BEGIN_MSG_MAP(CHelloView)
        MESSAGE_HANDLER(WM_PAINT, OnPaint)
        CHAIN_MSG_MAP(baseClass)
    END_MSG_MAP()
        
    LRESULT OnPaint(UINT, WPARAM, LPARAM, BOOL&)
    {
        // Paint the window
        PAINTSTRUCT ps;
        HDC         hdc = BeginPaint(&ps);
        
        SetTextColor(hdc, s_rgColors[m_nColorIndex]);
        
        RECT    rect; GetClientRect(&rect);
        DrawText(hdc, __T("Hello, Attila!"), -1, &rect, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
        
        EndPaint(&ps);
        return 0;
    }
    
    LRESULT OnColorChange(WORD nCode) 
    {
        m_nColorIndex = nCode - IDM_COLOR_BLACK;
        Invalidate();
        return 0;
    }
    
private:
    size_t          m_nColorIndex;
    static COLORREF s_rgColors[5];
    
};

COLORREF		CHelloView::s_rgColors[] = { RGB (  0,   0,   0),
RGB (255,   0,   0),
RGB (  0, 255,   0),
RGB (  0,   0, 255),
RGB (255, 255, 255), };

/////////////////////////////////////////////////////////////////////////////
// This is the MDI Child Frame parenting the View

class CHelloMdiChild : public CMdiChildWindowImpl<CHelloMdiChild>
{
public:
    typedef CMdiChildWindowImpl<CHelloMdiChild> baseClass;
    
    BEGIN_MSG_MAP(CHelloMdiChild)
        MESSAGE_HANDLER(WM_CREATE, OnCreate)
        MESSAGE_HANDLER(WM_SETFOCUS, OnSetFocus)
        MESSAGE_HANDLER(WM_SIZE, OnSize)		
        MESSAGE_HANDLER(WM_QUERYENDSESSION, OnQueryClose)
        MESSAGE_HANDLER(WM_CLOSE, OnQueryClose)
        COMMAND_ID_HANDLER(IDM_COLOR_BLACK, OnColorChange)
        COMMAND_ID_HANDLER(IDM_COLOR_RED, OnColorChange)
        COMMAND_ID_HANDLER(IDM_COLOR_GREEN, OnColorChange)
        COMMAND_ID_HANDLER(IDM_COLOR_BLUE, OnColorChange)
        COMMAND_ID_HANDLER(IDM_COLOR_WHITE, OnColorChange)
        
        CHAIN_MSG_MAP(baseClass)
    END_MSG_MAP()
        
    LRESULT OnQueryClose(UINT, WPARAM, LPARAM, BOOL& bHandled)
    {
        UINT msg = MessageBox(__T("May I close this window?"), __T("Hello"),  MB_ICONQUESTION | MB_YESNO);
        
        // If it's OK with the user, let DefMDIChildProc close us
        if( msg == IDYES ) bHandled = FALSE;
        return 0;
    }
    
    LRESULT OnCreate(UINT, WPARAM , LPARAM , BOOL& )
    {
        //Create the View
        m_HelloView.Create(m_hWnd,CWindow::rcDefault);
        return 0L;
    }
    
    LRESULT OnSize(UINT,WPARAM,LPARAM,BOOL& bHandled)
    {
        DefWindowProc();
        bHandled = ResizeElements();
        return 0L;
    }
    
    LRESULT OnSetFocus(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
    {
        m_HelloView.SetFocus();
        return 0L;
    }
    
    LRESULT OnColorChange(WORD, WORD nCode, HWND, BOOL&)
    {
        m_HelloView.OnColorChange(nCode);
        return 0L;
    }
    
    void OnFinalMessage(HWND)
    {
        delete this;
    }
    
public: //virtuals
    BOOL ResizeElements()
    {
        RECT rc; GetClientRect(&rc);
        m_HelloView.SetWindowPos(NULL, &rc,SWP_NOZORDER | SWP_NOACTIVATE);
        return TRUE;
    }
    
private:
    CHelloView  m_HelloView;
};

#endif  // INC_HELLOFRAME
