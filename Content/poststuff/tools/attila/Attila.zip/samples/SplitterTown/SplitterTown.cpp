// SplitterTown.cpp

#include "stdafx.h"
#include "resource.h"
#include "SplitterTownFrame.H"

CComModule _Module;

extern "C" int WINAPI _tWinMain(HINSTANCE hInstance, HINSTANCE, LPTSTR lpCmdLine, int nCmdShow)
{
    _Module.Init(0, hInstance);
    
    // Init common controls
    INITCOMMONCONTROLSEX iccx = { sizeof(iccx), ICC_ALL };
	InitCommonControlsEx(&iccx);

	// Create the App Frame
	CMySplitterTownFrame frame;
	HMENU hMenu = LoadMenu(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_MAINFRAME));
	frame.Create(::GetDesktopWindow(),CWindow::rcDefault,_T("Splitter Town!"),0,0,(UINT)hMenu);
	frame.CenterWindow();
	frame.ShowWindow(nCmdShow) ;
    frame.UpdateWindow();
    
    MSG msg;
    while (GetMessage(&msg, 0, 0, 0))
	{
		::TranslateMessage(&msg);
		::DispatchMessage(&msg);
	}

    _Module.Term();
	return msg.wParam;
}
