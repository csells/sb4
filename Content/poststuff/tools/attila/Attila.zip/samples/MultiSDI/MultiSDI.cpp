// MultiSDI.cpp

#include "stdafx.h"
#include "resource.h"
#include "SDIFrame.H"

CMyModule _Module;

DWORD WINAPI FrameThreadProc(LPVOID pv) ;

void CMyModule::On2ndInstance(LPCTSTR)
{
    _Module.CreateNewThread();
}

/////////////////////////////////////////////////////////////////////////////
//
extern "C" int WINAPI _tWinMain(HINSTANCE hInstance, HINSTANCE , LPTSTR lpCmdLine, int nShowCmd)
{
    _Module.Init(0, hInstance, FrameThreadProc, lpCmdLine);

    if( _Module.Is2ndInstance() )
    {
        _Module.Term();
        return S_OK;
    }

    // Init control containment
	AtlAxWinInit();
    
	// Init common controls
    INITCOMMONCONTROLSEX iccx = { sizeof(iccx), ICC_ALL };
	InitCommonControlsEx(&iccx);

	// this will spin up the first thread, and show the frame
	_Module.CreateNewThread();

	// wait until all the frames are closed
	_Module.WaitTilDone();

    _Module.Term();
	return 0;
}

/////////////////////////////////////////////////////////////////////////////
// The ThreadProc for each new thread

static DWORD WINAPI FrameThreadProc(LPVOID pv)
{
	CMyMainFrame frame ;

	frame.Create(::GetDesktopWindow(), CWindow::rcDefault);
	frame.ShowWindow(SW_SHOWNORMAL);
	frame.UpdateWindow();

	// Load Accelerators
    HACCEL hAccel = LoadAccelerators(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_ACCEL));

	MSG msg;
	while(GetMessage(&msg, 0, 0, 0))
	{
		if( !TranslateAccelerator(frame.m_hWnd, hAccel, &msg) )
		{
			if(!CMsgTranslator::RunThroughTranslators(msg, hAccel))
			{
				::TranslateMessage(&msg);
				::DispatchMessage(&msg);
			}				
		}
	}

	// Notify the module that we're done
	_Module.ThreadTerm() ;
	return 0L;
}
