// Application.h : Declaration of the CApplication

#ifndef __APPLICATION_H_
#define __APPLICATION_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CApplication

class ATL_NO_VTABLE CApplication : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CApplication, &CLSID_Application>,
	public IDispatchImpl<IApplication, &IID_IApplication>,
    public ICycleDetectImpl<CApplication>
{
public:
    CApplication();

    HRESULT FinalConstruct();
    void    FinalRelease();
    void    OnCycleDetected();

DECLARE_CYCLE_DETECT(CApplication) 
DECLARE_REGISTRY_RESOURCEID(IDR_APPLICATION)
DECLARE_NOT_AGGREGATABLE(CApplication)
//DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CApplication)
	COM_INTERFACE_ENTRY(IApplication)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ICycleDetect)
    COM_INTERFACE_ENTRY_THIS()
END_COM_MAP()

// IApplication
public:
    STDMETHOD(get_Parent)(/*[out, retval]*/ IApplication** ppVal);
    STDMETHOD(get_Application)(/*[out, retval]*/ IApplication** ppVal);
    STDMETHOD(get_DocumentCollection)(/*[out, retval]*/ IDocumentCollection** ppVal);
    STDMETHOD(Close)();

private:
    bool    m_bClosed;
    CComCycleManager<CApplication>      m_CycleManager;
    CComCyclePtr<IDocumentCollection>   m_spDocumentCollection;
};

#endif //__APPLICATION_H_
