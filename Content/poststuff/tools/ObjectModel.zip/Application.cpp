// Application.cpp : Implementation of CApplication

#include "stdafx.h"
#include "ObjectModel.h"
#include "Application.h"
#include "DocumentCollection.h"

/////////////////////////////////////////////////////////////////////////////
// CApplication

CApplication::CApplication()
:   m_bClosed(false),
    m_CycleManager(this)    // The cycle manager needs to know about us
{
    // ICycleDetectImpl needs to know about the cycle manager
    put_CycleManager(&m_CycleManager);
}

void CApplication::OnCycleDetected()
{
    ATLTRACE("CApplication::OnCycleDetected()\n");
    Close();
}

HRESULT CApplication::FinalConstruct()
{
    ATLTRACE("CApplication::FinalConstruct()\n");
    return S_OK;
}

void CApplication::FinalRelease()
{
    ATLTRACE("CApplication::FinalRelease()\n");
}

/////////////////////////////////////////////////////////////////////////////
// IApplication

STDMETHODIMP CApplication::get_Application(IApplication** ppVal)
{
	if( !ppVal ) return E_POINTER;
    return GetUnknown()->QueryInterface(ppVal);
}

STDMETHODIMP CApplication::get_Parent(IApplication** ppVal)
{
	if( !ppVal ) return E_POINTER;
    return GetUnknown()->QueryInterface(ppVal);
}

STDMETHODIMP CApplication::get_DocumentCollection(IDocumentCollection** ppVal)
{
    if( m_bClosed ) return E_UNEXPECTED;

    if( !m_spDocumentCollection )
    {
        // Create the documents collection
        CComObject<CDocumentCollection>* pDocs = 0;
        HR(pDocs->CreateInstance(&pDocs));

        // Give the child the cycle manager
        CComQIPtr<ICycleDetect> spCycleDetect = pDocs;
        if( spCycleDetect ) spCycleDetect->put_CycleManager(&m_CycleManager);

        // Init the document collection and cache the pointer
        HR(pDocs->Init(this));
        m_spDocumentCollection = pDocs;
    }

    return m_spDocumentCollection.CopyTo(ppVal);
}

STDMETHODIMP CApplication::Close()
{
    ATLTRACE("CApplication::Close()\n");
    if( m_bClosed ) ATLTRACE("\tWarning! Already closed!\n");

    if( m_spDocumentCollection )
    {
        // Close and release all sub-objects
        CDocumentCollection*    pDocs = 0;
        VERIFY(QueryImplementation(m_spDocumentCollection, &pDocs) == S_OK);
        pDocs->Close();
        m_spDocumentCollection.Release();
    }

    m_bClosed = true;
    return S_OK;
}

