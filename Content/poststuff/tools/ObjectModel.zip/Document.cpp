// Document.cpp : Implementation of CDocument

#include "stdafx.h"
#include "ObjectModel.h"
#include "Document.h"
#include "Application.h"
#include "DocumentCollection.h"

/////////////////////////////////////////////////////////////////////////////
// CDocument

HRESULT CDocument::FinalConstruct()
{
    ATLTRACE("CDocument::FinalConstruct()\n");
    return S_OK;
}

void CDocument::FinalRelease()
{
    ATLTRACE("CDocument::FinalRelease()\n");
}

HRESULT CDocument::Init(IDocumentCollection* pParent)
{
    if( !GetCycleManager() ) return E_UNEXPECTED;

    // Cache the parent
    m_spParent = pParent;

    // Just for fun, cache the Application, too
    CComPtr<IApplication>   spApplication;
    HR(m_spParent->get_Application(&spApplication));
    m_spApplication = spApplication;

    return S_OK;
}

void CDocument::Close()
{
    ATLTRACE("CDocument::Close()\n");

    // Let go of the parent
    m_spParent.Release();
}

/////////////////////////////////////////////////////////////////////////////
// IDocument

STDMETHODIMP CDocument::get_Data(BSTR* pVal)
{
    // We've been closed...
    if( !m_spParent ) return E_UNEXPECTED;

    return m_bstrData.CopyTo(pVal);
}

STDMETHODIMP CDocument::put_Data(BSTR newVal)
{
    // We've been closed...
    if( !m_spParent ) return E_UNEXPECTED;

    m_bstrData = newVal;
    return S_OK;
}

STDMETHODIMP CDocument::get_Application(IApplication** ppVal)
{
    // We've been closed...
    if( !m_spParent ) return E_UNEXPECTED;

    return m_spParent->get_Application(ppVal);
}

STDMETHODIMP CDocument::get_Parent(IDocumentCollection** ppVal)
{
    // We've been closed...
    if( !m_spParent ) return E_UNEXPECTED;

	if( !ppVal ) return E_POINTER;
    return m_spParent->QueryInterface(__uuidof(*ppVal), (void**)ppVal);
}
