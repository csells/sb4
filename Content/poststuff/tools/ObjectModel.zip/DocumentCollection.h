// DocumentCollection.h : Declaration of the CDocumentCollection

#ifndef __DOCUMENTCOLLECTION_H_
#define __DOCUMENTCOLLECTION_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CDocumentCollection

template <typename T>
struct _CopyVariantFromAdaptItf {
	static HRESULT copy(VARIANT* p1, CAdapt< CComCyclePtr<T> >* p2) {
    HRESULT hr = p2->m_T->QueryInterface(IID_IDispatch, (void**)&p1->pdispVal);
    if( SUCCEEDED(hr) ) {
      p1->vt = VT_DISPATCH;
    }
    else {
      hr = p2->m_T->QueryInterface(IID_IUnknown, (void**)&p1->punkVal);
      if( SUCCEEDED(hr) ) {
        p1->vt = VT_UNKNOWN;
      }
    }

    return hr;
  }
	
  static void init(VARIANT* p)    { VariantInit(p); }
  static void destroy(VARIANT* p) { VariantClear(p); }
};

typedef CComEnumOnSTL<IEnumVARIANT, &IID_IEnumVARIANT, VARIANT,
                        _CopyVariantFromAdaptItf<IDocument>,
                        vector< CAdapt< CComCyclePtr<IDocument> > > >
        CComEnumVariantOnVectorOfDocuments;

template <typename T>
struct _CopyItfFromAdaptItf {
	static HRESULT copy(T** p1, CAdapt< CComCyclePtr<T> >* p2) {
    if( *p1 = p2->m_T ) return (*p1)->AddRef(), S_OK;
    return E_POINTER;
  }
	
  static void init(T** p)    {}
  static void destroy(T** p) { if( *p ) (*p)->Release(); }
};

typedef vector< CAdapt< CComCyclePtr<IDocument> > > DocumentCollectionType;

typedef ICollectionOnSTLImpl<IDispatchImpl<IDocumentCollection, &IID_IDocumentCollection>,
                             DocumentCollectionType,
                             IDocument*,
                             _CopyItfFromAdaptItf<IDocument>,
                             CComEnumVariantOnVectorOfDocuments>
        IDocumentCollectionCollImpl;

class CApplication;

class ATL_NO_VTABLE CDocumentCollection : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CDocumentCollection, &CLSID_DocumentCollection>,
	public IDocumentCollectionCollImpl,
    public ICycleDetectImpl<CDocumentCollection>
{
public:
    HRESULT FinalConstruct();
    void    FinalRelease();
    HRESULT Init(IApplication* pParent);
    void    Close();

DECLARE_REGISTRY_RESOURCEID(IDR_DOCUMENTCOLLECTION)
DECLARE_NOT_AGGREGATABLE(CDocumentCollection)
DECLARE_CYCLE_DETECT(CDocumentCollection)
//DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CDocumentCollection)
	COM_INTERFACE_ENTRY(IDocumentCollection)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ICycleDetect)
    COM_INTERFACE_ENTRY_THIS()
END_COM_MAP()

// IDocumentCollection
public:
	STDMETHOD(get_Parent)(/*[out, retval]*/ IApplication** ppVal);
	STDMETHOD(get_Application)(/*[out, retval]*/ IApplication** ppVal);
	STDMETHOD(CreateDocument)(/*[out, retval]*/ IDocument** ppVal);
	STDMETHOD(DestroyDocument)(/*[in]*/ VARIANT var);

private:
    CComCyclePtr<IApplication>  m_spParent;
};

#endif //__DOCUMENTCOLLECTION_H_
