// DocumentCollection.cpp : Implementation of CDocumentCollection

#include "stdafx.h"
#include "ObjectModel.h"
#include "DocumentCollection.h"
#include "Application.h"
#include "Document.h"

/////////////////////////////////////////////////////////////////////////////
// CDocumentCollection

HRESULT CDocumentCollection::FinalConstruct()
{
    ATLTRACE("CDocumentCollection::FinalConstruct()\n");
    return S_OK;
}

void CDocumentCollection::FinalRelease()
{
    ATLTRACE("CDocumentCollection::FinalRelease()\n");
}

HRESULT CDocumentCollection::Init(IApplication* pParent)
{
    if( !GetCycleManager() ) return E_UNEXPECTED;
    m_spParent = pParent;
    return S_OK;
}

void CDocumentCollection::Close()
{
    ATLTRACE("CDocumentCollection::Close()\n");

    // Close and release all sub-objects
    for( DocumentCollectionType::iterator it = m_coll.begin(); it != m_coll.end(); ++it )
    {
        CDocument*  pDoc = 0;
        VERIFY(QueryImplementation(it->m_T, &pDoc) == S_OK);
        pDoc->Close();
        it->m_T.Release();
    }
    m_coll.clear();

    // Let go of the parent references
    m_spParent.Release();
}

/////////////////////////////////////////////////////////////////////////////
// IDocumentCollection

STDMETHODIMP CDocumentCollection::CreateDocument(IDocument** ppVal)
{
    // We've been closed...
    if( !m_spParent ) return E_UNEXPECTED;

    // Create a document
    CComObject<CDocument>*  pDoc = 0;
    HR(pDoc->CreateInstance(&pDoc));

    // Give document the cycle manager
    CComQIPtr<ICycleDetect> spCycleDetect = pDoc;
    if( spCycleDetect ) spCycleDetect->put_CycleManager(GetCycleManager());

    // Init the document
    HR(pDoc->Init(this));

    // Hand reference back to client
    HR(pDoc->QueryInterface(ppVal));

    // Put the document on the list
    m_coll.push_back(CComCyclePtr<IDocument>(*ppVal));
    return S_OK;
}

STDMETHODIMP CDocumentCollection::DestroyDocument(VARIANT var)
{
    // We've been closed...
    if( !m_spParent ) return E_UNEXPECTED;

    return E_NOTIMPL;
}

STDMETHODIMP CDocumentCollection::get_Application(IApplication** ppVal)
{
    // We've been closed...
    if( !m_spParent ) return E_UNEXPECTED;

    return m_spParent->get_Application(ppVal);
}

STDMETHODIMP CDocumentCollection::get_Parent(IApplication** ppVal)
{
    // We've been closed...
    if( !m_spParent ) return E_UNEXPECTED;

    if( !ppVal ) return E_POINTER;
    return m_spParent->QueryInterface(__uuidof(*ppVal), (void**)ppVal);
}
