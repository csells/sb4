// CycleDetect.h: A set of helpers for detecting ref count cycles in COM.
/////////////////////////////////////////////////////////////////////////////
// Copyright (c) 1999, Chris Sells.
// All rights reserved. No warranties extended. Use at your own risk.
// Comments and bug reports to csells@sellsbrothers.com.
/////////////////////////////////////////////////////////////////////////////
// History:
// 9/2/99:
// -That last release was all wrong. This one is still experimental, but
//  it actually works for the cases I was aiming at, i.e. child keeps
//  parent alive when client lets it go, but if client no longer holds
//  any references, the top-level object is given a chance to shut
//  everything down.
//
// 8/31/99:
// -Initial release. Still in the experimental stage.
/////////////////////////////////////////////////////////////////////////////
// This file defines a set of types for detecting reference count cycles,
// specifically for use in building hierarchical object models. The goal
// was to allow a client the option of manual or automatic "Close" of an
// object model with a minimum of impact on the code of the object model
// itself. This is all done in the face of expected reference cycles, i.e.
// parent holds on to child interface(s) and child holds onto parent interface(s).
//
// The general philosophy is that a child object in an object model cannot
// exist without its parent. Also, the child needs to be able to respond
// to requests for it's parent (as well as the topmost object in the model,
// often known as the "application" object). The child can keep it's parent
// alive for its (the child's) life as well as cache the parent's interface
// by keeping a COM reference on one of the parent's interfaces. However, as
// the parent is also likely to keep a reference on its child, what results
// is known as a reference count cycle. Practically, this means that, in the
// absence of some protocol to elminate the cycle, we are going to leak
// objects that the client no longer references, but are keeping each other
// alive.
//
// There are several ways to solve this problem:
// -Require client to manually close object model via a Close method
//  on the application object. Since most such clients are written by
//  VB/VBS programmers, this is problematic at best. This is the way that MS
//  office does it.
//
// -Implement a garbage collector for COM or use a language, i.e. Java, that
//  comes with a built in gc to collect cycled objects. Both of these are
//  theoretical as I've never seen this solution applied to this problem.
//
// -Use IExternalConnection to track the difference between references held
//  by other objects in the object model and references held by clients. This
//  works fine if the object model lives in another apartment than the client
//  *and* all objects in the object model live in the same apartment.
//
// -Use a protocol that is logically the inverse of IExternalConnection, i.e.
//  an object internal to the object model will notify other object model
//  objects that it has acquired a reference that could potentially be a
//  cycle. When all objects in the object model have only cycle references,
//  the objects can all be destroyed.

// This last method is what is implemented in this file. The cycle detection
// protocol is modeled via the ICycleDetect interface:
/*
[ uuid(6F510BA0-5E74-11D3-94C2-00500428E7C0), object ]
interface ICycleDetectParent : public IUnknown
{
    HRESULT put_CycleManager(ICycleManager* pcm);
    HRESULT get_CycleManager(ICycleManager** ppcm);
    HRESULT CycleAddRef();
    HRESULT CycleRelease();
};
*/
// An object implements ICycleDetect to let other objects in the object model
// know that it would like to be notified of references with potential cycles.
// When an object's references and it's cyclic references are the
// same, it has detected a potential cycle. A central cycle manager
// object is then be notified that the object has detected a local cycle,
// i.e. it's only being held onto by objects in the object model. 
// Their is one cycle manager per object model instance and it implements
// the ICycleManager interface:
/*
interface ICycleManager : IUnknown
{
    HRESULT AddObject();
    HRESULT RemoveObject();
    HRESULT AddCycle();
    HRESULT RemoveCycle();
};
*/
// AddObject and RemoveObject are called when an object in the model are
// created or destroyed. AddCycle and RemoveCycle are called when the
// object's reference count and cyclic reference count indicate a cycle.
// When all objects in the object model are in this state, the
// cycle manager can notify the application, which can shut down the object
// model.
//
// To make using this protocol easy, this file provides implementations of
// the pieces of the protocol. ICycleDetectImpl provides an implementation
// of ICycleDetect that knows when to notify the cycle manager of a cycle.
// It works in conjuction with DECLARE_CYCLE_DETECT that overrides ATL's
// InternalRelease function to detect a potential cycle and InternalAddRef
// to notify the cycle manager that a cycle no longer exists. Note: there
// are four places that m_dwRef and m_dwCycleRef could be equal on an object:
// IUnknown::AddRef, IUnknown::Release, ICycleDetect::CycleAddRef and 
// ICycleDetect::CycleRelease. However, only when m_dwRef == m_dwCycleDetect
// inside IUnknown::Release indicates a cycle. All other cases indicate a
// temporary cycle at most and never cause a call to the cycle manager.
// ICycleDetectImpl + DECLARE_CYCLE_DETECT work together to implement
// these cases correctly.
//
// To simplify the acquision of a cycled interface, CComCyclePtr QIs
// for ICycleDetect when an interface is acquired or released to let
// the object know of a cycled refefence. All cached object references, both
// child and parent, should use this class instead of CComPtr so that
// cycled objects can be notified of a cyclic reference.
//
// CComCycleManager implements ICycleManager and should be handled to
// each new object in the model as they are created
// (via ICycleDetect::put_CycleManager). When all objects in the model
// are in cycle, the containing object (typically the Application object)
// is notified via a call to OnCycleDetected:
//
// void OnCycleDetected();
//
// The typical response is for the object to call whatever function the
// client would have called, had it been doing shutdown manually. The
// canonical name for this function is "Close".
//
/////////////////////////////////////////////////////////////////////////////
// Usage:
// In all objects:
//  1. Derived from ICycleDetectImpl and add ICycleDetect to the interface map.
//  2. Place 'DECLARE_CYCLE_DETECT()' somewhere in the class declaration.
//  3. When creating child objects, pass the ICycleManager* obtained from
//     the ICycleManagerImpl::GetCycleManager() function to the child object
//     using ICycleDetect::put_CycleManger before caching the child's interface.
//     The child needs the cycle manager to watch for potential cycles.
//  4. Cache all object model pointers using CComCyclePtr.
//
// Additional steps in the application object:
//  5. Create a member variable of type 'CComCycleManager'.
//  6. In the ctor's member initialization list, pass the application object's
//     this pointer to the cycle manager.
//  7. In the ctor, call put_CycleManager, passing the address of the cycle
//     manager member variable.
//  8. Implement 'void OnCycleDetected()' to call your application's "Close"
//     method.
//  9. The "Close" method should let all child objects know that they've
//     been closed so that they can release their cached references and
//     refuse further calls.
/*
class ATL_NO_VTABLE CApplication : 
	...
    public ICycleDetectImpl<CApplication> // 1.
{
BEGIN_COM_MAP(CApplication)
	...
	COM_INTERFACE_ENTRY(ICycleDetect) // 1.
END_COM_MAP()

DECLARE_CYCLE_DETECT(CApplication) // 2.

    CApplication()
    :   m_bClosed(false),
        m_CycleManager(this)    // 6. The cycle manager needs to know about us
    {
        // 7. ICycleDetectImpl needs to know about the cycle manager
        put_CycleManager(&m_CycleManager);
    }

    STDMETHODIMP CApplication::get_DocumentCollection(IDocumentCollection** ppVal)
    {
        if( m_bClosed ) return E_UNEXPECTED;

        if( !m_spDocumentCollection )
        {
            // Create the documents collection
            CComObject<CDocumentCollection>* pDocs = 0;
            HR(pDocs->CreateInstance(&pDocs));

            // 3. Give the child the cycle manager
            CComQIPtr<ICycleDetect> spCycleDetect = pDocs;
            if( spCycleDetect ) spCycleDetect->put_CycleManager(&m_CycleManager);

            // Init the document collection and cache the pointer
            HR(pDocs->Init(this));
            m_spDocumentCollection = pDocs; // 4.
        }

        return m_spDocumentCollection.CopyTo(ppVal);
    }

    void OnCycleDetected()  // 8.
    {
        Close();
    }

    STDMETHODIMP Close()    // 9.
    {
        // Release child references
        CComPtr<IPrivateClose>  spClose;
        m_spDocumentCollection->QueryInterface(&spClose);
        spClose->Close();

        // Release parent references, too    

        m_bClosed = true;
        return S_OK;    
    }
    ...
private:
    bool    m_bClosed;
    CComCycleManager                  m_CycleManager;           // 5.
    CComCyclePtr<IDocumentCollection> m_spDocumentCollection;   // 4.
};
*/
/////////////////////////////////////////////////////////////////////////////
// Known Issues:
//  -This has not been tested across context boundaries, i.e. in the presence
//   of a proxy/stub between two objects. There may be issues related to the
//   proxy manager's caching of AddRef/Release calls.
//  -The interface is defined in this header file and not in IDL. This makes
//   usage from C++ convenient and from any other language impossible.
//  -There are too many lines of integration code. I'd prefer fewer to reduce
//   the chance for error.
//  -The testing has been pretty rudimentary.
/////////////////////////////////////////////////////////////////////////////

#pragma once
#ifndef INC_CYCLEDETECT
#define INC_CYCLEDETECT

#include <typeinfo.h>   // typeid

// TODO: These interfaces belong in IDL

// May be returned from AddCycle
#define CYCLE_S_CYCLEDETECTED MAKE_HRESULT(SEVERITY_ERROR, FACILITY_ITF, 0x200)

MIDL_INTERFACE("67DD7BE0-618E-11D3-94D2-00500428E7C0")
ICycleManager : public IUnknown
{
public:
    STDMETHOD(AddObject)() =0;
    STDMETHOD(RemoveObject)() =0;
    STDMETHOD(AddCycle)() =0;
    STDMETHOD(RemoveCycle)() =0;
};

#define IID_ICycleManager __uuidof(ICycleManager)

MIDL_INTERFACE("6F510BA0-5E74-11D3-94C2-00500428E7C0")
ICycleDetect : public IUnknown
{
public:
    STDMETHOD(put_CycleManager)(ICycleManager* pcm);
    STDMETHOD(get_CycleManager)(ICycleManager** ppcm);

    STDMETHOD(CycleAddRef)() =0;
    STDMETHOD(CycleRelease)() =0;
};

#define IID_ICycleDetect __uuidof(ICycleDetect)

// Client-side

template <typename T>
class CComCyclePtr : public CComPtr<T>
{
public:
    CComCyclePtr(T* _p = 0) : CComPtr<T>(_p)
	{
        CycleAddRef();
	}

    CComCyclePtr(const CComCyclePtr<T>& _p) : CComPtr<T>(_p)
	{
        CycleAddRef();
	}

	~CComCyclePtr()
	{
		CycleRelease();
	}

	void Release()
	{
        CycleRelease();
        CComPtr<T>::Release();
	}

	CComCyclePtr<T>& operator=(T* _p)
	{
        return Assign(_p);
	}

	CComCyclePtr<T>& operator=(const CComPtr<T>& sp)
	{
        return Assign(sp.p);
	}

	CComCyclePtr<T>& operator=(const CComCyclePtr<T>& sp)
	{
        return Assign(sp.p);
	}

	void Attach(T* _p)
	{
        CycleRelease();
        CComPtr<T>::Attach(_p);
        CycleAddRef();
        return *this;
	}

	T* Detach()
	{
        CycleRelease();
        return CComPtr<T>::Detach();
	}

	HRESULT CoCreateInstance(REFCLSID rclsid, LPUNKNOWN pUnkOuter = NULL, DWORD dwClsContext = CLSCTX_ALL)
	{
        CycleRelease();
        HRESULT hr = CComPtr<T>::CoCreateInstance(rclsid, pUnkOuter, dwClsContext);
        if( FAILED(hr) ) return hr;
        CycleAddRef();
        return hr;
	}

	HRESULT CoCreateInstance(LPCOLESTR szProgID, LPUNKNOWN pUnkOuter = NULL, DWORD dwClsContext = CLSCTX_ALL)
	{
        CycleRelease();
        HRESULT hr = CComPtr<T>::CoCreateInstance(szProgID, pUnkOuter, dwClsContext);
        if( FAILED(hr) ) return hr;
        CycleAddRef();
        return hr;
	}

private:
    // Turn this off as operator& can't do a CycleAddRef
    T** operator&();

    CComCyclePtr<T>& Assign(T* _p)
    {
        CycleRelease();
        CComPtr<T>::operator=(_p);
        CycleAddRef();
        return *this;
    }

    void CycleAddRef()
    {
        CComQIPtr<ICycleDetect> sp = p;
        if( sp ) sp->CycleAddRef();
    }

    void CycleRelease()
    {
        CComQIPtr<ICycleDetect> sp = p;
        if( sp ) sp->CycleRelease();
    }
};

// The top of the hierarchy has one of these and it's passed to everyone else

template <typename Container>
class CComCycleManager : public ICycleManager
{
public:
    CComCycleManager(Container* pContainer)
        : m_pContainer(pContainer), m_nObjects(0), m_nCycledObjects(0)
    {
        ATLASSERT(m_pContainer);
    }

protected:
    // IUnknown (stack-based)
    STDMETHODIMP QueryInterface(REFIID riid, void** ppv)
    {
        if( !ppv ) return E_POINTER;
        *ppv = 0;

        if( riid == IID_IUnknown || riid == IID_ICycleManager )
        {
            *ppv = static_cast<ICycleManager*>(this);
            reinterpret_cast<IUnknown*>(*ppv)->AddRef();
            return S_OK;
        }

        return E_NOINTERFACE;
    }

    STDMETHODIMP_(ULONG) AddRef()
    { return 2; }

    STDMETHODIMP_(ULONG) Release()
    { return 1; }

    // ICycleManager
    STDMETHODIMP AddObject()
    {
        ULONG   l = Increment(&m_nObjects);
        ATLTRACE("++m_nObjects= %d\n", l);
        return S_OK;
    }

    STDMETHODIMP RemoveObject()
    {
        ULONG   l = Decrement(&m_nObjects);
        ATLTRACE("--m_nObjects= %d\n", l);
        return S_OK;
    }

    STDMETHODIMP AddCycle()
    {
        ULONG   l = Increment(&m_nCycledObjects);
        ATLTRACE("++m_nCycledObjects= %d\n", l);

        if( (long)l == m_nObjects )
        {
            // Keep object alive during this method call
            // NOTE: This is so that when a cycle is detected and the
            // object is releasing its children, the children will
            // release it, driving this object's refcount to zero,
            // often causing a 'delete this' before the object is
            // done shutting down.
            CComPtr<IUnknown>   punk(This()->GetUnknown());

            // Call 'void Derived::OnCycleDetected()'
            This()->OnCycleDetected();
            return CYCLE_S_CYCLEDETECTED;
        }

        return S_OK;
    }

    STDMETHODIMP RemoveCycle()
    {
        ULONG   l = Decrement(&m_nCycledObjects);
        ATLTRACE("--m_nCycledObjects= %d\n", l);
        return S_OK;
    }

private:
    Container* This()
    { return m_pContainer; }

	ULONG Increment(long* p)
    { return Container::_ThreadModel::Increment(p); }

	ULONG Decrement(long* p)
    { return Container::_ThreadModel::Decrement(p); }

private:
    long        m_nObjects;
    long        m_nCycledObjects;
    Container*  m_pContainer;
};

// Everyone in the hierarchy implements this

template <typename Deriving>
class ICycleDetectImpl : public ICycleDetect
{
public:
    ICycleDetectImpl() : m_dwCycleRef(0), m_bAddedCycle(false)
    {}

    virtual ~ICycleDetectImpl()
    {
        RemoveObject();
    }

    // ICycleDetect
    STDMETHODIMP put_CycleManager(ICycleManager* pcm)
    {
        RemoveObject();
        m_spCycleManager = pcm;
        AddObject();
        return S_OK;
    }

    STDMETHODIMP get_CycleManager(ICycleManager** ppcm)
    { return m_spCycleManager.CopyTo(ppcm); }

    STDMETHODIMP CycleAddRef()
    {
        ULONG   l = Deriving::_ThreadModel::Increment(&m_dwCycleRef);
        ATLTRACE("++m_dwCycleRef= %d  %s\n", m_dwCycleRef, typeid(Deriving).name());
        RemoveCycle();
        return S_OK;
    }

    STDMETHODIMP CycleRelease()
    {
        ULONG   l = Deriving::_ThreadModel::Decrement(&m_dwCycleRef);
        ATLTRACE("--m_dwCycleRef= %d  %s\n", m_dwCycleRef, typeid(Deriving).name());
        RemoveCycle();
        return S_OK;
    }

protected:
    // A return of 'CYCLE_S_CYCLEDETECTED' indicates that a global
    // cycle was detected and this object has likely been destroyed.
    HRESULT CheckCycle()
    {
        if( m_dwCycleRef && (m_dwCycleRef == This()->m_dwRef) )
        {
            // Let cycle manager know a cycle was detected on this object
            return AddCycle();
        }

        // Let the cycle manager know we're no longer a cycle
        return RemoveCycle();
    }

    HRESULT AddObject()
    {
        if( m_spCycleManager && !m_bAddedObject )
        {
            m_bAddedObject = true;
            return m_spCycleManager->AddObject();
        }

        return S_OK;
    }

    HRESULT RemoveObject()
    {
        if( m_spCycleManager && m_bAddedObject )
        {
            m_bAddedObject = false;
            return m_spCycleManager->RemoveObject();
        }

        return S_OK;
    }

    HRESULT AddCycle()
    {
        if( m_spCycleManager && !m_bAddedCycle )
        {
            m_bAddedCycle = true;
            return m_spCycleManager->AddCycle();
        }

        return S_OK;
    }

    HRESULT RemoveCycle()
    {
        if( m_spCycleManager && m_bAddedCycle )
        {
            m_bAddedCycle = false;
            return m_spCycleManager->RemoveCycle();
        }

        return S_OK;
    }

    // Don't want to make m_spCycleManager public as setting
    // it outside of of put_CycleManager won't do the
    // AddObject/RemoveObject protocol.
    ICycleManager* GetCycleManager()
    { return m_spCycleManager; }

private:
    Deriving* This()
    { return static_cast<Deriving*>(this); }

private:
    long    m_dwCycleRef;
    bool    m_bAddedCycle:1;
    bool    m_bAddedObject:1;

    // The cycle manager may or may not implement ICycleDetect
    CComCyclePtr<ICycleManager> m_spCycleManager;
};

#define DECLARE_CYCLE_DETECT(_class) \
	ULONG InternalAddRef() \
	{ \
        ULONG   l = CComObjectRootEx<_ThreadModel>::InternalAddRef(); \
        ATLTRACE("++m_dwRef= %d " #_class "\n", m_dwRef); \
        /* If we've reported ourselves as a cycle, that's no longer true. */ \
        /* We're not calling CheckCycle because we can't AddRef our way */ \
        /* to a cycle. Cycles refs are always less than or equal to */ \
        /* an object's total refs. */ \
        ICycleDetectImpl<_class>::RemoveCycle(); \
        return l; \
	} \
\
	ULONG InternalRelease() \
    { \
        ULONG   l = CComObjectRootEx<_ThreadModel>::InternalRelease(); \
        ATLTRACE("--m_dwRef= %d " #_class "\n", m_dwRef); \
        /* We may now be a cycle */ \
        ICycleDetectImpl<_class>::CheckCycle(); \
        return l; \
    }

#endif // INC_CYCLEDETECT
