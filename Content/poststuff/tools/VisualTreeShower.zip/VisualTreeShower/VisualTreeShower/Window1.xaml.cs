using System;
using System.Text;
using MSAvalon.Windows;
using MSAvalon.Windows.Controls;
using MSAvalon.Windows.Documents;
using MSAvalon.Windows.Navigation;
using MSAvalon.Windows.Shapes;
using MSAvalon.Windows.Data;
using MSAvalon.Windows.Media;
using System.Reflection;
using System.Diagnostics;

// TODO: Show drop-down list of all built-in element types for exploring visual trees
// TODO: Hook up to Avalon equivilent of Spy++ to show visual trees of any running instance
// TODO: Allow types to be loaded dynamically?

namespace VisualTreeShower {
  public partial class Window1 : Window {
    // From http://weblogs.asp.net/digitalnetbizz/archive/2004/02/16/73603.aspx
    public static string GetVisualTree(Visual element) {
      string name = element.GetType().Name;
      string nl = System.Environment.NewLine;
      return string.
      Format(
        "<Style def:Name='My{0}Style'>{1}  <{0} />{1}  <Style.VisualTree>{1}{2}  </Style.VisualTree>{1}</Style>",
        name, nl, GetVisualTree((IVisual)element, 2));
    }

    static string GetVisualTree(IVisual element, int levelOffset) {
      StringBuilder sb = new StringBuilder();
      string nl = System.Environment.NewLine;
      const int spacesPerLevel = 2;
      string spaces = new string(' ', spacesPerLevel * levelOffset);

      foreach( Visual child in element.Children ) {
        string tag = child.GetType().Name;
        string nextLevel = GetVisualTree(child, levelOffset + 1);
        StringBuilder attributes = new StringBuilder();

        // Create an instance of this type to see what default attribute values are
        object defaultInstance = null;
        try {
          defaultInstance = child.GetType().Assembly.
          CreateInstance(child.GetType().FullName);
        }
        catch { }

        foreach( PropertyInfo property in child.GetType().
                                          GetProperties(BindingFlags.
                                                        Instance |
                                                        BindingFlags.
                                                        Public) ) {
          try {
            object value = property.GetValue(child, null);

            // If the property can't be written, it can't appear in markup
            if( !property.CanWrite )
              continue;

            // If a property can't be read, I can't pull it out for display
            if( !property.CanRead )
              continue;

            string valueString = value.ToString();

            // If the property is one set by default, no sense in showing it
            if( defaultInstance != null && property.
            GetValue(defaultInstance, null).ToString() ==
                valueString )
              continue;

            attributes.AppendFormat("{0}='{1}' ", property.Name, valueString);
          }
          catch( Exception ex ) {
            Debug.
            WriteLine(string.
            Format("Error getting {0}.{1}: {2}", tag, property.Name,
                   ex.Message));
          }
        }

        if( Empty(nextLevel) ) {
          sb.
          AppendFormat("{0}<{1} {2}/>{3}", spaces, tag, attributes, nl);
        }
        else {
          sb.
          AppendFormat("{0}<{1} {2}>{3}{4}{0}</{1}>{3}", spaces, tag, attributes, nl,
                       nextLevel);
        }
      }

      return sb.ToString();
    }

    public static bool Empty(string s) { return s == null || s.Length == 0; }

    void window_Loaded(object sender, EventArgs e) {
      button1.Click += new ClickEventHandler(button1_Click);
      
    }

    void button1_Click(object sender, ClickEventArgs e) {
      textbox1.Text = GetVisualTree(button1);
    }

  }
}











