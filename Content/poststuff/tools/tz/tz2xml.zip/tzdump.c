// tzdump.c

#include "tzdump.h"
#include "zic.h"
#include <ctype.h>  // isspace

#define lengthof(_rg) (sizeof(_rg)/sizeof(*_rg))

static const char*  filename = "";
static const char*  progname = "tz2xml";

static void
chrcat(
    char* string,
    char  ch)
{
    while( *string ) ++string;
    *string = ch;
    *(string + 1) = 0;
}

static const char*
escapeXml(
    const char* input,
    char*       output) // Assumes buffer is large enough
{
    char* const outputToReturn = output;
    *output = 0;
    while( *input )
    {
        switch( *input )
        {
        // TODO: There's more potentially bad characters...
        case '>': strcat(output, "&gt;"); break;
        case '<': strcat(output, "&lt;"); break;
        case '&': strcat(output, "&amp;"); break;
        default: chrcat(output, *input); break;
        }

        ++input;
    }

    return outputToReturn;
}

// Can't have "--" in an XML comments, so replace it with "-="
static const char*
escapeXmlComment(
    const char* input,
    char*       output) // Assumes buffer is large enough
{
    char* const outputToReturn = output;
    int         foundDash = FALSE;

    *output = 0;
    while( *input )
    {
        if( *input == '-' )
        {
            if( foundDash )
            {
                *output = '=';
                foundDash = FALSE;
            }
            else
            {
                *output = '-';
                foundDash = TRUE;
            }

        }
        else
        {
            *output = *input;
            foundDash = FALSE;
        }

        ++input;
        ++output;
    }

    *output = 0;
    return outputToReturn;
}

static void
dump_line(
    const char*     name,
    char ** const   fields,
    const int       nfields,
    const char*     fieldNames[],
    const int       nfieldNames,
    const int       closeElement)
{
    int i = 0;

    if( nfields > nfieldNames + 1 ) {
        error("Not enough field names");
        return;
    }

    printf("\t<%s", name);
    for( i = 0; i != nfields; ++i )
    {
        static char buf[1024];
        if( fields[i] && *fields[i] ) printf(" %s='%s'", fieldNames[i], escapeXml(fields[i], buf));
    }

    if( closeElement ) printf("/>\n");
    else printf(">\n");
}

static void
dump_leap(
register char ** const	fields,
const int		nfields)
{
    const char* fieldNames[LEAP_FIELDS-1] =
    {
        "year",     // LP_YEAR
        "month",    // LP_MONTH
        "day",      // LP_DAY
        "time",     // LP_TIME
        "corr",     // LP_CORR
        "roll",     // LP_ROLL
    };

	if (nfields != LEAP_FIELDS) {
		error(_("wrong number of fields on Leap line"));
		return;
	}

    dump_line("leap", fields + 1, nfields - 1, fieldNames, lengthof(fieldNames), TRUE);
}

static void
dump_link(
    register char ** const	fields,
    const int		nfields)
{
    const char* fieldNames[LINK_FIELDS-1] =
    {
        "from", // LF_FROM
        "to",   // LF_TO
    };

	if (nfields != LINK_FIELDS) {
		error(_("wrong number of fields on Link line"));
		return;
	}
	if (*fields[LF_FROM] == '\0') {
		error(_("blank FROM field on Link line"));
		return;
	}
	if (*fields[LF_TO] == '\0') {
		error(_("blank TO field on Link line"));
		return;
	}

    dump_line("link", fields + 1, nfields - 1, fieldNames, lengthof(fieldNames), TRUE);
}

static void
dump_rule(
    register char ** const	fields,
    const int		nfields)
{
    const char* fieldNames[RULE_FIELDS-1] =
    {
        "name",     // RF_NAME
        "loyear",   // RF_LOYEAR
        "hiyear",   // RF_HIYEAR
        "command",  // RF_COMMAND
        "month",    // RF_MONTH
        "day",      // RF_DAY
        "tod",      // RF_TOD
        "stdoff",   // RF_STDOFF
        "abbrvar",  // RF_ABBRVAR
    };

	if (nfields != RULE_FIELDS) {
		error(_("wrong number of fields on Rule line"));
		return;
	}
	if (*fields[RF_NAME] == '\0') {
		error(_("nameless rule"));
		return;
	}

    dump_line("rule", fields + 1, nfields - 1, fieldNames, lengthof(fieldNames), TRUE);
}

static int
dump_zone(
    register char ** const	fields,
    const int		nfields)
{
	/*
	** If there was an UNTIL field on this line,
	** there's more information about the zone on the next line.
	*/
    int hasuntil = nfields > ZF_TILYEAR;

    const char* fieldNames[ZONE_MAXFIELDS-1] =
    {
        "name",     // ZF_NAME
        "gmtoff",   // ZF_GMTOFF
        "rule",     // ZF_RULE
        "format",   // ZF_FORMAT
        "tilyear",  // ZF_TILYEAR
        "tilmonth", // ZF_TILMONTH
        "tilday",   // ZF_TILDAY
        "tiltime",  // ZF_TILTIME
    };

	if (nfields < ZONE_MINFIELDS || nfields > ZONE_MAXFIELDS) {
		error(_("wrong number of fields on Zone line"));
		return FALSE;
	}

    dump_line("zone", fields + 1, nfields - 1, fieldNames, lengthof(fieldNames), hasuntil ? FALSE : TRUE);

    return hasuntil;
}

static int
dump_zcont(
register char ** const	fields,
const int		nfields)
{
	/*
	** If there was an UNTIL field on this line,
	** there's more information about the zone on the next line.
	*/
    int hasuntil = nfields > ZFC_TILYEAR;

    const char* fieldNames[ZONEC_MAXFIELDS] =
    {
        "gmtoff",   // ZFC_GMTOFF
        "rule",     // ZFC_RULE
        "format",   // ZFC_FORMAT
        "tilyear",  // ZFC_TILYEAR
        "tilmonth", // ZFC_TILMONTH
        "tilday",   // ZFC_TILDAY
        "tiltime",  // ZFC_TILTIME
    };

    if (nfields < ZONEC_MINFIELDS || nfields > ZONEC_MAXFIELDS) {
		error(_("wrong number of fields on Zone continuation line"));
		return FALSE;
	}

    printf("\t");
    dump_line("zcont", fields, nfields, fieldNames, lengthof(fieldNames), TRUE);

    // Close the zone
    if( !hasuntil ) printf("\t</zone>\n");

    return hasuntil;
}

static void
dump_comment(const char* line, const int nfields, const int wantcont)
{
    char    buf[1024];

    // Check for the existance of a comment
    while( *line && (*line != '#') ) ++line;
    if( !*line )
    {
        if( !nfields ) printf("\n");
        return;
    }

    // Strip blank space and leading comment characters
    while( isspace(*line) || (*line == '#') ) ++line;
    if( !*line )
    {
        if( !nfields ) printf("\n");
        return;
    }

    if( nfields ) printf("\t");
    if( wantcont ) printf("\t");
    printf("<!-- %s -->\n", escapeXmlComment(line, buf));
}

void tzdump(const char* name)
{
    register FILE *         fp;
    register char **        fields;
    register char *         cp;
    register const struct lookup*   lp;
    register int            nfields;
    register int            wantcont;
    register int            num;
    char                    buf[BUFSIZ];
    const char*             afterFields = 0;
    
    if (strcmp(name, "-") == 0) {
        name = _("standard input");
        fp = stdin;
    } else if ((fp = fopen(name, "r")) == NULL) {
        const char *e = strerror(errno);
        
        (void) fprintf(stderr, _("%s: Can't open %s: %s\n"), progname, name, e);
        (void) exit(EXIT_FAILURE);
    }

    filename = name;

    wantcont = FALSE;
    for (num = 1; ; ++num) {
        eat(name, num);
        if (fgets(buf, (int) sizeof buf, fp) != buf)
            break;
        cp = strchr(buf, '\n');
        if (cp == NULL) {
            error(_("line too long"));
            (void) exit(EXIT_FAILURE);
        }
        *cp = '\0';
        fields = getfields(buf);
        nfields = 0;

        while( fields[nfields] )
        {
            // fields with the contents "-" are just placeholders and can be removed
            if( strcmp(fields[nfields], "-") == 0 ) *fields[nfields] = 0;
            ++nfields;
        }

        if( nfields ) afterFields = fields[nfields - 1] + strlen(fields[nfields - 1]) + 1;
        else afterFields = buf;

        dump_comment(afterFields, nfields, wantcont);

        if (nfields == 0) {
            /* nothing to do */
        } else if (wantcont) {
            wantcont = dump_zcont(fields, nfields);
        } else {
            lp = byword(fields[0], line_codes);
            if (lp == NULL)
                error(_("input line of unknown type"));
            else switch ((int) (lp->l_value)) {
                case LC_RULE:
                    dump_rule(fields, nfields);
                    wantcont = FALSE;
                    break;
                case LC_ZONE:
                    wantcont = dump_zone(fields, nfields);
                    break;
                case LC_LINK:
                    dump_link(fields, nfields);
                    wantcont = FALSE;
                    break;
                case LC_LEAP:
                    dump_leap(fields, nfields);
                    wantcont = FALSE;
                    break;
                default:	/* "cannot happen" */
                    (void) fprintf(stderr, _("%s: panic: Invalid l_value %d\n"), progname, lp->l_value);
                    (void) exit(EXIT_FAILURE);
            }
        }

        ifree((char *) fields);
    }
    if (ferror(fp)) {
        (void) fprintf(stderr, _("%s: Error reading %s\n"),
            progname, filename);
        (void) exit(EXIT_FAILURE);
    }
    if (fp != stdin && fclose(fp)) {
        const char *e = strerror(errno);
        
        (void) fprintf(stderr, _("%s: Error closing %s: %s\n"),
            progname, filename, e);
        (void) exit(EXIT_FAILURE);
    }
    if (wantcont)
        error(_("expected continuation line not found"));
}
