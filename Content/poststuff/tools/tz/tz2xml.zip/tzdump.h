// tzdump.h

void tzdump(const char* name);
