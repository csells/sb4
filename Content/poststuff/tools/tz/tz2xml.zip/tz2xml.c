// tz2xml.c

#include <stdio.h>
#include "tzdump.h"

// TODO: namespaces
// TODO: XSD

void main(int argc, char* argv[])
{
    int i = 0;

    printf("<tz>\n\n");

    if( argc > 1 )
    {
        for( i = 1; i!= argc; ++i )
        {
            tzdump(argv[i]);
            printf("\n");
        }
    }
    else
    {
        tzdump("-");
    }

    printf("</tz>\n");
}
