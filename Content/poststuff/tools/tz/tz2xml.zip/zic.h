// zic.h

#ifdef __cplusplus
extern "C" {
#endif

#include "private.h"
#include "tzfile.h"

extern int	getopt P((int argc, char * const argv[],
			const char * options));
extern int	link P((const char * fromname, const char * toname));
extern char *	optarg;
extern int	optind;

extern void	addtt P((time_t starttime, int type));
extern int	addtype P((long gmtoff, const char * abbr, int isdst,
				int ttisstd, int ttisgmt));
extern void	leapadd P((time_t t, int positive, int rolling, int count));
extern void	adjleap P((void));
extern void	associate P((void));
extern int	ciequal P((const char * ap, const char * bp));
extern void	convert P((long val, char * buf));
extern void	dolink P((const char * fromfile, const char * tofile));
extern void	doabbr P((char * abbr, const char * format,
			const char * letters, int isdst));
extern void	eat P((const char * name, int num));
extern void	eats P((const char * name, int num,
			const char * rname, int rnum));
extern long	eitol P((int i));
extern void	error P((const char * message));
extern char **	getfields P((char * buf));
extern long	gethms P((const char * string, const char * errstrng,
			int signable));
extern void	infile P((const char * filename));
extern void	inleap P((char ** fields, int nfields));
extern void	inlink P((char ** fields, int nfields));
extern void	inrule P((char ** fields, int nfields));
extern int	inzcont P((char ** fields, int nfields));
extern int	inzone P((char ** fields, int nfields));
extern int	inzsub P((char ** fields, int nfields, int iscont));
extern int	itsabbr P((const char * abbr, const char * word));
extern int	itsdir P((const char * name));
extern int	lowerit P((int c));
extern char *	memcheck P((char * tocheck));
extern int	mkdirs P((char * filename));
extern void	newabbr P((const char * abbr));
extern long	oadd P((long t1, long t2));
extern void	outzone P((const struct zone * zp, int ntzones));
extern void	puttzcode P((long code, FILE * fp));
extern int	rcomp P((const void * leftp, const void * rightp));
extern time_t	rpytime P((const struct rule * rp, int wantedy));
extern void	rulesub P((struct rule * rp,
			const char * loyearp, const char * hiyearp,
			const char * typep, const char * monthp,
			const char * dayp, const char * timep));
extern void	setboundaries P((void));
extern time_t	tadd P((time_t t1, long t2));
extern void	usage P((void));
extern void	writezone P((const char * name));
extern int	yearistype P((int year, const char * type));

#if !(HAVE_STRERROR - 0)
extern char *	strerror P((int));
#endif /* !(HAVE_STRERROR - 0) */

extern struct lookup const *	byword(const char * string,
					const struct lookup * lp);

extern struct lookup const	line_codes[];
extern struct lookup const	mon_names[];
extern struct lookup const	wday_names[];
extern struct lookup const	lasts[];
extern struct lookup const	begin_years[];
extern struct lookup const	end_years[];
extern struct lookup const	leap_types[];
extern const int	len_months[2][MONSPERYEAR];
extern const int	len_years[2];

extern struct attype {
	time_t		at;
	unsigned char	type;
}			attypes[TZ_MAX_TIMES];

extern long		gmtoffs[TZ_MAX_TYPES];
extern char		isdsts[TZ_MAX_TYPES];
extern unsigned char	abbrinds[TZ_MAX_TYPES];
extern char		ttisstds[TZ_MAX_TYPES];
extern char		ttisgmts[TZ_MAX_TYPES];
extern char		chars[TZ_MAX_CHARS];
extern time_t		trans[TZ_MAX_LEAPS];
extern long		corr[TZ_MAX_LEAPS];
extern char		roll[TZ_MAX_LEAPS];

struct lookup {
	const char *	l_word;
	const int	l_value;
};

/*
** Line codes.
*/

#define LC_RULE		0
#define LC_ZONE		1
#define LC_LINK		2
#define LC_LEAP		3

/*
** Which fields are which on a Zone line.
*/

#define ZF_NAME		1
#define ZF_GMTOFF	2
#define ZF_RULE		3
#define ZF_FORMAT	4
#define ZF_TILYEAR	5
#define ZF_TILMONTH	6
#define ZF_TILDAY	7
#define ZF_TILTIME	8
#define ZONE_MINFIELDS	5
#define ZONE_MAXFIELDS	9

/*
** Which fields are which on a Zone continuation line.
*/

#define ZFC_GMTOFF	0
#define ZFC_RULE	1
#define ZFC_FORMAT	2
#define ZFC_TILYEAR	3
#define ZFC_TILMONTH	4
#define ZFC_TILDAY	5
#define ZFC_TILTIME	6
#define ZONEC_MINFIELDS	3
#define ZONEC_MAXFIELDS	7

/*
** Which files are which on a Rule line.
*/

#define RF_NAME		1
#define RF_LOYEAR	2
#define RF_HIYEAR	3
#define RF_COMMAND	4
#define RF_MONTH	5
#define RF_DAY		6
#define RF_TOD		7
#define RF_STDOFF	8
#define RF_ABBRVAR	9
#define RULE_FIELDS	10

/*
** Which fields are which on a Link line.
*/

#define LF_FROM		1
#define LF_TO		2
#define LINK_FIELDS	3

/*
** Which fields are which on a Leap line.
*/

#define LP_YEAR		1
#define LP_MONTH	2
#define LP_DAY		3
#define LP_TIME		4
#define LP_CORR		5
#define LP_ROLL		6
#define LEAP_FIELDS	7

/*
** Year synonyms.
*/

#define YR_MINIMUM	0
#define YR_MAXIMUM	1
#define YR_ONLY		2

extern const char *	psxrules;
extern const char *	lcltime;
extern const char *	directory;
extern const char *	leapsec;
extern const char *	yitcommand;
extern int		sflag;


#ifdef __cplusplus
}
#endif
