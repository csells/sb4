using System;
using System.Text.RegularExpressions;

class Class1
{
    void MatchRegex()
    {
        // Regex match
        RegexOptions    options = RegexOptions.None;
        Regex           regex = new Regex(@"(?<zip>\d{5})(-(?<suffix>\d{4}))?", options);
        string          input = @"97007-1212";

        // Check for match
        bool    isMatch = regex.IsMatch(input);
        if( isMatch )
        {
            // TODO: Do something with result
            System.Windows.Forms.MessageBox.Show(input, "IsMatch");
        }

        // Get match
        Match   match = regex.Match(input);
        if( match != null )
        {
            // TODO: Do something with result
            System.Windows.Forms.MessageBox.Show(match.Value, "Match");
        }

        // Get matches
        MatchCollection matches = regex.Matches(input);
        for( int i = 0; i != matches.Count; ++i )
        {
            // TODO: Do something with result
            System.Windows.Forms.MessageBox.Show(matches[i].Value, "Match");
        }

        // Numbered groups
        for( int i = 0; i != match.Groups.Count; ++i )
        {
            Group   group = match.Groups[i];
            
            // TODO: Do something with result
            System.Windows.Forms.MessageBox.Show(group.Value, "Group: " + i);
        }

        // Named groups
        string  zip = match.Groups["zip"].Value;
        string  suffix = match.Groups["suffix"].Value;

        // TODO: Do something with result
        System.Windows.Forms.MessageBox.Show(zip, "Group: zip");
        System.Windows.Forms.MessageBox.Show(suffix, "Group: suffix");
    }

    void ReplaceRegex()
    {
        // Regex search and replace
        RegexOptions    options = RegexOptions.None;
        Regex           regex = new Regex(@"[aeiou]", options);
        string          input = @"a quick brown fox jumps over the lazy dog";
        string          replacement = @"!";
        string          result = regex.Replace(input, replacement); 

        // TODO: Do something with result
        System.Windows.Forms.MessageBox.Show(result, "Replace");
    }

    static void Main(string[] args)
    {
        (new Class1()).MatchRegex();
        (new Class1()).ReplaceRegex();
    }
}
