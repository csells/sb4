// RegexDesigner
/////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2001, Sells Brothers, Inc.
// All rights reserved. No warranties extended. Use at your own risk.
// You may not redistribute this code in any form.
// The official home of this utility is http://www.sellsbrothers.com
/////////////////////////////////////////////////////////////////////////////

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;    // Path and StreamWriter
using System.IO.IsolatedStorage;
using System.Text;  // StringBuilder
using System.Text.RegularExpressions;   // RegEx classes
using System.Diagnostics;   // Debug.Assert
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Reflection;
using System.Resources;
using Genghis.Windows.Forms;    // MRU

internal class MainForm : System.Windows.Forms.Form
{
    private System.Windows.Forms.MenuItem menuItem1;
    private System.Windows.Forms.MenuItem menuItem5;
    private System.Windows.Forms.MenuItem cmdFileExit;
    private System.Windows.Forms.MenuItem cmdHelpAbout;
    private System.Windows.Forms.MenuItem optSingleLine;
    private System.Windows.Forms.MenuItem optCompiled;
    private System.Windows.Forms.MenuItem optEcmaScript;
    private System.Windows.Forms.MenuItem optExplicitCapture;
    private System.Windows.Forms.MenuItem optIgnoreCase;
    private System.Windows.Forms.MenuItem optIgnorePatternWhitespace;
    private System.Windows.Forms.MenuItem optMultiline;
    private System.Windows.Forms.MenuItem optRightToLeft;
    private System.Windows.Forms.MenuItem optMultipleMatches;
    private System.Windows.Forms.MenuItem menuItem4;
    private System.Windows.Forms.MenuItem menuItem3;
    private System.Windows.Forms.MenuItem cmdNewdoc;
    private System.Windows.Forms.MenuItem cmdOpendoc;
    private System.Windows.Forms.SaveFileDialog saveFileDialog;
    private System.Windows.Forms.OpenFileDialog openFileDialog;
    private System.Windows.Forms.MainMenu mainMenu;
    private System.Windows.Forms.MenuItem cmdSavedoc;
    private System.Windows.Forms.MenuItem cmdSavedocAs;
    private System.Windows.Forms.MenuItem cmdMatchText;
    private System.Windows.Forms.MenuItem menuMatch;
    private System.Windows.Forms.MenuItem cmdCompileToAssembly;
    private System.Windows.Forms.TextBox txtRegex;
    private System.Windows.Forms.Splitter hSplitter;
    private System.Windows.Forms.StatusBar statusBar;
    private HeaderGroupBox grpTextToMatch;
    private System.Windows.Forms.TextBox txtTextToMatch;
    private System.Windows.Forms.Splitter vSplitter;
    private HeaderGroupBox grpMatchedText;
    private AxSHDocVw.AxWebBrowser axMatchedText;
    private System.Windows.Forms.ImageList toolBarImageList;
    private System.Windows.Forms.MenuItem cmdReplaceText;
    private System.Windows.Forms.ToolBar toolBar;
    private System.Windows.Forms.ToolBarButton tlbbtnCompileToAssembly;
    private System.Windows.Forms.ToolBarButton tlbbtnNewProject;
    private System.Windows.Forms.ToolBarButton tlbbtnOpenProject;
    private System.Windows.Forms.ToolBarButton tlbbtnSaveProject;
    private System.Windows.Forms.ToolBarButton tlbbtnMatchText;
    private System.Windows.Forms.ToolBarButton tlbbtnReplaceText;
    private System.Windows.Forms.TabControl tabControl;
    private System.Windows.Forms.TabPage pageRegex;
    private System.Windows.Forms.TabPage pageReplace;
    private System.Windows.Forms.TextBox txtReplace;
    private System.Windows.Forms.MenuItem cmdGenerateCode;
    private System.Windows.Forms.ToolBarButton tlbbtnCodeGen;
    private System.Windows.Forms.MenuItem cmdHelpContents;
    private System.Windows.Forms.MenuItem cmdHelpBuy;
    private System.Windows.Forms.MenuItem cmdSendFeedback;
    private System.Windows.Forms.MenuItem cmdHelpOnTheWeb;
    private System.Windows.Forms.MenuItem menuItem10;
    private System.Windows.Forms.MenuItem menuItem11;
    private System.Windows.Forms.MenuItem cmdSplitText;
    private System.Windows.Forms.MenuItem menuItem6;
    private System.Windows.Forms.ToolBarButton tlbbtnSeparator1;
    private System.Windows.Forms.ToolBarButton tblbtnSplitText;
    private System.Windows.Forms.ToolBarButton tlbbthSeparator2;
    private System.Windows.Forms.MenuItem cmdMRU;
    private System.Windows.Forms.MenuItem menuItem8;
    private System.Windows.Forms.MenuItem optShowZeroLengthMatches;
    private System.Windows.Forms.MenuItem menuItem2;
    private System.ComponentModel.IContainer components = null;
    
    public MainForm()
    {
        // Required for Windows Form Designer support
        InitializeComponent();

        // Cache the text's font for use when building the match output
        _fontFamily = txtTextToMatch.Font.FontFamily.Name;
        _fontSize = txtTextToMatch.Font.SizeInPoints;

        // Cache the title format
        _titleFormat = Text;
        
        // Set the About menu text
        // NOTE: No need to cache since only set once
        cmdHelpAbout.Text = string.Format(cmdHelpAbout.Text, App.ApplicationName);

        // TODO
        this.KeyPreview = true;
        
        // Load application and user settings
        _mru = new MRU(MRUMenuLocation.InMenu, 4, "Recently Used Files", 40, cmdMRU, new System.EventHandler(MRUClickEventHandler));
        LoadSettings();
    }

    private string      _fontFamily;
    private double      _fontSize;
    private string      _htmlFileName = Path.GetTempFileName();
    private string      _titleFormat;
    private string      _docFileName;
    private RegexDoc    _doc = new RegexDoc();
    private MRU         _mru;
    private Operation   _lastOperation = Operation.None;

    // Settings file
    private const string   _settingsFileName = "settings.txt";

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing )
    {
        if( disposing )
        {
            if( components != null )
            {
                components.Dispose();
            }
        }

        RemoveHtmlFile();

        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(MainForm));
      this.axMatchedText = new AxSHDocVw.AxWebBrowser();
      this.menuItem4 = new System.Windows.Forms.MenuItem();
      this.menuItem5 = new System.Windows.Forms.MenuItem();
      this.cmdHelpContents = new System.Windows.Forms.MenuItem();
      this.menuItem10 = new System.Windows.Forms.MenuItem();
      this.cmdHelpBuy = new System.Windows.Forms.MenuItem();
      this.cmdSendFeedback = new System.Windows.Forms.MenuItem();
      this.cmdHelpOnTheWeb = new System.Windows.Forms.MenuItem();
      this.menuItem11 = new System.Windows.Forms.MenuItem();
      this.cmdHelpAbout = new System.Windows.Forms.MenuItem();
      this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
      this.menuItem1 = new System.Windows.Forms.MenuItem();
      this.cmdNewdoc = new System.Windows.Forms.MenuItem();
      this.cmdOpendoc = new System.Windows.Forms.MenuItem();
      this.cmdSavedoc = new System.Windows.Forms.MenuItem();
      this.cmdSavedocAs = new System.Windows.Forms.MenuItem();
      this.menuItem8 = new System.Windows.Forms.MenuItem();
      this.cmdMRU = new System.Windows.Forms.MenuItem();
      this.menuItem3 = new System.Windows.Forms.MenuItem();
      this.cmdFileExit = new System.Windows.Forms.MenuItem();
      this.cmdCompileToAssembly = new System.Windows.Forms.MenuItem();
      this.toolBar = new System.Windows.Forms.ToolBar();
      this.tlbbtnNewProject = new System.Windows.Forms.ToolBarButton();
      this.tlbbtnOpenProject = new System.Windows.Forms.ToolBarButton();
      this.tlbbtnSaveProject = new System.Windows.Forms.ToolBarButton();
      this.tlbbtnSeparator1 = new System.Windows.Forms.ToolBarButton();
      this.tlbbtnMatchText = new System.Windows.Forms.ToolBarButton();
      this.tlbbtnReplaceText = new System.Windows.Forms.ToolBarButton();
      this.tblbtnSplitText = new System.Windows.Forms.ToolBarButton();
      this.tlbbthSeparator2 = new System.Windows.Forms.ToolBarButton();
      this.tlbbtnCodeGen = new System.Windows.Forms.ToolBarButton();
      this.tlbbtnCompileToAssembly = new System.Windows.Forms.ToolBarButton();
      this.toolBarImageList = new System.Windows.Forms.ImageList(this.components);
      this.optMultiline = new System.Windows.Forms.MenuItem();
      this.grpMatchedText = new HeaderGroupBox();
      this.txtTextToMatch = new System.Windows.Forms.TextBox();
      this.mainMenu = new System.Windows.Forms.MainMenu();
      this.menuItem2 = new System.Windows.Forms.MenuItem();
      this.optMultipleMatches = new System.Windows.Forms.MenuItem();
      this.optShowZeroLengthMatches = new System.Windows.Forms.MenuItem();
      this.menuMatch = new System.Windows.Forms.MenuItem();
      this.cmdMatchText = new System.Windows.Forms.MenuItem();
      this.cmdReplaceText = new System.Windows.Forms.MenuItem();
      this.cmdSplitText = new System.Windows.Forms.MenuItem();
      this.cmdGenerateCode = new System.Windows.Forms.MenuItem();
      this.menuItem6 = new System.Windows.Forms.MenuItem();
      this.optSingleLine = new System.Windows.Forms.MenuItem();
      this.optCompiled = new System.Windows.Forms.MenuItem();
      this.optEcmaScript = new System.Windows.Forms.MenuItem();
      this.optExplicitCapture = new System.Windows.Forms.MenuItem();
      this.optIgnoreCase = new System.Windows.Forms.MenuItem();
      this.optIgnorePatternWhitespace = new System.Windows.Forms.MenuItem();
      this.optRightToLeft = new System.Windows.Forms.MenuItem();
      this.txtRegex = new System.Windows.Forms.TextBox();
      this.grpTextToMatch = new HeaderGroupBox();
      this.statusBar = new System.Windows.Forms.StatusBar();
      this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
      this.vSplitter = new System.Windows.Forms.Splitter();
      this.hSplitter = new System.Windows.Forms.Splitter();
      this.tabControl = new System.Windows.Forms.TabControl();
      this.pageRegex = new System.Windows.Forms.TabPage();
      this.pageReplace = new System.Windows.Forms.TabPage();
      this.txtReplace = new System.Windows.Forms.TextBox();
      ((System.ComponentModel.ISupportInitialize)(this.axMatchedText)).BeginInit();
      this.grpMatchedText.SuspendLayout();
      this.grpTextToMatch.SuspendLayout();
      this.tabControl.SuspendLayout();
      this.pageRegex.SuspendLayout();
      this.pageReplace.SuspendLayout();
      this.SuspendLayout();
      // 
      // axMatchedText
      // 
      this.axMatchedText.ContainingControl = this;
      this.axMatchedText.Dock = System.Windows.Forms.DockStyle.Fill;
      this.axMatchedText.Enabled = true;
      this.axMatchedText.Location = new System.Drawing.Point(3, 16);
      this.axMatchedText.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axMatchedText.OcxState")));
      this.axMatchedText.Size = new System.Drawing.Size(367, 187);
      this.axMatchedText.TabIndex = 0;
      this.axMatchedText.TabStop = false;
      // 
      // menuItem4
      // 
      this.menuItem4.Index = 3;
      this.menuItem4.Text = "-";
      // 
      // menuItem5
      // 
      this.menuItem5.Index = 3;
      this.menuItem5.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.cmdHelpContents,
                                                                              this.menuItem10,
                                                                              this.cmdHelpBuy,
                                                                              this.cmdSendFeedback,
                                                                              this.cmdHelpOnTheWeb,
                                                                              this.menuItem11,
                                                                              this.cmdHelpAbout});
      this.menuItem5.Text = "&Help";
      // 
      // cmdHelpContents
      // 
      this.cmdHelpContents.Index = 0;
      this.cmdHelpContents.Text = "&Contents...";
      this.cmdHelpContents.Click += new System.EventHandler(this.cmdHelpContents_Click);
      // 
      // menuItem10
      // 
      this.menuItem10.Index = 1;
      this.menuItem10.Text = "-";
      // 
      // cmdHelpBuy
      // 
      this.cmdHelpBuy.Index = 2;
      this.cmdHelpBuy.Text = "&Buy RegexDesigner.NET...";
      this.cmdHelpBuy.Click += new System.EventHandler(this.cmdHelpBuy_Click);
      // 
      // cmdSendFeedback
      // 
      this.cmdSendFeedback.Index = 3;
      this.cmdSendFeedback.Text = "Send &Feedback...";
      this.cmdSendFeedback.Click += new System.EventHandler(this.cmdSendFeedback_Click);
      // 
      // cmdHelpOnTheWeb
      // 
      this.cmdHelpOnTheWeb.Index = 4;
      this.cmdHelpOnTheWeb.Text = "RegexDesigner.NET on the &Web...";
      this.cmdHelpOnTheWeb.Click += new System.EventHandler(this.cmdHelpOnTheWeb_Click);
      // 
      // menuItem11
      // 
      this.menuItem11.Index = 5;
      this.menuItem11.Text = "-";
      // 
      // cmdHelpAbout
      // 
      this.cmdHelpAbout.Index = 6;
      this.cmdHelpAbout.Text = "&About RegexDesigner.NET...";
      this.cmdHelpAbout.Click += new System.EventHandler(this.cmdHelpAbout_Click);
      // 
      // openFileDialog
      // 
      this.openFileDialog.DefaultExt = "rep";
      this.openFileDialog.Filter = "RegexDesigner.NET Projects (*.rep)|*.rep|All files|*.*";
      // 
      // menuItem1
      // 
      this.menuItem1.Index = 0;
      this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.cmdNewdoc,
                                                                              this.cmdOpendoc,
                                                                              this.cmdSavedoc,
                                                                              this.cmdSavedocAs,
                                                                              this.menuItem8,
                                                                              this.cmdMRU,
                                                                              this.menuItem3,
                                                                              this.cmdFileExit});
      this.menuItem1.Text = "&File";
      // 
      // cmdNewdoc
      // 
      this.cmdNewdoc.Index = 0;
      this.cmdNewdoc.Shortcut = System.Windows.Forms.Shortcut.CtrlN;
      this.cmdNewdoc.Text = "&New Project";
      this.cmdNewdoc.Click += new System.EventHandler(this.cmdNew_Click);
      // 
      // cmdOpendoc
      // 
      this.cmdOpendoc.Index = 1;
      this.cmdOpendoc.Shortcut = System.Windows.Forms.Shortcut.CtrlO;
      this.cmdOpendoc.Text = "&Open Project...";
      this.cmdOpendoc.Click += new System.EventHandler(this.cmdOpen_Click);
      // 
      // cmdSavedoc
      // 
      this.cmdSavedoc.Index = 2;
      this.cmdSavedoc.Shortcut = System.Windows.Forms.Shortcut.CtrlS;
      this.cmdSavedoc.Text = "&Save Project";
      this.cmdSavedoc.Click += new System.EventHandler(this.cmdSave_Click);
      // 
      // cmdSavedocAs
      // 
      this.cmdSavedocAs.Index = 3;
      this.cmdSavedocAs.Text = "Save Project &As...";
      this.cmdSavedocAs.Click += new System.EventHandler(this.cmdSaveAs_Click);
      // 
      // menuItem8
      // 
      this.menuItem8.Index = 4;
      this.menuItem8.Text = "-";
      // 
      // cmdMRU
      // 
      this.cmdMRU.Index = 5;
      this.cmdMRU.Text = "MRU";
      // 
      // menuItem3
      // 
      this.menuItem3.Index = 6;
      this.menuItem3.Text = "-";
      // 
      // cmdFileExit
      // 
      this.cmdFileExit.Index = 7;
      this.cmdFileExit.Text = "E&xit\tAlt+F4";
      this.cmdFileExit.Click += new System.EventHandler(this.cmdFileExit_Click);
      // 
      // cmdCompileToAssembly
      // 
      this.cmdCompileToAssembly.Index = 5;
      this.cmdCompileToAssembly.Shortcut = System.Windows.Forms.Shortcut.CtrlShiftB;
      this.cmdCompileToAssembly.Text = "&Compile To Assembly...";
      this.cmdCompileToAssembly.Click += new System.EventHandler(this.cmdCompileToAssembly_Click);
      // 
      // toolBar
      // 
      this.toolBar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
      this.toolBar.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
                                                                               this.tlbbtnNewProject,
                                                                               this.tlbbtnOpenProject,
                                                                               this.tlbbtnSaveProject,
                                                                               this.tlbbtnSeparator1,
                                                                               this.tlbbtnMatchText,
                                                                               this.tlbbtnReplaceText,
                                                                               this.tblbtnSplitText,
                                                                               this.tlbbthSeparator2,
                                                                               this.tlbbtnCodeGen,
                                                                               this.tlbbtnCompileToAssembly});
      this.toolBar.DropDownArrows = true;
      this.toolBar.ImageList = this.toolBarImageList;
      this.toolBar.Name = "toolBar";
      this.toolBar.ShowToolTips = true;
      this.toolBar.Size = new System.Drawing.Size(576, 25);
      this.toolBar.TabIndex = 1;
      this.toolBar.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.toolBar_ButtonClick);
      // 
      // tlbbtnNewProject
      // 
      this.tlbbtnNewProject.ImageIndex = 0;
      this.tlbbtnNewProject.ToolTipText = "New Project";
      // 
      // tlbbtnOpenProject
      // 
      this.tlbbtnOpenProject.ImageIndex = 1;
      this.tlbbtnOpenProject.ToolTipText = "Open Project";
      // 
      // tlbbtnSaveProject
      // 
      this.tlbbtnSaveProject.ImageIndex = 2;
      this.tlbbtnSaveProject.ToolTipText = "Save Project";
      // 
      // tlbbtnSeparator1
      // 
      this.tlbbtnSeparator1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
      // 
      // tlbbtnMatchText
      // 
      this.tlbbtnMatchText.ImageIndex = 3;
      this.tlbbtnMatchText.ToolTipText = "Match Text";
      // 
      // tlbbtnReplaceText
      // 
      this.tlbbtnReplaceText.ImageIndex = 4;
      this.tlbbtnReplaceText.ToolTipText = "Replace Text";
      // 
      // tblbtnSplitText
      // 
      this.tblbtnSplitText.ImageIndex = 5;
      this.tblbtnSplitText.ToolTipText = "Split Text";
      // 
      // tlbbthSeparator2
      // 
      this.tlbbthSeparator2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
      // 
      // tlbbtnCodeGen
      // 
      this.tlbbtnCodeGen.ImageIndex = 6;
      this.tlbbtnCodeGen.ToolTipText = "Generate Code";
      // 
      // tlbbtnCompileToAssembly
      // 
      this.tlbbtnCompileToAssembly.ImageIndex = 7;
      this.tlbbtnCompileToAssembly.ToolTipText = "Compile To Assembly";
      // 
      // toolBarImageList
      // 
      this.toolBarImageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth24Bit;
      this.toolBarImageList.ImageSize = new System.Drawing.Size(16, 16);
      this.toolBarImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("toolBarImageList.ImageStream")));
      this.toolBarImageList.TransparentColor = System.Drawing.Color.Transparent;
      // 
      // optMultiline
      // 
      this.optMultiline.Index = 13;
      this.optMultiline.Text = "Multili&ne";
      this.optMultiline.Click += new System.EventHandler(this.optMultiline_Click);
      // 
      // grpMatchedText
      // 
      this.grpMatchedText.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                                 this.axMatchedText});
      this.grpMatchedText.Dock = System.Windows.Forms.DockStyle.Fill;
      this.grpMatchedText.Location = new System.Drawing.Point(203, 127);
      this.grpMatchedText.Name = "grpMatchedText";
      this.grpMatchedText.Padding = 4;
      this.grpMatchedText.Size = new System.Drawing.Size(373, 206);
      this.grpMatchedText.TabIndex = 12;
      this.grpMatchedText.TabStop = false;
      this.grpMatchedText.Text = "Results";
      // 
      // txtTextToMatch
      // 
      this.txtTextToMatch.BackColor = System.Drawing.Color.White;
      this.txtTextToMatch.Dock = System.Windows.Forms.DockStyle.Fill;
      this.txtTextToMatch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.txtTextToMatch.ForeColor = System.Drawing.Color.Black;
      this.txtTextToMatch.Location = new System.Drawing.Point(3, 16);
      this.txtTextToMatch.Multiline = true;
      this.txtTextToMatch.Name = "txtTextToMatch";
      this.txtTextToMatch.ScrollBars = System.Windows.Forms.ScrollBars.Both;
      this.txtTextToMatch.Size = new System.Drawing.Size(194, 187);
      this.txtTextToMatch.TabIndex = 2;
      this.txtTextToMatch.Text = "";
      this.txtTextToMatch.WordWrap = false;
      this.txtTextToMatch.TextChanged += new System.EventHandler(this.txtTextToMatch_TextChanged);
      // 
      // mainMenu
      // 
      this.mainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                             this.menuItem1,
                                                                             this.menuItem2,
                                                                             this.menuMatch,
                                                                             this.menuItem5});
      // 
      // menuItem2
      // 
      this.menuItem2.Index = 1;
      this.menuItem2.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.optMultipleMatches,
                                                                              this.optShowZeroLengthMatches});
      this.menuItem2.Text = "&View";
      // 
      // optMultipleMatches
      // 
      this.optMultipleMatches.Checked = true;
      this.optMultipleMatches.Index = 0;
      this.optMultipleMatches.Text = "&Show Multiple Matches";
      this.optMultipleMatches.Click += new System.EventHandler(this.optMultipleMatches_Click);
      // 
      // optShowZeroLengthMatches
      // 
      this.optShowZeroLengthMatches.Checked = true;
      this.optShowZeroLengthMatches.Index = 1;
      this.optShowZeroLengthMatches.Text = "Show &Zero-Length Matches";
      this.optShowZeroLengthMatches.Click += new System.EventHandler(this.optShowZeroLengthMatches_Click);
      // 
      // menuMatch
      // 
      this.menuMatch.Index = 2;
      this.menuMatch.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.cmdMatchText,
                                                                              this.cmdReplaceText,
                                                                              this.cmdSplitText,
                                                                              this.menuItem4,
                                                                              this.cmdGenerateCode,
                                                                              this.cmdCompileToAssembly,
                                                                              this.menuItem6,
                                                                              this.optSingleLine,
                                                                              this.optCompiled,
                                                                              this.optEcmaScript,
                                                                              this.optExplicitCapture,
                                                                              this.optIgnoreCase,
                                                                              this.optIgnorePatternWhitespace,
                                                                              this.optMultiline,
                                                                              this.optRightToLeft});
      this.menuMatch.Text = "&Regex";
      this.menuMatch.Popup += new System.EventHandler(this.menuMatch_Popup);
      // 
      // cmdMatchText
      // 
      this.cmdMatchText.Index = 0;
      this.cmdMatchText.Shortcut = System.Windows.Forms.Shortcut.CtrlM;
      this.cmdMatchText.Text = "&Match Text";
      this.cmdMatchText.Click += new System.EventHandler(this.cmdMatchText_Click);
      // 
      // cmdReplaceText
      // 
      this.cmdReplaceText.Index = 1;
      this.cmdReplaceText.Shortcut = System.Windows.Forms.Shortcut.CtrlR;
      this.cmdReplaceText.Text = "&Replace Text";
      this.cmdReplaceText.Click += new System.EventHandler(this.cmdReplaceText_Click);
      // 
      // cmdSplitText
      // 
      this.cmdSplitText.Index = 2;
      this.cmdSplitText.Shortcut = System.Windows.Forms.Shortcut.CtrlL;
      this.cmdSplitText.Text = "Sp&lit Text";
      this.cmdSplitText.Click += new System.EventHandler(this.cmdSplitText_Click);
      // 
      // cmdGenerateCode
      // 
      this.cmdGenerateCode.Index = 4;
      this.cmdGenerateCode.Shortcut = System.Windows.Forms.Shortcut.CtrlG;
      this.cmdGenerateCode.Text = "&Generate Code...";
      this.cmdGenerateCode.Click += new System.EventHandler(this.cmdGenerateCode_Click);
      // 
      // menuItem6
      // 
      this.menuItem6.Index = 6;
      this.menuItem6.Text = "-";
      // 
      // optSingleLine
      // 
      this.optSingleLine.Index = 7;
      this.optSingleLine.Text = "Single &Line";
      this.optSingleLine.Click += new System.EventHandler(this.optSingleLine_Click);
      // 
      // optCompiled
      // 
      this.optCompiled.Index = 8;
      this.optCompiled.Text = "&Compiled";
      this.optCompiled.Click += new System.EventHandler(this.optCompiled_Click);
      // 
      // optEcmaScript
      // 
      this.optEcmaScript.Index = 9;
      this.optEcmaScript.Text = "&ECMAScript";
      this.optEcmaScript.Click += new System.EventHandler(this.optEcmaScript_Click);
      // 
      // optExplicitCapture
      // 
      this.optExplicitCapture.Index = 10;
      this.optExplicitCapture.Text = "E&xplicit Capture";
      this.optExplicitCapture.Click += new System.EventHandler(this.optExplicitCapture_Click);
      // 
      // optIgnoreCase
      // 
      this.optIgnoreCase.Index = 11;
      this.optIgnoreCase.Text = "&Ignore Case";
      this.optIgnoreCase.Click += new System.EventHandler(this.optIgnoreCase_Click);
      // 
      // optIgnorePatternWhitespace
      // 
      this.optIgnorePatternWhitespace.Index = 12;
      this.optIgnorePatternWhitespace.Text = "Ignore Pattern &Whitespace";
      this.optIgnorePatternWhitespace.Click += new System.EventHandler(this.optIgnorePatternWhitespace_Click);
      // 
      // optRightToLeft
      // 
      this.optRightToLeft.Index = 14;
      this.optRightToLeft.Text = "Right &to Left";
      this.optRightToLeft.Click += new System.EventHandler(this.optRightToLeft_Click);
      // 
      // txtRegex
      // 
      this.txtRegex.Dock = System.Windows.Forms.DockStyle.Fill;
      this.txtRegex.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.txtRegex.Multiline = true;
      this.txtRegex.Name = "txtRegex";
      this.txtRegex.Size = new System.Drawing.Size(568, 74);
      this.txtRegex.TabIndex = 0;
      this.txtRegex.Text = "";
      this.txtRegex.TextChanged += new System.EventHandler(this.txtRegex_TextChanged);
      // 
      // grpTextToMatch
      // 
      this.grpTextToMatch.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                                 this.txtTextToMatch});
      this.grpTextToMatch.Dock = System.Windows.Forms.DockStyle.Left;
      this.grpTextToMatch.Location = new System.Drawing.Point(0, 127);
      this.grpTextToMatch.Name = "grpTextToMatch";
      this.grpTextToMatch.Padding = 4;
      this.grpTextToMatch.Size = new System.Drawing.Size(200, 206);
      this.grpTextToMatch.TabIndex = 7;
      this.grpTextToMatch.TabStop = false;
      this.grpTextToMatch.Text = "Text to Match";
      // 
      // statusBar
      // 
      this.statusBar.Location = new System.Drawing.Point(0, 333);
      this.statusBar.Name = "statusBar";
      this.statusBar.Size = new System.Drawing.Size(576, 20);
      this.statusBar.TabIndex = 10;
      this.statusBar.Text = "Ready";
      // 
      // saveFileDialog
      // 
      this.saveFileDialog.DefaultExt = "rep";
      this.saveFileDialog.FileName = "Untitled";
      this.saveFileDialog.Filter = "RegexDesigner.NET Projects (*.rep)|*.rep|All files|*.*";
      // 
      // vSplitter
      // 
      this.vSplitter.BackColor = System.Drawing.SystemColors.Control;
      this.vSplitter.Location = new System.Drawing.Point(200, 127);
      this.vSplitter.Name = "vSplitter";
      this.vSplitter.Size = new System.Drawing.Size(3, 206);
      this.vSplitter.TabIndex = 9;
      this.vSplitter.TabStop = false;
      // 
      // hSplitter
      // 
      this.hSplitter.BackColor = System.Drawing.SystemColors.Control;
      this.hSplitter.Dock = System.Windows.Forms.DockStyle.Top;
      this.hSplitter.Location = new System.Drawing.Point(0, 125);
      this.hSplitter.Name = "hSplitter";
      this.hSplitter.Size = new System.Drawing.Size(576, 2);
      this.hSplitter.TabIndex = 6;
      this.hSplitter.TabStop = false;
      // 
      // tabControl
      // 
      this.tabControl.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                             this.pageRegex,
                                                                             this.pageReplace});
      this.tabControl.Dock = System.Windows.Forms.DockStyle.Top;
      this.tabControl.HotTrack = true;
      this.tabControl.Location = new System.Drawing.Point(0, 25);
      this.tabControl.Name = "tabControl";
      this.tabControl.SelectedIndex = 0;
      this.tabControl.Size = new System.Drawing.Size(576, 100);
      this.tabControl.TabIndex = 13;
      // 
      // pageRegex
      // 
      this.pageRegex.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.txtRegex});
      this.pageRegex.Location = new System.Drawing.Point(4, 22);
      this.pageRegex.Name = "pageRegex";
      this.pageRegex.Size = new System.Drawing.Size(568, 74);
      this.pageRegex.TabIndex = 0;
      this.pageRegex.Text = "Regular Expression";
      // 
      // pageReplace
      // 
      this.pageReplace.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                              this.txtReplace});
      this.pageReplace.Location = new System.Drawing.Point(4, 22);
      this.pageReplace.Name = "pageReplace";
      this.pageReplace.Size = new System.Drawing.Size(568, 74);
      this.pageReplace.TabIndex = 1;
      this.pageReplace.Text = "Replacement String";
      // 
      // txtReplace
      // 
      this.txtReplace.Dock = System.Windows.Forms.DockStyle.Fill;
      this.txtReplace.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
      this.txtReplace.Multiline = true;
      this.txtReplace.Name = "txtReplace";
      this.txtReplace.Size = new System.Drawing.Size(568, 74);
      this.txtReplace.TabIndex = 0;
      this.txtReplace.Text = "";
      this.txtReplace.TextChanged += new System.EventHandler(this.txtReplace_TextChanged);
      // 
      // MainForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(576, 353);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.grpMatchedText,
                                                                  this.vSplitter,
                                                                  this.grpTextToMatch,
                                                                  this.statusBar,
                                                                  this.hSplitter,
                                                                  this.tabControl,
                                                                  this.toolBar});
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Menu = this.mainMenu;
      this.MinimumSize = new System.Drawing.Size(560, 340);
      this.Name = "MainForm";
      this.Text = "{0}{1} - {2} {3}";
      this.Closing += new System.ComponentModel.CancelEventHandler(this.MainForm_Closing);
      this.Load += new System.EventHandler(this.MainForm_Load);
      ((System.ComponentModel.ISupportInitialize)(this.axMatchedText)).EndInit();
      this.grpMatchedText.ResumeLayout(false);
      this.grpTextToMatch.ResumeLayout(false);
      this.tabControl.ResumeLayout(false);
      this.pageRegex.ResumeLayout(false);
      this.pageReplace.ResumeLayout(false);
      this.ResumeLayout(false);

    }
    #endregion
      
    #region Application and User Settings
    private void LoadSettings()
    {
        try
        {
            using( Stream         stream = OpenSettingsStream() )
            using( StreamReader   reader = new StreamReader(stream) )
            {
                // Load settings
                tabControl.Height = (int)ReadSetting(reader, typeof(int));
                grpTextToMatch.Width = (int)ReadSetting(reader, typeof(int));
                WindowState = (FormWindowState)ReadSetting(reader, typeof(FormWindowState)); 
                ClientSize = (Size)ReadSetting(reader, typeof(Size));
                Location = (Point)ReadSetting(reader, typeof(Point));
                optShowZeroLengthMatches.Checked = (bool)ReadSetting(reader, typeof(bool));
                optMultipleMatches.Checked = (bool)ReadSetting(reader, typeof(bool));
                // Rehydrate MRU
                int   mruCount = (int)ReadSetting(reader, typeof(int));
                if( mruCount > 0 )
                {
                    for( int fileIndex = 1; fileIndex <= mruCount; fileIndex++ ) _mru.Add((string)ReadSetting(reader, typeof(string)));
                }
            }
        }
        catch
        {
            // Default form location if settings file doesn't exist
            StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        }
    }

    private void SaveSettings()
    {
        using( Stream         stream = CreateSettingsStream() )
        using( StreamWriter   writer = new StreamWriter(stream) )
        {   
            // Save settings
            FormWindowState   saveFormWindowState = (WindowState == FormWindowState.Minimized ? FormWindowState.Normal : WindowState);
            WriteSetting(writer, tabControl.Height);
            WriteSetting(writer, grpTextToMatch.Width);
            WindowState = FormWindowState.Normal;
            WriteSetting(writer, saveFormWindowState);
            WriteSetting(writer, ClientSize);
            WriteSetting(writer, Location);
            WriteSetting(writer, optShowZeroLengthMatches.Checked);
            WriteSetting(writer, optMultipleMatches.Checked);
            // Persist MRU
            if( _mru.Count > 0 )
            {
                WriteSetting(writer, _mru.Count);
                for( int fileIndex = _mru.Parent.Index + _mru.Count; fileIndex > _mru.Parent.Index; fileIndex-- )
                {
                    WriteSetting(writer, _mru.GetFileName(fileIndex));
                }
            }
        }
    }

    private IsolatedStorageFileStream CreateSettingsStream()
    {
        IsolatedStorageFile store = IsolatedStorageFile.GetUserStoreForDomain();
        return new IsolatedStorageFileStream(_settingsFileName, FileMode.Create, store);
    }

    private IsolatedStorageFileStream OpenSettingsStream()
    {
        IsolatedStorageFile store = IsolatedStorageFile.GetUserStoreForDomain();
        return new IsolatedStorageFileStream(_settingsFileName, FileMode.Open, store);
    }

    private object ReadSetting(StreamReader reader, Type type)
    {
        TypeConverter   converter = TypeDescriptor.GetConverter(type);
        return converter.ConvertFromString(reader.ReadLine());
    }

    private void WriteSetting(StreamWriter writer, object obj)
    {
        TypeConverter   converter = TypeDescriptor.GetConverter(obj.GetType());
        writer.WriteLine(converter.ConvertToString(obj));
    }
    #endregion
    
    #region Regex Match Text Html Management
    
    private void RemoveHtmlFile()
    {
        File.Delete(_htmlFileName);
        _htmlFileName = null;
    }

    private void NavigateToHtmlFile()
    {
        // Navigate to specified document
        object arg1 = 0; object arg2 = ""; object arg3 = ""; object arg4 = "";
        axMatchedText.Navigate(_htmlFileName, ref arg1, ref arg2, ref arg3, ref arg4);
    }
    
    private string HtmlEscape(string s)
    {
        StringBuilder   sb = new StringBuilder(s);
        sb.Replace("<", "&lt;");
        sb.Replace(">", "&gt;");
        // NOTE: \r should not actually display anything since it will always be followed by a \n
        //       but, if ony \n was matched, displaying an unmatched \r will cause a carriage return
        //       but we only want a carriage-return\linefeed combination to cause a newline *only* 
        //       after an \n, matched or not.  So, by removing the \r when not matched, we only allow
        //       the \r\n combination to generate a new line in the matched text, irrespective of which
        //       combination of these characters was included in the regex
        sb.Replace("\r", "");
        return sb.ToString();
    }
    
    private string InvisibleCharacterEscape(string s, bool addRealNewLine, bool showZeroLength)
    {
        // Check zero-length situation
        if( s.Length == 0 )
        {
            if( showZeroLength ) return "[]";
            else return "";
        }
        
        // Apply escape encoding
        StringBuilder   sb = new StringBuilder(s);
        sb.Replace(" ", "@");
        sb.Replace("\n", ( addRealNewLine ? @"\n" + "\n" : @"\n" ));
        sb.Replace("\r", @"\r");
        sb.Replace("\f", @"\f");
        sb.Replace("\t", "\t" + @"\t");
        sb.Replace("\v", @"\v");
        return sb.ToString();
    }
    
    private void ShowMatchResultsText(string html)
    {
        // Write the contents
        StreamWriter   file = File.CreateText(_htmlFileName);
        string htmlHeader = @"
<html>
</head>
<style>
.text {{ font: {0}pt {1}; }}
.match0 {{ color: red; cursor : hand; }}
.match1 {{ color: green; cursor : hand; }}
</style>
</head>
<body leftMargin=1 rightMargin=1 topMargin=1 bottomMargin=1 style='color: black; background-color: white;'>
<pre class='text'>";
        string   htmlFooter = @"</pre></body></html>";
        file.WriteLine(htmlHeader, _fontSize, _fontFamily);
        file.Write(html);
        file.WriteLine(htmlFooter);
        file.Close();

        // Feed it to the browser
        NavigateToHtmlFile();
    }

    private string BuildMatchResultsHtml(SegmentCollection segmentCollection)
    {       
        // Build operation results HTML
        StringBuilder   sb = new StringBuilder();
        
        foreach( Segment segment in segmentCollection )
        {
            // Is current segment a result?
            SegmentMatch   segmentMatch = segment.Match;
            if( segmentMatch != null )
            {
                int   segmentMatchNumber = segmentMatch.Number;

                // Build group(s)
                StringBuilder   groupBuilder = new StringBuilder();
                foreach( SegmentMatchGroup segmentMatchGroup in segmentMatch.MatchGroups )
                {
                    groupBuilder.Append("\r\n").Append(segmentMatchGroup.Position.ToString());
                    if( segmentMatchGroup.Named ) groupBuilder.Append(" (").Append(segmentMatchGroup.Name).Append(")");
                    groupBuilder.Append(": ");
                    groupBuilder.Append(InvisibleCharacterEscape(segmentMatchGroup.Value, false, optShowZeroLengthMatches.Checked));
                }
                if( groupBuilder.Length > 0 ) groupBuilder.Insert(0, string.Format("\r\nGroup{0}:", (segmentMatch.MatchGroups.Count > 1 ? "s" : "")));

                // Add tooltip
                StringBuilder   tooltipBuilder = new StringBuilder();
                string          originalValue = "";
                if( segmentCollection.Operation != Operation.Match ) originalValue = "\r\nOriginal Value:\r\n" + segmentMatch.OriginalValue;
                tooltipBuilder.Append(segmentCollection.OperationName.Singular).Append(" ").Append(segmentMatchNumber.ToString()).Append(originalValue).Append(groupBuilder.ToString());

                // Add result text
                sb.AppendFormat("<span class='match{0}' title='{1}'>", segmentMatchNumber % 2, tooltipBuilder.ToString());
                sb.Append( (segmentMatch.HasZeroLengthPrefix ? InvisibleCharacterEscape(" ", false, optShowZeroLengthMatches.Checked) : "") + HtmlEscape(InvisibleCharacterEscape(segment.Value, true, optShowZeroLengthMatches.Checked)));
                sb.Append("</span>");
            }
            else
            {
                // Add non-result text
                sb.Append(HtmlEscape(segment.Value));
            }                
        }
        return sb.ToString();
    }
        
    private string BuildMatchResultsStatusBar(SegmentCollection segmentCollection)
    {
        // Build status bar text, corresponding to operation and user options
        int      matchCount = segmentCollection.MatchCount;
        int      zeroLengthMatchCount = segmentCollection.ZeroLengthMatchCount;
        string   op = (matchCount == 1 ? segmentCollection.OperationName.Singular : segmentCollection.OperationName.Plural);
        string   hidden = ( (zeroLengthMatchCount > 0) && !optShowZeroLengthMatches.Checked ? " (" + zeroLengthMatchCount.ToString() + " of zero-length)" : "");
        return string.Format("{0} {1}{2}", matchCount, op, hidden);
    }
    
    private void MatchText()
    {
        // Push state into doc w/o changing the dirty bit.
        // Don't want to change the dirty bit just 'cuz we're
        // matching. If any options or text is changed, the dirty
        // bit will already be set anyway.
        // NOTE: The reason we're doing this is that we're keeping
        // the two text fields in the form instead of replicating
        // them into the document until the user saves, matches or replaces.
        ReplicateStateToRegexDoc(false);

        // Show matches
        if( CheckRegex() )
        {
            SegmentCollection   segmentCollection = _doc.MatchAndSegmentRegex(optMultipleMatches.Checked); 
            ShowMatchResultsText(BuildMatchResultsHtml(segmentCollection));
            statusBar.Text = BuildMatchResultsStatusBar(segmentCollection);
            _lastOperation = Operation.Match;
        }
    }
    
    private void ReplaceText()
    {
        // Push state into doc w/o changing the dirty bit.
        ReplicateStateToRegexDoc(false);

        // Show replacements
        if( CheckRegex() )
        {
            SegmentCollection   segmentCollection = _doc.ReplaceAndSegmentRegex(optMultipleMatches.Checked);
            ShowMatchResultsText(BuildMatchResultsHtml(segmentCollection));
            statusBar.Text = BuildMatchResultsStatusBar(segmentCollection);
            _lastOperation = Operation.Replace;
        }
    }

    private void SplitText()
    {
        // Push state into doc w/o changing the dirty bit.
        ReplicateStateToRegexDoc(false);

        // Show splits
        if( CheckRegex() )
        {
            SegmentCollection   segmentCollection = _doc.SplitAndSegmentRegex(optMultipleMatches.Checked); 
            ShowMatchResultsText(BuildMatchResultsHtml(segmentCollection));
            statusBar.Text = BuildMatchResultsStatusBar(segmentCollection);
            _lastOperation = Operation.Split;
        }
    }

    private void ReplayOperation()
    {
        switch( _lastOperation )
        {
            case Operation.Match:
                MatchText();
                break;
                
            case Operation.Replace:
                ReplaceText();
                break;
                
            case Operation.Split:
                SplitText();
                break;
        }
    }
    
    private void GenerateCode()
    {
        // Push state into doc w/o changing the dirty bit.
        ReplicateStateToRegexDoc(false);

        GenerateCodeDialog  dlg = new GenerateCodeDialog();
        dlg.Options = _doc.Options;
        dlg.Expression = _doc.Expression;
        dlg.Input = _doc.Text;
        dlg.Replacement = _doc.Replacement;
        dlg.ShowDialog();
    }
    
    #endregion
    
    #region Document management
    public bool CheckRegex()
    {
        try
        {
            _doc.MatchRegex();
            return true;
        }
        catch( ArgumentException ex )
        {
            MessageBox.Show("The regular expression is not valid:\n\n" + ex.Message, 
                            App.ApplicationName,
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
            return false;
        }    
    }
    
    private void UpdateOption(RegexOptions option, MenuItem item)
    {
        // Toggle option
        if( _doc.Option(option) ) _doc.Options &= ~option;
        else _doc.Options |= option;
        
        // Clear matched text
        ShowMatchResultsText("");
    }

    private bool CompileToAssembly()
    {   
        // Open CompileOptionsForm with some defaults set
        CompileOptionsForm  dlg = new CompileOptionsForm();
        dlg.txtFileName.Text = _doc.AssemblyFileName;
        dlg.txtNamespace.Text = _doc.AssemblyNamespace;
        dlg.txtClass.Text = _doc.AssemblyClass;
        dlg.listProtection.Text = (_doc.AssemblyClassPublic ? "Public" : "Private");
        if( dlg.ShowDialog() != DialogResult.OK ) return false;

        // Try not to affect the dirty bit
        if( _doc.AssemblyFileName != dlg.txtFileName.Text ) _doc.AssemblyFileName = dlg.txtFileName.Text;
        if( _doc.AssemblyNamespace != dlg.txtNamespace.Text ) _doc.AssemblyNamespace = dlg.txtNamespace.Text;
        if( _doc.AssemblyClass != dlg.txtClass.Text ) _doc.AssemblyClass = dlg.txtClass.Text;
        
        bool   assemblyClassPublic = (dlg.listProtection.Text == "Public");
        if( _doc.AssemblyClassPublic != assemblyClassPublic ) _doc.AssemblyClassPublic = assemblyClassPublic;

        // In case we've affected the dirty bit...
        SetTitle();

        // Replicate re and text to match cached in view into doc
        // but don't affect dirty bit for this
        ReplicateStateToRegexDoc(false);
        
        // Compile
        if( !CheckRegex() ) return false;
        return _doc.Compile();
    }

    private void SetTitle()
    {
        // Form title bar
        string   fileName = (_docFileName == null ? "Untitled" : Path.GetFileNameWithoutExtension(_docFileName));
        string   dirty = (_doc.Dirty ? "*" : "");
        string   readOnly = (_doc.ReadOnly ? "[Read-Only]" : "");
        String   title = string.Format(_titleFormat, fileName, dirty, App.ApplicationName, readOnly);
        Text = title;
    }
    
    private void SetDirty()
    {
        SetDirty(true);
    }

    private void SetDirty(bool dirty)
    {
        _doc.Dirty = dirty;
        SetTitle();
    }

    private bool CheckDirty()
    {
        // Check dirty bit
        if( _doc.Dirty )
        {
            DialogResult   res = MessageBox.Show(this, "Save changes?", App.ApplicationName, MessageBoxButtons.YesNoCancel);
            switch( res )
            {
                case DialogResult.Cancel:
                    return false;

                case DialogResult.Yes:
                    return SaveDoc();

                case DialogResult.No:
                    return true;

                default:
                    Debug.Assert(false);
                    return false;
            }
        }
        return true;
    }

    private bool SaveDoc()
    {
        return SaveDoc(false);
    }

    private bool SaveDocAs()
    {
        return SaveDoc(true);
    }

    private bool SaveDoc(bool saveAs)
    {        
        // Get the file name
        string   newFileName = _docFileName;

        // TODO: There must be a lot simpler/cleaner way to do this read-only business
               
        // Provide user input on read-only
        if( _doc.ReadOnly && (_docFileName != null) )
        {
            string   msgWarning = string.Format("{0} is read-only.  To save a copy, click OK, then give the project a new name in the Save As Dialog.", Path.GetFileName(_docFileName));
            MessageBox.Show(msgWarning, App.ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        if( saveAs || (_docFileName == null) || _doc.ReadOnly )
        {            
            DialogResult   res = saveFileDialog.ShowDialog();
            if( res != DialogResult.OK ) return false;
            newFileName = saveFileDialog.FileName;
            
            // Don't continue if file selected is read-only
            // NOTE: SaveAsDialog does not give granular-enough fileprotection, hence 
            //       the following code to prevent saving over a read-only file
            if( File.Exists(newFileName) && (File.GetAttributes(newFileName) & FileAttributes.ReadOnly) == FileAttributes.ReadOnly )
            {
                string   msgErr = string.Format("Can't save read-only file '{0}'.", newFileName);
                MessageBox.Show(msgErr, App.ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }        
        }
        
        // Write the data
        if( !WriteDoc(newFileName) ) return false;

        // Clear dirty bit
        SetDirty(false);

        // Update the view's title
        _docFileName = newFileName;
        _doc.ReadOnly = false;
        SetTitle();
        
        // Add to MRU
        _mru.Add(newFileName);

        // Return success
        return true;
    }

    private bool OpenDoc()
    {
        return OpenDoc(null);
    }

    private void ReplicateStateToRegexDoc(bool affectDirtyBit)
    {
        bool   dirty = _doc.Dirty;
        _doc.Expression = txtRegex.Text;
        _doc.Text = txtTextToMatch.Text;
        _doc.Replacement = txtReplace.Text;
        if( !affectDirtyBit ) _doc.Dirty = dirty;
    }
    
    
    // Let the app at this to open file from command line
    internal bool OpenDoc(string newFileName)
    {
        // Check if we need to save
        if( !CheckDirty() ) return false;

        if( (newFileName == null) || (newFileName.Length == 0) )
        {
            // Get the file to open
            DialogResult   res = openFileDialog.ShowDialog();
            if( res != DialogResult.OK ) return false;

            newFileName = openFileDialog.FileName;
        }

        // Read the data
        if( !ReadDoc(newFileName) ) return false;

        // Show the data
        txtTextToMatch.Text = _doc.Text;
        txtRegex.Text = _doc.Expression;
        txtReplace.Text = _doc.Replacement;

        // Clear dirty bit
        SetDirty(false);

        // Set the title
        _docFileName = newFileName;
        SetTitle();
 
        // Add To MRU
        _mru.Add(newFileName);
               
        // Clear matched text
        ShowMatchResultsText("");
        
        // Set focus on Regular Expression textbox
        txtRegex.Focus();
        
        // Reset Last Operation
        _lastOperation = Operation.None;
        
        // Return success
        return true;
    }

    private bool NewDoc()
    {
        // Check if we need to save
        if( !CheckDirty() ) return false;

        // Reset data
        _doc = new RegexDoc();
        txtRegex.Text = _doc.Expression;
        txtTextToMatch.Text = _doc.Text;
        txtReplace.Text = _doc.Replacement;
        
        ShowMatchResultsText("");

        // Reset UI
        statusBar.Text = "Ready";

        // Clear dirty bit
        SetDirty(false);

        // Set the title
        _docFileName = null;
        SetTitle();

        // Set focus on Regular Expression textbox
        txtRegex.Focus();

        // Reset Last Operation
        _lastOperation = Operation.None;
        
        // Return success
        return true;
    }

    private bool CloseDoc()
    {
        // Since we're not continuing if we close the doc,
        // we only need to check to see if we need to save
        return CheckDirty();
    }

    private bool WriteDoc(string fileName)
    {      
        _doc.Expression = txtRegex.Text;
        _doc.Text = txtTextToMatch.Text;
        _doc.Replacement = txtReplace.Text;

        try
        {
            IFormatter  formatter = new BinaryFormatter();
            Stream      stream = new FileStream(fileName, FileMode.Create, FileAccess.Write);
            formatter.Serialize(stream, _doc);
            stream.Close();
        }
        catch( Exception ex )
        {
            string   msg = string.Format("Can't save file '{0}'.\n\n{1}", Path.GetFileName(fileName), ex.Message);
            MessageBox.Show(msg, App.ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }

        return true;
    }

    private bool ReadDoc(string fileName)
    {
        try
        {
            IFormatter  formatter = new BinaryFormatter();
            Stream      stream = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            _doc = (RegexDoc)formatter.Deserialize(stream);
            _doc.ReadOnly = (File.GetAttributes(fileName) & FileAttributes.ReadOnly) == FileAttributes.ReadOnly;
            stream.Close();
        }
        catch( Exception ex )
        {
            string   msg = string.Format("Can't load file '{0}'.  {1}\n\n{2} will load the default project.", Path.GetFileName(fileName), ex.Message, App.ApplicationName);
            MessageBox.Show(msg, App.ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return false;
        }
        
        return true;
    }
    
    #endregion

    #region Event handlers

    private void MRUClickEventHandler(object sender, System.EventArgs e)
    {
        // Open selected file
        MenuItem   mi = (MenuItem) sender;
        OpenDoc(_mru.GetFileName(mi.Index));
    }
    
    private void cmdMatchText_Click(object sender, System.EventArgs e)
    {
        MatchText();
    }

    private void cmdReplaceText_Click(object sender, System.EventArgs e)
    {
        ReplaceText();
    }
    
    private void cmdSplitText_Click(object sender, System.EventArgs e)
    {
        SplitText();    
    }

    private void cmdGenerateCode_Click(object sender, System.EventArgs e)
    {
        GenerateCode();
    }

    private void MainForm_Load(object sender, System.EventArgs e)
    {
        // Hide form until it's been built
        Visible = false;

        // Have to open after the MRU files have been loaded to play properly with MRU
        // If doc opened and then MRU files are loaded from IsolatedStorage, 
        // The requested doc is removed from the MRU list if not of the IsolatedStorage files, 
        // or is not set to the first position if it is one of the IsolatedStorage files
        
        // Show some sample content, if a filename was not passed as a command-line parameter
        if( _docFileName == null )
        {
            _doc.Expression = txtRegex.Text = "[aeiou]";
            _doc.Text = txtTextToMatch.Text = "the quick brown fox jumped over the lazy dog";
            _doc.AssemblyFileName = "MyRegexFileName.dll";
            _doc.AssemblyClass = "MyRegexClass";
            _doc.AssemblyNamespace = "MyRegexNamespace";
        }
        ShowMatchResultsText("");

        // Set dirty bit and title
        SetDirty(false);
        SetTitle();

        // Show form
        Visible = true; 

        // Set focus on Regular Expression textbox
        txtRegex.Focus();
    }
    
    private void cmdHelpAbout_Click(object sender, System.EventArgs e)
    {
        // Show About dialog
        AboutDialog   dlg = new AboutDialog();
        dlg.ShowDialog();
    }

    private void cmdHelpContents_Click(object sender, System.EventArgs e)
    {
        string  helpPath = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location) + @"\regexdesigner.chm";
        try { Process.Start(helpPath); }
        catch( Exception ex )
        {
            String   s = string.Format("Could not open RegexDesigner.chm.\n\n{0}", ex.Message);
            MessageBox.Show(s, App.ApplicationName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void cmdHelpBuy_Click(object sender, System.EventArgs e)
    {
        Process.Start("http://www.sellsbrothers.com/products/#regexd");
    }

    private void cmdSendFeedback_Click(object sender, System.EventArgs e)
    {
        Process.Start("mailto:support@sellsbrothers.com?subject=Feedback on RegexDesigner.NET");
    }

    private void cmdHelpOnTheWeb_Click(object sender, System.EventArgs e)
    {
        Process.Start("http://www.sellsbrothers.com/products/#regexd");
    }

    private void menuMatch_Popup(object sender, System.EventArgs e)
    {
        optSingleLine.Checked = _doc.Option(RegexOptions.Singleline);
        optCompiled.Checked = _doc.Option(RegexOptions.Compiled);
        optEcmaScript.Checked = _doc.Option(RegexOptions.ECMAScript);
        optExplicitCapture.Checked = _doc.Option(RegexOptions.ExplicitCapture);
        optIgnoreCase.Checked = _doc.Option(RegexOptions.IgnoreCase);
        optIgnorePatternWhitespace.Checked = _doc.Option(RegexOptions.IgnorePatternWhitespace);
        optMultiline.Checked = _doc.Option(RegexOptions.Multiline);
        optRightToLeft.Checked = _doc.Option(RegexOptions.RightToLeft);
    }

    private void cmdFileExit_Click(object sender, System.EventArgs e)
    {
        if( CloseDoc() )
        {
            this.Close();
        }
    }

    private void MainForm_Closing(object sender, System.ComponentModel.CancelEventArgs e)
    {
        if( !CloseDoc() ) e.Cancel = true;
        
        // Save application and user settings
        SaveSettings();
    }

    private void optSingleLine_Click(object sender, System.EventArgs e)
    {
        UpdateOption(RegexOptions.Singleline, (MenuItem)sender);
    }

    private void optCompiled_Click(object sender, System.EventArgs e)
    {
        UpdateOption(RegexOptions.Compiled, (MenuItem)sender);
    }

    private void optEcmaScript_Click(object sender, System.EventArgs e)
    {
        UpdateOption(RegexOptions.ECMAScript, (MenuItem)sender);
    }

    private void optExplicitCapture_Click(object sender, System.EventArgs e)
    {
        UpdateOption(RegexOptions.ExplicitCapture, (MenuItem)sender);
    }

    private void optIgnoreCase_Click(object sender, System.EventArgs e)
    {
        UpdateOption(RegexOptions.IgnoreCase, (MenuItem)sender);
    }

    private void optIgnorePatternWhitespace_Click(object sender, System.EventArgs e)
    {
        UpdateOption(RegexOptions.IgnorePatternWhitespace, (MenuItem)sender);
    }

    private void optMultiline_Click(object sender, System.EventArgs e)
    {
        UpdateOption(RegexOptions.Multiline, (MenuItem)sender);
    }

    private void optRightToLeft_Click(object sender, System.EventArgs e)
    {
        UpdateOption(RegexOptions.RightToLeft, (MenuItem)sender);
    }

    private void optMultipleMatches_Click(object sender, System.EventArgs e)
    {
        // Toggle option
        optMultipleMatches.Checked = !optMultipleMatches.Checked;
        
        // Apply view change
        ReplayOperation();
    }

    private void optShowZeroLengthMatches_Click(object sender, System.EventArgs e)
    {
        // Toggle option
        optShowZeroLengthMatches.Checked = !optShowZeroLengthMatches.Checked;
        
        // Apply view change
        ReplayOperation();
    }
    
    private void txtRegex_TextChanged(object sender, System.EventArgs e)
    {
        SetDirty();
    }
    
    private void txtReplace_TextChanged(object sender, System.EventArgs e)
    {
        SetDirty();
    }

    private void txtTextToMatch_TextChanged(object sender, System.EventArgs e)
    {
        SetDirty();
    }

    private void cmdNew_Click(object sender, System.EventArgs e)
    {
        NewDoc();
    }

    private void cmdOpen_Click(object sender, System.EventArgs e)
    {
        
        OpenDoc();
    }

    private void cmdSave_Click(object sender, System.EventArgs e)
    {
        SaveDoc();
    }

    private void cmdSaveAs_Click(object sender, System.EventArgs e)
    {
        SaveDocAs();
    }

    private void cmdCompileToAssembly_Click(object sender, System.EventArgs e)
    {
        CompileToAssembly();
    }
    
    private void toolBar_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
    {
        if( e.Button == tlbbtnCompileToAssembly ) CompileToAssembly();
        else if( e.Button == tlbbtnNewProject ) NewDoc();
        else if( e.Button == tlbbtnOpenProject ) OpenDoc();
        else if( e.Button == tlbbtnSaveProject ) SaveDoc();
        else if( e.Button == tlbbtnMatchText ) MatchText();
        else if( e.Button == tlbbtnReplaceText ) ReplaceText();
        else if( e.Button == tlbbtnCodeGen) GenerateCode();
        else if( e.Button == tblbtnSplitText) SplitText();
    }
    
    #endregion
}