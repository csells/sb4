// Main.cs: The application's main entry point

using System;
using Microsoft.Win32;
using System.Windows.Forms;
using System.Text;
using System.Resources;
using System.IO;

public class RegexDesigner
{
    static void SetValue(RegistryKey root, string subKey, object keyValue)
    {
        SetValue(root, subKey, keyValue, null);
    }

    static void SetValue(RegistryKey root, string subKey, object keyValue, string valueName)
    {
        bool        hasSubKey = ((subKey != null) && (subKey.Length > 0));
        RegistryKey key = root;

        try
        {
            if( hasSubKey ) key = root.CreateSubKey(subKey);
            key.SetValue(valueName, keyValue);
        }
        finally
        {
            if( hasSubKey && (key != null) ) key.Close();
        }
    }

    static void DeleteKey(RegistryKey root, string subKey)
    {
        if( root.OpenSubKey(subKey) == null ) return;
        root.DeleteSubKeyTree(subKey);
        root.Close();
    }
    
    // Make double-click on a file with our extension launch this app
    // Also, associate doc icon with .REP file
    static void SetExtAssociation(string ext, string progID)
    {
        try
        {
            // Create extension subkey
            SetValue(Registry.ClassesRoot, ext, progID);

            // Create progid subkey
            string          assemblyFullPath = System.Reflection.Assembly.GetExecutingAssembly().Location.Replace("/", @"\");
            StringBuilder   sbShellEntry = new StringBuilder();
            sbShellEntry.AppendFormat("\"{0}\" \"%1\"", assemblyFullPath);
            SetValue(Registry.ClassesRoot, progID + @"\shell\open\command", sbShellEntry.ToString());
            StringBuilder   sbDefaultIconEntry = new StringBuilder();
            sbDefaultIconEntry.AppendFormat("\"{0}\",1", assemblyFullPath);
            SetValue(Registry.ClassesRoot, progID + @"\DefaultIcon", sbDefaultIconEntry.ToString());
            
            // Create application subkey
            SetValue(Registry.ClassesRoot, @"Applications\" + Path.GetFileName(assemblyFullPath), "", "NoOpenWith");
        }
        catch
        {
#if DEBUG
            throw;
#endif
        }
    }

    // Make double-click on a file with our extension launch this app
    static void DeleteExtAssociation(string ext, string progID)
    {
        try
        {
            // Delete extension subkey
            DeleteKey(Registry.ClassesRoot, ext);
            DeleteKey(Registry.ClassesRoot, progID);
        }
        catch
        {
#if DEBUG
            throw;
#endif
        }
    }
    
    [System.STAThread]
    static void Main(string[] args) 
    {
        // Extract command-line args, if any
        string clArgs = "";
        if( args.Length > 0 ) clArgs = args[0];

        // Uninstall?
        if( clArgs.ToLower() == "/uninstall" )
        {
            // Delete file extension and PROGID entries
            DeleteExtAssociation(".rep", App.ApplicationName + ".RegexDesignerProject");
            return;
        }
        
        // Create file extension and PROGID entries (Install or not)
        SetExtAssociation(".rep", App.ApplicationName + ".RegexDesignerProject");
        
        // Install?
        if( clArgs.ToLower() == "/install" ) return;

        // Open the app
        MainForm    mainForm = new MainForm();

        // Open with file?
        if( clArgs.Length > 0 )
        {
            string fileName = clArgs;
            mainForm.OpenDoc(fileName);
        }
        
        // Run app
        Application.Run(mainForm);
    }
}

