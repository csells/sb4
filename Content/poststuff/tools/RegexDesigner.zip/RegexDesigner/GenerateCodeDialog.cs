using System;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.Reflection;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Resources;

public class GenerateCodeDialog : System.Windows.Forms.Form
{
    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.Panel panel2;
    private System.Windows.Forms.Panel panel3;
    private System.Windows.Forms.Panel panel4;
    private System.Windows.Forms.RadioButton rdoMatch;
    private System.Windows.Forms.RadioButton rdoReplace;
    private System.Windows.Forms.RadioButton rdoSplit;
    private System.Windows.Forms.RadioButton rdoCSharp;
    private System.Windows.Forms.RadioButton rdoVB;
    private System.Windows.Forms.Button cmdCopy;
    private System.Windows.Forms.Button cmdClose;
    private System.Windows.Forms.TextBox txtCode;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public RegexOptions Options;
    public string       Expression = "";
    public string       Input = "";
    public string       Replacement = "";
    public string       Split = "";

    private XsltCodeGenerator.Input[]   _csInputs;
    private XsltCodeGenerator.Input[]   _vbInputs;
    
    private int   _controlMargin = 8;

    public GenerateCodeDialog()
    {
        // Required for Windows Form Designer support
        InitializeComponent();
    }

    protected string EncodeNonPrintingCS(string s)
    {
        // TODO: What have I missed?
        return s.Replace("\"", "\"\"").Replace("\r\n", "\" + \"\\r\\n\" + @\"").Replace("\r", "\" + \"\\r\" + @\"").Replace("\n", "\" + \"\\n\" + @\"").Replace("\t", "\" + \"\\t\" + @\"");
    }

    protected string EncodeNonPrintingVB(string s)
    {
        // TODO: What have I missed?
        return s.Replace("\"","\"\"").Replace("\r\n", "\" &amp; Chr(10) &amp; Chr(13) &amp; \"").Replace("\r", "\" &amp; Chr(10) &amp; \"").Replace("\n", "\" &amp; Chr(13) &amp; \"").Replace("\t", "\" &amp; Chr(9) &amp; \"");
    }

    protected override void OnLoad(EventArgs e)
    {
        // Let the base class have its way
        base.OnLoad(e);

        // Set up options
        StringBuilder   options = new StringBuilder();
        foreach( string option in Options.ToString().Split(',') )
        {
            if( options.Length > 0 ) options.Append(" OR ");
            options.Append("RegexOptions.").Append(option.Trim());
        }

        //TODO: Check later (MW Temp Build)

        // Set up inputs
        _csInputs = new XsltCodeGenerator.Input[]
        {
            new XsltCodeGenerator.Input("options",      options.ToString().Replace("OR", "|")),
            new XsltCodeGenerator.Input("expression",   EncodeNonPrintingCS(Expression)),
            new XsltCodeGenerator.Input("input",        Input.Replace("\"", "\"\"")),
            new XsltCodeGenerator.Input("replacement",  EncodeNonPrintingCS(Replacement)),
            new XsltCodeGenerator.Input("split",        EncodeNonPrintingCS(Split)),
            
        };

        _vbInputs = new XsltCodeGenerator.Input[]
        {
            new XsltCodeGenerator.Input("options",      options.ToString().Replace("OR", "Or")),
            new XsltCodeGenerator.Input("expression",   EncodeNonPrintingVB(Expression)),
            new XsltCodeGenerator.Input("input",        Input.Replace("\"", "\"\"")),
            new XsltCodeGenerator.Input("replacement",  EncodeNonPrintingVB(Replacement)),
            new XsltCodeGenerator.Input("split",        EncodeNonPrintingVB(Split)),
        };

        // Show code
        UiGenerateCode();
    }

    protected override void OnResize(EventArgs e)
    {
        // Let the base class have its way
        base.OnResize(e);
        
        // Move buttons accordingly
        cmdClose.Left = panel4.Width - _controlMargin - cmdClose.Width;
        cmdClose.Top = panel4.Height - _controlMargin - cmdClose.Height;
        cmdCopy.Left = cmdClose.Left - _controlMargin - cmdCopy.Width;
        cmdCopy.Top = cmdClose.Top;
    }
    
    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing )
    {
        if( disposing )
        {
            if(components != null)
            {
                components.Dispose();
            }
        }
        base.Dispose( disposing );
    }

//    enum Operation
//    {
//        Match,
//        Replace,
//        Split,
//    }

    enum Language
    {
        CSharp,
        VB,
    }

    string GenerateCode(Operation op, Language lang)
    {
        string              resName = "RegexDesigner.Exemplars." + op.ToString() + lang.ToString() + ".xslt";
        string              template = "";
        using( Stream       stream = GetType().Assembly.GetManifestResourceStream(resName) )
        using( StreamReader reader = new StreamReader(stream) )
        {
            template = reader.ReadToEnd();
        }

        return XsltCodeGenerator.Generate(template, (lang == Language.CSharp ? _csInputs : _vbInputs));
    }

	#region Windows Form Designer generated code
/// <summary>
/// Required method for Designer support - do not modify
/// the contents of this method with the code editor.
/// </summary>
private void InitializeComponent()
{
    System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(GenerateCodeDialog));
    this.rdoMatch = new System.Windows.Forms.RadioButton();
    this.panel1 = new System.Windows.Forms.Panel();
    this.panel3 = new System.Windows.Forms.Panel();
    this.rdoCSharp = new System.Windows.Forms.RadioButton();
    this.rdoVB = new System.Windows.Forms.RadioButton();
    this.panel2 = new System.Windows.Forms.Panel();
    this.rdoReplace = new System.Windows.Forms.RadioButton();
    this.rdoSplit = new System.Windows.Forms.RadioButton();
    this.panel4 = new System.Windows.Forms.Panel();
    this.cmdClose = new System.Windows.Forms.Button();
    this.cmdCopy = new System.Windows.Forms.Button();
    this.txtCode = new System.Windows.Forms.TextBox();
    this.panel1.SuspendLayout();
    this.panel3.SuspendLayout();
    this.panel2.SuspendLayout();
    this.panel4.SuspendLayout();
    this.SuspendLayout();
    // 
    // rdoMatch
    // 
    this.rdoMatch.Appearance = System.Windows.Forms.Appearance.Button;
    this.rdoMatch.Checked = true;
    this.rdoMatch.Location = new System.Drawing.Point(16, 8);
    this.rdoMatch.Name = "rdoMatch";
    this.rdoMatch.Size = new System.Drawing.Size(56, 24);
    this.rdoMatch.TabIndex = 1;
    this.rdoMatch.TabStop = true;
    this.rdoMatch.Text = "Match";
    this.rdoMatch.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
    this.rdoMatch.CheckedChanged += new System.EventHandler(this.rdoMatch_CheckedChanged);
    // 
    // panel1
    // 
    this.panel1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                         this.panel3,
                                                                         this.panel2});
    this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
    this.panel1.Name = "panel1";
    this.panel1.Size = new System.Drawing.Size(560, 40);
    this.panel1.TabIndex = 2;
    // 
    // panel3
    // 
    this.panel3.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                         this.rdoCSharp,
                                                                         this.rdoVB});
    this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
    this.panel3.Location = new System.Drawing.Point(216, 0);
    this.panel3.Name = "panel3";
    this.panel3.Size = new System.Drawing.Size(344, 40);
    this.panel3.TabIndex = 1;
    // 
    // rdoCSharp
    // 
    this.rdoCSharp.Appearance = System.Windows.Forms.Appearance.Button;
    this.rdoCSharp.Checked = true;
    this.rdoCSharp.Location = new System.Drawing.Point(16, 8);
    this.rdoCSharp.Name = "rdoCSharp";
    this.rdoCSharp.Size = new System.Drawing.Size(48, 24);
    this.rdoCSharp.TabIndex = 0;
    this.rdoCSharp.TabStop = true;
    this.rdoCSharp.Text = "C#";
    this.rdoCSharp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
    this.rdoCSharp.CheckedChanged += new System.EventHandler(this.rdoCSharp_CheckedChanged);
    // 
    // rdoVB
    // 
    this.rdoVB.Appearance = System.Windows.Forms.Appearance.Button;
    this.rdoVB.Location = new System.Drawing.Point(72, 8);
    this.rdoVB.Name = "rdoVB";
    this.rdoVB.Size = new System.Drawing.Size(48, 24);
    this.rdoVB.TabIndex = 0;
    this.rdoVB.Text = "VB";
    this.rdoVB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
    this.rdoVB.CheckedChanged += new System.EventHandler(this.rdoVB_CheckedChanged);
    // 
    // panel2
    // 
    this.panel2.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                         this.rdoMatch,
                                                                         this.rdoReplace,
                                                                         this.rdoSplit});
    this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
    this.panel2.Name = "panel2";
    this.panel2.Size = new System.Drawing.Size(216, 40);
    this.panel2.TabIndex = 0;
    // 
    // rdoReplace
    // 
    this.rdoReplace.Appearance = System.Windows.Forms.Appearance.Button;
    this.rdoReplace.Location = new System.Drawing.Point(80, 8);
    this.rdoReplace.Name = "rdoReplace";
    this.rdoReplace.Size = new System.Drawing.Size(56, 24);
    this.rdoReplace.TabIndex = 1;
    this.rdoReplace.Text = "Replace";
    this.rdoReplace.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
    this.rdoReplace.CheckedChanged += new System.EventHandler(this.rdoReplace_CheckedChanged);
    // 
    // rdoSplit
    // 
    this.rdoSplit.Appearance = System.Windows.Forms.Appearance.Button;
    this.rdoSplit.Location = new System.Drawing.Point(144, 8);
    this.rdoSplit.Name = "rdoSplit";
    this.rdoSplit.Size = new System.Drawing.Size(56, 24);
    this.rdoSplit.TabIndex = 1;
    this.rdoSplit.Text = "Split";
    this.rdoSplit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
    // 
    // panel4
    // 
    this.panel4.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                         this.cmdClose,
                                                                         this.cmdCopy});
    this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
    this.panel4.Location = new System.Drawing.Point(0, 342);
    this.panel4.Name = "panel4";
    this.panel4.Size = new System.Drawing.Size(560, 40);
    this.panel4.TabIndex = 3;
    // 
    // cmdClose
    // 
    this.cmdClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
    this.cmdClose.Location = new System.Drawing.Point(476, 9);
    this.cmdClose.Name = "cmdClose";
    this.cmdClose.TabIndex = 1;
    this.cmdClose.Text = "Close";
    this.cmdClose.Click += new System.EventHandler(this.cmdClose_Click);
    // 
    // cmdCopy
    // 
    this.cmdCopy.Location = new System.Drawing.Point(392, 9);
    this.cmdCopy.Name = "cmdCopy";
    this.cmdCopy.TabIndex = 0;
    this.cmdCopy.Text = "Copy";
    this.cmdCopy.Click += new System.EventHandler(this.cmdCopy_Click);
    // 
    // txtCode
    // 
    this.txtCode.Dock = System.Windows.Forms.DockStyle.Fill;
    this.txtCode.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
    this.txtCode.Location = new System.Drawing.Point(0, 40);
    this.txtCode.Multiline = true;
    this.txtCode.Name = "txtCode";
    this.txtCode.ScrollBars = System.Windows.Forms.ScrollBars.Both;
    this.txtCode.Size = new System.Drawing.Size(560, 302);
    this.txtCode.TabIndex = 4;
    this.txtCode.Text = "";
    this.txtCode.WordWrap = false;
    // 
    // GenerateCodeDialog
    // 
    this.AcceptButton = this.cmdCopy;
    this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
    this.CancelButton = this.cmdClose;
    this.ClientSize = new System.Drawing.Size(560, 382);
    this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.txtCode,
                                                                  this.panel4,
                                                                  this.panel1});
    this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
    this.MinimumSize = new System.Drawing.Size(400, 400);
    this.Name = "GenerateCodeDialog";
    this.ShowInTaskbar = false;
    this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
    this.Text = "Generate Code";
    this.panel1.ResumeLayout(false);
    this.panel3.ResumeLayout(false);
    this.panel2.ResumeLayout(false);
    this.panel4.ResumeLayout(false);
    this.ResumeLayout(false);

}
	#endregion

    #region Event Handlers
    void UiGenerateCode()
    {
        Operation   op = (rdoMatch.Checked ? Operation.Match : (rdoReplace.Checked ? Operation.Replace : Operation.Split));
        Language    lang = (rdoCSharp.Checked ? Language.CSharp : Language.VB);
        txtCode.Text = GenerateCode(op, lang);
    }

    private void rdoMatch_CheckedChanged(object sender, System.EventArgs e)
    {
        UiGenerateCode();
    }

    private void rdoReplace_CheckedChanged(object sender, System.EventArgs e)
    {
        UiGenerateCode();
    }

    private void rdoCSharp_CheckedChanged(object sender, System.EventArgs e)
    {
        UiGenerateCode();
    }

    private void rdoVB_CheckedChanged(object sender, System.EventArgs e)
    {
        UiGenerateCode();
    }

    private void cmdClose_Click(object sender, System.EventArgs e)
    {
        Close();
    }

    private void cmdCopy_Click(object sender, System.EventArgs e)
    {
        // Copy to clipboard
        Clipboard.SetDataObject(txtCode.Text, true);
        MessageBox.Show("Code copied to Clipboard", App.ApplicationName);
    }
    #endregion
}