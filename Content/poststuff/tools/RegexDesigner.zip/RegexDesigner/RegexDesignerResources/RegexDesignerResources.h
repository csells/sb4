// RegexDesignerResources.h

#pragma once

using namespace System;

namespace RegexDesignerResources
{
	public __gc class Class1
	{
		// TODO: Add your methods for this class here.
	};
}
