using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Diagnostics; // Process
using System.Text; // Stringbuilder
using System.Reflection; // Assembly details
/// <summary>
/// Application AboutForm
/// </summary>
public class AboutForm : System.Windows.Forms.Form
{
    private System.Windows.Forms.Button btnOK;
    private System.Windows.Forms.Label lblCopyright1;
    private System.Windows.Forms.Label lblCopyright2;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.PictureBox pictureBox1;
    private System.Windows.Forms.Label lblProduct;
    private System.Windows.Forms.Label lblReferencedAssemblies;
    private System.Windows.Forms.Label lblSBSupportEmail;
    private System.Windows.Forms.LinkLabel lnkSBSalesEmail;
    private System.Windows.Forms.LinkLabel lnkSBSupportEmail;
    private System.Windows.Forms.Label lblSBWebsite;
    private System.Windows.Forms.Label lblSBSalesEmail;
    private System.Windows.Forms.LinkLabel lnkSBWebsite;
    private System.Windows.Forms.ListBox lstReferenceAssemblies;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public AboutForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	
	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(AboutForm));
		this.lstReferenceAssemblies = new System.Windows.Forms.ListBox();
		this.groupBox1 = new System.Windows.Forms.GroupBox();
		this.lnkSBSupportEmail = new System.Windows.Forms.LinkLabel();
		this.lblProduct = new System.Windows.Forms.Label();
		this.lnkSBSalesEmail = new System.Windows.Forms.LinkLabel();
		this.lblSBSupportEmail = new System.Windows.Forms.Label();
		this.btnOK = new System.Windows.Forms.Button();
		this.lblSBWebsite = new System.Windows.Forms.Label();
		this.lblReferencedAssemblies = new System.Windows.Forms.Label();
		this.lblSBSalesEmail = new System.Windows.Forms.Label();
		this.lblCopyright1 = new System.Windows.Forms.Label();
		this.lblCopyright2 = new System.Windows.Forms.Label();
		this.pictureBox1 = new System.Windows.Forms.PictureBox();
		this.lnkSBWebsite = new System.Windows.Forms.LinkLabel();
		this.SuspendLayout();
		// 
		// lstReferenceAssemblies
		// 
		this.lstReferenceAssemblies.HorizontalScrollbar = true;
		this.lstReferenceAssemblies.Location = new System.Drawing.Point(105, 70);
		this.lstReferenceAssemblies.Name = "lstReferenceAssemblies";
		this.lstReferenceAssemblies.Size = new System.Drawing.Size(387, 108);
		this.lstReferenceAssemblies.Sorted = true;
		this.lstReferenceAssemblies.TabIndex = 7;
		// 
		// groupBox1
		// 
		this.groupBox1.Location = new System.Drawing.Point(14, 260);
		this.groupBox1.Name = "groupBox1";
		this.groupBox1.Size = new System.Drawing.Size(479, 4);
		this.groupBox1.TabIndex = 3;
		this.groupBox1.TabStop = false;
		this.groupBox1.Text = "groupBox1";
		// 
		// lnkSBSupportEmail
		// 
		this.lnkSBSupportEmail.LinkArea = new System.Windows.Forms.LinkArea(0, 25);
		this.lnkSBSupportEmail.Location = new System.Drawing.Point(153, 213);
		this.lnkSBSupportEmail.Name = "lnkSBSupportEmail";
		this.lnkSBSupportEmail.Size = new System.Drawing.Size(157, 14);
		this.lnkSBSupportEmail.TabIndex = 4;
		this.lnkSBSupportEmail.TabStop = true;
		this.lnkSBSupportEmail.Text = "support@sellsbrothers.com";
		this.lnkSBSupportEmail.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkSBSupportEmail_LinkClicked);
		// 
		// lblProduct
		// 
		this.lblProduct.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
		this.lblProduct.Location = new System.Drawing.Point(104, 10);
		this.lblProduct.Name = "lblProduct";
		this.lblProduct.Size = new System.Drawing.Size(349, 14);
		this.lblProduct.TabIndex = 2;
		this.lblProduct.Text = "{0}";
		// 
		// lnkSBSalesEmail
		// 
		this.lnkSBSalesEmail.Location = new System.Drawing.Point(153, 231);
		this.lnkSBSalesEmail.Name = "lnkSBSalesEmail";
		this.lnkSBSalesEmail.Size = new System.Drawing.Size(157, 14);
		this.lnkSBSalesEmail.TabIndex = 4;
		this.lnkSBSalesEmail.TabStop = true;
		this.lnkSBSalesEmail.Text = "info@sellsbrothers.com";
		this.lnkSBSalesEmail.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkSBSalesEmail_LinkClicked);
		// 
		// lblSBSupportEmail
		// 
		this.lblSBSupportEmail.Location = new System.Drawing.Point(104, 214);
		this.lblSBSupportEmail.Name = "lblSBSupportEmail";
		this.lblSBSupportEmail.Size = new System.Drawing.Size(49, 17);
		this.lblSBSupportEmail.TabIndex = 5;
		this.lblSBSupportEmail.Text = "Support:";
		// 
		// btnOK
		// 
		this.btnOK.CausesValidation = false;
		this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
		this.btnOK.Location = new System.Drawing.Point(409, 275);
		this.btnOK.Name = "btnOK";
		this.btnOK.Size = new System.Drawing.Size(84, 23);
		this.btnOK.TabIndex = 0;
		this.btnOK.Text = "OK";
		// 
		// lblSBWebsite
		// 
		this.lblSBWebsite.Location = new System.Drawing.Point(104, 197);
		this.lblSBWebsite.Name = "lblSBWebsite";
		this.lblSBWebsite.Size = new System.Drawing.Size(37, 11);
		this.lblSBWebsite.TabIndex = 5;
		this.lblSBWebsite.Text = "Web:";
		// 
		// lblReferencedAssemblies
		// 
		this.lblReferencedAssemblies.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
		this.lblReferencedAssemblies.Location = new System.Drawing.Point(104, 55);
		this.lblReferencedAssemblies.Name = "lblReferencedAssemblies";
		this.lblReferencedAssemblies.Size = new System.Drawing.Size(349, 14);
		this.lblReferencedAssemblies.TabIndex = 2;
		this.lblReferencedAssemblies.Text = "Referenced Assemblies:";
		// 
		// lblSBSalesEmail
		// 
		this.lblSBSalesEmail.Location = new System.Drawing.Point(104, 232);
		this.lblSBSalesEmail.Name = "lblSBSalesEmail";
		this.lblSBSalesEmail.Size = new System.Drawing.Size(37, 17);
		this.lblSBSalesEmail.TabIndex = 5;
		this.lblSBSalesEmail.Text = "Sales:";
		// 
		// lblCopyright1
		// 
		this.lblCopyright1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
		this.lblCopyright1.Location = new System.Drawing.Point(104, 24);
		this.lblCopyright1.Name = "lblCopyright1";
		this.lblCopyright1.Size = new System.Drawing.Size(349, 14);
		this.lblCopyright1.TabIndex = 2;
		this.lblCopyright1.Text = "Copyright \u00a9 1996-2002, Sells Brothers, Inc.";
		// 
		// lblCopyright2
		// 
		this.lblCopyright2.Location = new System.Drawing.Point(13, 272);
		this.lblCopyright2.Name = "lblCopyright2";
		this.lblCopyright2.Size = new System.Drawing.Size(394, 95);
		this.lblCopyright2.TabIndex = 2;
		this.lblCopyright2.Text = @"Warning: This computer program is protected by copyright law and international treaties.  Unauthorized reproduction or distribution of this program, or any portion of it, may result in sever civil and criminal penalties, and will be prosecuted to the maximum extent allowed under the law.";
		// 
		// pictureBox1
		// 
		this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
		this.pictureBox1.Image = ((System.Drawing.Bitmap)(resources.GetObject("pictureBox1.Image")));
		this.pictureBox1.Location = new System.Drawing.Point(13, 12);
		this.pictureBox1.Name = "pictureBox1";
		this.pictureBox1.Size = new System.Drawing.Size(78, 232);
		this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.pictureBox1.TabIndex = 6;
		this.pictureBox1.TabStop = false;
		// 
		// lnkSBWebsite
		// 
		this.lnkSBWebsite.Location = new System.Drawing.Point(153, 196);
		this.lnkSBWebsite.Name = "lnkSBWebsite";
		this.lnkSBWebsite.Size = new System.Drawing.Size(157, 14);
		this.lnkSBWebsite.TabIndex = 4;
		this.lnkSBWebsite.TabStop = true;
		this.lnkSBWebsite.Text = "http://www.sellsbrothers.com";
		this.lnkSBWebsite.VisitedLinkColor = System.Drawing.Color.Blue;
		this.lnkSBWebsite.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkSBWebsite_LinkClicked);
		// 
		// AboutForm
		// 
		this.AcceptButton = this.btnOK;
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.CancelButton = this.btnOK;
		this.CausesValidation = false;
		this.ClientSize = new System.Drawing.Size(508, 333);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																	  this.lstReferenceAssemblies,
																	  this.lnkSBSupportEmail,
																	  this.lblSBSupportEmail,
																	  this.pictureBox1,
																	  this.lblSBSalesEmail,
																	  this.lblSBWebsite,
																	  this.lnkSBSalesEmail,
																	  this.lnkSBWebsite,
																	  this.groupBox1,
																	  this.lblCopyright2,
																	  this.lblCopyright1,
																	  this.lblProduct,
																	  this.btnOK,
																	  this.lblReferencedAssemblies});
		this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
		this.MaximizeBox = false;
		this.MinimizeBox = false;
		this.Name = "AboutForm";
		this.ShowInTaskbar = false;
		this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "About {0}";
		this.Load += new System.EventHandler(this.AboutForm_Load);
		this.ResumeLayout(false);

	}
	#endregion

    #region Event Handlers
    private void AboutForm_Load(object sender, System.EventArgs e)
    {
        // Build dialog title
        Text = "About " + App.ApplicationName; // _assembly.GetName().Name;
        
        // Build product label
        lblProduct.Text = App.ApplicationName + " " +  _assembly.GetName().Version.ToString();
        
        // Build referenced assemblies list
        foreach( AssemblyName   assemblyName in _assembly.GetReferencedAssemblies() )
        {
            lstReferenceAssemblies.Items.Add(assemblyName.FullName);
        }
    }
    private void lnkSBWebsite_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
    {
        // Browse to SB website
        Process.Start(lnkSBWebsite.Text);
    }
    private void lnkSBSupportEmail_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
    {
        // Send support email, with system and assembly reference details
        StringBuilder   sb = new StringBuilder();
        sb.Append("mailto:");
        sb.Append(lnkSBSupportEmail.Text);
        sb.AppendFormat("?subject={0}", lblProduct.Text);
        sb.AppendFormat("&body={0}", BuildSupportMailBody());
        Process.Start(sb.ToString());
    }
    private void lnkSBSalesEmail_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
    {
        // Send sales email
        StringBuilder   sb = new StringBuilder();
        sb.Append("mailto:");
        sb.Append(lnkSBSalesEmail.Text);
        sb.AppendFormat("?subject={0}", lblProduct.Text);
        sb.AppendFormat("&body={0}", BuildSalesMailBody());
        Process.Start(sb.ToString());
    }
    #endregion
       
    private string BuildSupportMailBody()
    {
        // Build support mail body, with system details
        StringBuilder   sb = new StringBuilder();
        sb.Append("PROBLEM DESCRIPTION:%0d%0d");
        sb.Append("STEPS TO REPRODUCE:%0d%0d");
        sb.Append("EXPECTED BEHAVIOUR:%0d%0d");
        sb.Append("ACTUAL BEHAVIOUR:%0d%0d%0d");
        sb.Append("SYSTEM DETAILS%0d%0d");
        sb.Append(".NET Framework:%0d%0d");
        sb.Append("Operating System:%0d%0d");
        sb.Append("Machine:%0d%0d");
        sb.Append("Referenced Assemblies:%0d");
        foreach( AssemblyName   assemblyName in _assembly.GetReferencedAssemblies() )
        {
            sb.Append(assemblyName.ToString() + "%0d");
        }
        return sb.ToString();
    }

    private string BuildSalesMailBody()
    {
        return "Sales mail body";
    }
    
    Assembly   _assembly = Assembly.GetExecutingAssembly();
}