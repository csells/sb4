// mdichildren.h

#include "atldlgview.h"

class CHelloMdiChild : public CMdiChildWindowImpl<CHelloMdiChild>
{
public:
    CHelloMdiChild() : m_nColorIndex(0) {}

BEGIN_MSG_MAP(CHelloMdiChild)
    MESSAGE_HANDLER(WM_PAINT, OnPaint)
    MESSAGE_HANDLER(WM_QUERYENDSESSION, OnQueryClose)
    MESSAGE_HANDLER(WM_CLOSE, OnQueryClose)
    COMMAND_ID_HANDLER(IDM_COLOR_BLACK, OnColorChange)
    COMMAND_ID_HANDLER(IDM_COLOR_RED, OnColorChange)
    COMMAND_ID_HANDLER(IDM_COLOR_GREEN, OnColorChange)
    COMMAND_ID_HANDLER(IDM_COLOR_BLUE, OnColorChange)
    COMMAND_ID_HANDLER(IDM_COLOR_WHITE, OnColorChange)
    CHAIN_MSG_MAP(CMdiChildWindowImpl<CHelloMdiChild>)
END_MSG_MAP()

    LRESULT OnPaint(UINT, WPARAM, LPARAM, BOOL&)
    {
        // Paint the window
        PAINTSTRUCT ps;
        HDC         hdc = BeginPaint(&ps);
        
        SetTextColor(hdc, s_rgColors[m_nColorIndex]);

        RECT    rect; GetClientRect(&rect);
        DrawText(hdc, __T("Hello, World!"), -1, &rect, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
        
        EndPaint(&ps);
        return 0;
    }

    LRESULT OnQueryClose(UINT, WPARAM, LPARAM, BOOL& bHandled)
    {
        UINT msg = MessageBox(__T("May I close this window?"), __T("Hello"),  MB_ICONQUESTION | MB_YESNO);

        // If it's OK with the user, let DefMDIChildProc close us
        if( msg == IDYES ) bHandled = FALSE;
        return 0;
    }

    LRESULT OnColorChange(WORD, WORD nCode, HWND, BOOL&)
    {
        m_nColorIndex = nCode - IDM_COLOR_BLACK;
        Invalidate();
        return 0;
    }
    
    void OnFinalMessage(HWND)
    {
        delete this;
    }

private:
    size_t          m_nColorIndex;
    static COLORREF s_rgColors[5];
};

COLORREF    CHelloMdiChild::s_rgColors[] = { RGB (  0,   0,   0),
                                             RGB (255,   0,   0),
                                             RGB (  0, 255,   0),
                                             RGB (  0,   0, 255),
                                             RGB (255, 255, 255), };

class CRectMdiChild : public CMdiChildWindowImpl<CRectMdiChild>
{
public:
    CRectMdiChild() {}

BEGIN_MSG_MAP(CRectMdiChild)
    MESSAGE_HANDLER(WM_CREATE, OnCreate)
    MESSAGE_HANDLER(WM_TIMER, OnTimer)
    MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
    CHAIN_MSG_MAP(CMdiChildWindowImpl<CRectMdiChild>)
END_MSG_MAP()

    LRESULT OnCreate(UINT, WPARAM, LPARAM, BOOL&)
    {
        SetTimer(1, 250);
        return 0;
    }

    LRESULT OnTimer(UINT, WPARAM, LPARAM, BOOL&)
    {
        if( IsIconic() ) return 0;

        RECT    rect; GetClientRect(&rect);
        long    cxClient = rect.right - rect.left;
        long    cyClient = rect.bottom - rect.top;
        long    xLeft    = rand () % (cxClient ? cxClient : 1);
        long    xRight   = rand () % (cxClient ? cxClient : 1);
        long    yTop     = rand () % (cyClient ? cyClient : 1);
        long    yBottom  = rand () % (cyClient ? cyClient : 1);
        long    nRed     = rand () & 255;
        long    nGreen   = rand () & 255;
        long    nBlue    = rand () & 255;
        HDC     hdc = GetDC();
        HBRUSH  hbrush = CreateSolidBrush(RGB (nRed, nGreen, nBlue));

        SelectObject(hdc, hbrush);
        Rectangle(hdc, min(xLeft, xRight), min(yTop, yBottom), max(xLeft, xRight), max(yTop, yBottom));
        ReleaseDC(hdc);
        DeleteObject(hbrush);

        return 0;
    }

    LRESULT OnDestroy(UINT, WPARAM, LPARAM, BOOL&)
    {
        KillTimer(1);
        return 0;
    }

    void OnFinalMessage(HWND)
    {
        delete this;
    }
};

class CMyFormView : public CDialogViewImpl<CMyFormView>
{
public:
    BEGIN_MSG_MAP(CMyFormView)
        CHAIN_MSG_MAP(CDialogViewImpl<CMyFormView>)
    END_MSG_MAP()

    enum { IDD = IDD_DIALOG1 };
};

class CFormMdiChild : public CMdiChildWindowImpl<CFormMdiChild>
{
public:
BEGIN_MSG_MAP(CFormMdiChild)
    MESSAGE_HANDLER(WM_CREATE, OnCreate)
    MESSAGE_HANDLER(WM_SIZE, OnSize)
    CHAIN_MSG_MAP(CMdiChildWindowImpl<CFormMdiChild>)
END_MSG_MAP()

    LRESULT OnCreate(UINT, WPARAM, LPARAM, BOOL&)
    {
        HWND    hwnd = m_view.Create(m_hWnd);
        return (hwnd ? 0 : -1);
    }

    LRESULT OnSize(UINT, WPARAM, LPARAM, BOOL&)
    {
        RECT    rect; GetClientRect(&rect);
        m_view.MoveWindow(&rect);
        return 0;
    }

    void OnFinalMessage(HWND)
    {
        delete this;
    }

    BOOL Translate(MSG* pMsg, HACCEL hAccel = 0)
    {
        return m_view.Translate(pMsg, hAccel);
    }

private:
    CMyFormView m_view;
};
