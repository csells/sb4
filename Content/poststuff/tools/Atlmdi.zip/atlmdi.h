// atlmdi.h: Helpers for building MDI apps in ATL
/////////////////////////////////////////////////////////////////////////////
// Copyright (c) Chris Sells, 1999.
// All rights reserved. No warrenties extended.
/////////////////////////////////////////////////////////////////////////////
// History:
// 6/1/99:  Added support for translator routing to support form views.
// 4/30/99: Initial release.

#pragma once
#ifndef ATLMDI_INC
#define ATLMDI_INC

template <typename Deriving> class CMdiFrameWindow;
class CMdiClientWindow;
class CMdiChildWindow;

class CMdiClientWindow : public CWindow
{
public:
    static LPCTSTR GetWndClassName()
	{
		return _T("MDICLIENT");
	}

	HWND Create(HWND hWndParent, RECT& rcPos, LPCTSTR szWindowName = NULL,
			DWORD dwStyle = 0, DWORD dwExStyle = 0,
			UINT nID = 0, LPVOID lpCreateParam = NULL)
	{
		return CWindow::Create(GetWndClassName(), hWndParent, rcPos, szWindowName, dwStyle, dwExStyle, nID, lpCreateParam);
	}

	HWND Create(HWND hWndParent, LPRECT lpRect = NULL, LPCTSTR szWindowName = NULL,
			DWORD dwStyle = 0, DWORD dwExStyle = 0,
			HMENU hMenu = NULL, LPVOID lpCreateParam = NULL)
	{
		return CWindow::Create(GetWndClassName(), hWndParent, lpRect, szWindowName, dwStyle, dwExStyle, hMenu, lpCreateParam);
	}

    BOOL Translate(MSG* pmsg, HACCEL hAccel = 0)
    {
        HWND hwnd = MdiGetActive();
        if( !hwnd ) return FALSE;

        // Forward message for translation to active MDI child
        return ::SendMessage(hwnd, WM_FORWARDMSG, 0, (LPARAM)pmsg);
    }

    HWND MdiGetActive()
    {
        HWND    hwndChild = (HWND)SendMessage(WM_MDIGETACTIVE);
        if( !::IsWindow(hwndChild) ) return 0;
        return hwndChild;
    }

    void MdiDestroy(HWND hwndChild)
    {
        SendMessage(WM_MDIDESTROY, (WPARAM)hwndChild);
    }

    void MdiTile(UINT flags = MDITILE_VERTICAL | MDITILE_SKIPDISABLED)
    {
        SendMessage(WM_MDITILE, flags);
    }

    void MdiCascade(UINT flags = MDITILE_SKIPDISABLED)
    {
        SendMessage(WM_MDICASCADE, flags);
    }

    void MdiArrange()
    {
        SendMessage(WM_MDIICONARRANGE);
    }

    void MdiCloseAll()
    {
        EnumChildWindows(m_hWnd, CloseEnumProc, 0);
    }

    void MdiMaximize(HWND hwndChild)
    {
        SendMessage(WM_MDIMAXIMIZE, (WPARAM)hwndChild);
    }

    void MdiNext(HWND hwndChild = 0)
    {
        SendMessage(WM_MDINEXT, (WPARAM)(hwndChild ? hwndChild : MdiGetActive()), TRUE);
    }

    void MdiPrevious(HWND hwndChild = 0)
    {
        SendMessage(WM_MDINEXT, (WPARAM)(hwndChild ? hwndChild : MdiGetActive()), FALSE);
    }

    void MdiRefreshMenu()
    {
        SendMessage(WM_MDIREFRESHMENU);
    }

    void MdiRestore(HWND hwndChild)
    {
        SendMessage(WM_MDIRESTORE);
    }

    void MdiSetMenu(HMENU hmenuFrame, HMENU hmenuWindow = 0)
    {
        SendMessage(WM_MDISETMENU, (WPARAM)hmenuFrame, (LPARAM)hmenuWindow);
    }

private:
    static
    BOOL CALLBACK CloseEnumProc(HWND hwnd, LPARAM lParam)
    {
        // Check for icon title
        if( ::GetWindow (hwnd, GW_OWNER) ) return TRUE;
    
        ::SendMessage(::GetParent(hwnd), WM_MDIRESTORE, (WPARAM)hwnd, 0);
        if( !::SendMessage (hwnd, WM_QUERYENDSESSION, 0, 0) ) return TRUE;
        ::SendMessage(::GetParent(hwnd), WM_MDIDESTROY, (WPARAM)hwnd, 0);

        return TRUE;
    }
};

typedef CFrameWinTraits CMdiFrameWinTraits;

template <typename Deriving, typename Base = CWindow, typename Traits = CMdiFrameWinTraits>
class CMdiFrameWindowImpl : public CWindowImpl<Deriving, Base, Traits>
{
public:
    CMdiFrameWindowImpl() : m_hmenu(0) {}

DECLARE_WND_CLASS_EX(0, CS_HREDRAW | CS_VREDRAW, COLOR_APPWORKSPACE)
BEGIN_MSG_MAP(CMdiFrameWindowImpl)
    MESSAGE_HANDLER(WM_CREATE, OnCreate)
    MESSAGE_HANDLER(WM_QUERYENDSESSION, OnQueryClose)
    MESSAGE_HANDLER(WM_CLOSE, OnQueryClose)
    MESSAGE_HANDLER(WM_MDISETMENU, OnMdiSetMenu)
    COMMAND_ID_HANDLER(ID_APP_EXIT, OnAppExit)
    COMMAND_ID_HANDLER(ID_WINDOW_TILE_VERT, OnWindowTile)
    COMMAND_ID_HANDLER(ID_WINDOW_TILE_HORZ, OnWindowTile)
    COMMAND_ID_HANDLER(ID_WINDOW_CASCADE, OnWindowCascade)
    COMMAND_ID_HANDLER(ID_WINDOW_ARRANGE, OnWindowArrange)
    // Let the child handle it, and then pass it along to DefFrameProc
    if( uMsg == WM_COMMAND )
	{
		bHandled = FALSE;
        HWND    hwndChild = m_wndClient.MdiGetActive();
        if( hwndChild ) lResult = SendMessage(hwndChild, uMsg, wParam, lParam);
		if( bHandled ) return TRUE;
	}
END_MSG_MAP()

    LRESULT OnCreate(UINT, WPARAM, LPARAM, BOOL&)
    {
        // Cache our menu
        m_hmenu = GetMenu();

        // Create the client window
        CLIENTCREATESTRUCT client = { 0, MDIFIRSTCHILDID };
        RECT    rect = { 0 };
        HWND    hwndClient = m_wndClient.Create(m_hWnd, rect, 0,
                                                WS_CHILD | WS_CLIPCHILDREN | WS_VISIBLE,
                                                WS_EX_CLIENTEDGE, MDICLIENTID, &client);
        return (hwndClient ? 0 : -1);
    }

    LRESULT OnQueryClose(UINT, WPARAM, LPARAM, BOOL& bHandled)
    {
        // Try to close all the children
        m_wndClient.MdiCloseAll();

        // If we closed all the children, let DefFrameProc close us
        if( m_wndClient.GetWindow(GW_CHILD) == 0 ) bHandled = FALSE;

        return 0;
    }

    LRESULT OnWindowClose(WORD, WORD, HWND, BOOL&)
    {
        // Close the active window
        CWindow wndChild = m_wndClient.MdiGetActive();
        if( wndChild.m_hWnd && wndChild.SendMessage(WM_QUERYENDSESSION) )
        {
            m_wndClient.MdiDestroy(wndChild);
        }

        return 0 ;
    }

    LRESULT OnMdiSetMenu(UINT, WPARAM, LPARAM, BOOL&)
    {
        // When an MDI child window is going away, it will ask us to restore our menu
        m_wndClient.MdiSetMenu(m_hmenu);
        return 0;
    }

    LRESULT OnAppExit(WORD, WORD, HWND, BOOL&)
    {
        SendMessage(WM_CLOSE);
        return 0 ;
    }

    LRESULT OnWindowTile(WORD, WORD nCode, HWND, BOOL&)
    {
        m_wndClient.MdiTile((nCode == ID_WINDOW_TILE_VERT ? MDITILE_VERTICAL : MDITILE_HORIZONTAL) | MDITILE_SKIPDISABLED);
        return 0;
    }

    LRESULT OnWindowCascade(WORD, WORD, HWND, BOOL&)
    {
        m_wndClient.MdiCascade();
        return 0;
    }

    LRESULT OnWindowArrange(WORD, WORD, HWND, BOOL&)
    {
        m_wndClient.MdiArrange();
        return 0;
    }

    LRESULT OnWindowCloseAll(WORD, WORD, HWND, BOOL&)
    {
        m_wndClient.MdiCloseAll();
        return 0;
    }

    LRESULT OnWindowNext(WORD, WORD, HWND, BOOL&)
    {
        m_wndClient.MdiNext();
        return 0;
    }

    LRESULT OnWindowPrevious(WORD, WORD, HWND, BOOL&)
    {
        m_wndClient.MdiPrevious();
        return 0;
    }

    BOOL Translate(MSG* pmsg, HACCEL hAccel = 0)
    {
        if( ::TranslateMDISysAccel(m_wndClient, pmsg) ||
            (hAccel && ::TranslateAccelerator(m_hWnd, hAccel, pmsg)) ||
            m_wndClient.Translate(pmsg) )
        {
            return TRUE;
        }

        return FALSE;
    }

    // Hook up our WndProc instead of the base's
    virtual WNDPROC GetWindowProc()
	{
		return MdiFrameBaseWindowProc;
	}

    // Provide this function merely to bind to our DefWindowProc instead of CWindowImplBaseT
    static LRESULT CALLBACK MdiFrameBaseWindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
    {
        // NOTE: This is the only changed line of code.
        //       The rest is copied from CWindowImplBaseT::WindowProc
	    CMdiFrameWindowImpl*    pThis = (CMdiFrameWindowImpl*)hWnd;

	    // set a ptr to this message and save the old value
	    MSG msg = { pThis->m_hWnd, uMsg, wParam, lParam, 0, { 0, 0 } };
	    const MSG* pOldMsg = pThis->m_pCurrentMsg;
	    pThis->m_pCurrentMsg = &msg;
	    // pass to the message map to process
	    LRESULT lRes;
	    BOOL bRet = pThis->ProcessWindowMessage(pThis->m_hWnd, uMsg, wParam, lParam, lRes, 0);
	    // restore saved value for the current message
	    ATLASSERT(pThis->m_pCurrentMsg == &msg);
	    pThis->m_pCurrentMsg = pOldMsg;
	    // do the default processing if message was not handled
	    if(!bRet)
	    {
		    if(uMsg != WM_NCDESTROY)
			    lRes = pThis->DefWindowProc(uMsg, wParam, lParam);
		    else
		    {
			    // unsubclass, if needed
			    LONG pfnWndProc = ::GetWindowLong(pThis->m_hWnd, GWL_WNDPROC);
			    lRes = pThis->DefWindowProc(uMsg, wParam, lParam);
			    if(pThis->m_pfnSuperWindowProc != ::DefWindowProc && ::GetWindowLong(pThis->m_hWnd, GWL_WNDPROC) == pfnWndProc)
				    ::SetWindowLong(pThis->m_hWnd, GWL_WNDPROC, (LONG)pThis->m_pfnSuperWindowProc);
			    // clear out window handle
			    HWND hWnd = pThis->m_hWnd;
			    pThis->m_hWnd = NULL;
			    // clean up after window is destroyed
			    pThis->OnFinalMessage(hWnd);
		    }
	    }
	    return lRes;
    }

    LRESULT DefWindowProc()
	{
        if( !m_pCurrentMsg ) return 0;
        return DefWindowProc(m_pCurrentMsg->message, m_pCurrentMsg->wParam, m_pCurrentMsg->lParam);
	}

	LRESULT DefWindowProc(UINT msg, WPARAM wp, LPARAM lp)
	{
        return DefFrameProc(m_hWnd, m_wndClient.m_hWnd, msg, wp, lp);
	}

protected:
    enum { MDICLIENTID = 1 , MDIFIRSTCHILDID = 4096 };

    CMdiClientWindow    m_wndClient;
    HMENU               m_hmenu;
};

template <typename TDeriving, typename TBase = CWindow, typename TWinTraits = CMDIChildWinTraits>
class CMdiChildWindowImpl : public CWindowImpl<CMdiChildWindowImpl, TBase, TWinTraits>
{
public:
typedef CMdiChildWindowImpl<TDeriving, TBase, TWinTraits> thisClass;
BEGIN_MSG_MAP(thisClass)
    MESSAGE_HANDLER(WM_FORWARDMSG, OnForwardMsg)
    MESSAGE_HANDLER(WM_MDIACTIVATE, OnMdiActivate)
END_MSG_MAP()

    CMdiChildWindowImpl()
    :   m_hwndClient(0),
        m_hmenu(0)
    {
        // Route unhandled messages to the MDI Child WndProc
        m_pfnSuperWindowProc = DefMDIChildProc;
    }

	HWND Create(HWND hwndMdiClient, RECT& rcPos, LPCTSTR szWindowName = 0,
                DWORD dwStyle = 0, HMENU hmenu = 0, LPARAM lParam = 0)
    {
        m_hwndClient = hwndMdiClient;
        SetMenu(hmenu);

        // We need the class name to fill in the struct,
        // so register it if it hasn't already been registered.
        ATOM atom = TDeriving::GetWndClassInfo().Register(&m_pfnSuperWindowProc);

        // Create a thunk
        _Module.AddCreateWndData(&m_thunk.cd, this);

        MDICREATESTRUCT    mdicreate = { 0 };
        mdicreate.szClass = (LPCTSTR)MAKELONG(atom, 0);
        mdicreate.szTitle = szWindowName;
        mdicreate.hOwner  = _Module.GetResourceInstance();
        mdicreate.x       = rcPos.left;
        mdicreate.y       = rcPos.top;
        mdicreate.cx      = rcPos.right - rcPos.left;
        mdicreate.cy      = rcPos.bottom - rcPos.top;
        mdicreate.lParam  = lParam;
        mdicreate.style   = dwStyle;

        return (HWND)::SendMessage(m_hwndClient, WM_MDICREATE, 0, (LPARAM)&mdicreate);
    }

    LRESULT OnForwardMsg(UINT, WPARAM, LPARAM lParam, BOOL&)
    {
        MSG*    pmsg = (MSG*)lParam;
        _ASSERTE(pmsg);
        return static_cast<TDeriving*>(this)->Translate(pmsg);
    }

    BOOL Translate(MSG* pMsg, HACCEL hAccel = 0)
    {
        return FALSE;
    }

    LRESULT OnMdiActivate(UINT, WPARAM, LPARAM lParam, BOOL&)
    {
        // If we're gaining focus, ask the client to show our menu
        if( ((HWND)lParam == m_hWnd) && m_hmenu )
        {
            ::SendMessage(m_hwndClient, WM_MDISETMENU, (WPARAM)m_hmenu, (LPARAM)m_hmenuWindow);
        }
        // If we're losing focus, ask the frame to restore it's own menu
        else
        {
            ::SendMessage(::GetParent(m_hwndClient), WM_MDISETMENU, 0, 0);
        }
        
        ::DrawMenuBar(::GetParent(m_hwndClient));
        return 0 ;
    }

    HMENU GetMenu()
    {
        return m_hmenu;
    }

    void SetMenu(HMENU hmenu)
    {
        m_hmenu = hmenu;

        // Find the &Window menu so the MDI Client can list all the windows
        if( m_hmenu )
        {
            // The &Window menu is the 2nd to the last menu item (&Help is last)
            int nWindowMenu = GetMenuItemCount(m_hmenu) - 2;
            if( nWindowMenu < 0 ) return;

            const TCHAR     szWindow[] = "&Window";
            const size_t    cchWindow = sizeof(szWindow)/sizeof(*szWindow) - 1;
            TCHAR           szMenuName[cchWindow+1];
            int             ret = GetMenuString(m_hmenu, nWindowMenu, szMenuName, cchWindow + 1, MF_BYPOSITION);
            if( !ret ) return;

            if( CompareString(LOCALE_SYSTEM_DEFAULT, 0, szWindow, cchWindow, szMenuName, -1) == CSTR_EQUAL )
            {
                m_hmenuWindow = GetSubMenu(m_hmenu, nWindowMenu);
            }
        }
    }

private:
    HWND    m_hwndClient;
    HMENU   m_hmenu;
    HMENU   m_hmenuWindow;
};

#endif  // !defined(ATLMDI_INC)
