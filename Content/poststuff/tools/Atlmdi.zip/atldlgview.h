// atldlgview.h: ATL-based Dialog View
// This code was lifted from Dharma Shukla by Chris Sells.
// Copyright (c) 1999, Dharma Shukla. No warranties extended.
/////////////////////////////////////////////////////////////////////////////
// Usage:
// Derive a class from CDialogViewImpl, provide an IDD enum value and a 
// message map, chaining unhandled messages to the base.
/*
class CMyFormView : public CDialogViewImpl<CMyFormView>
{
public:
    BEGIN_MSG_MAP(CMyFormView)
        CHAIN_MSG_MAP(CDialogViewImpl<CMyFormView>)
    END_MSG_MAP()

    enum { IDD = IDD_DIALOG1 };
};

// In either a frame window or an MDI child window, create the form view
// as the child of the parent.

LRESULT MyFrameWnd::OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
    // m_view is of type CMyFormView
    HWND    hwnd = m_view.Create(m_hWnd);
    return (hwnd ? 0 : -1);
}

LRESULT MyFrameWnd::OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
    RECT    rect; GetClientRect(&rect);
    m_view.MoveWindow(&rect);
    return 0;
}

// Also, forward calls from the message loop to the Translate member function of
// the CDialogViewImpl class, e.g.

BOOL MyFrameWnd::Translate(MSG* pMsg, HACCEL hAccel = 0)
{
    return m_view.Translate(pMsg, hAccel);
}

...

int WINAPI WinMain(...)
{
    ...
    MSG     msg;
    while( GetMessage(&msg, 0, 0, 0) )
    {
        if( !wndMain.Translate(&msg) )
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }
}

*/

#pragma once
#ifndef INC_ATLDLGVIEW
#define INC_ATLDLGVIEW

template <typename TDerived, typename TBase = CWindow>
class ATL_NO_VTABLE CDialogViewImpl : public CAxDialogImpl<CDialogViewImpl, TBase>
{
public:
    typedef CDialogViewImpl<TDerived, TBase>        thisClass;
    typedef CAxDialogImpl<CDialogViewImpl, TBase>   theBase;
    
    BEGIN_MSG_MAP(thisClass)
    END_MSG_MAP()
        
public:
    // ATL's AX Create() *as is* for modeless dialogs
    HWND Create(HWND hWndParent, LPARAM dwInitParam = NULL)
    {
        ATLASSERT(m_hWnd == NULL);
        _Module.AddCreateWndData(&m_thunk.cd, (CDialogImplBaseT< TBase >*)this);
        
        HWND hWnd = AtlAxCreateDialog(_Module.GetResourceInstance(), MAKEINTRESOURCE(TDerived::IDD),
                                      hWndParent, (DLGPROC)StartDialogProc, dwInitParam);
        ATLASSERT(m_hWnd == hWnd);
        return hWnd;
    }
    
    // This is blatant copy ATL's PreTranslateAccelerator() minus its *hRet*
    BOOL Translate(MSG* pMsg, HACCEL hAccel=0)
    {
        if ((pMsg->message < WM_KEYFIRST || pMsg->message > WM_KEYLAST) &&
            (pMsg->message < WM_MOUSEFIRST || pMsg->message > WM_MOUSELAST))
            return FALSE;

        // find a direct child of the dialog from the window that has focus
        HWND hWndCtl = ::GetFocus();
        if (IsChild(hWndCtl) && ::GetParent(hWndCtl) != m_hWnd)
        {
            do
            {
                hWndCtl = ::GetParent(hWndCtl);
            }
            while (::GetParent(hWndCtl) != m_hWnd);
        }

        // give controls a chance to translate this message
        if (::SendMessage(hWndCtl, WM_FORWARDMSG, 0, (LPARAM)pMsg) == 1)
            return TRUE;
        
        // special handling for keyboard messages
        switch(pMsg->message)
        {
        case WM_CHAR:
            if(::SendMessage(pMsg->hwnd, WM_GETDLGCODE, 0, 0L) == 0)	// no dlgcode, possibly an ActiveX control
                return FALSE;	// let the container process this
            break;
        case WM_KEYDOWN:
            switch(LOWORD(pMsg->wParam))
            {
            case VK_EXECUTE:
            case VK_RETURN:
            case VK_ESCAPE:
            case VK_CANCEL:
                // we don't want to handle these, let the container do it
                return FALSE;
            }
            break;
        }
        
        return IsDialogMessage(pMsg);
    }
};

#endif  // INC_ATLDLGVIEW
