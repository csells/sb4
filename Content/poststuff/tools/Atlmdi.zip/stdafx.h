// stdafx.h

#include <atlbase.h>
extern CComModule _Module;
#include <atlwin.h>
#include <afxres.h>
#include "atlmdi.h"
#include <atlcom.h>
#include <atlhost.h>
