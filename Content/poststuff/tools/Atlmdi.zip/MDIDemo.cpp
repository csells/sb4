/*--------------------------------------------------------
 MDIDEMO.C -- Multiple-Document Interface Demonstration
 (c) Charles Petzold, 1998
 Modified for ATL by Chris Sells, 1999
 --------------------------------------------------------*/

#include "stdafx.h"
#include "resource.h"
#include "mdichildren.h"

CComModule _Module;

class CMyMdiFrame : public CMdiFrameWindowImpl<CMyMdiFrame>
{
public:
    CMyMdiFrame()
    {
        // Initialize window info
        CWndClassInfo&  wc = GetWndClassInfo();
        if( !wc.m_atom )
        {
            wc.m_wc.hIcon = LoadIcon(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDI_MDIDEMO));
            wc.m_wc.hIconSm = (HICON)::LoadImage(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDI_MDIDEMO), IMAGE_ICON, 16, 16, LR_DEFAULTCOLOR);
        }
    }

typedef CMdiFrameWindowImpl<CMyMdiFrame> baseClass;
BEGIN_MSG_MAP(CMyMdiFrame)
    COMMAND_ID_HANDLER(IDM_FILE_NEWHELLO, OnFileNewHello)
    COMMAND_ID_HANDLER(IDM_FILE_NEWRECT, OnFileNewRect)
    COMMAND_ID_HANDLER(IDM_FILE_NEWFORM, OnFileNewForm)
    COMMAND_ID_HANDLER(ID_APP_EXIT, OnAppExit)
    COMMAND_ID_HANDLER(ID_HELP_ABOUT, OnHelpAbout)
    // All of the rest of standard Window menu items are defined in afxres.h
    // and handled in CMdiFrameWindowImpl. However, these four don't have
    // standard menu item IDs and therefore need to be forwarded manually.
    COMMAND_ID_HANDLER(ID_WINDOW_CLOSE, baseClass::OnWindowClose)
    COMMAND_ID_HANDLER(ID_WINDOW_CLOSEALL, baseClass::OnWindowCloseAll)
    COMMAND_ID_HANDLER(ID_WINDOW_NEXT, baseClass::OnWindowNext)
    COMMAND_ID_HANDLER(ID_WINDOW_PREVIOUS, baseClass::OnWindowPrevious)
    CHAIN_MSG_MAP(baseClass)
END_MSG_MAP()

    LRESULT OnFileNewHello(WORD, WORD, HWND, BOOL&)
    {
        // Create a Hello child window
        static HMENU    hmenu = LoadMenu(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_HELLO));
        CHelloMdiChild* pChild = new CHelloMdiChild;
        pChild->Create(m_wndClient, CWindow::rcDefault, __T("Hello"), 0, hmenu);
        return 0;
    }

    LRESULT OnFileNewRect(WORD, WORD, HWND, BOOL&)
    {
        // Create a Rect child window
        static HMENU    hmenu = LoadMenu(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_RECT));
        CRectMdiChild*  pChild = new CRectMdiChild;
        pChild->Create(m_wndClient, CWindow::rcDefault, __T("Rectangles"), 0, hmenu);
        return 0;
    }

    LRESULT OnFileNewForm(WORD, WORD, HWND, BOOL&)
    {
        // Create a Form child window
        static HMENU    hmenu = LoadMenu(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_FORM));
        CFormMdiChild*  pChild = new CFormMdiChild;
        pChild->Create(m_wndClient, CWindow::rcDefault, __T("Form"), 0, hmenu);
        return 0;
    }

    LRESULT OnHelpAbout(WORD, WORD, HWND, BOOL&)
    {
        MessageBox(__T("A demonstration of an MDI application written in ATL\r\nCopyright (c) Chris Sells, 1999"), __T("ATL MDI Demo"));
        return 0;
    }

    void OnFinalMessage(HWND)
    {
        PostQuitMessage(0);
    }
};

int WINAPI WinMain(HINSTANCE hinst, HINSTANCE, LPSTR pszCommandLine, int nCmdShow)
{
    _Module.Init(0, hinst);
    
    // Create the frame window
    HMENU       hmenuFrame = LoadMenu(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_FRAME));
    CMyMdiFrame wndFrame;
    wndFrame.Create(0, CWindow::rcDefault, __T("ATL MDI Demonstration"), 0, 0, (UINT)hmenuFrame);
    if( !wndFrame.m_hWnd ) return 0;
    
    wndFrame.ShowWindow(nCmdShow) ;
    wndFrame.UpdateWindow();
    
    // Load accelerator table
    HACCEL   hAccel = LoadAccelerators(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_ACCEL));
    
    // Enter the modified message loop
    MSG msg;
    while( GetMessage (&msg, 0, 0, 0) )
    {
        if( !wndFrame.Translate(&msg, hAccel) )
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    _Module.Term();
    return msg.wParam ;
}
