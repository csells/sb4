//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MDIDemo.rc
//
#define IDR_FRAME                       105
#define IDR_HELLO                       106
#define IDR_RECT                        107
#define IDR_ACCEL                       108
#define IDR_FORM                        108
#define IDI_MDIDEMO                     109
#define IDD_DIALOG1                     110
#define IDC_EDIT1                       1000
#define IDC_LIST1                       1001
#define IDC_CALENDAR1                   1002
#define IDM_FILE_NEWHELLO               40001
#define IDM_FILE_NEWRECT                40002
#define IDM_COLOR_BLACK                 40005
#define IDM_COLOR_RED                   40006
#define IDM_COLOR_GREEN                 40007
#define IDM_COLOR_BLUE                  40008
#define IDM_COLOR_WHITE                 40009
#define ID_WINDOW_CLOSEALL              40017
#define ID_WINDOW_CLOSE                 40018
#define ID_WINDOW_NEXT                  40019
#define ID_WINDOW_PREVIOUS              40020
#define ID_HELP_ABOUT                   40021
#define IDM_FILE_NEWFORM                40027

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40028
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
