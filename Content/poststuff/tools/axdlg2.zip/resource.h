//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by dlgonly.rc
//
#define ID_HELP_ABOUT                   101
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDD_DLGONLY                     103
#define ID_FILE_EXIT                    105
#define IDI_DLGONLY                     107
#define IDI_SMALL                       108
#define IDC_DLGONLY                     109
#define IDR_DLGONLY                     109
#define IDC_CALENDAR1                   1000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
