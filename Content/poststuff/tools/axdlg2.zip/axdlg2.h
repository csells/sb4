// axdlg2.h: CAxDialogImpl2
/////////////////////////////////////////////////////////////////////////////
// Fake Modal dialog - enables you to create modal dialog still
// getting a chance to handle kbd as the dialog is modeless and fakes
// a modal loop.
// Built by Dharma Shukla (IUnknown2k@hotmail.com), 5/29/99 to
// provide better keyboard handling than CAxDIalogImpl when containing
// ActiveX Controls.
/////////////////////////////////////////////////////////////////////////////
// Usage: Use as base class instead of CAxDialogImpl.

template <class T, class TBase = CWindow>
class ATL_NO_VTABLE CAxDialogImpl2 : public CAxDialogImpl<T,TBase>
{
public:
    int DoModal(HWND hWndParent = ::GetActiveWindow(), LPARAM dwInitParam = NULL)
    {
        ATLASSERT(m_hWnd == NULL);
        _Module.AddCreateWndData(&m_thunk.cd, (CDialogImplBaseT< TBase >*)
            this);
        
        // Save original focus/etc.
        HWND hwndWithFocus = GetFocus();
        
        //Create the modeless dialog
        HWND hWnd = AtlAxCreateDialog(_Module.GetResourceInstance(),
                                      MAKEINTRESOURCE(T::IDD),  hWndParent,
                                      (DLGPROC)T::StartDialogProc, dwInitParam);
        ATLASSERT(m_hWnd == hWnd);
        ShowWindow(SW_SHOW);    // In case WS_VISIBLE is not set
        
        HWND hWndOwner = hWndParent;
        if (hWndOwner) //disable the owner
        {
            while (::GetWindowLong(hWndOwner, GWL_STYLE) & WS_CHILD)
                hWndOwner = ::GetParent(hWndOwner);
            if (::EnableWindow(hWndOwner, FALSE))
                hWndOwner = NULL;
        }
        
        MSG msg;//now its time to Spin the fake modal loop
        while (m_hWnd && ::GetMessage(&msg, 0, 0, 0))
        {
            T* pT = static_cast<T*>(this);
            if(pT->Translate(&msg) ){ continue; }
            ::TranslateMessage(&msg);
            ::DispatchMessage(&msg);
        }
        if (hWndOwner)//enable the owner
            ::EnableWindow(hWndOwner, TRUE);
        if (::IsWindow(hwndWithFocus)) //restore the focus back
            ::SetFocus(hwndWithFocus);
        
        if(msg.message == WM_QUIT)
            PostQuitMessage(msg.wParam);
        if(m_hWnd)
            EndDialog(0);//calls our version
        return 0;
    }
    BOOL EndDialog(int nRetCode)
    {
        ATLASSERT(::IsWindow(m_hWnd));
        return DestroyWindow();
    }
    
    //minimal version of PTAcc() of ATL
    //derived class may override this
    BOOL Translate(MSG* pMsg,HACCEL hAccel=0)
    {
        if ((pMsg->message < WM_KEYFIRST || pMsg->message > WM_KEYLAST) &&
            (pMsg->message < WM_MOUSEFIRST || pMsg->message > WM_MOUSELAST))
            return FALSE;
        
        // find a direct child of the dialog from the window that has focus
        HWND hWndCtl = ::GetFocus();
        if (IsChild(hWndCtl) && ::GetParent(hWndCtl) != m_hWnd)
        {
            do
            {
                hWndCtl = ::GetParent(hWndCtl);
            }
            while (::GetParent(hWndCtl) != m_hWnd);
        }
        // give AX controls a chance to translate this message
        if (::SendMessage(hWndCtl, WM_FORWARDMSG, 0, (LPARAM)pMsg) == 1)
            return TRUE;
        return IsDialogMessage(pMsg);
    }
};
