// CsvFileTest: From ms-help://MS.VSCC.2003/MS.MSDNQTR.2003APR.1033/enu_kbvbwin/vbwin/187670.htm

#region Copyright (c) 2003, Sells Brothers, Inc.
// Copyright � 2003 Sells Brothers, Inc.
// This software is provided 'as-is', without any express or implied warranty. In no event will the authors be held liable for any damages arising from the use of this software.
// Permission is granted to anyone to use this software for any purpose, including commercial applications.
#endregion

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.Odbc;
using System.IO;
using System.Data.OleDb;

namespace CsvFileTest {
  /// <summary>
  /// Summary description for Form1.
  /// </summary>
  public class MainForm : System.Windows.Forms.Form {
    System.Windows.Forms.DataGrid dataGrid;
    System.Windows.Forms.TextBox folderTextBox;
    System.Windows.Forms.Panel panel1;
    System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
    System.Windows.Forms.ComboBox queryComboBox;
    System.Windows.Forms.Button browseButton;
    System.Windows.Forms.Button goButton;
    System.Windows.Forms.Button aboutButton;
    System.Windows.Forms.Label label1;
    System.Windows.Forms.Label label2;
    System.Windows.Forms.StatusBar statusBar;

    /// <summary>
    /// Required designer variable.
    /// </summary>
    System.ComponentModel.Container components = null;

    public MainForm() {
      // Required for Windows Form Designer support
      InitializeComponent();

      // Add any constructor code after InitializeComponent call
      string exeFolder = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);
      folderTextBox.Text = exeFolder;
      queryComboBox.SelectedIndex = 0;
      queryComboBox.Items.Add("select * from `" + exeFolder + "`\\test.csv");
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if (disposing) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    void InitializeComponent() {
      this.dataGrid = new System.Windows.Forms.DataGrid();
      this.folderTextBox = new System.Windows.Forms.TextBox();
      this.browseButton = new System.Windows.Forms.Button();
      this.goButton = new System.Windows.Forms.Button();
      this.panel1 = new System.Windows.Forms.Panel();
      this.label2 = new System.Windows.Forms.Label();
      this.label1 = new System.Windows.Forms.Label();
      this.queryComboBox = new System.Windows.Forms.ComboBox();
      this.aboutButton = new System.Windows.Forms.Button();
      this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
      this.statusBar = new System.Windows.Forms.StatusBar();
      ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
      this.panel1.SuspendLayout();
      this.SuspendLayout();
      // 
      // dataGrid
      // 
      this.dataGrid.CaptionVisible = false;
      this.dataGrid.DataMember = "";
      this.dataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dataGrid.Location = new System.Drawing.Point(0, 92);
      this.dataGrid.Name = "dataGrid";
      this.dataGrid.Size = new System.Drawing.Size(552, 234);
      this.dataGrid.TabIndex = 1;
      // 
      // folderTextBox
      // 
      this.folderTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.folderTextBox.Location = new System.Drawing.Point(125, 18);
      this.folderTextBox.Name = "folderTextBox";
      this.folderTextBox.Size = new System.Drawing.Size(331, 22);
      this.folderTextBox.TabIndex = 1;
      // 
      // browseButton
      // 
      this.browseButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.browseButton.Location = new System.Drawing.Point(466, 18);
      this.browseButton.Name = "browseButton";
      this.browseButton.Size = new System.Drawing.Size(29, 27);
      this.browseButton.TabIndex = 2;
      this.browseButton.Text = "&...";
      this.browseButton.Click += new System.EventHandler(this.browseButton_Click);
      // 
      // goButton
      // 
      this.goButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.goButton.Location = new System.Drawing.Point(514, 55);
      this.goButton.Name = "goButton";
      this.goButton.Size = new System.Drawing.Size(29, 27);
      this.goButton.TabIndex = 6;
      this.goButton.Text = "&!";
      this.goButton.Click += new System.EventHandler(this.goButton_Click);
      // 
      // panel1
      // 
      this.panel1.Controls.Add(this.label2);
      this.panel1.Controls.Add(this.label1);
      this.panel1.Controls.Add(this.queryComboBox);
      this.panel1.Controls.Add(this.folderTextBox);
      this.panel1.Controls.Add(this.browseButton);
      this.panel1.Controls.Add(this.goButton);
      this.panel1.Controls.Add(this.aboutButton);
      this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
      this.panel1.Location = new System.Drawing.Point(0, 0);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(552, 92);
      this.panel1.TabIndex = 0;
      // 
      // label2
      // 
      this.label2.Location = new System.Drawing.Point(10, 55);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(105, 27);
      this.label2.TabIndex = 4;
      this.label2.Text = "JET &Query";
      this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(10, 18);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(105, 27);
      this.label1.TabIndex = 0;
      this.label1.Text = "CSV &File Folder";
      this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // queryComboBox
      // 
      this.queryComboBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.queryComboBox.Items.AddRange(new object[] {
            "select * from [test.csv]",
            "select Item, Time, Date, Cost, Price, Extension, Profit from [test.csv]",
            "select Extension + Profit from [test.csv]",
            "select Extension + Profit as ExtensionProfit from [test.csv]",
            "select Extension + Profit as ExtensionProfit from [test.csv] order by Extension +" +
                " Profit desc",
            "select Item, Cost, Price, Profit from [test.csv] where Profit >= 200",
            "select Item, Cost, Price, Profit from [test.csv] where Profit >= 200 order by Ite" +
                "m",
            "select item, iif(date is null, \'no date\', date) as checked_date from [test.csv]",
            "select CStr(Time) as string_time from [test.csv]",
            "select test.Item, test2.ItemCode, test.Cost from [test.csv] as test inner join [t" +
                "est2.csv] as test2 on test.Item = test2.Item"});
      this.queryComboBox.Location = new System.Drawing.Point(125, 55);
      this.queryComboBox.Name = "queryComboBox";
      this.queryComboBox.Size = new System.Drawing.Size(370, 24);
      this.queryComboBox.TabIndex = 5;
      // 
      // aboutButton
      // 
      this.aboutButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.aboutButton.Location = new System.Drawing.Point(514, 18);
      this.aboutButton.Name = "aboutButton";
      this.aboutButton.Size = new System.Drawing.Size(29, 27);
      this.aboutButton.TabIndex = 3;
      this.aboutButton.Text = "&?";
      this.aboutButton.Click += new System.EventHandler(this.aboutButton_Click);
      // 
      // statusBar
      // 
      this.statusBar.Location = new System.Drawing.Point(0, 301);
      this.statusBar.Name = "statusBar";
      this.statusBar.Size = new System.Drawing.Size(552, 25);
      this.statusBar.TabIndex = 2;
      this.statusBar.Text = "Ready";
      // 
      // MainForm
      // 
      this.AcceptButton = this.goButton;
      this.AutoScaleBaseSize = new System.Drawing.Size(6, 15);
      this.ClientSize = new System.Drawing.Size(552, 326);
      this.Controls.Add(this.statusBar);
      this.Controls.Add(this.dataGrid);
      this.Controls.Add(this.panel1);
      this.Name = "MainForm";
      this.Text = "Comma Separated Values File Tester";
      ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
      this.panel1.ResumeLayout(false);
      this.panel1.PerformLayout();
      this.ResumeLayout(false);

    }
    #endregion

    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main() {
      Application.Run(new MainForm());
    }

    void browseButton_Click(object sender, System.EventArgs e) {
      if (folderBrowserDialog.ShowDialog(this) == DialogResult.OK) {
        folderTextBox.Text = folderBrowserDialog.SelectedPath;
      }
    }

    void goButton_Click(object sender, System.EventArgs e) {
      //// Set the Connection String
      //string connStr = @"Driver={Microsoft Access Text Driver (*.txt; *.csv)};" +
      //  "Dbq=" + folderTextBox.Text + ";";

      //// Get all Table Names
      //OdbcConnection conn = new OdbcConnection(connStr);

      //// Read it
      //OdbcDataAdapter da = new OdbcDataAdapter(queryComboBox.Text, conn);
      try {
        //DataSet ds = new DataSet();
        //da.Fill(ds);
        //dataGrid.DataSource = ds.Tables[0];
        //statusBar.Text = ds.Tables[0].Rows.Count.ToString() + " row(s) returned";
        DataTable table = GetRowsFromCsvFile(folderTextBox.Text, queryComboBox.Text);
        dataGrid.DataSource = table;
        statusBar.Text = table.Rows.Count.ToString() + " row(s) returned";
      }
      //catch (OdbcException ex) {
      catch (OleDbException ex) {
        statusBar.Text = "Ready";
        string msg = ex.Message;
        string errors = "";
        //foreach (OdbcError err in ex.Errors) {
        foreach (OleDbError err in ex.Errors) {
          errors += err.Message;
        }
        MessageBox.Show(errors, msg);
      }
    }

    static DataTable GetRowsFromCsvFile(string folder, string query) {
      string connString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=\"{0}\"; Extended Properties='text;HDR=Yes;FMT=Delimited(,)';", folder);
      using (var conn = new OleDbConnection(connString)) {
        using (OleDbCommand cmd = new OleDbCommand(query, conn)) {
          conn.Open();
          using (OleDbDataAdapter adp = new OleDbDataAdapter(cmd)) {
            DataTable table = new DataTable();
            adp.Fill(table);
            return table;
          }
        }
      }
    }


    void aboutButton_Click(object sender, System.EventArgs e) {
      MessageBox.Show(this, "A query tester for CSV files.\r\nCopyright (c) 2003-2010, Sells Brothers, Inc.\r\nComments to csells@sellsbrothers.com.", "About CsvFileTester");
    }
  }
}
