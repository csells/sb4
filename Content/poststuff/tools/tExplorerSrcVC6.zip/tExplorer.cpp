// tExplorer.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "tExplorer.h"

#include "MainFrm.h"
#include "about.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTExplorerApp

BEGIN_MESSAGE_MAP(CTExplorerApp, CWinApp)
    //{{AFX_MSG_MAP(CTExplorerApp)
    ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTExplorerApp construction

CTExplorerApp::CTExplorerApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CTExplorerApp object

CTExplorerApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CTExplorerApp initialization

BOOL CTExplorerApp::InitInstance()
{
    // Standard initialization
	LoadStdProfileSettings(0);  // Load standard INI file options (including MRU)

    CMainFrame* pFrame = new CMainFrame;
    m_pMainWnd = pFrame;

    // create and load the frame with its resources

    pFrame->LoadFrame(IDR_MAINFRAME,
        WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE, NULL,
        NULL);

    pFrame->ShowWindow(SW_SHOW);
    pFrame->UpdateWindow();

    return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CTExplorerApp commands

// App command to run the dialog
void CTExplorerApp::OnAppAbout()
{
    CAboutDlg aboutDlg;
    aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CTExplorerApp message handlers
