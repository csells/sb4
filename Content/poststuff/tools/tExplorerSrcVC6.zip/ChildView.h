// ChildView.h : interface of the CChildView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CHILDVIEW_H__D21FDEC4_07BA_4369_BA55_97B284DC0888__INCLUDED_)
#define AFX_CHILDVIEW_H__D21FDEC4_07BA_4369_BA55_97B284DC0888__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FlagMap.h"

/////////////////////////////////////////////////////////////////////////////
// CChildView window

class CChildView : public CTreeView, public CtAppSink
{
// Construction
public:
	CChildView();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChildView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual void PostNcDestroy();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CChildView();

// App-level telephony events
protected:
    virtual void    OnLineCreate(DWORD nDeviceID);
    virtual void    OnPhoneCreate(DWORD nDeviceID);

	// Generated message map functions
protected:
	//{{AFX_MSG(CChildView)
	afx_msg void OnFileRefresh();
	afx_msg void OnUpdateLoVersion(CCmdUI* pCmdUI);
	afx_msg void OnUpdateHiVersion(CCmdUI* pCmdUI);
	afx_msg void OnHelpFeedback();
	afx_msg void OnHelpWeb();
	afx_msg void OnHelpContents();
	afx_msg void OnHelpBuy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	BOOL    m_bTapiInRegistry;
    CString m_sLoFormat;
    CString m_sHiFormat;

private:
    void    GotoUrl(LPCTSTR pszUrl);

    void    TapiInit();
    void    TapiShutdown();

    void    AddCallsForAllLines(HTREEITEM hRoot);
    void    AddCalls(CtLine* pLine, const CtCallList& lcl, DWORD* pnCallIndex, HTREEITEM hRoot);
    void    AddCallStatus(const CtCallStatus& status, HTREEITEM hRoot);
    void    AddCallInfo(const CtCallInfo& info, HTREEITEM hRoot);

	void    AddDialParams(LPLINEDIALPARAMS pldp, HTREEITEM hRoot);
    void    AddCallTreatment(DWORD dwCallTreatmentID, LPCSTR pszCallTreatmentName, HTREEITEM hRoot);
	void    AddLineDevCaps(const CtLineDevCaps& ldc, HTREEITEM hRoot);
    void    AddTerminals(const CtLineDevCaps& ldc, HTREEITEM hRoot);
	void    AddAddresses(DWORD nLineID, DWORD nAddrs, HTREEITEM hRoot);
	void    AddLines(HTREEITEM hRoot);
    void    AddAddressCaps(const CtAddressCaps& ac, HTREEITEM hRoot);
    void    AddCompletionMessages(const CtAddressCaps& ac, HTREEITEM hRoot);
    void    AddLineDevice(const CtLine& line, const char* pszDeviceClass, HTREEITEM hRoot);
    void    AddLineDeviceClasses(DWORD nLineID, const CtLineDevCaps& ldc, HTREEITEM hRoot);

    void    AddProviders(const CtProviderList& lpl, HTREEITEM hRoot);
    void    AddPriorities(HTREEITEM hRoot);
    void    AddLocations(const CtTranslateCaps& tc, HTREEITEM hRoot);
    void    AddCards(const CtTranslateCaps& tc, HTREEITEM hRoot);
    void    AddCountries(const CtCountryList& lcl, HTREEITEM hRoot);

    void    AddPhones(HTREEITEM hRoot);
    void    AddPhoneCaps(const CtPhoneCaps& pc, HTREEITEM hRoot);

    void    AddFlag(DWORD dwFlag, FlagMap aFlags[], LPCSTR szTag, HTREEITEM hRoot);
    void    AddFlags(DWORD dwFlags, FlagMap aFlags[], LPCSTR szTag, HTREEITEM hRoot);
    void    AddScalar(DWORD dwFlag, FlagMap aFlags[], LPCSTR szTag, HTREEITEM hRoot);

    void    GetTapiInfo();
    void    RefreshTapiInfo();

    HTREEITEM   InsertItem(LPCSTR szItem, HTREEITEM hRoot);
    HTREEITEM   InsertError(LPCSTR sz, HTREEITEM hRoot);
    HTREEITEM   InsertString(LPCSTR sz, LPCSTR szTag, HTREEITEM hRoot, LPCSTR szParen = 0);
    HTREEITEM   InsertNumber(DWORD n, LPCSTR szTag, HTREEITEM hRoot, LPCSTR szParen = 0);
    HTREEITEM   InsertHexNumber(DWORD n, LPCSTR szTag, HTREEITEM hRoot, LPCSTR szParen = 0);
    HTREEITEM   InsertGuid(const GUID& guid, LPCSTR szTag, HTREEITEM hRoot);

    DWORD   GetTapiNumber(LPCSTR szSection, LPCSTR szKey, DWORD nDefault = 0);
    LPCSTR  GetTapiString(LPCSTR szSection, LPCSTR szKey, LPCSTR szDefault = "");
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHILDVIEW_H__D21FDEC4_07BA_4369_BA55_97B284DC0888__INCLUDED_)
