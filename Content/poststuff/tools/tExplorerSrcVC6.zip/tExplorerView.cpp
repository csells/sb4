// tExplorerView.cpp : implementation of the CTExplorerView class
//

#include "stdafx.h"
#include "tExplorer.h"
#include "tExplorerDoc.h"
#include "tExplorerView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// For use when TAPI configuration is stored in the Registry
LPCSTR  g_pszTapiKey = "Software\\Microsoft\\Windows\\CurrentVersion\\Telephony";

// For use when TAPI configuration is stored in TELPHON.INI
LPCSTR  g_pszTapiIni = "telephon.ini";

/////////////////////////////////////////////////////////////////////////////
// CTExplorerView

IMPLEMENT_DYNCREATE(CTExplorerView, CTreeView)

BEGIN_MESSAGE_MAP(CTExplorerView, CTreeView)
	//{{AFX_MSG_MAP(CTExplorerView)
	ON_COMMAND(ID_FILE_REFRESH, OnFileRefresh)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTExplorerView construction/destruction

CTExplorerView::CTExplorerView()
{
    ::TfxLineInitialize(this);
    ::TfxPhoneInitialize(this);
}

CTExplorerView::~CTExplorerView()
{
    ::TfxLineShutdown();
    ::TfxPhoneShutdown();
}

BOOL CTExplorerView::PreCreateWindow(CREATESTRUCT& cs)
{
    cs.style |= TVS_HASLINES | TVS_HASBUTTONS | TVS_LINESATROOT;
	return CTreeView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTExplorerView drawing

void CTExplorerView::OnDraw(CDC* pDC)
{
	CTExplorerDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
}

void CTExplorerView::OnInitialUpdate()
{
	CTreeView::OnInitialUpdate();

    HKEY    hkey;
    if( ::RegOpenKey(HKEY_CURRENT_USER, g_pszTapiKey, &hkey) == ERROR_SUCCESS )
    {
        m_bTapiInRegistry = TRUE;
        ::RegCloseKey(hkey);
    }
    else
    {
        m_bTapiInRegistry = FALSE;
    }

    GetTapiInfo();
}

HTREEITEM CTExplorerView::InsertItem(LPCSTR g_szItem, HTREEITEM hParent)
{
    return GetTreeCtrl().InsertItem(g_szItem, hParent);
}

/////////////////////////////////////////////////////////////////////////////
// CTExplorerView diagnostics

#ifdef _DEBUG
void CTExplorerView::AssertValid() const
{
	CTreeView::AssertValid();
}

void CTExplorerView::Dump(CDumpContext& dc) const
{
	CTreeView::Dump(dc);
}

CTExplorerDoc* CTExplorerView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTExplorerDoc)));
	return (CTExplorerDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTExplorerView message handlers

void CTExplorerView::OnLineCreate(DWORD nDeviceID)
{
    CString sMsg;
    sMsg.Format("Line created: %lu", nDeviceID);
    MessageBox(sMsg);
    RefreshTapiInfo();
}

void CTExplorerView::OnPhoneCreate(DWORD nDeviceID)
{
    CString sMsg;
    sMsg.Format("Phone created: %lu", nDeviceID);
    MessageBox(sMsg);
    RefreshTapiInfo();
}

// Temporary use tree item buffer
static char g_szItem[256];

// Temporary use profile key and entry buffers
static char g_szKey[128];
static char g_szValue[128];

HTREEITEM CTExplorerView::InsertString(LPCSTR sz, LPCSTR szTag, HTREEITEM hRoot, LPCSTR szParen)
{
    ASSERT(szTag && *szTag);
    ASSERT(hRoot);

    if( szParen )
    {
        ::wsprintf(g_szItem, "%s: %s (%s)", szTag, (sz && *sz ? sz : "<None>"), szParen);
    }
    else
    {
        ::wsprintf(g_szItem, "%s: %s", szTag, (sz && *sz ? sz : "<None>"));
    }
    return InsertItem(g_szItem, hRoot);
}

HTREEITEM CTExplorerView::InsertNumber(DWORD n, LPCSTR szTag, HTREEITEM hRoot, LPCSTR szParen)
{
    ASSERT(hRoot);

    if( szParen )
    {
        ::wsprintf(g_szItem, "%s: %lu (%s)", szTag, n, szParen);
    }
    else
    {
        ::wsprintf(g_szItem, "%s: %lu", szTag, n);
    }
    return InsertItem(g_szItem, hRoot);
}

// InsertHexNumber (and it's uses) was contributed by Olaf Brandt [olaf@shoretel.com]
HTREEITEM CTExplorerView::InsertHexNumber(DWORD n, LPCSTR szTag, HTREEITEM hRoot, LPCSTR szParen)
{
    ASSERT(hRoot);

    if( szParen )
    {
        ::wsprintf(g_szItem, "%s: 0x%08X (%s)", szTag, n, szParen);
    }
    else
    {
        ::wsprintf(g_szItem, "%s: 0x%08X", szTag, n);
    }
    return InsertItem(g_szItem, hRoot);
}

DWORD CTExplorerView::GetTapiNumber(LPCSTR szSection, LPCSTR szKey, DWORD nDefault)
{
    DWORD   n = 0;
    
    if( m_bTapiInRegistry )
    {
        char    szRegKey[256];
        ::wsprintf(szRegKey, "%s\\%s", g_pszTapiKey, szSection);
        
        HKEY    hkey;
        if( ::RegOpenKey(HKEY_CURRENT_USER, szRegKey, &hkey) == ERROR_SUCCESS )
        {
            DWORD   nType = REG_DWORD;
            DWORD   nSize = sizeof(n);
            ::RegQueryValueEx(hkey, szKey, 0, &nType, (LPBYTE)&n, &nSize);
            ::RegCloseKey(hkey);
        }
    }
    else
    {
        n = ::GetPrivateProfileInt(szSection, szKey, nDefault, g_pszTapiIni);
    }
    return n;
}

LPCSTR CTExplorerView::GetTapiString(LPCSTR szSection, LPCSTR szKey, LPCSTR szDefault)
{
    *g_szValue = 0;

    if( m_bTapiInRegistry )
    {
        char    szRegKey[256];
        ::wsprintf(szRegKey, "%s\\%s", g_pszTapiKey, szSection);
        
        HKEY    hkey;
        if( ::RegOpenKey(HKEY_CURRENT_USER, szRegKey, &hkey) == ERROR_SUCCESS )
        {
            DWORD   nType = REG_SZ;
            DWORD   nSize = sizeof(g_szValue);
            ::RegQueryValueEx(hkey, szKey, 0, &nType, (LPBYTE)&g_szValue, &nSize);
            ::RegCloseKey(hkey);
        }
    }
    else
    {
        ::GetPrivateProfileString(szSection, szKey, szDefault, g_szValue, sizeof(g_szValue), g_pszTapiIni);
    }
    return g_szValue;
}

static
void CommaStringToStringList(CStringList* plist, LPCSTR szList)
{
    plist->RemoveAll();
    if( szList && szList[0] )
    {
        CString sList = szList;
        BOOL    bInString = FALSE;
        for( int nFirstChar = 0, nCurrChar = 0; nCurrChar < sList.GetLength(); nCurrChar++ )
        {
            if( sList[nCurrChar] == '"' )
            {
                bInString = !bInString;
            }
            else if( sList[nCurrChar] == ',' && !bInString )
            {
                CString sItem = sList.Mid(nFirstChar, nCurrChar - nFirstChar);
                plist->AddTail(sItem);
                nFirstChar = nCurrChar + 1;
            }
        }
        if( nFirstChar < nCurrChar )
        {
            CString sItem = sList.Mid(nFirstChar, nCurrChar - nFirstChar);
            plist->AddTail(sItem);
        }
    }
}

// Takes a non-cost CStringList& for efficiency (sigh)
static
LPCSTR GetListString(CStringList& rgStrings, int n)
{
    LPCSTR  sz = "";

    if( rgStrings.GetCount() )
    {
        POSITION    pos = rgStrings.GetHeadPosition();
        do
        {
            ASSERT(pos);
            sz = rgStrings.GetNext(pos);
        }
        while( n-- && pos );

        // Strange boundary condition I know...
        if( n != -1 )
        {
            sz = "";
        }
    }

    return sz;
}

static
DWORD GetListNumber(CStringList& rgStrings, int n)
{
    return ::atoi(GetListString(rgStrings, n));
}

static
int CountBits(DWORD bits)
{
    int nBits = 0;
    while( bits )
    {
        if( bits & 1 )
        {
            nBits++;
        }
        bits /= 2;
    }
    return nBits;
}

/////////////////////////////////////////////////////////////////////////////
// CTExplorerView message handlers

void CTExplorerView::RefreshTapiInfo()
{
    ::TfxLineShutdown();
    ::TfxLineInitialize(this);
    ::TfxPhoneShutdown();
    ::TfxPhoneInitialize(this);
    GetTapiInfo();
}

void CTExplorerView::GetTapiInfo()
{
    HTREEITEM   hRoot = 0;
    CTreeCtrl&  tc = GetTreeCtrl();
    tc.DeleteAllItems();
    
    if( hRoot = tc.InsertItem("Telephony Devices") )
    {
        // Lines
        AddLines(InsertNumber(::TfxGetNumLines(), "Lines", hRoot));

        // Phones
        AddPhones(InsertNumber(::TfxGetNumPhones(), "Phones", hRoot));
    }

    if( hRoot = tc.InsertItem("Telephony Configuration") )
    {
        ::GetProfileString("Windows Telephony", "TelephonINIChanged", "<Unknown>", g_szValue, sizeof(g_szValue));
        InsertString(g_szValue, "[Last] Changed", hRoot);

        // Telephony Service Providers
        CtProviderList  pl;
        if( TSUCCEEDED(pl.GetProviderList()) )
        {
            AddProviders(pl, InsertNumber(pl.GetNumProviders(), "Service Providers", hRoot));
        }
        else
        {
            MessageBox("Unable to load provider list");
        }

        // Hand-Off Priorities
        AddPriorities(tc.InsertItem("Hand-Off Priorities", hRoot));

        // Locations & Calling Cards
        CtTranslateCaps   tc;
        if( TSUCCEEDED(tc.GetTranslateCaps()) )
        {
            AddLocations(tc, InsertNumber(tc.GetNumLocations(), "Locations", hRoot));

            AddCards(tc, InsertNumber(tc.GetNumCards(), "[Calling] Cards", hRoot));
        }
        else
        {
            MessageBox("Unable to load Location or Calling Card lists");
        }

        // Countries
        CtCountryList   cl;
        if( TSUCCEEDED(cl.GetCountryList()) )
        {
            AddCountries(cl, InsertNumber(cl.GetNumCountries(), "Countries", hRoot));
        }
        else
        {
            MessageBox("Unable to load Country list");
        }
    }
}

void CTExplorerView::AddLines(HTREEITEM hRoot)
{
    ASSERT(hRoot);

    CTreeCtrl&  tc = GetTreeCtrl();
    for( DWORD nLineID = 0; nLineID < ::TfxGetNumLines(); nLineID++ )
    {
        HTREEITEM   hItem = InsertNumber(nLineID, "Line", hRoot);
        if( hItem )
        {
            // API Version
            DWORD   dwApiVersion = CtLine::GetApiVersion(nLineID);
            ::wsprintf(g_szItem, "API Version: %u.%u",
                       HIWORD(dwApiVersion), LOWORD(dwApiVersion));
            InsertItem(g_szItem, hItem);

            HTREEITEM   hCapsItem = InsertItem("Line Capabilities", hItem);

            CtLineDevCaps   ldc;
            if( TSUCCEEDED(ldc.GetDevCaps(nLineID)) )
            {
                // Line capabilities
                AddLineDevCaps(ldc, hCapsItem);

                // Addresses
                HTREEITEM   hAddrsItem = InsertNumber(ldc.GetNumAddresses(), "Addresses", hItem);
                AddAddresses(nLineID, ldc.GetNumAddresses(), hAddrsItem);
                tc.Expand(hAddrsItem, TVE_EXPAND);

                // Terminals
                HTREEITEM   hTermsItem = InsertNumber(ldc.GetNumTerminals(), "Terminals", hItem);
                AddTerminals(ldc, hTermsItem);
                tc.Expand(hTermsItem, TVE_EXPAND);

            }
            else
            {
                CString sMsg;
                sMsg.Format("Unable to load line device capabilities: %lu", nLineID);
                MessageBox(sMsg);
            }

            // Device classes
            AddLineDeviceClasses(nLineID, ldc, InsertItem("Device Classes", hItem));
        }
    }
    tc.Expand(hRoot, TVE_EXPAND);
}

void CTExplorerView::AddLineDevCaps(const CtLineDevCaps& ldc, HTREEITEM hRoot)
{
    ASSERT(hRoot);

    InsertString(ldc.GetProviderInfo(), "Provider Info", hRoot);
    InsertString(ldc.GetSwitchInfo(), "Switch Info", hRoot);
    //InsertNumber(ldc.GetPermanentLineID(), "Permanent Line ID", hRoot);
    InsertHexNumber(ldc.GetPermanentLineID(), "Permanent Line ID", hRoot);
    InsertString(ldc.GetLineName(), "Line Name", hRoot);

    AddFlags(ldc.GetAddressModes(), aAddressModes, "Address Modes", hRoot);
    AddFlags(ldc.GetBearerModes(), aBearerModes, "Bearer Modes", hRoot);
    
    InsertNumber(ldc.GetMaxRate(), "Max [Data] Rate (bps)", hRoot);
    
    AddFlags(ldc.GetMediaModes(), aMediaModes, "Media Modes", hRoot);
    AddFlags(ldc.GetGenerateToneModes(), aToneModes, "Generate Tone Modes", hRoot);
    
    InsertNumber(ldc.GetGenerateToneMaxNumFreq(), "Generate Tone Max Num Freq", hRoot);
    
    AddFlags(ldc.GetGenerateDigitModes(), aDigitModes, "Generate Digit Modes", hRoot);
    
    InsertNumber(ldc.GetMonitorToneMaxNumFreq(), "Monitor Tone Max Num Freq", hRoot);
    InsertNumber(ldc.GetMonitorToneMaxNumEntries(), "Monitor Tone Max Num Entries", hRoot);

    AddFlags(ldc.GetMonitorDigitModes(), aDigitModes, "Monitor Digit Modes", hRoot);
    
    InsertNumber(ldc.GetGatherDigitsMinTimeout(), "Gather Digits Min Timeout (ms)", hRoot);
    InsertNumber(ldc.GetGatherDigitsMaxTimeout(), "Gather Digits Max Timeout (ms)", hRoot);
    InsertNumber(ldc.GetMedCtlDigitMaxListSize(), "Media Control Digit Max List Size", hRoot);
    InsertNumber(ldc.GetMedCtlMediaMaxListSize(), "Media Control Media Max List Size", hRoot);
    InsertNumber(ldc.GetMedCtlToneMaxListSize(), "Media Control Tone Max List Size", hRoot);
    InsertNumber(ldc.GetMedCtlCallStateMaxListSize(), "Media Control Call State Max List Size", hRoot);
    
    AddFlags(ldc.GetDevCapFlags(), aLineDevCapFlags, "Dev Caps Flags", hRoot);
    
    InsertNumber(ldc.GetMaxNumActiveCalls(), "Max Num Active Calls", hRoot);
    
    AddFlag(ldc.GetAnswerMode(), aAnswerModes, "Answer Mode", hRoot);

    InsertNumber(ldc.GetRingModes(), "Ring Modes", hRoot);
    
    AddFlags(ldc.GetLineStates(), aLineDevStates, "Line States", hRoot);
    
    InsertNumber(ldc.GetUUIAcceptSize(), "UUI Accept Size", hRoot);
    InsertNumber(ldc.GetUUIAnswerSize(), "UUI Answer Size", hRoot);
    InsertNumber(ldc.GetUUIMakeCallSize(), "UUI Make Call Size", hRoot);
    InsertNumber(ldc.GetUUIDropSize(), "UUI Drop Size", hRoot);
    InsertNumber(ldc.GetUUISendUserUserInfoSize(), "UUI Send UUI Size", hRoot);
    InsertNumber(ldc.GetUUICallInfoSize(), "UUI Call Info Size", hRoot);
    
    AddDialParams(ldc.GetMinDialParams(), InsertItem("Minimum Dial Params", hRoot));
    AddDialParams(ldc.GetMaxDialParams(), InsertItem("Maximum Dial Params", hRoot));
    AddDialParams(ldc.GetDefaultDialParams(), InsertItem("Default Dial Params", hRoot));
    
    AddFlags(ldc.GetLineFeatures(), aLineFeatures, "Line Features", hRoot);
}

void CTExplorerView::AddFlag(DWORD dwFlag, FlagMap aFlags[], LPCSTR szTag, HTREEITEM hRoot)
{
    ASSERT(szTag && *szTag);
    ASSERT(hRoot);

    int     i = 0;
    BOOL    bFound = FALSE;
    while( !bFound && dwFlag && aFlags[i].dwFlag )
    {
        if( aFlags[i++].dwFlag & dwFlag )
        {
            bFound = TRUE;
        }
    }

    // Make sure we've found it
    ASSERT(bFound || !dwFlag);

    InsertString((bFound ? aFlags[i].szFlag : "<None>"), szTag, hRoot);
}

void CTExplorerView::AddFlags(DWORD dwFlags, FlagMap aFlags[], LPCSTR szTag, HTREEITEM hRoot)
{
    HTREEITEM   hFlagRoot = InsertNumber(CountBits(dwFlags), szTag, hRoot);

    int i = 0;
    while( dwFlags && aFlags[i].dwFlag )
    {
        if( aFlags[i].dwFlag & dwFlags )
        {
            InsertItem(aFlags[i].szFlag, hFlagRoot);
            dwFlags &= ~(aFlags[i].dwFlag);
        }
        i++;
    }

    // Show all the custom bits
    DWORD   bit = 1;
    while( dwFlags )
    {
        if( dwFlags & bit )
        {
            ::wsprintf(g_szItem, "0x%08x", bit);
            InsertItem(g_szItem, hFlagRoot);
            dwFlags &= ~bit;
        }
        // bit << 1; generates no code
        bit *= 2;
    }

    // Make sure we've caught them all
    ASSERT(!dwFlags);
}

// AddScalar (and it's uses) was contributed by Olaf Brandt [olaf@shoretel.com]
void CTExplorerView::AddScalar(DWORD dwFlag, FlagMap aFlags[], LPCSTR szTag, HTREEITEM hRoot)
{
    ASSERT(szTag && *szTag);
    ASSERT(hRoot);

    int     i = 0;
    BOOL    bFound = FALSE;
	if ( dwFlag )
	{
		while ( dwFlag && aFlags[i].szFlag )
		{
			if( aFlags[i].dwFlag == dwFlag )
			{
				bFound = TRUE;
				break;
			}
			i += 1;
		}
		
		// Make sure we've found it
		ASSERT(bFound);
	}

    InsertString((bFound ? aFlags[i].szFlag : "<None>"), szTag, hRoot);
}

void CTExplorerView::AddTerminals(const CtLineDevCaps& ldc, HTREEITEM hRoot)
{
    ASSERT(hRoot);

    for( DWORD nTermID = 0; nTermID < ldc.GetNumTerminals(); nTermID++ )
    {
        ::wsprintf(g_szItem, "Terminal %lu Capabilities: ", nTermID,
                   ldc.GetTerminalText(nTermID));
        HTREEITEM   hItem = InsertItem(g_szItem, hRoot);
        if( hItem )
        {
            LPLINETERMCAPS  pltc = ldc.GetTermCaps(nTermID);
            
            AddFlag(pltc->dwTermDev, aTermDevs, "Terminal Device", hItem);
            AddFlags(pltc->dwTermModes, aTermModes, "Terminal Modes", hItem);
            AddFlag(pltc->dwTermSharing, aTermSharing, "Terminal Sharing", hItem);
        }
    }
}

void CTExplorerView::AddDialParams(LPLINEDIALPARAMS pldp, HTREEITEM hRoot)
{
    if( pldp )
    {
        ASSERT(hRoot);

        InsertNumber(pldp->dwDialPause, "Dial Pause (ms)", hRoot);
        InsertNumber(pldp->dwDialSpeed, "Dial Speed (ms)", hRoot);
        InsertNumber(pldp->dwDigitDuration, "Digit Duration (ms)", hRoot);
        InsertNumber(pldp->dwWaitForDialtone, "Wait For Dialtone (ms?)", hRoot);
    }
}

void CTExplorerView::AddAddresses(DWORD nLineID, DWORD nAddrs, HTREEITEM hRoot)
{
    ASSERT(hRoot);
    ASSERT(nLineID < ::TfxGetNumLines());
    ASSERT(nAddrs);

    CtAddressCaps   ac;
    for( DWORD nAddressID = 0; nAddressID < nAddrs; nAddressID++ )
    {
        ::wsprintf(g_szItem, "Address %lu Capabilities", nAddressID);
        HTREEITEM   hItem = InsertItem(g_szItem, hRoot);
        if( hItem )
        {
            if( TSUCCEEDED(ac.GetAddressCaps(nLineID, nAddressID)) )
            {
                AddAddressCaps(ac, hItem);
            }
            else
            {
                CString sMsg;
                sMsg.Format("Unable to load address capabilities: %lu", nAddressID);
                MessageBox(sMsg);
            }
        }
        else
        {
            MessageBox("Listview full");
        }
    }
}

void CTExplorerView::AddAddressCaps(const CtAddressCaps& ac, HTREEITEM hRoot)
{
    InsertString(ac.GetAddress(), "Address [Name]", hRoot);

    AddFlags(ac.GetAddressSharing(), aAddressSharing, "Address Sharing", hRoot);
    AddFlags(ac.GetAddressStates(), aAddressStates, "Address States", hRoot);
    AddFlags(ac.GetCallInfoStates(), aCallInfoStates, "Call Info States", hRoot);
    AddFlags(ac.GetCallerIDFlags(), aCallerIDFlags, "Caller ID Flags", hRoot);
    AddFlags(ac.GetCalledIDFlags(), aCalledIDFlags, "Called ID Flags", hRoot);
    AddFlags(ac.GetConnectedIDFlags(), aConnectedIDFlags, "Connected ID Flags", hRoot);
    AddFlags(ac.GetRedirectionIDFlags(), aRedirectionIDFlags, "Redirection ID Flags", hRoot);
    AddFlags(ac.GetRedirectingIDFlags(), aRedirectingIDFlags, "Redirecting ID Flags", hRoot);
    AddFlags(ac.GetCallStates(), aCallStates, "Call States", hRoot);
    AddFlags(ac.GetDialToneModes(), aDialToneModes, "Dial Tone Modes", hRoot);
    AddFlags(ac.GetBusyModes(), aBusyModes, "Busy Modes", hRoot);
    AddFlags(ac.GetSpecialInfo(), aSpecialInfo, "Special Info", hRoot);
    AddFlags(ac.GetDisconnectModes(), aDisconnectModes, "Disconnected Modes", hRoot);

    InsertNumber(ac.GetMaxNumActiveCalls(), "Max Num Active Calls", hRoot);
    InsertNumber(ac.GetMaxNumOnHoldCalls(), "Max Num On Hold Calls", hRoot);
    InsertNumber(ac.GetMaxNumOnHoldPendingCalls(), "Max Num On Hold Pending Calls", hRoot);
    InsertNumber(ac.GetMaxNumConference(), "Max Num Conference", hRoot);
    InsertNumber(ac.GetMaxNumTransConf(), "Max Num Trans Conf", hRoot);

    AddFlags(ac.GetAddrCapFlags(), aAddrCapFlags, "Addr Cap Flags", hRoot);
    AddFlags(ac.GetCallFeatures(), aCallFeatures, "Call Features", hRoot);

    //AddFlag(ac.GetRemoveFromConfCaps(), aRemoveFromConf, "Remove From Conference Caps", hRoot);
    AddScalar(ac.GetRemoveFromConfCaps(), aRemoveFromConf, "Remove From Conference Caps", hRoot);
    AddFlag(ac.GetRemoveFromConfState(), aCallStates, "Remove From Conference State", hRoot);

    AddFlags(ac.GetTransferModes(), aTransferModes, "Transfer Modes", hRoot);
    AddFlags(ac.GetParkModes(), aParkModes, "Park Modes", hRoot);
    AddFlags(ac.GetForwardModes(), aForwardModes, "Forward Modes", hRoot);

    InsertNumber(ac.GetMaxForwardEntries(), "Max Forward Entries", hRoot);
    InsertNumber(ac.GetMaxSpecificEntries(), "Max Specific Entries", hRoot);
    InsertNumber(ac.GetMinFwdNumRings(), "Min Fwd Num Rings", hRoot);
    InsertNumber(ac.GetMaxFwdNumRings(), "Max Fwd Num Rings", hRoot);
    InsertNumber(ac.GetMaxCallCompletions(), "Max Call Completions", hRoot);

    AddFlags(ac.GetCallCompletionConds(), aCallCompletionConds, "Call Completion Conditions", hRoot);
    AddFlags(ac.GetCallCompletionModes(), aCallCompletionModes, "Call Completion Modes", hRoot);
    AddCompletionMessages(ac, InsertItem("Call Completion Messages", hRoot));
    AddFlags(ac.GetAddressFeatures(), aAddressFeatures, "Address Features", hRoot);
}

void CTExplorerView::AddCompletionMessages(const CtAddressCaps& ac, HTREEITEM hRoot)
{
    ASSERT(hRoot);
    for( DWORD i = 0; i < ac.GetNumCompletionMessages(); i++ )
    {
        InsertItem(ac.GetCompletionMsgText(i), hRoot);
    }
}

void CTExplorerView::AddProviders(const CtProviderList& pl, HTREEITEM hRoot)
{
    for( DWORD nIndex = 0; nIndex < pl.GetNumProviders(); nIndex++ )
    {
        HTREEITEM   hProviderRoot = InsertNumber(nIndex, "Provider", hRoot, pl.GetProviderFilename(nIndex));
        if( hProviderRoot )
        {
            //InsertNumber(pl.GetProviderPermanentID(nIndex), "Permanent ID", hProviderRoot);
            InsertHexNumber(pl.GetProviderPermanentID(nIndex), "Permanent ID", hProviderRoot);
            InsertString(pl.GetProviderFilename(nIndex), "Filename", hProviderRoot);

            // <<TODO: Show version info.>>
            // <<TODO: Add exploration of exported functions.>>
        }
    }
}

void CTExplorerView::AddPriorities(HTREEITEM hRoot)
{
    enum { KEY = 0, DESC = 1 };
    LPSTR   szKeyDescMap[][2] = {
        {"RequestMakeCall", "tapiMakeCall() Request"},
        {"RequestMediaCall","tapiMediaCall() Request"},
        {"unknown",         "Unknown"},
        {"interactivevoice","Interactive Voice"},
        {"automatedvoice",  "Automated Voice"},
        {"g3fax",           "Group 3 Fax"},
        {"g4fax",           "Group 4 Fax"},
        {"datamodem",       "Data Modem"},
        {"teletex",         "Teletext"},
        {"videotex",        "Videotex"},
        {"telex",           "Telex"},
        {"mixed",           "Mixed"},
        {"tdd",             "Telephony Device for the Deaf (TDD)"},
        {"adsi",            "Analog Display Services Interface (ADSI)"},
        {"digitaldata",     "Digital Data"},
        {0, 0}};

    int nKey = 0;
    while( szKeyDescMap[nKey][KEY] )
    {
        CStringList listApps;
        CommaStringToStringList(&listApps, GetTapiString("HandoffPriorities", szKeyDescMap[nKey][KEY]));

        int         nApps = listApps.GetCount();
        HTREEITEM   hPriorityRoot = InsertNumber(nApps, szKeyDescMap[nKey][DESC], hRoot);
        if( hPriorityRoot && nApps )
        {
            POSITION    pos = listApps.GetHeadPosition();
            while( pos )
            {
                InsertItem(listApps.GetNext(pos), hPriorityRoot);
            }
        }
        nKey++;
    }

    // <<TODO: Add support for extended media modes>>
}

void CTExplorerView::AddLocations(const CtTranslateCaps& tc, HTREEITEM hRoot)
{
    for( DWORD nIndex = 0; nIndex < tc.GetNumLocations(); nIndex++ )
    {
        CString     sName = tc.GetLocationName(nIndex);
        if( tc.GetPermanentLocationID(nIndex) == tc.GetCurrentLocationID() )
        {
            sName += " [CURRENT]";
        }

        HTREEITEM   hLocationRoot = InsertNumber(nIndex, "Location", hRoot, sName);
        if( hLocationRoot )
        {
            //InsertNumber(tc.GetPermanentLocationID(nIndex), "Permanent Location ID", hLocationRoot);
            InsertHexNumber(tc.GetPermanentLocationID(nIndex), "Permanent Location ID", hLocationRoot);
            InsertString(tc.GetLocationName(nIndex), "Location Name", hLocationRoot);
            InsertNumber(tc.GetCountryCode(nIndex), "Country Code", hLocationRoot);
            InsertString(tc.GetAreaCode(nIndex), "City/Area Code", hLocationRoot);
            InsertNumber(tc.GetPreferredCardID(nIndex), "Preferred Card ID", hLocationRoot);
            InsertString(tc.GetLocalAccessCode(nIndex), "Local Access Code", hLocationRoot);
            InsertString(tc.GetLongDistanceAccessCode(nIndex), "Long Distance Access Code", hLocationRoot);
            InsertString(tc.GetTollPrefixList(nIndex), "Toll Prefix List", hLocationRoot);
            InsertNumber(tc.GetCountryID(nIndex), "Country ID", hLocationRoot);
            InsertString(tc.GetCancelCallWaiting(nIndex), "Cancel Call Waiting [Dial String]", hLocationRoot);

            AddFlags(tc.GetLocationOptions(nIndex), aLocationOptions, "Location Options", hLocationRoot);
        }
    }
}

void CTExplorerView::AddCards(const CtTranslateCaps& tc, HTREEITEM hRoot)
{
    for( DWORD nIndex = 0; nIndex < tc.GetNumCards(); nIndex++ )
    {
        HTREEITEM   hCardRoot = InsertNumber(nIndex, "Card", hRoot, tc.GetCardName(nIndex));
        if( hCardRoot )
        {
            //InsertNumber(tc.GetPermanentCardID(nIndex), "Permanent Card ID", hCardRoot);
            InsertHexNumber(tc.GetPermanentCardID(nIndex), "Permanent Card ID", hCardRoot);
            InsertString(tc.GetCardName(nIndex), "Card Name", hCardRoot);
            InsertNumber(tc.GetCardNumberDigits(nIndex), "Card Number [of] Digits", hCardRoot);
            InsertString(tc.GetSameAreaRule(nIndex), "Same Area [Dialing] Rule", hCardRoot);
            InsertString(tc.GetLongDistanceRule(nIndex), "Long Distance [Dialing] Rule", hCardRoot);
            InsertString(tc.GetInternationalRule(nIndex), "International [Dialing] Rule", hCardRoot);

            AddFlags(tc.GetCardOptions(nIndex), aCardOptions, "Card Options", hCardRoot);
        }
    }
}

void CTExplorerView::AddCountries(const CtCountryList& cl, HTREEITEM hRoot)
{
    for( DWORD nIndex = 0; nIndex < cl.GetNumCountries(); nIndex++ )
    {
        HTREEITEM   hCountryRoot = InsertNumber(nIndex, "Country", hRoot, cl.GetCountryName(nIndex));
        if( hCountryRoot )
        {
            InsertNumber(cl.GetCountryCode(nIndex), "Country Code", hCountryRoot);
            InsertString(cl.GetCountryName(nIndex), "Country Name", hCountryRoot);
            InsertString(cl.GetSameAreaRule(nIndex), "Same Area [Dialing] Rule", hCountryRoot);
            InsertString(cl.GetLongDistanceRule(nIndex), "Long Distance [Dialing] Rule", hCountryRoot);
            InsertString(cl.GetInternationalRule(nIndex), "International [Dialing] Rule", hCountryRoot);
        }
    }
}

void CTExplorerView::AddLineDevice(const CtLine& line, const char* pszDeviceClass, HTREEITEM hRoot)
{
    CtDeviceID  did;
    if( SUCCEEDED(did.GetID(pszDeviceClass, line.GetHandle())) )
    {
        // comm
        if( strcmpi("comm", pszDeviceClass) == 0 )
        {
            InsertString(did.GetString(), pszDeviceClass, hRoot, "Communications Port Name");
        }
        // comm/datamodem
        else if( strcmpi("comm/datamodem", pszDeviceClass) == 0 )
        {
            HANDLE  hComm;
            LPCSTR  pszComm = did.GetHandleAndString(&hComm);
            
            HTREEITEM   hItem = InsertString(pszComm, pszDeviceClass, hRoot);
            if( hItem && pszComm && *pszComm )
            {
                InsertNumber(int(hComm), "hComm", hItem, "Communications Handle");
                InsertString(pszComm, "szDeviceName", hItem, "Device Name");
            }
        }
        // comm/datamodem/portname
        else if( strcmpi("comm/datamodem/portname", pszDeviceClass) == 0 )
        {
            InsertString(did.GetString(), pszDeviceClass, hRoot, "Port Name");
        }
        // wave/in
        else if( strcmpi("wave/in", pszDeviceClass) == 0 )
        {
            InsertNumber(did.GetDeviceID(), pszDeviceClass, hRoot, "Device ID");
        }
        // wave/out
        else if( strcmpi("wave/out", pszDeviceClass) == 0 )
        {
            InsertNumber(did.GetDeviceID(), pszDeviceClass, hRoot, "Device ID");
        }
        // midi/in
        else if( strcmpi("midi/in", pszDeviceClass) == 0 )
        {
            InsertNumber(did.GetDeviceID(), pszDeviceClass, hRoot, "Device ID");
        }
        // midi/out
        else if( strcmpi("midi/out", pszDeviceClass) == 0 )
        {
            InsertNumber(did.GetDeviceID(), pszDeviceClass, hRoot, "Device ID");
        }
        // tapi/line
        else if( strcmpi("tapi/line", pszDeviceClass) == 0 )
        {
            InsertNumber(did.GetDeviceID(), pszDeviceClass, hRoot, "Line Device ID");
        }
        // ndis
        else if( strcmpi("ndis", pszDeviceClass) == 0 )
        {
            InsertNumber(did.GetDeviceID(), pszDeviceClass, hRoot, "Line Device ID");
        }
        // <<TODO: Add tapi/phone.>>
        // <<TODO: Add tapi/terminals.>>
        
        // Unknown device class
        else
        {
            InsertItem(pszDeviceClass, hRoot);
        }
    }
}

void CTExplorerView::AddLineDeviceClasses(DWORD nLineID, const CtLineDevCaps& ldc, HTREEITEM hRoot)
{
    CtLine  line;
    DWORD   nPriviledges = LINECALLPRIVILEGE_MONITOR;
    DWORD   nMediaMode = 0;

    if( TSUCCEEDED(line.Open(nLineID, 0, nPriviledges, nMediaMode)) )
    {
#if (TAPI_CURRENT_VERSION >= 0x00020000)
        DWORD   nDeviceClasses = ldc.GetNumDeviceClasses();
        for( DWORD i = 0; i != nDeviceClasses; ++i )
        {
            AddLineDevice(line, ldc.GetDeviceClassName(i), hRoot);
        }
#else
        // Use fixed list of known device classes
        const char* rgpszDeviceClasses[] = {"comm",
                                            "comm/datamodem",
                                            "comm/datamodem/portname",
                                            "wave/in",
                                            "wave/out",
                                            "midi/in",
                                            "midi/out",
                                            "tapi/line",
                                            "ndis",
                                            // <<TODO: Add tapi/phone.>>
                                            // <<TODO: Add tapi/terminals.>>
                                           };

        for( int i = 0; i != DIM(rgpszDeviceClasses); ++i )
        {
            AddLineDevice(line, rgpszDeviceClasses[i], hRoot);
        }
#endif  // TAPI_CURRENT_VERSION >= 0x00020000
    }
}

void CTExplorerView::AddPhones(HTREEITEM hRoot)
{
    ASSERT(hRoot);

    CTreeCtrl&  tc = GetTreeCtrl();
    for( DWORD nPhoneID = 0; nPhoneID < ::TfxGetNumPhones(); nPhoneID++ )
    {
        HTREEITEM   hItem = InsertNumber(nPhoneID, "Phone", hRoot);
        if( hItem )
        {
            // API Version
            DWORD   dwApiVersion = CtPhone::GetApiVersion(nPhoneID);
            ::wsprintf(g_szItem, "API Version: %u.%u",
                       HIWORD(dwApiVersion), LOWORD(dwApiVersion));
            InsertItem(g_szItem, hItem);

            HTREEITEM   hCapsItem = InsertItem("Phone Capabilities", hItem);

            CtPhoneCaps   pc;
            if( TSUCCEEDED(pc.GetDevCaps(nPhoneID)) )
            {
                // Line capabilities
                AddPhoneCaps(pc, hCapsItem);
            }
            else
            {
                CString sMsg;
                sMsg.Format("Unable to load phone device capabilities: %lu", nPhoneID);
                MessageBox(sMsg);
            }

            // Device classes
            //<<TODO>> AddPhoneDeviceClasses(nPhoneID, InsertItem("Device Classes", hItem));
        }
    }
    tc.Expand(hRoot, TVE_EXPAND);
}

void CTExplorerView::AddPhoneCaps(const CtPhoneCaps& pc, HTREEITEM hRoot)
{
    ASSERT(hRoot);

    InsertString(pc.GetProviderInfo(), "Provider Info", hRoot);
    InsertString(pc.GetPhoneInfo(), "Phone Info", hRoot);
    //InsertNumber(pc.GetPermanentPhoneID(), "Permanent Phone ID", hRoot);
    InsertHexNumber(pc.GetPermanentPhoneID(), "Permanent Phone ID", hRoot);
    InsertString(pc.GetPhoneName(), "Phone Name", hRoot);

    AddFlags(pc.GetPhoneStates(), aPhoneStates, "Phone States", hRoot);
    AddFlags(pc.GetHookSwitchDevs(), aHookSwitchDevs, "Hookswitch Devices", hRoot);

    AddFlags(pc.GetHandsetHookSwitchModes(), aHookSwitchModes, "Handset Hookswitch Modes", hRoot);
    AddFlags(pc.GetSpeakerHookSwitchModes(), aHookSwitchModes, "Speaker Hookswitch Modes", hRoot);
    AddFlags(pc.GetHeadsetHookSwitchModes(), aHookSwitchModes, "Headset Hookswitch Modes", hRoot);

    AddFlags(pc.GetVolumeFlags(), aHookSwitchDevs, "Volume Flags", hRoot);
    AddFlags(pc.GetGainFlags(), aHookSwitchDevs, "Gain Flags", hRoot);

    InsertNumber(pc.GetDisplayNumRows(), "[Number of] Display Rows", hRoot);
    InsertNumber(pc.GetDisplayNumColumns(), "[Number of] Display Columns", hRoot);
    InsertNumber(pc.GetNumRingModes(), "[Number of] Ring Modes", hRoot);
    InsertNumber(pc.GetNumButtonLamps(), "[Number of] Buttons & Lamps", hRoot);

    // Button Modes
    {
        HTREEITEM   hButtonModesRoot = InsertItem("Button Modes", hRoot);
        if( hButtonModesRoot )
        {
            for( DWORD nButton = 0; nButton < pc.GetNumButtonLamps(); nButton++ )
            {
                CString sItem;
                sItem.Format("Button Modes: %lu", nButton);
                AddFlags(pc.GetButtonModes(nButton), aButtonModes, sItem, hButtonModesRoot);
            }
        }
    }

    // Button Functions
    {
        HTREEITEM   hButtonFunctionsRoot = InsertItem("Button Functions", hRoot);
        if( hButtonFunctionsRoot )
        {
            for( DWORD nButton = 0; nButton < pc.GetNumButtonLamps(); nButton++ )
            {
                CString sItem;
                sItem.Format("Button Function: %lu", nButton);
                //AddFlag(pc.GetButtonFunction(nButton), aButtonFunctions, sItem, hButtonFunctionsRoot);
                AddScalar(pc.GetButtonFunction(nButton), aButtonFunctions, sItem, hButtonFunctionsRoot);
            }
        }
    }

    // Lamp Modes
    {
        HTREEITEM   hLampModesRoot = InsertItem("Lamp Modes", hRoot);
        if( hLampModesRoot )
        {
            for( DWORD nLamp = 0; nLamp < pc.GetNumButtonLamps(); nLamp++ )
            {
                CString sItem;
                sItem.Format("Lamp Modes: %lu", nLamp);
                AddFlags(pc.GetLampModes(nLamp), aLampModes, sItem, hLampModesRoot);
            }
        }
    }

    InsertNumber(pc.GetNumSetData(), "[Number of] Set Data", hRoot);
    //<<TODO>> DWORD   GetSetData(DWORD nDatum) const;
    InsertNumber(pc.GetNumGetData(), "[Number of] Get Data", hRoot);
    //<<TODO>> DWORD   GetGetData(DWORD nDatum) const;

    InsertNumber(pc.GetDevSpecificSize(), "Device Specific Size", hRoot);
}

void CTExplorerView::OnFileRefresh() 
{
    RefreshTapiInfo();
}
