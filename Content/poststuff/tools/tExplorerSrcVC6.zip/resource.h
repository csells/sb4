//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by tExplorer.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDC_LINK                        1000
#define IDC_WEB                         1000
#define IDC_FILE_VERSION                1001
#define IDC_EMAIL                       1002
#define ID_FILE_REFRESH                 32771
#define ID_HELP_PRODUCTHOMEPAGE         32772
#define ID_HELP_PRODUCTFEEDBACK         32773
#define ID_HELP_WEB                     32774
#define ID_HELP_FEEDBACK                32775
#define ID_HELP_CONTENTS                32776
#define ID_HELP_BUYTEXPLORER            32777
#define ID_HELP_BUY                     32778
#define IDS_TAPI_VERSION                61204
#define IDS_LINE_VERSION                61204
#define IDS_LO_VERSION                  61204
#define IDS_PHONE_VERSION               61205
#define IDS_HI_VERSION                  61205

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
