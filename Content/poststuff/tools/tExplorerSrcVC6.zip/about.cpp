// about.cpp : Defines the class behaviors for the about box.
//

#include "stdafx.h"
#include "about.h"
#include "_bldNum.h"

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Control(pDX, IDC_WEB, m_linkWeb);
	DDX_Control(pDX, IDC_EMAIL, m_linkEmail);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static bool AppRegistered()
{
    bool    bRegistered = true;

    // Check registration
    char szMutexName[MAX_PATH];
    
    // Mutex name is in ANSI
    wsprintf(szMutexName, "%xUNREGISTERED", GetCurrentProcessId());
    
    HANDLE hMutex = CreateMutex(0, 0, szMutexName);
    
    if( GetLastError() == ERROR_ALREADY_EXISTS ) bRegistered = false;
    CloseHandle(hMutex);
    return bRegistered;
}

BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// Extra initialization
    CString sFileVersion;
    sFileVersion.Format("TAPI Explorer v%d.%d.%d.%d (%s)",
                        FILE_VERSION0,
                        FILE_VERSION1,
                        FILE_VERSION2,
                        BUILD_NUMBER,
                        AppRegistered() ? "Registered" : "UNREGISTERED");
    SetDlgItemText(IDC_FILE_VERSION, sFileVersion);

    CString sEmail;
    GetDlgItemText(IDC_EMAIL, sEmail);
    m_linkEmail.SetURL("mailto:" + sEmail);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
