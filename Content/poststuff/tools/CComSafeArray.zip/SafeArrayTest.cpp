// SafeArrayTest.cpp : Implementation of CSafeArrayTest
#include "stdafx.h"
#include <comutil.h>
#include "SafeArrayDemo.h"
#include "SafeArrayTest.h"
#include "ComSafeArray.h"

/////////////////////////////////////////////////////////////////////////////
// CSafeArrayTest


STDMETHODIMP CSafeArrayTest::GetStooges(SAFEARRAY **ppStooges)
{
	CComSafeArray SmartArray;

	SmartArray.CreateOneDim(VT_BSTR, m_vecStooges.size());

	vector<CComBSTR>::iterator it;
	int i = 0;
	BSTR * bstrArray;

	SmartArray.AccessData((void **)&bstrArray);

	for (it = m_vecStooges.begin(); it != m_vecStooges.end(); it++, i++)
	{
		bstrArray[i] = SysAllocString(it->m_str);	
	}

	SmartArray.UnaccessData();

	*ppStooges = SmartArray.Detach().parray;
	return S_OK;
}

HRESULT CSafeArrayTest::FinalConstruct()
{
	m_vecStooges.push_back(CComBSTR(L"Larry"));
	m_vecStooges.push_back(CComBSTR(L"Curly"));
	m_vecStooges.push_back(CComBSTR(L"Moe"));
	m_vecStooges.push_back(CComBSTR(L"Shemp"));
	m_vecStooges.push_back(CComBSTR(L"Joe"));
	return S_OK;
}

STDMETHODIMP CSafeArrayTest::get_Numbers(VARIANT *pNumbers)
{
	CComSafeArray SmartArray;

	SmartArray.CreateOneDim(VT_I4, m_vecNumbers.size());

	vector<long>::iterator it;
	int i = 0;
	long * longArray;

	SmartArray.AccessData((void **)&longArray);

	for (it = m_vecNumbers.begin(); it != m_vecNumbers.end(); it++, i++)
	{
		longArray[i] = *it;	
	}

	SmartArray.UnaccessData();

	*pNumbers = SmartArray.Detach();
	return S_OK;
}

STDMETHODIMP CSafeArrayTest::put_Numbers(VARIANT newVal)
{
	// Make sure it is an array of longs
	if ((newVal.vt & (VT_ARRAY | VT_I4)) == 0) 
		return E_INVALIDARG;

	m_vecNumbers.clear();

	CComSafeArray SmartArray;

	SmartArray.Attach(newVal);

	long * longArray;
	SmartArray.AccessData((void **)&longArray);

	for (int i=0; i < SmartArray.GetOneDimSize(); i++)
	{
		m_vecNumbers.push_back(longArray[i]);	
	}

	SmartArray.UnaccessData();
	return S_OK;
}

STDMETHODIMP CSafeArrayTest::AddNumber(long newVal)
{
	m_vecNumbers.push_back(newVal);	

	return S_OK;
}
