// SafeArrayTest.h : Declaration of the CSafeArrayTest

#ifndef __SAFEARRAYTEST_H_
#define __SAFEARRAYTEST_H_

#include "resource.h"       // main symbols
#include <vector>
using namespace std;

/////////////////////////////////////////////////////////////////////////////
// CSafeArrayTest
class ATL_NO_VTABLE CSafeArrayTest : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CSafeArrayTest, &CLSID_SafeArrayTest>,
	public IDispatchImpl<ISafeArrayTest, &IID_ISafeArrayTest, &LIBID_SAFEARRAYDEMOLib>
{
public:
	CSafeArrayTest()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SAFEARRAYTEST)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CSafeArrayTest)
	COM_INTERFACE_ENTRY(ISafeArrayTest)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

	HRESULT FinalConstruct();

// ISafeArrayTest
public:
	STDMETHOD(AddNumber)(/*[in]*/ long newVal);
	STDMETHOD(get_Numbers)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(put_Numbers)(/*[in]*/ VARIANT newVal);
	STDMETHOD(GetStooges)(/*[out, retval]*/ SAFEARRAY ** ppStooges);

private:
	vector<CComBSTR> m_vecStooges;
	vector<long> m_vecNumbers;
};

#endif //__SAFEARRAYTEST_H_
