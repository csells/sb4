#include <comdef.h>
#pragma once

/////////////////////////////////////////////////////////////////////////////
// CSafeArray class

typedef const SAFEARRAY* LPCSAFEARRAY;
typedef const VARIANT* LPCVARIANT;

class CComSafeArray : public tagVARIANT
{
//Constructors
public:
	CComSafeArray();
	CComSafeArray(const SAFEARRAY& saSrc, VARTYPE vtSrc);
	CComSafeArray(LPCSAFEARRAY pSrc, VARTYPE vtSrc);
	CComSafeArray(const CComSafeArray& saSrc);
	CComSafeArray(const VARIANT& varSrc);
	CComSafeArray(LPCVARIANT pSrc);
//	CComSafeArray(const _variant_t& varSrc);

// Operations
public:
	void Clear();
	void Attach(VARIANT& varSrc);
	VARIANT Detach();

	CComSafeArray& operator=(const CComSafeArray& saSrc);
	CComSafeArray& operator=(const VARIANT& varSrc);
	CComSafeArray& operator=(LPCVARIANT pSrc);
	CComSafeArray& operator=(const _variant_t& varSrc);

	BOOL operator==(const SAFEARRAY& saSrc) const;
	BOOL operator==(LPCSAFEARRAY pSrc) const;
	BOOL operator==(const CComSafeArray& saSrc) const;
	BOOL operator==(const VARIANT& varSrc) const;
	BOOL operator==(LPCVARIANT pSrc) const;
	BOOL operator==(const _variant_t& varSrc) const;

	operator LPVARIANT();
	operator LPCVARIANT() const;

	// One dim array helpers
	void CreateOneDim(VARTYPE vtSrc, DWORD dwElements,
		const void* pvSrcData = NULL, long nLBound = 0);
	DWORD GetOneDimSize();
	void ResizeOneDim(DWORD dwElements);

	// Multi dim array helpers
	void Create(VARTYPE vtSrc, DWORD dwDims, DWORD* rgElements);

	// SafeArray wrapper classes
	void Create(VARTYPE vtSrc, DWORD dwDims, SAFEARRAYBOUND* rgsabounds);
	void AccessData(void** ppvData);
	void UnaccessData();
	void AllocData();
	void AllocDescriptor(DWORD dwDims);
	void Copy(LPSAFEARRAY* ppsa);
	void GetLBound(DWORD dwDim, long* pLBound);
	void GetUBound(DWORD dwDim, long* pUBound);
	void GetElement(long* rgIndices, void* pvData);
	void PtrOfIndex(long* rgIndices, void** ppvData);
	void PutElement(long lIndex, void* pvData);
	void PutElement(long* rgIndices, void* pvData);
	void Redim(SAFEARRAYBOUND* psaboundNew);
	void Lock();
	void Unlock();
	DWORD GetDim();
	DWORD GetElemSize();
	void Destroy();
	void DestroyData();
	void DestroyDescriptor();

//Implementation
public:
	DWORD GetSize(DWORD nDim);
	~CComSafeArray();

	// Cache info to make element access (operator []) faster
	DWORD m_dwElementSize;
	DWORD m_dwDims;

private:

};

/////////////////////////////////////////////////////////////////////////////
// Helper for initializing CComSafeArray
void ATLSafeArrayInit(CComSafeArray* psa);

BOOL ATLCompareSafeArrays(SAFEARRAY* parray1, SAFEARRAY* parray2);
