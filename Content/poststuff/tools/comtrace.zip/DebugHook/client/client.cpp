#include <windows.h>
#include <stdio.h>
#include <time.h>
#include <atlbase.h>
#include "..\debughook.h"
#include "..\debughook_i.c"

// {00024500-0000-0000-C000-000000000046}
static const GUID CLSID_Excel = 
{ 0x24500, 0x0, 0x0, { 0xc0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x46 } };

// {000209FF-0000-0000-C000-000000000046}
static const GUID CLSID_Word = 
{ 0x209ff, 0x0, 0x0, { 0xc0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x46 } };

// {91493441-5A91-11cf-8700-00AA0060263B}
static const GUID CLSID_PowerPoint = 
{ 0x91493441, 0x5a91, 0x11cf, { 0x87, 0x0, 0x0, 0xaa, 0x0, 0x60, 0x26, 0x3b } };

// {7404C592-823F-11d1-96AB-00600819B080}
static const GUID CLSID_TraceLog = 
{ 0x7404c592, 0x823f, 0x11d1, { 0x96, 0xab, 0x0, 0x60, 0x8, 0x19, 0xb0, 0x80 } };

void ErrorBox(HRESULT hr);

void DumpStack(IUnknown* punk)
{
    HRESULT         hr;
    IStackTrace*    pst = 0;

    hr = punk->QueryInterface(IID_IStackTrace, (void**)&pst);
    if( SUCCEEDED(hr) )
    {
        /**/
        long    nCount;
        pst->GetCount(&nCount);
        
        for( long nItem = 0; nItem != nCount; ++nItem )
        {
            long        nLevel;
            CComBSTR    bstrTime;
            CComBSTR    bstrMachine;
            CComBSTR    bstrProcess;
            CComBSTR    bstrServer;
            CComBSTR    bstrClass;
            CComBSTR    bstrInterface;
            CComBSTR    bstrMethod;
            CComBSTR    bstrError;

            pst->GetItem(nItem,
                         &nLevel,
                         &bstrTime,
                         &bstrMachine,
                         &bstrProcess,
                         &bstrServer,
                         &bstrClass,
                         &bstrInterface,
                         &bstrMethod,
                         &bstrError);

            // Pad for the level
            for( long n = 0; n != nLevel; ++n )
            {
                printf("    ");
            }

            wprintf(L"%s, %s, %s, %s, %s, %s::%s() = %s\n", bstrTime, bstrMachine, bstrProcess, bstrServer, bstrClass, bstrInterface, bstrMethod, bstrError);
        }
        /**/

        IUnknown*   punk = 0;
        hr = GetActiveObject(CLSID_TraceLog, 0, &punk);
        if( SUCCEEDED(hr) )
        {
            ILogStackTrace* plst = 0;
            if( SUCCEEDED(punk->QueryInterface(IID_ILogStackTrace, (void**)&plst)) )
            {
                HRESULT hr = plst->LogStackTrace(pst);
                if( FAILED(hr) ) ErrorBox(hr);
                plst->Release();
            }
            punk->Release();
        }

        pst->Release();
    }
}

DWORD WINAPI ThreadProc(void* pv)
{
    CoInitialize(0);

    IStream*    pstm = (IStream*)pv;
    IUnknown*   punk = 0;
    CoUnmarshalInterface(pstm, IID_IUnknown, (void**)&punk);
    if( punk )
    {
        DumpStack(punk);
        punk->Release();
    }

    pstm->Release();
    CoUninitialize();
    return 0;
}

void main()
{
    CoInitialize(0);

    HRESULT hr;
    ISetStackTrace* psst = 0;
    hr = CoCreateInstance(CLSID_StackTrace, 0, CLSCTX_INPROC_SERVER,
                          IID_ISetStackTrace, (void**)&psst);

    if( SUCCEEDED(hr) )
    {
        // Simulate:
        // Client calls IDispatch::Invoke on CLSID_Excel
        // Excel calls IDispatch::Invoke on CLSID_Word
        // Excel calls IDispatch::Invoke on CLSID_PowerPoint
        // (Calls pushed in reverse order to get HRESULT)
        psst->put_Level(1);
        hr = psst->AppendStackEntry(time(0),
                                    L"ppt.exe",
                                    CLSID_PowerPoint,
                                    IID_IDispatch,
                                    L"Invoke",
                                    DISP_E_EXCEPTION);
        psst->put_Level(1);
        hr = psst->AppendStackEntry(time(0),
                                    L"winword.exe",
                                    CLSID_Word,
                                    IID_IDispatch,
                                    L"Invoke",
                                    0);
        psst->put_Level(0);
        hr = psst->AppendStackEntry(time(0),
                                    L"excel.exe",
                                    CLSID_Excel,
                                    IID_IDispatch,
                                    L"Invoke",
                                    DISP_E_EXCEPTION);

        DumpStack(psst);
        /*
        IStream*    pstm;
        CreateStreamOnHGlobal(0, TRUE, &pstm);
        CoMarshalInterface(pstm, IID_IUnknown, psst, MSHCTX_LOCAL, 0, MSHLFLAGS_NORMAL);
        LARGE_INTEGER li = { 0 };
        pstm->Seek(li, STREAM_SEEK_SET, 0);
        DWORD   dw;
        CreateThread(0, 0, ThreadProc, pstm, 0, &dw);
        MessageBox(0, "Waiting to exhale", 0, MB_SETFOREGROUND);
        */

        psst->Release();
    }

    CoUninitialize();
}

void ErrorBox(HRESULT hr)
{
    char    szError[256];
    BOOL    bRet = FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM,
                                  0,
                                  hr,
                                  0,
                                  szError,
                                  sizeof(szError),
                                  0);
    if( !bRet )
    {
        strcpy(szError, "<unknown");
    }

    MessageBox(0, szError, 0, MB_SETFOREGROUND);
}

