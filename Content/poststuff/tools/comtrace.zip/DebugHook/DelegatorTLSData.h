// DelegatorTLSData.h
#pragma once

interface IStackTrace;
struct Delegator;

struct DelegatorTLSData
{
	DelegatorTLSData( Delegator* pDelegator, DWORD retAddr, DWORD ecx,
					  long nTime, long nMethodIndex,
					  DelegatorTLSData* pTail = 0 )
	  : m_pDelegator( pDelegator ),
		m_retAddr( retAddr ),
		m_ecx( ecx ),
		m_nTime( nTime ),
		m_nMethodIndex( nMethodIndex ),
		m_pTail( pTail )
	{}
	Delegator*			m_pDelegator;
	DWORD				m_retAddr;
	DWORD				m_ecx;
	long				m_nTime;
	long				m_nMethodIndex;
	DelegatorTLSData*	m_pTail;
};
