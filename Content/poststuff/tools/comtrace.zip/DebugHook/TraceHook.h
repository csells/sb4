// TraceHook.h : Declaration of the CTraceHook

#ifndef __TRACEHOOK_H_
#define __TRACEHOOK_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CTraceHook
class ATL_NO_VTABLE CTraceHook : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CTraceHook, &CLSID_TraceHook>,
	public IChannelHook
{
public:
	CTraceHook();

DECLARE_REGISTRY_RESOURCEID(IDR_TRACEHOOK)
DECLARE_NOT_AGGREGATABLE(CTraceHook)

BEGIN_COM_MAP(CTraceHook)
    COM_INTERFACE_ENTRY(IChannelHook)
END_COM_MAP()

// IChannelHook
public:
    STDMETHODIMP_(void) ClientGetSize(
        REFGUID uExtent,
        REFIID  riid,
        ULONG  *pDataSize );
    
    STDMETHODIMP_(void) ClientFillBuffer(
        REFGUID uExtent,
        REFIID  riid,
        ULONG  *pDataSize,
        void   *pDataBuffer );
    
    STDMETHODIMP_(void) ClientNotify(
        REFGUID uExtent,
        REFIID  riid,
        ULONG   cbDataSize,
        void   *pDataBuffer,
        DWORD   lDataRep,
        HRESULT hrFault );
    
    STDMETHODIMP_(void) ServerNotify(
        REFGUID uExtent,
        REFIID  riid,
        ULONG   cbDataSize,
        void   *pDataBuffer,
        DWORD   lDataRep );
    
    STDMETHODIMP_(void) ServerGetSize(
        REFGUID uExtent,
        REFIID  riid,
        HRESULT hrFault,
        ULONG  *pDataSize );
    
    STDMETHODIMP_(void) ServerFillBuffer(
        REFGUID uExtent,
        REFIID  riid,
        ULONG  *pDataSize,
        void   *pDataBuffer,
        HRESULT hrFault );

private:
    ULONG   GetSize();
    HRESULT FillBuffer(ULONG* pDataSize, void* pDataBuffer);
    HRESULT ReadBuffer(ULONG cbDataSize, void* pDataBuffer);
};

#endif //__TRACEHOOK_H_
