/* this ALWAYS GENERATED file contains the proxy stub code */


/* File created by MIDL compiler version 3.01.75 */
/* at Mon Feb 23 14:53:17 1998
 */
/* Compiler settings for tracelog.idl:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )

#include "rpcproxy.h"
#include "tracelog.h"

#define TYPE_FORMAT_STRING_SIZE   1                                 
#define PROC_FORMAT_STRING_SIZE   1                                 

typedef struct _MIDL_TYPE_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ TYPE_FORMAT_STRING_SIZE ];
    } MIDL_TYPE_FORMAT_STRING;

typedef struct _MIDL_PROC_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ PROC_FORMAT_STRING_SIZE ];
    } MIDL_PROC_FORMAT_STRING;


extern const MIDL_TYPE_FORMAT_STRING __MIDL_TypeFormatString;
extern const MIDL_PROC_FORMAT_STRING __MIDL_ProcFormatString;


/* Object interface: IUnknown, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}} */


/* Object interface: ITraceLogger, ver. 0.0,
   GUID={0x7404C591,0x823F,0x11D1,{0x96,0xAB,0x00,0x60,0x08,0x19,0xB0,0x80}} */


extern const MIDL_STUB_DESC Object_StubDesc;


#pragma code_seg(".orpc")

static const MIDL_STUB_DESC Object_StubDesc = 
    {
    0,
    NdrOleAllocate,
    NdrOleFree,
    0,
    0,
    0,
    0,
    0,
    __MIDL_TypeFormatString.Format,
    0, /* -error bounds_check flag */
    0x10001, /* Ndr library version */
    0,
    0x301004b, /* MIDL Version 3.1.75 */
    0,
    0,
    0,  /* Reserved1 */
    0,  /* Reserved2 */
    0,  /* Reserved3 */
    0,  /* Reserved4 */
    0   /* Reserved5 */
    };

const CINTERFACE_PROXY_VTABLE(3) _ITraceLoggerProxyVtbl = 
{
    &IID_ITraceLogger,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy
};


static const PRPC_STUB_FUNCTION ITraceLogger_table[] =
{
    0    /* a dummy for an empty interface */
};

const CInterfaceStubVtbl _ITraceLoggerStubVtbl =
{
    &IID_ITraceLogger,
    0,
    3,
    &ITraceLogger_table[-3],
    CStdStubBuffer_METHODS
};

#pragma data_seg(".rdata")

#if !defined(__RPC_WIN32__)
#error  Invalid build platform for this stub.
#endif

static const MIDL_PROC_FORMAT_STRING __MIDL_ProcFormatString =
    {
        0,
        {

			0x0
        }
    };

static const MIDL_TYPE_FORMAT_STRING __MIDL_TypeFormatString =
    {
        0,
        {

			0x0
        }
    };

const CInterfaceProxyVtbl * _tracelog_ProxyVtblList[] = 
{
    ( CInterfaceProxyVtbl *) &_ITraceLoggerProxyVtbl,
    0
};

const CInterfaceStubVtbl * _tracelog_StubVtblList[] = 
{
    ( CInterfaceStubVtbl *) &_ITraceLoggerStubVtbl,
    0
};

PCInterfaceName const _tracelog_InterfaceNamesList[] = 
{
    "ITraceLogger",
    0
};


#define _tracelog_CHECK_IID(n)	IID_GENERIC_CHECK_IID( _tracelog, pIID, n)

int __stdcall _tracelog_IID_Lookup( const IID * pIID, int * pIndex )
{
    
    if(!_tracelog_CHECK_IID(0))
        {
        *pIndex = 0;
        return 1;
        }

    return 0;
}

const ExtendedProxyFileInfo tracelog_ProxyFileInfo = 
{
    (PCInterfaceProxyVtblList *) & _tracelog_ProxyVtblList,
    (PCInterfaceStubVtblList *) & _tracelog_StubVtblList,
    (const PCInterfaceName * ) & _tracelog_InterfaceNamesList,
    0, // no delegation
    & _tracelog_IID_Lookup, 
    1,
    1
};
