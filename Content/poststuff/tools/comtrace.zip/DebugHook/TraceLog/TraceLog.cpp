// TraceLog.cpp : Implementation of WinMain


// Note: Proxy/Stub Information
//		To build a separate proxy/stub DLL, 
//		run nmake -f TraceLogps.mk in the project directory.

#include "stdafx.h"
#include "resource.h"
#include "initguid.h"
#include "TraceLog.h"

#include "TraceLog_i.c"
#include "TraceLogger.h"


LONG CExeModule::Unlock()
{
	LONG l = CComModule::Unlock();
	if (l == 0)
	{
#if _WIN32_WINNT >= 0x0400
		if (CoSuspendClassObjects() == S_OK)
			PostThreadMessage(dwThreadID, WM_QUIT, 0, 0);
#else
		PostThreadMessage(dwThreadID, WM_QUIT, 0, 0);
#endif
	}
	return l;
}

CExeModule _Module;

BEGIN_OBJECT_MAP(ObjectMap)
END_OBJECT_MAP()


/////////////////////////////////////////////////////////////////////////////
//
extern "C" int WINAPI _tWinMain(HINSTANCE hInstance, 
	HINSTANCE /*hPrevInstance*/, LPTSTR lpCmdLine, int /*nShowCmd*/)
{
	lpCmdLine = GetCommandLine(); //this line necessary for _ATL_MIN_CRT
	CoInitialize(0);
	_Module.Init(ObjectMap, hInstance);
	_Module.dwThreadID = GetCurrentThreadId();

    CComObject<CTraceLogger>*   pLog;
    CComObject<CTraceLogger>::CreateInstance(&pLog);
    if( pLog )
    {
        // Put trace logger into ROT while window is active
        DWORD   dwRegister;
        RegisterActiveObject(pLog->GetUnknown(), pLog->GetObjectCLSID(),
                             ACTIVEOBJECT_STRONG, &dwRegister);
        pLog->Start();

	    MSG msg;
	    while( GetMessage(&msg, 0, 0, 0) ) DispatchMessage(&msg);

        // Take trace logger out of ROT
        RevokeActiveObject(dwRegister, 0);
    }

	CoUninitialize();
	return 0;
}
