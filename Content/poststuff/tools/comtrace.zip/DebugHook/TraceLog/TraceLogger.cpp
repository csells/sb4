// TraceLogger.cpp : Implementation of CTraceLogger
#include "stdafx.h"
#include "TraceLog.h"
#include "TraceLogger.h"
#include "..\debughook_i.c"
#include <windowsx.h>

/////////////////////////////////////////////////////////////////////////////
// CTraceLogger


CTraceLogger::CTraceLogger()
:   m_wndListBox(_T("ListBox"), this, 1)
{
}

void CTraceLogger::Start()
{
	RECT rcPos = { CW_USEDEFAULT, 0, 0, 0 };
	HMENU hMenu = LoadMenu(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_MENU));
	Create(GetDesktopWindow(), rcPos, _T("Trace Logger"), WS_VISIBLE | WS_OVERLAPPEDWINDOW, 0, (UINT)hMenu);
	ShowWindow(SW_SHOWNORMAL);
}

void CTraceLogger::Stop()
{
    PostQuitMessage(0);
}

LRESULT CTraceLogger::OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	RECT rc;
	GetClientRect(&rc);
	m_wndListBox.Create(m_hWnd, rc, 0, WS_VISIBLE | WS_CHILD | WS_HSCROLL | LBS_NOINTEGRALHEIGHT | LBS_DISABLENOSCROLL);

	return 0;
}

LRESULT CTraceLogger::OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
    m_wndListBox.MoveWindow(0, 0, LOWORD(lParam), HIWORD(lParam));
	return 0;
}

LRESULT CTraceLogger::OnClear(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
    m_wndListBox.SendMessage(LB_RESETCONTENT);
    return 0;
}

LRESULT CTraceLogger::OnExit(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
    Stop();
    return 0;
}

LRESULT CTraceLogger::OnNCDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& lResult)
{
    Stop();
    return 0;
}

// ILogStackTrace
STDMETHODIMP CTraceLogger::LogStackTrace(IStackTrace* pst)
{
    long    nCount;
    pst->GetCount(&nCount);
    
    for( long nItem = 0; nItem != nCount; ++nItem )
    {
        long        nLevel;
        CComBSTR    bstrTime;
        CComBSTR    bstrMachine;
        CComBSTR    bstrProcess;
        CComBSTR    bstrServer;
        CComBSTR    bstrClass;
        CComBSTR    bstrInterface;
        CComBSTR    bstrMethod;
        CComBSTR    bstrError;
        
        pst->GetItem(nItem,
                     &nLevel,
                     &bstrTime,
                     &bstrMachine,
                     &bstrProcess,
                     &bstrServer,
                     &bstrClass,
                     &bstrInterface,
                     &bstrMethod,
                     &bstrError);
        
        wchar_t wsz[1024] = L"";

        // Pad for the level
        for( long n = 0; n != nLevel; ++n )
        {
            wcscat(wsz, L"    ");
        }

        swprintf(wsz + wcslen(wsz),
                 L"%s, %s, %s, %s, %s, %s::%s() = %s\n",
                 bstrTime,
                 bstrMachine,
                 bstrProcess,
                 bstrServer,
                 bstrClass,
                 bstrInterface,
                 bstrMethod,
                 bstrError);

        char    sz[1024]; wcstombs(sz, wsz, DIM(sz));
        m_wndListBox.SendMessage(LB_ADDSTRING, 0, (LPARAM)sz);

        // Get length of string in listbox
        HDC     hdc = m_wndListBox.GetDC();
        HFONT   hfont = m_wndListBox.GetFont();
        HFONT   hfontOld = SelectFont(hdc, hfont);
        SIZE    size; GetTextExtentPoint32(hdc, sz, strlen(sz), &size);

        SelectFont(hdc, hfontOld);
        m_wndListBox.ReleaseDC(hdc);

        // Update horizontal pixel width of listbox.
        // NOTE: This is because a listbox is too stupid to do it itself.
        long    nExtent = m_wndListBox.SendMessage(LB_GETHORIZONTALEXTENT);
        if( nExtent < size.cx )
        {
            m_wndListBox.SendMessage(LB_SETHORIZONTALEXTENT, size.cx);
        }
    }
    
    return S_OK;
}
