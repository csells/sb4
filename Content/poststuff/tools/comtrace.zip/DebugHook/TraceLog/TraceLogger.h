// TraceLogger.h : Declaration of the CTraceLogger

#ifndef __TRACELOGGER_H_
#define __TRACELOGGER_H_

#include "resource.h"       // main symbols
#include "..\debughook.h"

/////////////////////////////////////////////////////////////////////////////
// CTraceLogger
class ATL_NO_VTABLE CTraceLogger : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CTraceLogger, &CLSID_TraceLogger>,
    public CWindowImpl<CTraceLogger>,
    public ILogStackTrace
{
public:
	CTraceLogger();
	
DECLARE_NO_REGISTRY()
DECLARE_NOT_AGGREGATABLE(CTraceLogger)

BEGIN_COM_MAP(CTraceLogger)
    COM_INTERFACE_ENTRY(ILogStackTrace)
END_COM_MAP()

BEGIN_MSG_MAP(CTraceLogger)
	COMMAND_ID_HANDLER(ID_EDIT_CLEAR, OnClear)
	COMMAND_ID_HANDLER(ID_FILE_EXIT, OnExit)
	MESSAGE_HANDLER(WM_CREATE, OnCreate)
	MESSAGE_HANDLER(WM_SIZE, OnSize)
	MESSAGE_HANDLER(WM_NCDESTROY, OnNCDestroy)
ALT_MSG_MAP(1)
	// Replace this with message map entries for contained ListBox
END_MSG_MAP()

	LRESULT OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
    LRESULT OnNCDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& lResult);
    LRESULT OnClear(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
    LRESULT OnExit(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);

public:
    void    Start();
    void    Stop();

// ILogStackTrace
public:
    STDMETHODIMP LogStackTrace(IStackTrace* pst);

private:
    CContainedWindow    m_wndListBox;
};

#endif //__TRACELOGGER_H_
