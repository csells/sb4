/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 3.01.75 */
/* at Mon Feb 23 14:53:17 1998
 */
/* Compiler settings for tracelog.idl:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_ITraceLogger = {0x7404C591,0x823F,0x11D1,{0x96,0xAB,0x00,0x60,0x08,0x19,0xB0,0x80}};


const IID LIBID_TRACELOGLib = {0x7404C584,0x823F,0x11D1,{0x96,0xAB,0x00,0x60,0x08,0x19,0xB0,0x80}};


const CLSID CLSID_TraceLogger = {0x7404C592,0x823F,0x11D1,{0x96,0xAB,0x00,0x60,0x08,0x19,0xB0,0x80}};


#ifdef __cplusplus
}
#endif

