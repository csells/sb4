/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 3.01.75 */
/* at Mon Feb 23 14:52:29 1998
 */
/* Compiler settings for DebugHook.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_ISetStackTrace = {0xDCB35171,0x7A1B,0x11D1,{0xA8,0x4F,0x00,0x80,0xC7,0x66,0x7A,0xBF}};


const IID IID_IStackTrace = {0x012B9D40,0x7A21,0x11d1,{0xA8,0x4F,0x00,0x80,0xC7,0x66,0x7A,0xBF}};


const IID IID_ILogStackTrace = {0x80FB39D0,0x8239,0x11d1,{0x96,0xAA,0x00,0x60,0x08,0x19,0xB0,0x80}};


const IID LIBID_DEBUGHOOKLib = {0xDCB35164,0x7A1B,0x11D1,{0xA8,0x4F,0x00,0x80,0xC7,0x66,0x7A,0xBF}};


const CLSID CLSID_StackTrace = {0xDCB35172,0x7A1B,0x11D1,{0xA8,0x4F,0x00,0x80,0xC7,0x66,0x7A,0xBF}};


const CLSID CLSID_TraceHook = {0x8DB3BEB4,0x862E,0x11D1,{0x96,0xAC,0x00,0x60,0x08,0x19,0xB0,0x80}};


#ifdef __cplusplus
}
#endif

