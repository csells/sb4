// StackEntry.h

#ifndef STACKENTRY_H
#define STACKENTRY_H

// Generic template for types where sizeof works well
template <typename T>
HRESULT Serialize(IStream* pstm, T& r, bool bRead)
{
    DWORD   nBytes;

    if( bRead )
    {
        return pstm->Read(&r, sizeof(r), &nBytes);
    }
    else
    {
        return pstm->Write(&r, sizeof(r), &nBytes);
    }
}

// Specialization for CComBSTR
inline
HRESULT Serialize(IStream* pstm, CComBSTR& r, bool bRead)
{
    if( bRead )
    {
        return r.ReadFromStream(pstm);
    }
    else
    {
        return r.WriteToStream(pstm);
    }
}

struct StackEntry
{
    long        m_time;
    long        m_nLevel;
    CComBSTR    m_bstrMachine;
    CComBSTR    m_bstrProcess;
    CComBSTR    m_bstrServer;
    CLSID       m_clsid;
    CComBSTR    m_bstrClass;
    IID         m_iid;
    CComBSTR    m_bstrInterface;
    CComBSTR    m_bstrMethod;
    HRESULT     m_hr;

    HRESULT Serialize(IStream* pstm, bool bRead)
    {
        HR(::Serialize(pstm, m_time, bRead));
        HR(::Serialize(pstm, m_nLevel, bRead));
        HR(::Serialize(pstm, m_bstrMachine, bRead));
        HR(::Serialize(pstm, m_bstrProcess, bRead));
        HR(::Serialize(pstm, m_bstrServer, bRead));
        HR(::Serialize(pstm, m_clsid, bRead));
        HR(::Serialize(pstm, m_bstrClass, bRead));
        HR(::Serialize(pstm, m_iid, bRead));
        HR(::Serialize(pstm, m_bstrInterface, bRead));
        HR(::Serialize(pstm, m_bstrMethod, bRead));
        HR(::Serialize(pstm, m_hr, bRead));

        return S_OK;
    }

    size_t SizeMax()
    {
        // BSTR lengths are taken care off by the sizeof the CComBSTR
        return sizeof(*this) +
               (m_bstrMachine.Length() + 1 +
               m_bstrProcess.Length() + 1 +
               m_bstrServer.Length() + 1 +
               m_bstrClass.Length() + 1 +
               m_bstrInterface.Length() + 1 +
               m_bstrMethod.Length() + 1) * sizeof(OLECHAR);
    }
};

inline
bool operator<(const StackEntry& lhs, const StackEntry& rhs)
{
    return lhs.m_time < rhs.m_time;
}

inline
bool operator==(const StackEntry& lhs, const StackEntry& rhs)
{
    return &lhs == &rhs;
}

#endif  // STACKENTRY_H