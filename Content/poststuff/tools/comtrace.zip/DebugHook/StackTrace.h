// StackTrace.h : Declaration of the CStackTrace

#ifndef __STACKTRACE_H_
#define __STACKTRACE_H_

#include "resource.h"       // main symbols
#include "StackEntry.h"
#include <vector>
using namespace std;

/////////////////////////////////////////////////////////////////////////////
// CStackTrace
class ATL_NO_VTABLE CStackTrace : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CStackTrace, &CLSID_StackTrace>,
	public IStackTrace,
	public ISetStackTrace,
    public IMarshal
{
public:
    CStackTrace();

DECLARE_REGISTRY_RESOURCEID(IDR_STACKTRACE)
DECLARE_NOT_AGGREGATABLE(CStackTrace)

BEGIN_COM_MAP(CStackTrace)
	COM_INTERFACE_ENTRY(IStackTrace)
	COM_INTERFACE_ENTRY(ISetStackTrace)
	COM_INTERFACE_ENTRY(IMarshal)
END_COM_MAP()

// IMarshal
    STDMETHODIMP GetUnmarshalClass
    (
        REFIID riid,
        void *pv,
        DWORD dwDestContext,
        void *pvDestContext,
        DWORD mshlflags,
        CLSID *pCid
    );

    STDMETHODIMP GetMarshalSizeMax
    (
        REFIID riid,
        void *pv,
        DWORD dwDestContext,
        void *pvDestContext,
        DWORD mshlflags,
        DWORD *pSize
    );

    STDMETHODIMP MarshalInterface
    (
        IStream *pStm,
        REFIID riid,
        void *pv,
        DWORD dwDestContext,
        void *pvDestContext,
        DWORD mshlflags
    );

    STDMETHODIMP UnmarshalInterface
    (
        IStream *pStm,
        REFIID riid,
        void **ppv
    );

    STDMETHODIMP ReleaseMarshalData
    (
        IStream *pStm
    );

    STDMETHODIMP DisconnectObject
    (
        DWORD dwReserved
    );

// ISetStackTrace
public:
    STDMETHODIMP get_Level(long* pnLevel);
    STDMETHODIMP put_Level(long nLevel);
    STDMETHODIMP AtOriginator();
    STDMETHODIMP AppendStackEntry(long nTime,
                                  LPCOLESTR pszServer,
                                  REFCLSID clsid,
                                  REFIID iid,
                                  LPCOLESTR pszMethod,
                                  HRESULT hr);

// IStackTrace
public:
    STDMETHODIMP GetCausality(BSTR* pbstrCausality);
    STDMETHODIMP GetCount(long* pnCount);
    STDMETHODIMP GetItem(long nItem,
                         long* pnLevel,
                         BSTR* pbstrTime,
                         BSTR* pbstrMachine,
                         BSTR* pbstrProcess,
                         BSTR* pbstrServer,
                         BSTR* pbstrClass,
                         BSTR* pbstrInterface,
                         BSTR* pbstrMethod,
                         BSTR* pbstrError);

private:
    typedef vector<StackEntry> StackEntryList;

    long            m_nLevel;
    StackEntryList  m_listEntries;

    HRESULT Serialize(IStream* pstm, bool bRead);
};

#endif //__STACKTRACE_H_
