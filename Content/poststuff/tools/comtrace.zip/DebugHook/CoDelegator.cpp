/////////////////////////////////////////////////////////////
// CoDelegator.cpp - Generic Delegator Component
//
// Copyright 1997, Keith Brown
//
// The CoDelegator class implements a standard non-delegating
// unknown and caches interface pointers lazily as they
// are asked for by the outer object.
// Each new interface pointer is wrapped by a Delegator
// object and refcounted individually, until the refcount
// on the interface drops to zero, at which time it is
// released and removed from the collection.
/////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "CoDelegator.h"
#include "Delegator.h"

DWORD g_nDelegatorTLSIndex = 0xFFFFFFFF;

extern bool LookupInterface( REFIID iid, wchar_t* pszName, int cchMax );

//---------------------------------------------------------------------------//
CoDelegator::CoDelegator( IUnknown* pUnkOuter, IUnknown* pUnkInner,
	const wchar_t* pszObjectName )
  : m_cRefs( 0 ),
	m_pUnkOuter( pUnkOuter ? pUnkOuter : this ),
	m_pUnkInner( pUnkInner ),
	m_first( 0 ),
	m_last( 0 ),
	m_end( 0 ),
	m_clsid( CLSID_NULL ),
	m_pszObjectName( 0 ),
	m_pTypeLib( 0 )
{
	InitializeCriticalSection( &m_sect );
	m_pUnkInner->AddRef();
	if ( pszObjectName )
	{
		int cch = lstrlenW( pszObjectName ) + 1;
		m_pszObjectName = new wchar_t[cch];
		if ( m_pszObjectName )
			CopyMemory( m_pszObjectName, pszObjectName, cch * sizeof *m_pszObjectName );
	}

	// Obtain required interfaces from object, attempting to use IMultiQI if available
	IProvideClassInfo* pProvideClassInfo = 0;
	IPersist* pPersist = 0;
	IDispatch* pDispatch = 0;
	{
		IMultiQI* pmqi = 0;
		HRESULT hrMQI = m_pUnkInner->QueryInterface( IID_IMultiQI, reinterpret_cast<void**>( &pmqi ) );
		if ( SUCCEEDED( hrMQI ) )
		{
			MULTI_QI rgmqi[] = { { &IID_IProvideClassInfo }, { &IID_IPersist }, { &IID_IDispatch } };
			hrMQI = pmqi->QueryMultipleInterfaces( sizeof rgmqi / sizeof *rgmqi, rgmqi );
			if ( SUCCEEDED( hrMQI ) )
			{
				if ( SUCCEEDED( rgmqi[0].hr ) )
					pProvideClassInfo	= reinterpret_cast<IProvideClassInfo*>	( rgmqi[0].pItf );
				if ( SUCCEEDED( rgmqi[1].hr ) )
					pPersist			= reinterpret_cast<IPersist*>			( rgmqi[1].pItf );
				if ( SUCCEEDED( rgmqi[2].hr ) )
					pDispatch			= reinterpret_cast<IDispatch*>			( rgmqi[2].pItf );
			}
			pmqi->Release();
		}
		else
		{
			HRESULT hrQI = m_pUnkInner->QueryInterface( IID_IProvideClassInfo, reinterpret_cast<void**>( &pProvideClassInfo ) );
			if ( FAILED( hrQI ) )
				pProvideClassInfo = 0;
			hrQI = m_pUnkInner->QueryInterface( IID_IPersist, reinterpret_cast<void**>( &pPersist ) );
			if ( FAILED( hrQI ) )
				pPersist = 0;
			hrQI = m_pUnkInner->QueryInterface( IID_IDispatch, reinterpret_cast<void**>( &pDispatch ) );
			if ( FAILED( hrQI ) )
				pDispatch = 0;
		}
	}


	// try to find clsid of inner object via IProvideClassInfo
	// (do this first 'cause we need the typelib anyway)
	HRESULT hr = S_OK;
	bool bFoundCLSID = false;
	if ( pProvideClassInfo )
	{
		ITypeInfo* pti = 0;
		hr = pProvideClassInfo->GetClassInfo( &pti );
		if ( SUCCEEDED( hr ) )
		{
			// grab the clsid
			TYPEATTR* pta = 0;
			hr = pti->GetTypeAttr( &pta );
			if ( SUCCEEDED( hr ) )
			{
				m_clsid = pta->guid;
				bFoundCLSID = true;
				pti->ReleaseTypeAttr( pta );
			}
		
			// while we're here, grab the typelib as well
			_cacheTypeLibFromTypeInfo( pti );
			pti->Release();
		}
	}

	// try to find clsid of inner object via IPersist
	if ( !bFoundCLSID && pPersist )
		pPersist->GetClassID( &m_clsid );

	// try IDispatch as a last resort for a typelib
	if ( !m_pTypeLib && pDispatch )
	{
		UINT nIndex = 0;
		hr = pDispatch->GetTypeInfoCount( &nIndex );
		if ( 1 == nIndex )
		{
			ITypeInfo* pti = 0;
			hr = pDispatch->GetTypeInfo( 1, 0, &pti );
			if ( SUCCEEDED( hr ) )
			{
				_cacheTypeLibFromTypeInfo( pti );
				pti->Release();
			}
		}
	}

	if ( pProvideClassInfo )
		pProvideClassInfo->Release();
	if ( pPersist )
		pPersist->Release();
	if ( pDispatch )
		pDispatch->Release();
}

//---------------------------------------------------------------------------//
CoDelegator::~CoDelegator()
{
	if ( m_pTypeLib )
		m_pTypeLib->Release();

	delete m_pszObjectName;

	for ( Delegator** it = m_first; it != m_last; ++it )
		delete *it;
	delete m_first;

	m_pUnkInner->Release();
	DeleteCriticalSection( &m_sect );
}

//---------------------------------------------------------------------------//
void CoDelegator::DeleteDelegator( Delegator* pDelegator )
{
	Lock lock( *this );
	
	for ( Delegator** it = m_first; m_last != it; ++it )
	{
		if ( *it == pDelegator )
		{
			delete *it;
			while ( ++it != m_last )
				*(it - 1) = *it;
			--m_last;
			break;
		}
	}
}

//---------------------------------------------------------------------------//
HRESULT CoDelegator::_growArray()
{
	size_t capacity = 2 * (m_end - m_first);
	if ( 0 == capacity )	
		capacity = INITIAL_CAPACITY;
	
	Delegator** first = new Delegator*[capacity];
	if ( !first )
		return E_OUTOFMEMORY;
	
	Delegator** dest = first;
	for ( Delegator** it = m_first; it != m_last; ++it )
		*dest++ = *it;

	m_last = first + (m_last - m_first);
	m_end = first + capacity;
	delete m_first;
	m_first = first;
	
	return S_OK;
}

//---------------------------------------------------------------------------//
void CoDelegator::_cacheTypeLibFromTypeInfo( ITypeInfo* pti )
{
	ITypeLib* ptlb = 0;
	UINT nIndex = 0;
	if ( SUCCEEDED( pti->GetContainingTypeLib( &ptlb, &nIndex ) ) )
		m_pTypeLib = ptlb;
}	

//---------------------------------------------------------------------------//
bool CoDelegator::_loadTypeLibFromRegistry( REFIID iid )
{
	// assumption: delegator has already acquired m_sect
	// assumption: m_pTypeLib == 0

	// if all else fails, try to find local typelib via HKCR/Interface/TypeLib registry entry
	TCHAR szTypelibKey[128];
	{
		#ifdef UNICODE
		wchar_t* wszIID = szTypelibKey;
		#else
		wchar_t wszIID[60];
		#endif

		StringFromGUID2( iid, wszIID, sizeof wszIID / sizeof *wszIID );

		#ifdef UNICODE
		TCHAR* pszIID = wszIID;
		#else
		TCHAR szIID[60];
		wcstombs( szIID, wszIID, sizeof szIID );
		TCHAR* pszIID = szIID;
		#endif
		
		wsprintf( szTypelibKey, __TEXT( "Interface\\%s\\TypeLib" ), pszIID );
	}
	HKEY hkeyTypelib = 0;
	DWORD dwErr = RegOpenKeyEx( HKEY_CLASSES_ROOT, szTypelibKey, 0, KEY_QUERY_VALUE, &hkeyTypelib );
	if ( ERROR_SUCCESS == dwErr )
	{
		TCHAR szLibid[128];
		DWORD cchLibid = sizeof szLibid / sizeof *szLibid;
		TCHAR szVer[128];
		DWORD cchVer = sizeof szVer / sizeof *szVer;
		dwErr = RegQueryValueEx( hkeyTypelib, __TEXT( "" ), 0, 0, reinterpret_cast<BYTE*>( szLibid ), &cchLibid );
		if ( ERROR_SUCCESS == dwErr )
			dwErr = RegQueryValueEx( hkeyTypelib, __TEXT( "Version" ), 0, 0, reinterpret_cast<BYTE*>( szVer ), &cchVer );
		RegCloseKey( hkeyTypelib );
		hkeyTypelib = 0;

		if ( ERROR_SUCCESS == dwErr )
		{
			GUID libid;
			#ifdef UNICODE
			wchar_t* pszLibid = szLibid;
			#else
			wchar_t wszLibid[60];
			mbstowcs( wszLibid, szLibid, sizeof wszLibid / sizeof *wszLibid );
			wchar_t* pszLibid = wszLibid;
			#endif

			HRESULT hr = CLSIDFromString( pszLibid, &libid );

			unsigned short nMajorVer = 0;
			unsigned short nMinorVer = 0;
			if ( SUCCEEDED( hr ) )
			{
				// parse version of library
				TCHAR* psz = szVer;
				bool bFoundMajorVer = false;
				while ( *psz )
				{
					if ( __TEXT( '.' ) == *psz )
					{
						*psz++ = __TEXT( '\0' );
						nMajorVer = _ttoi( szVer );
						bFoundMajorVer = true;
						break;
					}
					++psz;
				}
				if ( bFoundMajorVer && *psz )
					nMinorVer = _ttoi( psz );
				if ( !bFoundMajorVer )
					hr = E_FAIL;
			}
			if ( SUCCEEDED( hr ) )
			{
				// try the following common lcids, one after the other.
				hr = E_FAIL;
				ITypeLib* ptlb = 0;
				LCID lcid[] = { 0, 9, 409 };
				int cLangs = sizeof lcid / sizeof *lcid;
				for ( int i = 0; i < cLangs && FAILED( hr ); ++i )
					hr = LoadRegTypeLib( libid, nMajorVer, nMinorVer, lcid[i], &ptlb );

				if ( SUCCEEDED( hr ) )
				{
					m_pTypeLib = ptlb;
					ptlb = 0;
				}
			}
		}
	}
	return m_pTypeLib ? true : false;
}

//---------------------------------------------------------------------------//
STDMETHODIMP CoDelegator::QueryInterface( REFIID iid, void** ppv )
{
	// we subsume the identity of the inner
	if ( IID_IUnknown == iid )
	{
		((IUnknown*)(*ppv = (IUnknown*)this))->AddRef();
		return S_OK;
	}

	*ppv = 0;

	Lock lock( *this );

	// see if we've already assimilated the requested interface
	for ( Delegator** it = m_first; it != m_last; ++it )
	{
		if ( (*it)->m_iid == iid )
		{
			*ppv = (IUnknown*)*it;
			((IUnknown*)(*ppv))->AddRef();
			return S_OK;
		}
	}

	// go get the requested interface from the inner and assimilate it.
	IUnknown* pUnkInner = 0;
	HRESULT hr = m_pUnkInner->QueryInterface( iid, (void**)&pUnkInner );
	if ( SUCCEEDED( hr ) )
	{
		// grow the array if necessary
		if ( m_last == m_end )
			hr = _growArray();
		
		if ( SUCCEEDED( hr ) )
		{
			Delegator* pDelegator = new Delegator( *this, pUnkInner, iid );
			if ( pDelegator )
			{
				*m_last++ = pDelegator;
				((IUnknown*)(*ppv = pDelegator))->AddRef();
			}
			else hr = E_OUTOFMEMORY;
		}
		pUnkInner->Release();
	}
	return hr;
}

//---------------------------------------------------------------------------//
STDMETHODIMP_(ULONG) CoDelegator::AddRef()
{
	if ( 0 == m_cRefs )
		_Module.Lock();
	return InterlockedIncrement( &m_cRefs );
}

//---------------------------------------------------------------------------//
STDMETHODIMP_(ULONG) CoDelegator::Release()
{
	ULONG n = InterlockedDecrement( &m_cRefs );
	if ( 0 != n )
		return n;
	delete this;
	_Module.Unlock();
	return 0;
}

//---------------------------------------------------------------------------//
STDAPI CreateTraceDelegator( IUnknown* pUnkOuter, IUnknown* pUnkInner,
	const OLECHAR* pszObjectName, REFIID iid, void** ppv )
{
	*ppv = 0;

	// lazily allocate delegator's private TLS slot
	if ( 0xFFFFFFFF == g_nDelegatorTLSIndex )
		g_nDelegatorTLSIndex = TlsAlloc();

	if ( 0xFFFFFFFF == g_nDelegatorTLSIndex )
		return E_OUTOFMEMORY; // seems reasonable...

	// must pass at least an inner
	// (in this TraceDelegator version, passing NULL for pUnkOuter is typical)
	if ( !pUnkInner )
		return E_UNEXPECTED;
	CoDelegator* p = new CoDelegator( pUnkOuter, pUnkInner, pszObjectName );
	if ( !p )
		return E_OUTOFMEMORY;
	p->AddRef();
	HRESULT hr = p->QueryInterface( iid, ppv );
	p->Release();
	return hr;
}
