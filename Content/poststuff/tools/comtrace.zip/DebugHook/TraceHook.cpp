// TraceHook.cpp : Implementation of CTraceHook
#include "stdafx.h"
#include "DebugHook.h"
#include "TraceHook.h"
#include "StackTraceAccess.h"

/////////////////////////////////////////////////////////////////////////////
// CTraceHook

CTraceHook::CTraceHook()
{
}

ULONG CTraceHook::GetSize()
{
    ULONG   nDataSize = 0;

    // If there is no stack trace, create one
    // (May be the first call, but out-of-proc)
    SIP(IStackTrace)    spst;
    GetStackTrace(&spst);

    if( spst )
    {
        CoGetMarshalSizeMax(&nDataSize, IID_IStackTrace, spst,
                            MSHCTX_DIFFERENTMACHINE, 0, MSHLFLAGS_NORMAL);

        // Restore current stack trace
        SetStackTrace(spst);
    }

    return nDataSize;
}

HRESULT CTraceHook::FillBuffer(
    ULONG  *pDataSize,
    void   *pDataBuffer)
{
    HRESULT hr = S_FALSE;
    *pDataSize = 0;

    // Get current stack trace
    SIP(IStackTrace)    spst;
    if( GetStackTrace(&spst) == S_OK )
    {
        // Marshal stack trace into a stream
        SIP(IStream)    spstm;
        hr = CreateStreamOnHGlobal(0, TRUE, &spstm);
        if( spstm )
        {
            hr = CoMarshalInterface(spstm, IID_IStackTrace, spst,
                                    MSHCTX_DIFFERENTMACHINE, 0, MSHLFLAGS_NORMAL);

            // Hand back the bytes
            if( SUCCEEDED(hr) )
            {
                HGLOBAL hg = 0;
                hr = GetHGlobalFromStream(spstm, &hg);

                STATSTG ss;
                hr = spstm->Stat(&ss, STATFLAG_DEFAULT);

                *pDataSize = ss.cbSize.LowPart;
                void*   pv = GlobalLock(hg);
                memcpy(pDataBuffer, pv, *pDataSize);
                GlobalUnlock(hg);
            }
        }
    }

    return hr;
}

HRESULT CTraceHook::ReadBuffer(
    ULONG   cbDataSize,
    void   *pDataBuffer)
{
    HRESULT hr = E_OUTOFMEMORY;

    // Allocate global memory for data
    HGLOBAL hg = GlobalAlloc(GPTR, cbDataSize);
    if( hg )
    {
        void*   pv = GlobalLock(hg);
        memcpy(pv, pDataBuffer, cbDataSize);
        GlobalUnlock(hg);

        // Create stream around data
        SIP(IStream)    spstm;
        hr = CreateStreamOnHGlobal(hg, TRUE, &spstm);
        if( spstm )
        {
            HRESULT             hr;
            SIP(IStackTrace)    spst;
            
            // Pull stack trace out of data buffer
            hr = CoUnmarshalInterface(spstm, IID_IStackTrace, (void**)&spst);
            if( SUCCEEDED(hr) )
            {
                SetStackTrace(spst);
            }
        }
    }

    return hr;
}

STDMETHODIMP_(void) CTraceHook::ClientGetSize(
    REFGUID uExtent,
    REFIID  riid,
    ULONG  *pDataSize)
{
    // Get the size of the current stack trace object
    *pDataSize = this->GetSize();
}

STDMETHODIMP_(void) CTraceHook::ClientFillBuffer(
    REFGUID uExtent,
    REFIID  riid,
    ULONG  *pDataSize,
    void   *pDataBuffer)
{
    // Marshal the stack trace object into the RPCTHIS
    if( pDataBuffer ) this->FillBuffer(pDataSize, pDataBuffer);
}

STDMETHODIMP_(void) CTraceHook::ClientNotify(
    REFGUID uExtent,
    REFIID  riid,
    ULONG   cbDataSize,
    void   *pDataBuffer,
    DWORD   lDataRep,
    HRESULT hrFault)
{
    // Unmarshal the stack trace object from the RPCTHAT
    if( pDataBuffer ) this->ReadBuffer(cbDataSize, pDataBuffer);
}

STDMETHODIMP_(void) CTraceHook::ServerNotify(
    REFGUID uExtent,
    REFIID  riid,
    ULONG   cbDataSize,
    void   *pDataBuffer,
    DWORD   lDataRep)
{
    // Unmarshal the stack trace object from the RPCTHIS
    if( pDataBuffer ) this->ReadBuffer(cbDataSize, pDataBuffer);
}

STDMETHODIMP_(void) CTraceHook::ServerGetSize(
    REFGUID uExtent,
    REFIID  riid,
    HRESULT hrFault,
    ULONG  *pDataSize)
{
    // Get the size of the current stack trace object
    *pDataSize = this->GetSize();
}

STDMETHODIMP_(void) CTraceHook::ServerFillBuffer(
    REFGUID uExtent,
    REFIID  riid,
    ULONG  *pDataSize,
    void   *pDataBuffer,
    HRESULT hrFault)
{
    // Marshal the stack trace object into the RPCTHAT
    if( pDataBuffer ) this->FillBuffer(pDataSize, pDataBuffer);
}
