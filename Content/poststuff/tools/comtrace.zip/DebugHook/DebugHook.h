/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 3.01.75 */
/* at Mon Feb 23 14:52:29 1998
 */
/* Compiler settings for DebugHook.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )
#include "rpc.h"
#include "rpcndr.h"
#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __DebugHook_h__
#define __DebugHook_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __ISetStackTrace_FWD_DEFINED__
#define __ISetStackTrace_FWD_DEFINED__
typedef interface ISetStackTrace ISetStackTrace;
#endif 	/* __ISetStackTrace_FWD_DEFINED__ */


#ifndef __IStackTrace_FWD_DEFINED__
#define __IStackTrace_FWD_DEFINED__
typedef interface IStackTrace IStackTrace;
#endif 	/* __IStackTrace_FWD_DEFINED__ */


#ifndef __ILogStackTrace_FWD_DEFINED__
#define __ILogStackTrace_FWD_DEFINED__
typedef interface ILogStackTrace ILogStackTrace;
#endif 	/* __ILogStackTrace_FWD_DEFINED__ */


#ifndef __StackTrace_FWD_DEFINED__
#define __StackTrace_FWD_DEFINED__

#ifdef __cplusplus
typedef class StackTrace StackTrace;
#else
typedef struct StackTrace StackTrace;
#endif /* __cplusplus */

#endif 	/* __StackTrace_FWD_DEFINED__ */


#ifndef __ILogStackTrace_FWD_DEFINED__
#define __ILogStackTrace_FWD_DEFINED__
typedef interface ILogStackTrace ILogStackTrace;
#endif 	/* __ILogStackTrace_FWD_DEFINED__ */


#ifndef __TraceHook_FWD_DEFINED__
#define __TraceHook_FWD_DEFINED__

#ifdef __cplusplus
typedef class TraceHook TraceHook;
#else
typedef struct TraceHook TraceHook;
#endif /* __cplusplus */

#endif 	/* __TraceHook_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __ISetStackTrace_INTERFACE_DEFINED__
#define __ISetStackTrace_INTERFACE_DEFINED__

/****************************************
 * Generated header for interface: ISetStackTrace
 * at Mon Feb 23 14:52:29 1998
 * using MIDL 3.01.75
 ****************************************/
/* [object][local][unique][helpstring][uuid] */ 



EXTERN_C const IID IID_ISetStackTrace;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    interface DECLSPEC_UUID("DCB35171-7A1B-11D1-A84F-0080C7667ABF")
    ISetStackTrace : public IUnknown
    {
    public:
        virtual /* [propget] */ HRESULT STDMETHODCALLTYPE get_Level( 
            /* [retval][out] */ long __RPC_FAR *pnLevel) = 0;
        
        virtual /* [propput] */ HRESULT STDMETHODCALLTYPE put_Level( 
            /* [in] */ long nLevel) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE AppendStackEntry( 
            /* [in] */ long nTime,
            /* [in] */ LPCOLESTR pszServer,
            /* [in] */ REFCLSID clsid,
            /* [in] */ REFIID iid,
            /* [in] */ LPCOLESTR pszMethod,
            /* [in] */ HRESULT hr) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISetStackTraceVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ISetStackTrace __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ISetStackTrace __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ISetStackTrace __RPC_FAR * This);
        
        /* [propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Level )( 
            ISetStackTrace __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pnLevel);
        
        /* [propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Level )( 
            ISetStackTrace __RPC_FAR * This,
            /* [in] */ long nLevel);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AppendStackEntry )( 
            ISetStackTrace __RPC_FAR * This,
            /* [in] */ long nTime,
            /* [in] */ LPCOLESTR pszServer,
            /* [in] */ REFCLSID clsid,
            /* [in] */ REFIID iid,
            /* [in] */ LPCOLESTR pszMethod,
            /* [in] */ HRESULT hr);
        
        END_INTERFACE
    } ISetStackTraceVtbl;

    interface ISetStackTrace
    {
        CONST_VTBL struct ISetStackTraceVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISetStackTrace_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISetStackTrace_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISetStackTrace_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISetStackTrace_get_Level(This,pnLevel)	\
    (This)->lpVtbl -> get_Level(This,pnLevel)

#define ISetStackTrace_put_Level(This,nLevel)	\
    (This)->lpVtbl -> put_Level(This,nLevel)

#define ISetStackTrace_AppendStackEntry(This,nTime,pszServer,clsid,iid,pszMethod,hr)	\
    (This)->lpVtbl -> AppendStackEntry(This,nTime,pszServer,clsid,iid,pszMethod,hr)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [propget] */ HRESULT STDMETHODCALLTYPE ISetStackTrace_get_Level_Proxy( 
    ISetStackTrace __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pnLevel);


void __RPC_STUB ISetStackTrace_get_Level_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput] */ HRESULT STDMETHODCALLTYPE ISetStackTrace_put_Level_Proxy( 
    ISetStackTrace __RPC_FAR * This,
    /* [in] */ long nLevel);


void __RPC_STUB ISetStackTrace_put_Level_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ISetStackTrace_AppendStackEntry_Proxy( 
    ISetStackTrace __RPC_FAR * This,
    /* [in] */ long nTime,
    /* [in] */ LPCOLESTR pszServer,
    /* [in] */ REFCLSID clsid,
    /* [in] */ REFIID iid,
    /* [in] */ LPCOLESTR pszMethod,
    /* [in] */ HRESULT hr);


void __RPC_STUB ISetStackTrace_AppendStackEntry_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISetStackTrace_INTERFACE_DEFINED__ */


#ifndef __IStackTrace_INTERFACE_DEFINED__
#define __IStackTrace_INTERFACE_DEFINED__

/****************************************
 * Generated header for interface: IStackTrace
 * at Mon Feb 23 14:52:29 1998
 * using MIDL 3.01.75
 ****************************************/
/* [object][oleautomation][local][unique][helpstring][uuid] */ 



EXTERN_C const IID IID_IStackTrace;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    interface DECLSPEC_UUID("012B9D40-7A21-11d1-A84F-0080C7667ABF")
    IStackTrace : public IUnknown
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE GetCount( 
            /* [retval][out] */ long __RPC_FAR *pnCount) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetItem( 
            /* [in] */ long nItem,
            /* [out] */ long __RPC_FAR *pnLevel,
            /* [out] */ BSTR __RPC_FAR *pbstrTime,
            /* [out] */ BSTR __RPC_FAR *pbstrMachine,
            /* [out] */ BSTR __RPC_FAR *pbstrProcess,
            /* [out] */ BSTR __RPC_FAR *pbstrServer,
            /* [out] */ BSTR __RPC_FAR *pbstrClass,
            /* [out] */ BSTR __RPC_FAR *pbstrInterface,
            /* [out] */ BSTR __RPC_FAR *pbstrMethod,
            /* [out] */ BSTR __RPC_FAR *pbstrError) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IStackTraceVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IStackTrace __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IStackTrace __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IStackTrace __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetCount )( 
            IStackTrace __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pnCount);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetItem )( 
            IStackTrace __RPC_FAR * This,
            /* [in] */ long nItem,
            /* [out] */ long __RPC_FAR *pnLevel,
            /* [out] */ BSTR __RPC_FAR *pbstrTime,
            /* [out] */ BSTR __RPC_FAR *pbstrMachine,
            /* [out] */ BSTR __RPC_FAR *pbstrProcess,
            /* [out] */ BSTR __RPC_FAR *pbstrServer,
            /* [out] */ BSTR __RPC_FAR *pbstrClass,
            /* [out] */ BSTR __RPC_FAR *pbstrInterface,
            /* [out] */ BSTR __RPC_FAR *pbstrMethod,
            /* [out] */ BSTR __RPC_FAR *pbstrError);
        
        END_INTERFACE
    } IStackTraceVtbl;

    interface IStackTrace
    {
        CONST_VTBL struct IStackTraceVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IStackTrace_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IStackTrace_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IStackTrace_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IStackTrace_GetCount(This,pnCount)	\
    (This)->lpVtbl -> GetCount(This,pnCount)

#define IStackTrace_GetItem(This,nItem,pnLevel,pbstrTime,pbstrMachine,pbstrProcess,pbstrServer,pbstrClass,pbstrInterface,pbstrMethod,pbstrError)	\
    (This)->lpVtbl -> GetItem(This,nItem,pnLevel,pbstrTime,pbstrMachine,pbstrProcess,pbstrServer,pbstrClass,pbstrInterface,pbstrMethod,pbstrError)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IStackTrace_GetCount_Proxy( 
    IStackTrace __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pnCount);


void __RPC_STUB IStackTrace_GetCount_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IStackTrace_GetItem_Proxy( 
    IStackTrace __RPC_FAR * This,
    /* [in] */ long nItem,
    /* [out] */ long __RPC_FAR *pnLevel,
    /* [out] */ BSTR __RPC_FAR *pbstrTime,
    /* [out] */ BSTR __RPC_FAR *pbstrMachine,
    /* [out] */ BSTR __RPC_FAR *pbstrProcess,
    /* [out] */ BSTR __RPC_FAR *pbstrServer,
    /* [out] */ BSTR __RPC_FAR *pbstrClass,
    /* [out] */ BSTR __RPC_FAR *pbstrInterface,
    /* [out] */ BSTR __RPC_FAR *pbstrMethod,
    /* [out] */ BSTR __RPC_FAR *pbstrError);


void __RPC_STUB IStackTrace_GetItem_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IStackTrace_INTERFACE_DEFINED__ */


#ifndef __ILogStackTrace_INTERFACE_DEFINED__
#define __ILogStackTrace_INTERFACE_DEFINED__

/****************************************
 * Generated header for interface: ILogStackTrace
 * at Mon Feb 23 14:52:29 1998
 * using MIDL 3.01.75
 ****************************************/
/* [object][oleautomation][unique][helpstring][uuid] */ 



EXTERN_C const IID IID_ILogStackTrace;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    interface DECLSPEC_UUID("80FB39D0-8239-11d1-96AA-00600819B080")
    ILogStackTrace : public IUnknown
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE LogStackTrace( 
            /* [in] */ IStackTrace __RPC_FAR *pst) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ILogStackTraceVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ILogStackTrace __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ILogStackTrace __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ILogStackTrace __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *LogStackTrace )( 
            ILogStackTrace __RPC_FAR * This,
            /* [in] */ IStackTrace __RPC_FAR *pst);
        
        END_INTERFACE
    } ILogStackTraceVtbl;

    interface ILogStackTrace
    {
        CONST_VTBL struct ILogStackTraceVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ILogStackTrace_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ILogStackTrace_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ILogStackTrace_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ILogStackTrace_LogStackTrace(This,pst)	\
    (This)->lpVtbl -> LogStackTrace(This,pst)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ILogStackTrace_LogStackTrace_Proxy( 
    ILogStackTrace __RPC_FAR * This,
    /* [in] */ IStackTrace __RPC_FAR *pst);


void __RPC_STUB ILogStackTrace_LogStackTrace_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ILogStackTrace_INTERFACE_DEFINED__ */



#ifndef __DEBUGHOOKLib_LIBRARY_DEFINED__
#define __DEBUGHOOKLib_LIBRARY_DEFINED__

/****************************************
 * Generated header for library: DEBUGHOOKLib
 * at Mon Feb 23 14:52:29 1998
 * using MIDL 3.01.75
 ****************************************/
/* [helpstring][version][uuid] */ 




EXTERN_C const IID LIBID_DEBUGHOOKLib;

#ifdef __cplusplus
EXTERN_C const CLSID CLSID_StackTrace;

class DECLSPEC_UUID("DCB35172-7A1B-11D1-A84F-0080C7667ABF")
StackTrace;
#endif

#ifdef __cplusplus
EXTERN_C const CLSID CLSID_TraceHook;

class DECLSPEC_UUID("8DB3BEB4-862E-11D1-96AC-00600819B080")
TraceHook;
#endif
#endif /* __DEBUGHOOKLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
