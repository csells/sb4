// ComTrace.h

#ifndef COMTRACE_H
#define COMTRACE_H

#ifdef _DEBUG
#define COMTRACE(name, iid, pitf) ComTrace(name, iid, (void**)&pitf)
#else
#define COMTRACE(name, iid, pitf) S_OK
#endif  // _DEBUG

STDAPI ComTrace(const OLECHAR* pszObjectName, REFIID iid, void** ppv);

#endif  // COMTRACE_H
