// StackTrace.cpp : Implementation of CStackTrace
#include "stdafx.h"
#include "DebugHook.h"
#include "StackTrace.h"
#include <time.h>
#include <winsock.h>
#include <ctype.h>

/////////////////////////////////////////////////////////////////////////////
// CStackTrace

CStackTrace::CStackTrace()
:   m_nLevel(0) // The client is level 0
{
}

// IMarshal
STDMETHODIMP CStackTrace::GetUnmarshalClass
(
    REFIID riid,
    void *pv,
    DWORD dwDestContext,
    void *pvDestContext,
    DWORD mshlflags,
    CLSID *pCid
)
{
    return *pCid = GetObjectCLSID(), S_OK;
}

STDMETHODIMP CStackTrace::GetMarshalSizeMax
(
    REFIID riid,
    void *pv,
    DWORD dwDestContext,
    void *pvDestContext,
    DWORD mshlflags,
    DWORD *pSize
)
{
    *pSize = sizeof(m_nLevel) + // Current level
             sizeof(long);      // Count of items

    for( StackEntryList::iterator i = m_listEntries.begin(); i != m_listEntries.end(); ++i )
    {
        *pSize += i->SizeMax();
    }

    return S_OK;
}

DWORD GetStreamSize(IStream* pstm)
{
    STATSTG ss;
    if( SUCCEEDED(pstm->Stat(&ss, STATFLAG_DEFAULT)) )
    {
        return ss.cbSize.LowPart;
    }
    
    return 0;
}

DWORD GetStreamOffset(IStream* pstm)
{
    LARGE_INTEGER   li = { 0 };
    ULARGE_INTEGER  uli = { 0 };
    pstm->Seek(li, STREAM_SEEK_CUR, &uli);
    return uli.LowPart;
}

HRESULT CStackTrace::Serialize(IStream* pstm, bool bRead)
{
    // NOTE: Read and write in a platform specific way
    HR(::Serialize(pstm, m_nLevel, bRead));

    long    nEntries = m_listEntries.size();
    HR(::Serialize(pstm, nEntries, bRead));

    if( bRead )
    {
        for( long n = 0; n != nEntries; ++n )
        {
            StackEntry   e;
            HR(e.Serialize(pstm, true));
            m_listEntries.push_back(e);
        }
    }
    else
    {
        DWORD   nStreamSize = GetStreamSize(pstm);

        for( StackEntryList::iterator i = m_listEntries.begin(); i != m_listEntries.end(); ++i )
        {
            DWORD   nPreOffset = GetStreamOffset(pstm);
            DWORD   nEntrySizeMax = i->SizeMax();

            HR(i->Serialize(pstm, false));

            DWORD   nPostOffset = GetStreamOffset(pstm);
            DWORD   nEntrySize = nPostOffset - nPreOffset;
            if( nEntrySize > nEntrySizeMax )
            {
                OutputDebugString("Entry size beyond max!\n");
            }
        }
    }

    return S_OK;
}

STDMETHODIMP CStackTrace::MarshalInterface
(
    IStream *pStm,
    REFIID riid,
    void *pv,
    DWORD dwDestContext,
    void *pvDestContext,
    DWORD mshlflags
)
{
    return this->Serialize(pStm, false);
}

STDMETHODIMP CStackTrace::UnmarshalInterface
(
    IStream *pStm,
    REFIID riid,
    void **ppv
)
{
    HR(this->Serialize(pStm, true));
    return GetUnknown()->QueryInterface(riid, ppv);
}

STDMETHODIMP CStackTrace::ReleaseMarshalData
(
    IStream *pStm
)
{
    return S_OK;
}

STDMETHODIMP CStackTrace::DisconnectObject
(
    DWORD dwReserved
)
{
    return S_OK;
}

char* GetMachineName()
{
    static char szMachine[256] = "";
    if( !*szMachine )
    {
        WSADATA d;
        WSAStartup(0x101, &d);
        gethostname(szMachine, DIM(szMachine));
        WSACleanup();
    }

    return szMachine;
}

// ISetStackTrace
STDMETHODIMP CStackTrace::get_Level(long* pnLevel)
{
    return *pnLevel = m_nLevel, S_OK;
}

STDMETHODIMP CStackTrace::put_Level(long nLevel)
{
    return m_nLevel = nLevel, S_OK;
}

STDMETHODIMP CStackTrace::AtOriginator()
{
    if ( m_nLevel == 0 )
    {
        return S_OK;
    }

    return S_FALSE;
}

STDMETHODIMP CStackTrace::AppendStackEntry(
    long nTime,
    LPCOLESTR pszServer,
    REFCLSID clsid,
    REFIID iid,
    LPCOLESTR pszMethod,
    HRESULT hr)
{
    if( m_nLevel < 0 ) return E_UNEXPECTED;

    StackEntry   e;
    e.m_time = nTime;
    e.m_nLevel = m_nLevel;

    e.m_bstrMachine = GetMachineName();

    char    szModule[MAX_PATH+1];
    GetModuleFileName(0, szModule, MAX_PATH);
    e.m_bstrProcess = szModule;

    e.m_bstrServer = pszServer;

    e.m_clsid = clsid;
    e.m_iid = iid;

    // Cache class name
    {
        wchar_t szCLSID[40];
        StringFromGUID2(clsid, szCLSID, DIM(szCLSID));

        char    szClass[256];
        char    szKey[64] = "CLSID\\";
        long    nCount = DIM(szClass);
        wcstombs(szKey + strlen(szKey), szCLSID, DIM(szCLSID));
        if( RegQueryValue(HKEY_CLASSES_ROOT, szKey, szClass, &nCount) == ERROR_SUCCESS )
        {
            //e.m_bstrClass = A2BSTR(szClass);
            e.m_bstrClass = szClass;
        }
    }

    // Cache interface name
    {
        wchar_t szIID[40];
        StringFromGUID2(iid, szIID, DIM(szIID));

        char    szInterface[256];
        char    szKey[64] = "Interface\\";
        long    nCount = DIM(szInterface);
        wcstombs(szKey + strlen(szKey), szIID, DIM(szIID));
        if( RegQueryValue(HKEY_CLASSES_ROOT, szKey, szInterface, &nCount) == ERROR_SUCCESS )
        {
            //e.m_bstrInterface = A2BSTR(szInterface);
            e.m_bstrInterface = szInterface;
        }
    }

    e.m_bstrMethod = pszMethod;
    e.m_hr = hr;
    m_listEntries.push_back(e);
    return S_OK;
}

// IStackTrace

STDMETHODIMP CStackTrace::GetCount(long* pnCount)
{
    return *pnCount = m_listEntries.size(), S_OK;
}

STDMETHODIMP CStackTrace::GetItem(
    long nItem,
    long* pnLevel,
    BSTR* pbstrTime,
    BSTR* pbstrMachine,
    BSTR* pbstrProcess,
    BSTR* pbstrServer,
    BSTR* pbstrClass,
    BSTR* pbstrInterface,
    BSTR* pbstrMethod,
    BSTR* pbstrError)
{
    *pbstrTime = 0;
    *pbstrMachine = 0;
    *pbstrProcess = 0;
    *pbstrServer = 0;
    *pbstrClass = 0;
    *pbstrInterface = 0;
    *pbstrMethod = 0;
    *pbstrError = 0;

    long    nEntries = m_listEntries.size();
    if( nItem < 0 || nItem >= nEntries )
    {
        return E_UNEXPECTED;
    }
    
    // Item 0 is last entry in the list,
    // i.e. give out entries is reverse order
    // as they are appended to the list in reverse order.
    StackEntry&  e = m_listEntries[nEntries-nItem-1];

    wchar_t szTime[256];
    wcsftime(szTime, DIM(szTime), L"%c", localtime(&e.m_time));
    *pbstrTime = SysAllocString(szTime);
    *pnLevel = e.m_nLevel;
    *pbstrMachine = e.m_bstrMachine.Copy();
    *pbstrProcess = e.m_bstrProcess.Copy();
    *pbstrServer = e.m_bstrServer.Copy();
    *pbstrClass = e.m_bstrClass.Copy();
    *pbstrInterface = e.m_bstrInterface.Copy();
    *pbstrMethod = e.m_bstrMethod.Copy();

    char    szError[256];
    BOOL    bRet = FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM,
                                  0,
                                  e.m_hr,
                                  0,
                                  szError,
                                  sizeof(szError),
                                  0);
    if( bRet )
    {
        // Strip out CRs
        char*   psz = szError;
        while( *psz )
        {
            if( *psz == '\n' || !isprint(*psz) ) *psz = ' ';
            ++psz;
        }
    }
    else
    {
        strcpy(szError, "<unknown>");
    }

    wsprintf(szError+strlen(szError), " (0x%x)", e.m_hr);
    *pbstrError = A2BSTR(szError);

    return S_OK;
}

