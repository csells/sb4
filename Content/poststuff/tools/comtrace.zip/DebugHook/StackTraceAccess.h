// StackTraceAccess.h

/////////////////////////////////////////////////////////////////////////////
// Current stack trace access

#include "debughook.h"

STDAPI GetStackTrace(IStackTrace** ppst );   // S_FALSE == no stack trace available
STDAPI SetStackTrace(IStackTrace* pst);
STDAPI StackTracePreCall(long* ptime);
STDAPI StackTracePostCall(
    long time,
    LPCOLESTR pszServer,
    REFCLSID clsid,
    REFIID iid,
    LPCOLESTR pszMethod,
    HRESULT hr);
STDAPI DumpStack(IStackTrace* pst);

STDAPI CreateTraceDelegator( IUnknown* pUnkOuter, IUnknown* pUnkInner,
	const OLECHAR* pszObjectName, REFIID iid, void** ppv );
