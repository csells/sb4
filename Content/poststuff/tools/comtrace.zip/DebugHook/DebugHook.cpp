// DebugHook.cpp : Implementation of DLL Exports.


// Note: Proxy/Stub Information
//		To build a separate proxy/stub DLL, 
//		run nmake -f DebugHookps.mk in the project directory.

#include "stdafx.h"
#include "resource.h"
#include "initguid.h"
#include "DebugHook.h"
#include <time.h>

#include "DebugHook_i.c"
#include "StackTrace.h"
#include "TraceHook.h"
#include "StackTraceAccess.h"

// {DD147E90-8631-11d1-96AC-00600819B080}
static const GUID EXTENTID_TraceHook = 
{ 0xdd147e90, 0x8631, 0x11d1, { 0x96, 0xac, 0x0, 0x60, 0x8, 0x19, 0xb0, 0x80 } };

DWORD g_dwTLSIndex; // DONE: My TLS slot

CComModule _Module;

BEGIN_OBJECT_MAP(ObjectMap)
	OBJECT_ENTRY(CLSID_StackTrace, CStackTrace)
	OBJECT_ENTRY(CLSID_TraceHook, CTraceHook)
END_OBJECT_MAP()

/////////////////////////////////////////////////////////////////////////////
// DLL Entry Point

extern "C"
BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID /*lpReserved*/)
{
    // DONE: Declare one process-wide channel hook instance
    switch( dwReason )
    {
    case DLL_PROCESS_ATTACH:
    {
		_Module.Init(ObjectMap, hInstance);
		DisableThreadLibraryCalls(hInstance);

        // DONE: Acquire a TLS slot
        if( (g_dwTLSIndex = TlsAlloc()) == 0xFFFFFFFF )
        {
            return FALSE;
        }

        // DONE: Register the process-wide channel hook
        CComObject<CTraceHook>*  pth = 0;
        if( FAILED(CComObject<CTraceHook>::CreateInstance(&pth)) ||
            FAILED(CoRegisterChannelHook(EXTENTID_TraceHook, pth)) )
        {
            delete pth;
            return FALSE;
        }
    }
    break;

    case DLL_PROCESS_DETACH:
    {
        // DONE: Release the current stack trace
        SetStackTrace(0);

        // DONE: Release TLS slot and deallocate all memory
        if( g_dwTLSIndex != 0xFFFFFFFF )
        {
            TlsFree(g_dwTLSIndex);
        }

		_Module.Term();
    }
    break;

    case DLL_THREAD_DETACH:
    {
        // DONE: Release the current stack trace
        SetStackTrace(0);
    }
    break;
    }

	return TRUE;    // ok
}

/////////////////////////////////////////////////////////////////////////////
// DONE: Stack Trace Access

STDAPI GetStackTrace(IStackTrace** ppst)
{
    void*   pv = TlsGetValue(g_dwTLSIndex);
    if( *ppst = (IStackTrace*)pv )
    {
        TlsSetValue(g_dwTLSIndex, 0);   // Clear out stack trace
        return S_OK;
    }

    return S_FALSE;
}

STDAPI SetStackTrace(IStackTrace* pstNew)
{
    // Clear out current stack trace
    IStackTrace*    pstCurrent = 0;
    if( GetStackTrace(&pstCurrent) == S_OK )
    {
        pstCurrent->Release();
    }

    // Put in new stack trace
    TlsSetValue(g_dwTLSIndex, pstNew);
    if( pstNew ) pstNew->AddRef();

    return S_OK;
}

/////////////////////////////////////////////////////////////////////////////
// DONE: Delegator helpers

STDAPI ComTrace(const OLECHAR* pszObjectName, REFIID iid, void** ppv)
{
    // ppv is in/out
    if( !ppv || !*ppv ) return E_UNEXPECTED;

    // Move *ppv to punkInner
    IUnknown*   punkInner = (IUnknown*)*ppv;
    *ppv = 0;

    HRESULT     hr;
    hr = CreateTraceDelegator(0, punkInner, pszObjectName, iid, ppv);
    if( SUCCEEDED(hr) )
    {
        // ppv has been replaced, so let it's old interface go
        // (delegator is holding the itf now)
        punkInner->Release();
    }
    else
    {
        // Restore ppv
        *ppv = punkInner;
    }

    return hr;
}

STDAPI StackTracePreCall(long* ptime)
{
    HRESULT hr = E_FAIL;

    // If there is no stack trace, create one
    SIP(IStackTrace)    spst;
    if( (hr = GetStackTrace(&spst)) == S_FALSE )
    {
        hr = CoCreateInstance(CLSID_StackTrace, 0, CLSCTX_INPROC_SERVER, IID_IStackTrace, (void**)&spst);
    }

    // Increment the level for the current call
    if( spst )
    {
        SIP(ISetStackTrace) spsst = spst;
        if( spsst )
        {
            long    nLevel;
            spsst->get_Level(&nLevel);
            spsst->put_Level(++nLevel);

            // Put the stack trace object back
            SetStackTrace(spst);

            // Return the time of the start of the call
            *ptime = time(0);
        }
    }

    return hr;
}

STDAPI StackTracePostCall(
    long time,
    LPCOLESTR pszServer,
    REFCLSID clsid,
    REFIID iid,
    LPCOLESTR pszMethod,
    HRESULT hr)
{
    SIP(IStackTrace)    spst;
    if( GetStackTrace(&spst) == S_OK )
    {
        SIP(ISetStackTrace) spsst = spst;
        if( spsst )
        {
            // Append the stack trace info
            spsst->AppendStackEntry(time,
                                    pszServer,
                                    clsid,
                                    iid,
                                    pszMethod,
                                    hr);

            // Decrement the level for the next call up
            long    nLevel;
            spsst->get_Level(&nLevel);
            spsst->put_Level(--nLevel);

            // If we're at ground zero, dump the stack trace
            if( !nLevel )
            {
                DumpStack(spst);
            }
            // Otherwise, put the current stack trace object back
            else
            {
                SetStackTrace(spst);
            }
        }
    }

    return S_OK;
}

// {7404C592-823F-11d1-96AB-00600819B080}
static const GUID CLSID_TraceLog = 
{ 0x7404c592, 0x823f, 0x11d1, { 0x96, 0xab, 0x0, 0x60, 0x8, 0x19, 0xb0, 0x80 } };

STDAPI DumpStack(IStackTrace* pst)
{
    HRESULT             hr;
    CComPtr<IUnknown>   spunk;

    hr = GetActiveObject(CLSID_TraceLog, 0, &spunk);
    if( spunk )
    {
        SIP(ILogStackTrace) splst = spunk;
        if( splst )
        {
            hr = splst->LogStackTrace(pst);
        }
    }
    
    return hr;
}

/////////////////////////////////////////////////////////////////////////////
// Used to determine whether the DLL can be unloaded by OLE

STDAPI DllCanUnloadNow(void)
{
	return (_Module.GetLockCount()==0) ? S_OK : S_FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// Returns a class factory to create an object of the requested type

STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID* ppv)
{
	return _Module.GetClassObject(rclsid, riid, ppv);
}

/////////////////////////////////////////////////////////////////////////////
// DllRegisterServer - Adds entries to the system registry

STDAPI DllRegisterServer(void)
{
	// registers object, typelib and all interfaces in typelib
	return _Module.RegisterServer(TRUE);
}

/////////////////////////////////////////////////////////////////////////////
// DllUnregisterServer - Removes entries from the system registry

STDAPI DllUnregisterServer(void)
{
	_Module.UnregisterServer();
	return S_OK;
}
