// DhTest1.cpp : Implementation of CDhTest1
#include "stdafx.h"
#include "dhtest.h"
#include "DhTest1.h"
#include "..\ComTrace.h"

/////////////////////////////////////////////////////////////////////////////
// CDhTest1

STDMETHODIMP CDhTest1::Test(long nDepth)
{
    if( --nDepth )
    {
        HRESULT     hr;
        IDhTest1*   p;
        hr = CoCreateInstance(CLSID_DhTest1, 0, CLSCTX_ALL, IID_IDhTest1, (void**)&p);
        if( SUCCEEDED(hr) )
        {
            wchar_t szObjectName[256];
            swprintf(szObjectName, L"DhTest%d", nDepth);

            // Trace all calls to this object
            COMTRACE(szObjectName, IID_IDhTest1, p);

            hr = p->Test(nDepth);
            p->Release();
        }
    }

    return S_OK;
}
