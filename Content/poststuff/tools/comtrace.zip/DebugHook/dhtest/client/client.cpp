// dhtest client

#define _WIN32_DCOM
#include <windows.h>
#include <stdio.h>
#include "..\dhtest.h"
#include "..\dhtest_i.c"
#include "..\..\ComTrace.h"

void main()
{
    CoInitialize(0);

    HRESULT     hr;
    MULTI_QI    mqi = { &IID_IDhTest1 };    
    COSERVERINFO    si = { 0, L"frodo" };
    hr = CoCreateInstanceEx(CLSID_DhTest1, 0, CLSCTX_ALL, &si, 1, &mqi);
    if( SUCCEEDED(hr) )
    {
        IDhTest1*   p = (IDhTest1*)mqi.pItf;

        const long  nDepth = 4;
        wchar_t     szObjectName[256];
        swprintf(szObjectName, L"DhTest%d", nDepth);

        // Trace all calls to this object
        COMTRACE(szObjectName, IID_IDhTest1, p);

        hr = p->Test(nDepth);
        p->Release();
    }

    CoUninitialize();
}
