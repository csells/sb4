// DhTest1.h : Declaration of the CDhTest1

#ifndef __DHTEST1_H_
#define __DHTEST1_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CDhTest1
class ATL_NO_VTABLE CDhTest1 : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CDhTest1, &CLSID_DhTest1>,
	public IDhTest1,
    public IPersist // Give CLSID to trace delegator
{
public:
	CDhTest1()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_DHTEST1)
DECLARE_NOT_AGGREGATABLE(CDhTest1)

BEGIN_COM_MAP(CDhTest1)
	COM_INTERFACE_ENTRY(IDhTest1)
	COM_INTERFACE_ENTRY(IPersist)
END_COM_MAP()

// IPersist
public:
    STDMETHODIMP GetClassID(CLSID* pclsid)
    {
        return *pclsid = GetObjectCLSID(), S_OK;
    }

// IDhTest1
public:
	STDMETHOD(Test)(long nDepth);
};

#endif //__DHTEST1_H_
