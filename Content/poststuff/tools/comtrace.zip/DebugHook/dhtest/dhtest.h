/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 3.01.75 */
/* at Mon Feb 23 14:53:53 1998
 */
/* Compiler settings for dhtest.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )
#include "rpc.h"
#include "rpcndr.h"
#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __dhtest_h__
#define __dhtest_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IDhTest1_FWD_DEFINED__
#define __IDhTest1_FWD_DEFINED__
typedef interface IDhTest1 IDhTest1;
#endif 	/* __IDhTest1_FWD_DEFINED__ */


#ifndef __DhTest1_FWD_DEFINED__
#define __DhTest1_FWD_DEFINED__

#ifdef __cplusplus
typedef class DhTest1 DhTest1;
#else
typedef struct DhTest1 DhTest1;
#endif /* __cplusplus */

#endif 	/* __DhTest1_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IDhTest1_INTERFACE_DEFINED__
#define __IDhTest1_INTERFACE_DEFINED__

/****************************************
 * Generated header for interface: IDhTest1
 * at Mon Feb 23 14:53:53 1998
 * using MIDL 3.01.75
 ****************************************/
/* [object][unique][helpstring][oleautomation][uuid] */ 



EXTERN_C const IID IID_IDhTest1;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    interface DECLSPEC_UUID("BF85171E-86E9-11D1-96AC-00600819B080")
    IDhTest1 : public IUnknown
    {
    public:
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Test( 
            /* [in] */ long nDepth) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDhTest1Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IDhTest1 __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IDhTest1 __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IDhTest1 __RPC_FAR * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Test )( 
            IDhTest1 __RPC_FAR * This,
            /* [in] */ long nDepth);
        
        END_INTERFACE
    } IDhTest1Vtbl;

    interface IDhTest1
    {
        CONST_VTBL struct IDhTest1Vtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDhTest1_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDhTest1_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDhTest1_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDhTest1_Test(This,nDepth)	\
    (This)->lpVtbl -> Test(This,nDepth)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring] */ HRESULT STDMETHODCALLTYPE IDhTest1_Test_Proxy( 
    IDhTest1 __RPC_FAR * This,
    /* [in] */ long nDepth);


void __RPC_STUB IDhTest1_Test_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IDhTest1_INTERFACE_DEFINED__ */



#ifndef __DHTESTLib_LIBRARY_DEFINED__
#define __DHTESTLib_LIBRARY_DEFINED__

/****************************************
 * Generated header for library: DHTESTLib
 * at Mon Feb 23 14:53:53 1998
 * using MIDL 3.01.75
 ****************************************/
/* [helpstring][version][uuid] */ 



EXTERN_C const IID LIBID_DHTESTLib;

#ifdef __cplusplus
EXTERN_C const CLSID CLSID_DhTest1;

class DECLSPEC_UUID("BF85171F-86E9-11D1-96AC-00600819B080")
DhTest1;
#endif
#endif /* __DHTESTLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
