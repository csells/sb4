This sample contains the source code to the 'Web App Provider' tool that is installed
by Visual Studio .NET. The Web App Provider tool allows you to set up a computer to 
upload a web project to a web hosting service provider, or your own web server.

To setup for using with a web hosting service, add the following data to the registry:

[HKEY_CURRENT_USER\Software\Microsoft\VisualStudio\7.0\AppHostProviders\HosterName]
"PostURL"="http://www.Microsoft.com/HostingSite"
"FriendlyName"="Microsoft hosting site (sample only, not operational)"




The key name after AppHostProviders (in this case HosterName), must be one word, no spaces, 
and consist of only alpha-numerical characters.