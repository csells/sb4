//Copyright (c) Microsoft Corporation.  All rights reserved.

// Connect.h : Declaration of the CConnect
#pragma once
#include "resource.h"       // main symbols

// CConnect
class ATL_NO_VTABLE CConnect : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CConnect, &CLSID_Connect>,
	public IDispatchImpl<EnvDTE::IDTCommandTarget, &EnvDTE::IID_IDTCommandTarget, &EnvDTE::LIBID_EnvDTE, 7, 0>,
	public IDispatchImpl<AddInDesignerObjects::_IDTExtensibility2, &AddInDesignerObjects::IID__IDTExtensibility2, &AddInDesignerObjects::LIBID_AddInDesignerObjects, 1, 0>,
	public IDispatchImpl<IWebAppProvider, &__uuidof(IWebAppProvider), &__uuidof(WebAppProviderLib), 7, 0>
{
public:
	CConnect()
	{
	}

//DECLARE_REGISTRY_RESOURCEID(IDR_ADDIN)
	static HRESULT WINAPI UpdateRegistry(BOOL bRegister) throw();

DECLARE_NOT_AGGREGATABLE(CConnect)


BEGIN_COM_MAP(CConnect)
	COM_INTERFACE_ENTRY2(IDispatch, IWebAppProvider)
	COM_INTERFACE_ENTRY(AddInDesignerObjects::IDTExtensibility2)
	COM_INTERFACE_ENTRY(EnvDTE::IDTCommandTarget)
END_COM_MAP()


	DECLARE_PROTECT_FINAL_CONSTRUCT()

public:
	STDMETHOD(OnConnection)(IDispatch * Application, AddInDesignerObjects::ext_ConnectMode ConnectMode, IDispatch *AddInInst, SAFEARRAY **custom);
	STDMETHOD(OnDisconnection)(AddInDesignerObjects::ext_DisconnectMode RemoveMode, SAFEARRAY **custom );
	STDMETHOD(OnAddInsUpdate)(SAFEARRAY **custom );
	STDMETHOD(OnStartupComplete)(SAFEARRAY **custom );
	STDMETHOD(OnBeginShutdown)(SAFEARRAY **custom );
	STDMETHOD(QueryStatus)(BSTR CmdName, EnvDTE::vsCommandStatusTextWanted NeededText, EnvDTE::vsCommandStatus *StatusOption, VARIANT *CommandText);
	STDMETHOD(Exec)(BSTR CmdName, EnvDTE::vsCommandExecOption ExecuteOption, VARIANT *VariantIn, VARIANT *VariantOut, VARIANT_BOOL *Handled);
	STDMETHOD(AddProvider)(BSTR KeyedName, BSTR FriendlyName, BSTR PostingURL);
	STDMETHOD(InvokeCopy)(BSTR ProjUniqueName, BSTR ProviderKeyedName);

	CComPtr<EnvDTE::_DTE> m_pDTE;
	CComPtr<EnvDTE::AddIn> m_pAddInInstance;
	HRESULT CreateMenuButtons(EnvDTE::AddIn *pAddin, EnvDTE::Commands *pCommands, Office::CommandBar *pMenuBarCommandBar, BOOL fForceRecreate);
	HRESULT GetOurMenuItem(Office::CommandBar **ppCommandBar);	
};

OBJECT_ENTRY_AUTO(__uuidof(Connect), CConnect)
