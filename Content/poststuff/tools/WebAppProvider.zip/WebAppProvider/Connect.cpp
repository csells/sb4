//Copyright (c) Microsoft Corporation.  All rights reserved.

// Connect.cpp : Implementation of CConnect
#include "stdafx.h"
#include "AddIn.h"
#include "Connect.h"


// When run, the Add-in wizard prepared the registry for the Add-in.
// At a later time, if the Add-in becomes unavailable for reasons such as:
//   1) You moved this project to a computer other than which is was originally created on.
//   2) You chose 'Yes' when presented with a message asking if you wish to remove the Add-in.
//   3) Registry corruption.
// you will need to re-register the Add-in by building the MyAddin21Setup project 
// by right clicking the project in the Solution Explorer, then choosing install.

HRESULT CConnect::UpdateRegistry(BOOL bRegister) throw()
{
    // TODO: Dynamically calculate these
    ATL::_ATL_REGMAP_ENTRY regMapEntries[4] = { 0 };
    regMapEntries[0].szKey = L"PATH";
    regMapEntries[0].szData = L"C:\\temp\\webProvider\\WebAppProvider\\Debug\\";
    regMapEntries[1].szKey = L"SATELLITEPATH";
    regMapEntries[1].szData = L"C:\\temp\\webProvider\\WebAppProvider\\Debug";
    regMapEntries[2].szKey = L"SATELLITE";
    regMapEntries[2].szData = L"WebAppProvider.dll";

    return ATL::_pAtlModule->UpdateRegistryFromResource(IDR_ADDIN, bRegister, regMapEntries);
}

// CConnect
void DisplayNeedToSelectProject()
{
	MessageBox(NULL, "You need to select a web project first", "Visual Studio Web Host Provider", MB_ICONEXCLAMATION|MB_OK);
}

STDMETHODIMP CConnect::OnConnection(IDispatch *Application, AddInDesignerObjects::ext_ConnectMode ConnectMode, IDispatch *AddInInst, SAFEARRAY ** /*custom*/ )
{
	HRESULT hr = S_OK;
	Application->QueryInterface(__uuidof(EnvDTE::_DTE), (LPVOID*)&m_pDTE);
	AddInInst->QueryInterface(__uuidof(EnvDTE::AddIn), (LPVOID*)&m_pAddInInstance);
	if(ConnectMode == 5) //5 == ext_cm_UISetup
	{
		CComPtr<EnvDTE::Commands> pCommands;
		CComQIPtr<Office::CommandBar> pProviderCommandBar;
		CComPtr<IDispatch> pDisp;

		//Add a named command...
		IfFailGo(m_pDTE->get_Commands(&pCommands));
		IfFailGo(GetOurMenuItem(&pProviderCommandBar));
		CreateMenuButtons(m_pAddInInstance, pCommands, pProviderCommandBar, TRUE);
		return S_OK;
	}
Error:
	return hr;
}

STDMETHODIMP CConnect::OnDisconnection(AddInDesignerObjects::ext_DisconnectMode /*RemoveMode*/, SAFEARRAY ** /*custom*/ )
{
	
	m_pDTE = NULL;
	return S_OK;
}

STDMETHODIMP CConnect::OnAddInsUpdate (SAFEARRAY ** /*custom*/ )
{
	return S_OK;
}

STDMETHODIMP CConnect::OnStartupComplete (SAFEARRAY ** /*custom*/ )
{
	return S_OK;
}

STDMETHODIMP CConnect::OnBeginShutdown (SAFEARRAY ** /*custom*/ )
{
	return S_OK;
}

STDMETHODIMP CConnect::QueryStatus(BSTR CmdName, EnvDTE::vsCommandStatusTextWanted NeededText, EnvDTE::vsCommandStatus *StatusOption, VARIANT *CommandText)
{
	*StatusOption = (EnvDTE::vsCommandStatus)(EnvDTE::vsCommandStatusEnabled+EnvDTE::vsCommandStatusSupported);
	return S_OK;
}

STDMETHODIMP CConnect::Exec(BSTR CmdName, EnvDTE::vsCommandExecOption ExecuteOption, VARIANT *VariantIn, VARIANT *VariantOut, VARIANT_BOOL *Handled)
{
	HRESULT hr = S_OK;
	USES_CONVERSION;
	HKEY hKey;
	CComBSTR bstrRegRoot;
	TCHAR szProviderRegKey[MAX_PATH];
	VARIANT varActiveSlnPrjs;
	CComQIPtr<EnvDTE::Project> pProj;
	CComQIPtr<VSLangProj::VSProject> pVSProj;
	CComPtr<IDispatch> pDisp;
	CComBSTR bstrName;

	m_pDTE->get_RegistryRoot(&bstrRegRoot);
	_tcscpy(szProviderRegKey, W2T(bstrRegRoot));
	_tcscat(szProviderRegKey, _T("\\AppHostProviders\\"));
	WCHAR *pszProviderName = wcsrchr(CmdName, '.');
	pszProviderName++;

	IfFailGo(m_pDTE->get_ActiveSolutionProjects(&varActiveSlnPrjs));
	if(varActiveSlnPrjs.vt == (VT_ARRAY|VT_VARIANT))
	{
		CComVariant varProj;

		LONG lLBound, lUBound;
		IfFailGo(SafeArrayGetLBound(varActiveSlnPrjs.parray, 1, &lLBound));
		IfFailGo(SafeArrayGetUBound(varActiveSlnPrjs.parray, 1, &lUBound));

		if((lUBound - lLBound) != 0)
		{
			DisplayNeedToSelectProject();
			IfFailGo(E_FAIL);
		}

		IfFailGo(SafeArrayGetElement(varActiveSlnPrjs.parray, &lLBound, &varProj));
		pProj = varProj.pdispVal;
		pProj->get_Object(&pDisp);
		pVSProj = pDisp;
		if(!pVSProj.p)
		{
			DisplayNeedToSelectProject();
			IfFailGo(E_FAIL);
		}
		pProj->get_Name(&bstrName);
	}
	else
	{
		DisplayNeedToSelectProject();
		IfFailGo(E_FAIL);
	}


	//Look for the Provider name in the registry:
	_tcscat(szProviderRegKey, W2T(pszProviderName));
	if(RegOpenKeyEx(HKEY_CURRENT_USER, szProviderRegKey, 0, KEY_ALL_ACCESS, &hKey) == ERROR_SUCCESS)
	{
		*Handled = VARIANT_TRUE;
		HRESULT hrCopyWorked = S_OK;
		DWORD dwType, dwSize = MAX_PATH;
		TCHAR szPostURL[MAX_PATH];
		RegQueryValueEx(hKey, _T("PostURL"), NULL, &dwType, (LPBYTE)szPostURL, &dwSize);
		RegCloseKey(hKey);
		_tcscat(szPostURL, _T("/"));
		_tcscat(szPostURL, W2T(bstrName));
		_tcscat(szPostURL, _T("/"));

		hrCopyWorked = pVSProj->CopyProject(CComBSTR(szPostURL), CComBSTR(L""), VSLangProj::prjAllFiles, CComBSTR(L""), CComBSTR(L""));
		if(FAILED(hrCopyWorked))
		{
			HWND hWndMain;
			long lWndMain;
			CComPtr<EnvDTE::Window> pMainWindow;
			TCHAR szFriendlyName[MAX_PATH];
			TCHAR szErrorString[1000];
			dwSize = MAX_PATH;
			CComBSTR bstrFailureTemplate = L"Copying the project to %s has failed.\nDo you wish to remove the provider?";
			CComBSTR bstrErrTitle = L"Application Provider Error.";
			if(RegQueryValueEx(hKey, _T("FriendlyName"), NULL, &dwType, (LPBYTE)szFriendlyName, &dwSize) != ERROR_SUCCESS)
			{
				_tcscpy(szFriendlyName, W2T(pszProviderName));
			}

			m_pDTE->get_MainWindow(&pMainWindow);
			pMainWindow->get_HWnd(&lWndMain);
			hWndMain = (HWND)lWndMain;

			wsprintf(szErrorString, W2T(bstrFailureTemplate), szFriendlyName);

			if(MessageBox(hWndMain, szErrorString, _T("Application Provider Error"), MB_YESNO|MB_ICONEXCLAMATION) == IDYES)
			{
				CComPtr<EnvDTE::Command> pCommand;
				CComPtr<EnvDTE::Commands> pCommands;
				m_pDTE->get_Commands(&pCommands);
				pCommands->Item(CComVariant(CmdName), -1, &pCommand);
				pCommand->Delete();
				RegCloseKey(hKey);
				RegDeleteKey(HKEY_CURRENT_USER, szProviderRegKey);
			}
		}
	}
Error:
	return hr;
}

STDMETHODIMP CConnect::AddProvider(BSTR KeyedName, BSTR FriendlyName, BSTR PostingURL)
{
	USES_CONVERSION;
	HRESULT hr = S_OK;
	HKEY hKey;
	CComBSTR bstrRegRoot;
	TCHAR szProviderRegKey[MAX_PATH];
	m_pDTE->get_RegistryRoot(&bstrRegRoot);
	_tcscpy(szProviderRegKey, W2T(bstrRegRoot));
	_tcscat(szProviderRegKey, _T("\\AppHostProviders\\"));

	if(RegOpenKeyEx(HKEY_CURRENT_USER, szProviderRegKey, 0, KEY_ALL_ACCESS, &hKey) == ERROR_SUCCESS)
	{
		HKEY hCreated;
		if(RegCreateKeyEx(hKey, W2T(KeyedName), 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hCreated, NULL) == ERROR_SUCCESS)
		{
			CComQIPtr<Office::CommandBar> pProviderCommandBar;
			CComPtr<EnvDTE::Commands> pCommands;
			RegSetValueEx(hCreated, _T("FriendlyName"), 0, REG_SZ, (BYTE*)W2T(FriendlyName), (DWORD)wcslen(FriendlyName)+1);
			RegSetValueEx(hCreated, _T("PostURL"), 0, REG_SZ, (BYTE*)W2T(PostingURL), (DWORD)wcslen(PostingURL)+1);
			RegCloseKey(hCreated);
			IfFailGo(GetOurMenuItem(&pProviderCommandBar));
			IfFailGo(m_pDTE->get_Commands(&pCommands));
			CreateMenuButtons(m_pAddInInstance, pCommands, pProviderCommandBar, FALSE);
		}
		else
			hr = E_FAIL;
		RegCloseKey(hKey);
	}
	else 
		hr = E_FAIL;
Error:
	return hr;
}

STDMETHODIMP CConnect::InvokeCopy(BSTR ProjUniqueName, BSTR ProviderKeyedName)
{
	VARIANT_BOOL vbHandled = VARIANT_FALSE;
	EnvDTE::vsCommandStatus StatusOption;
	CComBSTR bstrCmdName = L"WebAppProvider.Connect.";
	bstrCmdName += CComBSTR(ProviderKeyedName);

	HRESULT hr = QueryStatus(bstrCmdName, EnvDTE::vsCommandStatusTextWantedNone, &StatusOption, NULL);
	if((SUCCEEDED(hr)) && (StatusOption == (EnvDTE::vsCommandStatusEnabled+EnvDTE::vsCommandStatusSupported)))
	{
		hr = Exec(bstrCmdName, EnvDTE::vsCommandExecOptionDoDefault, NULL, NULL, &vbHandled);
		if((SUCCEEDED(hr)) && (vbHandled == VARIANT_FALSE))
			hr = E_FAIL;
	}

	return hr;
}

HRESULT CConnect::GetOurMenuItem(Office::CommandBar **ppCommandBar)
{
	HRESULT hr = S_OK;
	CComPtr<IDispatch> pDisp;
	CComPtr<Office::CommandBarControls> pToolsControls;
	CComPtr<Office::CommandBarControl> pHostProviderControl;
	CComQIPtr<Office::CommandBarPopup> pCommandBarPopup;
	CComPtr<Office::_CommandBars> pCommandBars;
	CComPtr<Office::CommandBar> pMenuBarCommandBar;
	CComQIPtr<Office::CommandBar> pToolsCommandBar;
	CComPtr<Office::CommandBarControls> pMenuBarControls;
	CComPtr<Office::CommandBarControl> pCommandBarControl;
	CComQIPtr<Office::CommandBar> pProviderCommandBar;
	CComPtr<EnvDTE::Commands> pCommands;
	CComBSTR bstrPopupCaption = L"Copy to Application Host Provider";

	IfFailGo(m_pDTE->get_Commands(&pCommands));

	//Add a button to the tools menu bar.
	IfFailGo(m_pDTE->get_CommandBars(&pCommandBars));
	IfFailGo(pCommandBars->get_Item(CComVariant(L"MenuBar"), &pMenuBarCommandBar));
	IfFailGo(pMenuBarCommandBar->get_Controls(&pMenuBarControls));
	IfFailGo(pMenuBarControls->get_Item(CComVariant(L"Tools"), &pCommandBarControl));
	pCommandBarPopup = pCommandBarControl;
	IfFailGo(pCommandBarPopup->get_CommandBar(&pToolsCommandBar));
	IfFailGo(pToolsCommandBar->get_Controls(&pToolsControls));
	
	if((FAILED(pToolsControls->get_Item(CComVariant(bstrPopupCaption), &pHostProviderControl))) || (!pHostProviderControl.p))
	{
		IfFailGo(pCommands->AddCommandBar(CComBSTR(bstrPopupCaption), EnvDTE::vsCommandBarTypeMenu, pToolsCommandBar, 1, &pDisp));
		pProviderCommandBar = pDisp;
		*ppCommandBar = pProviderCommandBar;
		(*ppCommandBar)->AddRef();
	}
	else
	{
		pCommandBarPopup = pHostProviderControl;
		IfFailGo(pCommandBarPopup->get_CommandBar(&pProviderCommandBar));
		*ppCommandBar = pProviderCommandBar;
		(*ppCommandBar)->AddRef();
	}
Error:
	return hr;
}

HRESULT CConnect::CreateMenuButtons(EnvDTE::AddIn *pAddin, EnvDTE::Commands *pCommands, Office::CommandBar *pMenuBarCommandBar, BOOL fForceRecreate)
{
	USES_CONVERSION;
	HRESULT hr;
	HKEY hKey;
	CComBSTR bstrRegRoot;
	TCHAR szProvidersRootKey[MAX_PATH];
	m_pDTE->get_RegistryRoot(&bstrRegRoot);
	_tcscpy(szProvidersRootKey, W2T(bstrRegRoot));
	_tcscat(szProvidersRootKey, _T("\\AppHostProviders"));
	if(RegOpenKeyEx(HKEY_CURRENT_USER, szProvidersRootKey, 0, KEY_ALL_ACCESS, &hKey) == ERROR_SUCCESS)
	{
		DWORD dwIndex = 0;
		DWORD dwProviderNameSize = MAX_PATH;
		TCHAR szProviderName[MAX_PATH];
		while(RegEnumKeyEx(hKey, dwIndex, szProviderName, &dwProviderNameSize, NULL, NULL, NULL, NULL) == ERROR_SUCCESS)
		{
			HKEY hKeyProvider;
			if(RegOpenKeyEx(hKey, szProviderName, 0, KEY_ALL_ACCESS, &hKeyProvider) == ERROR_SUCCESS)
			{
				DWORD dwType;
				DWORD dwAdded = 0;
				DWORD dwSize;
				if(RegQueryValueEx(hKeyProvider, _T("ControlAdded"), NULL, &dwType, (LPBYTE)&dwAdded, &dwSize) != ERROR_SUCCESS) dwAdded = 0;
				if(fForceRecreate || (dwAdded == 0))
				{
					CComPtr<EnvDTE::Command> pCreatedCommand;
					CComBSTR bstrButtonText = L"Save project to %s";
					WCHAR *pszTemp = new WCHAR[wcslen(bstrButtonText) + 1 + _tcslen(szProviderName)];
					if(pszTemp)
					{          
						swprintf(pszTemp, bstrButtonText, T2W(szProviderName));
						if(SUCCEEDED(pCommands->AddNamedCommand(m_pAddInInstance, CComBSTR(szProviderName), CComBSTR(pszTemp), CComBSTR(pszTemp), VARIANT_TRUE, 10, NULL, EnvDTE::vsCommandStatusEnabled+EnvDTE::vsCommandStatusSupported, &pCreatedCommand)))
						{ 
							CComPtr<Office::CommandBarControl> pCommandBarControl;
							hr = pCreatedCommand->AddControl(pMenuBarCommandBar, 1, &pCommandBarControl);
							if(SUCCEEDED(hr))
							{
								//Mark in the registry that we added this provider so we do not try to add it again.
								dwAdded = 1;
								RegSetValueEx(hKeyProvider, _T("ControlAdded"), 0, REG_DWORD, (LPBYTE)&dwAdded, sizeof(DWORD));
							}
						}
						delete []pszTemp;
					}
				}
				RegCloseKey(hKeyProvider);
			}
			dwProviderNameSize = MAX_PATH;
			dwIndex++;
		}
		RegCloseKey(hKey);
	}
	return hr;
}