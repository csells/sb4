// ImSession.cs
// Copyright (C) 2001-2002, Chris Sells
// All rights reserved. No warranties extended. Use at your own risk.
// Comments to csells@sellsbrothers.com
// The official home of this source code is http://www.sellsbrothers.com.

// Includes code from Harry Pierson
// Comments to harry@DevHawk.net

// More info from:
// http://www.venkydude.com/articles/msn2.htm
// http://www.tlsecurity.net/Textware/Misc/draft-movva-msn-messenger-protocol-00.txt
// http://www.hypothetic.org/docs/msn/index.php

using System;
using System.Collections.Specialized;
using System.Net.Sockets;
using System.Net;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Diagnostics;
using System.Security.Cryptography; // MD5CryptoServiceProvider


namespace SellsBrothers.InstantMessenger {

  /// <summary>
  /// Represents a specific chat session between two users
  /// </summary>
  public class ImSession : ImConnection {
		
    /// <summary>
    /// Create a new session with a remote user at the local user's request
    /// </summary>
    /// <param name="user">local user</param>
    /// <param name="host">server to connect to</param>
    /// <param name="port">port on server to connect to</param>
    /// <param name="hash">identification hash</param>
    /// <param name="who">remote user to connect to</param>
    public ImSession(string user, string host, int port, string hash, string who) {
      Connect(host, port);
			
      long transID = WriteCommand("USR", user, hash);
      ImCommand cmd = ExpectCommand("USR", transID, "OK");    // USR 0 OK <user> <nick>

      transID = WriteCommand("CAL", who);
      cmd = ExpectCommand("CAL", transID);   // CAL 1 RINGING <sessionId>
      cmd = ExpectCommand("JOI");     // JOI <user> <nick>
    }

    /// <summary>
    /// Create a new session with a remote user at the remote user's request
    /// </summary>
    /// <param name="user">local user</param>
    /// <param name="host">server to connect to</param>
    /// <param name="port">port on server to connect to</param>
    /// <param name="hash">identification hash</param>
    /// <param name="sessionID">Session identifier</param>
    /// <param name="fromWho">remote user who requested the session</param>
    public ImSession(string user, string host, int port, string hash, string sessionID, string fromWho) {
      Connect(host, port);

      long transID = WriteCommand("ANS", user, hash, sessionID);
      ImCommand cmd = ExpectCommand("IRO", transID);
      while (cmd.Param(1) != cmd.Param(2))
        cmd = ExpectCommand("IRO", transID);
      cmd = ExpectCommand("ANS", transID);
    }

    /// <summary>
    /// Send a plain text message to the remote user
    /// </summary>
    /// <param name="message">message to send</param>
    public void Send(string message) {
      Send(message, "text/plain; charset=UTF-8");
    }

    /// <summary>
    /// Send a message of a customized content type to the remote user
    /// </summary>
    /// <param name="message">message to send</param>
    /// <param name="contentType">content type of message</param>
    public void Send(string message, string contentType) {
      StringBuilder   data = new StringBuilder();
      data.Append("MIME-Version: 1.0\r\n");
      data.Append("Content-Type: " + contentType + "\r\n");
      data.Append("X-MMS-IM-Format: FN=MS%20Shell%20Dlg; EF=; CO=0; CS=0; PF=0\r\n");
      data.Append("\r\n");
      data.Append(message);

      long transID = WriteMessage("A", data.ToString());
      ExpectCommand("ACK", transID);   
    }
  }
}
