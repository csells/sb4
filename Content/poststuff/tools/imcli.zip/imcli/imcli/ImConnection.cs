// ImConnection.cs
// Copyright (C) 2001-2002, Chris Sells
// All rights reserved. No warranties extended. Use at your own risk.
// Comments to csells@sellsbrothers.com
// The official home of this source code is http://www.sellsbrothers.com.

// Includes code from Harry Pierson
// Comments to harry@DevHawk.net

// More info from:
// http://www.venkydude.com/articles/msn2.htm
// http://www.tlsecurity.net/Textware/Misc/draft-movva-msn-messenger-protocol-00.txt
// http://www.hypothetic.org/docs/msn/index.php

using System;
using System.Collections.Specialized;
using System.Net.Sockets;
using System.Net;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Diagnostics;
using System.Security.Cryptography; // MD5CryptoServiceProvider

namespace SellsBrothers.InstantMessenger {
  #region ImErrorCode Enumeration
  /// <summary>
  /// Enumerated type of all the registered MSN IM Error codes
  /// </summary>
  public enum ImErrorCode {
    Syntax_error = 200,
    Invalid_parameter = 201,
    Invalid_user = 205,
    Domain_name_missing = 206,
    Already_logged_in = 207,
    Invalid_username = 208,
    Invalid_fusername = 209,
    User_list_full = 210,
    User_already_there = 215,
    User_already_on_list = 216,
    User_not_online = 217,
    Already_in_mode = 218,
    User_is_in_the_opposite_list = 219,
    Switchboard_failed = 280,
    Transfer_to_switchboard_failed = 281,

    Required_field_missing = 300,
    Not_logged_in = 302,

    Internal_server_error = 500,
    Database_server_error = 501,
    File_operation_failed = 510,
    Memory_allocation_failed = 520,

    Server_is_busy = 600,
    Server_is_unavaliable = 601,
    Peer_nameserver_is_down = 602,
    Database_connection_failed = 603,
    Server_is_going_down = 604,

    Could_not_create_connection = 707,
    Write_is_blocking = 711,
    Session_is_overloaded = 712,
    Too_many_active_users = 713,
    Too_many_sessions = 714,
    Not_expected = 715,
    Bad_friend_file = 717,

    Authentication_failed = 911,
    Not_allowed_when_offline = 913,
    Not_accepting_new_users = 920
  }
  #endregion

  #region ImException class
  /// <summary>
  /// IM class specific exception type
  /// </summary>
  public class ImException : ApplicationException {
    public static ImErrorCode GetErrorCode(string errNo) {
      return (ImErrorCode)Enum.Parse(typeof(ImErrorCode), errNo);
    }

    public ImException(ImErrorCode err) : this("", Enum.GetName(err.GetType(), err)) {
    }

    public ImException(string error) : this("", error) {
    }

    public ImException(string expected, string error) : base(error) {
      _expected = expected;
      _error = error;
    }

    public string Expected {
      get { return _expected; }
    }

    public string Error {
      get { return _error; }
    }

    private string  _expected;
    private string  _error;
  }
  #endregion

  #region ImCommand and ImMessage classes
  /// <summary>
  /// The ImCommand class represents a command sent from the IM server to 
  /// the client. It consists of a three letter command, zero or more parameters.
  /// Often, the first parameter is the transaction ID, allowing the client
  /// to match incoming commands with outgoing ones.
  /// </summary>
  public class ImCommand {
    private string _cmdID;
    private string _line;
    private string[] _params;

    public ImCommand(string line) {
      _line = line;
      _cmdID = line.Substring(0, 3);
      _params = line.Substring(4).Split(' ');
    }

    public string CommandName {
      get { return _cmdID; }
    }

    public string Param(int index) {
      return _params[index];
    }

    public int ParamCount {
      get { return _params.Length; }
    }

    public string Line {
      get { return _line; }
    }
  }

  /// <summary>
  /// The ImMessage is a specific type of command from the IM server. Messages 
  /// have "MSG" as their command name, and the last parameter indicates the 
  /// length, in bytes of the MIME message that follows. The message may include
  /// zero or more header values plus the body of the message.
  /// </summary>
  public class ImMessage : ImCommand {
    private NameValueCollection _header = new NameValueCollection();
    private string _body;

    public ImMessage(string line, TextReader reader) : base(line) {
      int length = int.Parse(Param(ParamCount - 1));

      char[] msgContent = new char[length];
      reader.Read(msgContent, 0, length);

      StringReader sr = new StringReader(new string(msgContent));
      string buf;
      while ((buf = sr.ReadLine()) != "") {
        int pos = buf.IndexOf(": ");
        string key = buf.Substring(0, pos);
        string val = buf.Substring(pos + 2);
        _header.Add(key, val);
      }

      _body = sr.ReadToEnd().Trim();
    }

    public string Header(string name) {
      return _header[name];
    }

    public string Body {
      get { return _body; }
    }
  }
  #endregion

  #region CommandReceived EventArgs and Delegate
  /// <summary>
  /// EventArgs subtype that includes an ImCommand that has been received by the client
  /// </summary>
  public class CommandReceivedEventArgs : EventArgs {
    private ImCommand _command;

    public CommandReceivedEventArgs(ImCommand cmd) {
      _command = cmd;
    }

    public ImCommand Command {
      get { return _command; }
    }
  }

  /// <summary>
  /// Event Handler delegate for receiving CommandReceived events
  /// </summary>
  public delegate void CommandReceivedEventHandler(object sender, CommandReceivedEventArgs e);
  #endregion

  /// <summary>
  /// ImConnection is the base class of the IM class library. Since the IM protocol
  /// is largely similar between the client and the chat sessions, the common
  /// elements have been factored into this common base class.
  /// </summary>
  public class ImConnection : IDisposable {
    #region Private member variables
    /// <summary>
    /// Every message from the client the IM server has a unique transaction ID.
    /// By convention, the id is incremented on every message sent to the server
    /// </summary>
    private long            _transactionID = 0;

    private TcpClient       _socket;
    private NetworkStream   _stream;
    private StreamReader    _reader;
    private StreamWriter    _writer;

    /// <summary>
    /// standard regular expression object to check for error messages from server
    /// </summary>
    private static Regex _reError = new Regex(@"^\d\d\d ");
    #endregion

    /// <summary>
    /// property wrapper around the network stream's data available property
    /// in order to facilitate polling
    /// </summary>
    protected bool DataAvailable {
      get { return _stream.DataAvailable; }
    }

    protected bool Connected {
      get { return _socket != null; }
    }

    #region Dispose and Finalizer
    // IDisposable
    ~ImConnection() {
      Dispose();
    }

    public void Dispose() {
      if( _socket != null ) {
        _reader.Close();
        _writer.Close();
        _stream.Close();
        _socket.Close();
      }

      GC.SuppressFinalize(this);
    }
    #endregion

    #region CommandReceived Event Handler
    /// <summary>
    /// Event indicating a Command (or message) has been received by the client
    /// </summary>
    public event CommandReceivedEventHandler CommandReceived;

    /// <summary>
    /// Raise the CommandReceived event, if anyone is listening
    /// </summary>
    /// <param name="cmd">the ImCommand that was received</param>
    protected void OnCommandReceived(ImCommand cmd) {
      if (CommandReceived != null && cmd != null) {
        CommandReceived(this, new CommandReceivedEventArgs(cmd));
      }
    }
    #endregion

    /// <summary>
    /// Processes the next available command object if available. Fires 
    /// CommandReceived Event when command is received Facilitates
    /// clients that poll for updates.
    /// UPDATED - This function used to be called GetNextCommand;
    /// </summary>
    public void ProcessCommands() {
      while (DataAvailable)
        OnCommandReceived(ReceiveCommand());
    }


    /// <summary>
    /// Connect the internal tcp client to the specified msn IM server
    /// </summary>
    /// <param name="host">IP host to connect to</param>
    /// <param name="port">IP port to connect to</param>
    protected void Connect(string host, int port) {
      _transactionID = 0;

      _socket = new TcpClient(host, port);
      _stream = _socket.GetStream();
      _reader = new StreamReader(_stream, Encoding.ASCII);
      _writer = new StreamWriter(_stream, Encoding.ASCII);
      _writer.AutoFlush = true;
    }


    /// <summary>
    /// Writes the specified line to the msn server via stream writer. Increments
    /// the internal transaction id and returns the current value (it is assumed 
    /// that the current transaction id is imbedded in the line to be sent.
    /// Optionally appends a new line - all commands except challenge responses
    /// end with a newline.
    /// </summary>
    /// <param name="line">message to send to the server</param>
    /// <param name="writeNewLine">append new line to message</param>
    /// <returns>the current transaction id</returns>
    private long WriteLine(string line, bool writeNewLine) {
      Console.WriteLine("Writing: " + line);
      if (writeNewLine)
        _writer.WriteLine(line);
      else
        _writer.Write(line);
      return _transactionID++;
    }

    /// <summary>
    /// Writes the specified command string to the server. Automatically appends the 
    /// transaction id as a parameter
    /// </summary>
    /// <param name="command">comannd string to send</param>
    /// <returns>the transaction of the sent command</returns>
    protected long WriteCommand(string command) {
      string line = string.Format("{0} {1}", command, _transactionID);
      return WriteLine(line, true);
    }

    /// <summary>
    /// Writes the specified command string to the server. Automatically appends the 
    /// transaction id as the parameter and the supplied parameter string as the rest of
    /// the parameters
    /// </summary>
    /// <param name="command">comannd string to send</param>
    /// <param name="parameters">parameter string to send</param>
    /// <returns>the transaction of of the sent command</returns>
    protected long WriteCommand(string command, string parameters) {
      string line = string.Format("{0} {1} {2}", command, _transactionID, parameters);
      return WriteLine(line, true);
    }

    /// <summary>
    /// Writes the specified command string to the server. Automatically appends the 
    /// transaction id as the parameter and the supplied parameters 
    /// </summary>
    /// <param name="command">comannd string to send</param>
    /// <param name="args">variable array of parameters</param>
    /// <returns>the transaction of the send command</returns>
    protected long WriteCommand(string command, params object[] args) {
      StringBuilder sb = new StringBuilder();
      foreach (object o in args) {
        if (sb.Length != 0)
          sb.AppendFormat(" {0}", o.ToString());
        else
          sb.Append(o.ToString());
      }

      return WriteCommand(command, sb.ToString());
    }
		
    /// <summary>
    /// Writes the specified command string to the server. Automatically appends the 
    /// transaction id as the parameter and the supplied parameter string as the rest of
    /// the parameters. does not append a new line at the end of the command string.
    /// </summary>
    /// <param name="command">comannd string to send</param>
    /// <param name="parameters">parameter string to send</param>
    /// <returns>the transaction of the sent command</returns>
    protected long WriteChallenge(string command, string parameters) {
      string line = string.Format("{0} {1} {2}", command, _transactionID, parameters);
      return WriteLine(line, false);
    }


    /// <summary>
    /// sends the specified message to the server. Automatically appends the transaction id
    /// </summary>
    /// <param name="acktype">type of acknowledgement requested</param>
    /// <param name="message">message to send</param>
    /// <returns>the transaction of the sent message</returns>
    protected long WriteMessage(string acktype, string message) {
      long transID = WriteCommand("MSG", acktype, message.Length);
      Console.WriteLine("Writing: " + message);
      _writer.Write(message);
      return transID;
    }

    /// <summary>
    /// Sends the end command, ending the current connection
    /// </summary>
    public void End() {
      Console.WriteLine("Writing: OUT");
      _writer.Write("OUT");
    }

    /// <summary>
    /// Processes the next command from the server. Throws an  exception on IM fault 
    /// message. Returns ImCommand or ImMessage object as appropriate
    /// </summary>
    /// <returns>received ImCommand</returns>
    protected ImCommand ReceiveCommand() {
      string  line = _reader.ReadLine();
      if (line == null) 
        return null;
      Console.WriteLine("Received: {0}", line);

      if (_reError.Match(line).Success) {
        throw new ImException(ImException.GetErrorCode(line.Substring(0, 3)));
      }

      if (line.StartsWith("MSG"))
        return new ImMessage(line, _reader);

      return new ImCommand(line);
    }

    /// <summary>
    /// Checks to ensure the given command matches the given command type
    /// </summary>
    /// <param name="cmd">the command to check</param>
    /// <param name="cmdName">the type of command it should be</param>
    /// <returns>does the command match?</returns>
    protected bool CheckCommand(ImCommand cmd, string cmdName) {
      if (cmd == null)
        return false;

      return (cmd.CommandName == cmdName);
    }


    /// <summary>
    /// Checks to ensure the given command matches the given command type 
    /// and transaction ID
    /// </summary>
    /// <param name="cmd">the command to check</param>
    /// <param name="cmdName">the type of command it should be</param>
    /// <param name="transID">the transaction id it should be 
    /// (-1 means ignore TransID)</param>
    /// <returns>does the command match?</returns>
    protected bool CheckCommand(ImCommand cmd, string cmdName, long transID) {
      if (cmd == null)
        return false;

      if (transID == -1)
        return (cmd.CommandName == cmdName);
      else
        return (cmd.CommandName == cmdName && cmd.Param(0) == transID.ToString());
    }

    /// <summary>
    /// Checks to ensure the given command matches the given command type,
    /// transaction ID and parameters
    /// </summary>
    /// <param name="cmd">the command to check</param>
    /// <param name="cmdName">the type of command it should be</param>
    /// <param name="transID">the transaction id it should be</param>
    /// <param name="args">the parameters that should be there</param>
    /// <returns>does the command match?</returns>
    protected bool CheckCommand(ImCommand cmd, string cmdName, long transID, params string[] args) {
      if (!CheckCommand(cmd, cmdName, transID))
        return false;

      if (args != null) {
        for (int i = 0; i < args.Length; i++) {
          if (cmd.Param(i+1) != args[i])
            return false;
        }
      }

      return true;
    }

    /// <summary>
    /// Calls the primary ExpectCommand method with default parameters
    /// </summary>
    /// <param name="cmdName">the type of command it should be</param>
    /// <returns>received ImCommand</returns>
    protected ImCommand ExpectCommand(string cmdName) {
      return ExpectCommand(cmdName, -1, null);
    }

    /// <summary>
    /// Calls the primary ExpectCommand method with default parameters
    /// </summary>
    /// <param name="cmdName">the type of command it should be</param>
    /// <param name="transID">the transaction id it should be</param>
    /// <returns>received ImCommand</returns>
    protected ImCommand ExpectCommand(string cmdName, long transID) {
      return ExpectCommand(cmdName, transID, null);
    }

    /// <summary>
    /// Calls ReceiveCommand then CheckCommand to receive the next command and
    /// ensure it's the expected type and transaction id and has the expected 
    /// parameters.
    /// UPDATE - If CheckCommand fails, the commandReceived event is raised
    /// and the next command is received. This continues until the expected 
    /// command is received or there are no more commands, in which case and
    /// exception is thrown
    /// </summary>
    /// <param name="cmdName">the type of command it should be</param>
    /// <param name="transID">the transaction id it should be</param>
    /// <param name="args">the parameters that should be there</param>
    /// <returns>received ImCommand</returns>
    protected ImCommand ExpectCommand(string cmdName, long transID, params string[] args) {

      ImCommand cmd = null;
			
      do {
        cmd = ReceiveCommand();
        if (!CheckCommand(cmd, cmdName, transID, args))
          OnCommandReceived(cmd);
        else
          return cmd;
      }
      while (cmd != null);

      throw new ImException("Expected command " + cmdName + " never received");
    }
  }
}
