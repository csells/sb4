// ImClient.cs
// Copyright (C) 2001-2002, Chris Sells
// All rights reserved. No warranties extended. Use at your own risk.
// Comments to csells@sellsbrothers.com
// The official home of this source code is http://www.sellsbrothers.com.

// Includes code from Harry Pierson
// Comments to harry@DevHawk.net

// More info from:
// http://www.venkydude.com/articles/msn2.htm
// http://www.tlsecurity.net/Textware/Misc/draft-movva-msn-messenger-protocol-00.txt
// http://www.hypothetic.org/docs/msn/index.php

#region History
// 1/2/2004: Updated by Robert M. Wagner Jr. to support MSNP8
#endregion

using System;
using System.Collections;
using System.Collections.Specialized;
using System.Net.Sockets;
using System.Net;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Diagnostics;
using System.Security.Cryptography; // MD5CryptoServiceProvider

namespace SellsBrothers.InstantMessenger {
  /// <summary>
  /// Represents the main connection from the IM client and the MSN servers
  /// </summary>
  public class ImClient : ImConnection {
    private string		_userName;
    private string		_screenName;
    private ArrayList	_passPortUrls;

    public string UserName {
      get { return _userName; }
    }

    public string ScreenName {
      get { return _screenName; }
    }

    public ImClient(string user, string password) : this(user, password, null) {
    }

    /// <summary>
    /// Create an IM client session
    /// </summary>
    /// <param name="user">passport name (email address)</param>
    /// <param name="password">user's password</param>
    public ImClient(string user, string password, CommandReceivedEventHandler evt) {
      string  host = "messenger.hotmail.com"; 
      int     port = 1863;
      string  hash;
      long    transID;
      ImCommand cmd;
	
      if (evt == null)
        evt = new SellsBrothers.InstantMessenger.CommandReceivedEventHandler(ImCmdReceived);
      if (evt != null)
        CommandReceived += evt;

      while( true ) {
        Connect(host, port);

        // Login
        transID = WriteCommand("VER", "MSNP8 MSNP9 CVRO");
        cmd = ExpectCommand("VER", transID);    // VER 0 MSNP7 MSNP6 MSNP5 MSNP4

        transID = WriteCommand("CVR", "0x0413 winnt 5.1 i386 MSNMSGR 6.0.0602 MSMSG " + user);
        cmd = ReceiveCommand();

        transID = WriteCommand("USR", "TWN I " + user);
        cmd = ReceiveCommand();

        if (cmd.CommandName == "USR") {
          hash = cmd.Param(3);
          break;
        }

        if (cmd.CommandName != "XFR")
          throw new ImException("Expected XFR or USR, Received" + cmd.CommandName);

        string[] arIP = cmd.Param(2).Split(':');
        host = arIP[0];
        port = int.Parse(arIP[1]);

        Dispose();
      }

      Debug.Assert(hash.Length > 0);
      if(!GetPassPortUrls())
        throw new ImException("Could not get passport urls");

      string passwordHash = GetClientTicket(password, user, hash);

      transID = WriteCommand("USR", "TWN S " + passwordHash);
      cmd = ExpectCommand("USR", transID, "OK");    // USR 3 OK <user> <nick>
      _userName = cmd.Param(2);
      _screenName = System.Web.HttpUtility.UrlDecode(cmd.Param(3));

      transID = WriteCommand("CHG", "NLN");
      cmd = ExpectCommand("CHG", transID, "NLN");
    }

    private void ImCmdReceived(object sender, SellsBrothers.InstantMessenger.CommandReceivedEventArgs e) {
      SellsBrothers.InstantMessenger.ImCommand cmd = e.Command;

      if (cmd.CommandName == "CHL")
        ChallengeResponse(cmd.Param(1));
    }

    /// <summary>
    /// Calculate the response to the server challenge and send it to the 
    /// server using the QRY command, then ensure the QRY command is echoed
    /// back, indicating successful response to the challenge
    /// </summary>
    /// <param name="hash">
    /// Hash values passed as second parameter of the CHL server command
    /// </param>
    public void ChallengeResponse(string hash) {
      string newhash = GetMD5String(hash + "Q1P7W2E4J9R8U3S5");
      long transID = WriteChallenge("QRY", "msmsgs@msnmsgr.com 32\r\n" + newhash);
      ExpectCommand("QRY", transID);
    }

    /// <summary>
    /// Creates a new chat session with the specified user
    /// </summary>
    /// <param name="who">the user to start the chat session with</param>
    /// <returns>an ImSession object representing the chat session</returns>
    public ImSession RequestSession(string who) {
      if (!Connected) throw new ImException("Must login first");

      long transID = WriteCommand("XFR", "SB");
      ImCommand cmd = ExpectCommand("XFR", transID, "SB"); //  XFR 5 SB <host>:<port> CKI <hash>

      string[] arIP = cmd.Param(2).Split(':');
      string host = arIP[0];
      int port = int.Parse(arIP[1]);
      string hash = cmd.Param(4);

      return new ImSession(UserName, host, port, hash, who);
    }


    /// <summary>
    /// Answers a chat session request from another user
    /// </summary>
    /// <param name="cmd">the RNG command received from the server</param>
    /// <returns>an ImSession object representing the chat session</returns>
    public ImSession ReceiveSessionInvite(ImCommand cmd) {
      if (cmd.CommandName != "RNG")
        throw new ImException("RNG", string.Format("ReceiveSessionInvite called with {0} command, expected RNG", cmd.CommandName));

      string[] arIP = cmd.Param(1).Split(':');
      string host = arIP[0];
      int port = int.Parse(arIP[1]);
      string hash = cmd.Param(3);
      string sessionID = cmd.Param(0);
      string fromWho = cmd.Param(4);
			
      return new ImSession(UserName, host, port, hash, sessionID, fromWho);
    }

    /// <summary>
    /// Performs the MD5 hashing used to respond to both challenges and 
    /// user login requests
    /// </summary>
    /// <param name="s">string to hash</param>
    /// <returns>hashed string</returns>
    public static string GetMD5String(string s) {
      MD5             md5 = new MD5CryptoServiceProvider();
      byte[]          hash = md5.ComputeHash(Encoding.ASCII.GetBytes(s));
      StringBuilder   sb = new StringBuilder();
      foreach( byte b in hash ) sb.AppendFormat("{0:x2}", b);
      return sb.ToString();
    }

    /// <summary>
    /// This function connects to nexus.passport.com and populate our passport array.
    /// </summary>
    /// <returns>true if successful</returns>
    public bool GetPassPortUrls() {
      bool	bReturn = false;

      HttpWebRequest serverRequest = (HttpWebRequest)WebRequest.Create("https://nexus.passport.com/rdr/pprdr.asp");
			
      HttpWebResponse serverResponse = (HttpWebResponse)serverRequest.GetResponse();
      if(serverResponse.StatusCode == HttpStatusCode.OK) {
        string retrieveddata = serverResponse.Headers.ToString();
        _passPortUrls = new ArrayList();

        string[] result = serverResponse.Headers.Get("PassportURLs").Split(',');
        for(int index = 0; index < result.GetLength(0); index++) {
          _passPortUrls.Add(result[index].Substring(result[index].IndexOf('=') + 1));
        }

        bReturn = true;
      }

      serverResponse.Close();
      return bReturn;
    }

    public string GetClientTicket(string password, string user, string challenge) {
      string uri = "https://" + _passPortUrls[DALOGIN];

      HttpWebRequest ServerRequest;
      HttpWebResponse ServerResponse;
      try {
        while(true) {
          ServerRequest = (HttpWebRequest)HttpWebRequest.Create(uri);
          ServerRequest.AllowAutoRedirect = false;
          ServerRequest.Pipelined = false;
          ServerRequest.KeepAlive = false;
          ServerRequest.ProtocolVersion = new Version(1,0);
          // Send the authentication header
          ServerRequest.Headers.Add("Authorization", "Passport1.4 OrgVerb=GET,OrgURL=http%3A%2F%2Fmessenger%2Emsn%2Ecom,sign-in=" + user.Replace("@", "%40") + ",pwd=" + password + "," + challenge + "\n");
          // Pick up the result
          ServerResponse = (HttpWebResponse)ServerRequest.GetResponse();

          // If the statuscode is OK, then there is a valid return
          if (ServerResponse.StatusCode == HttpStatusCode.OK) {
            // Pick up the information of the authentications
            string AuthenticationInfo = ServerResponse.Headers.Get("Authentication-Info");
            // Get the startposition of the ticket id (note it is between two quotes)
            int startposition = AuthenticationInfo.IndexOf('\'');
            // Get the endposition 
            int endposition = AuthenticationInfo.LastIndexOf('\'');
            // Substract the startposition of the endposition
            endposition = endposition - startposition ;

            // Close connection
            ServerResponse.Close();

            // Generate a new substring and return it
            return AuthenticationInfo.Substring(startposition + 1, endposition -1 );
						
          }
            // If the statuscode is 302, then there is a redirect, read the new adres en connect again
          else if (ServerResponse.StatusCode == HttpStatusCode.Found) {
            uri = ServerResponse.Headers.Get("Location");
          }
        }
      }
      catch (WebException e) {
        // If the statuscode is 401, then an exeption occurs
        // Think that your password + username combination is not correct
        // return number so that calling functions knows what to do
        if (e.Status == WebExceptionStatus.ProtocolError) {
          return "401";
        }
        else {
          return "0";
        }	
      }
    }

    const int DALOGIN = 1;
  }

}
