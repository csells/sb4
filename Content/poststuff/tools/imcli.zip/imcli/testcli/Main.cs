// Main.cs
// Copyright (C) 2001-2002, Chris Sells
// All rights reserved. No warranties extended. Use at your own risk.
// Comments to csells@sellsbrothers.com

using System;
using System.Configuration;
using System.Collections.Specialized;
using SellsBrothers.InstantMessenger;

class App {
  static void Notify(string user, string password, string who, string what) {
    using( ImClient im = new ImClient(user, password) )
    using( ImSession session = im.RequestSession(who) ) {
      session.Send(what);
      session.Send("This message brought to you by http://www.sellsbrothers.com." + "\r\nthink deeply. code well.");
    }
  }

  static void Main(string[] args) {
    // Gather command-line args
    if( args.Length < 2 ) {
      Console.WriteLine("usage: imcli <imRecipientEmail> <message>");
      return;
    }

    string  who = args[0];
    string  what = "";
    for( int i = 1; i < args.Length; ++i ) what += args[i] + " ";

    // Gather .config settings
    NameValueCollection settings = ConfigurationSettings.AppSettings;
    string              user = settings["user"];
    string              password = settings["password"];
    string              nickname = settings["nickname"];

    if( user.Length < 1 || password.Length < 1 ) {
      Console.WriteLine("Please set user and password appSettings in the .config file");
      return;
    }

    if( nickname.Length < 1 ) nickname = "Sells Brothers IM client";

    // Send the IM message
    try {
      Notify(user, password, who, what);
    }
    catch( ImException e ) {
      Console.WriteLine("{0}: expected '{1}', error '{2}'", e.Message, e.Expected, e.Error);
    }
    catch( Exception e ) {
      Console.WriteLine(e.Message);
    }
  }
}
