// comdate.cpp
/////////////////////////////////////////////////////////////////////////////
// Copyright (c) 1998-2000 Chris Sells
// All rights reserved.
//
// NO WARRANTIES ARE EXTENDED. USE AT YOUR OWN RISK.
//
// To contact the author with suggestions or comments, use csells@sellsbrothers.com.

// This file no longer needed. comdate.h is sufficient.
