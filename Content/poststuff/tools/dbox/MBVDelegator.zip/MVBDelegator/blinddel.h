////////////////////////////////////////////////////////////
//
// blinddel.h - Copyright 1999, DevelopMentor
//
// Generic blind delegation code
//
// If this code works, it was written by Don Box.
// If it doesn't, it was written by Paul DiLascia
//
//

#ifndef _BLIND_DELEGATOR_H
#define _BLIND_DELEGATOR_H

enum { MAX_VTABLE_ENTRIES  = 1024 };
typedef void (_stdcall *VTBL_ENTRY)();
typedef VTBL_ENTRY VTABLE[MAX_VTABLE_ENTRIES];

extern VTABLE g_bdvtbl;

struct BlindDelegator
{
    VTABLE                 *m_pVTable;
    IUnknown               *m_pUnkRealItf;
    IUnknown               *m_pCtlUnk;
    LONG                    m_cRef;


    static inline BlindDelegator *This(void *pvThis) 
    { 
        return (BlindDelegator*)(LPBYTE(pvThis) - offsetof(BlindDelegator, m_pVTable)); 
    }

    static HRESULT STDMETHODCALLTYPE QueryInterface(IUnknown *pvThis, REFIID riid, void **ppv)
    {
        return This(pvThis)->m_pCtlUnk->QueryInterface(riid, ppv);
    }

    static ULONG STDMETHODCALLTYPE AddRef(IUnknown *pvThis)
    {
        return InterlockedIncrement(&This(pvThis)->m_cRef);
    }

    static ULONG STDMETHODCALLTYPE Release(IUnknown *pvThis)
    {
        BlindDelegator *pThis = This(pvThis);
        LONG res = InterlockedDecrement(&pThis->m_cRef);
        if (res == 0)
        {
            IUnknown *pCtlUnk = pThis->m_pCtlUnk;
            pThis->m_pUnkRealItf->Release();
            delete pThis;
            res = pCtlUnk->Release();
        }
        return res;
    }

    static HRESULT CreateDelegator(IUnknown *pCtlUnk, IUnknown *pUnkDelegatee, REFIID riid, void **ppv)
    {
        IUnknown *pItf = 0;
        *ppv = 0;
        HRESULT hr = pUnkDelegatee->QueryInterface(riid, (void**)&pItf);
        if (SUCCEEDED(hr))
        {
            BlindDelegator *pDel = new BlindDelegator;
            if (pDel)
            {
                pDel->m_cRef = 1;
                (pDel->m_pCtlUnk = pCtlUnk)->AddRef();
                pDel->m_pUnkRealItf = pItf;
                pDel->m_pVTable = &g_bdvtbl;
                *ppv = LPBYTE(pDel) + offsetof(BlindDelegator, m_pVTable);
            }
            else
            {
                pItf->Release();
                hr = E_OUTOFMEMORY;
            }

        }
        return hr;
    }
};



#endif
