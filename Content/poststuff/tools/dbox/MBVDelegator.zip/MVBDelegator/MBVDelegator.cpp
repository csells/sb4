////////////////////////////////////////////////////////////
//
// MBVDelegator.cpp - Copyright 1999, DevelopMentor
//
// Implementation of MBVDelegator
//
// If this code works, it was written by Don Box.
// If it doesn't, it was written by Paul DiLascia
//
//

#include "stdafx.h"
#include "Mbvref.h"
#include "MBVDelegator.h"

/////////////////////////////////////////////////////////////////////////////
// CMBVDelegator


struct MBV_HEADER
{
    GUID				guidSignature; // == CLSID_MBVDelgator
    CLSID				clsid; // == GUID_NULL -> FTM
    unsigned __int64	cb;
};

STDMETHODIMP 
CMBVDelegator::GetUnmarshalClass(REFIID riid, void *pv, DWORD dwDestContext,
                                 void *pvDestContext, DWORD mshlflags, CLSID *pCid)
{
    HRESULT hr = S_OK;
    if (dwDestContext == MSHCTX_INPROC && m_pUnkFTM)
    {
        CComPtr<IMarshal> pMsh;
        HRESULT hr = m_pUnkFTM->QueryInterface(&pMsh);
        if (SUCCEEDED(hr))
            hr = pMsh->GetUnmarshalClass(riid, pv, dwDestContext, pvDestContext, mshlflags, pCid);
    }
    else
        *pCid = __uuidof(MBVDelegator);
    return hr;
}

STDMETHODIMP 
CMBVDelegator::GetMarshalSizeMax(REFIID riid, void *pv, DWORD dwDestContext,
                                 void *pvDestContext, DWORD mshlflags, DWORD *pSize)
{
    HRESULT hr = S_OK;
    if (dwDestContext == MSHCTX_INPROC && m_pUnkFTM)
    {
        CComPtr<IMarshal> pMsh;
        HRESULT hr = m_pUnkFTM->QueryInterface(&pMsh);
        if (SUCCEEDED(hr))
            hr = pMsh->GetMarshalSizeMax(riid, pv, dwDestContext, pvDestContext, mshlflags, pSize);
    }
    else
    {
        __int64 cbMax;
        HRESULT hr = m_ppsDelegatee->GetSizeMax((ULARGE_INTEGER*)&cbMax);
        if (SUCCEEDED(hr))
            *pSize = DWORD(cbMax) + sizeof(MBV_HEADER);
        else
        {
            hr = S_OK;
            if (!m_pStmCachedRead)
            {
                hr = CreateStreamOnHGlobal(0, TRUE, &m_pStmCachedRead);
                if (SUCCEEDED(hr))
                {
                    hr = m_ppsDelegatee->Save(m_pStmCachedRead, FALSE);
                    if (SUCCEEDED(hr))
                    {
                        LARGE_INTEGER liZero = { 0 };
                        hr = m_pStmCachedRead->Seek(liZero, STREAM_SEEK_CUR, (ULARGE_INTEGER*)&cbMax);
                        m_pStmCachedRead->Seek(liZero, STREAM_SEEK_SET, 0);
                        m_cbMax = DWORD(cbMax);
                        *pSize = m_cbMax + sizeof(MBV_HEADER);
                        
                    }
                    else
                    {
                        if (hr == 0x800a02e0)
                            OutputDebugString(__TEXT("error: MBVDelegator: Tried to marshal object prior to IPersistStreamInit::InitNew was called.\n"));
                    }
                }
            }
            else
                *pSize = m_cbMax + sizeof(MBV_HEADER);
            
        }
    }
    return hr;    
}

STDMETHODIMP 
CMBVDelegator::MarshalInterface(IStream *pStm, REFIID riid, void *pv,
                                DWORD dwDestContext, void *pvDestContext, DWORD mshlflags)
{
    HRESULT hr = S_OK;
    if (dwDestContext == MSHCTX_INPROC && m_pUnkFTM)
    {
        CComPtr<IMarshal> pMsh;
        HRESULT hr = m_pUnkFTM->QueryInterface(&pMsh);
        if (SUCCEEDED(hr))
            hr = pMsh->MarshalInterface(pStm, riid, pv, dwDestContext, pvDestContext, mshlflags);
    }
    else
    {
        CLSID clsidDelegatee;
        HRESULT hr = m_ppsDelegatee->GetClassID(&clsidDelegatee);
        if (SUCCEEDED(hr))
        {
            CComPtr<IStream> pStmClone;
            hr = pStm->Clone(&pStmClone);
            if (SUCCEEDED(hr))
            {
                MBV_HEADER header;
                header.guidSignature = __uuidof(MBVDelegator);
                header.clsid = clsidDelegatee;
                hr = pStm->Write(&header, sizeof(header), 0);
                if (SUCCEEDED(hr))
                {
                    if (!m_pStmCachedRead)
                    {
                        hr = m_ppsDelegatee->Save(pStm, FALSE);
                        if (hr == 0x800a02e0)
                            OutputDebugString(__TEXT("error: MBVDelegator: Tried to marshal object prior to IPersistStreamInit::InitNew was called.\n"));
                    }
                    else
                    {
                        ULARGE_INTEGER li;
                        li.QuadPart = m_cbMax;
                        hr = m_pStmCachedRead->CopyTo(pStm, li, 0, 0);
                        m_pStmCachedRead.Release();
                    }
                }
                // rewrite header with valid cb
                unsigned __int64 start, end;
                LARGE_INTEGER liZero = { 0 };
                hr = pStm->Seek(liZero, STREAM_SEEK_CUR, (ULARGE_INTEGER*)&end);
                if (SUCCEEDED(hr))
                    hr = pStmClone->Seek(liZero, STREAM_SEEK_CUR, (ULARGE_INTEGER*)&start);
                if (SUCCEEDED(hr))
                {
                    header.cb = end - start - sizeof(MBV_HEADER);
                    hr = pStmClone->Write(&header, sizeof(header), 0);
                }
            }
        }
    }
    return hr;
}

extern HRESULT IsApartmentNeutral(IUnknown *pUnk, bool *pbFTM);
extern HRESULT GetFTMCLSID(CLSID *pclsid);


STDMETHODIMP 
CMBVDelegator::UnmarshalInterface(IStream *pStm, REFIID riid, void **ppv)
{
    *ppv = 0;
    
    MBV_HEADER header;
    HRESULT hr = pStm->Read(&header, sizeof(header), 0);
    if (hr == S_OK)
    {
        CComPtr<IUnknown> pUnkDelegatee;
        hr = CoCreateInstance(header.clsid, 0, CLSCTX_ALL, __uuidof(pUnkDelegatee), (void**)&pUnkDelegatee);
        if (SUCCEEDED(hr))
            if (FAILED(hr = pUnkDelegatee->QueryInterface(&m_ppsDelegatee)))
                hr = pUnkDelegatee->QueryInterface(__uuidof(IPersistStreamInit), (void**)&m_ppsDelegatee);
            
            if (SUCCEEDED(hr))
            {
                hr = m_ppsDelegatee->Load(pStm);
                if (SUCCEEDED(hr))
                {
                    bool bFTM;
                    hr = IsApartmentNeutral(m_ppsDelegatee, &bFTM);
                    if (SUCCEEDED(hr))
                    {
                        if (bFTM)
                            hr = CoCreateFreeThreadedMarshaler(static_cast<IMarshal*>(this), &m_pUnkFTM);
                        if (SUCCEEDED(hr))
                            hr = GetControllingUnknown()->QueryInterface(riid, ppv);
                    }
                }
            }
    }
    else
        hr = RPC_E_CLIENT_CANTUNMARSHAL_DATA;
    return hr;
}

STDMETHODIMP 
CMBVDelegator::ReleaseMarshalData(IStream *pStm)
{
    MBV_HEADER header = { 0 };
    HRESULT hr = pStm->Read(&header, sizeof(header), 0);
    if (SUCCEEDED(hr) && header.guidSignature == __uuidof(MBVDelegator))
        hr = pStm->Seek(*(LARGE_INTEGER*)&header.cb, STREAM_SEEK_CUR, 0);
    return hr;
}

STDMETHODIMP 
CMBVDelegator::DisconnectObject(DWORD dwReserved)
{
    return S_OK;
}
