
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 5.03.0268 */
/* at Wed Sep 29 12:02:58 1999
 */
/* Compiler settings for C:\local\soap\isapi\SimpleExtSrv\SimpleExtSrv.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32 (32b run), ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __SimpleExtSrv_h__
#define __SimpleExtSrv_h__

/* Forward Declarations */ 

#ifndef __SimpleExt_FWD_DEFINED__
#define __SimpleExt_FWD_DEFINED__

#ifdef __cplusplus
typedef class SimpleExt SimpleExt;
#else
typedef struct SimpleExt SimpleExt;
#endif /* __cplusplus */

#endif 	/* __SimpleExt_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 


#ifndef __SIMPLEEXTSRVLib_LIBRARY_DEFINED__
#define __SIMPLEEXTSRVLib_LIBRARY_DEFINED__

/* library SIMPLEEXTSRVLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_SIMPLEEXTSRVLib;

EXTERN_C const CLSID CLSID_SimpleExt;

#ifdef __cplusplus

class DECLSPEC_UUID("1F686324-311D-46A1-A3DF-56B7587331FA")
SimpleExt;
#endif
#endif /* __SIMPLEEXTSRVLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


