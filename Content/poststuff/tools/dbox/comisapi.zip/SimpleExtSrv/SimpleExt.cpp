// SimpleExt.cpp : Implementation of CSimpleExt
#include "stdafx.h"
#include "SimpleExtSrv.h"
#include "SimpleExt.h"

/////////////////////////////////////////////////////////////////////////////
// CSimpleExt

STDMETHODIMP_(BOOL) 
CSimpleExt::GetExtensionVersion(const char *pszDLLName, 
                                HSE_VERSION_INFO  *pVer)
{
    pVer->dwExtensionVersion = HSE_VERSION;
    lstrcpyA(pVer->lpszExtensionDesc, "Hello Extension");
    return TRUE;
}

STDMETHODIMP_(DWORD)  
CSimpleExt::HttpExtensionProc(EXTENSION_CONTROL_BLOCK * pECB)
{
    char sz[] = "Hello, world";
    DWORD cb = sizeof(sz) - 1;
    if (pECB->WriteClient(pECB->ConnID, sz, &cb, HSE_IO_SYNC ))
        return HSE_STATUS_SUCCESS;
    else
        return HSE_STATUS_ERROR;
}

STDMETHODIMP_(BOOL)  
CSimpleExt::TerminateExtension(DWORD dwFlags)
{
    return TRUE;
}
