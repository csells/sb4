	
// SimpleExt.h : Declaration of the CSimpleExt

#ifndef __SIMPLEEXT_H_
#define __SIMPLEEXT_H_

#include "resource.h"       // main symbols

#include "../isapiitf.h"

/////////////////////////////////////////////////////////////////////////////
// CSimpleExt
class ATL_NO_VTABLE CSimpleExt : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CSimpleExt, &CLSID_SimpleExt>,
	public IIsapiExtension
{
public:
	CSimpleExt()
	{
		m_pUnkMarshaler = NULL;
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SIMPLEEXT)
DECLARE_NOT_AGGREGATABLE(CSimpleExt)
DECLARE_GET_CONTROLLING_UNKNOWN()

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CSimpleExt)
	COM_INTERFACE_ENTRY(IIsapiExtension)
	COM_INTERFACE_ENTRY_AGGREGATE(IID_IMarshal, m_pUnkMarshaler.p)
END_COM_MAP()

	HRESULT FinalConstruct()
	{
		return CoCreateFreeThreadedMarshaler(
			GetControllingUnknown(), &m_pUnkMarshaler.p);
	}

	void FinalRelease()
	{
		m_pUnkMarshaler.Release();
	}

	CComPtr<IUnknown> m_pUnkMarshaler;

// IIsapiExtension
public:
    STDMETHODIMP_(BOOL) GetExtensionVersion(const char *pszDLLName, HSE_VERSION_INFO  *pVer);
    STDMETHODIMP_(DWORD)  HttpExtensionProc(EXTENSION_CONTROL_BLOCK * pECB);
    STDMETHODIMP_(BOOL)  TerminateExtension(DWORD dwFlags);


};

#endif //__SIMPLEEXT_H_
