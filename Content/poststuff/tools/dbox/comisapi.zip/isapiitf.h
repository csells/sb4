

#ifndef _IISAPI_H
#define _IISAPI_H

#include <httpext.h>

interface __declspec(uuid("{87FC6F03-53E7-4165-83BE-8190F2009F5D}")) IIsapiExtension : IUnknown
{
    STDMETHOD_(BOOL, GetExtensionVersion)(const char *pszDLLName, HSE_VERSION_INFO  *pVer) PURE;
    STDMETHOD_(DWORD, HttpExtensionProc)(EXTENSION_CONTROL_BLOCK * pECB) PURE;
    STDMETHOD_(BOOL, TerminateExtension)(DWORD dwFlags) PURE;
};

#endif
