/////////////////////////////////////////////////////////////////////////
//
// XMLPropertyBag example - Copyright 1999, DevelopMentor
//
// Oct. 17, 1999 - Richard Anderson
//                 As per http://www.vivid-creations.com/dom/xmlpropbag/oct_18.zip
//
// Sept. 4, 1999 - Don Box
//
// This file implements three functions:
//
//    GetPropertyBagFromXML - Builds a property bag on top of an existing XML element
//    SaveToXML - Saves an IPersistPropertyBag-based object to an XML stream
//    LoadFromXML - Loads an IPersistPropertyBag-based object from an XML stream
//
//  This implementation supports everything you can put into a variant EXCEPT arrays.
//  FWIW, VB doesn't support writing arrays or UDTs to a property bag. This code
//  supports UDTs but not arrays (for now).
// 
//  This code also assumes that object references are unique. If you try to store
//  the same object reference twice, I serialize the object twice.
//
//

#include "stdafx.h"


//
// Depending upon the XML support you are using define one of these 
//

//#define USE_MSXML
#define USE_ACTIVEDOM                   // Download from http://www.vivid-creations.com

// Use the Microsoft support - required IE4/IE5 to be installed

#ifdef USE_MSXML
#import "msxml.dll" rename_namespace("xml") raw_interfaces_only no_implementation
#endif

// Using the Vivid Creations XML support - doesn't required IE4/5 to be installed.
// Check http://www.vivid-creations.com/dom/index.htm for details about ActiveDOM

#ifdef USE_ACTIVEDOM  
#import "vcxml10.dll" rename_namespace("xml") raw_interfaces_only no_implementation
#endif


// Sample component

#import "vb6component/foo.dll" no_namespace raw_interfaces_only no_implementation

#include <atlbase.h>
CComModule _Module;
#include <atlcom.h>
#include <atldb.h>

HRESULT GetPropertyBagFromXML( xml::IXMLDOMDocument *pDocument, 
                               xml::IXMLDOMElement *pElement, 
                               IPropertyBag **ppPropBag);
HRESULT SaveToXML( xml::IXMLDOMDocument *pDocument, 
                   xml::IXMLDOMElement *pElement, 
                   IPersistPropertyBag *pObj, 
                   BOOL bClearDirty, 
                   BOOL bSaveAllProperties);

HRESULT LoadFromXML( xml::IXMLDOMDocument *pDocument, 
                     xml::IXMLDOMElement *pElement, 
                     IErrorLog *pLog, 
                     IPersistPropertyBag **ppObj);



// Purpose: MSXML uses variants where the W3C spec actually specifies strings.
//          This functions just bridges the differences.

HRESULT GetAttributeToBSTRVariant( xml::IXMLDOMElement *pElem,
                                   CComBSTR& sAttributeName,
                                   CComVariant& var )
{
#ifdef USE_MSXML
HRESULT hr;
hr = pElem->getAttribute(sAttributeName, &var);
if (FAILED(hr)) return hr;
hr = var.ChangeType(VT_BSTR);
#endif

#ifdef USE_ACTIVEDOM
HRESULT hr;
CComBSTR sVal;
hr = pElem->getAttribute(sAttributeName, &sVal);
if (FAILED(hr)) return hr;
var = sVal;
#endif

return hr;
}
// Purpose: MSXML uses variants where the W3C spec actually specifies strings.
//          This functions just bridges the differences.

HRESULT SetAttributeVariant( xml::IXMLDOMElement *pElem,
                             CComBSTR& sAttributeName,
                             CComVariant& var )
{
#ifdef USE_MSXML
HRESULT hr;
hr = pElem->setAttribute(sAttributeName, var);
if (FAILED(hr)) return hr;
#endif

#ifdef USE_ACTIVEDOM
HRESULT hr;
CComBSTR sVal;
var.ChangeType( VT_BSTR );
hr = pElem->setAttribute(sAttributeName, var.bstrVal);
if (FAILED(hr)) return hr;
#endif

return hr;
}

class XMLPropertyBag : public CComObjectRootEx<CComMultiThreadModelNoCS>, 
                       public IPropertyBag
{
public:
    BEGIN_COM_MAP(XMLPropertyBag)
        COM_INTERFACE_ENTRY(IPropertyBag)
    END_COM_MAP()
    CComPtr<xml::IXMLDOMDocument> m_doc;
    CComPtr<xml::IXMLDOMElement>  m_elem;


    STDMETHODIMP Read(LPCOLESTR pwszPropName, VARIANT *pVar, IErrorLog *pErrorLog)
    {
        CComPtr<xml::IXMLDOMNode> node;
        HRESULT hr = m_elem->selectSingleNode(CComBSTR(pwszPropName), &node);
        if (FAILED(hr)) return hr;
        if (hr == S_FALSE) 
        {
            pVar->vt = VT_EMPTY;
            return S_OK;
        }

        CComPtr<xml::IXMLDOMElement> pElem;
        hr = node->QueryInterface(&pElem);
        if (FAILED(hr)) return hr;

        CComVariant varVT;

       // MSXML breaks from the W3C spec so we need different code

#ifdef USE_MSXML
        hr = pElem->getAttribute(CComBSTR(L"vt"), &varVT);
#endif

#ifdef USE_ACTIVEDOM
        CComBSTR sVal;
        hr = pElem->getAttribute(CComBSTR(L"vt"), &sVal);
        varVT = sVal;
#endif

        if (FAILED(hr)) return hr;
        
        hr = varVT.ChangeType(VT_I2);
        if (FAILED(hr)) return hr;

        VARTYPE vt = varVT.iVal;

        if (vt == VT_RECORD)
        {
            CComVariant var;

            // Get the uuid 

            hr = GetAttributeToBSTRVariant( pElem, CComBSTR(L"uuid"), var );
            if (FAILED(hr)) return hr;
            GUID uuid;
            hr = CLSIDFromString(var.bstrVal, &uuid);
            if (FAILED(hr)) return hr;
            var.Clear();

            // Get the libid

            hr = GetAttributeToBSTRVariant( pElem, CComBSTR(L"libid"), var );
            if (FAILED(hr)) return hr;
            GUID libid;
            hr = CLSIDFromString(var.bstrVal, &libid);
            if (FAILED(hr)) return hr;
            var.Clear();

      
            hr = GetAttributeToBSTRVariant( pElem, CComBSTR(L"major"), var );
            if (FAILED(hr)) return hr;
            hr = var.ChangeType(VT_I2);
            if (FAILED(hr)) return hr;
            WORD wMajor = var.iVal;
            var.Clear();

            hr = GetAttributeToBSTRVariant( pElem, CComBSTR(L"minor"), var );
            hr = var.ChangeType(VT_I2);
            if (FAILED(hr)) return hr;
            WORD wMinor = var.iVal;
            var.Clear();

            hr = GetAttributeToBSTRVariant( pElem, CComBSTR(L"lcid"), var );
            if (FAILED(hr)) return hr;
            hr = var.ChangeType(VT_UI4);
            if (FAILED(hr)) return hr;
            LCID lcid = var.ulVal;
            var.Clear();

            CComPtr<IRecordInfo> pRecInfo;
            hr = GetRecordInfoFromGuids(libid, wMajor, wMinor, lcid, uuid, &pRecInfo);
            if (FAILED(hr)) return hr;

            void *pvRecord = pRecInfo->RecordCreate();

            ULONG cFields;
            hr = pRecInfo->GetFieldNames(&cFields, 0);
            if (FAILED(hr)) return hr;

            BSTR *prgNames = new BSTR[cFields];
            CAutoMemRelease<BSTR> autoFree(prgNames);
            hr = pRecInfo->GetFieldNames(&cFields, prgNames);
            if (FAILED(hr)) return hr;

            CComPtr<IPropertyBag> pPropBag;
            hr = GetPropertyBagFromXML(m_doc.p, pElem.p, &pPropBag);
            for (ULONG i = 0; i < cFields; i++)
            {
                if (SUCCEEDED(hr))
                {
                    CComVariant value;
                    hr = pPropBag->Read(prgNames[i], &value, pErrorLog);
                    if (SUCCEEDED(hr))
                        hr = pRecInfo->PutField(INVOKE_PROPERTYPUT, pvRecord, prgNames[i], &value);\
                }
                SysFreeString(prgNames[i]);
            }
            if (FAILED(hr)) return hr;
            pVar->vt = VT_RECORD;
            pVar->pRecInfo = pRecInfo.Detach();
            pVar->pvRecord = pvRecord;

        }
        else if (vt == VT_UNKNOWN || vt == VT_DISPATCH)
        {
            CComPtr<IPersistPropertyBag> pppb;
            hr = LoadFromXML(m_doc.p, pElem.p, pErrorLog, &pppb);
            if (FAILED(hr)) return hr;

            pVar->vt = vt;
            if (hr == S_OK)
                return pppb->QueryInterface((vt == VT_UNKNOWN ? IID_IUnknown : IID_IDispatch), (void**)&pVar->punkVal);
            else
            {
                pVar->punkVal = 0;
                return S_FALSE;
            }
        }
        else if (vt == VT_BSTR)
        {
            hr = pElem->get_text(&pVar->bstrVal);
            if (FAILED(hr)) return hr;
            pVar->vt = vt;
        }
        else
        {
            CComVariant textValue;
            hr = pElem->get_text(&textValue.bstrVal);
            if (FAILED(hr)) return hr;
            textValue.vt = VT_BSTR;
            return VariantChangeType(pVar, &textValue, 0, vt);
        }


        return S_OK;
    }

    STDMETHODIMP Write(LPCOLESTR pwszPropName, VARIANT *pVar)
    {
        VARTYPE vt = pVar->vt;
        
        if (vt & VT_BYREF)
            return E_NOTIMPL;


        CComPtr<xml::IXMLDOMElement> pElem;
        HRESULT hr = m_doc->createElement(CComBSTR(pwszPropName), &pElem);
        if (FAILED(hr)) return hr;


        CComVariant Variant(vt);
        hr = Variant.ChangeType( VT_BSTR );
        if  ( FAILED(hr) ) return hr;

#ifdef USE_ACTIVEDOM
        hr = pElem->setAttribute(CComBSTR(L"vt"), Variant.bstrVal );
#endif

#ifdef USE_MSXML
        hr = pElem->setAttribute(CComBSTR(L"vt"), Variant );
#endif

        if (FAILED(hr)) return hr;

        if (vt & VT_ARRAY)
        {
            return E_NOTIMPL;
        }
        else if (vt == VT_RECORD)
        {
            CComPtr<IRecordInfo> pRecInfo = pVar->pRecInfo;
            void *pvRecord = pVar->pvRecord;

            GUID guid;
            hr = pRecInfo->GetGuid(&guid);
            if (FAILED(hr)) return hr;

            CComBSTR bstr(guid);
#ifdef USE_MSXML
            hr = pElem->setAttribute(CComBSTR(L"uuid"), CComVariant(bstr));
#endif
#ifdef USE_ACTIVEDOM
            hr = pElem->setAttribute(CComBSTR(L"uuid"), bstr);
#endif

            if (FAILED(hr)) return hr;


            CComPtr<ITypeInfo> pTypeInfo;
            hr = pRecInfo->GetTypeInfo(&pTypeInfo);
            if (FAILED(hr)) return hr;

            CComPtr<ITypeLib> pTypeLib;
            UINT index;
            hr  = pTypeInfo->GetContainingTypeLib(&pTypeLib, &index);
            if (FAILED(hr)) return hr;

            TLIBATTR *pattr = 0;
            hr = pTypeLib->GetLibAttr(&pattr);
            if (FAILED(hr)) return hr;

            hr = SetAttributeVariant(pElem, CComBSTR(L"libid"), CComVariant(CComBSTR(pattr->guid)));
            if (FAILED(hr)) return hr;
            hr = SetAttributeVariant(pElem, CComBSTR(L"major"), CComVariant(pattr->wMajorVerNum));
            if (FAILED(hr)) return hr;
            hr = SetAttributeVariant(pElem, CComBSTR(L"minor"), CComVariant(pattr->wMinorVerNum));
            if (FAILED(hr)) return hr;
            hr = SetAttributeVariant(pElem, CComBSTR(L"lcid"), CComVariant(long(pattr->lcid)));
            if (FAILED(hr)) return hr;

            pTypeLib->ReleaseTLibAttr(pattr);

            ULONG cFields;
            hr = pRecInfo->GetFieldNames(&cFields, 0);
            if (FAILED(hr)) return hr;

            BSTR *prgNames = new BSTR[cFields];
            CAutoMemRelease<BSTR> autoFree(prgNames);
            hr = pRecInfo->GetFieldNames(&cFields, prgNames);
            if (FAILED(hr)) return hr;

            CComPtr<IPropertyBag> pPropBag;
            hr = GetPropertyBagFromXML(m_doc.p, pElem.p, &pPropBag);
            for (ULONG i = 0; i < cFields; i++)
            {
                if (SUCCEEDED(hr))
                {
                    CComVariant value;
                    hr = pRecInfo->GetField(pvRecord, prgNames[i], &value);
                    if (SUCCEEDED(hr))
                        hr = pPropBag->Write(prgNames[i], &value);
                }
                SysFreeString(prgNames[i]);
            }
            if (FAILED(hr)) return hr;

        }
        else if (vt == VT_UNKNOWN || vt == VT_DISPATCH)
        {
            CComPtr<IPersistPropertyBag> pppb;
            if (pVar->punkVal)
            {
                hr = pVar->punkVal->QueryInterface(&pppb);
                if (FAILED(hr)) return hr;
            }

            hr = SaveToXML(m_doc.p, pElem.p, pppb.p, TRUE, TRUE);
            if (FAILED(hr)) return hr;
        }
        else if (vt == VT_BSTR)
        {
            hr = pElem->put_text(pVar->bstrVal);
            if (FAILED(hr)) return hr;
        }
        else
        {
            CComVariant value;
            hr = VariantChangeType(&value, pVar, 0, VT_BSTR);
            if (FAILED(hr)) return hr;

            hr = pElem->put_text(value.bstrVal);
            if (FAILED(hr)) return hr;

        }

#ifdef USE_MSXML
        return m_elem->appendChild(pElem.p, 0);
#endif
#ifdef USE_ACTIVEDOM
        return m_elem->appendChild(pElem.p);
#endif
    }
};


HRESULT GetPropertyBagFromXML(xml::IXMLDOMDocument *pDocument, xml::IXMLDOMElement *pElement, IPropertyBag **ppPropBag)
{
    CComObject<XMLPropertyBag> *pPropBag = 0;
    HRESULT hr = pPropBag->CreateInstance(&pPropBag);
    if (FAILED(hr)) return hr;

    pPropBag->m_doc = pDocument;
    pPropBag->m_elem = pElement;
    return pPropBag->QueryInterface(ppPropBag);
}

HRESULT SaveToXML(xml::IXMLDOMDocument *pDocument, xml::IXMLDOMElement *pElement, IPersistPropertyBag *pObj, BOOL bClearDirty, BOOL bSaveAllProperties)
{
    CComPtr<IPropertyBag> pPropBag;
    HRESULT hr = GetPropertyBagFromXML(pDocument, pElement, &pPropBag);
    if (FAILED(hr)) return hr;
    CLSID clsid = { 0 };
    if (pObj)
    {
        hr = pObj->GetClassID(&clsid);
        if (FAILED(hr)) return hr;
    }

    WCHAR wszGUID[40];
    StringFromGUID2(clsid, wszGUID, sizeof(wszGUID));

    hr = SetAttributeVariant(pElement, CComBSTR(L"clsid"), CComVariant(wszGUID));
    if (FAILED(hr)) return hr;

    if (pObj)
        return pObj->Save(pPropBag, bClearDirty, bSaveAllProperties);
    else
        return S_OK;
}

HRESULT LoadFromXML(xml::IXMLDOMDocument *pDocument, xml::IXMLDOMElement *pElement, IErrorLog *pLog, IPersistPropertyBag **ppObj)
{
    CComVariant varCLSID;
    HRESULT hr = GetAttributeToBSTRVariant( pElement, CComBSTR(L"clsid"), varCLSID);
    if (FAILED(hr) || varCLSID.vt != VT_BSTR) return hr;

    CLSID clsid;
    hr = CLSIDFromString(varCLSID.bstrVal, &clsid);
    if (FAILED(hr)) return hr;

    if (clsid == GUID_NULL)
    {
        *ppObj = 0;
        return S_FALSE;
    }

    CComPtr<IPersistPropertyBag> pObj;
    hr = pObj.CoCreateInstance(clsid);
    if (FAILED(hr)) return hr;


    CComPtr<IPropertyBag> pPropBag;
    hr = GetPropertyBagFromXML(pDocument, pElement, &pPropBag);
    if (FAILED(hr)) return hr;

    hr = pObj->Load(pPropBag, pLog);
    if (FAILED(hr)) return hr;

    *ppObj = pObj.Detach();

    return S_OK;

}

HRESULT main(int argc, char **argv)
{
    USES_CONVERSION;
    HRESULT hr = CoInitializeEx(0, 0);
    if (FAILED(hr)) return hr;
    {

    CComPtr<xml::IXMLDOMDocument> pDoc;
    hr = pDoc.CoCreateInstance(__uuidof(xml::DOMDocument));
    if (FAILED(hr)) return hr;

    if  ( stricmp( argv[1], "save" ) == 0 ) 
    {        
        CComPtr<xml::IXMLDOMElement> pElem;
        hr = pDoc->createElement(CComBSTR(L"Object"), &pElem);
        if (FAILED(hr)) return hr;

        // RJA - Need to add element to doc before this line will work.

#ifdef USE_MSXML
        hr = pDoc->appendChild( pElem, 0 );
#endif

#ifdef USE_ACTIVEDOM
        hr = pDoc->appendChild( pElem );
#endif

        if (FAILED(hr)) return hr;
      
        // RJA - end of change 

        CComPtr<xml::IXMLDOMElement> pRoot;
        hr = pDoc->get_documentElement(&pRoot);
        if (FAILED(hr)) return hr;
    

//        hr = pRoot->appendChild(pElem.p, 0);
//        if (FAILED(hr)) return hr;

        CComPtr<IPersistPropertyBag> pppb;
        hr = pppb.CoCreateInstance(__uuidof(Foo));
        if (FAILED(hr)) return hr;

        hr = pppb->InitNew();
        if (FAILED(hr)) return hr;

// todo: replace this code with something specific to your object
        CComPtr<_Foo> pObj;
        hr = pppb->QueryInterface(&pObj);
        if (FAILED(hr)) return hr;

        // Set various value in the object so the save is more meaningful.
        // The default VB component provided does set a few values by default as
        // an example.
        
#ifdef SKIP
        hr = pObj->SetValues(CComBSTR(L"FooBar"), CComVariant(34), 1, 2, 3, 4);
        if (FAILED(hr)) return hr;
#endif


        hr = SaveToXML(pDoc.p, pElem.p, pppb, TRUE, TRUE);
        if (FAILED(hr)) return hr;
         
#ifdef USE_MSXML
        hr = pDoc->save(CComVariant(argv[2]));
#endif

#ifdef USE_ACTIVEDOM
        hr = pDoc->save(CComBSTR(argv[2]));
#endif

        if (FAILED(hr)) return hr;
    }
    else
    {

       // RJA - load the user specified file

       VARIANT_BOOL b;
#ifdef USE_MSXML
       hr = pDoc->load(CComVariant(argv[2]), &b);
#endif

#ifdef USE_ACTIVEDOM
       hr = pDoc->load(CComBSTR(argv[2]), &b);
#endif

       if (FAILED(hr)) return hr;

       // RJA - Check if the load worked or not.

       if  ( b == VARIANT_FALSE ) 
       {
           printf("The load failed\n");
           return E_FAIL;
       }

        CComPtr<xml::IXMLDOMNode> node;
        hr = pDoc->selectSingleNode(CComBSTR(L"//Object"), &node);
        if (FAILED(hr)) return hr;

        CComPtr<xml::IXMLDOMElement> pElem;
        hr = node->QueryInterface(&pElem);
        if (FAILED(hr)) return hr;

        CComPtr<IPersistPropertyBag> pppb;
        hr = LoadFromXML(pDoc.p, pElem.p, 0, &pppb);
        if (FAILED(hr)) return hr;

// todo: replace this code with something specific to your object
        CComPtr<_Foo> pObj;
        hr = pppb->QueryInterface(&pObj);
        if (FAILED(hr)) return hr;

#ifdef SKIP
        hr = pObj->ShowSelf();
        if (FAILED(hr)) return hr;
#endif
    }
}
    CoUninitialize();
    return S_OK;
}
