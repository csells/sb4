//////////////////////////////////////////////////////////////////
//
// enumgen.h - Copyright 1997, Don Box
//
// MIDL/C Header that vastly simplifies defining enumerator interfaces
// in IDL. This header file ensures that the generated proxy/stub DLL
// uses the method aliasing technique to allow null for the 3rd parameter 
// to Next. It does this via trickery to say the least.
// 
//
// example:
/*
    enumerator(long, IEnumLong, 12345678-1234-4567-2345-141425253636)
    enumerator(IDispatch *, IEnumDispatch, 12345679-1234-4567-2345-141425253636)

    [ uuid(1234567A-1234-4567-2345-141425253636), object ]
    interface IUseEm : IUnknown
    {
      HRESULT GetSomeLongs([out] IEnumLong **ppel);
      HRESULT CallSomeMethod([in] IEnumDispatch *ped, LPCOLESTR pwszMethodName);
    }

*/
//

#ifndef _ENUMGEN_H
#define _ENUMGEN_H


#if (defined(__midl))

#define enumerator(xxx, IEnumXXX, guid) \
[ uuid(guid), object, pointer_default(unique) ] \
interface IEnumXXX : IUnknown { \
  [local] HRESULT Next([in] ULONG cElems, [out] xxx *prgElems, [out] ULONG *pcFetched); \
  [call_as(Next)] HRESULT RemNext([in] ULONG cElems, [out, size_is(cElems), length_is(*pcFetched)] xxx *prgElems, [out] ULONG *pcFetched); \
  HRESULT Skip([in] ULONG cElems); \
  HRESULT Reset(void); \
  HRESULT Clone([out] IEnumXXX **ppenum); \
}\
cpp_quote("#ifdef __midl_proxy")\
cpp_quote("#include \"enumgen.h\"")\
cpp_quote("GENERATE_NEXT_CALLAS(")\
cpp_quote(#IEnumXXX)\
cpp_quote(",")\
cpp_quote(#xxx)\
cpp_quote(")")\
cpp_quote("#endif")

#else

#define GENERATE_NEXT_CALLAS(IEnumXXX, xxx) \
static HRESULT STDMETHODCALLTYPE IEnumXXX##_Next_Proxy\
(IEnumXXX* This, ULONG cElems, xxx *prgElems, ULONG *pcFetched) \
{  ULONG cFetched; if (pcFetched == 0 && cElems > 1) return E_INVALIDARG; else return IEnumXXX##_RemNext_Proxy(This, cElems, prgElems, pcFetched ? pcFetched : &cFetched); } \
static HRESULT STDMETHODCALLTYPE \
IEnumXXX##_Next_Stub \
(IEnumXXX * This, ULONG cElems, xxx *prgElems, ULONG *pcFetched) \
{  HRESULT hr = This->lpVtbl->Next(This, cElems, prgElems, pcFetched); if (hr == S_OK && cElems == 1) *pcFetched = 1; return hr; }

#endif

#endif
