// SimplePadView.cpp : implementation of the CSimplePadView class
//

#include "stdafx.h"
#include "SimplePad.h"

#include "SimplePadDoc.h"
#include "SimplePadView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CSimplePadView

IMPLEMENT_DYNCREATE(CSimplePadView, CEditView)

BEGIN_MESSAGE_MAP(CSimplePadView, CEditView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CEditView::OnFilePrintPreview)
END_MESSAGE_MAP()

// CSimplePadView construction/destruction

CSimplePadView::CSimplePadView()
{
	EnableActiveAccessibility();
	// TODO: add construction code here

}

CSimplePadView::~CSimplePadView()
{
}

BOOL CSimplePadView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	BOOL bPreCreated = CEditView::PreCreateWindow(cs);
	cs.style &= ~(ES_AUTOHSCROLL|WS_HSCROLL);	// Enable word-wrapping

	return bPreCreated;
}


// CSimplePadView printing

BOOL CSimplePadView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default CEditView preparation
	return CEditView::OnPreparePrinting(pInfo);
}

void CSimplePadView::OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo)
{
	// Default CEditView begin printing
	CEditView::OnBeginPrinting(pDC, pInfo);
}

void CSimplePadView::OnEndPrinting(CDC* pDC, CPrintInfo* pInfo)
{
	// Default CEditView end printing
	CEditView::OnEndPrinting(pDC, pInfo);
}


// CSimplePadView diagnostics

#ifdef _DEBUG
void CSimplePadView::AssertValid() const
{
	CEditView::AssertValid();
}

void CSimplePadView::Dump(CDumpContext& dc) const
{
	CEditView::Dump(dc);
}

CSimplePadDoc* CSimplePadView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSimplePadDoc)));
	return (CSimplePadDoc*)m_pDocument;
}
#endif //_DEBUG


// CSimplePadView message handlers
