// SimplePadView.h : interface of the CSimplePadView class
//


#pragma once


class CSimplePadView : public CEditView
{
protected: // create from serialization only
	CSimplePadView();
	DECLARE_DYNCREATE(CSimplePadView)

// Attributes
public:
	CSimplePadDoc* GetDocument() const;

// Operations
public:

// Overrides
	public:
virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// Implementation
public:
	virtual ~CSimplePadView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in SimplePadView.cpp
inline CSimplePadDoc* CSimplePadView::GetDocument() const
   { return reinterpret_cast<CSimplePadDoc*>(m_pDocument); }
#endif

