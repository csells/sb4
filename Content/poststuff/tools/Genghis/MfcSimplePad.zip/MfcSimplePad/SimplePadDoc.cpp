// SimplePadDoc.cpp : implementation of the CSimplePadDoc class
//

#include "stdafx.h"
#include "SimplePad.h"

#include "SimplePadDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CSimplePadDoc

IMPLEMENT_DYNCREATE(CSimplePadDoc, CDocument)

BEGIN_MESSAGE_MAP(CSimplePadDoc, CDocument)
END_MESSAGE_MAP()


// CSimplePadDoc construction/destruction

CSimplePadDoc::CSimplePadDoc()
{
	// TODO: add one-time construction code here

}

CSimplePadDoc::~CSimplePadDoc()
{
}

BOOL CSimplePadDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}




// CSimplePadDoc serialization

void CSimplePadDoc::Serialize(CArchive& ar)
{
	// CEditView contains an edit control which handles all serialization
	reinterpret_cast<CEditView*>(m_viewList.GetHead())->SerializeRaw(ar);
}


// CSimplePadDoc diagnostics

#ifdef _DEBUG
void CSimplePadDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CSimplePadDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CSimplePadDoc commands
