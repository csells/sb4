// SimplePad.h : main header file for the SimplePad application
//
#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols


// CSimplePadApp:
// See SimplePad.cpp for the implementation of this class
//

class CSimplePadApp : public CWinApp
{
public:
	CSimplePadApp();


// Overrides
public:
	virtual BOOL InitInstance();

// Implementation
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};

extern CSimplePadApp theApp;