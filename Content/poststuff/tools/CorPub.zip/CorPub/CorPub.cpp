// CorPub.cpp : Defines the entry point for the console application.
// Copyright (c) 2001, Chris Sells.
// ALL RIGHTS RESERVED. NO WARRANTIES EXTENDED. USE AT YOUR OWN RISK.
// You may use this code in your own projects, but you may not redistribute
// the code in source form w/o express permission from Chris Sells.
// The official home of this tools is http://www.sellsbrothers.com/.
// Comments and suggestions to csells@sellsbrothers.com.
// History:
// 10/10/01 -- Added a call to ICorDebug::Initialize to get *all* managed processes.
//             Thanks to Atif Aziz [atif.aziz@skybow.com] for the tip.
// 09/13/01 -- Initial release.

#include "stdafx.h"
#include <cor.h>
#include <corpub.h>
//#include <corpub_i.c>
#include <cordebug.h>
//#include <cordebug_i.c>
//#include "enum_iterator.h"
#pragma comment(lib, "corguids")

HRESULT DumpAppDomain(ICorPublishAppDomain* pAppDomain)
{
    // Dump the AppDomain
    ULONG32 nId;
    HR(pAppDomain->GetID(&nId));

    ULONG32 cchName = MAX_PATH;
    WCHAR   wszName[MAX_PATH+1];
    HR(pAppDomain->GetName(cchName, &cchName, wszName));

    printf("\tAppDomain 0x%x: %S\n", nId, wszName);

    return S_OK;
}

HRESULT DumpProcess(ICorPublishProcess* pProcess)
{
    // Dump the process
    UINT    nProcessId;
    HR(pProcess->GetProcessID(&nProcessId));

    ULONG32 cchDisplayName = MAX_PATH;
    WCHAR   wszDisplayName[MAX_PATH+1];
    HR(pProcess->GetDisplayName(cchDisplayName, &cchDisplayName, wszDisplayName));

    BOOL    bIsManaged;
    HR(pProcess->IsManaged(&bIsManaged));

    printf("%s process 0x%x: %S\n",
           bIsManaged ? "Managed" : "Unmanaged",
           nProcessId,
           *wszDisplayName ? wszDisplayName : L"<unknown>");

    // Enum the AppDomains
    CComPtr<ICorPublishAppDomainEnum>   spEnum;
    HR(pProcess->EnumAppDomains(&spEnum));

    ULONG   celt;
    HR(spEnum->GetCount(&celt));

    while( celt-- )
    {
        ULONG   dummy;
        CComPtr<ICorPublishAppDomain> spAppDomain;
        HR(spEnum->Next(1, &spAppDomain, &dummy));
        HR(DumpAppDomain(spAppDomain));
    }

    return S_OK;
}

HRESULT DumpProcesses()
{
    // Enum the 
    CComPtr<ICorPublish>    spPublish;
    HR(spPublish.CoCreateInstance(CLSID_CorpubPublish));

    CComPtr<ICorPublishProcessEnum> spEnum;
    HR(spPublish->EnumProcesses(COR_PUB_MANAGEDONLY, &spEnum));

    /*    BUG: ICorPublishProcessEnum implementation of Next sets celtFetched to a number          different than celt, but returns S_OK anyway. Should return S_FALSE.
         This breaks enum_iterator.

    typedef enum_iterator<ICorPublishProcessEnum, &IID_ICorPublishProcessEnum, ICorPublishProcess*, _CopyInterface<ICorPublishProcess> > CorPublishProcessEnum;
    for( CorPublishProcessEnum it = CorPublishProcessEnum(spEnum); it != CorPublishProcessEnum(); ++it )
    {
        DumpProcess(*it);
    }
    */

    ULONG   celt;
    HR(spEnum->GetCount(&celt));

    while( celt-- )
    {
        /*
        BUG: The implementation of Next *also* doesn't allow pceltFetched to be NULL
             when celt is 1. <sigh> Didn't anyone teach these fellows COM?
        */
        ULONG   dummy;
        CComPtr<ICorPublishProcess> spProcess;
        HR(spEnum->Next(1, &spProcess, &dummy));
        HR(DumpProcess(spProcess));
        printf("\n");
    }

    return S_OK;
}

HRESULT CorPub()
{
    // Atif Aziz [atif.aziz@skybow.com] suggested that we will get more processes
    // if we initialize the COR debugging sub-system.
    CComPtr<ICorDebug>  spDebug;
    HR(spDebug.CoCreateInstance(CLSID_CorDebug));
    HR(spDebug->Initialize());

    HR(DumpProcesses());
    return S_OK;
}

int _tmain(int argc, _TCHAR* argv[])
{
    CoInitialize(0);
    HRESULT hr = CorPub();
    CoUninitialize();
	return hr;
}

