//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//Copyright 1999 Dharma Shukla.

//Keep in mind that I wrote this code just for fun :-) 
//Use it at your own risk! 

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include "stdafx.H"
#include "Reader.H"
#include "PersistBag.H"
#include <fstream>

//-----------------------------------------------------------------------------------------------------------------------------
//BeginObject -  DCon.Form.1   -   {AECB25D6-4581-11D2-8A38-00C04FA3FB82} 
HRESULT CReader::StoreObject(PropertyObjBase *pBag, std::string str, CLSID* pCLSID, string &strObj, bool isSubObject)
{
	if(!pBag || !pCLSID) { return E_POINTER; }

	std::vector<string> vecStr;
	
	string::size_type pos = 0, prev_pos = 0;

	while( ( pos = str.find_first_of(' ',pos)) !=string::npos )
	{
		string tempStr = str.substr( prev_pos, pos - prev_pos);
		if( (lstrcmpi( tempStr.c_str(), "") !=0) && (lstrcmpi( tempStr.c_str(), "\t") !=0))
		{
			vecStr.push_back(tempStr);
		}
		prev_pos = ++pos;
	}
	vecStr.push_back(str.substr( prev_pos, pos - prev_pos) );//last word of the line
		
	itString itTempString = vecStr.begin();
	for(;itTempString != vecStr.end();itTempString++)
	{
		ATLTRACE(itTempString->c_str());ATLTRACE("\n");
	}


	itTempString = vecStr.begin();
	pBag->m_bIfSubProp = isSubObject;

	++itTempString; //get past the BeginObject or BeginProperty tag
	++itTempString; // get past the " - "
	
	strObj = pBag->m_strObjName = itTempString->c_str();
	
	++itTempString; // get past the Name
	++itTempString; // get past the " - "
	
	USES_CONVERSION;
	HRESULT hr = CLSIDFromString(T2OLE( itTempString->c_str() ) ,pCLSID );
	if(SUCCEEDED(hr))
	{
		memcpy(&(pBag->m_clsid),pCLSID,sizeof(CLSID) );
	}
		
	return S_OK;

}

//-------------------------------------------------------------------------------------------------------------------------------
//  AllowWindowlessActivation    =     asadasdj\asds\sd\asdsdsds

HRESULT CReader::StoreProperty(PropertyObjBase *pBag, std::string str)
{
	if(!pBag) { return E_POINTER; }
	
	std::vector<string> vecStr;
	string::size_type pos = 0, prev_pos = 0;
	
	string format;	format.insert(0," ");
	
	while( ( pos = str.find_first_of(format,pos)) !=string::npos )
	{
		string tempStr ;
		tempStr = str.substr( prev_pos, pos - prev_pos);
		
		if( (lstrcmpi( tempStr.c_str(), "") !=0) && (lstrcmpi( tempStr.c_str(), "\t") !=0) && (lstrcmpi( tempStr.c_str(), "\n") !=0))
		{
			vecStr.push_back(tempStr); 
			if( lstrcmpi( tempStr.c_str(), "=") == 0 )
			{
				prev_pos = ++pos;
				pos = str.length() - 1;
				tempStr = str.substr( prev_pos, pos - prev_pos);
				vecStr.push_back(tempStr); 
				break;
			}
		}
		prev_pos = ++pos;
	}
	itString itTempString = vecStr.begin();
	for(;itTempString != vecStr.end();itTempString++)
	{
		ATLTRACE(itTempString->c_str());ATLTRACE("\n");
	}


	itTempString = vecStr.begin();
	NameValue nv;
	
	nv.strName = itTempString->c_str();				
	itTempString++;									//Name 
	itTempString++;									//= 
	nv.varValue = itTempString->c_str();		//Value
		
	pBag->m_map_Name_Val.push_back(nv);

	return S_OK;
}
//-------------------------------------------------------------------------------------------------------------------------------
HRESULT CReader::OpenFile(LPCTSTR pszFileName)
{
	ifstream inFile(pszFileName);
	
	std::vector<string>	tempVecString;
		
	TCHAR psz[1024];
	while ( inFile.getline(psz,1024) )
	{
		tempVecString.push_back(psz);
	}

	//first close the file then do the rest
	inFile.close();

	itString it = tempVecString.begin();

	//Initialize PropertyShebang
	m_ReaderInfo.m_nControls = _ttoi(tempVecString[0].c_str());
	
	m_ReaderInfo.m_pCLSID = (CLSID*)CoTaskMemAlloc(m_ReaderInfo.m_nControls * sizeof(CLSID));
	HRESULT hr = E_FAIL;
	
	for(UINT n=0;n < m_ReaderInfo.m_nControls;n++)
	{
		ATLTRACE(tempVecString[n+1].c_str());
		ATLTRACE("\n");
		USES_CONVERSION;
		hr = CLSIDFromString(T2OLE(tempVecString[n+1].c_str()),&(m_ReaderInfo.m_pCLSID[n]));	
		it++;
		if(FAILED(hr)) { return hr; }
	}
	
	it++;

	//Now build the struct out of the temp vector of strings
	for(;it != tempVecString.end();it++)
	{	
		if(it !=0)
		{
			if( it->find("BeginObject")!= string::npos )
			{
				MainPropertyBag Bag;
				
				CLSID clsid;
				string ObjName;
				StoreObject(&Bag, it->c_str(),&clsid,ObjName); 

				it++;

				while( it->find("EndObject") == string::npos )
				{
					if( it->find("BeginProperty")!= string::npos )
					{
						LoopAndStoreProperty(it,&Bag);
						continue;
					}
					StoreProperty(&Bag,it->c_str());
					it++;
				}
				m_VecBag.push_back(Bag);
			}
		}
	}
	//Traces
	for(itPropertyBag itTrace = m_VecBag.begin();itTrace!= m_VecBag.end();itTrace++)
	{	
		if( (itTrace !=0) )
		{
			ATLTRACE("\n");ATLTRACE(itTrace->m_strObjName.c_str());ATLTRACE("\n");

			itNameValue itSub = itTrace->m_map_Name_Val.begin();
			for(;itSub != itTrace->m_map_Name_Val.end();itSub++)
			{
				ATLTRACE("\n");ATLTRACE(itSub->strName.c_str());ATLTRACE("\n");
			}
			ATLTRACE("\n");
			for(int i = 0; i < itTrace->m_SubObject.size(); i++)
			{
				itSubPropertyBag it = &itTrace->m_SubObject[i];

				for(itNameValue itSub = it->m_map_Name_Val.begin();
				itSub != it->m_map_Name_Val.end();
				itSub++)
				{
					if(itSub)
					{
						ATLTRACE("\n");
						ATLTRACE(itSub->strName.c_str());
						ATLTRACE("\n");
					}
				}
			}
		}
	}
	return S_OK;
}
//--------------------------------------------------------------------------------------------------------------------------------------------
HRESULT CReader::LoopAndStoreProperty(itString &it, SubPropBag *pBag, MainPropertyBag *pMainBag)
{
	if(!pBag || !pMainBag){ return E_POINTER; }
	
	if(it->find("BeginProperty")!= string::npos)
	{
		SubPropBag SubBag;

		CLSID clsid;
		string SubObjName;
		StoreObject(&SubBag,it->c_str(),&clsid,SubObjName,true); 
		it++; // Begin Property
		while( it->find("EndProperty") == string::npos )
		{
			LoopAndStoreProperty(it, &SubBag,pMainBag);
			it++;
		}
		
		pMainBag->m_SubObject.push_back(SubBag);
		it++;	//EndProperty
		return S_OK;
	}
	
	if( it->find("EndObject") == string::npos )
	{
		return S_OK;
	}

	StoreProperty(pBag,it->c_str()); 
	
	return S_OK;
}
//--------------------------------------------------------------------------------------------------------------------------------------------
HRESULT CReader::LoopAndStoreProperty(itString &it, MainPropertyBag *pBag)
{
	if(!pBag){ return E_POINTER; }

	SubPropBag SubBag;

	CLSID clsid;
	string SubObjName;
	StoreObject(&SubBag,it->c_str(),&clsid,SubObjName,true); 
	
	it++; //Get past the BeginProperty mark

	while( it->find("EndProperty") == string::npos )
	{
		if(it->find("BeginProperty")!= string::npos)
		{
			HRESULT hr = LoopAndStoreProperty(it, pBag);
			
			//Now add this subobject to the list
			pBag->m_SubObject.push_back(SubBag);
			
			while( it->find("EndProperty") != string::npos )
			{
				it++;	//Get past the EndProperty mark
			}
			return hr;
		}
	
		StoreProperty(&SubBag,it->c_str()); 
		it++;
	}
	
	pBag->m_SubObject.push_back(SubBag);
	if( it->find("EndProperty") != string::npos )
	{
		it++;	//Get past the EndProperty mark
	}
	return S_OK;
}
//--------------------------------------------------------------------------------------------------------------------------------------------



