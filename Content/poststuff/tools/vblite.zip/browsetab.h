//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//Copyright 1999 Dharma Shukla.

//Keep in mind that I wrote this code just for fun :-) 
//So use it at your own risk! 

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#pragma once
#ifndef _BROWSETAB_H_
#define _BROWSETAB_H_
#include "PropBrowseCtl.H"
//---------------------------------------------------------------------------------------------------------------------------
//
//
//
//--------------------------------------------------------------------------------------------------------------------------------------------------
typedef CWindowImplBaseT<CTabCtrl, CWinTraits<WS_CHILDWINDOW|WS_VISIBLE|WS_TABSTOP|WS_GROUP|TCS_TOOLTIPS|TCS_TABS|TCS_RIGHTJUSTIFY|TCS_SINGLELINE,WS_EX_WINDOWEDGE|WS_EX_NOPARENTNOTIFY|WS_EX_RIGHTSCROLLBAR|WS_EX_LEFT|WS_EX_LTRREADING>  > CWindowImplTab;

class CBrowseTabContainer;

class CBrowseTab : public CWindowImplTab
{
public:
	DECLARE_WND_SUPERCLASS(_T("TabControl"),GetWndClassName());	

	CBrowseTab(CBrowseTabContainer *pContainer) ;

	~CBrowseTab()
	{
		if(m_hTabFont)
		{
			::DeleteObject(m_hTabFont);
			m_hTabFont = NULL;
		}
	}

BEGIN_MSG_MAP(CBrowseTab)
	MESSAGE_HANDLER(WM_CREATE, OnCreate)
	MESSAGE_HANDLER(WM_SIZE, OnSize)
END_MSG_MAP()
public://Handlers
	LRESULT OnCreate(UINT , WPARAM , LPARAM , BOOL& bHandled);
	LRESULT OnSize(UINT , WPARAM , LPARAM , BOOL& bHandled);

public: //helpers
	void		InitOutputTab(bool bShow = true);
	
public:
	
	HWND Create(HWND hWndParent, RECT& rcPos, LPCTSTR szWindowName = NULL,
			DWORD dwStyle = 0, DWORD dwExStyle = 0,
			UINT nID = 0, LPVOID lpCreateParam = NULL)
	{
		if (GetWndClassInfo().m_lpszOrigName == NULL)
			GetWndClassInfo().m_lpszOrigName = GetWndClassName();
		ATOM atom = GetWndClassInfo().Register(&m_pfnSuperWindowProc);

		dwStyle		|= GetWndStyle(dwStyle);
		dwExStyle	|= GetWndExStyle(dwExStyle);

		return CWindowImplTab::Create(hWndParent, rcPos, szWindowName,dwStyle, dwExStyle, nID, atom, lpCreateParam);
	}

	CPropertyBrowseControl& GetNativeBrowser(){ return m_wndPBNative; }
	CPropertyBrowseControl& GetAmbientBrowser(){ return m_wndPBAmbient; }
	CPropertyBrowseControl& GetExtendedBrowser(){ return m_wndPBExtended; }
	
	HFONT GetFont()const { return m_hTabFont; }

private:
	CPropertyBrowseControl		m_wndPBNative;
	CPropertyBrowseControl		m_wndPBAmbient;
	CPropertyBrowseControl		m_wndPBExtended;
	CBrowseTabContainer			*m_pContainer;
	HFONT						m_hTabFont;


};
//---------------------------------------------------------------------------------------------------------------------------
//
//
//
//--------------------------------------------------------------------------------------------------------------------------
class CBrowseTabContainer : public CWindowImpl<CBrowseTabContainer>
{
public:

	CBrowseTabContainer():	m_wndBrowseTab(this),m_wndControlCombo(this,1){}
	
	~CBrowseTabContainer(){}

	static CWndClassInfo& GetWndClassInfo()
	{
		static CWndClassInfo wc =
		{
			{ sizeof(WNDCLASSEX), 0, StartWindowProc,
			  0, 0, 0, 0, 0, (HBRUSH)(COLOR_BTNFACE + 1), 0, _T("Browser_Container"), 0 },
			NULL, NULL, IDC_ARROW, TRUE, 0, _T("")
		};
		return wc;
	}
	
BEGIN_MSG_MAP(CBrowseTabContainer)
	MESSAGE_HANDLER(WM_CREATE, OnCreate)
	MESSAGE_HANDLER(WM_SIZE, OnSize)
	NOTIFY_CODE_HANDLER(TCN_SELCHANGE, OnTabChanged)
	COMMAND_CODE_HANDLER(CBN_SELENDOK, OnSelEndOK)
ALT_MSG_MAP(1)

END_MSG_MAP()

	
public://Handlers
	LRESULT OnCreate(UINT , WPARAM , LPARAM , BOOL& bHandled);
	LRESULT OnSize(UINT , WPARAM , LPARAM , BOOL& bHandled);
	LRESULT OnTabChanged(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);
	LRESULT OnSelEndOK(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
	HRESULT	EnumerateControlsAndFillCombo(/*[in]*/IOleContainer *pOleContainer,BSTR *pstr =0);
	
	void ClearListViews()
	{
		if( m_wndBrowseTab.GetNativeBrowser().IsWindow() )
			m_wndBrowseTab.GetNativeBrowser().ClearListView();

		if(m_wndBrowseTab.GetAmbientBrowser().IsWindow() )
			m_wndBrowseTab.GetAmbientBrowser().ClearListView();

		if(m_wndBrowseTab.GetExtendedBrowser().IsWindow() )
			m_wndBrowseTab.GetExtendedBrowser().ClearListView();
	}

public:
	HWND Create(		HWND hWndParent, 
						RECT& rcPos, 
						LPCTSTR szWindowName = _T("Property Browser"),
						DWORD dwStyle = WS_POPUP|WS_VISIBLE|WS_TABSTOP|WS_BORDER|WS_SYSMENU|WS_DLGFRAME,
						DWORD dwExStyle = WS_EX_WINDOWEDGE|WS_EX_TOOLWINDOW,
						UINT nID = 0,
						LPVOID lpCreateParam = NULL
				)
	{
		dwStyle		= GetWndStyle(dwStyle);
		dwExStyle	= GetWndExStyle(dwExStyle);

		return CWindowImpl<CBrowseTabContainer>::Create(hWndParent,rcPos,szWindowName,dwStyle,dwExStyle,nID);
	}

	
public:
	typedef CContainedWindowT<CComboBox, CWinTraitsOR<CBS_DROPDOWNLIST> > ControlCombo;

	void			EnableAmbientTab(BOOL bEnable);
	CBrowseTab&		GetBrowseTab()	{ return m_wndBrowseTab;	}
	ControlCombo&	GetControlCombo(){ return m_wndControlCombo; }
	
private:
	CBrowseTab				m_wndBrowseTab;
	ControlCombo			m_wndControlCombo;
	CComPtr<IOleContainer>	m_spOleContainer;
};

//---------------------------------------------------------------------------------------------------------------------------
#endif
