//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//Copyright 1999 Dharma Shukla.

//Keep in mind that I wrote this code just for fun :-) 
//Use it at your own risk! 

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#pragma once
#ifndef __FORM_H_
#define __FORM_H_

#include "resource.h" 
#include <atlctl.h>
#include "VBLite.H"
#include "Base_Include\AxHostWindow2.H"
#include "base_include/comobj.H"

#ifdef __DOMEnabled_
	#include "Base_Include\xmlpropbag.H"
#endif

#include <list>
using namespace std;


class CAxWindowHandle;

//------------------------------------------------------------------------------------------------------------------
// CForm
//
//
//
class CContainerFrame;
class CScripterWindow;

class ATL_NO_VTABLE CForm : 
	public CComObjectRootEx<CComSingleThreadModel>,
	
	public IDispatchImpl<IForm, &IID_IForm, &LIBID_VBLiteLib>,
	public ISupportErrorInfo,
	public CComCompositeControl<CForm>,
	
	public IPersistStreamInitImpl<CForm>,
	public IPersistPropertyBagImpl<CForm>,
	public IPersistStorageImpl<CForm>,
	
	public IOleControlImpl<CForm>,
	public IOleObjectImpl<CForm>,
	public IOleInPlaceActiveObjectImpl<CForm>,
	public IOleInPlaceObjectWindowlessImpl<CForm>,
	public IViewObjectExImpl<CForm>,
	
	public IConnectionPointContainerImpl<CForm>,
	public IQuickActivateImpl<CForm>,
	public IDataObjectImpl<CForm>,

	public IProvideClassInfo2Impl<&CLSID_Form, &DIID__IFormEvents, &LIBID_VBLiteLib>,
	public IPropertyNotifySinkCP<CForm>,
	
	public ISpecifyPropertyPagesImpl<CForm>,

	public IOleInPlaceFrame,
	public IOleContainer,

	public CComCoClass<CForm, &CLSID_Form>,
	public DataHolder<CContainerFrame>
{
public:
	CForm():	m_bControlBox(VARIANT_FALSE),
				m_bSelected(FALSE),
				m_hBmpGrid(0),
				m_hBrGrid(0),
				m_hBrRunMode(0),
				m_pScripterObj(0),
				m_nMaxControls(0),
				m_bDeleted(false)
	{
		m_bWindowOnly = TRUE;
		CalcExtent(m_sizeExtent);

		m_hBmpGrid = ::LoadBitmap(_Module.GetResourceInstance(),MAKEINTRESOURCE(IDB_GRID));
		m_hBrGrid = ::CreatePatternBrush(m_hBmpGrid);
		
		m_hCursor[0] = ::LoadCursor(0,MAKEINTRESOURCE(IDC_CROSS) );
		m_hCursor[1] = ::LoadCursor(0,MAKEINTRESOURCE(IDC_ARROW) ) ;

		m_hBrRunMode = (HBRUSH)::GetStockObject(LTGRAY_BRUSH);
	}
	virtual ~CForm()
	{
		DestroyAcceleratorTable(m_FrameInfo.haccel);
		if(m_hBmpGrid)
		{
			::DeleteObject(m_hBmpGrid);m_hBmpGrid = 0;
		}
		
		if(m_hBrGrid)
		{
			::DeleteObject(m_hBrGrid);m_hBrGrid = 0;
		}
		
		ClearTheListOfDeletedSites();

		Close();//deletes all the sites and the embeddings
	}
	

DECLARE_REGISTRY_RESOURCEID(IDR_FORM)

//DECLARE_NO_REGISTRY()
DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CForm)
	COM_INTERFACE_ENTRY(IForm)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IViewObjectEx)
	COM_INTERFACE_ENTRY(IViewObject2)
	COM_INTERFACE_ENTRY(IViewObject)
	
	COM_INTERFACE_ENTRY(IOleInPlaceFrame)
	COM_INTERFACE_ENTRY(IOleInPlaceUIWindow)
	COM_INTERFACE_ENTRY2(IOleWindow,IOleInPlaceFrame)
	COM_INTERFACE_ENTRY(IOleContainer)
	
	COM_INTERFACE_ENTRY(IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceObject)
	//COM_INTERFACE_ENTRY2(IOleWindow, IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceActiveObject)
	COM_INTERFACE_ENTRY(IOleControl)
	COM_INTERFACE_ENTRY(IOleObject)
	COM_INTERFACE_ENTRY(IPersistStreamInit)
	COM_INTERFACE_ENTRY(IPersistPropertyBag)
	COM_INTERFACE_ENTRY2(IPersist, IPersistStreamInit)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(IConnectionPointContainer)
	COM_INTERFACE_ENTRY(ISpecifyPropertyPages)
	COM_INTERFACE_ENTRY(IQuickActivate)
	COM_INTERFACE_ENTRY(IPersistStorage)
	COM_INTERFACE_ENTRY(IDataObject)
	COM_INTERFACE_ENTRY(IProvideClassInfo)
	COM_INTERFACE_ENTRY(IProvideClassInfo2)
END_COM_MAP()

BEGIN_PROP_MAP(CForm)
	PROP_DATA_ENTRY("_cx", m_sizeExtent.cx, VT_UI4)
	PROP_DATA_ENTRY("_cy", m_sizeExtent.cy, VT_UI4)
	PROP_ENTRY("ControlBox", 1, CLSID_GeneralPage)
	PROP_PAGE(CLSID_GeneralPage)
END_PROP_MAP()

BEGIN_CONNECTION_POINT_MAP(CForm)
	CONNECTION_POINT_ENTRY(IID_IPropertyNotifySink)
END_CONNECTION_POINT_MAP()

BEGIN_MSG_MAP(CForm)
	MESSAGE_HANDLER(WM_CTLCOLORDLG, OnDialogColor)
		
	MESSAGE_HANDLER(WM_INITDIALOG,OnCreate)
	MESSAGE_HANDLER(WM_DESTROY,OnDestroy)
	MESSAGE_HANDLER(WM_LBUTTONDOWN,OnLButtonDown)
	MESSAGE_HANDLER(WM_LBUTTONDBLCLK,OnShowScriptWindow)

	MESSAGE_HANDLER(WM_SETFOCUS, OnSetFocus)
	MESSAGE_HANDLER(WM_MOUSEACTIVATE, OnSetFocus)
	MESSAGE_HANDLER(WM_KILLFOCUS, OnKillFocus)
	MESSAGE_HANDLER(WM_SETCURSOR, OnSetCursor)		
	
	CHAIN_MSG_MAP(CComCompositeControl<CForm>)
END_MSG_MAP()

public://handlers
	LRESULT OnCreate(UINT , WPARAM , LPARAM , BOOL& );
	LRESULT OnLButtonDown(UINT , WPARAM , LPARAM , BOOL& );
	LRESULT OnShowScriptWindow(UINT , WPARAM , LPARAM , BOOL& );
	LRESULT OnDialogColor(UINT, WPARAM , LPARAM, BOOL&);
	LRESULT OnSetFocus(UINT , WPARAM , LPARAM , BOOL& );
	LRESULT OnKillFocus(UINT , WPARAM , LPARAM , BOOL& );
	LRESULT OnDestroy(UINT , WPARAM , LPARAM , BOOL& );
	


BEGIN_SINK_MAP(CForm)
	//Make sure the Event Handlers have __stdcall calling convention
END_SINK_MAP()


	STDMETHOD(OnAmbientPropertyChange)(DISPID dispid);
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);
		

	// IOleWindow
	STDMETHOD(GetWindow)(HWND* phwnd);
	STDMETHOD(ContextSensitiveHelp)(BOOL /*fEnterMode*/);

	// IOleInPlaceUIWindow
	STDMETHOD(GetBorder)(LPRECT /*lprectBorder*/);
	STDMETHOD(RequestBorderSpace)(LPCBORDERWIDTHS /*pborderwidths*/);
	STDMETHOD(SetBorderSpace)(LPCBORDERWIDTHS /*pborderwidths*/);
	STDMETHOD(SetActiveObject)(IOleInPlaceActiveObject* pActiveObject, LPCOLESTR /*pszObjName*/);

	// IOleInPlaceFrameWindow
	STDMETHOD(InsertMenus)(HMENU /*hmenuShared*/, LPOLEMENUGROUPWIDTHS /*lpMenuWidths*/);
	STDMETHOD(SetMenu)(HMENU /*hmenuShared*/, HOLEMENU /*holemenu*/, HWND /*hwndActiveObject*/);
	STDMETHOD(RemoveMenus)(HMENU /*hmenuShared*/);
	STDMETHOD(SetStatusText)(LPCOLESTR /*pszStatusText*/);
	STDMETHOD(EnableModeless)(BOOL /*fEnable*/);
	STDMETHOD(TranslateAccelerator)(LPMSG lpMsg, WORD wID);


	//IOleContainer
	STDMETHOD(ParseDisplayName)(IBindCtx* /*pbc*/, LPOLESTR /*pszDisplayName*/, ULONG* /*pchEaten*/, IMoniker** /*ppmkOut*/);
	STDMETHOD(EnumObjects)(DWORD /*grfFlags*/, IEnumUnknown** ppenum);
	STDMETHOD(LockContainer)(BOOL fLock);
	

	HRESULT FinalConstruct();
	void	FinalRelease();	
	BOOL PreTranslateAccelerator(LPMSG pMsg, HRESULT& hRet)	;

	HRESULT SaveText();
	HRESULT OpenText();
	
#ifdef __DOMEnabled_
	HRESULT SaveXML(IXMLDOMDocument *pDoc);
	HRESULT OpenXML(IXMLDOMDocument *pDoc,IXMLDOMNodeList *pNodeList);
#endif

	HRESULT Close();

public:	
	LRESULT OnSetCursor(UINT, WPARAM , LPARAM , BOOL& )
	{
		if(m_bSelected)
		{
			::SetCursor( m_hCursor[0] );
		}
		else
		{
			::SetCursor( m_hCursor[1] );
		}
		return 0L;
	}
	void CaptureMouse()
	{
		::SetCursor( ::LoadCursor(0,MAKEINTRESOURCE(IDC_CROSS)) );
		SetCapture();
	}
	void ReleaseMouse()
	{
		::SetCursor( ::LoadCursor(0,MAKEINTRESOURCE(IDC_ARROW)) );
		ReleaseCapture();
	}

	HRESULT ReleaseInPlaceActiveObject()
	{
		if(!m_spInPlaceActiveObj){ return S_FALSE; }

		m_spInPlaceActiveObj.Release();
		m_spInPlaceActiveObj = 0;
		return S_OK;
	}
	LPOLEINPLACEFRAMEINFO GetInPlaceFrameInfo() { return &m_FrameInfo; }

public:
	// IViewObjectEx
	DECLARE_VIEW_STATUS(VIEWSTATUS_SOLIDBKGND)


private:
	CAxWindowHandle*	CreateAndEmbedControlOnForm(const POINT &pt, bool bUninit = false,bool bBinary = false);
	HRESULT				InitScriptingForControl(CAxWindowHandle *pSiteNode);
	HWND				GetSimpleFrameControlHWND(const POINT& pt);	

public:	
	HRESULT WriteControlHeaders();
	int		GetControlCount()			{ return m_listSites.size(); }
	HRESULT DeleteFromList(HWND hWnd);
	HRESULT SetScriptNameValuePair(IDispatch *pDisp, CComBSTR& strNewName, CComBSTR strOldName = 0);
	HRESULT DeleteAllEmbeddings();
	HRESULT DoBinarySave();
	HRESULT DoBinaryLoad();
	HRESULT FreeStream();
	HRESULT CreateStream();
	bool	ClearTheListOfDeletedSites();

public:
	
	enum { IDD = IDD_FORM };

public:
	STDMETHOD(get_ControlBox)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_ControlBox)(/*[in]*/ VARIANT_BOOL newVal);
	
	HRESULT PutSelectionInfo(CComBSTR& clsid);
	HRESULT UpdateControlEnumeration(CComBSTR bstr = 0);
	HRESULT UpdateUserModesofHostedControls(VARIANT_BOOL bUserMode);	
	HRESULT StartScriptingEngine();
	HRESULT ShutDownScriptingEngine();
	UINT	GetControlSeqNumber(CLSID *pCLSID);

private:
	CComPtr<IOleInPlaceActiveObject>						 m_spInPlaceActiveObj;
	VARIANT_BOOL											 m_bControlBox;
	BOOL													 m_bSelected;
	std::list<CAxWindowHandle* >							 m_listSites;
	CComBSTR											     m_bstrCLSID;
	
	HBITMAP													 m_hBmpGrid;
	HBRUSH													 m_hBrGrid;
	HBRUSH													 m_hBrRunMode;
	HCURSOR													 m_hCursor[2];	
	CInternalComObjectWithData<CScripterWindow,CForm>		*m_pScripterObj;
	OLEINPLACEFRAMEINFO										m_FrameInfo;		
	
	CComPtr<IStream>										m_spStream;
	UINT													m_nMaxControls;
	std::list<CAxWindowHandle*>								m_listOfDeletedSites;
	bool													m_bDeleted;
};

typedef std::list<CAxWindowHandle*>::iterator	itAxWindowImpl;

//------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------

#endif //__FORM_H_
