//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//Copyright 1999 Dharma Shukla.

//Keep in mind that I wrote this code just for fun :-) 
//Use it at your own risk! 

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#pragma once
#ifndef __EXTENDEDDISPATCH_H_
#define __EXTENDEDDISPATCH_H_

#include "resource.h"       // main symbols
#include "VBLite.H"
#include "Base_Include\comobj.H"

//------------------------------------------------------------------------------------------------------------
// CExtendedDispatch
class CAxWindowHandle;

class ATL_NO_VTABLE CExtendedDispatch : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CExtendedDispatch, &CLSID_ExtendedDispatch>,
	public IDispatchImpl<IExtendedDispatch, &IID_IExtendedDispatch, &LIBID_VBLiteLib>,
	public IPersistPropertyBagImpl<CExtendedDispatch>,
	public IPersistStreamInitImpl<CExtendedDispatch>,
	public DataHolder<CAxWindowHandle>
{
public:

	CExtendedDispatch() :m_nPosX(0),m_nPosY(0),m_nWidth(0),m_nHeight(0),m_bDirty(VARIANT_FALSE)
	{
		
	}

public:

DECLARE_REGISTRY_RESOURCEID(IDR_EXTENDEDDISPATCH)
DECLARE_PROTECT_FINAL_CONSTRUCT()
DECLARE_NOT_AGGREGATABLE(CExtendedDispatch)


BEGIN_COM_MAP(CExtendedDispatch)
	COM_INTERFACE_ENTRY(IPersistPropertyBag)	
	COM_INTERFACE_ENTRY(IPersistStreamInit)	
	COM_INTERFACE_ENTRY2(IDispatch,IExtendedDispatch)
	COM_INTERFACE_ENTRY(IExtendedDispatch)
END_COM_MAP()


BEGIN_PROP_MAP(CExtendedDispatch)
	PROP_ENTRY("Name", 0x8000, CLSID_GeneralPage)
	PROP_ENTRY("PositionX", 0x8001, CLSID_GeneralPage)
	PROP_ENTRY("PositionY", 0x8002, CLSID_GeneralPage)
	PROP_ENTRY("SizeX", 0x8003, CLSID_GeneralPage)
	PROP_ENTRY("SizeY", 0x8004, CLSID_GeneralPage)
END_PROP_MAP()

	
// IExtendedDispatch
public:
	STDMETHOD(SetCLSIDOfControl)(/*[in]*/CComBSTR& bstrclsid);
	
	STDMETHOD(get_Name)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Name)(/*[in]*/ BSTR newVal);
	
	STDMETHOD(put_PositionX)(long x) ;
    STDMETHOD(get_PositionX)(long *px);
    
	STDMETHOD(put_PositionY)(long y);
    STDMETHOD(get_PositionY)(long *py);
	
	STDMETHOD(put_SizeX)(long x);
	STDMETHOD(get_SizeX)(long *px);

    STDMETHOD(put_SizeY)(long y) ;
    STDMETHOD(get_SizeY)(long *py);

public:
	HRESULT SetUpdateRect();
	STDMETHOD(SetDirty)(/*[in]*/ VARIANT_BOOL bDirty);

public:	
	unsigned			m_bRequiresSave:1;

private:
	CComBSTR			m_strName;
	CLSID				m_clsid;

	long				m_nPosX;
	long				m_nPosY;
	long				m_nWidth;
	long				m_nHeight;
	
	VARIANT_BOOL		m_bDirty;
};

#endif //__EXTENDEDDISPATCH_H_
