//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//Copyright 1999 Dharma Shukla.

//Keep in mind that I wrote this code just for fun :-) 
//Use it at your own risk! 

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#pragma once
#ifndef __EVENTDIALOG_H_
#define __EVENTDIALOG_H_

#include "resource.h"       // main symbols
#include <atlhost.h>
#include "EventMgr.H"
#include "commctrl.H"
//----------------------------------------------------------------------------------------------------------------------

// CEventDialog
class CEventDialog : public CAxDialogImpl<CEventDialog>
{
public:
	CEventDialog():m_pEventMap(0),m_hImageList(0)
	{
	
	}

	~CEventDialog()
	{
		if(m_hImageList)
		{
			ImageList_RemoveAll(m_hImageList);
			ImageList_Destroy(m_hImageList);
		}
	}

	enum { IDD = IDD_EVENTDIALOG };

BEGIN_MSG_MAP(CEventDialog)
	MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	COMMAND_ID_HANDLER(IDOK, OnOK)
END_MSG_MAP()

	HRESULT SetEventMap(CEventMap *pEventMap)
	{
		if(!pEventMap) { return E_POINTER; }

		m_pEventMap = pEventMap;
		return S_OK;
	}

	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		if(!m_pEventMap) { return 1; }
		HWND hWndList = GetDlgItem(IDC_EVENTNAMES_LIST);
		HBITMAP hBitmap = 0;
		m_hImageList = ImageList_Create(16, 16, ILC_COLOR, 1, 1);
		hBitmap = LoadBitmap(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDB_EVENT));
		
	
		LVITEM Item;
		Item.mask = LVIF_TEXT|LVIF_IMAGE ;
		Item.iSubItem	= 0;
		Item.state		= 0;
		Item.stateMask	= 0;
		Item.iImage		= ImageList_Add(m_hImageList, hBitmap,(HBITMAP)0);;
		Item.lParam		= 0;
		TCHAR psz[256];
		
		ListView_SetImageList(hWndList, m_hImageList, LVSIL_SMALL );
		DeleteObject(hBitmap);//clear the bmp
		
		
		for(UINT n=0; n < m_pEventMap->GetNumberOfEvents(); n++)
		{
			Item.iItem = n;
			Item.pszText = _T(""); 
			
			USES_CONVERSION;
			lstrcpy(psz, OLE2T(m_pEventMap->GetEventInfo()[n].m_strEventName.m_str));
			
			ListView_InsertItem(hWndList,&Item);
			ListView_SetItemText(hWndList,n,0,psz);
		}
		return 1;  // Let the system set the focus
	}

	LRESULT OnOK(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		EndDialog(wID);
		if(m_hImageList)
		{
			ImageList_RemoveAll(m_hImageList);
			ImageList_Destroy(m_hImageList);
		}
		return 0;
	}

	CEventMap* GetEventMap() { return m_pEventMap; }

private:
	CEventMap	*m_pEventMap;
	HIMAGELIST	m_hImageList;	
};

#endif //__EVENTDIALOG_H_
