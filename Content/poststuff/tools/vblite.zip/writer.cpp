//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//Copyright 1999 Dharma Shukla.

//Keep in mind that I wrote this code just for fun :-) 
//Use it at your own risk! 

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include "stdafx.H"
#include "Writer.H"
//----------------------------------------------------------------------------------------------------------------------------
HRESULT CWriter::WriteFile(LPCTSTR psz)
{
	DWORD dwBytesWritten = 0;
	if(::WriteFile(m_hFile,psz,lstrlen(psz),&dwBytesWritten,NULL))
	{
		return S_OK;
	}

	return E_UNEXPECTED;
}
//-------------------------------------------------------------------------------------------------------------------------------
HRESULT CWriter::WriteControlCount(UINT n)
{
	TCHAR	pszT[1024];
	wsprintf(pszT,_T("%d\n"),n);

	DWORD dwBytesWritten = 0;
	if(!::WriteFile(m_hFile,pszT,lstrlen(pszT),&dwBytesWritten,NULL))
	{
		return E_FAIL;
	}
	
	return S_OK;	
}
//-------------------------------------------------------------------------------------------------------------------------------
HRESULT CWriter::WriteHeader(REFCLSID rclsid)
{
	LPOLESTR pszCLSID  = 0;

	TCHAR	pszT[1024];
	HRESULT hr = S_OK;

	StringFromCLSID(rclsid,&pszCLSID);

	USES_CONVERSION;
	wsprintf(pszT,_T("%s\n"),OLE2T(pszCLSID));

	DWORD dwBytesWritten = 0;
	if(!::WriteFile(m_hFile,pszT,lstrlen(pszT),&dwBytesWritten,NULL)) { hr = E_FAIL; }

	CoTaskMemFree(pszCLSID);

	return hr;
}
//------------------------------------------------------------------------------------------------------------------------
HRESULT CWriter::WriteControlHeader(REFCLSID rclsid,LPCOLESTR pszPropName,bool bIsSubObject)
{
	LPOLESTR pszProgID = 0;
	LPOLESTR pszCLSID  = 0;

	TCHAR	pszT[1024];
	
	HRESULT hr = S_OK;

	StringFromCLSID(rclsid,&pszCLSID);

	USES_CONVERSION;
	if(!bIsSubObject) //top level control
	{
		ProgIDFromCLSID(rclsid,&pszProgID);
		wsprintf(pszT,_T("%s %s %s %s \n"),_T("BeginObject - "),OLE2T(pszProgID),_T("-"),OLE2T(pszCLSID) );
	}
	else // IP property of a control
	{
		wsprintf(pszT,_T("%s %s %s %s\n"),_T("BeginProperty - "),OLE2T(pszPropName),_T("-"), OLE2T(pszCLSID) );
	}
	

	DWORD dwBytesWritten = 0;
	if(!::WriteFile(m_hFile,pszT,lstrlen(pszT),&dwBytesWritten,NULL))
	{
		hr = E_FAIL;
	}

	CoTaskMemFree(pszProgID);
	CoTaskMemFree(pszCLSID);
	
	return hr;
}
//-------------------------------------------------------------------------------------------------------------------------------
HRESULT CWriter::WriteControlFooter(bool bIsSubObject)
{
	TCHAR	pszT[1024];
	HRESULT hr = S_OK;
	
	if(!bIsSubObject) //top level control
	{
		wsprintf(pszT,_T("%s \n"),_T("EndObject"));
	}
	else // IP property of a control
	{
		wsprintf(pszT,_T("%s \n"),_T("EndProperty"));
	}
	
	DWORD dwBytesWritten = 0;
	if(!::WriteFile(m_hFile,pszT,lstrlen(pszT),&dwBytesWritten,NULL))
	{
		hr = E_FAIL;
	}

	return hr;	
}
//-------------------------------------------------------------------------------------------------------------------------------

HRESULT CWriter::CreateFile(LPCTSTR pszFileName,DWORD dwMode)
{
	m_hFile = ::CreateFile(	pszFileName, 
							GENERIC_WRITE|GENERIC_READ,
							FILE_SHARE_READ,
							NULL,
							dwMode,
							FILE_ATTRIBUTE_NORMAL|FILE_FLAG_SEQUENTIAL_SCAN|FILE_FLAG_WRITE_THROUGH,
							NULL
						  );                
	
	if (m_hFile == INVALID_HANDLE_VALUE) 
	{
		m_hFile = 0;
		return E_FAIL;
    }

	::SetFilePointer(m_hFile, 0, 0, FILE_BEGIN); 
	return S_OK;
}

//-------------------------------------------------------------------------------------------------------------------------------
HRESULT CWriter::CloseFile()
{
	if(m_hFile)
	{
		::CloseHandle(m_hFile); 
		m_hFile = 0;
	}

	return S_OK;
}
//-------------------------------------------------------------------------------------------------------------------------------
