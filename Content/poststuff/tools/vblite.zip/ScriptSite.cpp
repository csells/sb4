//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//Copyright 1999 Dharma Shukla.

//Keep in mind that I wrote this code just for fun :-) 
//Use it at your own risk! 

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include "stdafx.H"
#include "ScriptSite.H"
#include "Form.H"

//------------------------------------------------------------------------------------------------------------
CScripterWindow::CScripterWindow()
{
}
//------------------------------------------------------------------------------------------------------------
CScripterWindow::~CScripterWindow()
{
}
//------------------------------------------------------------------------------------------------------------
HRESULT CScripterWindow::FinalConstruct()
{
	return 	CreateScriptEngine();
}
//------------------------------------------------------------------------------------------------------------
void CScripterWindow::FinalRelease()
{
	for(itScriptPair it =m_vecScriptPair.begin();it !=m_vecScriptPair.end();it++)
	{
		if((*it))
		{
			delete (*it);(*it) = 0;
		}
	}
	m_vecScriptPair.clear();
	CloseEngine();
}
//------------------------------------------------------------------------------------------------------------	
HRESULT CScripterWindow::CreateScriptEngine()
{
	const CLSID CLSID_VBScript = {0xb54f3741, 0x5b07, 0x11cf,{ 0xa4, 0xb0, 0x0, 0xaa, 0x0, 0x4a, 0x55, 0xe8}};

	HRESULT hr = CoCreateInstance(CLSID_VBScript,NULL,CLSCTX_INPROC_SERVER,IID_IActiveScript, (void **)&m_spScript);
	if(FAILED(hr)) return hr;

	hr = m_spScript->QueryInterface(&m_spScriptParse);
	if(FAILED(hr)) { m_spScript.Release(); return hr; }
	
	hr = m_spScript->SetScriptSite((IActiveScriptSite*)this); 
	if(FAILED(hr)) { m_spScript.Release(); return hr; }

	hr = m_spScriptParse->InitNew();
	if(FAILED(hr)) { m_spScript.Release(); return hr; }
		
	return hr;
}
//---------------------------------------------------------------------------------------------------------------
HRESULT CScripterWindow::UpdateItem(IDispatch* pDisp,CComBSTR& strNewItem,CComBSTR strOldItem, DWORD dwFlags)
{
	if(!pDisp){ return E_POINTER; }
	
	bool bFound = false;
	//loop through the vector and replace the old name with the new name
	for(itScriptPair it =m_vecScriptPair.begin();it !=m_vecScriptPair.end();it++)
	{
		if((*it) && _wcsicmp((*it)->m_strName, strOldItem) == 0)
		{
			(*it)->m_strName.Empty();
			(*it)->m_strName = strNewItem;
			bFound = true;
			break;
		}
	}
	if(!bFound)
	{
		ScriptPair *pSP = new ScriptPair();
		pSP->m_strName = strNewItem;
		pSP->m_spDispatch = pDisp;
		m_vecScriptPair.push_back(pSP);
	}
	
	return m_spScript->AddNamedItem(strNewItem, dwFlags);;
}
//------------------------------------------------------------------------------------------------------------
// IActiveScriptSite
HRESULT CScripterWindow::IActiveScriptSite_GetItemInfo(LPCOLESTR pstrName,DWORD dwReturnMask,IUnknown **ppUnkItem,ITypeInfo **ppTI)
{
	if (dwReturnMask & SCRIPTINFO_ITYPEINFO)
	{
		if (!ppTI){ return E_INVALIDARG; }
		*ppTI = NULL;
	}

	if (dwReturnMask & SCRIPTINFO_IUNKNOWN)
	{
		if (!ppUnkItem){ return E_INVALIDARG; }
		*ppUnkItem = NULL;
	}
	
	for(itScriptPair it =m_vecScriptPair.begin();it !=m_vecScriptPair.end();it++)
	{
		if((*it) && _wcsicmp((*it)->m_strName, pstrName) == 0)
		{
			if (dwReturnMask & SCRIPTINFO_ITYPEINFO)
			{
				//(*it).m_spDispatch->GetTypeInfo(0, NULL, ppTI);
				//(*ppTI)->AddRef();    
				return S_OK;
			}
			if (dwReturnMask & SCRIPTINFO_IUNKNOWN)
			{
				*ppUnkItem = (*it)->m_spDispatch.p;
				(*ppUnkItem)->AddRef();    
				return S_OK;
			}
		}
	}

	return E_INVALIDARG;
}
//------------------------------------------------------------------------------------------------------------        
HRESULT CScripterWindow::IActiveScriptSite_OnStateChange(SCRIPTSTATE ssScriptState)
{
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------        
HRESULT CScripterWindow::IActiveScriptSite_OnScriptError(IActiveScriptError *pscripterror)
{
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------
LRESULT CScripterWindow::OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	return 0L;
}
//------------------------------------------------------------------------------------------------------------
HRESULT CScripterWindow::ExecuteScript()
{
	EXCEPINFO    ei;
	TCHAR psz[256];
	HWND hWndEdit = GetDlgItem(IDC_EDIT_SCRIPT);
	::GetWindowText(hWndEdit,psz,256);
	CComBSTR str(psz);
	
	HRESULT hr = E_UNEXPECTED;
	if(m_spScriptParse)
	{
		hr = m_spScriptParse->ParseScriptText(str.m_str, NULL, NULL, NULL, 0, 0, 0L, NULL, &ei);
	}
	
	if(SUCCEEDED(hr) && m_spScript)
	{
		hr = m_spScript->SetScriptState(SCRIPTSTATE_CONNECTED);
	}
	return hr;
}
//------------------------------------------------------------------------------------------------------------
LRESULT CScripterWindow::OnExecuteScript(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	ExecuteScript();
	return 0L;
}
//------------------------------------------------------------------------------------------------------------
