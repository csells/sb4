Readme.txt

//Keep in mind that I wrote this sample code just for fun :-) 
//Use it at your own risk! 

//-----------------

1. I have added the XML based text persistence using Don Box's XML based propertybag
implementation. Thanks, Don!

Assuming you want the XML based persistence (and you have the msXml.H et al)

Add the macro 

__DOMEnabled_ 

to enable the text persistence using
XML based propertybag instead of vanilla text persistence(which works w/o the macro). 

2. SimpleFrameSite support is pretty basic

3. Active Scripting support is also pretty basic. 


//-----------------
History of updates:

Oct 99:

I modified the VBLite container to implement text persistence on an 
XML file using Don Box's cool XML based PropertyBag implementation; in 
addition to the vanilla text persistence that it already had.  Thanks, Don!

Nov 99:

a) Replaced the OleUIInsertObject() dialog with a home cooked one. 
b) CAxHostWindow2T<> now implements 
IOleInPlaceSiteWindowless::GetDC() 
and IOleControlSite::TransformCoords() 

