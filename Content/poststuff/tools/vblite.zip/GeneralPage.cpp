//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//Copyright 1999 Dharma Shukla.

//Keep in mind that I wrote this code just for fun :-) 
//Use it at your own risk! 

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

// GeneralPage.cpp : Implementation of CGeneralPage
#include "stdafx.h"
#include "VBLite.h"
#include "GeneralPage.h"
#include "ExtendedDispatch.H"

/////////////////////////////////////////////////////////////////////////////
// CGeneralPage

//------------------------------------------------------------------------------------------------------------------
LRESULT CGeneralPage::InitWnd()
{
	m_WndName.Attach(GetDlgItem(IDC_EDIT_NAME));
	m_WndPosX.Attach(GetDlgItem(IDC_EDIT_POSX));
	m_WndPosY.Attach(GetDlgItem(IDC_EDIT_POSY));
	m_WndSizeX.Attach(GetDlgItem(IDC_EDIT_SIZEX));
	m_WndSizeY.Attach(GetDlgItem(IDC_EDIT_SIZEY));
	return 0L;
}

//------------------------------------------------------------------------------------------------------------------
LRESULT CGeneralPage::OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	InitWnd();
	
	for (UINT i = 0; i < m_nObjects; i++)
	{
		CComPtr<IExtendedDispatch> spExtendedDisp;
		if(SUCCEEDED(GetExtendedDispatch(m_ppUnk[i], &spExtendedDisp)))
		{
			TCHAR psz[256];
			CComBSTR strName;
			spExtendedDisp->get_Name(&strName);
			
			USES_CONVERSION;
			m_WndName.SetWindowText(OLE2T(strName));
			
			long nX = 0;
			spExtendedDisp->get_PositionX(&nX);
			
			wsprintf(psz,_T("%d"),nX);
			m_WndPosX.SetWindowText(psz);
			
			long nY = 0;
			spExtendedDisp->get_PositionY(&nY);
			wsprintf(psz,_T("%d"),nY);
			m_WndPosY.SetWindowText(psz);

			long nSizeX = 0;
			spExtendedDisp->get_SizeX(&nSizeX);
			wsprintf(psz,_T("%d"),nSizeX);
			m_WndSizeX.SetWindowText(psz);


			long nSizeY = 0;
			spExtendedDisp->get_SizeY(&nSizeY);
			wsprintf(psz,_T("%d"),nSizeY);
			m_WndSizeY.SetWindowText(psz);
		}
	}

	CenterWindow();
	return 1L;
}

//------------------------------------------------------------------------------------------------------------------
LRESULT CGeneralPage::OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	if(m_WndName.m_hWnd)
	{
		m_WndName.Detach();
	}
	if(m_WndPosX.m_hWnd)
	{
		m_WndPosX.Detach();
	}
	if(m_WndPosY.m_hWnd)
	{
		m_WndPosY.Detach();
	}
	if(m_WndSizeX.m_hWnd)
	{
		m_WndSizeX.Detach();
	}
	if(m_WndSizeY.m_hWnd)
	{
		m_WndSizeY.Detach();
	}

	return 0L;
}

//------------------------------------------------------------------------------------------------------------------
STDMETHODIMP CGeneralPage::Apply(void)
{
	if(m_bDirty == FALSE)
	{ 
		return S_OK; 
	}

	for (UINT i = 0; i < m_nObjects; i++)
	{
		CComPtr<IExtendedDispatch> spExtendedDisp;
		if(SUCCEEDED(GetExtendedDispatch(m_ppUnk[i], &spExtendedDisp)))
		{
			TCHAR psz[256];
			CComBSTR strName;
			m_WndName.GetWindowText(&strName);
			spExtendedDisp->put_Name(strName.m_str);
			
			RECT rc;
			m_WndPosX.GetWindowText(psz,256);
			
			//spExtendedDisp->SetDirty(VARIANT_FALSE);
			
			rc.left = _ttoi(psz);
			spExtendedDisp->put_PositionX(rc.left);
			
			m_WndPosY.GetWindowText(psz,256);
			rc.top = _ttoi(psz);
			spExtendedDisp->put_PositionY(rc.top);

			m_WndSizeX.GetWindowText(psz,256);
			rc.right  = rc.left +  _ttoi(psz);
			spExtendedDisp->put_SizeX(rc.right - rc.left);

			m_WndSizeY.GetWindowText(psz,256);
			rc.bottom  = rc.top +  _ttoi(psz);
			spExtendedDisp->put_SizeY(rc.bottom - rc.top);
			
			spExtendedDisp->SetDirty(VARIANT_TRUE);
		}
	}

	m_bDirty = FALSE;
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------------
HRESULT CGeneralPage::GetExtendedDispatch(IUnknown* pUnk, IExtendedDispatch **ppExtDisp)
{
	if(!pUnk || !ppExtDisp){ return E_POINTER; }
	
	CComPtr<IOleObject> spObj;
	HRESULT hr = pUnk->QueryInterface(&spObj);
	if(FAILED(hr)) return hr;
	
	CComPtr<IOleClientSite> spClientSite;
	hr = spObj->GetClientSite(&spClientSite);
	if(FAILED(hr)) return hr;

	CComPtr<IOleControlSite> spControlSite;
	hr = spClientSite->QueryInterface(&spControlSite);
	if(FAILED(hr)) return hr;

	CComPtr<IDispatch> spDisp;
	hr = spControlSite->GetExtendedControl(&spDisp);
	if(FAILED(hr)) return hr;

	return spDisp->QueryInterface(ppExtDisp);
}
//-------------------------------------------------------------------------------------------------------------
HRESULT CGeneralPage::GetInPlaceSite(IUnknown* pUnk, IOleInPlaceSite **ppInPlaceSite)
{
	if(!pUnk || !ppInPlaceSite){ return E_POINTER; }
	
	CComPtr<IOleObject> spObj;
	HRESULT hr = pUnk->QueryInterface(&spObj);
	if(FAILED(hr)) return hr;
	
	CComPtr<IOleClientSite> spClientSite;
	hr = spObj->GetClientSite(&spClientSite);
	if(FAILED(hr)) return hr;
	
	return spClientSite->QueryInterface(ppInPlaceSite);
}
//-------------------------------------------------------------------------------------------------------------
LRESULT CGeneralPage::OnEditChange(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	SetDirty(TRUE);
	return 0L;
}
//-------------------------------------------------------------------------------------------------------------
