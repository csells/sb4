//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//Copyright 1999 Dharma Shukla.

//Keep in mind that I wrote this code just for fun :-) 
//Use it at your own risk! 

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include "stdafx.H"
#include "browsetab.H"

//-----------------------------------------------------------------------------------------------------------------
CBrowseTab::CBrowseTab(CBrowseTabContainer *pContainer) :	m_pContainer(pContainer),
															m_hTabFont(0)
{
	m_hTabFont	= ::CreateFont(
								15, 0, 0, 0, FW_NORMAL,
								FALSE,FALSE,FALSE,ANSI_CHARSET,
								OUT_DEFAULT_PRECIS,
								CLIP_DEFAULT_PRECIS,
								DEFAULT_QUALITY,DEFAULT_PITCH,
								_T("MS Sans Serif")
							  );
}
//-----------------------------------------------------------------------------------------------------------------
LRESULT CBrowseTab::OnCreate(UINT, WPARAM , LPARAM, BOOL& bHandled)
{
	DefWindowProc();
	
	InitOutputTab();
	
	m_wndPBNative.Create(m_hWnd,CWindow::rcDefault);
	m_wndPBAmbient.Create(m_hWnd,CWindow::rcDefault);
	m_wndPBExtended.Create(m_hWnd,CWindow::rcDefault);

	m_wndPBNative.ShowWindow(SW_SHOW);
	m_wndPBAmbient.ShowWindow(SW_HIDE);
	m_wndPBExtended.ShowWindow(SW_HIDE);
	
	SetFont(m_hTabFont);

	bHandled = TRUE;
	return 0L;
}
//-----------------------------------------------------------------------------------------------------------------
LRESULT CBrowseTab::OnSize(UINT , WPARAM , LPARAM , BOOL& bHandled)
{
	DefWindowProc();

	RECT rc;
	GetClientRect(&rc);
	rc.left = rc.left + 3;
	rc.top = rc.top + 28;
	rc.right = rc.right - 3;
	rc.bottom = rc.bottom - 5;
	int nWidth = rc.right - rc.left;
	
	m_wndPBNative.SetWindowPos(NULL,rc.left,rc.top ,nWidth,rc.bottom - rc.top, SWP_NOZORDER | SWP_NOACTIVATE);
	m_wndPBAmbient.SetWindowPos(NULL,rc.left,rc.top ,nWidth,rc.bottom - rc.top, SWP_NOZORDER | SWP_NOACTIVATE);
	m_wndPBExtended.SetWindowPos(NULL,rc.left,rc.top ,nWidth,rc.bottom - rc.top, SWP_NOZORDER | SWP_NOACTIVATE);
	
	bHandled = TRUE;
	return 0L;
}
//-----------------------------------------------------------------------------------------------------------------
void CBrowseTab::InitOutputTab(bool bShow)
{
	TC_ITEM tci;

	tci.mask		= TCIF_TEXT |TCIF_IMAGE ; 
	tci.iImage		= -1;
	tci.lParam		= 0;
	int n = 0;
	
	tci.pszText		= _T("Native");
	tci.cchTextMax	= lstrlen(tci.pszText) + 1;
	InsertItem(n++, &tci);
	
	if(bShow)
	{
		tci.pszText		= _T("Ambient");
		tci.cchTextMax	= lstrlen(tci.pszText) + 1;
		InsertItem(n++, &tci);
	}
	
	
	tci.pszText		= _T("Extended");
	tci.cchTextMax	= lstrlen(tci.pszText) + 1;
	InsertItem(n++, &tci);
}
//------------------------------------------------------------------------------------------
LRESULT CBrowseTabContainer::OnCreate(UINT , WPARAM , LPARAM , BOOL& bHandled)
{
	DefWindowProc();

	RECT rc;
	GetClientRect(&rc);
	m_wndBrowseTab.Create(m_hWnd,rc);
	
	m_wndControlCombo.Create(m_hWnd,&CWindow::rcDefault);
	m_wndControlCombo.ShowWindow(SW_SHOW);
	m_wndControlCombo.SetFont(m_wndBrowseTab.GetFont());	

	//change the styles
	ModifyStyle(GetStyle(), WS_OVERLAPPEDWINDOW|WS_VISIBLE| 
							 WS_CLIPSIBLINGS |WS_CLIPCHILDREN |
							 WS_OVERLAPPED);
			
		
	ModifyStyleEx(GetExStyle(),WS_EX_LEFT|WS_EX_LTRREADING|
								WS_EX_RIGHTSCROLLBAR|
								WS_EX_TOOLWINDOW|WS_EX_WINDOWEDGE);
		
	::SetClassLong(m_hWnd,GCL_STYLE,CS_NOCLOSE);


	bHandled = TRUE;
	return 0L;
}
//------------------------------------------------------------------------------------------
LRESULT CBrowseTabContainer::OnSize(UINT , WPARAM , LPARAM , BOOL& bHandled)
{
	RECT rc;
	GetClientRect(&rc);
	rc.left = rc.left + 5;
	rc.right = rc.right -5 ;
	rc.bottom = rc.bottom - 5;
	int nWidth = rc.right - rc.left;

	//first the control combo
	m_wndControlCombo.SetWindowPos(NULL,rc.left,rc.top +5 ,nWidth,rc.top + 100, SWP_NOZORDER | SWP_NOACTIVATE);
	
	m_wndBrowseTab.SetWindowPos(NULL,rc.left,rc.top+30 ,nWidth,rc.bottom - rc.top - 30, SWP_NOZORDER | SWP_NOACTIVATE);
	
	bHandled = TRUE;
	return 0L;
}
//------------------------------------------------------------------------------------------
LRESULT CBrowseTabContainer::OnTabChanged(int idCtrl, LPNMHDR pnmh, BOOL& bHandled)
{
	UINT nTab = m_wndBrowseTab.GetCurSel() ;
	if(nTab == 0)
	{
		m_wndBrowseTab.GetNativeBrowser().ShowWindow(SW_SHOW);
		m_wndBrowseTab.GetAmbientBrowser().ShowWindow(SW_HIDE);
		m_wndBrowseTab.GetExtendedBrowser().ShowWindow(SW_HIDE);
	}
	else if(nTab == 1)
	{
		m_wndBrowseTab.GetNativeBrowser().ShowWindow(SW_HIDE);
		m_wndBrowseTab.GetAmbientBrowser().ShowWindow(SW_SHOW);
		m_wndBrowseTab.GetExtendedBrowser().ShowWindow(SW_HIDE);
	}
	else if(nTab == 2)
	{
		m_wndBrowseTab.GetNativeBrowser().ShowWindow(SW_HIDE);
		m_wndBrowseTab.GetAmbientBrowser().ShowWindow(SW_HIDE);
		m_wndBrowseTab.GetExtendedBrowser().ShowWindow(SW_SHOW);
	}
	
	bHandled = TRUE;		
	return 0L;
}
//-----------------------------------------------------------------------------------------------------------------
//This exercise is to verify that the control enumeration works as expected(little testing routine) :-)
//
//
HRESULT CBrowseTabContainer::EnumerateControlsAndFillCombo(IOleContainer *pOleContainer, BSTR *pstr)
{
	if ( !m_wndControlCombo.IsWindow() ) { return S_FALSE; }
    if(!pOleContainer){ return E_POINTER; }

	if(m_spOleContainer)
	{
		m_spOleContainer.Release();
	}
	m_spOleContainer = pOleContainer;

	
	CComPtr<IEnumUnknown>	spEnumUnk;
	HRESULT hr = pOleContainer->EnumObjects(OLECONTF_EMBEDDINGS |OLECONTF_OTHERS,&spEnumUnk);
	if(FAILED(hr)) {  return hr; }

	m_wndControlCombo.ResetContent();
	CComPtr<IUnknown>	spUnk;
			
	while (spEnumUnk->Next(1,&spUnk,NULL) == S_OK) 
	{
		CComPtr<IOleObject> spOleObject;
		hr = spUnk->QueryInterface(&spOleObject);
		
		if(SUCCEEDED(hr)) 
		{
			//ActiveX control
			CComPtr<IOleClientSite> spClientSite;

			if(SUCCEEDED(spOleObject->GetClientSite(&spClientSite)))
			{
				CComQIPtr<IOleInPlaceSite> spInPlaceSite(spClientSite);
				if(spInPlaceSite)
				{
					CComPtr<IDispatch> spExtendedDispatch;	
					CComQIPtr<IOleControlSite,&IID_IOleControlSite> spControlSite(spClientSite);

					if(spControlSite && SUCCEEDED(spControlSite->GetExtendedControl(&spExtendedDispatch)))
					{
						CComVariant var(VT_BSTR);
						CComDispatchDriver disp(spExtendedDispatch.p);
						hr = disp.GetPropertyByName(L"Name",&var);
						
						USES_CONVERSION;
						
						m_wndControlCombo.AddString(OLE2T(var.bstrVal));
					}
				}
			}
		}
		spUnk.Release();
	}

	if(pstr)
	{
		USES_CONVERSION;
		if( m_wndControlCombo.SelectString(0,OLE2T(*pstr)) == CB_ERR )
		{
			return S_FALSE;//special hack for Form object
		}
	}
	return hr;
}
//-----------------------------------------------------------------------------------------------------------------
LRESULT CBrowseTabContainer::OnSelEndOK(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	if(!m_spOleContainer) { return 0L; }
	
	
	CComPtr<IEnumUnknown>	spEnumUnk;
	HRESULT hr = m_spOleContainer->EnumObjects(OLECONTF_EMBEDDINGS |OLECONTF_OTHERS,&spEnumUnk);
	if(FAILED(hr)) {  return hr; }
	
	bool bFound = false;
	CComPtr<IUnknown>	spUnk;
	CComBSTR strSelected;
	m_wndControlCombo.GetLBTextBSTR(m_wndControlCombo.GetCurSel(), strSelected.m_str);
		
	while (spEnumUnk->Next(1,&spUnk,NULL) == S_OK) 
	{
		CComPtr<IOleObject> spOleObject;
		hr = spUnk->QueryInterface(&spOleObject);
		
		if(SUCCEEDED(hr)) 
		{
			//ActiveX control
			CComPtr<IOleClientSite> spClientSite;

			if(SUCCEEDED(spOleObject->GetClientSite(&spClientSite)))
			{
				CComQIPtr<IOleInPlaceSite> spInPlaceSite(spClientSite);
				if(spInPlaceSite)
				{
					CComPtr<IDispatch> spExtendedDispatch;	
					CComQIPtr<IOleControlSite,&IID_IOleControlSite> spControlSite(spClientSite);

					if(spControlSite && SUCCEEDED(spControlSite->GetExtendedControl(&spExtendedDispatch)))
					{
						CComVariant var(VT_BSTR);
						CComDispatchDriver disp(spExtendedDispatch.p);
						hr = disp.GetPropertyByName(L"Name",&var);
						
						if (strSelected == var.bstrVal)
						{
							bFound = true;
							HWND hWndFocus = 0;
							if(SUCCEEDED( spInPlaceSite->GetWindow(&hWndFocus) ) )
							{
								::SetFocus(hWndFocus);
							}
							break;
						}
					}
				}
			}
		}
		spUnk.Release();
	}

	if(!bFound)// this is the Form - special hack
	{
		CComPtr<IOleClientSite> spClientSiteForForm;
		CComQIPtr<IOleObject> spFormObj(m_spOleContainer);
		if(spFormObj)
		{
			if(FAILED ( spFormObj->GetClientSite(&spClientSiteForForm) )){return 0L;}
			
			CComQIPtr<IOleInPlaceSite> spInPlaceSite(spClientSiteForForm);
			
			if(spInPlaceSite)
			{
				HWND hWndFocus = 0;
				if(SUCCEEDED( spInPlaceSite->GetWindow(&hWndFocus) ) )
				{
					::SetFocus(hWndFocus);
				}
			}
		}

	}

	return 0L;
}
//-----------------------------------------------------------------------------------------------------------------
void CBrowseTabContainer::EnableAmbientTab(BOOL bEnable)
{
	m_wndBrowseTab.GetAmbientBrowser().EnableWindow(bEnable);
}
//-----------------------------------------------------------------------------------------------------------------