//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//Copyright 1999 Dharma Shukla.

//Keep in mind that I wrote this code just for fun :-) 
//Use it at your own risk! 

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

// EventDialog.cpp : Implementation of CEventDialog
#include "stdafx.h"
#include "EventDialog.h"

/////////////////////////////////////////////////////////////////////////////
// CEventDialog
