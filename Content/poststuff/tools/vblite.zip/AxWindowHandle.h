//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//Copyright 1999 Dharma Shukla.

//Keep in mind that I wrote this code just for fun :-) 
//So use it at your own risk! 

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#pragma once
#ifndef __AXWINDOWHANDLE_H_
#define __AXWINDOWHANDLE_H_

#include "Base_Include\comobj.H"
#include "Base_Include\SiteBase.H"
#include "EventMgr.H"
#include "Base_Include\AxHostWindow2.H"
#include "ExtendedDispatch.H"
#include "ContainerFrame.H"

#define ID_MIN_VERB 1000
#define ID_MAX_VERB 2000           
#define ID_CONVERT  10000

//------------------------------------------------------------------------------------------------------------------
//ALT_MSG_MAP(1) of this class gets all the messages meant for the Child ActiveX control(if Windowed)
//The regular message map gets all the messages meant for the CAxHostWindow as its nothing but the superclasses AxWin
//

class CContainerFrame;
class CExtendedDispatch;
class CAxWindowHandle;
class CContainerFrame;

//------------------------------------------------------------------------------------------------------------------
class CAxWindowHandle : public CAxWindowImplT<CAxWindowHandle,CAxWindow2>
{
public:
	typedef CAxWindowImplT<CAxWindowHandle,CAxWindow2>						baseClass;
	typedef CComObject<CAxHostWindow2T<CContainerFrame> >					theSiteObj;

	CAxWindowHandle::CAxWindowHandle(CContainerFrame *pFrame) :	m_pFrame(pFrame),
																m_pSiteObject(0), 
																m_wndControl(this,1),
																m_bSimplFrame(false),
																m_bInvisAtRunTime(false),
																m_bSubClassed(false),
																m_pExtendedDispatchObj(0),
																m_pEventMap(0)
	{
	}
	
	~CAxWindowHandle()
	{}

public:	
	BEGIN_MSG_MAP(CAxWindowHandle)
		MESSAGE_HANDLER(WM_CREATE,OnCreate)
		MESSAGE_HANDLER(WM_SIZE,OnSize)
		MESSAGE_HANDLER(WM_SETFOCUS,OnSetFocus)
		MESSAGE_HANDLER(WM_EXITSIZEMOVE,OnSize)
		MESSAGE_HANDLER(WM_NCDESTROY,OnNCDestroy)
		MESSAGE_HANDLER(WM_NCHITTEST,OnNCHitTest)	
		COMMAND_RANGE_HANDLER(ID_MIN_VERB,ID_MAX_VERB,OnVerb)
		MESSAGE_HANDLER(WM_COMMAND,OnCommand)

		//if(m_pSiteObject && m_pSiteObject->m_bWindowless)
		//{
			MESSAGE_HANDLER(WM_NCRBUTTONDOWN, OnContextMenu)
			MESSAGE_HANDLER(WM_NCLBUTTONDOWN, OnLButtonDown)
			MESSAGE_HANDLER(WM_NCLBUTTONDBLCLK, OnLButtonDBlClk)
		//}
		
		CHAIN_MSG_MAP(baseClass)
		
	ALT_MSG_MAP(1)
		MESSAGE_HANDLER(WM_KEYDOWN,OnKeyDown)	
		MESSAGE_HANDLER(WM_CONTEXTMENU, OnContextMenu)
		MESSAGE_HANDLER(WM_LBUTTONDOWN, OnLButtonDown)
		MESSAGE_HANDLER(WM_NCHITTEST,OnNCHitTestCtl)
	END_MSG_MAP()
	
	LRESULT OnCreate(UINT,WPARAM,LPARAM,BOOL& bHandled);
	LRESULT OnVerb(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
	LRESULT OnSetFocus(UINT,WPARAM,LPARAM, BOOL& bHandled);
	LRESULT OnNCHitTest(UINT , WPARAM , LPARAM , BOOL& bHandled);
	LRESULT OnCommand(UINT,WPARAM,LPARAM, BOOL& bHandled);
	LRESULT OnSize(UINT,WPARAM,LPARAM, BOOL& bHandled);
	LRESULT OnNCDestroy(UINT , WPARAM , LPARAM , BOOL& bHandled);
	LRESULT OnLButtonDBlClk(UINT , WPARAM , LPARAM , BOOL& bHandled);
	LRESULT OnKeyDown(UINT , WPARAM , LPARAM , BOOL& bHandled);
	
	//ALT_MSG_MAP(1)
	LRESULT OnLButtonDown(UINT,WPARAM,LPARAM,BOOL& bHandled);
	LRESULT OnContextMenu(UINT,WPARAM,LPARAM,BOOL& bHandled);
	LRESULT OnNCHitTestCtl(UINT , WPARAM , LPARAM , BOOL& bHandled);
	
public:
	HRESULT AxCreateControl2(LPCOLESTR lpszName, HWND hWnd, IStream* pStream, IUnknown** ppUnkContainer, IUnknown** ppUnkControl = 0, REFIID iidSink = IID_NULL, IUnknown* punkSink = 0);
	HRESULT UpdateBrowsers(bool bOnlyExtended=false);	
	
	BOOL SubclassControl();
	
	BOOL UnsubclassControl()
	{
		if(m_wndControl.IsWindow())//windowed control
		{
			m_wndControl.UnsubclassWindow(TRUE);
			m_bSubClassed = false;
			m_wndControl.m_hWnd = 0;
		}
		return TRUE;
	}
	HRESULT InitializeEventMap(LPUNKNOWN pUnk)
	{
		if(!pUnk) { return E_POINTER; }

		HRESULT hr = S_FALSE;
		
		if(!m_pEventMap)
		{
			hr = m_pEventMap->CreateInstanceWithData(&m_pEventMap, pUnk);
			if(SUCCEEDED(hr))
			{
				m_pEventMap->AddRef();
				m_pEventMap->Advise();
				CComPtr<IOleControl> spControl;
				pUnk->QueryInterface(&spControl);
				spControl->FreezeEvents(TRUE);
			}
		}

		return hr;
	}
	HRESULT			InitializeSite();
public:		//Usermode specific
	HRESULT					OnUserModeChanged(VARIANT_BOOL bUserMode);
	HRESULT					GetSiteForTheForm(LPUNKNOWN *ppUnkFormSite);
	VARIANT_BOOL			GetContainerUserMode(void);
	
	
	CInternalComObjectWithData<CExtendedDispatch,CAxWindowHandle>			*m_pExtendedDispatchObj;
	CInternalComObjectWithData<CEventMap,IUnknown>							*m_pEventMap;

public:
	void				SetSimpleFrame(bool b)		{ m_bSimplFrame = b; }
	void				SetInvisAtRunTime(bool b)	{ m_bInvisAtRunTime = b; }
	
	BOOL				ShowEventDialog();
	HWND				GetChildControlHwnd()const	{ return m_wndControl.m_hWnd;}

	CContainerFrame*	GetContainerFrame()const	{ return m_pFrame;}
	bool				IsSimpleFrame()				{ return m_bSimplFrame; }
	bool				IsInvisAtRunTime()			{ return m_bInvisAtRunTime; }

	
public:	
	theSiteObj			*m_pSiteObject;
	
private:
	HRESULT			AmIASiteForTheForm(bool &b);


private:
	CContainedWindow	m_wndControl;
	CContainerFrame		*m_pFrame;
	bool				m_bSimplFrame;
	bool				m_bInvisAtRunTime;
	bool				m_bSubClassed;		    
};

//------------------------------------------------------------------------------------------------------------------

#endif

