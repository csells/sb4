//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//Copyright 1999 Dharma Shukla.

//Keep in mind that I wrote this code just for fun :-) 
//Use it at your own risk! 

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#include "stdafx.h"
#include "VBLite.h"
#include "ExtendedDispatch.h"
#include "Base_Include\AxHostWindow2.H"
#include "AxWindowHandle.H"
#include "containerFrame.H"

// CExtendedDispatch
	
//------------------------------------------------------------------------------------------------------------
STDMETHODIMP CExtendedDispatch::get_Name(BSTR *pVal)
{
	if(!pVal) { return E_POINTER; }

	*pVal = m_strName.Copy();
	return S_OK;
}

//------------------------------------------------------------------------------------------------------------
STDMETHODIMP CExtendedDispatch::put_Name(BSTR newVal)
{
	if(m_pData)
	{
		CAxWindowHandle *pWindowHandle = m_pData;
		CContainerFrame *pFrame = pWindowHandle->GetContainerFrame();
		
		//Update the name for the scripting giving old and new names
		CComPtr<IDispatch> spDispatch;
		if(SUCCEEDED( pWindowHandle->QueryControl(&spDispatch) ))
		{
			if(pFrame && pFrame->m_pFormObj)
			{
				CComBSTR strNew = newVal;
				pFrame->m_pFormObj->SetScriptNameValuePair(spDispatch,strNew,m_strName);
			}
		}

		m_strName = newVal;
		m_bRequiresSave = TRUE;
	
		//update the property browser combo
		if(pFrame && pFrame->m_pFormObj)
		{
			pFrame->m_pFormObj->UpdateControlEnumeration(newVal);
		}
	}
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------
STDMETHODIMP CExtendedDispatch::put_PositionX(long x) 
{
	if(m_nPosX == x){ return S_OK; }
	if(m_nPosX && m_pData && m_pData->IsInvisAtRunTime())
		return S_OK;
	
	m_nPosX = x;
	m_bRequiresSave = TRUE;
	SetUpdateRect();	
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------
STDMETHODIMP CExtendedDispatch::get_PositionX(long *px)
{
	if(!px) { return E_POINTER; }
	
	*px = m_nPosX;
	
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------
STDMETHODIMP CExtendedDispatch::put_PositionY(long y)
{
	if(m_nPosY == y){ return S_OK; }
	if(m_nPosY && m_pData->IsInvisAtRunTime())
		return S_OK;
	
	m_nPosY = y;
	m_bRequiresSave = TRUE;
	SetUpdateRect();
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------
STDMETHODIMP CExtendedDispatch::get_PositionY(long *py)
{
	if(!py) { return E_POINTER; }

	*py = m_nPosY;
	
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------
STDMETHODIMP CExtendedDispatch::put_SizeX(long x)
{
	if(m_nWidth == x){ return S_OK; }
	if(m_nWidth && m_pData->IsInvisAtRunTime())
		return S_OK;
	
	m_nWidth = x;
	m_bRequiresSave = TRUE;
	SetUpdateRect();
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------
STDMETHODIMP CExtendedDispatch::get_SizeX(long *px)
{
	if(!px) { return E_POINTER; }
	
	*px = m_nWidth;
	
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------
STDMETHODIMP CExtendedDispatch::put_SizeY(long y)
{
	if(m_nHeight == y){ return S_OK; }
	if(m_nHeight && m_pData->IsInvisAtRunTime())
		return S_OK;
	
	m_nHeight = y;
	m_bRequiresSave = TRUE;
	SetUpdateRect();
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------
STDMETHODIMP CExtendedDispatch::get_SizeY(long *py)
{
	if(!py) { return E_POINTER; }
	
	*py = m_nHeight;
	
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------
HRESULT CExtendedDispatch::SetUpdateRect()
{
	if(!m_pData){ return E_POINTER; }
	if(m_bDirty == VARIANT_FALSE) { return S_FALSE; }
	
	RECT rc;
	rc.left = m_nPosX;
	rc.top  = m_nPosY;
	rc.right = rc.left + m_nWidth;
	rc.bottom  = rc.top + m_nHeight;

	if(m_pData)
		m_pData->SetWindowPos(HWND_TOP,&rc ,SWP_NOZORDER);	

	return S_OK; 
}
//------------------------------------------------------------------------------------------------------------

STDMETHODIMP CExtendedDispatch::SetDirty(VARIANT_BOOL bDirty)
{
	m_bDirty = bDirty;
	return S_OK;
}
//------------------------------------------------------------------------------------------------------------
STDMETHODIMP CExtendedDispatch::SetCLSIDOfControl(/*[in]*/CComBSTR& bstrclsid)
{
	HRESULT hr = ::CLSIDFromString(bstrclsid,&m_clsid);
	if(FAILED(hr)) return hr;

	LPOLESTR psz = 0;
	::ProgIDFromCLSID(m_clsid, &psz);
	
	wcstok(psz, L".");
	m_strName = wcstok(NULL, L".");
	
	CoTaskMemFree(psz); psz = 0;

	if(m_pData)
	{
		CAxWindowHandle *pWindowHandle = m_pData;
		CContainerFrame *pFrame = pWindowHandle->GetContainerFrame();
		
		//Update the name for the scripting giving old and new names
		CComPtr<IDispatch> spDispatch;
		hr = pWindowHandle->QueryControl(&spDispatch);
		if(FAILED(hr)) return hr;
		
		if(pFrame && pFrame->m_pFormObj)
		{
			UINT n = pFrame->m_pFormObj->GetControlSeqNumber(&m_clsid);
			TCHAR pszNumber[56];
			wsprintf(pszNumber, _T("%d"),n);
			USES_CONVERSION;
			m_strName += T2BSTR(pszNumber);
		}
	}
	
	return hr;
}
//------------------------------------------------------------------------------------------------------------