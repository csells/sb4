Imports System
Imports System.IO
Imports CollectionGenerator

Module Module1

    <STAThread()> _
    Public Sub Main(ByVal args() As String)
        Dim inputFile As String = "..\mixed.xml"
        Dim input As String = (New StreamReader(inputFile)).ReadToEnd()
        Dim gen As CollectionGenerator.CollectionGenerator
        Dim code As String

        Dim gens() As CollectionGenerator.CollectionGenerator = {New VBCollectionGenerator()}

        For Each gen In gens
            Try
                'We ignore any errors, as they get printed to the console together with the source
                code = gen.GenerateCodeFromXml(input)
                Console.WriteLine(code)
            Catch ex As Exception
                Console.WriteLine(ex.ToString())
            End Try
        Next
    End Sub
End Module

