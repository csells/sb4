using System;
using System.IO;
using CollectionGenerator;

class CSTestCli
{
    [STAThread]
    static void Main(string[] args)
    {
        string  inputFile = @"..\..\mixed.xml";
        string  input = (new StreamReader(inputFile)).ReadToEnd();

        CollectionGenerator.CollectionGenerator[] gens =
        {
            new CSharpCollectionGenerator(),
        };

        foreach( CollectionGenerator.CollectionGenerator gen in gens )
        {
            try
            {
                // We ignore any errors, as they get printed to the console together with the source
                string  code = gen.GenerateCodeFromXml(input);
                Console.WriteLine(code);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

        }
    }
}
