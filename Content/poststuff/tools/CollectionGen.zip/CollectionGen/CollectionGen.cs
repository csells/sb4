// CollectionGen.cs: Chris Sells [csells@sellsbrothers.com]
// Inspired by Jon Flanders [jfland@develop.com] and Shawn Van Ness [shawnv@arithex.com]

#region Copyright � 2002 Chris Sells
/* This software is provided 'as-is', without any express or implied warranty.
 * In no event will the authors be held liable for any damages arising from the
 * use of this software.
 * 
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, subject to the following restrictions:
 * 
 * 1. The origin of this software must not be misrepresented; you must not
 *    claim that you wrote the original software. If you use this software in a
 *    product, an acknowledgment in the product documentation is requested, as
 *    shown here:
 * 
 *    Portions copyright � 2002 Chris Sells (http://www.sellsbrothers.com/).
 * 
 * 2. No substantial portion of this source code may be redistributed without
 *    the express written permission of the copyright holders, where
 *    "substantial" is defined as enough code to be recognizably from this code.
 */
#endregion
#region Extensibility
/*
 * CollectionGen composes the name of the template using: lang + templateKind + ".xslt",
 * where lang is either "CS or "VB". It will first look in the file system right next to
 * the assembly and then for a resource embedded into the assembly itself. If you'd like
 * to override {CS|VB}{Vector|HashTable}.xslt, feel free. Likewise, you can replace
 * {CS|VB}Header.xslt, which is generated first, before all of the collections themselves
 * are generated.
 * Also, if you'd like to add your own templates, you can by naming your template
 * {CS|VB}<templateKind> where templateKind is whatever you put into the collection
 * definition input file.
 */
#endregion
#region History
// 8/27/02:
//  -Chris Sells [csells@sellsbrothers.com] split out VS.NET-specific functionality.
// 7/21/02:
//  -Tor-Erik Hagen [tor-erik@web-amp.com] added better error reporting.
// 7/1/02:
//  -Chris Sells [csells@sellsbrothers.com] added self-registration support.
#endregion

using System;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Xsl;
using System.IO;
using System.Reflection;
using System.CodeDom.Compiler;
using System.Text;
using System.Collections;

namespace CollectionGenerator
{
    public class CollectionGenerator
    {
        // NOTE: languagePrefix is case-sensitive to use the built-in template resources
        public CollectionGenerator(string languagePrefix)
        {
            this.languagePrefix = languagePrefix;
        }

        protected static string GetStringFromResource(Assembly assem, string resName)
        {
            using( Stream       stream = assem.GetManifestResourceStream(resName) )
            using( StreamReader reader = new StreamReader(stream) )
            {
                return reader.ReadToEnd();
            }
        }

        protected static string GetStringFromFile(string fileName)
        {
            using( StreamReader reader = new StreamReader(fileName) )
            {
                return reader.ReadToEnd();
            }
        }

        // name examples: "CSHeader.xslt" or "VBHashTable.xslt"
        protected string GetStringFromFileOrResource(string name)
        {
            Assembly    assem = GetType().Assembly;

            try
            {
                // Try pulling from the file 1st
                string  fullName = name;
                if( !System.IO.Path.IsPathRooted(name) )
                {
                    // Pull relative file names from the same directory as the assembly
                    fullName = System.IO.Path.GetDirectoryName(assem.Location) + @"\" + name;
                }

                return GetStringFromFile(fullName);
            }
            catch
            {
            }

            try
            {
                // Try pulling from the resource 2nd
                string  resPrefix = this.GetType().Namespace + ".Templates.";
                return GetStringFromResource(assem, resPrefix + name);
            }
            catch
            {
            }

            // Complain 3rd
            throw new ApplicationException("Template not found: " + name);
        }

        public static string Transform(string template, string input)
        {
            // Generate text from XSLT template
            using( Stream xsltStream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(template)) )
            using( Stream xmlStream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(input)) )
            {
                XslTransform    transform = new XslTransform();
                transform.Load(new XmlTextReader(xsltStream));

                XPathDocument   doc = new XPathDocument(xmlStream);
                StringWriter    writer = new StringWriter();
                transform.Transform(doc, null, writer);

                return writer.ToString().Trim();
            }
        }

        protected ArrayList GetTemplateKinds(string input)
        {
            using( Stream xmlStream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(input)) )
            {
                XPathDocument   doc = new XPathDocument(xmlStream);
                XPathNavigator  nav = doc.CreateNavigator();

                // Select all templateKind nodes (sorted)
                XPathExpression expr; 
                expr = nav.Compile("/typeSafeCollections/typeSafeCollection/templateKind");
                //expr.AddSort(".", XmlSortOrder.Ascending, XmlCaseOrder.None, "", XmlDataType.Text);

                // Build the array list of unique template kinds
                ArrayList           list = new ArrayList();
                XPathNodeIterator   it = nav.Select(expr);
                while( it.MoveNext() )
                {
                    string  templateKind = it.Current.Value;
                    if( !list.Contains(templateKind) ) list.Add(templateKind);
                }

                return list;
            }
        }

        // Added for backwards compability
        public string GenerateCodeFromXml(string input)
        {
            bool   error       = false;
            string errorInfo = "";
            return GenerateCodeFromXml(input, ref error, ref errorInfo);
        }

        public string GenerateCodeFromXml(string input, ref bool error, ref string errorInfo)
        {
            StringBuilder   sb = new StringBuilder();
            string          template = GetStringFromFileOrResource(languagePrefix + "Header.xslt");
            sb.Append(Transform(template, input)).Append(Environment.NewLine);
            int            errorCount = 0;
            string         lastErrorString = "";
			

            errorInfo = "";
            error = false;

            foreach( string kind in GetTemplateKinds(input) )
            {
                string  code = "";

                try
                {
                    template = GetStringFromFileOrResource(languagePrefix + kind + ".xslt");
                    code = Transform(template, input);
                }
                catch( Exception ex )
                {
                    errorCount++;
                    code = "***ERROR*** Can't generate from template kind: " + kind + Environment.NewLine + ex.Message;
                    lastErrorString = "***ERROR*** Can't generate from template kind: " + kind + Environment.NewLine + ex.Message;
                }

                sb.Append(Environment.NewLine).Append(code);
            }

            if (errorCount > 0)
            {
                error = true;
                if (errorCount > 1)
                {
                    errorInfo = "There was multiple errors generating the collection(s), please review the generated code for error info";
                }
                else
                {
                    errorInfo = lastErrorString;
                }
            }
            return sb.ToString();

        }

        protected string    languagePrefix;
    }

    public class CSharpCollectionGenerator : CollectionGenerator
    {
        public CSharpCollectionGenerator() : base("CS") {}
    }

    public class VBCollectionGenerator : CollectionGenerator
    {
        public VBCollectionGenerator() : base("VB") {}
    }
}
