// collgen.cs: Tor-Erik Hagen [tor-erik@web-amp.com]
// Commandline utility for generating collections using CollectionGen

#region Copyright � 2002 Chris Sells
/* This software is provided 'as-is', without any express or implied warranty.
 * In no event will the authors be held liable for any damages arising from the
 * use of this software.
 * 
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, subject to the following restrictions:
 * 
 * 1. The origin of this software must not be misrepresented; you must not
 *    claim that you wrote the original software. If you use this software in a
 *    product, an acknowledgment in the product documentation is requested, as
 *    shown here:
 * 
 *    Portions copyright � 2002 Chris Sells (http://www.sellsbrothers.com/).
 * 
 * 2. No substantial portion of this source code may be redistributed without
 *    the express written permission of the copyright holders, where
 *    "substantial" is defined as enough code to be recognizably from this code.
 */
#endregion
#region Usage
/* Usage:
 * Run CollectionGenUtil /h for command line switches
 * See CollectionGen.cs in the core folder for info about the XML format etc. 
*/
#endregion
#region History
// 8/27/02:
//  -Chris Sells [csells@sellsbrothers.com] simplified usage
// 7/21/02:
//  -Tor-Erik Hagen [tor-erik@web-amp.com] initial version
#endregion

using System;
using System.IO;
using System.Collections;
using Genghis;
using CollectionGenerator;

class CommandLineHandler : CommandLineParser
{
    [Genghis.CommandLineParser.NoUsage]
    private string   _inputxml = @"";

    [Genghis.CommandLineParser.ValueUsage("Location of input xml file.", Name = "i", Optional = false)]
    public string   inputxml
    {
        get { return _inputxml; }
        set 
        {
            if( !(new FileInfo(value)).Exists )
            {
                throw new UsageException("inputxml", value + " not found");
            }

            _inputxml = value;
        }
    }

    [Genghis.CommandLineParser.NoUsage]
    private string   _language = @"CS";

    [Genghis.CommandLineParser.ValueUsage("Language VB = Visual Basic.NET, CS = C#", Name = "l")]
    public string   language
    {
        get { return _language; }
        set 
        {
            if ((!(value.ToUpper() == "VB")) && (!(value.ToUpper() == "CS")))
            {
                throw new UsageException("language","Language must be either VB (Visual Basic.NET) or CS (C#)");
            }

            _language = value.ToUpper();
        }
    }

    [Genghis.CommandLineParser.FlagUsage("Turn on debugging info", IgnoreCase = false)]
    public bool debug = false;
}

class CollectionGenUtil
{
    [STAThread]
    static void Main(string[] args)
    {
        CommandLineHandler cl = new CommandLineHandler();

        try
        {
            // Parse the command line and show help or version or error
            if( !cl.ParseAndContinue(args) )
            {
                Environment.ExitCode = 1;
                return;
            }

            string  inputFile = cl.inputxml;
            string  input = (new StreamReader(inputFile)).ReadToEnd();

            CollectionGenerator.CollectionGenerator gen = new CollectionGenerator.VBCollectionGenerator();
				
            if (cl.language == "VB")
            {
                gen = new CollectionGenerator.VBCollectionGenerator();
            }
            else
            {
                gen = new CollectionGenerator.CSharpCollectionGenerator();
            }

            string  errorInfo = "";
            bool    error = false;

            string code = gen.GenerateCodeFromXml(input, ref error, ref errorInfo);

            if (error)
            {
                Console.WriteLine("Failed to generate collections, due to an error: {0}\n\n", errorInfo);
                Console.WriteLine("Complete error info:\n\n");
                code = code.Replace(Environment.NewLine,"\n");
                string[] codeLines = code.Split("\n".ToCharArray());
                for (int i = 0; i < codeLines.Length; i++)
                {
                    if (codeLines[i].IndexOf("***ERROR***") > -1)
                    {
                        Console.WriteLine(codeLines[i]);
                        i++;
                        Console.WriteLine(" - " + codeLines[i]);
                    }
                }

                Environment.ExitCode = 1;
                return;
            }

            Console.WriteLine(code);
        }
        catch(Exception ex)
        {
            if (!cl.debug)
            {
                Console.WriteLine("Unexpected error!\n\n{0}\n\nUse the debug switch to see stacktrace", ex.Message);
            }
            else
            {
                Console.WriteLine("Unexpected error!\n\n{0}", ex.ToString());
            }

            Console.WriteLine("Exiting ...");
            Environment.ExitCode = 1;
            return;
			
        }
    }
}
