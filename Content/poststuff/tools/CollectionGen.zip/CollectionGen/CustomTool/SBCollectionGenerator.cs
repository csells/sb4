// SBCollectionGenerator.cs: Chris Sells [csells@sellsbrothers.com]
#region Copyright � 2002-2003 Chris Sells
/* This software is provided 'as-is', without any express or implied warranty.
 * In no event will the authors be held liable for any damages arising from the
 * use of this software.
 * 
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, subject to the following restrictions:
 * 
 * 1. The origin of this software must not be misrepresented; you must not
 *    claim that you wrote the original software. If you use this software in a
 *    product, an acknowledgment in the product documentation is requested, as
 *    shown here:
 * 
 *    Portions copyright � 2002-2003 Chris Sells (http://www.sellsbrothers.com/).
 * 
 * 2. No substantial portion of this source code may be redistributed without
 *    the express written permission of the copyright holders, where
 *    "substantial" is defined as enough code to be recognizably from this code.
 */
#endregion
#region Usage
/*
 * Registration:
 * c:/> regasm /codebase CollectionGen.dll
 *
 * Unregistration:
 * c:/> regasm /unregister CollectionGen.dll
 * 
 * Usage:
 * Add a .xml file in the correct format and set:
 *  Build Action: Content
 *  Custom Tool: SBCollectionGenerator
 * 
 * Format of .xml file:

<typeSafeCollections>
    <typeSafeCollection>
        <templateKind>Vector</templateKind>
        <itemType>int</itemType>
        <collectionName>IntegerCollection</collectionName>
        <collectionNamespace>MyCollections</collectionNamespace>
    </typeSafeCollection>
    <typeSafeCollection>
        <templateKind>Vector</templateKind>
        <itemType>System.Drawing.Point</itemType>
        <collectionName>PointCollection</collectionName>
        <collectionNamespace>MyCollections</collectionNamespace>
    </typeSafeCollection>
    <typeSafeCollection>
        <templateKind>HashTable</templateKind>
        <keyType>string</keyType>
        <itemType>int</itemType>
        <collectionName>StringIntHash</collectionName>
        <collectionNamespace>MyCollections</collectionNamespace>
    </typeSafeCollection>
    <typeSafeCollection>
        <templateKind>HashTable</templateKind>
        <keyType>string</keyType>
        <itemType>System.Drawing.Point</itemType>
        <collectionName>StringPointHash</collectionName>
        <collectionNamespace>MyCollections</collectionNamespace>
    </typeSafeCollection>
</typeSafeCollections>
*/
#endregion
#region History
// 1/3/03:
//  -Chris Sells updated the collection generator to work with VS.NET 2003
//   using a replacement for the BaseCodeGeneratorWithSite from
//   Ian Griffiths [igriffiths@develop.com]. Thanks, Ian!
// 9/29/02:
//  -Daniel Cazzulino [kazzupepe@hotmail.com] pointed out that a DWORD key can be
//   added by passing a signed integer (not an unsigned one as I tried -- silly me).
//   Thanks, Dan!
// 8/27/02:
//  -Chris Sells split out VS.NET-specific functionality.
// 7/1/02:
//  -Chris Sells added self-registration support.
#endregion

using System;
using Microsoft.Win32;  // Registry
using System.Runtime.InteropServices;   // ComRegisterFunction et al
using SellsBrothers.VSDesigner.CodeGenerator; // BaseCodeGeneratorWithSite

namespace CollectionGenerator {
  public abstract class VsCollectionGenerator : BaseCodeGeneratorWithSite {
    public byte[] GenerateCode(CollectionGenerator generator, string fileName, string fileContents) {
      string code = "";
      try {
        code = generator.GenerateCodeFromXml(fileContents);
      }
      catch( Exception e ) {
        code = "***ERROR***\n" + e.Message;
      }
      return System.Text.Encoding.ASCII.GetBytes(code);
    }

    protected static Guid CSharpCategoryGuid = new Guid("{FAE04EC1-301F-11D3-BF4B-00C04F79EFBC}");
    protected static Guid VBCategoryGuid = new Guid("{164B10B9-B200-11D0-8C61-00A0C91E29D5}");

    protected static Version GetVsVersion() {
      Version rtVersion = System.Environment.Version;
      if( rtVersion <= new Version("1.1") ) return new Version("7.0");
      return new Version("7.1");
    }

//    protected static string GetKeyName(Guid categoryGuid) {
//      return GetKeyName(categoryGuid, null);
//    }

    protected static string GetKeyName(Guid categoryGuid, Version vsVersion) {
      string name = "SBCollectionGenerator";
      string ver = (vsVersion == null ? GetVsVersion() : vsVersion).ToString();
      return @"SOFTWARE\Microsoft\VisualStudio\" + ver + @"\Generators\{" + categoryGuid.ToString() + @"}\" + name;
    }

    protected static void RegisterCustomTool(Guid categoryGuid, Type generatorType, string desc, Version vsVersion) {
      /*
        * [HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\VisualStudio\7.0\Generators\{FAE04EC1-301F-11D3-BF4B-00C04F79EFBC}\SBCollectionGenerator]
        * @="Sells Brothers C# Code Generator for Type-Safe Collections"
        * "CLSID"="{3D05404F-6ECF-42b2-8435-2AB63382FFA2}"
        * "GeneratesDesignTimeSource"=dword:00000001
        */

      // Assume GUID is associated with this class via the GuidAttribute.
      // Since this is required for COM interop to work with VS.NET, this seems reasonable
      string  generatorGuid = ((GuidAttribute)(generatorType.GetCustomAttributes(typeof(GuidAttribute), true)[0])).Value;

      using( RegistryKey key = Registry.LocalMachine.CreateSubKey(GetKeyName(categoryGuid, vsVersion)) ) {
        key.SetValue("", desc);
        key.SetValue("CLSID", "{" + generatorGuid + "}");
        key.SetValue("GeneratesDesignTimeSource", 1);
      }
    }

    protected static void UnregisterCustomTool(Guid categoryGuid, Type generatorType, Version vsVersion) {
      Registry.LocalMachine.DeleteSubKey(GetKeyName(categoryGuid, vsVersion), false);
    }
  }

  [Guid("F6144A30-C061-44e4-A50E-1BB10A8B8A45")]
  public class VsCSharpCollectionGenerator : VsCollectionGenerator {
    public override string DefaultExtension { get { return ".cs"; } }

    public override byte[] GenerateCode(string fileName, string fileContents) {
      return GenerateCode(new CSharpCollectionGenerator(), fileName, fileContents);
    }

    [ComRegisterFunction]
    public static void RegisterClass(Type t) {
      Guid category = CSharpCategoryGuid;
      Type type = typeof(VsCSharpCollectionGenerator);
      string desc = "Sells Brothers C# Code Generator for Type-Safe Collections";

      // Should work for both VS.NET 2002 & 2003
      RegisterCustomTool(category, type, desc, new Version(7, 0));
      RegisterCustomTool(category, type, desc, new Version(7, 1));
    }

    [ComUnregisterFunction]
    public static void UnregisterClass(Type t) {
      Guid category = CSharpCategoryGuid;
      Type type = typeof(VsCSharpCollectionGenerator);

      // Should work for both VS.NET 2002 & 2003
      UnregisterCustomTool(category, type, new Version(7, 0));
      UnregisterCustomTool(category, type, new Version(7, 1));
    }
  }

  [Guid("9581541A-C790-41f3-A524-58469FCBB212")]
  public class VsVBCollectionGenerator : VsCollectionGenerator {
    public override string DefaultExtension { get { return ".vb"; } }

    public override byte[] GenerateCode(string fileName, string fileContents) {
      return GenerateCode(new VBCollectionGenerator(), fileName, fileContents);
    }

    [ComRegisterFunction]
    public static void RegisterClass(Type t) {
      Guid category = VBCategoryGuid;
      Type type = typeof(VsVBCollectionGenerator);
      string desc = "Sells Brothers VB Code Generator for Type-Safe Collections";

      // Should work for both VS.NET 2002 & 2003
      RegisterCustomTool(category, type, desc, new Version(7, 0));
      RegisterCustomTool(category, type, desc, new Version(7, 1));
    }

    [ComUnregisterFunction]
    public static void UnregisterClass(Type t) {
      Guid category = VBCategoryGuid;
      Type type = typeof(VsVBCollectionGenerator);

      // Should work for both VS.NET 2002 & 2003
      UnregisterCustomTool(category, type, new Version(7, 0));
      UnregisterCustomTool(category, type, new Version(7, 1));
    }
  }
}
