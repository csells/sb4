using System;
using System.Security;
using System.Security.Permissions;
using System.Collections;
using System.ComponentModel;
using System.Configuration.Install;
using System.Security.Policy;

namespace customActions
{
    /// <summary>
    /// Summary description for Installer1.
    /// </summary>
    [RunInstaller(true)]
    public class Installer1 : System.Configuration.Install.Installer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;

        // Generated with secutil -c -s wahoo.exe
        private byte[] m_bPublicKey = { 0, 36, 0, 0, 4, 128, 0, 0, 148, 0, 0, 0, 6, 2, 0, 0, 0, 36, 0, 0, 82, 83, 65, 49, 0, 4, 0, 0, 1, 0, 1, 0, 235, 73, 247, 5, 169, 205, 173, 221, 44, 56, 88, 64, 87, 197, 241, 152, 127, 14, 144, 91, 93, 141, 210, 16, 107, 14, 120, 201, 31, 40, 5, 124, 206, 36, 14, 66, 58, 35, 89, 152, 152, 238, 112, 117, 218, 42, 57, 79, 202, 136, 233, 204, 52, 128, 225, 11, 198, 237, 239, 240, 13, 214, 106, 137, 237, 226, 172, 222, 52, 121, 181, 185, 161, 14, 160, 56, 5, 159, 137, 85, 71, 73, 240, 65, 78, 121, 207, 13, 194, 240, 120, 87, 172, 205, 13, 73, 240, 111, 127, 206, 155, 86, 107, 26, 40, 53, 237, 173, 45, 100, 201, 52, 142, 222, 154, 145, 245, 150, 190, 203, 10, 185, 209, 181, 234, 16, 135, 218 };

        public Installer1()
        {
            // This call is required by the Designer.
            InitializeComponent();

            // Find the machine policy level
            PolicyLevel machinePolicyLevel = null;
            System.Collections.IEnumerator ph = SecurityManager.PolicyHierarchy();

            while( ph.MoveNext() )
            {
                PolicyLevel pl = (PolicyLevel)ph.Current;

                // HACK: Don't like using a string here but there doesn't appear to be
                // an enum to compare against.
                if( pl.Label == "Machine" )
                {
                    machinePolicyLevel = pl;
                    break;
                }
            }

            if( machinePolicyLevel != null )
            {
                // TODO: Make sure code groups don't already exist, or they're added again

                // Create a new code group giving Wahoo! Internet permissions
            {
                // NOTE: FullTrust is too lenient when shipping the key with the source
                PermissionSet           permissionSet = new NamedPermissionSet("Internet");
                StrongNamePublicKeyBlob key = new StrongNamePublicKeyBlob(m_bPublicKey);
                IMembershipCondition    membership = new StrongNameMembershipCondition(key, null, null);

                // Create the code group
                PolicyStatement         policy = new PolicyStatement(permissionSet);
                CodeGroup               codeGroup = new UnionCodeGroup(membership, policy);
                codeGroup.Description = "Internet permissions for Sells Brothers Wahoo!";
                codeGroup.Name = "Sells Brothers Wahoo!";

                // Add the code group
                machinePolicyLevel.RootCodeGroup.AddChild(codeGroup);
            }

                // HACK: Need minimal Execute permissions site-wide for other permissions to kick in under SP1
                // (Thanks to Keith Brown (kbrown@develop.com) for figuring this out!
                // Create a new permission set with just Execute in it and
                // create a new code group giving all of sellsbrothers.com this permission.
            {
                PermissionSet           permissionSet = new NamedPermissionSet("Execution");
                IMembershipCondition    membership = new SiteMembershipCondition("www.sellsbrothers.com");

                // Create the code group
                PolicyStatement         policy = new PolicyStatement(permissionSet);
                CodeGroup               codeGroup = new UnionCodeGroup(membership, policy);
                codeGroup.Description = "Minimal execute permissions for sellsbrothers.com to enable Internet permission for Wahoo! (fix for SP1 bug)";
                codeGroup.Name = "sellsbrothers.com minimal execute";

                // Add the code group
                machinePolicyLevel.RootCodeGroup.AddChild(codeGroup);
            }

                // Save it
                SecurityManager.SavePolicy();
            }
        }

		#region Component Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
        }
		#endregion
    }
}

class Test
{
    static void Main()
    {
        customActions.Installer1 installer = new customActions.Installer1();
    }
}
