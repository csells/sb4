#ifndef __ICOLLECTIONONSTL2_H__
#define __ICOLLECTIONONSTL2_H__

/*
 * (C) Copyright 1999, Josh Gray.
 * All rights reserved.
 *
 * Comments, please to joshtgray@home.com.
 */

#include <utility>
using namespace std;

//////////////////////////////////////////////////////////////////////////////
// Fast item-at support
//

template <class ITER> inline ITER item_at(ITER F, ITER L, long N)
{
    return _item_at(F, L, N, _Iter_cat(F));
}

template <class ITER> inline ITER _item_at(ITER F, ITER L, long N,
                                           input_iterator_tag)
{
    while(F != L && N-- > 0)
        ++F;
    return F;
}

template <class ITER> inline ITER _item_at(ITER F, ITER L, long N,
                                           forward_iterator_tag)
{
    while(F != L && N-- > 0)
        ++F;
    return F;
}

template <class ITER> inline ITER _item_at(ITER F, ITER L, long N,
                                           bidirectional_iterator_tag)
{
    while(F != L && N-- > 0)
        ++F;
    return F;
}

template <class ITER> inline ITER _item_at(ITER F, ITER L, long N,
                                           random_access_iterator_tag)
{
    if ((L - F) > N)
        return L;
    return F + N;
}

//////////////////////////////////////////////////////////////////////////////
// Index policy
//

template <class ITER>
struct CSimpleIntegerIndexPolicy
{
    static ITER ItemAt(ITER b, ITER e, const VARIANT & index)
    {
        CComVariant v;
        HRESULT hr = v.ChangeType(VT_I4, &index);
        if (FAILED(hr))
            return e;

        return item_at(b, e, V_I4(&v) - 1); // One-based
    }
};

//////////////////////////////////////////////////////////////////////////////
// ICollectionOnSTLImpl2
//

template <class T, class CollType, class ItemType, class CopyItem,
    class EnumBase, const IID * EnumIid,
    class IPolicy = CSimpleIntegerIndexPolicy<CollType::iterator>,
    // CComEnumFlags FLAGS = AtlFlagNoCopy>
    // CComEnumFlags FLAGS = AtlFlagTakeOwnership>
    CComEnumFlags FLAGS = AtlFlagCopy>
class ICollectionOnSTLImpl2 : public T
{
public:
    STDMETHOD(get_Count)(long* pcount)
    {
        if (pcount == NULL)
            return E_POINTER;
        *pcount = m_coll.size();
        return S_OK;
    }

    STDMETHOD(get_Item)(VARIANT VarIndex, ItemType* pvar)
    {
        if (pvar == NULL)
            return E_POINTER;
        HRESULT hr = E_FAIL;
        CollType::iterator iter = IPolicy::ItemAt(m_coll.begin(), m_coll.end(), VarIndex);
        if (iter != m_coll.end())
            hr = CopyItem::copy(pvar, &*iter);
        return hr;
    }
    STDMETHOD(get__NewEnum)(IUnknown** ppUnk)
    {
        if (ppUnk == NULL)
            return E_POINTER;
        *ppUnk = NULL;
        HRESULT hRes = S_OK;

        if (FLAGS == AtlFlagNoCopy)
        {
            typedef CComObject<
                CComEnumOnSTL<
                    IEnumVARIANT,
                    &__uuidof(IEnumVARIANT),
                    VARIANT,
                    _Copy<VARIANT>,
                    CollType
                > > EnumType;

            CComObject<EnumType>* p;
            hRes = CComObject<EnumType>::CreateInstance(&p);
            if (SUCCEEDED(hRes))
            {
                hRes = p->Init(this, m_coll);
                if (hRes == S_OK)
                    hRes = p->QueryInterface(IID_IUnknown, (void**)ppUnk);
            }
            if (hRes != S_OK)
                delete p;
        }
        else
        {
            typedef CComObject<
                CComEnumOnSTL2<
                    IEnumVARIANT,
                    &__uuidof(IEnumVARIANT),
                    VARIANT,
                    _Copy<VARIANT>,
                    CollType::iterator
                > > EnumType;

            CComObject<EnumType>* p;
            hRes = CComObject<EnumType>::CreateInstance(&p);
            if (SUCCEEDED(hRes))
            {
                hRes = p->Init(m_coll.begin(), m_coll.end(), 0, FLAGS);
                if (hRes == S_OK)
                    hRes = p->QueryInterface(IID_IUnknown, (void**)ppUnk);
            }
            if (hRes != S_OK)
                delete p;
        }
        return hRes;
    }

    CollType m_coll;
};

#endif /* not defined __ICOLLECTIONONSTL2_H__ */
#pragma once