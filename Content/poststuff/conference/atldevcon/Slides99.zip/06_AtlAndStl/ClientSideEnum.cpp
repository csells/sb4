/*
 * (C) Copyright 1999, Josh Gray.
 * All rights reserved.
 *
 * Comments, please to joshtgray@home.com.
 */

/*
 * Relies on Chris Sells' client-side enum headers.  See the
 * slides for the URL.
 */

#include "stdafx.h"

#include <iostream>
#include <algorithm>
using namespace std;

#include <atlbase.h>
#include <msxml.h>

struct CoInit {
    CoInit() { CoInitialize(0); }
    ~CoInit() { CoUninitialize(); }
} _CoInit;

#include "enum_iterator.h"

void PrintXmlTree(IXMLElement * pElem, int Indent);

/*
 * Functor to extract an XML element from a variant
 * and print its subtree.
 */

struct PrintNode
{
    PrintNode(int Indent = 0) : m_Indent(Indent) { }

    void operator() (VARIANT & v)
    {
        if (V_VT(&v) == VT_DISPATCH)
        {
            CComPtr<IXMLElement> pElem;
            HRESULT hr = V_DISPATCH(&v)->QueryInterface(&pElem);
            if (SUCCEEDED(hr))
                PrintXmlTree(pElem, m_Indent);
        }
    }

private:
    long m_Indent;
};

void PrintXmlTree(IXMLElement * pElem, int Indent = 0)
{
    for(int i = Indent; i; --i)
        cout << '\t';

    CComBSTR TagName;
    HRESULT hr = pElem->get_tagName(&TagName);
    if (SUCCEEDED(hr))
        wcout << L"<" << static_cast<BSTR>(TagName) << L" />";
    cout << endl;

    CComPtr<IXMLElementCollection> pCol;
    hr = pElem->get_children(&pCol);
    if (FAILED(hr) || !pCol)
        return;

    CComPtr<IUnknown> pUnk;
    hr = pCol->get__newEnum(&pUnk);
    if (FAILED(hr))
        return;

#if 1

    for_each(
        variant_iterator(pUnk),
        variant_iterator(),
        PrintNode(Indent + 1)
    );

#else
    CComPtr<IEnumVARIANT> pEnum;
    pUnk->QueryInterface(&pEnum);

    PrintNode NodePrinter(Indent + 1);

    const int CHUNK_SIZE = 64;
    VARIANT buf[CHUNK_SIZE];
    int NumInBuffer = 0;
    unsigned long Actual = 0;
    while (SUCCEEDED(hr = pEnum->Next(CHUNK_SIZE, buf, &Actual)))
    {
        for(int i = 0; i < Actual; ++i)
            NodePrinter(buf[i]);

        if (hr == S_FALSE)
            break;
    }
#endif
}

int main(int argc, char* argv[])
{
    if (argc < 2)
        return cerr << "Must supply a filename." << endl, -1;

    HRESULT hr;

    CComPtr<IXMLDocument> pDoc;
    hr = pDoc.CoCreateInstance(__uuidof(XMLDocument));

    hr = pDoc->put_URL(CComBSTR(argv[1]));
    if (FAILED(hr))
        return -1;

    CComPtr<IXMLElement> pElem;
    hr = pDoc->get_root(&pElem);
    if (FAILED(hr))
        return -1;

    PrintXmlTree(pElem);

    return 0;
}
