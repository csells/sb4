#ifndef __IENUMONSTLIMPL2_H__
#define __IENUMONSTLIMPL2_H__

/*
 * (C) Copyright 1999, Josh Gray.
 * All rights reserved.
 *
 * Comments, please to joshtgray@home.com.
 */

//////////////////////////////////////////////////////////////////////////////
// IEnumOnSTLImpl2
//

template <class Base,
    const IID* piid,
    class T,
    class Copy,
    class ITER>
class ATL_NO_VTABLE IEnumOnSTLImpl2 : public Base
{
public:
    IEnumOnSTLImpl2() { m_dwFlags = 0; }
    ~IEnumOnSTLImpl2();
    STDMETHOD(Next)(ULONG celt, T* rgelt, ULONG* pceltFetched);
    STDMETHOD(Skip)(ULONG celt);
    STDMETHOD(Reset)(void) { m_iter = m_begin; return S_OK; }
    STDMETHOD(Clone)(Base ** ppEnum);

    HRESULT Init(ITER begin, ITER end, IUnknown* pUnk,
        CComEnumFlags flags = AtlFlagNoCopy);

    CComPtr<IUnknown> m_spUnk;

    T* m_begin;
    T* m_end;
    T* m_iter;

    DWORD m_dwFlags;
protected:
    enum FlagBits
    {
        BitCopy=1,
        BitOwn=2
    };
};

template <class Base, const IID* piid, class T, class Copy, class ITER>
IEnumOnSTLImpl2<Base, piid, T, Copy, ITER>::~IEnumOnSTLImpl2()
{
    if (m_dwFlags & BitOwn)
    {
        for (T* p = m_begin; p != m_end; p++)
            Copy::destroy(p);
        delete [] m_begin;
    }
}

template <class Base, const IID* piid, class T, class Copy, class ITER>
STDMETHODIMP IEnumOnSTLImpl2<Base, piid, T, Copy, ITER>::Next(ULONG celt, T* rgelt,
    ULONG* pceltFetched)
{
    if (rgelt == NULL || (celt != 1 && pceltFetched == NULL))
        return E_POINTER;
    if (m_begin == NULL || m_end == NULL || m_iter == NULL)
        return E_FAIL;
    ULONG nRem = (ULONG)(m_end - m_iter);
    HRESULT hRes = S_OK;
    if (nRem < celt)
        hRes = S_FALSE;
    ULONG nMin = min(celt, nRem);
    if (pceltFetched != NULL)
        *pceltFetched = nMin;
    T* pelt = rgelt;
    while(nMin--)
    {
        HRESULT hr = Copy::copy(pelt, m_iter);
        if (FAILED(hr))
        {
            while (rgelt < pelt)
                Copy::destroy(rgelt++);
            if (pceltFetched != NULL)
                *pceltFetched = 0;
            return hr;
        }
        pelt++;
        m_iter++;
    }
    return hRes;
}

template <class Base, const IID* piid, class T, class Copy, class ITER>
STDMETHODIMP IEnumOnSTLImpl2<Base, piid, T, Copy, ITER>::Skip(ULONG celt)
{
    m_iter += celt;
    if (m_iter >= m_end)
    {
        m_iter = m_end;
        return S_FALSE;
    }
    if (m_iter < m_begin)
    {
        m_iter = m_begin;
        return S_FALSE;
    }
    return S_OK;
}

template <class Base, const IID* piid, class T, class Copy, class ITER>
STDMETHODIMP IEnumOnSTLImpl2<Base, piid, T, Copy, ITER>::Clone(Base** ppEnum)
{
    typedef CComObject<CComEnum<Base, piid, T, Copy> > _class;
    HRESULT hRes = E_POINTER;
    if (ppEnum != NULL)
    {
        *ppEnum = NULL;
        _class* p;
        hRes = _class::CreateInstance(&p);
        if (SUCCEEDED(hRes))
        {
            // If the data is a copy then we need to keep "this" object around
            hRes = p->Init(m_begin, m_end, (m_dwFlags & BitCopy) ? this : m_spUnk);
            if (SUCCEEDED(hRes))
            {
                p->m_iter = m_iter;
                hRes = p->_InternalQueryInterface(*piid, (void**)ppEnum);
            }
            if (FAILED(hRes))
                delete p;
        }
    }
    return hRes;
}

template <class Base, const IID* piid, class T, class Copy, class ITER>
HRESULT IEnumOnSTLImpl2<Base, piid, T, Copy, ITER>::Init(ITER begin, ITER end, IUnknown* pUnk,
    CComEnumFlags flags)
{
    /*
     * This is a bit kludgy, 'cause it doesn't statically enforce
     * that begin and end must be pointer-style iterators when
     * flags is not equal to AtlFlagCopy.  However, due to the fact
     * that this class was really designed to support ICollectionOnSTL2.h
     * which plays by the correct rules, I let it slide here.  :)
     */
    if (flags == AtlFlagCopy)
    {
        ATLASSERT(m_begin == NULL); //Init called twice?
        ATLTRY(m_begin = new T[distance(begin, end)])
        m_iter = m_begin;
        if (m_begin == NULL)
            return E_OUTOFMEMORY;
        for (ITER i=begin; i != end; i++)
        {
            Copy::init(m_iter);
            HRESULT hr = Copy::copy(m_iter, &*i);
            if (FAILED(hr))
            {
                T* p = m_begin;
                while (p < m_iter)
                    Copy::destroy(p++);
                delete [] m_begin;
                m_begin = m_end = m_iter = NULL;
                return hr;
            }
            m_iter++;
        }
        m_end = m_begin + (distance(begin,end));
    }
    else
    {
        m_begin = &*begin;
        m_end = &*end;
    }
    m_spUnk = pUnk;
    m_iter = m_begin;
    m_dwFlags = flags;
    return S_OK;
}

//////////////////////////////////////////////////////////////////////////////
// CComEnumOnSTL2
//

template <class Base, const IID* piid, class T, class Copy, class ITER, class ThreadModel = CComObjectThreadModel>
class ATL_NO_VTABLE CComEnumOnSTL2 :
    public IEnumOnSTLImpl2<Base, piid, T, Copy, ITER>,
    public CComObjectRootEx< ThreadModel >
{
public:
    typedef CComEnumOnSTL2<Base, piid, T, Copy, ITER, ThreadModel > _CComEnum;
    typedef IEnumOnSTLImpl2<Base, piid, T, Copy, ITER > _CComEnumBase;
    BEGIN_COM_MAP(_CComEnum)
        COM_INTERFACE_ENTRY_IID(*piid, _CComEnumBase)
    END_COM_MAP()
};

#endif /* not defined __IENUMONSTLIMPL2_H__ */
#pragma once