ATL DevCon Slides:

Each folder contains the slides and the corresponding code for the
speaker's presentation at the 1999 ATL DevCon. Speakers may be
reached at the following email addresses:

Dr. Richard Grimes: richard@grimes.demon.co.uk
Dr. Al Major: AlMajor@BoxSpoon.Com
Don Box: dbox@develop.com
Dharma Shukla: IUnknown2k@hotmail.com
Josh Gray: jgray@genedax.com
Hugh Brown: brown_hugh@hotmail.com
Ron Estrin: rsestrin@software.rockwell.com
Chris Sells: csells@sellsbrothers.com
