#ifndef __ATL_AI_
#define __ATL_AI_

#if (_MSC_VER >= 1200)	// VC6 or greater
extern "C++"
{
#endif

#define DEFINE_UNKNOWN_ID(n) \
    MIDL_INTERFACE("00000000-0000-0000-C000-000000000046") \
	IUnknownID##n \
    { \
    public: \
        BEGIN_INTERFACE \
        virtual HRESULT STDMETHODCALLTYPE QueryInterface##n( \
            /* [in] */ REFIID riid, \
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject) = 0; \
        virtual ULONG STDMETHODCALLTYPE AddRef( void) = 0; \
        virtual ULONG STDMETHODCALLTYPE Release( void) = 0; \
        END_INTERFACE \
    };

#define DEFINE_DISPATCH_ID(n) \
	DEFINE_UNKNOWN_ID(n) \
    MIDL_INTERFACE("00020400-0000-0000-C000-000000000046") \
    IDispatchID##n : public IUnknownID##n \
    { \
    public: \
        virtual HRESULT STDMETHODCALLTYPE GetTypeInfoCount( \
            /* [out] */ UINT __RPC_FAR *pctinfo) = 0; \
        virtual HRESULT STDMETHODCALLTYPE GetTypeInfo( \
            /* [in] */ UINT iTInfo, \
            /* [in] */ LCID lcid, \
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo) = 0; \
        virtual HRESULT STDMETHODCALLTYPE GetIDsOfNames( \
            /* [in] */ REFIID riid, \
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames, \
            /* [in] */ UINT cNames, \
            /* [in] */ LCID lcid, \
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId) = 0; \
        virtual /* [local] */ HRESULT STDMETHODCALLTYPE Invoke( \
            /* [in] */ DISPID dispIdMember, \
            /* [in] */ REFIID riid, \
            /* [in] */ LCID lcid, \
            /* [in] */ WORD wFlags, \
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams, \
            /* [out] */ VARIANT __RPC_FAR *pVarResult, \
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo, \
            /* [out] */ UINT __RPC_FAR *puArgErr) = 0; \
    };

#define DEFINE_SUPPORTERRORINFO_ID(n) \
    MIDL_INTERFACE("DF0B3D60-548F-101B-8E65-08002B2BD119") \
    ISupportErrorInfoID##n : public IUnknownID##n \
    { \
    public: \
        virtual HRESULT STDMETHODCALLTYPE InterfaceSupportsErrorInfo( \
            /* [in] */ REFIID riid) = 0; \
    };

#define DEFINE_PERSIST_ID(n) \
    MIDL_INTERFACE("0000010c-0000-0000-C000-000000000046") \
	IPersistID##n : public IUnknownID##n \
    { \
    public: \
        virtual HRESULT STDMETHODCALLTYPE IPIDGetClassID( \
            /* [out] */ CLSID __RPC_FAR *pClassID) = 0; \
    };
#define IMPLEMENT_PERSIST_ID public: \
	STDMETHOD (IPIDGetClassID) (CLSID __RPC_FAR *pClassID) { \
		HRESULT hr; \
		CComPtr <IPersistStreamInit> spIPSI; \
		hr	= _InternalQueryInterface (IID_IPersistStreamInit, reinterpret_cast<void **> (&spIPSI)); \
		ATLASSERT (SUCCEEDED (hr)); \
		return spIPSI->GetClassID (pClassID); \
	}

#define DEFINE_PERSISTSTREAMINIT_ID(n) \
    MIDL_INTERFACE("7FD52380-4E07-101B-AE2D-08002B2EC713") \
    IPersistStreamInitID##n : public IPersistID##n \
    { \
    public: \
        virtual HRESULT STDMETHODCALLTYPE IPSIDIsDirty( void) = 0; \
        virtual HRESULT STDMETHODCALLTYPE IPSIDLoad( \
            /* [in] */ LPSTREAM pStm) = 0; \
        virtual HRESULT STDMETHODCALLTYPE IPSIDSave##ID##n ( \
            /* [in] */ LPSTREAM pStm, \
            /* [in] */ BOOL fClearDirty) = 0; \
        virtual HRESULT STDMETHODCALLTYPE IPSIDGetSizeMax( \
            /* [out] */ ULARGE_INTEGER __RPC_FAR *pCbSize) = 0; \
        virtual HRESULT STDMETHODCALLTYPE IPSIDInitNew( void) = 0; \
    };
#define IMPLEMENT_PERSISTSTREAMINIT_ID(n) \
	IMPLEMENT_PERSIST_ID \
    STDMETHOD (IPSIDIsDirty) (void) { \
		HRESULT hr; \
		CComPtr <IPersistStreamInit> spIPSI; \
		hr	= _InternalQueryInterface (IID_IPersistStreamInit, reinterpret_cast<void **> (&spIPSI)); \
		ATLASSERT (SUCCEEDED (hr)); \
		return spIPSI->IsDirty (); \
	} \
    STDMETHOD (IPSIDLoad) (LPSTREAM pStm) { \
		HRESULT hr; \
		CComPtr <IPersistStreamInit> spIPSI; \
		hr	= _InternalQueryInterface (IID_IPersistStreamInit, reinterpret_cast<void **> (&spIPSI)); \
		ATLASSERT (SUCCEEDED (hr)); \
		return spIPSI->Load (pStm); \
	} \
	STDMETHOD (IPSIDSave##ID##n) (LPSTREAM pStm, BOOL fClearDirty) { \
		_m_vlID	= n; \
		HRESULT hr; \
		CComPtr <IPersistStreamInit> spIPSI; \
		hr	= _InternalQueryInterface (IID_IPersistStreamInit, reinterpret_cast<void **> (&spIPSI)); \
		ATLASSERT (SUCCEEDED (hr)); \
		return spIPSI->Save (pStm, fClearDirty); \
	} \
	STDMETHOD (IPSIDGetSizeMax) (ULARGE_INTEGER __RPC_FAR *pCbSize) { \
		HRESULT hr; \
		CComPtr <IPersistStreamInit> spIPSI; \
		hr	= _InternalQueryInterface (IID_IPersistStreamInit, reinterpret_cast<void **> (&spIPSI)); \
		ATLASSERT (SUCCEEDED (hr)); \
		return spIPSI->GetSizeMax (pCbSize); \
	} \
	STDMETHOD (IPSIDInitNew) (void) { \
		HRESULT hr; \
		CComPtr <IPersistStreamInit> spIPSI; \
		hr	= _InternalQueryInterface (IID_IPersistStreamInit, reinterpret_cast<void **> (&spIPSI)); \
		ATLASSERT (SUCCEEDED (hr)); \
		return spIPSI->InitNew (); \
	}

#define DEFINE_PERSISTFILE_ID(n) \
    MIDL_INTERFACE("0000010b-0000-0000-C000-000000000046") \
    IPersistFileID##n : public IPersistID##n \
    { \
    public: \
        virtual HRESULT STDMETHODCALLTYPE IPFIDIsDirty( void) = 0; \
        virtual HRESULT STDMETHODCALLTYPE IPFIDLoad( \
            /* [in] */ LPCOLESTR pszFileName, \
            /* [in] */ DWORD dwMode) = 0; \
        virtual HRESULT STDMETHODCALLTYPE IPFIDSaveID##n ( \
            /* [unique][in] */ LPCOLESTR pszFileName, \
            /* [in] */ BOOL fRemember) = 0; \
        virtual HRESULT STDMETHODCALLTYPE IPFIDSaveCompleted( \
            /* [unique][in] */ LPCOLESTR pszFileName) = 0; \
        virtual HRESULT STDMETHODCALLTYPE IPFIDGetCurFile( \
            /* [out] */ LPOLESTR __RPC_FAR *ppszFileName) = 0; \
    };
#define IMPLEMENT_PERSISTFILE_ID(n) public: \
    STDMETHOD (IPFIDIsDirty) (void) { \
		HRESULT hr; \
		CComPtr <IPersistFile> spIPF; \
		hr	= _InternalQueryInterface (IID_IPersistFile, reinterpret_cast <void **> (&spIPF)); \
		ATLASSERT (SUCCEEDED (hr)); \
		return spIPF->IsDirty (); \
	} \
    STDMETHOD (IPFIDLoad) (LPCOLESTR pszFileName, DWORD dwMode) { \
		HRESULT hr; \
		CComPtr <IPersistFile> spIPF; \
		hr	= _InternalQueryInterface (IID_IPersistFile, reinterpret_cast <void **> (&spIPF)); \
		ATLASSERT (SUCCEEDED (hr)); \
		return spIPF->Load (pszFileName, DWORD dwMode); \
	} \
	STDMETHOD (IPFIDSaveID##n) (LPCOLESTR pszFileName) { \
		_m_vlID	= n; \
		HRESULT hr; \
		CComPtr <IPersistFile> spIPF; \
		hr	= _InternalQueryInterface (IID_IPersistFile, reinterpret_cast <void **> (&spIPF)); \
		ATLASSERT (SUCCEEDED (hr)); \
		return spIPF->Save (pszFileName); \
	} \
	STMETHOD(IPFIDSaveCompleted) (LPCOLESTR pszFileName) {\
		HRESULT hr; \
		CComPtr <IPersistFile> spIPF; \
		hr	= _InternalQueryInterface (IID_IPersistFile, reinterpret_cast <void **> (&spIPF)); \
		ATLASSERT (SUCCEEDED (hr)); \
		return spIPF->SaveCompleted (pszFileName); \
	} \
	STDMETHOD(IPFIDGetCurFile) (LPOLESTR __RPC_FAR *ppszFileName) { \
		HRESULT hr; \
		CComPtr <IPersistFile> spIPF; \
		hr	= _InternalQueryInterface (IID_IPersistFile, reinterpret_cast <void **> (&spIPF)); \
		ATLASSERT (SUCCEEDED (hr)); \
		return spIPF->GetCurFile (ppszFileName); \
	}

#define DEFINE_PERSISTPROPERTYBAG_ID(n) \
    MIDL_INTERFACE("37D84F60-42CB-11CE-8135-00AA004BB851") \
    IPersistPropertyBagID##n : public IPersistID##n \
    { \
    public: \
        virtual HRESULT STDMETHODCALLTYPE IPPIDInitNew( void) = 0; \
        virtual HRESULT STDMETHODCALLTYPE IPPIDLoad( \
            /* [in] */ IPropertyBag __RPC_FAR *pPropBag, \
            /* [in] */ IErrorLog __RPC_FAR *pErrorLog) = 0; \
        virtual HRESULT STDMETHODCALLTYPE IPPIDSaveID##n ( \
            /* [in] */ IPropertyBag __RPC_FAR *pPropBag, \
            /* [in] */ BOOL fClearDirty, \
            /* [in] */ BOOL fSaveAllProperties) = 0; \
    };
#define IMPLEMENT_PERSISTPROPERTYBAG_ID(n) public: \
	STDMETHOD (IPPIDInitNew) (void) { \
		HRESULT hr; \
		CComPtr <IPersistPropertyBag> spIPP; \
		hr	= _InternalQueryInterface (IID_IPersistPropertyBag, reinterpret_cast <void **> (&spIPP)); \
		ATLASSERT (SUCCEEDED (hr)); \
		return spIPP->InitNew (); \
	} \
	STDMETHOD(IPPIDLoad)(IPropertyBag __RPC_FAR *pPropBag, IErrorLog __RPC_FAR *pErrorLog) { \
		HRESULT hr; \
		CComPtr <IPersistPropertyBag> spIPP; \
		hr	= _InternalQueryInterface (IID_IPersistPropertyBag, reinterpret_cast <void **> (&spIPP)); \
		ATLASSERT (SUCCEEDED (hr)); \
		return spIPP->Load (pPropBag, pErrorLog); \
	} \
	STDMETHOD (IPPIDSaveID##n) (IPropertyBag __RPC_FAR *pPropBag, BOOL fClearDirty, BOOL fSaveAllProperties) { \
		_m_vlID	= n; \
		HRESULT hr; \
		CComPtr <IPersistPropertyBag> spIPP; \
		hr	= _InternalQueryInterface (IID_IPersistPropertyBag, reinterpret_cast <void **> (&spIPP)); \
		ATLASSERT (SUCCEEDED (hr)); \
		return spIPP->Save (pPropBag, fClearDirty, fSaveAllProperties); \
	}

#if (_MSC_VER >= 1200)	// VC6 or greater
} // extern "C++"
#endif

#define BEGIN_COM_MAP2(x,n) public: \
	HRESULT _InternalQueryInterface##n(REFIID iid, void** ppvObject) \
	{ return InternalQueryInterface(this, _GetEntries##n(), iid, ppvObject); } \
	const static _ATL_INTMAP_ENTRY* WINAPI _GetEntries##n() { \
	static const _ATL_INTMAP_ENTRY _entries##n[] = { DEBUG_QI_ENTRY(x)

#ifdef _ATL_DEBUG
#define END_COM_MAP2(n) {NULL, 0, 0}}; return &_entries##n[1];} \
	STDMETHOD(QueryInterface##n)(REFIID, void**) = 0;
#else
#define END_COM_MAP2(n) {NULL, 0, 0}}; return _entries##n;} \
	STDMETHOD(QueryInterface##n)(REFIID, void**) = 0;
#endif // _ATL_DEBUG


typedef HRESULT (WINAPI _ATL_QIFUNC) (void*, const _ATL_INTMAP_ENTRY*, REFIID iid, void** ppvObject);

struct _ATL_IDMAP_ENTRY
{
	LONG	m_vlID;
	const _ATL_INTMAP_ENTRY* m_pEntry; //NULL:end, 1:offset, n:ptr
};

#define BEGIN_IDENTITY_MAP(n) \
	HRESULT _InternalQueryInterface (LONG l, REFIID iid, void ** ppvObject) { \
		const _ATL_IDMAP_ENTRY * pEntry; \
		for ( pEntry = _GetIDMapEntries (); \
			pEntry->m_pEntry; \
			pEntry++ ) { \
			if ( l == pEntry->m_vlID ) \
				return InternalQueryInterface (this, pEntry->m_pEntry, iid, ppvObject); \
		} \
		ATLASSERT (FALSE); \
		return QueryInterface (iid, ppvObject); \
	} \
	const static _ATL_IDMAP_ENTRY* WINAPI _GetIDMapEntries() { \
	static const _ATL_IDMAP_ENTRY _idmapentries[] = {

#define END_IDENTITY_MAP {0, 0}}; return _idmapentries;}

#define COM_IDENTITY_ENTRY(n)\
	{n, \
	_GetEntries##n()},

#define IMPLEMENT_PERSISTABLE_ID public: \
	LONG _m_vlID;

#define DEFINE_OBJECT_CLASS_ID2(n, m, T) \
template <class B> \
class T##ID##n : \
	public T##ID##m <B> \
{ \
public: \
	T##ID##n () { \
	} \
	T##ID##n (void * p) \
		: T##ID##m <B> (p) { \
	} \
	STDMETHOD(QueryInterface##n)(REFIID iid, void ** ppvObject) \
		{return _InternalQueryInterface##n(iid, ppvObject);} \
};

#define DEFINE_OBJECT_CLASS_ID(n, T) \
template <class B> \
class T##ID##n : \
	public T <B> \
{ \
public: \
	T##ID##n () { \
	} \
	T##ID##n (void * p) \
		: T <B> (p) { \
	} \
	STDMETHOD(QueryInterface##n)(REFIID iid, void ** ppvObject) \
		{return _InternalQueryInterface##n(iid, ppvObject);} \
};

#define DEFINE_OBJECT_CLASS_ID_1(T) \
template <class B> \
class T##ID1 : \
	public T <B> \
{ \
public: \
	T##ID1 () { \
	} \
	T##ID1 (void *p) \
		: T <B> (p) { \
	} \
	STDMETHOD(QueryInterface1)(REFIID iid, void ** ppvObject) \
		{return _InternalQueryInterface(1, iid, ppvObject);} \
};

#define DEFINE_OBJECT_CLASS_ID_2(T) \
template <class B> \
class T##ID2 : \
	public T <B> \
{ \
public: \
	T##ID2 () { \
	} \
	T##ID2 (void *p) \
		: T <B> (p) {} \
	STDMETHOD(QueryInterface1)(REFIID iid, void ** ppvObject) \
		{return _InternalQueryInterface(1, iid, ppvObject);} \
	STDMETHOD(QueryInterface2)(REFIID iid, void ** ppvObject) \
		{return _InternalQueryInterface(2, iid, ppvObject);} \
};

#define DEFINE_OBJECT_CLASS_ID_3(T) \
template <class B> \
class T##ID3 : \
	public T <B> \
{ \
public: \
	T##ID3 () { \
	} \
	T##ID3 (void *p) \
		: T <B> (p) {} \
	STDMETHOD(QueryInterface1)(REFIID iid, void ** ppvObject) \
		{return _InternalQueryInterface(1, iid, ppvObject);} \
	STDMETHOD(QueryInterface2)(REFIID iid, void ** ppvObject) \
		{return _InternalQueryInterface(2, iid, ppvObject);} \
	STDMETHOD(QueryInterface3)(REFIID iid, void ** ppvObject) \
		{return _InternalQueryInterface(3, iid, ppvObject);} \
};

#define DEFINE_OBJECT_CLASS_ID_4(T) \
template <class B> \
class T##ID4 : \
	public T <B> \
{ \
public: \
	T##ID4 () { \
	} \
	T##ID4 (void *p) \
		: T <B> (p) { \
	} \
	STDMETHOD(QueryInterface1)(REFIID iid, void ** ppvObject) \
		{return _InternalQueryInterface(1, iid, ppvObject);} \
	STDMETHOD(QueryInterface2)(REFIID iid, void ** ppvObject) \
		{return _InternalQueryInterface(2, iid, ppvObject);} \
	STDMETHOD(QueryInterface3)(REFIID iid, void ** ppvObject) \
		{return _InternalQueryInterface(3, iid, ppvObject);} \
	STDMETHOD(QueryInterface4)(REFIID iid, void ** ppvObject) \
		{return _InternalQueryInterface(4, iid, ppvObject);} \
};

#define DEFINE_OBJECT_CLASS_PERSISTABLE_ID(n, T) \
template <class B> \
class T##IDPersist##n : \
	public T##ID##n <B> \
{ \
public: \
	T##IDPersist##n () : _m_vlMaxID (n) : { \
	} \
	T##IDPersist##n (void * p) \
		: T##ID##n <B> (p), _m_vlMaxID (n) { \
	} \
	STDMETHOD(QueryInterface)(REFIID iid, void ** ppvObject) \
	{ \
		if ( 0 >= _m_vlID || _m_vlID > _m_vlMaxID ) { \
			return T <B>::QueryInterface (iid, ppvObject); \
		} else { \
			return _InternalQueryInterface (_m_vlID, iid, ppvObject); \
		} \
	} \
private: \
	const LONG _m_vlMaxID; \
};

#define DECLARE_NOT_AGGREGATABLE_AI(x, c) public:\
	typedef CComCreator2< CComCreator< c < x > >, CComFailCreator<CLASS_E_NOAGGREGATION> > _CreatorClass; \
	LONG		m_vlID;

DEFINE_DISPATCH_ID (1)
DEFINE_DISPATCH_ID (2)
DEFINE_DISPATCH_ID (3)
DEFINE_DISPATCH_ID (4)
DEFINE_DISPATCH_ID (5)
DEFINE_DISPATCH_ID (6)
DEFINE_DISPATCH_ID (7)
DEFINE_DISPATCH_ID (8)
DEFINE_DISPATCH_ID (9)
DEFINE_DISPATCH_ID (10)

DEFINE_SUPPORTERRORINFO_ID (1)
DEFINE_SUPPORTERRORINFO_ID (2)
DEFINE_SUPPORTERRORINFO_ID (3)
DEFINE_SUPPORTERRORINFO_ID (4)
DEFINE_SUPPORTERRORINFO_ID (5)
DEFINE_SUPPORTERRORINFO_ID (6)
DEFINE_SUPPORTERRORINFO_ID (7)
DEFINE_SUPPORTERRORINFO_ID (8)
DEFINE_SUPPORTERRORINFO_ID (9)
DEFINE_SUPPORTERRORINFO_ID (10)

DEFINE_PERSIST_ID (1)
DEFINE_PERSIST_ID (2)
DEFINE_PERSIST_ID (3)
DEFINE_PERSIST_ID (4)
DEFINE_PERSIST_ID (5)
DEFINE_PERSIST_ID (6)
DEFINE_PERSIST_ID (7)
DEFINE_PERSIST_ID (8)
DEFINE_PERSIST_ID (9)
DEFINE_PERSIST_ID (10)

DEFINE_PERSISTSTREAMINIT_ID (1)
DEFINE_PERSISTSTREAMINIT_ID (2)
DEFINE_PERSISTSTREAMINIT_ID (3)
DEFINE_PERSISTSTREAMINIT_ID (4)
DEFINE_PERSISTSTREAMINIT_ID (5)
DEFINE_PERSISTSTREAMINIT_ID (6)
DEFINE_PERSISTSTREAMINIT_ID (7)
DEFINE_PERSISTSTREAMINIT_ID (8)
DEFINE_PERSISTSTREAMINIT_ID (9)
DEFINE_PERSISTSTREAMINIT_ID (10)

DEFINE_PERSISTFILE_ID (1)
DEFINE_PERSISTFILE_ID (2)
DEFINE_PERSISTFILE_ID (3)
DEFINE_PERSISTFILE_ID (4)
DEFINE_PERSISTFILE_ID (5)
DEFINE_PERSISTFILE_ID (6)
DEFINE_PERSISTFILE_ID (7)
DEFINE_PERSISTFILE_ID (8)
DEFINE_PERSISTFILE_ID (9)
DEFINE_PERSISTFILE_ID (10)

DEFINE_PERSISTPROPERTYBAG_ID (1)
DEFINE_PERSISTPROPERTYBAG_ID (2)
DEFINE_PERSISTPROPERTYBAG_ID (3)
DEFINE_PERSISTPROPERTYBAG_ID (4)
DEFINE_PERSISTPROPERTYBAG_ID (5)
DEFINE_PERSISTPROPERTYBAG_ID (6)
DEFINE_PERSISTPROPERTYBAG_ID (7)
DEFINE_PERSISTPROPERTYBAG_ID (8)
DEFINE_PERSISTPROPERTYBAG_ID (9)
DEFINE_PERSISTPROPERTYBAG_ID (10)

DEFINE_OBJECT_CLASS_ID_1 (CComObject)
DEFINE_OBJECT_CLASS_ID_2 (CComObject)
DEFINE_OBJECT_CLASS_ID_3 (CComObject)
DEFINE_OBJECT_CLASS_ID_4 (CComObject)

DEFINE_OBJECT_CLASS_ID_1 (CComObjectGlobal)
DEFINE_OBJECT_CLASS_ID_2 (CComObjectGlobal)
DEFINE_OBJECT_CLASS_ID_3 (CComObjectGlobal)
DEFINE_OBJECT_CLASS_ID_4 (CComObjectGlobal)

DEFINE_OBJECT_CLASS_ID_1 (CComObjectSI)
DEFINE_OBJECT_CLASS_ID_2 (CComObjectSI)
DEFINE_OBJECT_CLASS_ID_3 (CComObjectSI)
DEFINE_OBJECT_CLASS_ID_4 (CComObjectSI)

DEFINE_OBJECT_CLASS_PERSISTABLE_ID (1, CComObject)
DEFINE_OBJECT_CLASS_PERSISTABLE_ID (2, CComObject)
DEFINE_OBJECT_CLASS_PERSISTABLE_ID (3, CComObject)
DEFINE_OBJECT_CLASS_PERSISTABLE_ID (4, CComObject)

#endif
