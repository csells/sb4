#ifndef __ATL__SI_
#define __ATL__SI_

#if (_MSC_VER >= 1200)	// VC6 or greater
extern "C++"
{
#endif

#define DEFINE_UNKNOWNWEAK \
    MIDL_INTERFACE("00000000-0000-0000-C000-000000000046") \
	IUnknownWeak \
    { \
    public: \
        BEGIN_INTERFACE \
        virtual HRESULT STDMETHODCALLTYPE WeakQueryInterface( \
            /* [in] */ REFIID riid, \
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject) = 0; \
        virtual ULONG STDMETHODCALLTYPE WeakAddRef( void) = 0; \
        virtual ULONG STDMETHODCALLTYPE WeakRelease( void) = 0; \
        END_INTERFACE \
    };

#define DEFINE_DISPATCHWEAK \
	DEFINE_UNKNOWNWEAK \
    MIDL_INTERFACE("00020400-0000-0000-C000-000000000046") \
    IDispatchWeak : public IUnknownWeak \
    { \
    public: \
        virtual HRESULT STDMETHODCALLTYPE GetTypeInfoCount( \
            /* [out] */ UINT __RPC_FAR *pctinfo) = 0; \
        virtual HRESULT STDMETHODCALLTYPE GetTypeInfo( \
            /* [in] */ UINT iTInfo, \
            /* [in] */ LCID lcid, \
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo) = 0; \
        virtual HRESULT STDMETHODCALLTYPE GetIDsOfNames( \
            /* [in] */ REFIID riid, \
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames, \
            /* [in] */ UINT cNames, \
            /* [in] */ LCID lcid, \
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId) = 0; \
        virtual /* [local] */ HRESULT STDMETHODCALLTYPE Invoke( \
            /* [in] */ DISPID dispIdMember, \
            /* [in] */ REFIID riid, \
            /* [in] */ LCID lcid, \
            /* [in] */ WORD wFlags, \
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams, \
            /* [out] */ VARIANT __RPC_FAR *pVarResult, \
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo, \
            /* [out] */ UINT __RPC_FAR *puArgErr) = 0; \
    };

#if (_MSC_VER >= 1200)	// VC6 or greater
} // extern "C++"
#endif

DEFINE_DISPATCHWEAK

#define BEGIN_COM_MAP_WEAK(x) public: \
	HRESULT _WeakInternalQueryInterface (REFIID iid, void** ppvObject) \
	{ return InternalQueryInterface(this, _GetEntriesWeak(), iid, ppvObject); } \
	const static _ATL_INTMAP_ENTRY* WINAPI _GetEntriesWeak() { \
	static const _ATL_INTMAP_ENTRY _entriesweak[] = { DEBUG_QI_ENTRY(x)

#ifdef _ATL_DEBUG
#define END_COM_MAP_WEAK {NULL, 0, 0}}; return &_entriesweak[1];} \
	STDMETHOD(WeakQueryInterface)(REFIID, void**) = 0;
#else
#define END_COM_MAP_WEAK {NULL, 0, 0}}; return _entriesweak;} \
	STDMETHOD(WeakQueryInterface)(REFIID, void**) = 0;
#endif // _ATL_DEBUG

#define DECLARE_NOT_AGGREGATABLE_SI(x) public:\
	typedef CComCreator2< CComCreator< CComObjectSI< x > >, CComFailCreator<CLASS_E_NOAGGREGATION> > _CreatorClass;

class CComObjectRootBaseSI : public CComObjectRootBase
{
public:
	CComObjectRootBaseSI () {
		m_dwWeakRef	= 0L;
	}
	long m_dwWeakRef;
};

template <class ThreadModel>
class CComObjectRootSI : public CComObjectRootBaseSI
{
public:
	typedef ThreadModel _ThreadModel;
	typedef _ThreadModel::AutoCriticalSection _CritSec;
	typedef CComObjectLockT<_ThreadModel> ObjectLock;

	ULONG InternalAddRef()
	{
		ATLASSERT(m_dwRef != -1L);
		return _ThreadModel::Increment(&m_dwRef);
	}
	ULONG InternalRelease()
	{
		ATLASSERT(m_dwRef > 0);
		return _ThreadModel::Decrement(&m_dwRef);
	}

	ULONG InternalWeakAddRef()
	{
		ATLASSERT(m_dwRef != -1L);
		return _ThreadModel::Increment(&m_dwWeakRef);
	}
	ULONG InternalWeakRelease()
	{
		ATLASSERT(m_dwRef > 0);
		return _ThreadModel::Decrement(&m_dwWeakRef);
	}

	void Lock() {m_critsec.Lock();}
	void Unlock() {m_critsec.Unlock();}
private:
	_CritSec m_critsec;
};

template <>
class CComObjectRootSI<CComSingleThreadModel> : public CComObjectRootBaseSI
{
public:
	typedef CComSingleThreadModel _ThreadModel;
	typedef _ThreadModel::AutoCriticalSection _CritSec;
	typedef CComObjectLockT<_ThreadModel> ObjectLock;

	ULONG InternalAddRef()
	{
		ATLASSERT(m_dwRef != -1L);
		return _ThreadModel::Increment(&m_dwRef);
	}
	ULONG InternalRelease()
	{
		return _ThreadModel::Decrement(&m_dwRef);
	}

	ULONG InternalWeakAddRef()
	{
		ATLASSERT(m_dwWeakRef != -1L);
		return _ThreadModel::Increment(&m_dwWeakRef);
	}
	ULONG InternalWeakRelease()
	{
		ATLASSERT(m_dwWeakRef > 0);
		return _ThreadModel::Decrement(&m_dwWeakRef);
	}

	void Lock() {}
	void Unlock() {}
};

template <class Base>
class CComObjectSI : public Base
{
public:
	typedef Base _BaseClass;
	CComObjectSI(void* = NULL)
	{
		_Module.Lock();
	}
	// Set refcount to 1 to protect destruction
	~CComObjectSI()
	{
#ifdef _ATL_DEBUG_INTERFACES
		_Module.DeleteNonAddRefThunk(_GetRawUnknown());
#endif
		_Module.Unlock();
	}
	void BeginDestroy (void) {
		FinalRelease ();
	}
	//If InternalAddRef or InternalRelease is undefined then your class
	//doesn't derive from CComObjectRoot
	STDMETHOD_(ULONG, AddRef)() {return InternalAddRef();}
	STDMETHOD_(ULONG, Release)()
	{
		ULONG l = InternalRelease();
		if (l == 0) {
			WeakAddRef ();
			BeginDestroy ();
			WeakRelease ();
		}
		return l;
	}
	//if _InternalQueryInterface is undefined then you forgot BEGIN_COM_MAP
	STDMETHOD(QueryInterface)(REFIID iid, void ** ppvObject)
	{return _InternalQueryInterface(iid, ppvObject);}
	template <class Q>
	HRESULT STDMETHODCALLTYPE QueryInterface(Q** pp)
	{
		return QueryInterface(__uuidof(Q), (void**)pp);
	}
	STDMETHOD(WeakQueryInterface)(REFIID iid, void ** ppvObject)
	{return _WeakInternalQueryInterface(iid, ppvObject);}

	STDMETHOD_(ULONG, WeakAddRef)() {return InternalWeakAddRef();}
	STDMETHOD_(ULONG, WeakRelease)()
	{
		ULONG l = InternalWeakRelease();
		if (l == 0 && m_dwRef == 0)
			delete this;
		return l;
	}
	static HRESULT WINAPI CreateInstance(CComObjectSI<Base>** pp);
};

template <class Base>
HRESULT WINAPI CComObjectSI<Base>::CreateInstance(CComObjectSI<Base>** pp)
{
	ATLASSERT(pp != NULL);
	HRESULT hRes = E_OUTOFMEMORY;
	CComObject<Base>* p = NULL;
	ATLTRY(p = new CComObjectSI<Base>())
	if (p != NULL)
	{
		p->SetVoid(NULL);
		p->InternalFinalConstructAddRef();
		hRes = p->FinalConstruct();
		p->InternalFinalConstructRelease();
		if (hRes != S_OK)
		{
			delete p;
			p = NULL;
		}
	}
	*pp = p;
	return hRes;
}

#endif
