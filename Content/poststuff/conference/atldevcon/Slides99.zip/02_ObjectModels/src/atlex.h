#ifndef __ATL_EX_
#define __ATL_EX_

#define DEFINE_CFSINGLETONEX(n) \
template <class T> \
class CComClassFactorySingletonEx##n : public CComClassFactory \
{ \
public: \
	void FinalRelease() \
	{ \
		CoDisconnectObject(m_Obj.GetUnknown(), 0); \
	} \
	STDMETHOD(CreateInstance)(LPUNKNOWN pUnkOuter, REFIID riid, void** ppvObj) \
	{ \
		HRESULT hRes = E_POINTER; \
		if (ppvObj != NULL) \
		{ \
			*ppvObj = NULL; \
			ATLASSERT(pUnkOuter == NULL); \
			if (pUnkOuter != NULL) \
				hRes = CLASS_E_NOAGGREGATION; \
			else \
			{ \
				if (m_Obj.m_hResFinalConstruct != S_OK) \
					hRes = m_Obj.m_hResFinalConstruct; \
				else \
					hRes = m_Obj.QueryInterface(riid, ppvObj); \
			} \
		} \
		return hRes; \
	} \
	CComObjectGlobalID##n <T> m_Obj; \
};

#define DECLARE_CLASSFACTORY_SINGLETON_EX(obj, n) \
	DECLARE_CLASSFACTORY_EX(CComClassFactorySingletonEx##n <obj>)

DEFINE_CFSINGLETONEX (1)
DEFINE_CFSINGLETONEX (2)
DEFINE_CFSINGLETONEX (3)
DEFINE_CFSINGLETONEX (4)

#endif
