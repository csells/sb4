//	Hugh Brown
//	BROWN_HUGH@hotmail.com
//	Presented at ATL DevCon
//	Portland, 25 Jun 1999

// FileData.h: Definition of the FileData class
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FILEDATA_H__527328B3_B3FE_11D2_B296_0000C08D84ED__INCLUDED_)
#define AFX_FILEDATA_H__527328B3_B3FE_11D2_B296_0000C08D84ED__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// FileData

class FileData : 
	public IDispatchImpl<IFileData, &IID_IFileData, &LIBID_RETDATALib>, 
	public ISupportErrorInfo,
	public CComObjectRoot,
	public CComCoClass<FileData,&CLSID_FileData>
{
public:
	FileData() {}
BEGIN_COM_MAP(FileData)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IFileData)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()
//DECLARE_NOT_AGGREGATABLE(FileData) 
// Remove the comment from the line above if you don't want your object to 
// support aggregation. 

DECLARE_REGISTRY_RESOURCEID(IDR_FileData)
// ISupportsErrorInfo
public:
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

public:
	STDMETHOD(get_Checksum)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_Length)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_Start)(/*[out, retval]*/ long *pVal);

// IFileData
public:
	FDS m_fds;
	void InitFDS (const FDS& fd)
	{
		m_fds = fd;
	}
};

#endif // !defined(AFX_FILEDATA_H__527328B3_B3FE_11D2_B296_0000C08D84ED__INCLUDED_)
