//	Hugh Brown
//	BROWN_HUGH@hotmail.com
//	Presented at ATL DevCon
//	Portland, 25 Jun 1999

// data.h : Declaration of the Cdata

#ifndef __DATA_H_
#define __DATA_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// Cdata
class ATL_NO_VTABLE Cdata : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<Cdata, &CLSID_data>,
	public IDispatchImpl<Idata, &IID_Idata, &LIBID_RETDATALib>
{
public:
	Cdata()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_DATA)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(Cdata)
	COM_INTERFACE_ENTRY(Idata)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// Idata
public:
	STDMETHOD(get_ADO)(/*[out, retval]*/ IDispatch* *pVal);
	STDMETHOD(Close)();
	STDMETHOD(Open)(/*[in]*/ BSTR filename);
	
	STDMETHOD(get__NewEnum)(/*[out, retval]*/ IUnknown** prop);
	STDMETHOD(get_Count)(/*[out, retval]*/ long* prop);
	STDMETHOD(Item)(/*[in]*/ LONG Index, /*[out, retval]*/ IDispatch** prop);

	STDMETHOD(get_SafeArray) (/*[out, retval]*/ VARIANT *arr);

private:
	vector<FDS> m_data;

};

#endif //__DATA_H_
