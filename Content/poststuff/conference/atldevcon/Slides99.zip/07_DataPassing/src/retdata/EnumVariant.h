//	Hugh Brown
//	BROWN_HUGH@hotmail.com
//	Presented at ATL DevCon
//	Portland, 25 Jun 1999

// EnumVariant.h: Definition of the EnumVariant class
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ENUMVARIANT_H__06C17D6A_B420_11D2_B296_0000C08D84ED__INCLUDED_)
#define AFX_ENUMVARIANT_H__06C17D6A_B420_11D2_B296_0000C08D84ED__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// EnumVariant
#if 1
class CEnumVariant : 
	public IDispatchImpl<IEnumVariant, &IID_IEnumVariant, &LIBID_RETDATALib>, 
	public ISupportErrorInfo,
	public CComObjectRoot,
	public CComCoClass<CEnumVariant,&CLSID_EnumVariant>
{
public:
	CEnumVariant(): m_lLBound(0L), m_lCurrent(0L), m_cElements(0L) {}
BEGIN_COM_MAP(CEnumVariant)
	COM_INTERFACE_ENTRY(IEnumVariant)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()
//DECLARE_NOT_AGGREGATABLE(EnumVariant) 
// Remove the comment from the line above if you don't want your object to 
// support aggregation. 

DECLARE_REGISTRY_RESOURCEID(IDR_EnumVariant)
// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

private:
	vector<FDS> m_fds;
public:
	void Init (const vector<FDS>& fds)
	{
		m_fds = fds;
		m_cElements = m_fds.size ();
	}
	LONG m_lCurrent, m_lLBound, m_cElements;

// IEnumVariant
public:
	STDMETHOD(Next)(/*[in]*/ ULONG celt,
            /* [length_is][size_is][out] */ VARIANT *rgVar,
            /* [out] */ ULONG *pCeltFetched);
	STDMETHOD(Skip)(/* [in] */ ULONG celt);
	STDMETHOD(Reset)(void);
	STDMETHOD(Clone)(/* [out] */ IEnumVARIANT **ppEnum);
};
#endif
#endif // !defined(AFX_ENUMVARIANT_H__06C17D6A_B420_11D2_B296_0000C08D84ED__INCLUDED_)
