//	Hugh Brown
//	BROWN_HUGH@hotmail.com
//	Presented at ATL DevCon
//	Portland, 25 Jun 1999

// FileData.cpp : Implementation of CRetdataApp and DLL registration.

#include "stdafx.h"
#include "retdata.h"
#include "FileData.h"

/////////////////////////////////////////////////////////////////////////////
//

STDMETHODIMP FileData::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IFileData,
	};

	for (int i=0;i<sizeof(arr)/sizeof(arr[0]);i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP FileData::get_Start(long *pVal)
{
	// TODO: Add your implementation code here
	*pVal = m_fds.start;
	return S_OK;
}

STDMETHODIMP FileData::get_Length(long *pVal)
{
	// TODO: Add your implementation code here
	*pVal = m_fds.len;
	return S_OK;
}

STDMETHODIMP FileData::get_Checksum(long *pVal)
{
	// TODO: Add your implementation code here
	*pVal = m_fds.checksum;
	return S_OK;
}
