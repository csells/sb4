/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Fri Jul 02 10:14:44 1999
 */
/* Compiler settings for C:\xxx\Presentations\code\retdata\retdata.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __retdata_h__
#define __retdata_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __Idata_FWD_DEFINED__
#define __Idata_FWD_DEFINED__
typedef interface Idata Idata;
#endif 	/* __Idata_FWD_DEFINED__ */


#ifndef __IFileData_FWD_DEFINED__
#define __IFileData_FWD_DEFINED__
typedef interface IFileData IFileData;
#endif 	/* __IFileData_FWD_DEFINED__ */


#ifndef __IEnumVariant_FWD_DEFINED__
#define __IEnumVariant_FWD_DEFINED__
typedef interface IEnumVariant IEnumVariant;
#endif 	/* __IEnumVariant_FWD_DEFINED__ */


#ifndef __data_FWD_DEFINED__
#define __data_FWD_DEFINED__

#ifdef __cplusplus
typedef class data data;
#else
typedef struct data data;
#endif /* __cplusplus */

#endif 	/* __data_FWD_DEFINED__ */


#ifndef __FileData_FWD_DEFINED__
#define __FileData_FWD_DEFINED__

#ifdef __cplusplus
typedef class FileData FileData;
#else
typedef struct FileData FileData;
#endif /* __cplusplus */

#endif 	/* __FileData_FWD_DEFINED__ */


#ifndef __EnumVariant_FWD_DEFINED__
#define __EnumVariant_FWD_DEFINED__

#ifdef __cplusplus
typedef class EnumVariant EnumVariant;
#else
typedef struct EnumVariant EnumVariant;
#endif /* __cplusplus */

#endif 	/* __EnumVariant_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

/* interface __MIDL_itf_retdata_0000 */
/* [local] */ 






extern RPC_IF_HANDLE __MIDL_itf_retdata_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_retdata_0000_v0_0_s_ifspec;

#ifndef __Idata_INTERFACE_DEFINED__
#define __Idata_INTERFACE_DEFINED__

/* interface Idata */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_Idata;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("527328AF-B3FE-11D2-B296-0000C08D84ED")
    Idata : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Open( 
            /* [in] */ BSTR filename) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Close( void) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get__NewEnum( 
            /* [retval][out] */ IUnknown __RPC_FAR *__RPC_FAR *prop) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_Count( 
            /* [retval][out] */ long __RPC_FAR *prop) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Item( 
            /* [in] */ LONG Index,
            /* [retval][out] */ IDispatch __RPC_FAR *__RPC_FAR *prop) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_SafeArray( 
            /* [retval][out] */ VARIANT __RPC_FAR *arr) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ADO( 
            /* [retval][out] */ IDispatch __RPC_FAR *__RPC_FAR *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IdataVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            Idata __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            Idata __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            Idata __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            Idata __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            Idata __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            Idata __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            Idata __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Open )( 
            Idata __RPC_FAR * This,
            /* [in] */ BSTR filename);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Close )( 
            Idata __RPC_FAR * This);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get__NewEnum )( 
            Idata __RPC_FAR * This,
            /* [retval][out] */ IUnknown __RPC_FAR *__RPC_FAR *prop);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Count )( 
            Idata __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *prop);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Item )( 
            Idata __RPC_FAR * This,
            /* [in] */ LONG Index,
            /* [retval][out] */ IDispatch __RPC_FAR *__RPC_FAR *prop);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SafeArray )( 
            Idata __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *arr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ADO )( 
            Idata __RPC_FAR * This,
            /* [retval][out] */ IDispatch __RPC_FAR *__RPC_FAR *pVal);
        
        END_INTERFACE
    } IdataVtbl;

    interface Idata
    {
        CONST_VTBL struct IdataVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define Idata_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define Idata_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define Idata_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define Idata_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define Idata_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define Idata_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define Idata_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define Idata_Open(This,filename)	\
    (This)->lpVtbl -> Open(This,filename)

#define Idata_Close(This)	\
    (This)->lpVtbl -> Close(This)

#define Idata_get__NewEnum(This,prop)	\
    (This)->lpVtbl -> get__NewEnum(This,prop)

#define Idata_get_Count(This,prop)	\
    (This)->lpVtbl -> get_Count(This,prop)

#define Idata_Item(This,Index,prop)	\
    (This)->lpVtbl -> Item(This,Index,prop)

#define Idata_get_SafeArray(This,arr)	\
    (This)->lpVtbl -> get_SafeArray(This,arr)

#define Idata_get_ADO(This,pVal)	\
    (This)->lpVtbl -> get_ADO(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Idata_Open_Proxy( 
    Idata __RPC_FAR * This,
    /* [in] */ BSTR filename);


void __RPC_STUB Idata_Open_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Idata_Close_Proxy( 
    Idata __RPC_FAR * This);


void __RPC_STUB Idata_Close_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE Idata_get__NewEnum_Proxy( 
    Idata __RPC_FAR * This,
    /* [retval][out] */ IUnknown __RPC_FAR *__RPC_FAR *prop);


void __RPC_STUB Idata_get__NewEnum_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE Idata_get_Count_Proxy( 
    Idata __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *prop);


void __RPC_STUB Idata_get_Count_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE Idata_Item_Proxy( 
    Idata __RPC_FAR * This,
    /* [in] */ LONG Index,
    /* [retval][out] */ IDispatch __RPC_FAR *__RPC_FAR *prop);


void __RPC_STUB Idata_Item_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE Idata_get_SafeArray_Proxy( 
    Idata __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *arr);


void __RPC_STUB Idata_get_SafeArray_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE Idata_get_ADO_Proxy( 
    Idata __RPC_FAR * This,
    /* [retval][out] */ IDispatch __RPC_FAR *__RPC_FAR *pVal);


void __RPC_STUB Idata_get_ADO_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __Idata_INTERFACE_DEFINED__ */


#ifndef __IFileData_INTERFACE_DEFINED__
#define __IFileData_INTERFACE_DEFINED__

/* interface IFileData */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IFileData;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("527328B1-B3FE-11D2-B296-0000C08D84ED")
    IFileData : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Start( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Length( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Checksum( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IFileDataVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IFileData __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IFileData __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IFileData __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IFileData __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IFileData __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IFileData __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IFileData __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Start )( 
            IFileData __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Length )( 
            IFileData __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Checksum )( 
            IFileData __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        END_INTERFACE
    } IFileDataVtbl;

    interface IFileData
    {
        CONST_VTBL struct IFileDataVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IFileData_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IFileData_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IFileData_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IFileData_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IFileData_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IFileData_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IFileData_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IFileData_get_Start(This,pVal)	\
    (This)->lpVtbl -> get_Start(This,pVal)

#define IFileData_get_Length(This,pVal)	\
    (This)->lpVtbl -> get_Length(This,pVal)

#define IFileData_get_Checksum(This,pVal)	\
    (This)->lpVtbl -> get_Checksum(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IFileData_get_Start_Proxy( 
    IFileData __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IFileData_get_Start_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IFileData_get_Length_Proxy( 
    IFileData __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IFileData_get_Length_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IFileData_get_Checksum_Proxy( 
    IFileData __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IFileData_get_Checksum_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IFileData_INTERFACE_DEFINED__ */


#ifndef __IEnumVariant_INTERFACE_DEFINED__
#define __IEnumVariant_INTERFACE_DEFINED__

/* interface IEnumVariant */
/* [unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_IEnumVariant;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("06C17D68-B420-11D2-B296-0000C08D84ED")
    IEnumVariant : public IUnknown
    {
    public:
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Next( 
            ULONG celt,
            VARIANT __RPC_FAR *rgVar,
            ULONG __RPC_FAR *pCeltFetched) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Skip( 
            /* [in] */ ULONG celt) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Reset( void) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Clone( 
            /* [out] */ IEnumVARIANT __RPC_FAR *__RPC_FAR *ppEnum) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IEnumVariantVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IEnumVariant __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IEnumVariant __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IEnumVariant __RPC_FAR * This);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Next )( 
            IEnumVariant __RPC_FAR * This,
            ULONG celt,
            VARIANT __RPC_FAR *rgVar,
            ULONG __RPC_FAR *pCeltFetched);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Skip )( 
            IEnumVariant __RPC_FAR * This,
            /* [in] */ ULONG celt);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Reset )( 
            IEnumVariant __RPC_FAR * This);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Clone )( 
            IEnumVariant __RPC_FAR * This,
            /* [out] */ IEnumVARIANT __RPC_FAR *__RPC_FAR *ppEnum);
        
        END_INTERFACE
    } IEnumVariantVtbl;

    interface IEnumVariant
    {
        CONST_VTBL struct IEnumVariantVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IEnumVariant_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IEnumVariant_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IEnumVariant_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IEnumVariant_Next(This,celt,rgVar,pCeltFetched)	\
    (This)->lpVtbl -> Next(This,celt,rgVar,pCeltFetched)

#define IEnumVariant_Skip(This,celt)	\
    (This)->lpVtbl -> Skip(This,celt)

#define IEnumVariant_Reset(This)	\
    (This)->lpVtbl -> Reset(This)

#define IEnumVariant_Clone(This,ppEnum)	\
    (This)->lpVtbl -> Clone(This,ppEnum)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [id] */ HRESULT STDMETHODCALLTYPE IEnumVariant_Next_Proxy( 
    IEnumVariant __RPC_FAR * This,
    ULONG celt,
    VARIANT __RPC_FAR *rgVar,
    ULONG __RPC_FAR *pCeltFetched);


void __RPC_STUB IEnumVariant_Next_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IEnumVariant_Skip_Proxy( 
    IEnumVariant __RPC_FAR * This,
    /* [in] */ ULONG celt);


void __RPC_STUB IEnumVariant_Skip_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IEnumVariant_Reset_Proxy( 
    IEnumVariant __RPC_FAR * This);


void __RPC_STUB IEnumVariant_Reset_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IEnumVariant_Clone_Proxy( 
    IEnumVariant __RPC_FAR * This,
    /* [out] */ IEnumVARIANT __RPC_FAR *__RPC_FAR *ppEnum);


void __RPC_STUB IEnumVariant_Clone_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IEnumVariant_INTERFACE_DEFINED__ */



#ifndef __RETDATALib_LIBRARY_DEFINED__
#define __RETDATALib_LIBRARY_DEFINED__

/* library RETDATALib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_RETDATALib;

EXTERN_C const CLSID CLSID_data;

#ifdef __cplusplus

class DECLSPEC_UUID("527328B0-B3FE-11D2-B296-0000C08D84ED")
data;
#endif

EXTERN_C const CLSID CLSID_FileData;

#ifdef __cplusplus

class DECLSPEC_UUID("527328B2-B3FE-11D2-B296-0000C08D84ED")
FileData;
#endif

EXTERN_C const CLSID CLSID_EnumVariant;

#ifdef __cplusplus

class DECLSPEC_UUID("06C17D69-B420-11D2-B296-0000C08D84ED")
EnumVariant;
#endif
#endif /* __RETDATALib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

unsigned long             __RPC_USER  VARIANT_UserSize(     unsigned long __RPC_FAR *, unsigned long            , VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
void                      __RPC_USER  VARIANT_UserFree(     unsigned long __RPC_FAR *, VARIANT __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
