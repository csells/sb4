//	Hugh Brown
//	BROWN_HUGH@hotmail.com
//	Presented at ATL DevCon
//	Portland, 25 Jun 1999

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by retdata.rc
//
#define IDS_PROJNAME                    100
#define IDR_DATA                        101
#define IDS_FILEDATA_DESC               102
#define IDR_FileData                    103
#define IDS_ENUMVARIANT_DESC            104
#define IDR_EnumVariant                 105

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
