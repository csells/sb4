//	Hugh Brown
//	BROWN_HUGH@hotmail.com
//	Presented at ATL DevCon
//	Portland, 25 Jun 1999

// EnumVariant.cpp : Implementation of CRetdataApp and DLL registration.

#include "stdafx.h"
#include "retdata.h"
#include "FileData.h"

#include "EnumVariant.h"

/////////////////////////////////////////////////////////////////////////////
//
#if 1
STDMETHODIMP CEnumVariant::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IEnumVariant,
	};

	for (int i=0;i<sizeof(arr)/sizeof(arr[0]);i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CEnumVariant::Next(/*[in]*/ ULONG celt,
            /* [length_is][size_is][out] */ VARIANT *pvar,
            /* [out] */ ULONG *pCeltFetched)
{
    HRESULT hr; 
    ULONG l; 
    long l1; 
    ULONG l2; 
     
    if (pCeltFetched != NULL) 
        *pCeltFetched = 0; 
         
    // Retrieve the next cElements elements. 
	LONG m_cElements= m_fds.size();
    for (l1=m_lCurrent, l2=0; l1<(long)(m_lLBound+m_cElements) && l2<celt; l1++, l2++) 
    {
		IDispatch *disp = NULL;
		CComObject<FileData> *obj = NULL;
		hr = CComObject<FileData>::CreateInstance (&obj);
		if (SUCCEEDED(hr))
		{
			FDS fd;
			fd = m_fds.at (m_lCurrent);
			obj->InitFDS (fd);
			hr = obj->QueryInterface (IID_IDispatch, reinterpret_cast<void **>(&disp));

			VARIANT v;
			::VariantInit (&v);
			V_VT(&v) = VT_DISPATCH;
			V_DISPATCH(&v) = disp;

			pvar[l2] = v;
		}

		if (FAILED(hr)) 
			goto error;  
    } 
    // Set count of elements retrieved 
    if (pCeltFetched != NULL) 
        *pCeltFetched = l2; 
    m_lCurrent = l1; 
     
    return (l2 < celt) ? S_FALSE : NOERROR; 
 
error: 
    for (l=0; l<celt; l++) 
        VariantClear(&pvar[l]); 
    return hr;     
}

STDMETHODIMP CEnumVariant::Skip (/* [in] */ ULONG celt)
{
	HRESULT hr;
    m_lCurrent += celt;  
    if (m_lCurrent > (long)(m_lLBound+m_cElements)) 
    { 
        m_lCurrent =  m_lLBound+m_cElements; 
        hr = S_FALSE; 
    }  
    else
		hr = S_OK;
	return hr; 
}
STDMETHODIMP CEnumVariant::Reset(void)
{
	m_lCurrent = 0;
	return S_OK;
}
STDMETHODIMP CEnumVariant::Clone(/* [out] */ IEnumVARIANT **ppEnum)
{
	return E_NOTIMPL;
}

#endif