//	Hugh Brown
//	BROWN_HUGH@hotmail.com
//	Presented at ATL DevCon
//	Portland, 25 Jun 1999

// data.cpp : Implementation of Cdata
#include "stdafx.h"
#include "Retdata.h"
#include "data.h"
#include "FileData.h"
#include "EnumVariant.h"

/////////////////////////////////////////////////////////////////////////////
// Cdata

STDMETHODIMP Cdata::Open(BSTR filename)
{
	HRESULT hr = S_OK;
	USES_CONVERSION;
	char *cp = W2A(filename);
	FILE *fp = fopen (cp, "rb");
	if (NULL != fp)
	{
		char buf[512];
		FDS fd;
		fd.start = 0;
		fd.checksum = 0xDEADBEEFL;
		while (NULL != fgets (buf, sizeof(buf), fp))
		{
			fd.len = strlen (buf);
			m_data.push_back(fd);
			fd.start = ftell (fp);
		}
		fclose (fp);
	}
	else
		hr = E_FAIL;
	return hr;
}

STDMETHODIMP Cdata::Close()
{
	m_data.clear ();
	return S_OK;
}

STDMETHODIMP Cdata::get__NewEnum(/*[out, retval]*/ IUnknown** prop)
{
#if 0
	return E_NOTIMPL;
#else
	*prop = NULL;
	CComObject<CEnumVariant> *pNewEnum = NULL;
	HRESULT hr = CComObject<CEnumVariant>::CreateInstance (&pNewEnum);
	if (SUCCEEDED(hr))
	{
		pNewEnum->Init (m_data);
		hr = pNewEnum->QueryInterface (IID_IUnknown, reinterpret_cast<void **>(prop));
	}
	else
		delete pNewEnum;
	return hr;
#endif
}
STDMETHODIMP Cdata::get_Count(/*[out, retval]*/ long* prop)
{
	*prop = m_data.size ();
	return S_OK;
}
STDMETHODIMP Cdata::Item (/*[in]*/ LONG index, /*[out, retval]*/ IDispatch** prop)
{
	HRESULT hr = S_OK;
	*prop = NULL;
	//index--;		//	1-based index
	if (index > m_data.size () || index < 0)
		hr = E_FAIL;
	else
	{
		CComObject<FileData> *obj = NULL;
		hr = CComObject<FileData>::CreateInstance (&obj);
		if (SUCCEEDED(hr))
		{
			FDS fd;
			fd = m_data.at (index);
			obj->InitFDS (fd);
			hr = obj->QueryInterface (IID_IDispatch, reinterpret_cast<void **>(prop));
		}
	}
	return hr;
}

STDMETHODIMP Cdata::get_SafeArray (/*[out, retval]*/ VARIANT *arr)
{
	HRESULT hr = S_OK;
	const unsigned int cDims = 2;
	SAFEARRAYBOUND rgsaBound[cDims];
	rgsaBound[0].cElements = m_data.size ();
	rgsaBound[0].lLbound = 0;
	rgsaBound[1].cElements = 3;
	rgsaBound[1].lLbound = 0;

	const VARTYPE vt = VT_VARIANT;
	SAFEARRAY *sa = ::SafeArrayCreate (vt, cDims, rgsaBound);
	sa->fFeatures = (FADF_VARIANT | FADF_FIXEDSIZE | FADF_EMBEDDED);
	if (NULL != sa)
	{
		VARIANT tmp;
		::VariantInit (&tmp);
		V_VT(&tmp) = VT_I4;

		LONG index[2];
		const LONG j = m_data.size();
		for (int i = 0; i < j; i++)
		{
			index[0] = i;
			const FDS fds = m_data.at(i);
			//ATLTRACE(_T("%d %ld %ld %lx\n"), i, fds.start, fds.len, fds.checksum);
			V_I4(&tmp) = fds.start;
			index[1] = 0;
			hr = ::SafeArrayPutElement (sa, index, &tmp);
			_ASSERTE(S_OK == hr);

			V_I4(&tmp) = fds.len;
			index[1] = 1;
			hr = ::SafeArrayPutElement (sa, index, &tmp);
			_ASSERTE(S_OK == hr);

			V_I4(&tmp) = fds.checksum;
			index[1] = 2;
			hr = ::SafeArrayPutElement (sa, index, &tmp);
			_ASSERTE(S_OK == hr);
		}

		::VariantInit(arr);
		V_VT(arr) = VT_ARRAY | vt;
		V_ARRAY(arr) = sa;
	}
	else
		hr = E_OUTOFMEMORY;
	return hr;
}


#import "c:/progra~1/common~1/system/ado/MSADO15.DLL" named_guids no_namespace rename("EOF", "ADOEOF")

STDMETHODIMP Cdata::get_ADO(IDispatch **pVal)
{
	HRESULT hr = S_OK;
	*pVal = NULL;
	try
	{
		_RecordsetPtr pRecord;
		hr = pRecord.CreateInstance (CLSID_Recordset);
		if (SUCCEEDED(hr))
		{
			const _bstr_t start("Start");
			const _bstr_t len("Len");
			const _bstr_t checksum("CheckSum");

			pRecord->CursorLocation = adUseClientBatch;
			FieldsPtr f = pRecord->Fields;
			hr = f->Append (start, adInteger, sizeof(long), adFldFixed);
			hr = f->Append (len, adInteger, sizeof(long), adFldFixed);
			hr = f->Append (checksum, adInteger, sizeof(long), adFldFixed);

			_variant_t nothing, noConnection;
			nothing = vtMissing;
			noConnection = vtMissing;

			const CursorTypeEnum cursorType = adOpenUnspecified; // adOpenForwardOnly;
			const LockTypeEnum lockType = adLockUnspecified; // adLockReadOnly;
			long options = adCmdUnspecified;

			pRecord->CursorLocation = adUseClient;
			hr = pRecord->Open (nothing, noConnection, cursorType, lockType, options);

			const LONG j = m_data.size();
			for (int i = 0; i < j; i++)
			{
				const FDS fds = m_data.at(i);
				pRecord->AddNew (start, fds.start);
			}
			
			hr = pRecord->QueryInterface (IID_IDispatch, (void **)(pVal));
		}
	}
	catch (_com_error& e)
	{
		_bstr_t s = e.Source ();
		_bstr_t d = e.Description ();
		::MessageBox (NULL, (char *) d, (char *) s, MB_OK);
		hr = e.Error();
	}

	return hr;
}
