//	Hugh Brown
//	BROWN_HUGH@hotmail.com
//	Presented at ATL DevCon
//	Portland, 25 Jun 1999

// Test.cpp : Implementation of CTest
#include "stdafx.h"
#include "RecordTest.h"
#include "Test.h"

#include <vector>
using namespace std;

/////////////////////////////////////////////////////////////////////////////
// CTest

STDMETHODIMP CTest::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ITest
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

#include "CopyVectorToSafeArray.h"

STDMETHODIMP CTest::GetUDT(VARIANT *pVal)
{
	HRESULT hr = S_OK;
	if (0 == pVal)
		hr = E_POINTER;
	else
	{
		GUID guid = {0xF00758F0, 0x2966, 0x11d3, {0x88, 0xDF, 0x00, 0xC0, 0x4F, 0x4F, 0xEA, 0x70}};
		
		vector<XX> xxVector;
		for (int i = 0; i < 10; i++)
		{
			XX x;
			x.l = i;
			x.n = 11 * i;
			xxVector.push_back(x);
		}
		
		hr = CopyVectorToSafeArray<XX> (LIBID_RECORDTESTLib,
											guid,
											xxVector,
											pVal);
	}
	return hr;
}
