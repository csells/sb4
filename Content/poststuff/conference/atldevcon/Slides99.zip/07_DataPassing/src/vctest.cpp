//	Hugh Brown
//	BROWN_HUGH@hotmail.com
//	Presented at ATL DevCon
//	Portland, 25 Jun 1999

// vctest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <comdef.h>
#include <comutil.h>

#import "c:/temp/retdata/retdata.tlb" named_guids no_namespace
#import "c:/progra~1/common~1/system/ado/MSADO15.DLL" named_guids no_namespace rename("EOF", "ADOEOF")

HRESULT test_ADO (IdataPtr obj)
{
	HRESULT hr = S_OK;
	const DWORD dwStart = ::GetTickCount ();

	try
	{
		IDispatchPtr idisp = obj->ADO;
		idisp = NULL;
		_RecordsetPtr pRecord;
		hr = idisp->QueryInterface (IID__Recordset, (void **) &pRecord);
		idisp = NULL;
		if (SUCCEEDED(hr))
		{
			hr = pRecord->MoveFirst ();
			if (SUCCEEDED(hr))
			{
				FieldsPtr f = pRecord->Fields;
				while (VARIANT_FALSE == pRecord->ADOEOF)
				{
					long start, checksum, len;
					_variant_t value;
					hr = f->GetItem (0L)->get_Value(&value);
					start = value;
					hr = f->GetItem (1L)->get_Value(&value);
					len = value;
					hr = f->GetItem (2L)->get_Value(&value);
					checksum = value;

					hr = pRecord->MoveNext ();
				}
				f = NULL;
			}
		}
		pRecord = NULL;
	}
	catch (_com_error& e)
	{
		_bstr_t s = e.Source ();
		_bstr_t d = e.Description ();
		::MessageBox (NULL, (char *) d, (char *) s, MB_OK);
		hr = e.Error();
	}
	const DWORD dwEnd = ::GetTickCount ();
	const DWORD dwElapsed = dwEnd - dwStart;
	printf ("ADO:  %ld.%03ld\n", dwElapsed / 1000, dwElapsed % 1000);

	return hr;
}

HRESULT test_collection (IdataPtr obj)
{
	HRESULT hr = S_OK;
	const DWORD dwStart = ::GetTickCount ();

	try
	{
		LONG count;
		hr = obj->get_Count (&count);
		if (SUCCEEDED(hr))
		{
			for (long i = 0; i < count; i++)
			{
				IDispatchPtr idisp = obj->Item(i);
				IFileDataPtr filedata = NULL;
				hr = idisp->QueryInterface (IID_IFileData, (void **) &filedata);
				idisp = NULL;

				if (SUCCEEDED(hr))
				{
					const long s = filedata->GetStart ();
					const long l = filedata->GetLength ();
					const long c = filedata->GetChecksum ();
					//printf ("%ld %ld %lx\n", s, l, c);
				}
				filedata = NULL;
			}
		}
	}
	catch (_com_error& e)
	{
		_bstr_t s = e.Source ();
		_bstr_t d = e.Description ();
		::MessageBox (NULL, (char *) d, (char *) s, MB_OK);
		hr = e.Error();
	}
	
	const DWORD dwEnd = ::GetTickCount ();
	const DWORD dwElapsed = dwEnd - dwStart;
	printf ("collection:  %ld.%03ld\n", dwElapsed / 1000, dwElapsed % 1000);
	return hr;
}

HRESULT test_enumeration (IdataPtr obj)
{
	HRESULT hr = S_OK;
	const DWORD dwStart = ::GetTickCount ();

	try
	{
		IUnknownPtr pUnk = obj->Get_NewEnum ();
		IEnumVariantPtr pEnumVARIANT = NULL;
		hr = pUnk->QueryInterface (IID_IEnumVariant, (void **) &pEnumVARIANT);
		if (SUCCEEDED(hr))
		{
			VARIANT v;
			::VariantInit (&v);
			ULONG actual;
			while (S_OK == pEnumVARIANT->Next (1L, &v, &actual))
			{
				IDispatchPtr idisp = v.pdispVal;

				IFileDataPtr filedata;
				hr = idisp->QueryInterface (IID_IFileData, (void **) &filedata);

				const long s = filedata->GetStart ();
				const long l = filedata->GetLength ();
				const c = filedata->GetChecksum ();
				//printf ("%ld %ld %lx\n", s, l, c);
				filedata = NULL;

				::VariantClear (&v);
			}
		}
	}
	catch (_com_error& e)
	{
		_bstr_t s = e.Source ();
		_bstr_t d = e.Description ();
		::MessageBox (NULL, (char *) d, (char *) s, MB_OK);
		hr = e.Error();
	}
	
	const DWORD dwEnd = ::GetTickCount ();
	const DWORD dwElapsed = dwEnd - dwStart;
	printf ("enumeration:  %ld.%03ld\n", dwElapsed / 1000, dwElapsed % 1000);
	return hr;
}

HRESULT test_array (IdataPtr obj)
{
	const DWORD dwStart = ::GetTickCount ();
	VARIANT var;
	::VariantInit (&var);
	HRESULT hr = obj->get_SafeArray (&var);
	
	SAFEARRAY *sa = var.parray;
	LONG cDims = ::SafeArrayGetDim (sa);
	LONG lLbound1, lUbound1;
	hr = ::SafeArrayGetLBound (sa, 1, &lLbound1);
	hr = ::SafeArrayGetUBound (sa, 1, &lUbound1);

	LONG lLbound2, lUbound2;
	hr = ::SafeArrayGetLBound (sa, 2, &lLbound2);
	hr = ::SafeArrayGetUBound (sa, 2, &lUbound2);

	LONG *index = NULL;
	index = new LONG [cDims];
	for (LONG i = lLbound1; i <= lUbound1; i++)
	{
		index[0] = i;
		for (LONG j = lLbound2; j <= lUbound2; j++)
		{
			VARIANT element;
			index[1] = j;
			hr = ::SafeArrayGetElement (sa, index, (void *) &element);

			//printf ("(%d,%d) = %ld\n", i, j, element.lVal);
		}
	}
	delete [] index;

	::VariantClear (&var);

	const DWORD dwEnd = ::GetTickCount ();
	const DWORD dwElapsed = dwEnd - dwStart;
	printf ("Array:  %ld.%03ld\n", dwElapsed / 1000, dwElapsed % 1000);
	return hr;
}

int main(int argc, char* argv[])
{
	HRESULT hr = ::CoInitialize (NULL);
	if (SUCCEEDED(hr))
	{
		try
		{
			IdataPtr obj = NULL;
			obj.CreateInstance (CLSID_data);
			//const _bstr_t file = "d:\\etc\\words.txt"; // "c:\\temp\\retdata\\data.cpp";
			const _bstr_t file = "D:\\Program Files\\Microsoft Visual Studio\\redist.txt";
			hr = obj->Open (file);

			hr = test_enumeration (obj);
			hr = test_array (obj);
			hr = test_collection (obj);
			hr = test_ADO (obj);

			hr = obj->Close ();
			obj = NULL;
		}
		catch (_com_error& e)
		{
			_bstr_t s = e.Source ();
			_bstr_t d = e.Description ();
			::MessageBox (NULL, (char *) s, (char *) d, MB_OK);
		}

		::CoUninitialize ();
	}
	return 0;
}

