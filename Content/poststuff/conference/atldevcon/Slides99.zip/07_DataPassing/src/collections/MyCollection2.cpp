//	Hugh Brown
//	BROWN_HUGH@hotmail.com
//	Presented at ATL DevCon
//	Portland, 25 Jun 1999

// MyCollection2.cpp : Implementation of CMyCollection2
#include "stdafx.h"
#include "Collections.h"
#include "MyCollection2.h"

/////////////////////////////////////////////////////////////////////////////
// CMyCollection2

STDMETHODIMP CMyCollection2::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IMyCollection2
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

#include "../CopyRecordToVariant.h"

static struct __declspec(uuid("B0D99C63-2672-11d3-B2E5-0000C08D84ED")) {} FileDesc_Dummy;

static HRESULT convert (/* out */ VARIANT *pValue, /* in */ const FileDesc& elem)
{
	HRESULT hr = CopyRecordToVariant<FileDesc> (
		LIBID_COLLECTIONSLib,
		__uuidof(FileDesc_Dummy),
		&elem,
		pValue);
	return hr;
}

//	Fill the collection with the values
HRESULT CMyCollection2::FinalConstruct ()
{
	HRESULT hr = S_OK;
	FILE *fp = fopen ("c:\\b", "r");
	if (NULL != fp)
	{
		char buf[512];
		while (fgets (buf, sizeof(buf), fp))
		{
			FileDesc dst;
			CComBSTR tmp;
			char *start, *end;
			start = buf;

			end = strchr (start, ',');
			*end = '\0';
			tmp = start;
			dst.fileName = tmp.Detach();

			start = end + 1;
			end = strchr (start, ',');
			*end = '\0';
			tmp = start;
			dst.filePath = tmp.Detach();

			start = end + 1;
			end = strchr (start, ',');
			*end = '\0';
			dst.fileLength = atol (start);

			start = end + 1;
			end = strchr (start, '\n');
			*end = '\0';
			dst.fileAttrib = atol (start);

			m_vecFileDesc.push_back (dst);
		}

		const long max_iter = m_vecFileDesc.size();
		for (long index = 0; index < max_iter; index++)
		{
			VARIANT v;
			hr = convert (&v, this->m_vecFileDesc[index]);
			if (FAILED(hr))
				//	Bad news
				break;
			this->m_convertedToInterfacePtr.push_back (v);
		}

		fclose (fp);
	}
	return hr;
}

//	Destroy the collection's values
void CMyCollection2::FinalRelease ()
{
	long j = m_vecFileDesc.size();
	for (long i = 0; i < j; i++)
	{
		FileDesc &fd = this->m_vecFileDesc[i];
		::SysFreeString (fd.fileName);
		::SysFreeString (fd.filePath);
		fd.fileName = NULL;
		fd.filePath = NULL;
	}
	m_vecFileDesc.clear();
	j = this->m_convertedToInterfacePtr.size();
	for (i = 0; i < j; i++)
	{
		::VariantClear(&this->m_convertedToInterfacePtr[i]);
	}
	m_convertedToInterfacePtr.clear();
}

/////////////////////////////////////////////////////////////////////////////
//	IDL methods and properties

STDMETHODIMP CMyCollection2::Item (/*[in]*/ LONG index, /*[out]*/ VARIANT *pValue)
{
	HRESULT hr = S_OK;
	if (NULL == pValue)
		hr = E_POINTER;
	else if ((0 > index) || (index >= m_vecFileDesc.size()))
		hr = E_INVALIDARG;
	else
	{
		::VariantInit (pValue);
		hr = ::VariantCopy (/* dst */pValue, 
					/* sr */ &this->m_convertedToInterfacePtr[index]);
	}
	return hr;
}

STDMETHODIMP CMyCollection2::get_Count (/*[out, retval]*/ LONG *pCount)
{
	HRESULT hr = S_OK;
	if (NULL == pCount)
		hr = E_POINTER;
	else
		*pCount = this->m_convertedToInterfacePtr.size();
	return hr;
}

#if 0
template<typename T, 	/* in */ const GUID& guidOfTypeLibrary,
	/* in */ const GUID& guidOfStruct,
>
class CopyRecord<T>
{
public:
	static HRESULT copy(VARIANT* p1, T* p2)
	{
		HRESULT hr = S_OK;
		(*p1) = (LPOLESTR)CoTaskMemAlloc(sizeof(OLECHAR)*(ocslen(*p2)+1));
		if (*p1 == NULL)
			hr = E_OUTOFMEMORY;
		else
			ocscpy(*p1,*p2);
		return hr;
	}
	static void init(LPOLESTR* p) {*p = NULL;}
	static void destroy(LPOLESTR* p) { CoTaskMemFree(*p);}
};
#endif

STDMETHODIMP CMyCollection2::get__NewEnum (/*[out, retval]*/ IUnknown **pUnknown)
{
	HRESULT hr = S_OK;
	if (NULL == pUnknown)
		hr = E_POINTER;
	else
	{
		typedef CComEnumOnSTL <
			IEnumVARIANT, &IID_IEnumVARIANT, 
			VARIANT,
			_Copy<VARIANT>, vector<VARIANT>
			> EnumVariant;

		CComObject<EnumVariant> *pEnumVariant = NULL;
		hr = CComObject<EnumVariant>::CreateInstance (&pEnumVariant);
		if (SUCCEEDED(hr))
		{
			pEnumVariant->AddRef();

			hr = pEnumVariant->Init (this->GetUnknown(), this->m_convertedToInterfacePtr);
			if (SUCCEEDED(hr))
				hr = pEnumVariant->QueryInterface (pUnknown);
			pEnumVariant->Release();
		}
	}
	return hr;
}

