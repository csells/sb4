//	Hugh Brown
//	BROWN_HUGH@hotmail.com
//	Presented at ATL DevCon
//	Portland, 25 Jun 1999

// MyCollection2.h : Declaration of the CMyCollection2

#ifndef __MYCOLLECTION2_H_
#define __MYCOLLECTION2_H_

#include "resource.h"       // main symbols
#include <vector>
using namespace std;

/////////////////////////////////////////////////////////////////////////////
// CMyCollection2
class ATL_NO_VTABLE CMyCollection2 : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CMyCollection2, &CLSID_MyCollection2>,
	public ISupportErrorInfo,
	public IDispatchImpl<IMyCollection2, &IID_IMyCollection2, &LIBID_COLLECTIONSLib>
{
public:
	CMyCollection2()
	{
	}

	HRESULT FinalConstruct ();
	void FinalRelease ();


DECLARE_REGISTRY_RESOURCEID(IDR_MYCOLLECTION2)
DECLARE_NOT_AGGREGATABLE(CMyCollection2)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CMyCollection2)
	COM_INTERFACE_ENTRY(IMyCollection2)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IMyCollection2
public:
	//	Return VT_RECORD sructure
	STDMETHOD(Item) (/*[in]*/ LONG index, /*[out]*/ VARIANT *pValue);

	STDMETHOD(get_Count) (/*[out, retval]*/ LONG *pCount);
	STDMETHOD(get__NewEnum) (/*[out, retval]*/ IUnknown **pUnknown);

private:
	std::vector<FileDesc> m_vecFileDesc;
	std::vector<VARIANT> m_convertedToInterfacePtr;
};

#endif //__MYCOLLECTION2_H_
