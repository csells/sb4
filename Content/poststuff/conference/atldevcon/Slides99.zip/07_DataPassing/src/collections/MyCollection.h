//	Hugh Brown
//	BROWN_HUGH@hotmail.com
//	Presented at ATL DevCon
//	Portland, 25 Jun 1999

// MyCollection.h : Declaration of the CMyCollection

#ifndef __MYCOLLECTION_H_
#define __MYCOLLECTION_H_

#include "resource.h"       // main symbols
#include <vector>
using namespace std;

/////////////////////////////////////////////////////////////////////////////
// CMyCollection
class ATL_NO_VTABLE CMyCollection : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CMyCollection, &CLSID_MyCollection>,
	public ISupportErrorInfo,
	public IDispatchImpl<IMyCollection, &IID_IMyCollection, &LIBID_COLLECTIONSLib>
{
public:
	CMyCollection()
	{
	}

	HRESULT FinalConstruct ();
	void FinalRelease ();

DECLARE_REGISTRY_RESOURCEID(IDR_MYCOLLECTION)
DECLARE_NOT_AGGREGATABLE(CMyCollection)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CMyCollection)
	COM_INTERFACE_ENTRY(IMyCollection)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IMyCollection
public:
	//	Return interface pointer
	STDMETHOD(Item) (/*[in]*/ LONG index, /*[out]*/ VARIANT *pValue);

	STDMETHOD(get_Count) (/*[out, retval]*/ LONG *pCount);
	STDMETHOD(get__NewEnum) (/*[out, retval]*/ IUnknown **pUnknown);

private:
	std::vector<FileDesc> m_vecFileDesc;
	std::vector<VARIANT> m_convertedToInterfacePtr;
};

#endif //__MYCOLLECTION_H_
