//	Hugh Brown
//	BROWN_HUGH@hotmail.com
//	Presented at ATL DevCon
//	Portland, 25 Jun 1999

// MyCollection.cpp : Implementation of CMyCollection
#include "stdafx.h"
#include "Collections.h"
#include "MyCollection.h"

#include "FileInfo.h"

//
//	Option Explicit
//
//	Dim obj		''	As Collections.MyCollection
//	Set obj = CreateObject ("Collections.MyCollection")
//
//	Dim i, j	''	As Integer
//	j = obj.Count - 1
//	For i = 0 to j
//		MsgBox CStr(i) & " " & CStr(obj.Item(i))
//	Next
//
//	For Each i in obj
//		MsgBox CStr(i)
//	Next
//
//	Set obj = Nothing
//

/////////////////////////////////////////////////////////////////////////////
//	InterfaceSupportsErrorInfo

STDMETHODIMP CMyCollection::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IMyCollection
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

/////////////////////////////////////////////////////////////////////////////
//	Internal methods

static HRESULT convert (/* out */ VARIANT *pValue, /* in */ const FileDesc& elem)
{
	::VariantInit (pValue);

	CComObject<CFileInfo> *x = NULL;
	HRESULT hr = CComObject<CFileInfo>::CreateInstance (&x);
	if (SUCCEEDED(hr))
	{
		x->Init (elem);
		IDispatch *pDisp = NULL;
		hr = x->QueryInterface (&pDisp);
		if (SUCCEEDED(hr))
		{
			V_DISPATCH(pValue) = pDisp;
			V_VT(pValue) = VT_DISPATCH;
			pDisp->AddRef();
		}
	}
	return hr;
}

//	Fill the collection with the values
HRESULT CMyCollection::FinalConstruct ()
{
	HRESULT hr = S_OK;
	FILE *fp = fopen ("c:\\b", "r");
	if (NULL != fp)
	{
		char buf[512];
		while (fgets (buf, sizeof(buf), fp))
		{
			FileDesc dst;
			CComBSTR tmp;
			char *start, *end;
			start = buf;

			end = strchr (start, ',');
			*end = '\0';
			tmp = start;
			dst.fileName = tmp.Detach();

			start = end + 1;
			end = strchr (start, ',');
			*end = '\0';
			tmp = start;
			dst.filePath = tmp.Detach();

			start = end + 1;
			end = strchr (start, ',');
			*end = '\0';
			dst.fileLength = atol (start);

			start = end + 1;
			end = strchr (start, '\n');
			*end = '\0';
			dst.fileAttrib = atol (start);

			m_vecFileDesc.push_back (dst);
		}

		const long max_iter = m_vecFileDesc.size();
		for (long index = 0; index < max_iter; index++)
		{
			VARIANT v;
			hr = convert (&v, this->m_vecFileDesc[index]);
			if (FAILED(hr))
				//	Bad news
				break;
			this->m_convertedToInterfacePtr.push_back (v);
		}

		fclose (fp);
	}
	return hr;
}

//	Destroy the collection's values
void CMyCollection::FinalRelease ()
{
	long j = m_vecFileDesc.size();
	for (long i = 0; i < j; i++)
	{
		FileDesc &fd = this->m_vecFileDesc[i];
		::SysFreeString (fd.fileName);
		::SysFreeString (fd.filePath);
		fd.fileName = NULL;
		fd.filePath = NULL;
	}
	m_vecFileDesc.clear();
	j = this->m_convertedToInterfacePtr.size();
	for (i = 0; i < j; i++)
	{
		::VariantClear(&this->m_convertedToInterfacePtr[i]);
	}
	m_convertedToInterfacePtr.clear ();
}

/////////////////////////////////////////////////////////////////////////////
//	IDL methods and properties

STDMETHODIMP CMyCollection::Item (/*[in]*/ LONG index, /*[out]*/ VARIANT *pValue)
{
	HRESULT hr = S_OK;
	if (NULL == pValue)
		hr = E_POINTER;
	else if ((0 > index) || (index >= m_vecFileDesc.size()))
		hr = E_INVALIDARG;
	else
	{
		::VariantInit (pValue);
		hr = ::VariantCopy (/* dst */ pValue,
			/* src */ &this->m_convertedToInterfacePtr[index]);
	}
	return hr;
}

STDMETHODIMP CMyCollection::get_Count (/*[out, retval]*/ LONG *pCount)
{
	HRESULT hr = S_OK;
	if (NULL == pCount)
		hr = E_POINTER;
	else
		*pCount = this->m_convertedToInterfacePtr.size();
	return hr;
}

#if 0
template<class T>
class _CopyInterfaceToVariant
{
	static HRESULT copy (VARIANT *p1, T **p2)
	{
		T *p = *p2;
		V_VT(p1) = VT_UNKNOWN;
		V_DISPATCH(p1) = p;
		if (NULL != p)
			p->AddRef ();			
	};
	static void init (VARIANT *p1, T **p2)
	{
		::VariantInit (p1);
	};
	static void destroy (VARIANT *p1, T **p2)
	{
		::VariantClear (p1);
	};
};
#endif

STDMETHODIMP CMyCollection::get__NewEnum (/*[out, retval]*/ IUnknown **pUnknown)
{
	HRESULT hr = S_OK;
	if (NULL == pUnknown)
		hr = E_POINTER;
	else
	{
		typedef CComEnumOnSTL <
			IEnumVARIANT, &IID_IEnumVARIANT, 
			VARIANT,
			_Copy<VARIANT>, vector<VARIANT>
			> EnumVariant;

		CComObject<EnumVariant> *pEnumVariant = NULL;
		hr = CComObject<EnumVariant>::CreateInstance (&pEnumVariant);
		if (SUCCEEDED(hr))
		{
			pEnumVariant->AddRef();

			hr = pEnumVariant->Init (this->GetUnknown(), this->m_convertedToInterfacePtr);
			if (SUCCEEDED(hr))
				hr = pEnumVariant->QueryInterface (pUnknown);
			pEnumVariant->Release();
		}
	}
	return hr;
}

