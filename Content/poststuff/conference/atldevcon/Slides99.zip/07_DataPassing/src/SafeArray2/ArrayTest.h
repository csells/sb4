//	Hugh Brown
//	BROWN_HUGH@hotmail.com
//	Presented at ATL DevCon
//	Portland, 25 Jun 1999

// ArrayTest.h : Declaration of the CArrayTest

#ifndef __ARRAYTEST_H_
#define __ARRAYTEST_H_

#include "resource.h"       // main symbols

#include <vector>

/////////////////////////////////////////////////////////////////////////////
// CArrayTest
class ATL_NO_VTABLE CArrayTest : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CArrayTest, &CLSID_ArrayTest>,
	public ISupportErrorInfo,
	public IDispatchImpl<IArrayTest, &IID_IArrayTest, &LIBID_SAFEARRAY2Lib>
{
public:
	CArrayTest()
	{
	}

	HRESULT FinalConstruct ();
	void FinalRelease ();


DECLARE_REGISTRY_RESOURCEID(IDR_ARRAYTEST)
DECLARE_NOT_AGGREGATABLE(CArrayTest)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CArrayTest)
	COM_INTERFACE_ENTRY(IArrayTest)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IArrayTest
public:
	//	2-d SAFEARRAY of VARIANT
	//	1: file name, 2: file path, 3: file size, 4: file attribute
	STDMETHOD(Test1) (/*[in]*/ LONG count, /*[out, retval]*/  SAFEARRAY **psa);

	//	Same thing, packed into a VARIANT
	STDMETHOD(Test2) (/*[in]*/ LONG count, /*[out, retval]*/  VARIANT *psa);

	//	Interface pointer methods
	//	1-d SAFEARRAY of IDispatch pointer
	STDMETHOD(Test3) (/*[in]*/ LONG count, /*[out, retval]*/  SAFEARRAY **psa);

	//	Same thing packed into a VARIANT
	STDMETHOD(Test4) (/*[in]*/ LONG count, /*[out, retval]*/  VARIANT *psa);

	//	VT_RECORD methods
	//	1-d SAFEARRAY of IDispatch pointer
	STDMETHOD(Test5) (/*[in]*/ LONG count, /*[out, retval]*/  SAFEARRAY **psa);

	//	Same thing packed into a VARIANT
	STDMETHOD(Test6) (/*[in]*/ LONG count, /*[out, retval]*/  VARIANT *psa);



private:
	std::vector<FileDesc> m_vecFileDesc;
};

#endif //__ARRAYTEST_H_
