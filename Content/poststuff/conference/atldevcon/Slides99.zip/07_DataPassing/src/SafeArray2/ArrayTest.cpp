//	Hugh Brown
//	BROWN_HUGH@hotmail.com
//	Presented at ATL DevCon
//	Portland, 25 Jun 1999

// ArrayTest.cpp : Implementation of CArrayTest
#include "stdafx.h"
#include "SafeArray2.h"
#include "ArrayTest.h"
#include "FileInfo.h"

/////////////////////////////////////////////////////////////////////////////
// CArrayTest

STDMETHODIMP CArrayTest::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IArrayTest
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

/////////////////////////////////////////////////////////////////////////////
//	Internal methods

//	Fill the collection with the values
HRESULT CArrayTest::FinalConstruct ()
{
	HRESULT hr = S_OK;
	FILE *fp = fopen ("c:\\b", "r");
	if (NULL != fp)
	{
		char buf[512];
		while (fgets (buf, sizeof(buf), fp))
		{
			FileDesc dst;
			CComBSTR tmp;
			char *start, *end;
			start = buf;

			end = strchr (start, ',');
			*end = '\0';
			tmp = start;
			dst.fileName = tmp.Detach ();

			start = end + 1;
			end = strchr (start, ',');
			*end = '\0';
			tmp = start;
			dst.filePath = tmp.Detach ();

			start = end + 1;
			end = strchr (start, ',');
			*end = '\0';
			dst.fileLength = atol (start);

			start = end + 1;
			end = strchr (start, '\n');
			*end = '\0';
			dst.fileAttrib = atol (start);

			m_vecFileDesc.push_back (dst);
		}
		fclose (fp);
	}
	return hr;
}

//	Destroy the collection's values
void CArrayTest::FinalRelease ()
{
	long j = m_vecFileDesc.size();
	for (long i = 0; i < j; i++)
	{
		FileDesc &fd = this->m_vecFileDesc[i];
		::SysFreeString (fd.fileName);
		::SysFreeString (fd.filePath);
	}
}

static HRESULT PopulateFromVector (SAFEARRAY *sa, const std::vector<FileDesc> & fd, long count)
{
	HRESULT hr = S_OK;
	LONG index[2];
	for (LONG i = 0L; i < count; i++)
	{
		const FileDesc& elem = fd[i];
		index[0] = i;

		CComVariant v1;
	
		v1 = CComBSTR(elem.fileName);
		index[1] = 0;
		hr = ::SafeArrayPutElement (sa, index, (void *)((VARIANT *) &v1));
		if (FAILED(hr)) return hr;

		v1 = CComBSTR(elem.filePath);
		index[1] = 1;
		hr = ::SafeArrayPutElement (sa, index, (void *)((VARIANT *) &v1));
		if (FAILED(hr)) return hr;

		v1 = elem.fileLength;
		index[1] = 2;
		hr = ::SafeArrayPutElement (sa, index, (void *)((VARIANT *) &v1));
		if (FAILED(hr)) return hr;

		v1 = elem.fileAttrib;
		index[1] = 3;
		hr = ::SafeArrayPutElement (sa, index, (void *)((VARIANT *) &v1));
		if (FAILED(hr)) return hr;
	}
	return hr;
}

/////////////////////////////////////////////////////////////////////////////
//	IDL methods and properties

//	2-D SAFEARRAY of VARIANTs
STDMETHODIMP CArrayTest::Test1 (/*[in]*/ LONG count, /*[out, retval]*/  SAFEARRAY **psa)
{
	HRESULT hr = S_OK;
	const UINT cDims = 2;
	SAFEARRAYBOUND rgsabound[2];
	rgsabound[0].cElements = count;
	rgsabound[0].lLbound = 0;
	rgsabound[1].cElements = 4;
	rgsabound[1].lLbound = 0;

	*psa = NULL;
	SAFEARRAY *sa = ::SafeArrayCreate (VT_VARIANT, cDims, rgsabound);
	if (NULL != sa)
	{
		hr = PopulateFromVector (sa, this->m_vecFileDesc, count);
		*psa = sa;
	}
	
	return hr;
}

STDMETHODIMP CArrayTest::Test2 (/*[in]*/ LONG count, /*[out, retval]*/  VARIANT *psa)
{
	HRESULT hr = S_OK;
	const UINT cDims = 2;
	SAFEARRAYBOUND rgsabound[2];
	rgsabound[0].cElements = count;
	rgsabound[0].lLbound = 0;
	rgsabound[1].cElements = 4;
	rgsabound[1].lLbound = 0;

	::VariantInit (psa);
	SAFEARRAY *sa = ::SafeArrayCreate (VT_VARIANT, cDims, rgsabound);
	if (NULL != sa)
	{
		hr = PopulateFromVector (sa, this->m_vecFileDesc, count);
		if (SUCCEEDED(hr))
		{
			V_ARRAY(psa) = sa;
			V_VT(psa) = VT_ARRAY | VT_VARIANT;
		}
	}
	
	return hr;
}

//	1-D SAFEARRAY of interface pointers
STDMETHODIMP CArrayTest::Test3 (/*[in]*/ LONG count, /*[out, retval]*/  SAFEARRAY**psa)
{
	HRESULT hr = S_OK;
	const UINT cDims = 1;
	SAFEARRAYBOUND rgsabound[1];
	rgsabound[0].cElements = count;
	rgsabound[0].lLbound = 0;

	*psa = NULL;
	SAFEARRAY *sa = ::SafeArrayCreate (VT_DISPATCH, cDims, rgsabound);
	if (NULL != sa)
	{
		LONG index[1];
		for (long i = 0L; i < count; i++)
		{
			const FileDesc& elem = this->m_vecFileDesc[i];
			index[0] = i;

			CComObject<CFileInfo> *x = NULL;
			hr = CComObject<CFileInfo>::CreateInstance (&x);
			if (SUCCEEDED(hr))
			{
				x->Init (elem);
				IDispatch *pDisp = NULL;
				hr = x->QueryInterface (IID_IDispatch, (void **) &pDisp);
				if (SUCCEEDED(hr))
				{
					hr = ::SafeArrayPutElement (sa, index, (void *) pDisp);
					pDisp->Release ();
				}
			}
			if (FAILED(hr))
				return hr;
		}
		*psa = sa;
	}
	
	return hr;

}


STDMETHODIMP CArrayTest::Test4 (/*[in]*/ LONG count, /*[out, retval]*/  VARIANT *psa)
{
	HRESULT hr = S_OK;
	const UINT cDims = 1;
	SAFEARRAYBOUND rgsabound[1];
	rgsabound[0].cElements = count;
	rgsabound[0].lLbound = 0;

	::VariantInit (psa);

	SAFEARRAY *sa = ::SafeArrayCreate (VT_DISPATCH, cDims, rgsabound);
	if (NULL != sa)
	{
		LONG index[1];
		for (long i = 0L; i < count; i++)
		{
			const FileDesc& elem = this->m_vecFileDesc[i];
			index[0] = i;

			CComObject<CFileInfo> *x = NULL;
			hr = CComObject<CFileInfo>::CreateInstance (&x);
			if (SUCCEEDED(hr))
			{
				x->Init (elem);
				IDispatch *pDisp = NULL;
				hr = x->QueryInterface (IID_IDispatch, (void **) &pDisp);
				if (SUCCEEDED(hr))
				{
					hr = ::SafeArrayPutElement (sa, index, (void *) pDisp);
					pDisp->Release ();
				}
			}
			if (FAILED(hr))
				return hr;
		}

		V_VT(psa) = VT_ARRAY | VT_DISPATCH;
		V_ARRAY(psa) = sa;
	}
	
	return hr;
}

//	2-D SAFEARRAY of VARIANTs

static struct __declspec(uuid("B0D99C63-2672-11d3-B2E5-0000C08D84ED")) {} FileDesc_Dummy;

STDMETHODIMP CArrayTest::Test5 (/*[in]*/ LONG count, /*[out, retval]*/  SAFEARRAY**psa)
{
	HRESULT hr = S_OK;
	const UINT cDims = 1;
	SAFEARRAYBOUND rgsabound[1];
	rgsabound[0].cElements = count;
	rgsabound[0].lLbound = 0;

	*psa = NULL;

	CComPtr<IRecordInfo> pIR;
	hr = ::GetRecordInfoFromGuids (LIBID_SAFEARRAY2Lib,
					1L, 0L,
					NULL,
					__uuidof(FileDesc_Dummy), &pIR);

	if (SUCCEEDED(hr))
	{
		SAFEARRAY *sa = ::SafeArrayCreateEx (VT_RECORD, cDims, rgsabound, pIR.p);
		if (NULL != sa)
		{
			LONG index[1];
			for (long i = 0L; i < count; i++)
			{
				const FileDesc& elem = this->m_vecFileDesc[i];
				index[0] = i;

				hr = ::SafeArrayPutElement (sa, index, (void *) &elem);
				if (FAILED(hr))
					return hr;
			}
			*psa = sa;
		}
	}
	
	return hr;
}

STDMETHODIMP CArrayTest::Test6 (/*[in]*/ LONG count, /*[out, retval]*/  VARIANT *psa)
{
	HRESULT hr = S_OK;
	const UINT cDims = 1;
	SAFEARRAYBOUND rgsabound[1];
	rgsabound[0].cElements = count;
	rgsabound[0].lLbound = 0;

	::VariantInit (psa);

	CComPtr<IRecordInfo> pIR;
	hr = ::GetRecordInfoFromGuids (LIBID_SAFEARRAY2Lib,
					1L, 0L,
					NULL,
					__uuidof(FileDesc_Dummy), &pIR);

	if (SUCCEEDED(hr))
	{
		SAFEARRAY *sa = ::SafeArrayCreateEx (VT_RECORD, cDims, rgsabound, pIR.p);
		if (NULL != sa)
		{
			LONG index[1];
			for (long i = 0L; i < count; i++)
			{
				const FileDesc& elem = this->m_vecFileDesc[i];
				index[0] = i;

				hr = ::SafeArrayPutElement (sa, index, (void *) &elem);
				if (FAILED(hr))
					return hr;
			}

			V_VT(psa) = VT_ARRAY | VT_RECORD;
			V_ARRAY(psa) = sa;
		}
	}
	
	return hr;
}

