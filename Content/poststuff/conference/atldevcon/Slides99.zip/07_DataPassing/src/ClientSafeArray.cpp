//	Hugh Brown
//	BROWN_HUGH@hotmail.com
//	Presented at ATL DevCon
//	Portland, 25 Jun 1999

struct id_string {
	long id;
	string name;

	HRESULT CopyTo (SAFEARRAY *psa, LONG i) const;
	HRESULT CopyFrom (SAFEARRAY *psa, LONG i);
};

HRESULT id_string::CopyTo (SAFEARRAY *psa, LONG i) const
{
	HRESULT hr;
	LONG index[2];
	index[0] = i;

	_variant_t v1;
	
	v1 = id;
	index[1] = 0;
	hr = ::SafeArrayPutElement (psa, index, (void *)((VARIANT *)&v1));
	if (FAILED(hr)) return hr;

	v1 = _bstr_t(name.c_str());
	index[1] = 1;
	hr = ::SafeArrayPutElement (psa, index, (void *)((VARIANT *)&v1));
	if (FAILED(hr)) return hr;

	return hr;
}

HRESULT id_string::CopyFrom (SAFEARRAY *psa, LONG i)
{
	HRESULT hr = S_OK;
	LONG index[2];
	index[0] = i;

	_variant_t v1;
	
	index[1] = 0;
	hr = ::SafeArrayGetElement (psa, index, (void *)((VARIANT *)&v1));
	if (FAILED(hr)) return hr;
	id = v1;

	index[1] = 1;
	hr = ::SafeArrayGetElement (psa, index, (void *)((VARIANT *)&v1));
	if (FAILED(hr)) return hr;
	name = _bstr_t(v1);

	return hr;
}

//	Put the vector<id_string> m_value_types into a SAFEARRAY
//	inside pVal and return to caller
STDMETHODIMP XXX::get_Values(/*[out, retval]*/ VARIANT *pVal)
{
	HRESULT hr = getSafeArray<id_string, 2> (
					/* IN */ m_value_types,
					/* OUT */ pVal);
	return hr;
}

//	Put the values in the 2-d SAFEARRAY into the
//	vector<id_string> m_value_types
STDMETHODIMP XXX::put_Values(/*[out, retval]*/ VARIANT *pVal)
{
	HRESULT hr = putSafeArray<id_string, 2> (
					/* IN */ pVal,
					/* OUT */ m_value_types);
	return hr;
}
