//	Hugh Brown
//	BROWN_HUGH@hotmail.com
//	Presented at ATL DevCon
//	Portland, 25 Jun 1999

// MyEnumeration.cpp : Implementation of CMyEnumeration
#include "stdafx.h"
#include "Enumeration.h"
#include "MyEnumeration.h"

/////////////////////////////////////////////////////////////////////////////
//	InterfaceSupportsErrorInfo

STDMETHODIMP CMyEnumeration::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IMyEnumeration
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

/////////////////////////////////////////////////////////////////////////////
//	IDL methods and properties

STDMETHODIMP CMyEnumeration::Next (
			/*[in]*/ ULONG cElements,
			/*[out, size_is(cElements), length_is(*pcElementsFetched)]*/ VARIANT *pVariants,
			/*[out]*/ ULONG *pcElementsFetched)
{
	HRESULT hr = S_OK;
	return hr;
}

STDMETHODIMP CMyEnumeration::Skip (/*[in]*/ ULONG cElements)
{
	HRESULT hr = S_OK;
	return hr;
}

STDMETHODIMP CMyEnumeration::Reset ()
{
	HRESULT hr = S_OK;
	return hr;
}

STDMETHODIMP CMyEnumeration::Clone (/*[out]*/ IEnumVARIANT **ppEnum)
{
	HRESULT hr = S_OK;
	return hr;
}


