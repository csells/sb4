//	Hugh Brown
//	BROWN_HUGH@hotmail.com
//	Presented at ATL DevCon
//	Portland, 25 Jun 1999

// MyEnumeration.h : Declaration of the CMyEnumeration

#ifndef __MYENUMERATION_H_
#define __MYENUMERATION_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CMyEnumeration
class ATL_NO_VTABLE CMyEnumeration : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CMyEnumeration, &CLSID_MyEnumeration>,
	public ISupportErrorInfo,
	public IDispatchImpl<IMyEnumeration, &IID_IMyEnumeration, &LIBID_ENUMERATIONLib>
{
public:
	CMyEnumeration()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_MYENUMERATION)
DECLARE_NOT_AGGREGATABLE(CMyEnumeration)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CMyEnumeration)
	COM_INTERFACE_ENTRY(IMyEnumeration)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IMyEnumeration
public:
	STDMETHOD(Next) (
			/*[in]*/ ULONG cElements,
			/*[out, size_is(cElements), length_is(*pcElementsFetched)]*/ VARIANT *pVariants,
			/*[out]*/ ULONG *pcElementsFetched);
	STDMETHOD(Skip) (/*[in]*/ ULONG cElements);
	STDMETHOD(Reset) ();
	STDMETHOD(Clone) (/*[out]*/ IEnumVARIANT **ppEnum);

};

#endif //__MYENUMERATION_H_
