/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Fri Jul 02 10:13:13 1999
 */
/* Compiler settings for C:\xxx\Presentations\code\enumeration\enumeration.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __enumeration_h__
#define __enumeration_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IMyEnumeration_FWD_DEFINED__
#define __IMyEnumeration_FWD_DEFINED__
typedef interface IMyEnumeration IMyEnumeration;
#endif 	/* __IMyEnumeration_FWD_DEFINED__ */


#ifndef __MyEnumeration_FWD_DEFINED__
#define __MyEnumeration_FWD_DEFINED__

#ifdef __cplusplus
typedef class MyEnumeration MyEnumeration;
#else
typedef struct MyEnumeration MyEnumeration;
#endif /* __cplusplus */

#endif 	/* __MyEnumeration_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IMyEnumeration_INTERFACE_DEFINED__
#define __IMyEnumeration_INTERFACE_DEFINED__

/* interface IMyEnumeration */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IMyEnumeration;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("FBEAD3ED-2673-11D3-B2E5-0000C08D84ED")
    IMyEnumeration : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Next( 
            /* [in] */ ULONG cElements,
            /* [length_is][size_is][out] */ VARIANT __RPC_FAR *pVariants,
            /* [out] */ ULONG __RPC_FAR *pcElementsFetched) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Skip( 
            /* [in] */ ULONG cElements) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Reset( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Clone( 
            /* [out] */ IEnumVARIANT __RPC_FAR *__RPC_FAR *ppEnum) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IMyEnumerationVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IMyEnumeration __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IMyEnumeration __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IMyEnumeration __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IMyEnumeration __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IMyEnumeration __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IMyEnumeration __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IMyEnumeration __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Next )( 
            IMyEnumeration __RPC_FAR * This,
            /* [in] */ ULONG cElements,
            /* [length_is][size_is][out] */ VARIANT __RPC_FAR *pVariants,
            /* [out] */ ULONG __RPC_FAR *pcElementsFetched);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Skip )( 
            IMyEnumeration __RPC_FAR * This,
            /* [in] */ ULONG cElements);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Reset )( 
            IMyEnumeration __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Clone )( 
            IMyEnumeration __RPC_FAR * This,
            /* [out] */ IEnumVARIANT __RPC_FAR *__RPC_FAR *ppEnum);
        
        END_INTERFACE
    } IMyEnumerationVtbl;

    interface IMyEnumeration
    {
        CONST_VTBL struct IMyEnumerationVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IMyEnumeration_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IMyEnumeration_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IMyEnumeration_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IMyEnumeration_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IMyEnumeration_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IMyEnumeration_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IMyEnumeration_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IMyEnumeration_Next(This,cElements,pVariants,pcElementsFetched)	\
    (This)->lpVtbl -> Next(This,cElements,pVariants,pcElementsFetched)

#define IMyEnumeration_Skip(This,cElements)	\
    (This)->lpVtbl -> Skip(This,cElements)

#define IMyEnumeration_Reset(This)	\
    (This)->lpVtbl -> Reset(This)

#define IMyEnumeration_Clone(This,ppEnum)	\
    (This)->lpVtbl -> Clone(This,ppEnum)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IMyEnumeration_Next_Proxy( 
    IMyEnumeration __RPC_FAR * This,
    /* [in] */ ULONG cElements,
    /* [length_is][size_is][out] */ VARIANT __RPC_FAR *pVariants,
    /* [out] */ ULONG __RPC_FAR *pcElementsFetched);


void __RPC_STUB IMyEnumeration_Next_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMyEnumeration_Skip_Proxy( 
    IMyEnumeration __RPC_FAR * This,
    /* [in] */ ULONG cElements);


void __RPC_STUB IMyEnumeration_Skip_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMyEnumeration_Reset_Proxy( 
    IMyEnumeration __RPC_FAR * This);


void __RPC_STUB IMyEnumeration_Reset_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMyEnumeration_Clone_Proxy( 
    IMyEnumeration __RPC_FAR * This,
    /* [out] */ IEnumVARIANT __RPC_FAR *__RPC_FAR *ppEnum);


void __RPC_STUB IMyEnumeration_Clone_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IMyEnumeration_INTERFACE_DEFINED__ */



#ifndef __ENUMERATIONLib_LIBRARY_DEFINED__
#define __ENUMERATIONLib_LIBRARY_DEFINED__

/* library ENUMERATIONLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_ENUMERATIONLib;

EXTERN_C const CLSID CLSID_MyEnumeration;

#ifdef __cplusplus

class DECLSPEC_UUID("FBEAD3EE-2673-11D3-B2E5-0000C08D84ED")
MyEnumeration;
#endif
#endif /* __ENUMERATIONLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  VARIANT_UserSize(     unsigned long __RPC_FAR *, unsigned long            , VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
void                      __RPC_USER  VARIANT_UserFree(     unsigned long __RPC_FAR *, VARIANT __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
