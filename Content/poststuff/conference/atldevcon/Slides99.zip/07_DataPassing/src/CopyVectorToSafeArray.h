//	Hugh Brown
//	BROWN_HUGH@hotmail.com
//	Presented at ATL DevCon
//	Portland, 25 Jun 1999

#pragma once
#ifndef _CopyVectorToSafeArray_H
#define _CopyVectorToSafeArray_H		1

//
//	Copy a vector of VT_RECORD structures to a SAFEARRAY
//
template<class T>
HRESULT CopyVectorToSafeArray (
	/* in */ const GUID& guidOfTypeLibrary,
	/* in */ const GUID& guidOfStruct,
	/* in */ const std::vector<T>& elements,
	/* out */ SAFEARRAY **psa)
{
	CComPtr<IRecordInfo> pRecInfo;
	HRESULT hr = ::GetRecordInfoFromGuids(
				guidOfTypeLibrary, 
                1, 0,
                LOCALE_NEUTRAL, 
                guidOfStruct, 
                &pRecInfo);
	if (SUCCEEDED(hr))
	{
		const long elementCount = elements.size();
		SAFEARRAYBOUND sb;
		sb.cElements = elementCount;
		sb.lLbound = 0L;
		
		SAFEARRAY *sa = ::SafeArrayCreateEx(VT_RECORD, 1, &sb, pRecInfo.p);
		if (NULL != sa)
		{		
			for (long i = 0L; i < elementCount; i++)
			{
				T& element = elements[i];
				hr = ::SafeArrayPutElement(sa, &i,
						reinterpret_cast<void *>(&element));
			}
			::SafeArraySetRecordInfo(psa, pRecInfo.p);
			pRecInfo->AddRef ();
			*psa = sa;
		}
		else
			hr = E_OUTOFMEMORY;
	}
	return hr;
}

//
//	Copy a vector of VT_RECORD structures to VARIANT containing a SAFEARRAY
//
template<class T>
HRESULT CopyVectorToSafeArray (
	/* in */ const GUID& guidOfTypeLibrary,
	/* in */ const GUID& guidOfStruct,
	/* in */ const vector<T>& elements,
	/* out */ VARIANT *pVal)
{
	HRESULT hr = S_OK;
	if (NULL == pVal)
		hr = E_POINTER;
	else
	{
		SAFEARRAY *psa = NULL;
		::VariantClear(pVal);
		hr = CopyVectorToSafeArray<T> (guidOfTypeLibrary,
							   guidOfStruct,
							   elements,
							   &psa);
		if (SUCCEEDED(hr))
		{
			V_ARRAY(pVal) = psa;
			V_VT(pVal) = VT_ARRAY | VT_RECORD;
		}
	}
	return hr;
}

#endif
