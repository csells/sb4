//	Hugh Brown
//	BROWN_HUGH@hotmail.com
//	Presented at ATL DevCon
//	Portland, 25 Jun 1999

#pragma once
#ifndef _CopyRecordToVariant_H
#define _CopyRecordToVariant_H		1

//
//	Copy a VT_RECORD record to a VARIANT
//
template <typename T>
HRESULT CopyRecordToVariant (
	/* in */ const GUID& guidOfTypeLibrary,
	/* in */ const GUID& guidOfStruct,
	/* in */ const T *pRecord,
	/* out */ VARIANT *val)
{
	IRecordInfo *pRecInfo = NULL;
	HRESULT hr = ::GetRecordInfoFromGuids(
			guidOfTypeLibrary, 
                        1, 0,
                        LOCALE_NEUTRAL, 
                        guidOfStruct, 
                        &pRecInfo);
	if (SUCCEEDED(hr))
	{
		::VariantInit(val);
		V_VT(val) = VT_RECORD;
		V_RECORD(val) = const_cast<T *>(pRecord);
		V_RECORDINFO(val) = pRecInfo;
		pRecInfo->AddRef();
	}
	return hr;
}
#endif
