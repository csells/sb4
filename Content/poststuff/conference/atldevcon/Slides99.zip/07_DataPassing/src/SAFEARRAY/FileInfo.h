//	Hugh Brown
//	BROWN_HUGH@hotmail.com
//	Presented at ATL DevCon
//	Portland, 25 Jun 1999

// FileInfo.h : Declaration of the CFileInfo

#ifndef __FILEINFO_H_
#define __FILEINFO_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CFileInfo
class ATL_NO_VTABLE CFileInfo : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CFileInfo, &CLSID_FileInfo>,
	public ISupportErrorInfo,
	public IDispatchImpl<IFileInfo, &IID_IFileInfo, &LIBID_SAFEARRAYLib>
{
public:
	CFileInfo()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_FILEINFO)
DECLARE_NOT_AGGREGATABLE(CFileInfo)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CFileInfo)
	COM_INTERFACE_ENTRY(IFileInfo)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IFileInfo
public:
	STDMETHOD(get_FileSize) (/*[out, retval]*/ LONG *size);

	void Init (const FileDesc& src);

private:
	CComBSTR m_filename, m_filepath;
	long m_size, m_attrib;

};

#endif //__FILEINFO_H_
