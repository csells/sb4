//	Hugh Brown
//	BROWN_HUGH@hotmail.com
//	Presented at ATL DevCon
//	Portland, 25 Jun 1999

// FileInfo.cpp : Implementation of CFileInfo
#include "stdafx.h"
#include "SAFEARRAY.h"
#include "FileInfo.h"

/////////////////////////////////////////////////////////////////////////////
// CFileInfo

STDMETHODIMP CFileInfo::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IFileInfo
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

void CFileInfo::Init (const FileDesc& src)
{
	this->m_filename = src.fileName;
	this->m_filepath = src.filePath;
	this->m_size = src.fileLength;
	this->m_attrib = src.fileAttrib;
}

STDMETHODIMP CFileInfo::get_FileSize (/*[out, retval]*/ LONG *size)
{
	*size = m_size;
	return S_OK;
}
